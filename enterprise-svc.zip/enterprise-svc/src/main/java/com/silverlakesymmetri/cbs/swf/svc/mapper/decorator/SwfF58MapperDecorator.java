package com.silverlakesymmetri.cbs.swf.svc.mapper.decorator;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

import com.silverlakesymmetri.cbs.swf.jpa.mapping.sdo.SwfFinEntityJpe;
import com.silverlakesymmetri.cbs.swf.svc.mapper.mapping.SwfF58Mapper;
import com.silverlakesymmetri.cbs.swf.xmlapi.SWFF58TYPEType;

public abstract class SwfF58MapperDecorator implements SwfF58Mapper {
	
	@Autowired
	@Qualifier("delegate")
	protected SwfF58Mapper delegate;

	@Override
	public SWFF58TYPEType mapToApi(SwfFinEntityJpe jpe){
		SWFF58TYPEType swfF58 = delegate.mapToApi(jpe);
		if(swfF58 != null && swfF58.getACCOUNT() == null && swfF58.getADDRESS() == null && swfF58.getBIC() == null && swfF58.getBRANCHLOCATION() == null){
			return null;
		}
		return swfF58;
	}
	
	@Override
	public SwfFinEntityJpe mapToJpe(SWFF58TYPEType api){
		return delegate.mapToJpe(api);
	}
	
}
