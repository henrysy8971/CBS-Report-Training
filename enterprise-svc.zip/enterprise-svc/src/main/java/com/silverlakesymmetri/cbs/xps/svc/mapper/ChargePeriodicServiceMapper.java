package com.silverlakesymmetri.cbs.xps.svc.mapper;

import org.mapstruct.DecoratedWith;
import org.mapstruct.InheritInverseConfiguration;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingTarget;
import org.mapstruct.Mappings;

import com.silverlakesymmetri.cbs.commons.jpa.util.DateTimeHelper;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.ChargePeriodicJpe;
import com.silverlakesymmetri.cbs.xps.svc.mapper.decorator.ChargePeriodicServiceDecorator;
import com.silverlakesymmetri.cbs.xps.xmlapi.XPSTRANCHARGEDETAILAPIType;

@Mapper(uses = { DateTimeHelper.class, ChargePeriodicSlabServiceMapper.class })
@DecoratedWith(ChargePeriodicServiceDecorator.class)
public interface ChargePeriodicServiceMapper {

	@Mappings({
		@Mapping(source="rateLadder", target = "RATELADDER"),
		@Mapping(source="noOfDays", target = "NOOFDAYS"),
		@Mapping(source="calculationType", target = "CALCULATIONTYPE"),
		@Mapping(source="perPeriodDays", target = "PERPERIODDAYS"),
		@Mapping(source="graceDays", target = "GRACEDAYS"),
		@Mapping(source="npDaysForCalculation", target = "NPDAYSFORCALCULATION"),
		@Mapping(source="startDate", target = "STARTDATE", qualifiedByName = {"DateTimeHelper", "convertDateToCbsXmlApiDate"}),
		@Mapping(source="endDate", target = "ENDDATE", qualifiedByName = {"DateTimeHelper", "convertDateToCbsXmlApiDate"}),
		@Mapping(source="amendStartDate", target = "AMENDSTARTDATE", qualifiedByName = {"DateTimeHelper", "convertDateToCbsXmlApiDate"}),
		@Mapping(source="amendEndDate", target = "AMENDENDDATE", qualifiedByName = {"DateTimeHelper", "convertDateToCbsXmlApiDate"}),
		@Mapping(source="noExtendedDays", target = "NPEXTENDEDDAYS"),
		@Mapping(source="setupCcy", target = "SETUPCCY"),
		@Mapping(source="amendBalanceAmt", target = "AMENDBALANCEAMT"),
		@Mapping(source="overallMinAmt", target = "OVERALLMINAMT"),
		@Mapping(source="overallMaxAmt", target = "OVERALLMAXAMT"),
		@Mapping(source="perAnnumMinAmt", target = "PERANNUMMINAMT"),
		@Mapping(source="perAnnumMaxAmt", target = "PERANNUMMAXAMT"),
		@Mapping(source="amtType", target = "AMTTYPE"),
		@Mapping(source="basisAmt", target = "BASISAMT"),
		@Mapping(source="basisCcy", target = "BASISCCY"),
		@Mapping(source="basisCalcAmt", target = "BASISCALCAMT"),
		@Mapping(source="exchRate", target = "EXCHRATE"),
		@Mapping(source="exchQuote", target = "EXCHQUOTE"),
		@Mapping(source="amount", target = "AMOUNT"),
		@Mapping(source="calculatedAmt", target = "CALCULATEDAMT"),
		@Mapping(source="periodicSlabList", target = "SLABS.XPSTRANCHARGEDETAILSLABTYPE")
	})
	public XPSTRANCHARGEDETAILAPIType mapToApi(ChargePeriodicJpe jpe, @MappingTarget XPSTRANCHARGEDETAILAPIType api);

	@InheritInverseConfiguration(name = "mapToApi")
	@Mappings({
		@Mapping(source = "AMENDSTARTDATE", target = "amendStartDate", qualifiedByName = {"DateTimeHelper", "convertCbsApiDateToString"}),
		@Mapping(source = "AMENDENDDATE", target = "amendEndDate", qualifiedByName = {"DateTimeHelper", "convertCbsApiDateToString"}),
		@Mapping(source = "STARTDATE", target = "startDate", qualifiedByName = {"DateTimeHelper", "convertCbsApiDateToString"}),
		@Mapping(source = "ENDDATE", target = "endDate", qualifiedByName = {"DateTimeHelper", "convertCbsApiDateToString"})
	})
	public ChargePeriodicJpe mapToJpe(XPSTRANCHARGEDETAILAPIType api, @MappingTarget ChargePeriodicJpe jpe);

	@InheritInverseConfiguration(name = "mapToApi")
	@Mappings({
		@Mapping(source = "AMENDSTARTDATE", target = "amendStartDate", qualifiedByName = {"DateTimeHelper", "convertCbsApiDateToString"}),
		@Mapping(source = "AMENDENDDATE", target = "amendEndDate", qualifiedByName = {"DateTimeHelper", "convertCbsApiDateToString"}),
		@Mapping(source = "STARTDATE", target = "startDate", qualifiedByName = {"DateTimeHelper", "convertCbsApiDateToString"}),
		@Mapping(source = "ENDDATE", target = "endDate", qualifiedByName = {"DateTimeHelper", "convertCbsApiDateToString"})
	})
	public ChargePeriodicJpe mapToJpe(XPSTRANCHARGEDETAILAPIType api);
}