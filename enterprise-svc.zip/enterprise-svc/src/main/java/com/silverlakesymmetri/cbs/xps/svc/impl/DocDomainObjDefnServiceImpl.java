package com.silverlakesymmetri.cbs.xps.svc.impl;

import com.mysema.query.types.EntityPath;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.svc.AbstractBusinessService;
import com.silverlakesymmetri.cbs.commons.svc.BusinessObjectValidationCapable;
import com.silverlakesymmetri.cbs.xps.bdo.sdo.DocDomainObjDefn;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.DocDomainObjDefnJpe;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.QDocDomainObjDefnJpe;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.id.DocDomainObjDefnPk;
import com.silverlakesymmetri.cbs.xps.svc.DocDomainObjDefnService;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Map;

@Service
@Transactional
public class DocDomainObjDefnServiceImpl extends AbstractBusinessService<DocDomainObjDefn, DocDomainObjDefnJpe, DocDomainObjDefnPk> implements DocDomainObjDefnService, BusinessObjectValidationCapable<DocDomainObjDefn> {
	
	@Override
	protected DocDomainObjDefnPk getIdFromDataObjectInstance(DocDomainObjDefn dataObject) {
		return new DocDomainObjDefnPk(dataObject.getModuleRefDomain(), dataObject.getRefDomain(),
			dataObject.getRefDomainKey(), dataObject.getDocumentType(), dataObject.getRefObjectKey());
	}

	@Override
	protected EntityPath<DocDomainObjDefnJpe> getEntityPath() {
		return QDocDomainObjDefnJpe.docDomainObjDefnJpe;
	}

	@Override
	public DocDomainObjDefn getByPk(String publicKey, DocDomainObjDefn reference) {
		return super.getByPk(publicKey, reference);
	}
	
	@Override
	public List<DocDomainObjDefn> query(int offset, int resultLimit, String groupBy, String order, Map<String, Object> filters) {
		return super.query(offset, resultLimit, groupBy, order, filters);
	}
	
	@Override
	public List<DocDomainObjDefn> find(FindCriteria findCriteria, CbsHeader cbsHeader){
		return super.find(findCriteria, cbsHeader);
	}
	
	@Override
	public DocDomainObjDefn create(DocDomainObjDefn dataObject) {
		return super.create(dataObject);
	}
	
	@Override
	public DocDomainObjDefn update(DocDomainObjDefn dataObject) {
		return super.update(dataObject);
	}
	
	@Override
	public boolean delete(DocDomainObjDefn dataObject) {
		return super.delete(dataObject);
	}
}