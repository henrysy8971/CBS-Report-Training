package com.silverlakesymmetri.cbs.gla.svc;

import java.util.Map;

import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation;
import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation.ServiceOperationType;
import com.silverlakesymmetri.cbs.commons.svc.BusinessService;
import com.silverlakesymmetri.cbs.gla.bdo.sdo.ProjectedNostroBalanceDetail;
import com.silverlakesymmetri.cbs.gla.jpa.mapping.sdo.ProjectedNostroBalanceDetailJpe;

public interface ProjectedNostroBalanceDetailService extends BusinessService<ProjectedNostroBalanceDetail, ProjectedNostroBalanceDetailJpe> {

	public static final String SVC_OP_NAME_PROJECTEDNOSTRODETAILBALANCESERVICE_GET = "ProjectedNostroBalanceDetailService.getQueryDetailApi";
	
    @ServiceOperation(name = SVC_OP_NAME_PROJECTEDNOSTRODETAILBALANCESERVICE_GET, type = ServiceOperationType.GET, passParamAsMap = true)
    public ProjectedNostroBalanceDetail getQueryDetailApi(Map<String, Object> queryParams);
}