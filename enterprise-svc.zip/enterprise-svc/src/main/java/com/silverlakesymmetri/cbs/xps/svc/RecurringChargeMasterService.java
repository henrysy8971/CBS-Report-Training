package com.silverlakesymmetri.cbs.xps.svc;

import java.util.List;
import java.util.Map;

import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation;
import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation.ServiceOperationType;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.svc.BusinessService;
import com.silverlakesymmetri.cbs.xps.bdo.sdo.ChargeMaster;
import com.silverlakesymmetri.cbs.xps.bdo.sdo.RecurringChargeMaster;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.RecurringChargeMasterJpe;

public interface RecurringChargeMasterService extends BusinessService<RecurringChargeMaster, RecurringChargeMasterJpe> {
	public static final String SVC_OP_NAME_RECURRINGCHARGEMASTERSERVICE_CREATE = "RecurringChargeMasterService.create";
	public static final String SVC_OP_NAME_RECURRINGCHARGEMASTERSERVICE_UPDATE = "RecurringChargeMasterService.update";
	public static final String SVC_OP_NAME_RECURRINGCHARGEMASTERSERVICE_DELETE = "RecurringChargeMasterService.delete";
	public static final String SVC_OP_NAME_RECURRINGCHARGEMASTERSERVICE_GET = "RecurringChargeMasterService.get";
	public static final String SVC_OP_NAME_RECURRINGCHARGEMASTERSERVICE_QUERY = "RecurringChargeMasterService.query";
	public static final String SVC_OP_NAME_RECURRINGCHARGEMASTERSERVICE_FIND = "RecurringChargeMasterService.find";
	public static final String SVC_OP_NAME_RECURRINGCHARGEMASTERSERVICE_COUNT = "RecurringChargeMasterService.count";
	
	@ServiceOperation(name = SVC_OP_NAME_RECURRINGCHARGEMASTERSERVICE_GET, type = ServiceOperationType.GET)
    public RecurringChargeMaster getByPk(String publicKey, RecurringChargeMaster reference);
    
    @ServiceOperation(name = SVC_OP_NAME_RECURRINGCHARGEMASTERSERVICE_CREATE)
    public RecurringChargeMaster create(RecurringChargeMaster dataObject);

    @ServiceOperation(name = SVC_OP_NAME_RECURRINGCHARGEMASTERSERVICE_UPDATE)
    public RecurringChargeMaster update(RecurringChargeMaster dataObject);

    @ServiceOperation(name = SVC_OP_NAME_RECURRINGCHARGEMASTERSERVICE_DELETE)
    public boolean delete(RecurringChargeMaster dataObject);
    
    @ServiceOperation(name = SVC_OP_NAME_RECURRINGCHARGEMASTERSERVICE_COUNT, type = ServiceOperationType.GET)
    public Long count(FindCriteria findCriteria, CbsHeader cbsHeader);
    
    @ServiceOperation(name = SVC_OP_NAME_RECURRINGCHARGEMASTERSERVICE_QUERY)
    public List<RecurringChargeMaster> query(int offset, int resultLimit, String groupBy, String order, Map<String, Object> filters);
    
    @ServiceOperation(name = SVC_OP_NAME_RECURRINGCHARGEMASTERSERVICE_FIND)
    public List<RecurringChargeMaster> find(FindCriteria findCriteria, CbsHeader cbsHeader);
}
