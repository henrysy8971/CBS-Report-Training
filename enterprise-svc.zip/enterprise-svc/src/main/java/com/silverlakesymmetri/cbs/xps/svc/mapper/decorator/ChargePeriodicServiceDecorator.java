package com.silverlakesymmetri.cbs.xps.svc.mapper.decorator;

import org.mapstruct.MappingTarget;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.ChargePeriodicJpe;
import com.silverlakesymmetri.cbs.xps.svc.mapper.ChargePeriodicServiceMapper;
import com.silverlakesymmetri.cbs.xps.xmlapi.XPSTRANCHARGEDETAILAPIType;

public abstract class ChargePeriodicServiceDecorator implements ChargePeriodicServiceMapper {
	
	@Autowired
	@Qualifier("delegate")
	protected ChargePeriodicServiceMapper delegate;

	@Override
	public XPSTRANCHARGEDETAILAPIType mapToApi(ChargePeriodicJpe jpe, @MappingTarget XPSTRANCHARGEDETAILAPIType api){
		delegate.mapToApi(jpe, api);
		return api;
	}
	
	@Override
	public ChargePeriodicJpe mapToJpe(XPSTRANCHARGEDETAILAPIType api, @MappingTarget ChargePeriodicJpe jpe){
		delegate.mapToJpe(api, jpe);
		return jpe;
	}

}


