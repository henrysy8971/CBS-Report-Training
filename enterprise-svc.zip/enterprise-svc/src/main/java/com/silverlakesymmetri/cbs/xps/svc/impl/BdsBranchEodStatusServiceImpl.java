package com.silverlakesymmetri.cbs.xps.svc.impl;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.mysema.query.types.EntityPath;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.svc.AbstractBusinessService;
import com.silverlakesymmetri.cbs.commons.svc.BusinessObjectValidationCapable;
import com.silverlakesymmetri.cbs.xps.bdo.sdo.BdsBranchEodStatus;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.BdsBranchEodStatusJpe;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.QBdsBranchEodStatusJpe;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.id.BdsBranchEodStatusPk;
import com.silverlakesymmetri.cbs.xps.svc.BdsBranchEodStatusService;

@Service
@Transactional
public class BdsBranchEodStatusServiceImpl extends AbstractBusinessService<BdsBranchEodStatus, BdsBranchEodStatusJpe, BdsBranchEodStatusPk> implements BdsBranchEodStatusService, BusinessObjectValidationCapable<BdsBranchEodStatus> {

    private static final String EODIND_N = "N";

    @Override
    protected BdsBranchEodStatusPk getIdFromDataObjectInstance(BdsBranchEodStatus dataObject) {
        return new BdsBranchEodStatusPk(dataObject.getBranch());
    }

    @Override
    protected EntityPath<BdsBranchEodStatusJpe> getEntityPath() {
        return QBdsBranchEodStatusJpe.bdsBranchEodStatusJpe;
    }

    @Override
    public BdsBranchEodStatus getByPk(String publicKey, BdsBranchEodStatus reference) {
        return super.getByPk(publicKey, reference);
    }

    @Override
    public List<BdsBranchEodStatus> query(int offset, int resultLimit, String groupBy, String order, Map<String, Object> filters) {
        return super.query(offset, resultLimit, groupBy, order, filters);
    }

    @Override
    public List<BdsBranchEodStatus> find(FindCriteria findCriteria, CbsHeader cbsHeader) {
        return super.find(findCriteria, cbsHeader);
    }
    
    @Override
    public BdsBranchEodStatus preCreateValidation(BdsBranchEodStatus dataObject) {
        BdsBranchEodStatusJpe jpe = jaxbSdoHelper.unwrap(dataObject);
        setDefaultings(jpe);
        return super.preCreateValidation(jaxbSdoHelper.wrap(jpe, BdsBranchEodStatus.class));
    }

    @Override
    public BdsBranchEodStatus preUpdateValidation(BdsBranchEodStatus dataObject) {
        BdsBranchEodStatusJpe jpe = jaxbSdoHelper.unwrap(dataObject);
        setDefaultings(jpe);
        return super.preUpdateValidation(jaxbSdoHelper.wrap(jpe, BdsBranchEodStatus.class));
    }

    @Override
    public BdsBranchEodStatus update(BdsBranchEodStatus dataObject) {
        BdsBranchEodStatusJpe jpe = dataService.find(BdsBranchEodStatusJpe.class, dataObject.getBranch());
        if (jpe == null) {
            return super.create(dataObject);
        }
        return super.update(dataObject);
    }
    
    private void setDefaultings(BdsBranchEodStatusJpe jpe) {
        if (jpe.getEodInd() == null || jpe.getEodInd().isEmpty()) {
            jpe.setEodInd(EODIND_N);
        }
    }
}