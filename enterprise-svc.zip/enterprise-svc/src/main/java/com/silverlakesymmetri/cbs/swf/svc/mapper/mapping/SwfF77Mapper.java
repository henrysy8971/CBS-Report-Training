package com.silverlakesymmetri.cbs.swf.svc.mapper.mapping;

import org.apache.commons.lang3.StringUtils;
import org.mapstruct.DecoratedWith;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Mappings;

import com.silverlakesymmetri.cbs.swf.jpa.mapping.sdo.SwfF77Jpe;
import com.silverlakesymmetri.cbs.swf.svc.mapper.decorator.SwfF77MapperDecorator;
import com.silverlakesymmetri.cbs.swf.xmlapi.SWFF77TYPEType;

@Mapper(imports=StringUtils.class, uses = SwfF77NarrativeMapper.class)
@DecoratedWith(SwfF77MapperDecorator.class)
public interface SwfF77Mapper {
	@Mappings({
		@Mapping(source="opt", target="OPT"),
		@Mapping(source="swfF77NarrativeList", target="DETAILS.SWFF77NARRATIVETYPE")
	})
	SWFF77TYPEType mapToApi(SwfF77Jpe jpe);
	
	@Mappings({
		@Mapping(target="opt", expression="java(StringUtils.isNotBlank(api.getOPT())?api.getOPT():null)"),
		@Mapping(target="swfF77NarrativeList", source="DETAILS.SWFF77NARRATIVETYPE")
	})
	SwfF77Jpe mapToJpe(SWFF77TYPEType api);
}