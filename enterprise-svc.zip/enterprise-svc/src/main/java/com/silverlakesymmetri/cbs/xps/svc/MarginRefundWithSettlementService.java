package com.silverlakesymmetri.cbs.xps.svc;

import java.util.Map;

import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation;
import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation.ServiceOperationType;
import com.silverlakesymmetri.cbs.commons.bdo.sdo.DmsFile;
import com.silverlakesymmetri.cbs.commons.svc.BusinessService;
import com.silverlakesymmetri.cbs.xps.bdo.sdo.AdvicePreview;
import com.silverlakesymmetri.cbs.xps.bdo.sdo.MarginRefundWithSettlement;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.MarginRefundWithSettlementJpe;

public interface MarginRefundWithSettlementService extends BusinessService<MarginRefundWithSettlement, MarginRefundWithSettlementJpe> {
	public static final String XPS_MARGINREFUNDWITHSETTLEMENTSERVICE_GET = "MarginRefundWithSettlementService.get";
    public static final String XPS_MARGINREFUNDWITHSETTLEMENTSERVICE_CREATE = "MarginRefundWithSettlementService.create";
    public static final String XPS_MARGINREFUNDWITHSETTLEMENTSERVICE_UPDATE = "MarginRefundWithSettlementService.update";
    public static final String XPS_MARGINREFUNDWITHSETTLEMENTSERVICE_DELETE = "MarginRefundWithSettlementService.delete";
	public static final String XPS_MARGINREFUNDWITHSETTLEMENTSERVICE_SWFMSG = "MarginRefundWithSettlementService.generateSwfMessage";
    public static final String XPS_MARGINREFUNDWITHSETTLEMENTSERVICE_EMAILPREVIEW = "MarginRefundWithSettlementService.generateEmailPreview";
    public static final String XPS_MARGINREFUNDWITHSETTLEMENTSERVICE_GENADVICE = "MarginRefundWithSettlementService.generateAdvice";
    public static final String XPS_MARGINREFUNDWITHSETTLEMENTSERVICE_GETATTACHED = "MarginRefundWithSettlementService.getAttachedMarginWithRefund";
    public static final String XPS_MARGINREFUNDWITHSETTLEMENTSERVICE_GETATTACHEDWITHREFNO = "MarginRefundWithSettlementService.getAttachedMarginWithRefundWithRefNo";
    
    @ServiceOperation(name = XPS_MARGINREFUNDWITHSETTLEMENTSERVICE_GET, type = ServiceOperationType.GET)
    public MarginRefundWithSettlement getByPk(String publicKey, MarginRefundWithSettlement reference);
    
    @ServiceOperation(name = XPS_MARGINREFUNDWITHSETTLEMENTSERVICE_CREATE)
    public MarginRefundWithSettlement create(MarginRefundWithSettlement dataObject);

    @ServiceOperation(name = XPS_MARGINREFUNDWITHSETTLEMENTSERVICE_UPDATE)
    public MarginRefundWithSettlement update(MarginRefundWithSettlement dataObject);

    @ServiceOperation(name = XPS_MARGINREFUNDWITHSETTLEMENTSERVICE_DELETE)
    public boolean delete(MarginRefundWithSettlement dataObject);

    @ServiceOperation(name = XPS_MARGINREFUNDWITHSETTLEMENTSERVICE_SWFMSG, passParamAsMap = true)
    public String generateSwfMessage(Map<String, Object> params);
    
    @ServiceOperation(name = XPS_MARGINREFUNDWITHSETTLEMENTSERVICE_EMAILPREVIEW, passParamAsMap = true)
    public AdvicePreview generateEmailPreview(Map<String, Object> params);
    
    @ServiceOperation(name = XPS_MARGINREFUNDWITHSETTLEMENTSERVICE_GENADVICE, passParamAsMap = true)
    public DmsFile generateAdvice(Map<String, Object> params);
    
    @ServiceOperation(name = XPS_MARGINREFUNDWITHSETTLEMENTSERVICE_GETATTACHED, passParamAsMap = true)
    public MarginRefundWithSettlement getAttachedMarginWithRefund(Map<String, Object> params);

    @ServiceOperation(name = XPS_MARGINREFUNDWITHSETTLEMENTSERVICE_GETATTACHEDWITHREFNO, passParamAsMap = true)
    public MarginRefundWithSettlement getAttachedMarginWithRefundWithRefNo(Map<String, Object> params);

}
