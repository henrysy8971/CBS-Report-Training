package com.silverlakesymmetri.cbs.gla.svc.impl;

import com.mysema.query.types.EntityPath;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.helper.jpa.QueryCondition;
import com.silverlakesymmetri.cbs.commons.jpa.extension.CbsOracle12Platform;
import com.silverlakesymmetri.cbs.commons.svc.AbstractBusinessService;
import com.silverlakesymmetri.cbs.gla.bdo.sdo.GlAcctBalGLKeysQry;
import com.silverlakesymmetri.cbs.gla.jpa.mapping.sdo.GlAcctBalGLKeysQryJpe;
import com.silverlakesymmetri.cbs.gla.jpa.mapping.sdo.QGlAcctBalGLKeysQryJpe;
import com.silverlakesymmetri.cbs.gla.jpa.mapping.sdo.id.GlAcctBalGLKeysQryPk;
import com.silverlakesymmetri.cbs.gla.svc.GlAcctBalByGlKeysQryService;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;

@Service
public class GlAcctBalByGlKeysQryServiceImpl extends AbstractBusinessService<GlAcctBalGLKeysQry, GlAcctBalGLKeysQryJpe, GlAcctBalGLKeysQryPk> implements
		GlAcctBalByGlKeysQryService {

	private static final String D = "D";
	private static final String C = "C";


	@Override
	protected GlAcctBalGLKeysQryPk getIdFromDataObjectInstance(GlAcctBalGLKeysQry dataObject) {
		return new GlAcctBalGLKeysQryPk(dataObject.getGlCode(), dataObject.getBranch(), dataObject.getCcy(), dataObject.getClientNo(), dataObject.getProfitCentre(), dataObject.getSeqNo(), dataObject.getGlType(), dataObject.getAcctStatus());
	}

	@Override
	protected EntityPath<GlAcctBalGLKeysQryJpe> getEntityPath() {
		return QGlAcctBalGLKeysQryJpe.glAcctBalGLKeysQryJpe;
	}
	
	@Override
	public GlAcctBalGLKeysQry getByPk(String publicKey, GlAcctBalGLKeysQry dataObject) {
		GlAcctBalGLKeysQry bdo = super.getByPk(publicKey, dataObject);

		if(bdo.getAggBalMtd() != null && bdo.getMtdDays() != null && bdo.getMtdDays() > 0) {
			bdo.setAverageMtdBal(bdo.getAggBalMtd() / bdo.getMtdDays());
		}

		if(bdo.getAggBalYtd() != null && bdo.getYtdDays() != null && bdo.getYtdDays() > 0) {
			bdo.setAverageYtdBal(bdo.getAggBalYtd() / bdo.getYtdDays());
		}

		setDrCrValues(bdo);
		return bdo;
	}

	private void setDrCrValues(GlAcctBalGLKeysQry bdo) {

		if(bdo.getAggBalMtd() != null) {
			if(bdo.getAggBalMtd() < 0){
				bdo.setAggBalMtdDrCr(C);
			} else {
				bdo.setAggBalMtdDrCr(D);
			}
		}

		if(bdo.getAggBalYtd() != null){
			if(bdo.getAggBalMtd() < 0){
				bdo.setAggBalYtdDrCr(C);
			} else {
				bdo.setAggBalYtdDrCr(D);
			}
		}

		if(bdo.getActualBalAbs() != null) {
			if (bdo.getActualBalAbs() < 0) {
				bdo.setActualBalDrCr(C);
			} else {
				bdo.setActualBalDrCr(D);
			}
		}

		if(bdo.getLedgerBalAbs() != null) {
			if(bdo.getLedgerBalAbs() < 0) {
				bdo.setLedgerBalDrCr(C);
			} else {
				bdo.setLedgerBalDrCr(D);
			}
		}

	}

	@Override
	public List<GlAcctBalGLKeysQry> query(int offset, int resultLimit, String groupBy, String order,
			Map<String, Object> filters) {
		try {
			CbsOracle12Platform.setUseNewOraclePaging(true);
			return super.query(offset, resultLimit, groupBy, order, filters);
		} finally {
			CbsOracle12Platform.setUseNewOraclePaging(false);
		}
	}

	@Override
	public List<GlAcctBalGLKeysQry> find(FindCriteria findCriteria, CbsHeader cbsHeader) {
		try {
			CbsOracle12Platform.setUseNewOraclePaging(true);
			return super.find(findCriteria, cbsHeader);
		} finally {
			CbsOracle12Platform.setUseNewOraclePaging(false);
		}
	}
	
	@Override
	public GlAcctBalGLKeysQry get(GlAcctBalGLKeysQry objectInstanceIdentifier) {
		return super.get(objectInstanceIdentifier);
	}

}
