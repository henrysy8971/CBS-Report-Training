package com.silverlakesymmetri.cbs.xps.svc.mapper;

import org.mapstruct.Context;
import org.mapstruct.DecoratedWith;
import org.mapstruct.InheritInverseConfiguration;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingTarget;
import org.mapstruct.Mappings;

import com.silverlakesymmetri.cbs.commons.jpa.util.DateTimeHelper;
import com.silverlakesymmetri.cbs.commons.xmlapi.enums.CbsXmlApiOperation;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.MarginRefundWithSettlementJpe;
import com.silverlakesymmetri.cbs.xps.svc.mapper.decorator.MarginRefundWithSettlementServiceDecorator;
import com.silverlakesymmetri.cbs.xps.svc.mapper.mapping.XpsMessageJpeToXPSMESSAGETYPETypeMapper;
import com.silverlakesymmetri.cbs.xps.xmlapi.XPSTRANMARGINREFUNDWITHSETTLEAPIType;

@Mapper(uses={ DateTimeHelper.class, MarginSettlementServiceMapper.class, XpsMessageJpeToXPSMESSAGETYPETypeMapper.class })
@DecoratedWith(MarginRefundWithSettlementServiceDecorator.class)
public interface MarginRefundWithSettlementServiceMapper {

	@Mappings({
		@Mapping(expression = "java(oper != null ? oper.getOperation() : null)", target="OPERATION"),
		@Mapping(source="internalKey", target = "INTERNALKEY"),
		@Mapping(source="marginInternalKey", target = "MARGININTERNALKEY"),
		@Mapping(source="marginRefundStructRec.relInternalKey", target = "RELINTERNALKEY"),
		@Mapping(source="marginRefundStructRec.seqNo", target = "SEQNO"),
		@Mapping(source="marginRefundStructRec.valueDate", target = "VALUEDATE", qualifiedByName = {"DateTimeHelper", "convertDateToCbsXmlApiDate"}),
		@Mapping(source="marginRefundStructRec.amount", target = "AMOUNT"),
		@Mapping(source="marginRefundStructRec.tranStatus", target = "TRANSTATUS"),
		@Mapping(source="marginRefundStructRec.remarks", target = "REMARKS"),
		@Mapping(source="marginRefundStructRec.relEventType", target = "RELEVENTTYPE"),
		@Mapping(source="marginRefundStructRec.domain", target = "DOMAIN"),
		@Mapping(source="marginRefundStructRec.messageStructList", target = "MESSAGELIST.XPSMESSAGETYPE"),
		@Mapping(source="settlementStructRec", target = "SETTLEMENT")
	})
	public XPSTRANMARGINREFUNDWITHSETTLEAPIType mapToApi(MarginRefundWithSettlementJpe jpe, @Context CbsXmlApiOperation oper);

	@InheritInverseConfiguration(name = "mapToApi")
	@Mappings({
		@Mapping(source="VALUEDATE", target="marginRefundStructRec.valueDate", qualifiedByName = {"DateTimeHelper", "convertCbsApiDateToString"})
	})
	public MarginRefundWithSettlementJpe mapToJpe(XPSTRANMARGINREFUNDWITHSETTLEAPIType api, @MappingTarget MarginRefundWithSettlementJpe jpe);

	@InheritInverseConfiguration(name = "mapToApi")
	@Mappings({
		@Mapping(source="VALUEDATE", target="marginRefundStructRec.valueDate", qualifiedByName = {"DateTimeHelper", "convertCbsApiDateToString"})
	})
	public MarginRefundWithSettlementJpe mapToJpe(XPSTRANMARGINREFUNDWITHSETTLEAPIType api);
}