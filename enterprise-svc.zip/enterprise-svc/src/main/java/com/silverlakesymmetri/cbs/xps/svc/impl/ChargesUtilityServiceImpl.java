package com.silverlakesymmetri.cbs.xps.svc.impl;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.inject.Inject;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.silverlakesymmetri.cbs.commons.bdo.CbsBusinessDataObject;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.ext.ServiceExtensionManager;
import com.silverlakesymmetri.cbs.commons.ext.ServiceExtensionPoint;
import com.silverlakesymmetri.cbs.commons.jpa.extension.JaxbSdoHelper;
import com.silverlakesymmetri.cbs.commons.jpa.service.CbsGenericDataService;
import com.silverlakesymmetri.cbs.commons.jpa.service.impl.BusinessDataObjectJpaQueryComponentImpl;
import com.silverlakesymmetri.cbs.commons.jpa.util.DateTimeHelper;
import com.silverlakesymmetri.cbs.commons.restlet.JsonConvertionManager;
import com.silverlakesymmetri.cbs.commons.svc.util.InMemoryQueryExecutor;
import com.silverlakesymmetri.cbs.core.util.CcyConversionObject;
import com.silverlakesymmetri.cbs.csd.util.CurrencyHelper;
import com.silverlakesymmetri.cbs.mcl.jpa.mapping.sdo.ClientJpe;
import com.silverlakesymmetri.cbs.mcl.jpa.mapping.sdo.util.MclJpeConstants;
import com.silverlakesymmetri.cbs.pim.bdo.sdo.MessageKey;
import com.silverlakesymmetri.cbs.xps.bdo.sdo.ChargeDetails;
import com.silverlakesymmetri.cbs.xps.bdo.sdo.ChargeEventInfo;
import com.silverlakesymmetri.cbs.xps.bdo.sdo.ChargeEventSeqNoQry;
import com.silverlakesymmetri.cbs.xps.bdo.sdo.ChargeEventTypeQry;
import com.silverlakesymmetri.cbs.xps.bdo.sdo.ChargeInstrumentInfo;
import com.silverlakesymmetri.cbs.xps.bdo.sdo.ChargeMaster;
import com.silverlakesymmetri.cbs.xps.bdo.sdo.ChargeNoQry;
import com.silverlakesymmetri.cbs.xps.bdo.sdo.MsgGrpDefQry;
import com.silverlakesymmetri.cbs.xps.bdo.sdo.MsgGrpTypeQry;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.ChargeEventInfoJpe;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.ChargeEventSeqNoQryJpe;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.ChargeEventTypeQryJpe;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.ChargeInstrumentInfoJpe;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.ChargeNoQryJpe;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.MsgGrpDefQryJpe;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.MsgGrpTypeQryJpe;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.util.ChargeCalcHelper;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.util.ChargeMgrHelper;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.util.ChargeMsgHelper;
import com.silverlakesymmetri.cbs.xps.svc.ChargeCalculateService;
import com.silverlakesymmetri.cbs.xps.svc.ChargeDefaultsService;
import com.silverlakesymmetri.cbs.xps.svc.ChargePeriodicRecalculateService;
import com.silverlakesymmetri.cbs.xps.svc.ChargeRecalculateService;
import com.silverlakesymmetri.cbs.xps.svc.ChargeRecalculateSlabService;
import com.silverlakesymmetri.cbs.xps.svc.ChargesUtilityService;
import com.silverlakesymmetri.cbs.xps.svc.ext.BgtChargesServiceExt;
import com.silverlakesymmetri.cbs.xps.svc.ext.TfnChargesServiceExt;
import com.silverlakesymmetri.cbs.xps.svc.mapper.ChargeDetailServiceMapper;

@Service
public class ChargesUtilityServiceImpl implements ChargesUtilityService {
	
	@Autowired
    protected JaxbSdoHelper jaxbSdoHelper;
	
	@Autowired
	private ChargeMgrHelper chargeMgrHelper;

	@Autowired
	private ChargeMsgHelper chargeMsgHelper;

	@Autowired
	private ChargeCalcHelper chargeCalcHelper;
	
	@Autowired(required = true)
    @Qualifier("cbsGenericDataService")
    protected CbsGenericDataService dataService;
	
    @Inject
    protected JsonConvertionManager jsonConversionMngr;

    @Autowired
    protected DateTimeHelper dateTimeHelper;

	@Autowired
	protected ChargeDetailServiceMapper detailMapper;
	
	@Autowired
	protected ChargeDefaultsService chargeDefaults;
	
	@Autowired
	protected ChargeCalculateService chargeCalculator;
	
	@Autowired
	protected ChargeRecalculateService chargeRecalculator;
	
	@Autowired
	protected ChargePeriodicRecalculateService chargePeriodicRecalculator;
	
	@Autowired
	protected ChargeRecalculateSlabService ratedSlabRecalculator;
	
	@Autowired
	protected CurrencyHelper ccyHelper;

	@Autowired
	private ServiceExtensionManager extMgr;

	private static final String CUT_ERROR_LIST_TYPE = "CUT_ERROR_LIST";
	private static final String CUT_ERROR_FUNCTIONAL = "CUT_ERROR_FUNCTIONAL";
	private static final String CUT_ERROR_SYSTEM = "CUT_ERROR_SYSTEM";
	private static final String XPS_TRAN_CHARGE_DETAIL_API = "XPS_TRAN_CHARGE_DETAIL_API";
	private static final String XPS_CHARGE_EVENT_INFO_TYPE = "XPS_CHARGE_EVENT_TYPE";
	private static final String XPS_CHARGE_INSTRUMENT_INFO_TYPE = "XPS_CHARGE_INSTRUMENT_TYPE";
	private static final String XPS_CHARGE_TYPE = "XPS_CHARGE_TYPE";


	@Override
	public List<ChargeEventTypeQry> getEventType(Map<String, Object> queryParams) {
		int limit = queryParams.get("limit") != null ? Integer.parseInt((String)queryParams.get("limit")) : 10;
        int offset = queryParams.get("offset") != null ? Integer.parseInt((String)queryParams.get("offset")) : 0;

		Map<String, Object> filter = new HashMap<>();
        String groupBy = (String) queryParams.get("groupBy");
        String order = (String) queryParams.get("order");
        
		String domain = (String) queryParams.get("domain");
        String instrumentType = (String) queryParams.get("instrumentType");
        String refNo = (String) queryParams.get("refNo");
        String type = (String) queryParams.get("type");
        Long tranKey = this.getTranKey(refNo, type, instrumentType);    
        String code = (String) queryParams.get("code");   
        String desc = (String) queryParams.get("description");
        
		List<ChargeEventTypeQry> resultList = new ArrayList<>();
		List<ChargeEventTypeQryJpe> jpeList = chargeMgrHelper.getEventType(domain, instrumentType, tranKey);
		if (jpeList != null && !jpeList.isEmpty()) {
			for (ChargeEventTypeQryJpe jpe : jpeList) {
				resultList.add(jaxbSdoHelper.wrap(jpe, ChargeEventTypeQry.class));
			}
		}
		
		if(code != null) {
			filter.put("code", code);
		}
		
		if(desc != null) {
			filter.put("description", desc);
		}
		
		FindCriteria fc = jaxbSdoHelper.wrap(BusinessDataObjectJpaQueryComponentImpl
				.buildFindCriteria(offset, limit, groupBy, order, filter));
		InMemoryQueryExecutor<ChargeEventTypeQry> inMemQry = new InMemoryQueryExecutor<>(resultList);
		return inMemQry.executeFilter(fc);
	}

	@Override
	public List<ChargeEventSeqNoQry> getEventSeq(Map<String, Object> queryParams) {
		int limit = queryParams.get("limit") != null ? Integer.parseInt((String)queryParams.get("limit")) : 10;
        int offset = queryParams.get("offset") != null ? Integer.parseInt((String)queryParams.get("offset")) : 0;
		Map<String, Object> filter = new HashMap<>();
        String groupBy = (String) queryParams.get("groupBy");
        String order = (String) queryParams.get("order");
		
		String domain = (String) queryParams.get("domain");
        String instrumentType = (String) queryParams.get("instrumentType");
        String refNo = (String) queryParams.get("refNo");
        String eventType = (String) queryParams.get("eventType");
        String type = (String) queryParams.get("type");
        Long tranKey = this.getTranKey(refNo, type, instrumentType);
        String seqNo = (String) queryParams.get("seqNo");
		
		List<ChargeEventSeqNoQry> resultList = new ArrayList<>();
		List<ChargeEventSeqNoQryJpe> jpeList = chargeMgrHelper.getEventSeq(domain, instrumentType, tranKey, eventType);
		if (jpeList != null && !jpeList.isEmpty()) {
			for (ChargeEventSeqNoQryJpe jpe : jpeList) {
				resultList.add(jaxbSdoHelper.wrap(jpe, ChargeEventSeqNoQry.class));
			}
		}
		
		if(seqNo != null) {
			filter.put("seqNo", Integer.parseInt(seqNo));
		}

		FindCriteria fc = jaxbSdoHelper.wrap(BusinessDataObjectJpaQueryComponentImpl
				.buildFindCriteria(offset, limit, groupBy, order, filter));
		InMemoryQueryExecutor<ChargeEventSeqNoQry> inMemQry = new InMemoryQueryExecutor<>(resultList);
		return inMemQry.executeFilter(fc);
	}
	
	@Override
	public List<ChargeNoQry> getChargeNo(Map<String, Object> queryParams) {
		int limit = queryParams.get("limit") != null ? Integer.parseInt((String)queryParams.get("limit")) : 10;
        int offset = queryParams.get("offset") != null ? Integer.parseInt((String)queryParams.get("offset")) : 0;
		Map<String, Object> filter = new HashMap<>();
        String groupBy = (String) queryParams.get("groupBy");
        String order = (String) queryParams.get("order");
		
		String clientNo = (String) queryParams.get("clientNo");
		String code = (String) queryParams.get("code");
		String domain = (String) queryParams.get("domain");
        String desc = (String) queryParams.get("description");
		Long clientId = getClientId(clientNo);
		
		List<ChargeNoQry> resultList = new ArrayList<>();
		List<ChargeNoQryJpe> jpeList = chargeMgrHelper.getChargeNo(clientId);
		if (jpeList != null && !jpeList.isEmpty()) {
			for (ChargeNoQryJpe jpe : jpeList) {
				resultList.add(jaxbSdoHelper.wrap(jpe, ChargeNoQry.class));
			}
		}
		
		if(code != null) {
			filter.put("code", code);
		}
		
		if(desc != null ) {
			filter.put("description", desc);
		}
		
		FindCriteria fc = jaxbSdoHelper.wrap(BusinessDataObjectJpaQueryComponentImpl
				.buildFindCriteria(offset, limit, groupBy, order, filter));
		InMemoryQueryExecutor<ChargeNoQry> inMemQry = new InMemoryQueryExecutor<>(resultList);
		return inMemQry.executeFilter(fc);
	}

	@Override
	public List<MsgGrpDefQry> getMsgGrpDefQryList(String domain, String msgGrp, String eventType, String prodType) {
    	List<MsgGrpDefQryJpe> jpel = chargeMsgHelper.getMsgGrpDefList(domain, msgGrp, eventType, prodType);
    	
    	if (jpel != null && !jpel.isEmpty()){
    		List<MsgGrpDefQry> result  = new ArrayList<MsgGrpDefQry>();
    		for (MsgGrpDefQryJpe jpe : jpel){	
    			MsgGrpDefQry bdo = jaxbSdoHelper.createSdoInstance(MsgGrpDefQry.class);    			
    			bdo.setSenderContactType(jpe.getSenderContactType());
    			bdo.setSenderContactSubType(jpe.getSenderContactSubType());
    			bdo.setReceiverClientType(jpe.getReceiverClientType());
    			bdo.setReceiverContactType(jpe.getReceiverContactType());
    			bdo.setReceiverContactSubType(jpe.getReceiverContactSubType());
    			bdo.setFormat(jpe.getFormat());
    			bdo.setAdviceDays(jpe.getAdviceDays());
    			result.add(bdo);
    		}	
    		return result;
    	}
    	
    	return null;
	}

	@Override
	public List<MsgGrpTypeQry> getMsgGrpTypeQryList(String domain, String eventType, String prodType) {
    	List<MsgGrpTypeQryJpe> jpel = chargeMsgHelper.getMsgGrpTypeList(domain, eventType, prodType);
    	
    	if (jpel != null && !jpel.isEmpty()){
    		List<MsgGrpTypeQry> result  = new ArrayList<MsgGrpTypeQry>();
    		for (MsgGrpTypeQryJpe jpe : jpel){	
    			MsgGrpTypeQry bdo = jaxbSdoHelper.createSdoInstance(MsgGrpTypeQry.class);
    			bdo.setMsgGrp(jpe.getMsgGrp());
    			bdo.setDescription(jpe.getDescription());
    			result.add(bdo);
    		}	
    		return result;
    	}

		return null;
	}
	
	public Long getTranKey(String refNo, String type, String instrumentType) {
		Long tranKey = null;
		if(instrumentType != null && (instrumentType.toUpperCase()).equals("LC")) {
			TfnChargesServiceExt tfnChargesServiceExt = getTfnChargeServiceExtensionPoint();
			if(tfnChargesServiceExt != null){
	        	if((type.toUpperCase()).equals("I")) {
	        		tranKey = tfnChargesServiceExt.getImportLcTranKey(refNo);
	        	}else if((type.toUpperCase()).equals("E")) {
	        		tranKey = tfnChargesServiceExt.getExportLcTranKey(refNo);
	        	}
			}
        } else if(instrumentType != null && (instrumentType.toUpperCase()).equals("NE")) {
			TfnChargesServiceExt tfnChargesServiceExt = getTfnChargeServiceExtensionPoint();
			if(tfnChargesServiceExt != null){
	        	if((type.toUpperCase()).equals("I")) {
	        		tranKey = tfnChargesServiceExt.getImportNeTranKey(refNo);
	        	}else if((type.toUpperCase()).equals("E")) {
	        		tranKey = tfnChargesServiceExt.getExportNeTranKey(refNo);
	        	}
			}
        } else if(instrumentType != null && (instrumentType.toUpperCase()).equals("DC")) {
			TfnChargesServiceExt tfnChargesServiceExt = getTfnChargeServiceExtensionPoint();
			if(tfnChargesServiceExt != null){
	        	if((type.toUpperCase()).equals("I")) {
	        		tranKey = tfnChargesServiceExt.getImportDcTranKey(refNo);
	        	}else if((type.toUpperCase()).equals("E")) {
	        		tranKey = tfnChargesServiceExt.getExportDcTranKey(refNo);
	        	}
			}
        } else if(instrumentType != null && (instrumentType.toUpperCase()).equals("SG")) {
			TfnChargesServiceExt tfnChargesServiceExt = getTfnChargeServiceExtensionPoint();
			if(tfnChargesServiceExt != null){
	        	tranKey = tfnChargesServiceExt.getSgTranKey(refNo);
			}
        } else if(instrumentType != null && (instrumentType.toUpperCase()).equals("BG")) {
        	BgtChargesServiceExt bgtChargesServiceExt = getBgtChargeServiceExtensionPoint();
        	if(bgtChargesServiceExt != null){
	    		if((type.toUpperCase()).equals("I")) {
	        		tranKey = bgtChargesServiceExt.getIssuanceTranKey(refNo);
	        	}else if((type.toUpperCase()).equals("A")) {
	        		tranKey = bgtChargesServiceExt.getAdvisingTranKey(refNo);
	        	}
        	}
        }
		
		return tranKey;
	}
	
	@Override
	public TfnChargesServiceExt getTfnChargeServiceExtensionPoint(){
    	final ServiceExtensionPoint[] extPointList = extMgr.getServiceExtensionPoints(
    			TfnChargesServiceExt.TFN_CHARGE_UTILITY, TfnChargesServiceExt.TFN_CHARGE);
		if (extPointList != null && extPointList.length > 0) {
			if (TfnChargesServiceExt.class.isInstance(extPointList[0])) {
				TfnChargesServiceExt tfnChargesServiceExt = (TfnChargesServiceExt) extPointList[0];
				return tfnChargesServiceExt;
			}
		}
		return null;
	}
	
	@Override
	public BgtChargesServiceExt getBgtChargeServiceExtensionPoint(){
    	final ServiceExtensionPoint[] extPointList = extMgr.getServiceExtensionPoints(
    			BgtChargesServiceExt.BGT_CHARGE_UTILITY, BgtChargesServiceExt.BGT_CHARGE);
		if (extPointList != null && extPointList.length > 0) {
			if (BgtChargesServiceExt.class.isInstance(extPointList[0])) {
				BgtChargesServiceExt bgtChargesServiceExt = (BgtChargesServiceExt) extPointList[0];
				return bgtChargesServiceExt;
			}
		}
		return null;
	}

	@Override
	public ChargeInstrumentInfo getChargeInstrumentInfo(Map<String, Object> params) {
		String domain = (String) params.get("domain");
		String instrumentType = (String) params.get("instrumentType");
		String refNo = (String) params.get("refNo");
		String type = (String) params.get("type");

		Long tranKey = null;
		if(refNo != null) {
			tranKey = getTranKey(refNo, type, instrumentType);
		}
		ChargeInstrumentInfoJpe jpe = chargeMgrHelper.getChargeInstrumentInfo(domain, instrumentType, tranKey, type);
		if(jpe != null){
			Map<String, Object> parameters = new HashMap<String, Object>();
			if(jpe.getAgentClientId() != null){
				parameters.put("clientId", jpe.getAgentClientId());
				List<ClientJpe> clientList = dataService.findWithNamedQuery(MclJpeConstants.CLIENT_JPE_GET_CLIENT_FROM_ID, parameters, ClientJpe.class);
				if(clientList != null && clientList.size() > 0){
					jpe.setAgentClientNo(clientList.get(0).getClientNo());
				}
			}
			if(jpe.getCustomerClientId() != null){
				parameters.put("clientId", jpe.getCustomerClientId());
				List<ClientJpe> clientList = dataService.findWithNamedQuery(MclJpeConstants.CLIENT_JPE_GET_CLIENT_FROM_ID, parameters, ClientJpe.class);
				if(clientList != null && clientList.size() > 0){
					jpe.setCustomerClientNo(clientList.get(0).getClientNo());
				}
			}
			ChargeInstrumentInfo bdo = jaxbSdoHelper.wrap(jpe, ChargeInstrumentInfo.class);
			return bdo;
		}
		return null;
	}

	@Override
	public ChargeEventInfo getChargeEventInfo(Map<String, Object> params) {
		String domain = (String) params.get("domain");
		String instrumentType = (String) params.get("instrumentType");
		String refNo = (String) params.get("refNo");
		String eventType = (String) params.get("eventType");
		Integer eventSeq = params.get("eventSeq") != null ? Integer.parseInt(params.get("eventSeq").toString()) : null;
		String type = (String) params.get("type");
		String attached = (String) params.get("attached");
		String attachedRelKey = (String) params.get("attachedKey");

		Boolean isAttached = attached == null ? null : Boolean.TRUE;
		Long attachedKey = attachedRelKey == null ? null : Long.parseLong(attachedRelKey);
		Long tranKey = null;
		if(refNo != null) {
			tranKey = getTranKey(refNo, type, instrumentType);
		}
		ChargeEventInfoJpe jpe = chargeMgrHelper.getChargeEventInfo(domain, instrumentType, tranKey, eventType, eventSeq, isAttached, attachedKey);
		if(jpe != null){
			ChargeEventInfo bdo = jaxbSdoHelper.wrap(jpe, ChargeEventInfo.class);
			return bdo;
		}
		return null;
	}

	@Override
	public List<ChargeDetails> computeDefaultCharges(ChargeMaster chargeMaster) {
		chargeMaster.setPartyClientId(getClientId(chargeMaster.getPartyClientNo()));
		return chargeDefaults.getChargeProdDefaults(chargeMaster);
	}
	
	private Long getClientId(String clientNo){
		Long partyClientId = null;
		Map<String, Object> parameters = new HashMap<String, Object>();
		parameters.put("clientNo", clientNo);
		List<ClientJpe> clientList = dataService.findWithNamedQuery(MclJpeConstants.CLIENT_JPE_GET_CLIENT_FROM_CLIENT_NO, parameters, ClientJpe.class);
		if(clientList != null && clientList.size() > 0){
			partyClientId = clientList.get(0).getClientId();
		}
		return partyClientId;
	}

	@Override
	public ChargeDetails calculate(Map<String, Object> params) {
		return chargeCalculator.calculate(params);
	}

	@Override
	public ChargeDetails recalculate(Map<String, Object> params) {
		return chargeRecalculator.recalculate(params);
	}

	@Override
	public ChargeDetails periodicRecalculate(Map<String, Object> params) {
		return chargePeriodicRecalculator.recalculate(params);
	}

	@Override
	public CcyConversionObject convertAmount(CcyConversionObject conversionObj) {
		ccyHelper.convertAmount(conversionObj);
		return conversionObj;
	}

	@Override
	public CcyConversionObject convertBaseAmount(CcyConversionObject conversionObj) {
		//below method is created for TFN, but since this is located in Core, we can reuse
		ccyHelper.tfConvertAmt(conversionObj);
    	return conversionObj;
	}

	@Override
	public Double calculateEquivAmount(Double amount, Double exchRate, String exchQuote, String ccy) {
		Double equivAmount = chargeCalcHelper.calculateEquivAmount(amount, exchRate, exchQuote, ccy);
		return equivAmount;
	}

	@Override
	public Double calculateEquivAmountReverse(Double amount, Double exchRate, String exchQuote, String ccy) {
		Double equivAmount = chargeCalcHelper.calculateEquivAmountReverse(amount, exchRate, exchQuote, ccy);
		return equivAmount;
	}
	
	@Override
	public Double getIntBasisRate(String intBasis, String basisCcy, Date valueDate) {
		Double intBasisRate = chargeCalcHelper.getDefaultIntBasisRate(intBasis, basisCcy, valueDate);
		return intBasisRate;
	}
	
	@Override
	public ChargeDetails recalculateRatedSlabs(Map<String, Object> params) {
		return ratedSlabRecalculator.recalculateSlab(params);
	}
	
	@Override
	public String getDestinationAddress(String module, CbsBusinessDataObject mainBdo, String refNo, MessageKey message, String instrumentType, String instrumentSubType, Map<String, Object> qParams){
		if(TRADE_FINANCE_MODULE.equals(module)){
        	TfnChargesServiceExt tfnChargesServiceExt = getTfnChargeServiceExtensionPoint();
        	if(tfnChargesServiceExt != null){
				return tfnChargesServiceExt.getDestinationAddress(mainBdo, refNo, message, instrumentType, instrumentSubType, qParams);
        	}
		} else if(BANK_GUARANTEE_MODULE.equals(module)){
        	BgtChargesServiceExt bgtChargesServiceExt = getBgtChargeServiceExtensionPoint();
        	if(bgtChargesServiceExt != null){
				return bgtChargesServiceExt.getDestinationAddress(mainBdo, refNo, message, instrumentType, instrumentSubType, qParams);
        	}
		}
		return null;
	}
	
	public Long getInternalKey(String api) {
		return chargeMgrHelper.getInternalKey(api);
	}

	@Override
	public String getNextRecurDate(Map<String, Object> params) {
		Date nextRecurDate = chargeMgrHelper.getNextRecurDate(params);
		if (nextRecurDate != null) {
			return dateTimeHelper.getSDODateTime(nextRecurDate); 
		}
		return null;
	}

}
