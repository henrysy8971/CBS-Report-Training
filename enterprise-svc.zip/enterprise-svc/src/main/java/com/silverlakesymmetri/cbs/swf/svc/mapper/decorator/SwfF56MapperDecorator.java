package com.silverlakesymmetri.cbs.swf.svc.mapper.decorator;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

import com.silverlakesymmetri.cbs.swf.jpa.mapping.sdo.SwfFinEntityJpe;
import com.silverlakesymmetri.cbs.swf.svc.mapper.mapping.SwfF56Mapper;
import com.silverlakesymmetri.cbs.swf.xmlapi.SWFF56TYPEType;

public abstract class SwfF56MapperDecorator implements SwfF56Mapper {
	
	@Autowired
	@Qualifier("delegate")
	protected SwfF56Mapper delegate;

	@Override
	public SWFF56TYPEType mapToApi(SwfFinEntityJpe jpe){
		SWFF56TYPEType swfF56 = delegate.mapToApi(jpe);
		if(swfF56 != null && swfF56.getACCOUNT() == null && swfF56.getADDRESS() == null && swfF56.getBIC() == null && swfF56.getBRANCHLOCATION() == null){
			return null;
		}
		return swfF56;
	}
	
	@Override
	public SwfFinEntityJpe mapToJpe(SWFF56TYPEType api){
		return delegate.mapToJpe(api);
	}
	
}
