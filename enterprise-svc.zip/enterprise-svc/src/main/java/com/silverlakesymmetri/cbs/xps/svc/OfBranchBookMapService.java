package com.silverlakesymmetri.cbs.xps.svc;


import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation;
import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation.ServiceOperationType;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.svc.BusinessService;
import com.silverlakesymmetri.cbs.xps.bdo.sdo.OfBranchBookMap;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.OfBranchBookMapJpe;

import java.util.List;
import java.util.Map;

public interface OfBranchBookMapService extends BusinessService<OfBranchBookMap, OfBranchBookMapJpe> {

    String SVC_OP_NAME_OF_BRANCH_BOOK_MAP_SERVICE_GET = "OfBranchBookMapService.get";
    String SVC_OP_NAME_OF_BRANCH_BOOK_MAP_SERVICE_QUERY = "OfBranchBookMapService.query";
    String SVC_OP_NAME_OF_BRANCH_BOOK_MAP_SERVICE_CREATE = "OfBranchBookMapService.create";
    String SVC_OP_NAME_OF_BRANCH_BOOK_MAP_SERVICE_UPDATE = "OfBranchBookMapService.update";
    String SVC_OP_NAME_OF_BRANCH_BOOK_MAP_SERVICE_DELETE = "OfBranchBookMapService.delete";
    String SVC_OP_NAME_OF_BRANCH_BOOK_MAP_SERVICE_FIND = "OfBranchBookMapService.find";

    @ServiceOperation(name = SVC_OP_NAME_OF_BRANCH_BOOK_MAP_SERVICE_GET, type = ServiceOperationType.GET)
    OfBranchBookMap getByPk(String publicKey, OfBranchBookMap reference);

    @ServiceOperation(name = SVC_OP_NAME_OF_BRANCH_BOOK_MAP_SERVICE_CREATE)
    OfBranchBookMap create(OfBranchBookMap dataObject);

    @ServiceOperation(name = SVC_OP_NAME_OF_BRANCH_BOOK_MAP_SERVICE_UPDATE)
    OfBranchBookMap update(OfBranchBookMap dataObject);

    @ServiceOperation(name = SVC_OP_NAME_OF_BRANCH_BOOK_MAP_SERVICE_QUERY)
    List<OfBranchBookMap> query(int offset, int resultLimit, String groupBy, String order, Map<String, Object> filters);

    @ServiceOperation(name = SVC_OP_NAME_OF_BRANCH_BOOK_MAP_SERVICE_DELETE)
    boolean delete(OfBranchBookMap dataObject);

    @ServiceOperation(name = SVC_OP_NAME_OF_BRANCH_BOOK_MAP_SERVICE_FIND)
    List<OfBranchBookMap> find(FindCriteria findCriteria, CbsHeader cbsHeader);

}
