package com.silverlakesymmetri.cbs.xps.svc.batch.processor;

import java.nio.file.Path;

import org.springframework.batch.item.ItemProcessor;
import org.springframework.beans.factory.annotation.Autowired;

import com.silverlakesymmetri.cbs.commons.logging.CbsAppLogger;
import com.silverlakesymmetri.cbs.commons.logging.CbsAppLoggerFactory;
import com.silverlakesymmetri.cbs.xps.enums.XpsGlobalConstants;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.MessageQJpe;
import com.silverlakesymmetri.cbs.xps.svc.util.MessageQueueUtil;

public class MessageQueueListItemProcessor implements ItemProcessor<MessageQJpe, MessageQJpe> {
	public static final String SWIFT_SPOOL_DIRECTORY_ATTR = "swiftSpoolDirectory";
	public static final String SWIFT_MESSAGE_SEPARATOR_ATTR = "swiftMessageSeparator";
	public static final String SWIFT_FILE_NAME_ATTR = "swiftFileName";
	
	private CbsAppLogger logger = CbsAppLoggerFactory.getLogger(MessageQueueListItemProcessor.class.getName());

	@Autowired
	MessageQueueUtil messageQueueUtil;
	
	String swiftSpoolDirectory;
	String swiftMessageSeparator;
	String swiftFileName;
	boolean swiftFileEmpty;

	public String getSwiftSpoolDirectory() {
		return swiftSpoolDirectory;
	}
	public void setSwiftSpoolDirectory(String swiftSpoolDirectory) {
		this.swiftSpoolDirectory = swiftSpoolDirectory;
	}
	public String getSwiftMessageSeparator() {
		return swiftMessageSeparator;
	}
	public void setSwiftMessageSeparator(String swiftMessageSeparator) {
		this.swiftMessageSeparator = swiftMessageSeparator;
	}	
	public String getSwiftFileName() {
		return swiftFileName;
	}
	public void setSwiftFileName(String swiftFileName) {
		this.swiftFileName = swiftFileName;
	}	
	public boolean isSwiftFileEmpty() {
		return swiftFileEmpty;
	}
	public void setSwiftFileEmpty(boolean swiftFileEmpty) {
		this.swiftFileEmpty = swiftFileEmpty;
	}
	
	@Override
	public MessageQJpe process(MessageQJpe jpe) throws Exception {
		if (jpe == null || jpe.getInternalKey() == null) {
			logger.warn("Cannot retrieve internalKey. Processing will fail");
		}

		if (XpsGlobalConstants.SWIFT_ROUTE.equals(jpe.getRoute())) {
			Path returnedPath = messageQueueUtil.spoolSwiftMessage(swiftSpoolDirectory, swiftFileName, jpe.getInternalKey(), XpsGlobalConstants.SWIFT_FORMAT, swiftMessageSeparator, this.swiftFileEmpty);
			if(returnedPath != null && this.swiftFileEmpty){ //set flag if file is no longer empty
				synchronized(this){
					if(returnedPath != null && this.swiftFileEmpty){ //Double check locking
						setSwiftFileEmpty(false);
					}
				}
			}
		} else {
			jpe = messageQueueUtil.processAdvice(jpe, null);
		}

		return jpe;
	}

}
