package com.silverlakesymmetri.cbs.swf.svc;

import java.util.List;
import java.util.Map;

import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation;
import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation.ServiceOperationType;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.bdo.sdo.ReportRequestLog;
import com.silverlakesymmetri.cbs.commons.jpa.mapping.sdo.ReportRequestLogJpe;
import com.silverlakesymmetri.cbs.commons.svc.BusinessService;

public interface SwfReportRequestLogService extends BusinessService<ReportRequestLog, ReportRequestLogJpe> {

    String SVC_OP_NAME_REPORTREQUESTSERVICE_GET = "SwfReportRequestLogService.get";
    String SVC_OP_NAME_REPORTREQUESTSERVICE_UPDATE = "SwfReportRequestLogService.update";
    String SVC_OP_NAME_REPORTREQUESTSERVICE_CREATE = "SwfReportRequestLogService.create";
    String SVC_OP_NAME_REPORTREQUESTSERVICE_DELETE = "SwfReportRequestLogService.delete";
    String SVC_OP_NAME_REPORTREQUESTSERVICE_QUERY = "SwfReportRequestLogService.query";
    String SVC_OP_NAME_REPORTREQUESTSERVICE_FIND = "SwfReportRequestLogService.find";
    String SVC_OP_NAME_REPORTREQUESTSERVICE_START = "SwfReportRequestLogService.start";
    String SVC_OP_NAME_REPORTREQUESTSERVICE_REQUEST = "SwfReportRequestLogService.createRequest";

    @ServiceOperation(name = SVC_OP_NAME_REPORTREQUESTSERVICE_GET, type = ServiceOperation.ServiceOperationType.GET)
    ReportRequestLog getByPk(String publicKey, ReportRequestLog reference);

    @ServiceOperation(name = SVC_OP_NAME_REPORTREQUESTSERVICE_CREATE)
    ReportRequestLog create(ReportRequestLog dataObject);

    @ServiceOperation(name = SVC_OP_NAME_REPORTREQUESTSERVICE_UPDATE)
    ReportRequestLog update(ReportRequestLog dataObject);

    @ServiceOperation(name = SVC_OP_NAME_REPORTREQUESTSERVICE_DELETE)
    boolean delete(ReportRequestLog dataObject);

    @ServiceOperation(name = SVC_OP_NAME_REPORTREQUESTSERVICE_QUERY)
    List<ReportRequestLog> query(int offset, int resultLimit, String groupBy, String order, Map<String, Object> filters);

    @ServiceOperation(name = SVC_OP_NAME_REPORTREQUESTSERVICE_FIND)
    List<ReportRequestLog> find(FindCriteria findCriteria, CbsHeader cbsHeader);

    @ServiceOperation(name = SVC_OP_NAME_REPORTREQUESTSERVICE_START, type = ServiceOperationType.EXECUTE, passParamAsMap = true)
    ReportRequestLog start(Map<String, Object> params);

    @ServiceOperation(name = SVC_OP_NAME_REPORTREQUESTSERVICE_REQUEST, type = ServiceOperationType.EXECUTE, passParamAsMap = true)
    ReportRequestLog createRequest(Map<String, Object> params);

}