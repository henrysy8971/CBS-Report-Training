package com.silverlakesymmetri.cbs.swf.svc.mapper.mapping;

import org.mapstruct.InheritInverseConfiguration;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Mappings;

import com.silverlakesymmetri.cbs.swf.jpa.mapping.sdo.SwfF77NarrativeJpe;
import com.silverlakesymmetri.cbs.swf.xmlapi.SWFF77NARRATIVETYPEType;

@Mapper()
public interface SwfF77NarrativeMapper {
	@Mappings({
		@Mapping(source="index", target="INDEX"),
		@Mapping(source="code", target="CODE"),
		@Mapping(source="country", target="COUNTRY"),
		@Mapping(source="narrative", target="NARRATIVE")
	})
	SWFF77NARRATIVETYPEType mapToApi(SwfF77NarrativeJpe jpe);
	
	@InheritInverseConfiguration(name = "mapToApi")
	SwfF77NarrativeJpe mapToJpe(SWFF77NARRATIVETYPEType api);

}