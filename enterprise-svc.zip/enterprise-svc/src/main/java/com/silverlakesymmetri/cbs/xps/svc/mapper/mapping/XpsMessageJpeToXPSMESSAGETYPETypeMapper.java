package com.silverlakesymmetri.cbs.xps.svc.mapper.mapping;

import org.mapstruct.InheritInverseConfiguration;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingTarget;
import org.mapstruct.Mappings;

import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.XpsMessageJpe;
import com.silverlakesymmetri.cbs.xps.svc.batch.XmlApiMapperResolvable;
import com.silverlakesymmetri.cbs.xps.xmlapi.XPSMESSAGETYPEType;

@Mapper
public interface XpsMessageJpeToXPSMESSAGETYPETypeMapper extends XmlApiMapperResolvable<XpsMessageJpe, XPSMESSAGETYPEType> {

    @Mappings({
    	@Mapping(source = "senderContactType", target = "SENDERCONTACTTYPE"),
    	@Mapping(source = "senderContactSubType", target = "SENDERCONTACTSUBTYPE"),
    	@Mapping(source = "receiverClientType", target = "RECEIVERCLIENTTYPE"),
    	@Mapping(source = "receiverContactType", target = "RECEIVERCONTACTTYPE"),
    	@Mapping(source = "receiverContactSubType", target = "RECEIVERCONTACTSUBTYPE"),
    	@Mapping(source = "format", target = "FORMAT"),
    	@Mapping(source = "adviceDays", target = "ADVICEDAYS"),
    })
    XPSMESSAGETYPEType mapToApi(XpsMessageJpe jpe);

    @InheritInverseConfiguration(name = "mapToApi")
    XpsMessageJpe mapToJpe(XPSMESSAGETYPEType api, @MappingTarget XpsMessageJpe jpe);

    @InheritInverseConfiguration(name = "mapToApi")
    XpsMessageJpe mapToJpe(XPSMESSAGETYPEType api);

}
