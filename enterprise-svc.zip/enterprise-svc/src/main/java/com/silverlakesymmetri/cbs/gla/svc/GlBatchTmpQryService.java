package com.silverlakesymmetri.cbs.gla.svc;

import java.util.List;
import java.util.Map;

import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation;
import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation.ServiceOperationType;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.svc.BusinessService;
import com.silverlakesymmetri.cbs.gla.bdo.sdo.GlBatchTmpQry;
import com.silverlakesymmetri.cbs.gla.jpa.mapping.sdo.GlBatchTmpQryJpe;

public interface GlBatchTmpQryService extends BusinessService<GlBatchTmpQry, GlBatchTmpQryJpe> {

	public static final String SVC_OP_NAME_GLBATCHTMPQRYQRYSERVICE_GET = "GlBatchTmpQryService.get";
	public static final String SVC_OP_NAME_GLBATCHTMPQRYSERVICE_FIND = "GlBatchTmpQryService.find";
	public static final String SVC_OP_NAME_GLBATCHTMPQRYSERVICE_QUERY = "GlBatchTmpQryService.query";
	public static final String SVC_OP_NAME_GLBATCHTMPQRYQRYSERVICE_GET_TRADE_NOS = "GlBatchTmpQryService.getTradeNos";
	public static final String SVC_OP_NAME_GLBATCHTMPQRYQRYSERVICE_GET_REF_NOS = "GlBatchTmpQryService.getRefNos";

	@ServiceOperation(name = SVC_OP_NAME_GLBATCHTMPQRYQRYSERVICE_GET, type = ServiceOperationType.GET)
	public GlBatchTmpQry getByPk(String publicKey, GlBatchTmpQry reference);

	@ServiceOperation(name = SVC_OP_NAME_GLBATCHTMPQRYSERVICE_FIND)
	public List<GlBatchTmpQry> find(FindCriteria findCriteria, CbsHeader cbsHeader);

	@ServiceOperation(name = SVC_OP_NAME_GLBATCHTMPQRYSERVICE_QUERY)
	public List<GlBatchTmpQry> query(int offset, int resultLimit, String groupBy, String order,
			Map<String, Object> filters);

	@ServiceOperation(name = SVC_OP_NAME_GLBATCHTMPQRYQRYSERVICE_GET_TRADE_NOS, type = ServiceOperationType.READ, passParamAsMap = true)
	public List<GlBatchTmpQry> getTradeNos(Map<String, Object> queryParams);

	@ServiceOperation(name = SVC_OP_NAME_GLBATCHTMPQRYQRYSERVICE_GET_REF_NOS, type = ServiceOperationType.READ, passParamAsMap = true)
	public List<GlBatchTmpQry> getRefNos(Map<String, Object> queryParams);

}
