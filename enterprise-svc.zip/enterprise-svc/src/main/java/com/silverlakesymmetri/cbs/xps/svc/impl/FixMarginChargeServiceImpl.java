package com.silverlakesymmetri.cbs.xps.svc.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.inject.Inject;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;

import com.mysema.query.types.EntityPath;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.jpa.extension.JaxbSdoHelper;
import com.silverlakesymmetri.cbs.commons.jpa.service.CbsGenericDataService;
import com.silverlakesymmetri.cbs.commons.jpa.service.impl.BusinessDataObjectJpaQueryComponentImpl;
import com.silverlakesymmetri.cbs.commons.svc.AbstractBusinessService;
import com.silverlakesymmetri.cbs.commons.svc.BusinessObjectValidationCapable;
import com.silverlakesymmetri.cbs.commons.svc.ref.ReferenceNumberGeneratorService;
import com.silverlakesymmetri.cbs.commons.svc.util.InMemoryQueryExecutor;
import com.silverlakesymmetri.cbs.csd.svc.CcyConversionService;
import com.silverlakesymmetri.cbs.xps.bdo.sdo.FixMarginCharge;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.FixMarginChargeJpe;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.QFixMarginChargeJpe;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.util.XpsJpeConstants;
import com.silverlakesymmetri.cbs.xps.svc.FixMarginChargeService;

@Service
@Transactional
public class FixMarginChargeServiceImpl extends AbstractBusinessService<FixMarginCharge, FixMarginChargeJpe, String>
		implements FixMarginChargeService, BusinessObjectValidationCapable<FixMarginCharge> {

	@Inject
	protected JaxbSdoHelper jaxbSdoHelper;
	@Autowired
	protected CcyConversionService ccyConversionService;
	@Autowired
	private CbsGenericDataService dataService;

	@Autowired
	private ReferenceNumberGeneratorService referenceNumberGeneratorService;

	@Override
	protected String getIdFromDataObjectInstance(FixMarginCharge dataObject) {
		return dataObject.getChargeRefNo();
	}

	@Override
	protected EntityPath<FixMarginChargeJpe> getEntityPath() {
		return QFixMarginChargeJpe.fixMarginChargeJpe;
	}

	@Override
	public FixMarginCharge get(FixMarginCharge objectInstanceIdentifier) {

		List<FixMarginChargeJpe> jpeResult = dataService
				.findWithNamedQuery(XpsJpeConstants.FIX_MARGIN_CHARGE_JPE_GET_ALL, FixMarginChargeJpe.class);
		FixMarginCharge sdo = null;
		for (FixMarginChargeJpe jpe : jpeResult) {
			if (jpe.getChargeRefNo().equals(objectInstanceIdentifier.getChargeRefNo())) {
				sdo = jaxbSdoHelper.wrap(jpe, FixMarginCharge.class);
			}
		}

		return sdo;
	}

	@Override
	public List<FixMarginCharge> query(int offset, int resultLimit, String groupBy, String order,
			Map<String, Object> filters) {
		List<FixMarginCharge> sdoResult = getAll();
		FindCriteria fc = jaxbSdoHelper.wrap(BusinessDataObjectJpaQueryComponentImpl.buildFindCriteria(offset,
				resultLimit, groupBy, order, filters));
		return filterAndSortResult(fc, sdoResult);
	}

	@Override
	public FixMarginCharge create(FixMarginCharge dataObject) {
		Defaulting(dataObject);
		return super.create(dataObject);
	}

	@Override
	public FixMarginCharge update(FixMarginCharge dataObject) {
		Defaulting(dataObject);
		return super.update(dataObject);
	}

	@Override
	public boolean delete(FixMarginCharge dataObject) {
		return super.delete(dataObject);
	}

	@Override
	public List<FixMarginCharge> getAll() {
		List<FixMarginCharge> sdoResult = new ArrayList<FixMarginCharge>();

		List<FixMarginChargeJpe> jpeResult = dataService
				.findWithNamedQuery(XpsJpeConstants.FIX_MARGIN_CHARGE_JPE_GET_ALL, FixMarginChargeJpe.class);

		for (FixMarginChargeJpe jpe : jpeResult) {
			if (null != jpe.getChargeType()
					&& (("F".equals(jpe.getChargeType())) || ("M".equals(jpe.getChargeType())))) {
				FixMarginCharge sdo = jaxbSdoHelper.wrap(jpe, FixMarginCharge.class);
				sdoResult.add(sdo);
			}
		}

		return sdoResult;
	}

	private List<FixMarginCharge> filterAndSortResult(FindCriteria findCriteria, List<FixMarginCharge> list) {
		InMemoryQueryExecutor<FixMarginCharge> inMemQry = new InMemoryQueryExecutor<>(list);
		return inMemQry.executeFilter(findCriteria);
	}

	@Override
	protected FixMarginCharge preCreateValidation(FixMarginCharge dataObject) {
		if (null != dataObject) {
			performDefaulting(dataObject);
			if (StringUtils.isEmpty(dataObject.getChargeRefNo())) {
				referenceNumberGeneratorService.getNewRefNo(dataObject, "chargeRefNo");
			}
			if (dataObject.isUsedYn() == null) {
				dataObject.setUsedYn(false);
			}
			if (dataObject.isActiveYn() == null) {
				dataObject.setActiveYn(false);
			}
		}
		return dataObject;
	}

	@Override
	protected FixMarginCharge preUpdateValidation(FixMarginCharge dataObject) {
		performDefaulting(dataObject);
		return dataObject;
	}

	private void performDefaulting(FixMarginCharge fixMarginChargeJpe) {
		if (null != fixMarginChargeJpe) {
			if (null == fixMarginChargeJpe.getChargeType()) {
				fixMarginChargeJpe.setChargeType("F");
			}
		}
	}

	@Override
	public List<FixMarginCharge> find(FindCriteria findCriteria, CbsHeader cbsHeader) {
		List<FixMarginCharge> sdoResult = getAll();
		return filterAndSortResult(findCriteria, sdoResult);
	}

	@Override
	public FixMarginCharge getByPk(String publicKey, FixMarginCharge reference) {
		FixMarginCharge result = super.getByPk(publicKey, reference);
		if (null != result && null != result.getChargeType()
				&& (("F".equals(result.getChargeType())) || ("M".equals(result.getChargeType())))) {
			return result;
		} else {
			return null;
		}
	}

	@Override
	public Long count(FindCriteria findCriteria, CbsHeader cbsHeader) {
		List<FixMarginCharge> sdoResult = getAll();
		return Long.valueOf((long) filterAndSortResult(findCriteria, sdoResult).size());
	}

	private void Defaulting(FixMarginCharge dataObject) {
		if (null != dataObject) {
			// chargeType
			if (null != dataObject.getChargeType() && "M".equals(dataObject.getChargeType())) {
				dataObject.setFixAmt(null);
				dataObject.setRecurring("N");
				dataObject.setPeriodFreq(null);
			}
			// recurring
			if (null == dataObject.getRecurring()) {
				dataObject.setRecurring("N");
			}
			// userRateConstituents
			if (null == dataObject.getUseRateConstituents()) {
				dataObject.setUseRateConstituents("N");
			}
			// interestAction
			if (null == dataObject.getInterestAction()) {
				dataObject.setInterestAction("N");
			}
		}
	}

}
