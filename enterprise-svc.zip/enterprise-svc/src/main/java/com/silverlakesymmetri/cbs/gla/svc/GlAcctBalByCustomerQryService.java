package com.silverlakesymmetri.cbs.gla.svc;

import java.util.List;
import java.util.Map;

import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation;
import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation.ServiceOperationType;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.svc.BusinessService;
import com.silverlakesymmetri.cbs.gla.bdo.sdo.GlAcctBalByCustomerQry;
import com.silverlakesymmetri.cbs.gla.jpa.mapping.sdo.GlAcctBalByCustomerQryJpe;

public interface GlAcctBalByCustomerQryService extends BusinessService<GlAcctBalByCustomerQry, GlAcctBalByCustomerQryJpe> {

	public static final String SVC_OP_NAME_GLACCTBALBYCUSTOMERQRYSERVICE_GET = "GlAcctBalByCustomerQryService.get";
	public static final String SVC_OP_NAME_GLACCTBALBYCUSTOMERQRYSERVICE_FIND = "GlAcctBalByCustomerQryService.find";
	public static final String SVC_OP_NAME_GLACCTBALBYCUSTOMERQRYSERVICE_QUERY = "GlAcctBalByCustomerQryService.query";
	
	@ServiceOperation(name = SVC_OP_NAME_GLACCTBALBYCUSTOMERQRYSERVICE_GET, type = ServiceOperationType.GET)
    public GlAcctBalByCustomerQry getByPk(String publicKey, GlAcctBalByCustomerQry reference);

    @ServiceOperation(name = SVC_OP_NAME_GLACCTBALBYCUSTOMERQRYSERVICE_FIND)
    public List<GlAcctBalByCustomerQry> find(FindCriteria findCriteria, CbsHeader cbsHeader);
    
    @ServiceOperation(name = SVC_OP_NAME_GLACCTBALBYCUSTOMERQRYSERVICE_QUERY)
    public List<GlAcctBalByCustomerQry> query(int offset, int resultLimit, String groupBy, String order, Map<String, Object> filters);
}
