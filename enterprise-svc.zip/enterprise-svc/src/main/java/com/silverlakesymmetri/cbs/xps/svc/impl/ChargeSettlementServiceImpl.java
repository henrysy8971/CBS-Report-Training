package com.silverlakesymmetri.cbs.xps.svc.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.velocity.VelocityContext;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.mysema.query.types.EntityPath;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.exception.base.CbsServiceProcessException;
import com.silverlakesymmetri.cbs.commons.jpa.util.DateTimeHelper;
import com.silverlakesymmetri.cbs.commons.xmlapi.enums.CbsXmlApiOperation;
import com.silverlakesymmetri.cbs.mcl.bdo.sdo.Client;
import com.silverlakesymmetri.cbs.mcl.bdo.sdo.ClientContact;
import com.silverlakesymmetri.cbs.swf.bdo.sdo.SwfMessageGroup;
import com.silverlakesymmetri.cbs.xps.bdo.sdo.ChargeMaster;
import com.silverlakesymmetri.cbs.xps.bdo.sdo.ChargeSettlement;
import com.silverlakesymmetri.cbs.xps.bdo.sdo.ChargeSettlementDetails;
import com.silverlakesymmetri.cbs.xps.bdo.sdo.MessageQOthers;
import com.silverlakesymmetri.cbs.xps.bdo.sdo.SettleMessagePreviewAddInfo;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.ChargeSettlementJpe;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.QChargeSettlementJpe;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.util.XpsJpeConstants;
import com.silverlakesymmetri.cbs.xps.svc.AbstractXmlApiAdviceCapableBusinessService;
import com.silverlakesymmetri.cbs.xps.svc.ChargeMasterService;
import com.silverlakesymmetri.cbs.xps.svc.ChargeSettlementService;
import com.silverlakesymmetri.cbs.xps.svc.mapper.ChargeSettlementServiceMapper;
import com.silverlakesymmetri.cbs.xps.xmlapi.XPSTRANCHARGESETTLEAPIType;

@Service
@Transactional
public class ChargeSettlementServiceImpl extends AbstractXmlApiAdviceCapableBusinessService<ChargeSettlement, ChargeSettlementJpe, Long, XPSTRANCHARGESETTLEAPIType, XPSTRANCHARGESETTLEAPIType> implements ChargeSettlementService {

    @Autowired
    private ChargeSettlementServiceMapper mapper;

    @Autowired
    private ChargeMasterService chargeMasterService;
    
	@Autowired
	protected DateTimeHelper dateTimeHelper;


    @Override
    public ChargeSettlement getByPk(String publicKey, ChargeSettlement reference) {
    	Map<String, Object> params = new HashMap<String, Object>();
    	params.put("internalKey", new Long(publicKey));
    	List<ChargeSettlementJpe> result = dataService.findWithNamedQuery(XpsJpeConstants.FIND_CHARGE_SETTLEMENT_BY_INTERNAL_KEY, params, ChargeSettlementJpe.class);
    	if(result != null && result.size() > 0){
    		ChargeSettlementJpe jpe = result.get(0);
    		ChargeSettlement bdo = jaxbSdoHelper.wrap(jpe, ChargeSettlement.class);
        	XPSTRANCHARGESETTLEAPIType request = new XPSTRANCHARGESETTLEAPIType();
        	request.setINTERNALKEY(new Long(publicKey));
        	request.setOPERATION(CbsXmlApiOperation.QUERY.getOperation());
			super.setTechColsFromDataObject(bdo, request);
			XPSTRANCHARGESETTLEAPIType resultApiType = queryXmlApiRs(request);
			ChargeSettlement settlement = processXmlApiRs(bdo, resultApiType);
			if (settlement != null) {
				bdo.setChargeSettleDetailsList(settlement.getChargeSettleDetailsList());
			}
			return bdo;
    	}
    	return null;
    }

    @Override
    public List<ChargeSettlement> find(FindCriteria findCriteria, CbsHeader cbsHeader) {
        return super.find(findCriteria, cbsHeader);
    }

    @Override
    public List<ChargeSettlement> query(int offset, int resultLimit, String groupBy, String order, Map<String, Object> filters) {
        return super.query(offset, resultLimit, groupBy, order, filters);
    }

    @Override
    public ChargeSettlement preCreateValidation(ChargeSettlement dataObject) {
    	validateSettlementAmount(dataObject);
    	return super.preCreateValidation(dataObject);
    }

    @Override
    public ChargeSettlement create(ChargeSettlement dataObject) {
        return super.create(dataObject);
    }

    @Override
    public ChargeSettlement preUpdateValidation(ChargeSettlement dataObject) {
    	validateSettlementAmount(dataObject);
    	return super.preUpdateValidation(dataObject);
    }

    private void validateSettlementAmount(ChargeSettlement dataObject){
		ChargeMaster master = chargeMasterService.getByPk(dataObject.getInternalKey().toString(), null);
    	if(dataObject.getChargeSettleDetailsList() != null && master != null){
    		Double totalSettlementAmount = new Double(0);
    		for(ChargeSettlementDetails detail : dataObject.getChargeSettleDetailsList()){
				if(detail.getAmount() != null){
					totalSettlementAmount = totalSettlementAmount.doubleValue() + detail.getAmount().doubleValue();
				}
    		}
    		if(totalSettlementAmount.compareTo(master.getAmount()) != 0){
	            String msg = messageUtils.getMessage("CBS.B.XPS.CHARGEWITHSETTLEMENT.0001", new String[] {});
	            CbsServiceProcessException exec = new CbsServiceProcessException("CBS.B.XPS.CHARGEWITHSETTLEMENT.0001", msg);
	            throw exec;
			}
    	}
    }

    @Override
    public ChargeSettlement update(ChargeSettlement dataObject) {
        return super.create(dataObject);
    }

    @Override
    protected XPSTRANCHARGESETTLEAPIType transformBdoToXmlApiRqCreate(ChargeSettlement dataObject) {
        return transformBdoToXmlApiType(dataObject, CbsXmlApiOperation.INSERT);
    }

    @Override
    protected XPSTRANCHARGESETTLEAPIType transformBdoToXmlApiRqUpdate(ChargeSettlement dataObject) {
        return transformBdoToXmlApiType(dataObject, CbsXmlApiOperation.INSERT);
    }

    @Override
    protected XPSTRANCHARGESETTLEAPIType transformBdoToXmlApiRqDelete(ChargeSettlement dataObject) {
        return null;
    }

    private XPSTRANCHARGESETTLEAPIType transformBdoToXmlApiType(ChargeSettlement dataObject, CbsXmlApiOperation oper) {
    	ChargeSettlementJpe jpe = jaxbSdoHelper.unwrap(dataObject);
    	XPSTRANCHARGESETTLEAPIType api = mapper.mapToApi(jpe, oper);
    	super.setTechColsFromDataObject(dataObject, api);
        return api;
    }

    @Override
    protected Map<String, String> executeStoredProcedure(String xmlApiReq, String xmlHeaderIn) {
        String xmlApiReqProcess = xmlApiReq.replaceAll("XPS_TRAN_CHARGE_SETTLE_API OPERATION=\"INSERT\"", "XPS_TRAN_CHARGE_SETTLE_API OPERATION=\"PROCESS_AUTHORIZE\"");
        return super.executeStoredProcedure(xmlApiReqProcess, xmlHeaderIn);
    }

    @Override
    protected ChargeSettlement processXmlApiRs(ChargeSettlement dataObject, XPSTRANCHARGESETTLEAPIType xmlApiRs) {
    	ChargeSettlementJpe jpe = new ChargeSettlementJpe();
        mapper.mapToJpe(xmlApiRs, jpe);
        ChargeSettlement response = jaxbSdoHelper.wrap(jpe);
        return response;
    }

    @Override
    protected List<ChargeSettlement> processXmlApiListRs(ChargeSettlement dataObject, XPSTRANCHARGESETTLEAPIType xmlApiRs) {
        return null;
    }

    @Override
    protected Class<XPSTRANCHARGESETTLEAPIType> getXmlApiResponseClass() {
        return XPSTRANCHARGESETTLEAPIType.class;
    }

    @Override
    protected Long getIdFromDataObjectInstance(ChargeSettlement dataObject) {
    	ChargeSettlementJpe jpe = jaxbSdoHelper.unwrap(dataObject);
        return jpe.getInternalKey();
    }

    @Override
    protected EntityPath<ChargeSettlementJpe> getEntityPath() {
        return QChargeSettlementJpe.chargeSettlementJpe;
    }

	@Override
	public Long count(FindCriteria findCriteria, CbsHeader cbsHeader) {
		// TODO Auto-generated method stub
		return null;
	}
    

	@Override
	public String generateSwfMessage(Map<String, Object> params) {
		String swfMessage = null;
    	SwfMessageGroup msgGroup = jsonConversionMngr.convertToType(params.get("msgGroup"), SwfMessageGroup.class, null, null);
		if(params.get("module") != null){
			msgGroup.setModule(params.get("module").toString());
		} 
		ChargeSettlement bdo = jsonConversionMngr.convertToType(params.get("transactionBdo"), ChargeSettlement.class, null, null);
    	String swiftMessageFromQueue = getGeneratedSwiftMessage(bdo.getInternalKey(), "ZST", msgGroup.getFormat(), msgGroup.getModule());
    	if(swiftMessageFromQueue != null){
    		return swiftMessageFromQueue;
    	}
		XPSTRANCHARGESETTLEAPIType xmlApiReq = transformBdoToXmlApiType(bdo, CbsXmlApiOperation.QUERY);
    	SettleMessagePreviewAddInfo addtlInfo = jsonConversionMngr.convertToType(params.get("parentInfo"), SettleMessagePreviewAddInfo.class, null, null);
    	swfMessage = transformToSwfFormat(xmlApiReq, msgGroup, addtlInfo);
		return swfMessage;
	}

	@Override
	protected MessageQOthers fillContext(Map<String, Object> adviceParams, VelocityContext context){
		ChargeMaster master = jsonConversionMngr.convertToType(adviceParams.get("ChargeMaster"), ChargeMaster.class, null, null);
		context.put("ChargeMaster", master);
		adviceParams.remove("ChargeMaster");

		ChargeSettlementDetails details = jsonConversionMngr.convertToType(adviceParams.get("bdo"), ChargeSettlementDetails.class, null, null);
		context.put("ChargeSettlementDetails", details);
		adviceParams.remove("bdo");

		if(details.getCommonSettleDepositRec() != null){
			context.put("CommonSettleDeposit", details.getCommonSettleDepositRec());
			Client client = clientService.getByPk(details.getCommonSettleDepositRec().getClientNo(), null);
			if(client != null){
				context.put("Client", client);
				adviceParams.put("Client", client);
				ClientContact contact = getClientContact(client, "POSTAL", null);
				context.put("ClientContact", contact);
			}
		}

		if(details.getInternalKey() != null) {
			Map<String, Object> filters = new HashMap<String, Object>();
			filters.put("tranInternalKey", details.getInternalKey());
			filters.put("tranEventType", "ZST");
			List<MessageQOthers> messageQList = messageQOthersService.query(0, -1, null, null, filters);
			if(messageQList != null && messageQList.size() > 0){
				return messageQList.get(0);
			}
		}
		return null;
	}

	

}
