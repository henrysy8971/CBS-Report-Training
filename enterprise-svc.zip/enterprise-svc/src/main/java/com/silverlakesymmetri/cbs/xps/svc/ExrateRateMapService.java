package com.silverlakesymmetri.cbs.xps.svc;

import java.util.List;
import java.util.Map;

import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation;
import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation.ServiceOperationType;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.svc.BusinessService;
import com.silverlakesymmetri.cbs.xps.bdo.sdo.ExrateRateMap;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.ExrateRateMapJpe;

public interface ExrateRateMapService extends BusinessService<ExrateRateMap, ExrateRateMapJpe>{
	
	public static final String XPS_OP_NAME_EXRATERATEMAPSERVICE_GET = "ExrateRateMapService.get";
    public static final String XPS_OP_NAME_EXRATERATEMAPSERVICE_QUERY = "ExrateRateMapService.query";
    public static final String XPS_OP_NAME_EXRATERATEMAPSERVICE_CREATE = "ExrateRateMapService.create";
    public static final String XPS_OP_NAME_EXRATERATEMAPSERVICE_UPDATE = "ExrateRateMapService.update";
    public static final String XPS_OP_NAME_EXRATERATEMAPSERVICE_DELETE = "ExrateRateMapService.delete";
    public static final String XPS_OP_NAME_EXRATERATEMAPSERVICE_FIND = "ExrateRateMapService.find";
    
    @ServiceOperation(name = XPS_OP_NAME_EXRATERATEMAPSERVICE_GET, type = ServiceOperationType.GET)
    public ExrateRateMap getByPk(String publicKey, ExrateRateMap reference);

    @ServiceOperation(name = XPS_OP_NAME_EXRATERATEMAPSERVICE_CREATE)
    public ExrateRateMap create(ExrateRateMap dataObject);

     @ServiceOperation(name = XPS_OP_NAME_EXRATERATEMAPSERVICE_UPDATE)
    public ExrateRateMap update(ExrateRateMap dataObject);

    @ServiceOperation(name = XPS_OP_NAME_EXRATERATEMAPSERVICE_QUERY)
    public List<ExrateRateMap> query(int offset, int resultLimit, String groupBy, String order, Map<String, Object> filters);

    @ServiceOperation(name = XPS_OP_NAME_EXRATERATEMAPSERVICE_DELETE)
    public boolean delete(ExrateRateMap dataObject);

    @ServiceOperation(name = XPS_OP_NAME_EXRATERATEMAPSERVICE_FIND)
    public List<ExrateRateMap> find(FindCriteria findCriteria, CbsHeader cbsHeader);

}
