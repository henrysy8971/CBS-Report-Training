package com.silverlakesymmetri.cbs.xps.svc;

import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation;
import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation.ServiceOperationType;
import com.silverlakesymmetri.cbs.commons.svc.BusinessService;
import com.silverlakesymmetri.cbs.xps.bdo.sdo.NostroReconWrapper;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.NostroReconWrapperJpe;

public interface NostroReconWrapperService extends BusinessService<NostroReconWrapper, NostroReconWrapperJpe> {
	/*
	public static final String XPS_OP_NAME_NOSTRORECONWRAPPERSERVICE_GET = "NostroReconWrapperService.get";
    public static final String XPS_OP_NAME_NOSTRORECONWRAPPERSERVICE_QUERY = "NostroReconWrapperService.query";
    public static final String XPS_OP_NAME_NOSTRORECONWRAPPERSERVICE_FIND = "NostroReconWrapperService.find";
    public static final String XPS_OP_NAME_NOSTRORECONWRAPPERSERVICE_CREATE = "NostroReconWrapperService.create";
    public static final String XPS_OP_NAME_NOSTRORECONWRAPPERSERVICE_DELETE = "NostroReconWrapperService.delete";
	public static final String XPS_OP_NAME_NOSTRORECONWRAPPERSERVICE_UPDATE = "NostroReconWrapperService.update";
    */
    public static final String XPS_OP_NAME_NOSTRORECONWRAPPERSERVICE_RECONCILE = "NostroReconWrapperService.reconcile";
    
    /*
    @ServiceOperation(name = XPS_OP_NAME_NOSTRORECONWRAPPERSERVICE_GET, type = ServiceOperationType.GET)
    public NostroReconWrapper getByPk(String publicKey, NostroReconWrapper reference);

    @ServiceOperation(name = XPS_OP_NAME_NOSTRORECONWRAPPERSERVICE_QUERY)
    public List<NostroReconWrapper> query(int offset, int resultLimit, String groupBy, String order, Map<String, Object> filters);
    
    @ServiceOperation(name = XPS_OP_NAME_NOSTRORECONWRAPPERSERVICE_FIND)
    public List<NostroReconWrapper> find(FindCriteria findCriteria, CbsHeader cbsHeader);
    
    @ServiceOperation(name = XPS_OP_NAME_NOSTRORECONWRAPPERSERVICE_CREATE)
    public NostroReconWrapper create(NostroReconWrapper dataObject);

    @ServiceOperation(name = XPS_OP_NAME_NOSTRORECONWRAPPERSERVICE_DELETE)
    public boolean delete(NostroReconWrapper dataObject);
    */

    @ServiceOperation(name = XPS_OP_NAME_NOSTRORECONWRAPPERSERVICE_RECONCILE, type = ServiceOperationType.EXECUTE)
    public NostroReconWrapper reconcile(NostroReconWrapper dataObject);
}