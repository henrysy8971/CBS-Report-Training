package com.silverlakesymmetri.cbs.swf.svc.mapper.decorator;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

import com.silverlakesymmetri.cbs.swf.jpa.mapping.sdo.SwfFinEntityJpe;
import com.silverlakesymmetri.cbs.swf.svc.mapper.mapping.SwfF57Mapper;
import com.silverlakesymmetri.cbs.swf.xmlapi.SWFF57TYPEType;

public abstract class SwfF57MapperDecorator implements SwfF57Mapper {
	
	@Autowired
	@Qualifier("delegate")
	protected SwfF57Mapper delegate;

	@Override
	public SWFF57TYPEType mapToApi(SwfFinEntityJpe jpe){
		SWFF57TYPEType swfF57 = delegate.mapToApi(jpe);
		if(swfF57 != null && swfF57.getACCOUNT() == null && swfF57.getADDRESS() == null && swfF57.getBIC() == null && swfF57.getBRANCHLOCATION() == null){
			return null;
		}
		return swfF57;
	}
	
	@Override
	public SwfFinEntityJpe mapToJpe(SWFF57TYPEType api){
		return delegate.mapToJpe(api);
	}
	
}
