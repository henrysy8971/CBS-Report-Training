package com.silverlakesymmetri.cbs.swf.svc.mapper.mapping;

import org.mapstruct.InheritInverseConfiguration;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Mappings;

import com.silverlakesymmetri.cbs.swf.jpa.mapping.sdo.SwfMtn96Jpe;
import com.silverlakesymmetri.cbs.swf.xmlapi.SWFMTN96TYPEType;

@Mapper(uses={
		  SwfF21Mapper.class,
		  SwfF76Mapper.class,
		  SwfF77TextMapper.class,
		  SwfF11Mapper.class,
		  SwfF79Mapper.class})
public interface SwfMtn96Mapper {
	@Mappings({
		@Mapping(source="relatedRef", target="RELATEDREFERENCE"),
		@Mapping(source="answersStructRec", target="ANSWERS"),
		@Mapping(source="narrativeStructRec", target="NARRATIVE"),
		@Mapping(source="origMessageDateStructRec", target="ORIGMESSAGEDATE"),
		@Mapping(source="origMessageNarrativeStructRec", target="ORIGMESSAGENARRATIVE"),
	})
	SWFMTN96TYPEType mapToApi(SwfMtn96Jpe jpe);
	
	@InheritInverseConfiguration(name="mapToApi")
	SwfMtn96Jpe mapToJpe(SWFMTN96TYPEType api);
	
}
