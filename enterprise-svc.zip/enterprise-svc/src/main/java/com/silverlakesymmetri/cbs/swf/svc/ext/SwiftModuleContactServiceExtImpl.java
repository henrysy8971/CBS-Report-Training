package com.silverlakesymmetri.cbs.swf.svc.ext;

import com.silverlakesymmetri.cbs.commons.ext.ServiceExtensionPoint;
import com.silverlakesymmetri.cbs.commons.ext.impl.AbstractServiceExtPointImpl;
import com.silverlakesymmetri.cbs.commons.jpa.extension.JaxbSdoHelper;
import com.silverlakesymmetri.cbs.commons.jpa.repository.RegistryRepository;
import com.silverlakesymmetri.cbs.commons.jpa.service.CbsGenericDataService;
import com.silverlakesymmetri.cbs.commons.util.MessageUtils;
import com.silverlakesymmetri.cbs.csd.jpa.validation.business.SwiftModuleContactServiceExt;
import com.silverlakesymmetri.cbs.swf.jpa.mapping.sdo.BicDirectoryJpe;
import com.silverlakesymmetri.cbs.swf.jpa.mapping.sdo.util.SwfJpeConstants;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.persistence.NoResultException;
import java.util.*;

@Service
public class SwiftModuleContactServiceExtImpl extends AbstractServiceExtPointImpl implements ServiceExtensionPoint,
        SwiftModuleContactServiceExt {


	@Autowired
	private JaxbSdoHelper jaxbSdoHelper;

	@Autowired
	private CbsGenericDataService dataService;

	@Autowired
	private RegistryRepository registryRepository;

	@Autowired
	protected MessageUtils messageUtils;

	@Override
	public String[] getExtendedBdoNames() {
		return new String[]{CONTACT};
	}

	@Override
	public String[] getExtendedServiceNames() {
		return new String[]{SWIFT_MODULE_CONTACT_SERVICE_EXT_VALIDATE};
	}

	@Override
	public void beforeService(Object[] serviceParameters) {
		// TODO Auto-generated method stub
	}

	@Override
	public Object afterService(Object result, Object[] serviceParameters) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void beforeQuery(Object[] serviceParameters) {
		// TODO Auto-generated method stub
	}

	@Override
	public Object afterQuery(Object result, Object[] serviceParameters) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean isValidBicCode(String bicCode) {
		Map<String, Object> param = new HashMap<>();
		param.put("bic", bicCode);
		boolean isValid = true;

		try{
			BicDirectoryJpe jpe = dataService.getWithNamedQuery(SwfJpeConstants.BIC_DIRECTORY_JPE_LOV_VALIDATION, param, BicDirectoryJpe.class);
			if(jpe != null && jpe.getBic() != null) {
				isValid=true;
			}
		} catch (NoResultException e) {
			isValid = false;
		}

		return isValid;
	}


}
