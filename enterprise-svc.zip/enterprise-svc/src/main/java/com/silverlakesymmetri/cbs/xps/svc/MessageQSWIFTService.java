package com.silverlakesymmetri.cbs.xps.svc;

import java.util.List;
import java.util.Map;

import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation;
import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation.ServiceOperationType;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.svc.BusinessService;
import com.silverlakesymmetri.cbs.xps.bdo.sdo.MessageQSWIFT;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.MessageQSWIFTJpe;

public interface MessageQSWIFTService extends BusinessService<MessageQSWIFT, MessageQSWIFTJpe> {

    public static final String SVC_OP_NAME_MESSAGEQSWIFTSERVICE_GET = "MessageQSWIFTService.get";
    public static final String SVC_OP_NAME_MESSAGEQSWIFTSERVICE_QUERY = "MessageQSWIFTService.query";
    public static final String SVC_OP_NAME_MESSAGEQSWIFTSERVICE_CREATE = "MessageQSWIFTService.create";
    public static final String SVC_OP_NAME_MESSAGEQSWIFTSERVICE_UPDATE = "MessageQSWIFTService.update";
    public static final String SVC_OP_NAME_MESSAGEQSWIFTSERVICE_DELETE = "MessageQSWIFTService.delete";
    public static final String SVC_OP_NAME_MESSAGEQSWIFTSERVICE_FIND = "MessageQSWIFTService.find";
    
    @ServiceOperation(name = SVC_OP_NAME_MESSAGEQSWIFTSERVICE_GET, type = ServiceOperationType.GET)
    public MessageQSWIFT getByPk(String publicKey, MessageQSWIFT reference);

    @ServiceOperation(name = SVC_OP_NAME_MESSAGEQSWIFTSERVICE_CREATE)
    public MessageQSWIFT create(MessageQSWIFT dataObject);

    @ServiceOperation(name = SVC_OP_NAME_MESSAGEQSWIFTSERVICE_UPDATE)
    public MessageQSWIFT update(MessageQSWIFT dataObject);

    @ServiceOperation(name = SVC_OP_NAME_MESSAGEQSWIFTSERVICE_DELETE)
    public boolean delete(MessageQSWIFT dataObject);

    @ServiceOperation(name = SVC_OP_NAME_MESSAGEQSWIFTSERVICE_QUERY)
    public List<MessageQSWIFT> query(int offset, int resultLimit, String groupBy, String order, Map<String, Object> filters);

    @ServiceOperation(name = SVC_OP_NAME_MESSAGEQSWIFTSERVICE_FIND)
    public List<MessageQSWIFT> find(FindCriteria findCriteria, CbsHeader cbsHeader);

}
