package com.silverlakesymmetri.cbs.gla.svc.mapper.mapping;

import org.mapstruct.InheritInverseConfiguration;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Mappings;

import com.silverlakesymmetri.cbs.commons.jpa.util.DateTimeHelper;
import com.silverlakesymmetri.cbs.gla.jpa.mapping.sdo.ManualBatchHdrJpe;
import com.silverlakesymmetri.cbs.gla.xmlapi.GLABATCHHEADERAPIType;

@Mapper(uses={ DateTimeHelper.class})
public interface ManualBatchHdrToGLABATCHHEADERAPITypeMapper {
	
	@Mappings({
		@Mapping(source="batchNo", target="BATCHNO"),
		@Mapping(source="branch", target="BRANCH"),
		@Mapping(source="batchDate", target="BATCHDATE", qualifiedByName = {"DateTimeHelper", "convertDateToCbsXmlApiDate"}),
		@Mapping(source="noOfItems", target="NOOFITEMS"),
		@Mapping(source="hashTotal", target="HASHTOTAL"),
		@Mapping(source="valueDate", target="VALUEDATE", qualifiedByName = {"DateTimeHelper", "convertDateToCbsXmlApiDate"}),
		@Mapping(source="tranDate", target="TRANDATE", qualifiedByName = {"DateTimeHelper", "convertDateToCbsXmlApiDate"}),
		@Mapping(source="internalKey", target="INTERNALKEY"),
		@Mapping(source="interbranch", target="INTERBRANCH")
	})
	public GLABATCHHEADERAPIType mapToApi(ManualBatchHdrJpe jpe);

	@InheritInverseConfiguration(name = "mapToApi")
	@Mappings({ 
		@Mapping(source="BATCHDATE", target="batchDate", qualifiedByName = {"DateTimeHelper", "convertCbsApiDateToString"}),
		@Mapping(source="VALUEDATE", target="valueDate", qualifiedByName = {"DateTimeHelper", "convertCbsApiDateToString"}),
		@Mapping(source="TRANDATE", target="tranDate", qualifiedByName = {"DateTimeHelper","convertCbsApiDateToString"})
	})
	public ManualBatchHdrJpe mapToJpe(GLABATCHHEADERAPIType api);
}
