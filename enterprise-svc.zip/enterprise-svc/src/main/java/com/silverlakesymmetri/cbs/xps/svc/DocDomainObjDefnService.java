package com.silverlakesymmetri.cbs.xps.svc;

import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation;
import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation.ServiceOperationType;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.svc.BusinessService;
import com.silverlakesymmetri.cbs.xps.bdo.sdo.DocDomainObjDefn;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.DocDomainObjDefnJpe;

import java.util.List;
import java.util.Map;

public interface DocDomainObjDefnService extends BusinessService<DocDomainObjDefn, DocDomainObjDefnJpe> {
	public static final String XPS_OP_NAME_DOCDOMAINOBJDEFNSERVICE_GET = "DocDomainObjDefnService.get";
    public static final String XPS_OP_NAME_DOCDOMAINOBJDEFNSERVICE_QUERY = "DocDomainObjDefnService.query";
    public static final String XPS_OP_NAME_DOCDOMAINOBJDEFNSERVICE_FIND = "DocDomainObjDefnService.find";
    public static final String XPS_OP_NAME_DOCDOMAINOBJDEFNSERVICE_CREATE = "DocDomainObjDefnService.create";
    public static final String XPS_OP_NAME_DOCDOMAINOBJDEFNSERVICE_UPDATE = "DocDomainObjDefnService.update";
    public static final String XPS_OP_NAME_DOCDOMAINOBJDEFNSERVICE_DELETE = "DocDomainObjDefnService.delete";
    
    @ServiceOperation(name = XPS_OP_NAME_DOCDOMAINOBJDEFNSERVICE_GET, type = ServiceOperationType.GET)
    public DocDomainObjDefn getByPk(String publicKey, DocDomainObjDefn reference);

    @ServiceOperation(name = XPS_OP_NAME_DOCDOMAINOBJDEFNSERVICE_QUERY)
    public List<DocDomainObjDefn> query(int offset, int resultLimit, String groupBy, String order, Map<String, Object> filters);
    
    @ServiceOperation(name = XPS_OP_NAME_DOCDOMAINOBJDEFNSERVICE_FIND)
    public List<DocDomainObjDefn> find(FindCriteria findCriteria, CbsHeader cbsHeader);
    
    @ServiceOperation(name = XPS_OP_NAME_DOCDOMAINOBJDEFNSERVICE_CREATE)
    public DocDomainObjDefn create(DocDomainObjDefn dataObject);

     @ServiceOperation(name = XPS_OP_NAME_DOCDOMAINOBJDEFNSERVICE_UPDATE)
    public DocDomainObjDefn update(DocDomainObjDefn dataObject);

    @ServiceOperation(name = XPS_OP_NAME_DOCDOMAINOBJDEFNSERVICE_DELETE)
    public boolean delete(DocDomainObjDefn dataObject);
}