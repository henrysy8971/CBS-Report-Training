package com.silverlakesymmetri.cbs.xps.svc.mapper;

import org.mapstruct.Context;
import org.mapstruct.DecoratedWith;
import org.mapstruct.InheritInverseConfiguration;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingTarget;
import org.mapstruct.Mappings;

import com.silverlakesymmetri.cbs.commons.jpa.util.DateTimeHelper;
import com.silverlakesymmetri.cbs.commons.xmlapi.enums.CbsXmlApiOperation;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.ChargeSettlementJpe;
import com.silverlakesymmetri.cbs.xps.svc.mapper.decorator.ChargeSettlementServiceDecorator;
import com.silverlakesymmetri.cbs.xps.svc.mapper.mapping.XpsMessageJpeToXPSMESSAGETYPETypeMapper;
import com.silverlakesymmetri.cbs.xps.xmlapi.XPSTRANCHARGESETTLEAPIType;

@Mapper(uses={ DateTimeHelper.class, ChargeSettlementDetailsServiceMapper.class, XpsMessageJpeToXPSMESSAGETYPETypeMapper.class })
@DecoratedWith(ChargeSettlementServiceDecorator.class)
public interface ChargeSettlementServiceMapper {

	@Mappings({
		@Mapping(expression = "java(oper != null ? oper.getOperation() : null)", target="OPERATION"),
		@Mapping(source="internalKey", target = "INTERNALKEY"),
		@Mapping(source="tranDate", target = "TRANDATE", qualifiedByName = {"DateTimeHelper", "convertDateToCbsXmlApiDate"}),
		@Mapping(source="settleDate", target = "SETTLEDATE", qualifiedByName = {"DateTimeHelper", "convertDateToCbsXmlApiDate"}),
		@Mapping(source="messageStructList", target = "MESSAGELIST.XPSMESSAGETYPE"),
		@Mapping(source="tranStatus", target = "TRANSTATUS"),
		@Mapping(source="domain", target = "DOMAIN"),
		@Mapping(source="chargeSettleDetailsList", target = "DETAILS.XPSTRANCHARGESETTLEDETAILAPI")
	})
	public XPSTRANCHARGESETTLEAPIType mapToApi(ChargeSettlementJpe jpe, @Context CbsXmlApiOperation oper);

	@InheritInverseConfiguration(name = "mapToApi")
	@Mappings({
		@Mapping(source="TRANDATE", target="tranDate", qualifiedByName = {"DateTimeHelper", "convertCbsApiDateToString"}),
		@Mapping(source="SETTLEDATE", target="settleDate", qualifiedByName = {"DateTimeHelper", "convertCbsApiDateToString"})
	})
	public ChargeSettlementJpe mapToJpe(XPSTRANCHARGESETTLEAPIType api, @MappingTarget ChargeSettlementJpe jpe);

	@InheritInverseConfiguration(name = "mapToApi")
	@Mappings({
		@Mapping(source="TRANDATE", target="tranDate", qualifiedByName = {"DateTimeHelper", "convertCbsApiDateToString"}),
		@Mapping(source="SETTLEDATE", target="settleDate", qualifiedByName = {"DateTimeHelper", "convertCbsApiDateToString"})
	})
	public ChargeSettlementJpe mapToJpe(XPSTRANCHARGESETTLEAPIType api);
}