package com.silverlakesymmetri.cbs.gla.svc.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.springframework.stereotype.Service;

import com.mysema.query.types.EntityPath;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.svc.AbstractBusinessService;
import com.silverlakesymmetri.cbs.commons.jpa.service.CbsEntityManagerAware;
import com.silverlakesymmetri.cbs.gla.bdo.sdo.GlOverallPositionQry;
import com.silverlakesymmetri.cbs.gla.bdo.sdo.GlOverallPositionDtlQry;
import com.silverlakesymmetri.cbs.gla.jpa.mapping.sdo.GlOverallPositionQryJpe;
import com.silverlakesymmetri.cbs.gla.jpa.mapping.sdo.GlOverallPositionDtlQryJpe;
import com.silverlakesymmetri.cbs.gla.jpa.mapping.sdo.QGlOverallPositionQryJpe;
import com.silverlakesymmetri.cbs.gla.jpa.mapping.sdo.util.GlaJpeConstants;
import com.silverlakesymmetri.cbs.gla.jpa.mapping.sdo.id.GlOverallPositionQryPk;
import com.silverlakesymmetri.cbs.gla.svc.GlOverallPositionQryService;

@Service
public class GlOverallPositionQryServiceImpl extends AbstractBusinessService<GlOverallPositionQry, GlOverallPositionQryJpe, GlOverallPositionQryPk> implements 
		GlOverallPositionQryService {

	@Override
	protected GlOverallPositionQryPk getIdFromDataObjectInstance(GlOverallPositionQry dataObject) {
		return new GlOverallPositionQryPk(dataObject.getCcy());
	}

	@Override
	protected EntityPath<GlOverallPositionQryJpe> getEntityPath() {
		return QGlOverallPositionQryJpe.glOverallPositionQryJpe;
	}
	
	@Override
	public GlOverallPositionQry getByPk(String publicKey, GlOverallPositionQry dataObject) {

		// same implentation as ExternalAccountStatementServiceImpl
		GlOverallPositionQry glOverallPositionQry = super.getByPk(publicKey, dataObject);
		if (glOverallPositionQry != null) {
			((CbsEntityManagerAware) dataService).getMyEntityManager().detach(unwrap(glOverallPositionQry));

			if (glOverallPositionQry != null) {
				List<GlOverallPositionDtlQry> overallPositionDtlQryList = getList(glOverallPositionQry);
				glOverallPositionQry.setGlOverallPositionDtlQryList(overallPositionDtlQryList);
			}
		}

		return glOverallPositionQry;
	}

	private List<GlOverallPositionDtlQry> getList(final GlOverallPositionQry dataObject) {
		List<GlOverallPositionDtlQry> bdoList = null;

		Map<String, Object> params = new HashMap<>();
		params.put("contractCcy", dataObject.getCcy());
		List<GlOverallPositionDtlQryJpe>  dtlQryList = dataService.findWithNamedQuery(
				GlaJpeConstants.GLA_OVERALL_POSITION_DTL_QRY_JPE_FIND_BY_CONTRACT_CCY, params, 
				GlOverallPositionDtlQryJpe.class);

		if (dtlQryList != null && !dtlQryList.isEmpty()) {
			bdoList = dtlQryList.stream()
									.map(glQryJpe -> jaxbSdoHelper.wrap(glQryJpe, GlOverallPositionDtlQry.class))
									.collect(Collectors.toList());
		}
		return bdoList;
	}
	
	@Override
	public List<GlOverallPositionQry> query(int offset, int resultLimit, String groupBy, String order,
			Map<String, Object> filters) {
		return super.query(offset, resultLimit, groupBy, order, filters);
	}

	@Override
	public List<GlOverallPositionQry> find(FindCriteria findCriteria, CbsHeader cbsHeader) {
		return super.find(findCriteria, cbsHeader);
	}
	
	@Override
	public GlOverallPositionQry get(GlOverallPositionQry objectInstanceIdentifier) {
		return super.get(objectInstanceIdentifier);
	}

}
