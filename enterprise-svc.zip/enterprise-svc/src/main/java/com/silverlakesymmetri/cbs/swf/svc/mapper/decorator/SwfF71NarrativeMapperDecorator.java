package com.silverlakesymmetri.cbs.swf.svc.mapper.decorator;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

import com.silverlakesymmetri.cbs.swf.jpa.mapping.sdo.SwfF71NarrativeJpe;
import com.silverlakesymmetri.cbs.swf.svc.mapper.mapping.SwfF71NarrativeMapper;
import com.silverlakesymmetri.cbs.swf.xmlapi.SWFF71NARRATIVETYPEType;

public abstract class SwfF71NarrativeMapperDecorator implements SwfF71NarrativeMapper {
	
	@Autowired
	@Qualifier("delegate")
	protected SwfF71NarrativeMapper delegate;

	@Override
	public SWFF71NARRATIVETYPEType mapToApi(SwfF71NarrativeJpe jpe){
		SWFF71NARRATIVETYPEType swfF71Narrative = delegate.mapToApi(jpe);
		if(swfF71Narrative != null){
			if(swfF71Narrative.getDETAILS() == null || swfF71Narrative.getDETAILS().getSWFCHARGENARRATIVETYPE() == null || swfF71Narrative.getDETAILS().getSWFCHARGENARRATIVETYPE().size() == 0){
				return null;
			}
		}
		return swfF71Narrative;
	}
	
	@Override
	public SwfF71NarrativeJpe mapToJpe(SWFF71NARRATIVETYPEType api){
		return delegate.mapToJpe(api);
	}
	
}
