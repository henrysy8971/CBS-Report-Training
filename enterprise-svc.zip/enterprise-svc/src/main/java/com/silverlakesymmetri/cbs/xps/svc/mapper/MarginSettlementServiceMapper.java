package com.silverlakesymmetri.cbs.xps.svc.mapper;

import org.mapstruct.Context;
import org.mapstruct.DecoratedWith;
import org.mapstruct.InheritInverseConfiguration;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingTarget;
import org.mapstruct.Mappings;

import com.silverlakesymmetri.cbs.commons.jpa.util.DateTimeHelper;
import com.silverlakesymmetri.cbs.commons.xmlapi.enums.CbsXmlApiOperation;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.MarginSettlementJpe;
import com.silverlakesymmetri.cbs.xps.svc.mapper.decorator.MarginSettlementServiceDecorator;
import com.silverlakesymmetri.cbs.xps.svc.mapper.mapping.XpsMessageJpeToXPSMESSAGETYPETypeMapper;
import com.silverlakesymmetri.cbs.xps.xmlapi.XPSTRANMARGINSETTLEAPIType;

@Mapper(uses={ DateTimeHelper.class, MarginSettlementDetailsServiceMapper.class, XpsMessageJpeToXPSMESSAGETYPETypeMapper.class })
@DecoratedWith(MarginSettlementServiceDecorator.class)
public interface MarginSettlementServiceMapper {

	@Mappings({
		@Mapping(expression = "java(oper != null ? oper.getOperation() : null)", target="OPERATION"),
		@Mapping(source="internalKey", target = "MARGININTERNALKEY"),
		@Mapping(source="settleDate", target = "SETTLEDATE", qualifiedByName = {"DateTimeHelper", "convertDateToCbsXmlApiDate"}),
		@Mapping(source="messageStructList", target = "MESSAGELIST.XPSMESSAGETYPE"),
		@Mapping(source="tranStatus", target = "TRANSTATUS"),
		@Mapping(source="domain", target = "DOMAIN"),
		@Mapping(source="settleType", target = "SETTLETYPE"),
		@Mapping(source="marginSettleDetailsList", target = "DETAILS.XPSTRANMARGINSETTLEDETAILAPI")
	})
	public XPSTRANMARGINSETTLEAPIType mapToApi(MarginSettlementJpe jpe, @Context CbsXmlApiOperation oper);

	@InheritInverseConfiguration(name = "mapToApi")
	@Mappings({
		@Mapping(source="SETTLEDATE", target="settleDate", qualifiedByName = {"DateTimeHelper", "convertCbsApiDateToString"})
	})
	public MarginSettlementJpe mapToJpe(XPSTRANMARGINSETTLEAPIType api, @MappingTarget MarginSettlementJpe jpe);

	@InheritInverseConfiguration(name = "mapToApi")
	@Mappings({
		@Mapping(source="SETTLEDATE", target="settleDate", qualifiedByName = {"DateTimeHelper", "convertCbsApiDateToString"})
	})
	public MarginSettlementJpe mapToJpe(XPSTRANMARGINSETTLEAPIType api);
}