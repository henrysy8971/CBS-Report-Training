package com.silverlakesymmetri.cbs.xps.svc.impl;

import static java.util.stream.Collectors.toMap;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.mysema.query.types.EntityPath;
import com.silverlakesymmetri.cbs.commons.context.CbsRuntimeContextManager;
import com.silverlakesymmetri.cbs.commons.context.CbsSessionContext;
import com.silverlakesymmetri.cbs.commons.logging.CbsAppLogger;
import com.silverlakesymmetri.cbs.commons.logging.CbsAppLoggerFactory;
import com.silverlakesymmetri.cbs.commons.svc.AbstractBusinessService;
import com.silverlakesymmetri.cbs.commons.svc.BusinessObjectValidationCapable;
import com.silverlakesymmetri.cbs.commons.svc.context.impl.CbsRuntimeContextManagerImpl;
import com.silverlakesymmetri.cbs.xps.bdo.sdo.NostroReconWrapper;
import com.silverlakesymmetri.cbs.xps.enums.NostroReconEnum;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.NostroReconWrapperJpe;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.NrPostJpe;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.NrStmtDetailJpe;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.QNostroReconWrapperJpe;
import com.silverlakesymmetri.cbs.xps.svc.NostroReconWrapperService;

@Service
@Transactional
public class NostroReconWrapperServiceImpl extends AbstractBusinessService<NostroReconWrapper, NostroReconWrapperJpe, String> implements NostroReconWrapperService, BusinessObjectValidationCapable<NostroReconWrapper> {

	private static final CbsAppLogger LOGGER = CbsAppLoggerFactory.getLogger(NostroReconWrapperServiceImpl.class);
	private static final String MATCH_TYPE_SKIP = "S";
	private static final String MATCH_TYPE_FORCEMATCH = "F";
	private static final String SEQUENCE_NAME = "XPS_NR_RECON_SEQ_NO_S";
	
    @Autowired
    private CbsRuntimeContextManager ctxMngr;

	@Override
	public NostroReconWrapper reconcile(NostroReconWrapper bdo) {
		if(NostroReconEnum.FORCEMATCH.toString().equals(bdo.getAction())){
			doForceMatch(bdo);
		}else if(NostroReconEnum.UNMATCH.toString().equals(bdo.getAction())){
			doUnmatch(bdo);
		}else if(NostroReconEnum.SKIP.toString().equals(bdo.getAction())){
			doSkip(bdo);
		}else if(NostroReconEnum.UNSKIP.toString().equals(bdo.getAction())){
			doUnskip(bdo);
		}
		return bdo;
	}

	@Override
	protected String getIdFromDataObjectInstance(NostroReconWrapper bdo) {
		NostroReconWrapperJpe jpe = jaxbSdoHelper.unwrap(bdo);
		return jpe.toString();
	}

	@Override
	protected EntityPath<NostroReconWrapperJpe> getEntityPath() {
		return QNostroReconWrapperJpe.nostroReconWrapperJpe;
	}

	private void doUnskip(NostroReconWrapper nrObj) {
		List<NrStmtDetailJpe> exList = getExternalJpeList(nrObj, null);
		for(NrStmtDetailJpe jpe: exList){
			jpe.setMatchType(null);
			jpe.setUnskipBy(getCurrentUser());
			jpe.setUnskipDate(dateTimeHelper.getRunDate());
			this.dataService.update(jpe);
		}

		List<NrPostJpe> intList = getInternalJpeList(nrObj, null);
		for(NrPostJpe jpe: intList){
			jpe.setMatchType(null);
			jpe.setUnskipBy(getCurrentUser());
			jpe.setUnskipDate(dateTimeHelper.getRunDate());
			this.dataService.update(jpe);
		}
	}

	private void doSkip(NostroReconWrapper nrObj) {
		List<NrStmtDetailJpe> exList = getExternalJpeList(nrObj, null);
		for(NrStmtDetailJpe jpe: exList){
			jpe.setMatchType(MATCH_TYPE_SKIP);
			jpe.setSkipBy(getCurrentUser());
			jpe.setSkipDate(dateTimeHelper.getRunDate());
			this.dataService.update(jpe);
		}

		List<NrPostJpe> intList = getInternalJpeList(nrObj, null);
		for(NrPostJpe jpe: intList){
			jpe.setMatchType(MATCH_TYPE_SKIP);
			jpe.setSkipBy(getCurrentUser());
			jpe.setSkipDate(dateTimeHelper.getRunDate());
			this.dataService.update(jpe);
		}
	}

	private void doUnmatch(NostroReconWrapper nrObj) {
		Map<Long, Double> dummyMap = new HashMap<>();
		List<NrStmtDetailJpe> extList = getExternalJpeList(nrObj, dummyMap);
		List<NrPostJpe> intList = getInternalJpeList(nrObj, dummyMap);
		List<Integer> extReconList = extList.stream().map(external -> external.getReconSeqNo()).distinct().collect(Collectors.toList());
		List<Integer> intReconList = intList.stream().map(internal -> internal.getReconSeqNo()).distinct().collect(Collectors.toList());
		
		List<Integer> reconList = new ArrayList<>();
		reconList.addAll(extReconList);
		reconList.addAll(intReconList);

		List<NrStmtDetailJpe> extUpdList = getExternalListByRecon(reconList);
		for(NrStmtDetailJpe jpe: extUpdList){
			jpe.setReconSeqNo(null);
			jpe.setMatchType(null);
			jpe.setUnmatchBy(getCurrentUser());
			jpe.setUnmatchDate(dateTimeHelper.getRunDate());
			jpe.setOutstandingAmt(null);
			this.dataService.update(jpe);
		}
		List<NrPostJpe> intUpdList = getInternalListByRecon(reconList);
		for(NrPostJpe jpe: intUpdList){
			jpe.setReconSeqNo(null);
			jpe.setMatchType(null);
			jpe.setUnmatchBy(getCurrentUser());
			jpe.setUnmatchDate(dateTimeHelper.getRunDate());
			jpe.setOutstandingAmt(null);
			this.dataService.update(jpe);
		}
	}

	private void doForceMatch(NostroReconWrapper nrObj) {
		//external
		Map<Long, Double> extAmtMap = new HashMap<>();
		List<NrStmtDetailJpe> exList = getExternalJpeList(nrObj, extAmtMap);
		Map<Long, Double> extSortedAmtMap = this.sortByValue(extAmtMap);
		Double extTotal = extAmtMap.values().stream().reduce(0d, Double::sum);
		
		//internal
		Map<Long, Double> intAmtMap = new HashMap<>();
		List<NrPostJpe> intList = getInternalJpeList(nrObj, intAmtMap);
		Map<Long, Double> intSortedAmtMap = this.sortByValue(intAmtMap);
		Double intTotal = intAmtMap.values().stream().reduce(0d, Double::sum);

		//logic
		Double diff = Math.abs(extTotal - intTotal);
		boolean updExtOutstanding = false;
		boolean updIntOutstanding = false;
		Map.Entry<Long, Double> extWithHighestAmt = null;
		Map.Entry<Long, Double> intWithHighestAmt = null;
		if(diff > 0){
			updExtOutstanding = extTotal > intTotal;
			updIntOutstanding = intTotal > extTotal;
			if(updExtOutstanding){
				extWithHighestAmt = extSortedAmtMap.entrySet().iterator().next();
			}
			if(updIntOutstanding){
				intWithHighestAmt = intSortedAmtMap.entrySet().iterator().next();
			}
		}
		
		//update
		Long reconSeqNo = dataService.nextSequenceValue(SEQUENCE_NAME);
		for(NrStmtDetailJpe jpe: exList){
			jpe.setReconSeqNo(reconSeqNo.intValue());
			jpe.setMatchType(MATCH_TYPE_FORCEMATCH);
			jpe.setMatchBy(getCurrentUser());
			jpe.setMatchDate(dateTimeHelper.getRunDate());
			if(updExtOutstanding && extWithHighestAmt != null){
				if(jpe.getInternalKey().equals(extWithHighestAmt.getKey())){
					jpe.setOutstandingAmt(diff);
				}
			}
			this.dataService.update(jpe);
		}
		for(NrPostJpe jpe: intList){
			jpe.setReconSeqNo(reconSeqNo.intValue());
			jpe.setMatchType(MATCH_TYPE_FORCEMATCH);
			jpe.setMatchBy(getCurrentUser());
			jpe.setMatchDate(dateTimeHelper.getRunDate());
			if(updIntOutstanding && intWithHighestAmt != null){
				if(jpe.getInternalKey().equals(intWithHighestAmt.getKey())){
					jpe.setOutstandingAmt(diff);
				}
			}
			this.dataService.update(jpe);
		}
	}

	private List<NrStmtDetailJpe> getExternalJpeList(NostroReconWrapper nrObj, Map<Long, Double> amountMap){
		List<NrStmtDetailJpe> externalList = new ArrayList<>();
		if(amountMap==null){amountMap = new HashMap<>();}
		
		if(nrObj.getExternalPkList() !=null && !nrObj.getExternalPkList().isEmpty()){
			String query = "select e from NrStmtDetailJpe e where e.internalKey IN :keys";
			Map<String, Object> filters = new HashMap<>();
			filters.put("keys", nrObj.getExternalPkList());
			
			externalList = dataService.findWithQuery(query, NrStmtDetailJpe.class, filters, null);
			if(externalList!=null){
				for(NrStmtDetailJpe jpe : externalList){
					amountMap.put(jpe.getInternalKey(), jpe.getAmount());
				}
			}
		}
		
		return externalList;
	}

	private List<NrStmtDetailJpe> getExternalListByRecon(List<Integer> reconSeqNoList){
		List<NrStmtDetailJpe> externalList = new ArrayList<>();

		if(reconSeqNoList !=null && !reconSeqNoList.isEmpty()){
			String query = "select e from NrStmtDetailJpe e where e.reconSeqNo in :keys";

			Map<String, Object> filters = new HashMap<>();
			filters.put("keys", reconSeqNoList);
			externalList = dataService.findWithQuery(query, NrStmtDetailJpe.class, filters, null);
		}
		
		return externalList;
	}
	
	private List<NrPostJpe> getInternalJpeList(NostroReconWrapper nrObj, Map<Long, Double> amountMap){
		List<NrPostJpe> internalList = new ArrayList<>();
		if(amountMap==null){amountMap=new HashMap<>();}
		
		if(nrObj.getInternalPkList() !=null && !nrObj.getInternalPkList().isEmpty()){
			String query = "select e from NrPostJpe e where e.internalKey IN :keys";
			
			Map<String, Object> filters = new HashMap<>();
			filters.put("keys", nrObj.getInternalPkList());
			
			internalList = dataService.findWithQuery(query, NrPostJpe.class, filters, null);
			
			if(internalList!=null){
				for(NrPostJpe jpe : internalList){
					amountMap.put(jpe.getInternalKey(), jpe.getAmount());
				}
			}
		}
		
		return internalList;
	}

	private List<NrPostJpe> getInternalListByRecon(List<Integer> reconSeqNoList){
		List<NrPostJpe> internalList = new ArrayList<>();

		if(reconSeqNoList !=null && !reconSeqNoList.isEmpty()){
			String query = "select e from NrPostJpe e where e.reconSeqNo in :keys";

			Map<String, Object> filters = new HashMap<>();
			filters.put("keys", reconSeqNoList);
			internalList = dataService.findWithQuery(query, NrPostJpe.class, filters, null);
		}
		
		return internalList;
	}

    private Map<Long, Double> sortByValue(Map<Long, Double> amountMap) {
        return amountMap.entrySet()
                .stream()
                .sorted(Map.Entry.<Long, Double>comparingByValue().reversed())
                .collect(toMap(Map.Entry::getKey, Map.Entry::getValue, (e1, e2) -> e1, LinkedHashMap::new));
    }

	private String getCurrentUser(){
		CbsSessionContext sessionCtx = ((CbsRuntimeContextManagerImpl) ctxMngr).getContext(CbsSessionContext.class);
		return sessionCtx.getUserCode();
	}

}