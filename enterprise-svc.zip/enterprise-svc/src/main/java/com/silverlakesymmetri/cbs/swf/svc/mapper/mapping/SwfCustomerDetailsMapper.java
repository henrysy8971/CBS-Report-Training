package com.silverlakesymmetri.cbs.swf.svc.mapper.mapping;

import org.apache.commons.lang3.StringUtils;
import org.mapstruct.DecoratedWith;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Mappings;

import com.silverlakesymmetri.cbs.commons.jpa.util.DateTimeHelper;
import com.silverlakesymmetri.cbs.swf.jpa.mapping.sdo.SwfCustomerDetailsJpe;
import com.silverlakesymmetri.cbs.swf.svc.mapper.decorator.SwfCustomerDetailsMapperDecorator;
import com.silverlakesymmetri.cbs.swf.xmlapi.SWFCUSTOMERDETAILSTYPEType;

@Mapper(imports = StringUtils.class, uses={DateTimeHelper.class})
@DecoratedWith(SwfCustomerDetailsMapperDecorator.class)
public interface SwfCustomerDetailsMapper {	
	@Mappings({
		@Mapping(source="name", target="NAME"),
		@Mapping(source="address", target="ADDRESS"),
		@Mapping(source="country", target="COUNTRY"),
		@Mapping(source="town", target="TOWN"),
		@Mapping(source="state", target="STATE"),
		@Mapping(source="postalCode", target="POSTALCODE"),
		@Mapping(source="birthDate", target="BIRTHDATE", qualifiedByName = {"DateTimeHelper","convertDateToCbsXmlApiDate"}),
		@Mapping(source="birthCountry", target="BIRTHCOUNTRY"),
		@Mapping(source="birthPlace", target="BIRTHPLACE"),
		@Mapping(source="customerIdCountry", target="CUSTOMERIDCOUNTRY"),
		@Mapping(source="customerIdIssuer", target="CUSTOMERIDISSUER"),
		@Mapping(source="customerId", target="CUSTOMERID"),
		@Mapping(source="nationalIdCountry", target="NATIONALIDCOUNTRY"),
		@Mapping(source="nationalId", target="NATIONALID"),
		@Mapping(source="additionalInfoCode", target="ADDITIONALINFOCODE"),
		@Mapping(source="additionalInfo", target="ADDITIONALINFO")
	})
	SWFCUSTOMERDETAILSTYPEType mapToApi(SwfCustomerDetailsJpe jpe);
	
	@Mappings({
		@Mapping(target="name", expression="java(StringUtils.isNotBlank(api.getNAME())?api.getNAME():null)"),
		@Mapping(target="address", expression="java(StringUtils.isNotBlank(api.getADDRESS())?api.getADDRESS():null)"),
		@Mapping(target="country", expression="java(StringUtils.isNotBlank(api.getCOUNTRY())?api.getCOUNTRY():null)"),
		@Mapping(target="town", expression="java(StringUtils.isNotBlank(api.getTOWN())?api.getTOWN():null)"),
		@Mapping(target="state", expression="java(StringUtils.isNotBlank(api.getSTATE())?api.getSTATE():null)"),
		@Mapping(target="postalCode", expression="java(StringUtils.isNotBlank(api.getPOSTALCODE())?api.getPOSTALCODE():null)"),
		@Mapping(target="birthDate", source="BIRTHDATE", qualifiedByName = { "DateTimeHelper", "convertCbsApiDateToString" }),
		@Mapping(target="birthCountry", expression="java(StringUtils.isNotBlank(api.getBIRTHCOUNTRY())?api.getBIRTHCOUNTRY():null)"),
		@Mapping(target="birthPlace", expression="java(StringUtils.isNotBlank(api.getBIRTHPLACE())?api.getBIRTHPLACE():null)"),
		@Mapping(target="customerIdCountry", expression="java(StringUtils.isNotBlank(api.getCUSTOMERIDCOUNTRY())?api.getCUSTOMERIDCOUNTRY():null)"),
		@Mapping(target="customerIdIssuer", expression="java(StringUtils.isNotBlank(api.getCUSTOMERIDISSUER())?api.getCUSTOMERIDISSUER():null)"),
		@Mapping(target="customerId", expression="java(StringUtils.isNotBlank(api.getCUSTOMERID())?api.getCUSTOMERID():null)"),
		@Mapping(target="nationalIdCountry", expression="java(StringUtils.isNotBlank(api.getNATIONALIDCOUNTRY())?api.getNATIONALIDCOUNTRY():null)"),
		@Mapping(target="nationalId", expression="java(StringUtils.isNotBlank(api.getNATIONALID())?api.getNATIONALID():null)"),
		@Mapping(target="additionalInfoCode", expression="java(StringUtils.isNotBlank(api.getADDITIONALINFOCODE())?api.getADDITIONALINFOCODE():null)"),
		@Mapping(target="additionalInfo", expression="java(StringUtils.isNotBlank(api.getADDITIONALINFO())?api.getADDITIONALINFO():null)")
	})
	SwfCustomerDetailsJpe mapToJpe(SWFCUSTOMERDETAILSTYPEType api);
}