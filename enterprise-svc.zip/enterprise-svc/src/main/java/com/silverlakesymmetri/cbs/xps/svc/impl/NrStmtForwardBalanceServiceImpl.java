package com.silverlakesymmetri.cbs.xps.svc.impl;

import com.mysema.query.types.EntityPath;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.bdo.ViewCriteriaItem;
import com.silverlakesymmetri.cbs.commons.bdo.ViewCriteriaRow;
import com.silverlakesymmetri.cbs.commons.jpa.entity.FindCriteriaJpe;
import com.silverlakesymmetri.cbs.commons.jpa.entity.ViewCriteriaItemJpe;
import com.silverlakesymmetri.cbs.commons.jpa.entity.ViewCriteriaRowJpe;
import com.silverlakesymmetri.cbs.commons.svc.AbstractBusinessService;
import com.silverlakesymmetri.cbs.commons.svc.BusinessObjectValidationCapable;
import com.silverlakesymmetri.cbs.xps.bdo.sdo.NrStmtForwardBalance;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.NrStmtForwardBalanceJpe;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.QNrStmtForwardBalanceJpe;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.id.NrStmtForwardBalancePk;
import com.silverlakesymmetri.cbs.xps.svc.NrStmtForwardBalanceService;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.*;

@Service
@Transactional
public class NrStmtForwardBalanceServiceImpl extends AbstractBusinessService<NrStmtForwardBalance, NrStmtForwardBalanceJpe, NrStmtForwardBalancePk> implements NrStmtForwardBalanceService, BusinessObjectValidationCapable<NrStmtForwardBalance> {
	
	@Override
	protected NrStmtForwardBalancePk getIdFromDataObjectInstance(NrStmtForwardBalance dataObject) {
		NrStmtForwardBalanceJpe jpe = jaxbSdoHelper.unwrap(dataObject);
		return new NrStmtForwardBalancePk(jpe.getInternalKey());
	}

	@Override
	protected EntityPath<NrStmtForwardBalanceJpe> getEntityPath() {
		return QNrStmtForwardBalanceJpe.nrStmtForwardBalanceJpe;
	}

	@Override
	public NrStmtForwardBalance getByPk(String publicKey, NrStmtForwardBalance reference) {
		NrStmtForwardBalance bdo = super.getByPk(publicKey, reference);
		return bdo;
	}

	@Override
	public List<NrStmtForwardBalance> query(int offset, int resultLimit, String groupBy, String order, Map<String, Object> filters) {
		return super.query(offset, resultLimit, groupBy, order, filters);
	}
	
	@Override
	public List<NrStmtForwardBalance> find(FindCriteria fc, CbsHeader cbsHeader){
		return super.find(fc, cbsHeader);
	}
	
	@Override
	public NrStmtForwardBalance create(NrStmtForwardBalance dataObject) {
		return super.create(dataObject);
	}

	@Override
	public NrStmtForwardBalance update(NrStmtForwardBalance dataObject) {
		return super.update(dataObject);
	}
	
	@Override
	public boolean delete(NrStmtForwardBalance dataObject) {
		return super.delete(dataObject);
	}
}