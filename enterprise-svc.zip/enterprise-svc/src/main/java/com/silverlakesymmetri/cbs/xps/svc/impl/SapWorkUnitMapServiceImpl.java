package com.silverlakesymmetri.cbs.xps.svc.impl;

import com.mysema.query.types.EntityPath;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.svc.AbstractBusinessService;
import com.silverlakesymmetri.cbs.commons.svc.BusinessObjectBpmMergeCapable;
import com.silverlakesymmetri.cbs.commons.svc.BusinessObjectValidationCapable;
import com.silverlakesymmetri.cbs.xps.bdo.sdo.DocumentInventoryHdr;
import com.silverlakesymmetri.cbs.xps.bdo.sdo.SapWorkUnitMap;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.QSapWorkUnitMapJpe;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.SapWorkUnitMapJpe;
import com.silverlakesymmetri.cbs.xps.svc.DocumentInventoryService;
import com.silverlakesymmetri.cbs.xps.svc.SapWorkUnitMapService;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Map;

@Service
@Transactional
public class SapWorkUnitMapServiceImpl extends AbstractBusinessService<SapWorkUnitMap, SapWorkUnitMapJpe, String>
        implements SapWorkUnitMapService, BusinessObjectValidationCapable<SapWorkUnitMap> {

    @Override
    protected String getIdFromDataObjectInstance(SapWorkUnitMap dataObject) {
        return dataObject.getWorkUnit();
    }

    @Override
    protected EntityPath<SapWorkUnitMapJpe> getEntityPath() {
        return QSapWorkUnitMapJpe.sapWorkUnitMapJpe;
    }

    @Override
    public SapWorkUnitMap getByPk(String publicKey, SapWorkUnitMap reference) {
        return super.getByPk(publicKey, reference);
    }

    @Override
    public SapWorkUnitMap create(SapWorkUnitMap dataObject) {
        return super.create(dataObject);
    }

    @Override
    public SapWorkUnitMap update(SapWorkUnitMap dataObject) {
        return super.update(dataObject);
    }

    @Override
    public boolean delete(SapWorkUnitMap dataObject) {
        return super.delete(dataObject);
    }

    @Override
    public List<SapWorkUnitMap> query(int offset, int resultLimit, String groupBy, String order, Map<String, Object> filters) {
        return super.query(offset, resultLimit, groupBy, order, filters);
    }

    @Override
    public List<SapWorkUnitMap> find(FindCriteria findCriteria, CbsHeader cbsHeader) {
        return super.find(findCriteria, cbsHeader);
    }
}
