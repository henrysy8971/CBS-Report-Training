package com.silverlakesymmetri.cbs.xps.svc.mapper.mapping;

import org.mapstruct.InheritInverseConfiguration;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingTarget;
import org.mapstruct.Mappings;

import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.SettleMessageJpe;
import com.silverlakesymmetri.cbs.xps.xmlapi.XPSSETTLEMESSAGETYPEType;

@Mapper
public interface SettleMessageJpeToXPSSETTLEMESSAGETYPETypeMapper {

    @Mappings({
    	@Mapping(source = "senderContactType", target = "SENDERCONTACTTYPE"),
    	@Mapping(source = "senderContactSubType", target = "SENDERCONTACTSUBTYPE"),
    	@Mapping(source = "receiverClientType", target = "RECEIVERCLIENTTYPE"),
    	@Mapping(source = "receiverContactType", target = "RECEIVERCONTACTTYPE"),
    	@Mapping(source = "receiverContactSubType", target = "RECEIVERCONTACTSUBTYPE"),
    	@Mapping(source = "format", target = "FORMAT"),
    	@Mapping(source = "daysAdvance", target = "DAYSADVANCE"),
    })
    XPSSETTLEMESSAGETYPEType mapToApi(SettleMessageJpe jpe);

    @InheritInverseConfiguration(name = "mapToApi")
    SettleMessageJpe mapToJpe(XPSSETTLEMESSAGETYPEType api, @MappingTarget SettleMessageJpe jpe);

}
