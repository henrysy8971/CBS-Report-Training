package com.silverlakesymmetri.cbs.gla.svc.impl;

import com.mysema.query.types.EntityPath;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.context.CbsRuntimeContextManager;
import com.silverlakesymmetri.cbs.commons.context.CbsSessionContext;
import com.silverlakesymmetri.cbs.commons.jpa.util.JaxbDatetimeAdapter;
import com.silverlakesymmetri.cbs.commons.svc.AbstractBusinessService;
import com.silverlakesymmetri.cbs.csd.bdo.sdo.Branch;
import com.silverlakesymmetri.cbs.csd.bdo.sdo.Currency;
import com.silverlakesymmetri.cbs.csd.jpa.mapping.sdo.BranchJpe;
import com.silverlakesymmetri.cbs.csd.jpa.mapping.sdo.CurrencyJpe;
import com.silverlakesymmetri.cbs.gla.bdo.sdo.CashFlowOverallQry;
import com.silverlakesymmetri.cbs.gla.jpa.mapping.sdo.CashFlowOverallQryJpe;
import com.silverlakesymmetri.cbs.gla.jpa.mapping.sdo.QCashFlowOverallQryJpe;
import com.silverlakesymmetri.cbs.gla.jpa.mapping.sdo.id.CashFlowOverallQryPk;
import com.silverlakesymmetri.cbs.gla.jpa.mapping.sdo.util.GlaJpeConstants;
import com.silverlakesymmetri.cbs.gla.svc.CashFlowOverallQryService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


@Service
@Transactional
public class CashFlowOverallQryServiceImpl extends AbstractBusinessService<CashFlowOverallQry, CashFlowOverallQryJpe, CashFlowOverallQryPk> implements CashFlowOverallQryService {

	@Autowired
	private CbsRuntimeContextManager cbsRuntimeContextManager;

	@Override
	protected CashFlowOverallQryPk getIdFromDataObjectInstance(CashFlowOverallQry dataObject) {
		return new CashFlowOverallQryPk(dataObject.getBranch(), dataObject.getCcy(), JaxbDatetimeAdapter.parseDate(dataObject.getValueDate()));
	}

	@Override
	protected EntityPath<CashFlowOverallQryJpe> getEntityPath() {
		return QCashFlowOverallQryJpe.cashFlowOverallQryJpe;
	}
	
	@Override
	public CashFlowOverallQry getByPk(String publicKey, CashFlowOverallQry reference) {
		return super.getByPk(publicKey, reference);
	}
	
	@Override
	public List<CashFlowOverallQry> query(int offset, int resultLimit, String groupBy, String order,
			Map<String, Object> filters) {
		return super.query(offset, resultLimit, groupBy, order, filters);
	}
	
	@Override
	public List<CashFlowOverallQry> find(FindCriteria findCriteria, CbsHeader cbsHeader) {
		return super.find(findCriteria, cbsHeader);
	}
	
	@Override
	public CashFlowOverallQry get(CashFlowOverallQry objectInstanceIdentifier) {
		return super.get(objectInstanceIdentifier);
	}

	@Override
	public List<Branch> findBranches(Map<String, Object> queryParams) {
		long orgId = cbsRuntimeContextManager.getContext(CbsSessionContext.class).getOrgId();
		String branch = (String) queryParams.get("branch");
		int limit = queryParams.get("limit") != null ? Integer.parseInt((String)queryParams.get("limit")) : 10;
		int offset = queryParams.get("offset") != null ? Integer.parseInt((String)queryParams.get("offset")) : 0;
		String nativeQuery = GlaJpeConstants.GLA_CASH_FLOW_OVERALL_BRANCH_LOV_QUERY;

		List<Branch> result = new ArrayList<Branch>();
		final Map<String, Object> parameters = new HashMap<>();

		parameters.put("org_id", orgId);
		if(branch != null && branch != ""){
            nativeQuery = nativeQuery + " AND UPPER(b.branch) like ?branch";
			parameters.put("branch", "%" + branch.toUpperCase() + "%");
		}

        nativeQuery = nativeQuery + " ORDER BY b.branch";
		List<BranchJpe> list = dataService.findWithNativeQuery(nativeQuery, parameters, offset, limit, BranchJpe.class);

		for (BranchJpe o : list) {
			Branch bdo = jaxbSdoHelper.createSdoInstance(Branch.class);
			bdo.setBranch(o.getBranch());
			bdo.setBranchDesc(o.getBranchDesc());
			result.add(bdo);
		}
		return result;
	}

	@Override
	public List<Currency> findCcy(Map<String, Object> queryParams) {
		long orgId = cbsRuntimeContextManager.getContext(CbsSessionContext.class).getOrgId();
		String ccy = (String) queryParams.get("ccy");
		String branch = (String) queryParams.get("branch");
		int limit = queryParams.get("limit") != null ? Integer.parseInt((String)queryParams.get("limit")) : 10;
		int offset = queryParams.get("offset") != null ? Integer.parseInt((String)queryParams.get("offset")) : 0;
		String nativeQuery = GlaJpeConstants.GLA_CASH_FLOW_OVERALL_CURRENCY_LOV_QUERY;

		List<Currency> result = new ArrayList<Currency>();
		final Map<String, Object> parameters = new HashMap<>();
		parameters.put("org_id", orgId);
		if(ccy != null && ccy != ""){
			nativeQuery = nativeQuery + " AND UPPER(c.ccy) like ?ccy";
			parameters.put("ccy", "%" + ccy.toUpperCase() + "%");
		}

		if (branch != null && branch != "") {
			nativeQuery = nativeQuery + " AND c.ccy IN (SELECT cf.ccy from gla_cash_flow_overall_v cf WHERE cf.branch = ?branch GROUP BY cf.ccy)";
			parameters.put("branch", branch.toUpperCase());
		} else {
			nativeQuery = nativeQuery + " AND c.ccy IN (SELECT cf.ccy from gla_cash_flow_overall_v cf GROUP BY cf.ccy)";
		}

		nativeQuery = nativeQuery + " ORDER BY c.ccy";
		List<CurrencyJpe> list = dataService.findWithNativeQuery(nativeQuery, parameters, offset, limit, CurrencyJpe.class);

		for (CurrencyJpe o : list) {
			Currency bdo = jaxbSdoHelper.createSdoInstance(Currency.class);
			bdo.setCcy(o.getCcy());
			bdo.setCcyDesc(o.getCcyDesc());
			result.add(bdo);
		}

		return result;
	}

}
