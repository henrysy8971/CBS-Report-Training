package com.silverlakesymmetri.cbs.xps.svc.ext;

import com.silverlakesymmetri.cbs.csd.bdo.sdo.Contact;

/**
 * Service extension for anything account-related
 * @author Ryan.Vargas
 *
 */
public interface AccountServiceExt {
	
	public static final String ACCOUNT_SERVICE = "ACCOUNT_SERVICE";
	public static final String ACCOUNT_SERVICE_CONTACT = "AccountServiceExt.facilitate";

    public Contact getAccountStmtContact(String acctNo);
    
}
