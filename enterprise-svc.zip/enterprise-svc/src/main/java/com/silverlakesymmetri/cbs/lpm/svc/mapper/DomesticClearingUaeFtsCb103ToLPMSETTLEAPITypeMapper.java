package com.silverlakesymmetri.cbs.lpm.svc.mapper;

import org.mapstruct.Context;
import org.mapstruct.DecoratedWith;
import org.mapstruct.InheritInverseConfiguration;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingTarget;
import org.mapstruct.Mappings;

import com.silverlakesymmetri.cbs.commons.jpa.util.DateTimeHelper;
import com.silverlakesymmetri.cbs.commons.xmlapi.enums.CbsXmlApiOperation;
import com.silverlakesymmetri.cbs.lpm.jpa.mapping.sdo.DomesticClearingUaeFtsCb103Jpe;
import com.silverlakesymmetri.cbs.lpm.xmlapi.LPMSETTLEAPIType;
import com.silverlakesymmetri.cbs.lpm.svc.mapper.decorator.DomesticClearingUaeFtsCb103MapperDecorator;

@Mapper(uses = { DateTimeHelper.class })
@DecoratedWith(DomesticClearingUaeFtsCb103MapperDecorator.class)
public interface DomesticClearingUaeFtsCb103ToLPMSETTLEAPITypeMapper {
	@Mappings({
		@Mapping(expression = "java(oper != null ? oper.getOperation() : null)", target = "OPERATION"),
		@Mapping(target="INTERNALKEY", source="internalKey"),
		@Mapping(target="FORMAT", source="format"),
		@Mapping(target="BANKREFNO", source="bankRefNo"),
		@Mapping(target="ACCOUNTNO", source="accountNo"),
		@Mapping(target="ACCOUNTNAME", source="accountName")
	})
	LPMSETTLEAPIType mapToApi(DomesticClearingUaeFtsCb103Jpe jpe, @Context CbsXmlApiOperation oper);
	
	@InheritInverseConfiguration(name="mapToApi")
	DomesticClearingUaeFtsCb103Jpe mapToJpe(LPMSETTLEAPIType api, @MappingTarget DomesticClearingUaeFtsCb103Jpe jpe);
}
