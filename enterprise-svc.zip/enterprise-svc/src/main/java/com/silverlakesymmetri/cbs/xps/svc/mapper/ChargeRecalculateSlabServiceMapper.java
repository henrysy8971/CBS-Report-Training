package com.silverlakesymmetri.cbs.xps.svc.mapper;

import org.mapstruct.Context;
import org.mapstruct.DecoratedWith;
import org.mapstruct.InheritInverseConfiguration;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingTarget;
import org.mapstruct.Mappings;

import com.silverlakesymmetri.cbs.commons.jpa.util.DateTimeHelper;
import com.silverlakesymmetri.cbs.commons.xmlapi.enums.CbsXmlApiOperation;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.ChargeMasterJpe;
import com.silverlakesymmetri.cbs.xps.svc.mapper.decorator.ChargeRecalculateSlabServiceDecorator;
import com.silverlakesymmetri.cbs.xps.xmlapi.XPSCHARGERECALCULATESLABAPIType;

@Mapper(uses = { DateTimeHelper.class, ChargeEventInfoMapper.class, ChargeInstrumentInfoMapper.class, ChargeServiceMapper.class })
@DecoratedWith(ChargeRecalculateSlabServiceDecorator.class)
public interface ChargeRecalculateSlabServiceMapper {

	@Mappings({
		@Mapping(source="domain", target = "DOMAIN"),
		@Mapping(source="chargeInstrumentInfoStructRec", target = "INSTRUMENT"),
		@Mapping(source="chargeEventInfoStructRec", target = "EVENT"),
		@Mapping(source="chargeSetupRec", target = "SETUP"),
		@Mapping(source="valueDate", target = "VALUEDATE", qualifiedByName = {"DateTimeHelper", "convertDateToCbsXmlApiDate"}),
		@Mapping(source="tranDate", target = "RUNDATE", qualifiedByName = {"DateTimeHelper", "convertDateToCbsXmlApiDate"}),
		@Mapping(source="ccy", target = "MASTERCCY")
	})
	public XPSCHARGERECALCULATESLABAPIType mapToApi(ChargeMasterJpe jpe, @Context CbsXmlApiOperation oper);

	@InheritInverseConfiguration(name = "mapToApi")
	@Mappings({
		@Mapping(source="VALUEDATE", target="valueDate", qualifiedByName = {"DateTimeHelper", "convertCbsApiDateToString"}),
		@Mapping(source="RUNDATE", target="tranDate", qualifiedByName = {"DateTimeHelper", "convertCbsApiDateToString"})
	})
	public ChargeMasterJpe mapToJpe(XPSCHARGERECALCULATESLABAPIType api, @MappingTarget ChargeMasterJpe jpe);
}