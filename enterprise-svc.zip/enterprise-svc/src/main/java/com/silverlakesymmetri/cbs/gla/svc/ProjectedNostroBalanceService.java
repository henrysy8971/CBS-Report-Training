package com.silverlakesymmetri.cbs.gla.svc;

import java.util.Map;

import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation;
import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation.ServiceOperationType;
import com.silverlakesymmetri.cbs.commons.svc.BusinessService;
import com.silverlakesymmetri.cbs.gla.bdo.sdo.ProjectedNostroBalance;
import com.silverlakesymmetri.cbs.gla.jpa.mapping.sdo.ProjectedNostroBalanceJpe;

public interface ProjectedNostroBalanceService extends BusinessService<ProjectedNostroBalance, ProjectedNostroBalanceJpe> {

	public static final String SVC_OP_NAME_PROJECTEDNOSTROBALANCESERVICE_GET = "ProjectedNostroBalanceService.getQueryApi";
	
    @ServiceOperation(name = SVC_OP_NAME_PROJECTEDNOSTROBALANCESERVICE_GET, type = ServiceOperationType.GET, passParamAsMap = true)
    public ProjectedNostroBalance getQueryApi(Map<String, Object> queryParams);
}
