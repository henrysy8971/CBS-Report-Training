package com.silverlakesymmetri.cbs.gla.svc.impl;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.silverlakesymmetri.cbs.commons.jpa.extension.CbsOracle12Platform;
import org.springframework.stereotype.Service;

import com.mysema.query.types.EntityPath;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.svc.AbstractBusinessService;
import com.silverlakesymmetri.cbs.gla.bdo.sdo.GlRelatedPostingQry;
import com.silverlakesymmetri.cbs.gla.jpa.mapping.sdo.GlRelatedPostingQryJpe;
import com.silverlakesymmetri.cbs.gla.jpa.mapping.sdo.QGlRelatedPostingQryJpe;
import com.silverlakesymmetri.cbs.gla.jpa.mapping.sdo.id.GlRelatedPostingQryPk;
import com.silverlakesymmetri.cbs.gla.svc.GlRelatedPostingQryService;

@Service
public class GlRelatedPostingQryServiceImpl extends AbstractBusinessService<GlRelatedPostingQry, GlRelatedPostingQryJpe, GlRelatedPostingQryPk> implements GlRelatedPostingQryService {

	private static final String START_DATE = "startDate";
	private static final String END_DATE = "endDate";
	private static final String DATE_TYPE = "dateType";
	private static final String CCY = "ccy";
	private static final String PROFIT_CENTRE = "profitCentre";
	private static final String GL_CODE = "glCode";
	private static final String BRANCH = "branch";
	private static final String SEQ_NO = "seqNo";
	private static final String CLIENT_NO = "clientNo";
	private static final String POST_DATE = "postDate";
	private static final String VALUE_DATE = "valueDate";
	private static final String DR_VALUE = "DR";

	@Override
	protected GlRelatedPostingQryPk getIdFromDataObjectInstance(GlRelatedPostingQry dataObject) {
		return new GlRelatedPostingQryPk(dataObject.getBranch(), dataObject.getCcy(), dataObject.getClientNo(), dataObject.getGlCode(), dataObject.getSeqNo(), dataObject.getProfitCentre(),  dataObject.getRowReferenceNo());
	}

	@Override
	protected EntityPath<GlRelatedPostingQryJpe> getEntityPath() {
		return QGlRelatedPostingQryJpe.glRelatedPostingQryJpe;
	}
	
	@Override
	public GlRelatedPostingQry getByPk(String publicKey, GlRelatedPostingQry dataObject) {
		return super.getByPk(publicKey, dataObject);
	}

	@Override
	public List<GlRelatedPostingQry> query(int offset, int resultLimit, String groupBy, String order,
			Map<String, Object> filters) {

		String dateTypeOpt = "valueDate|postDate";
		boolean hasRange = false;

		String branch = (String) filters.get(BRANCH);
        String ccy = (String) filters.get(CCY);
        String clientNo = (String) filters.get(CLIENT_NO);
        String glCode = (String) filters.get(GL_CODE);
        Integer seqNo = filters.get(SEQ_NO) == null ? null : Integer.parseInt((String) filters.get(SEQ_NO));
        String profitCentre = (String) filters.get(PROFIT_CENTRE);
        String dateType = (String) filters.get(DATE_TYPE);
        Date startDate = filters.get(START_DATE)==null? null : this.dateTimeHelper.getDate((String) filters.get(START_DATE));
        Date endDate = filters.get(END_DATE)==null? null : this.dateTimeHelper.getDate((String) filters.get(END_DATE));

		if (dateType != null && dateTypeOpt.contains(dateType)) {
			if (startDate != null && endDate != null) {
				hasRange = true;
			}
		}

		try {
			CbsOracle12Platform.setUseNewOraclePaging(true);
			if(hasRange){
				return getValuePostDate(branch, ccy, clientNo,
						glCode, seqNo, profitCentre, startDate, endDate, dateType);
			}else{
				return super.query(offset, resultLimit, groupBy, order, filters);
			}
		} finally {
			CbsOracle12Platform.setUseNewOraclePaging(false);
		}
	}

	@Override
	public List<GlRelatedPostingQry> find(FindCriteria fc, CbsHeader cbsHeader) {
		try {
			CbsOracle12Platform.setUseNewOraclePaging(true);
			return super.find(fc, cbsHeader);
		} finally {
			CbsOracle12Platform.setUseNewOraclePaging(false);
		}
	}
	
	@Override
	public GlRelatedPostingQry get(GlRelatedPostingQry objectInstanceIdentifier) {
		return super.get(objectInstanceIdentifier);
	}


	private List<GlRelatedPostingQry> getValuePostDate(String branch, String ccy, String clientNo,
													   String glCode, Integer seqNo, String profitCentre, Date startDate, Date endDate, String dateType) {

		String sqlQuery = "SELECT grp FROM GlRelatedPostingQryJpe grp WHERE ";
		Map<String, Object> params = new HashMap<>();

		if(startDate!=null && endDate!=null && VALUE_DATE.matches(dateType)){
			sqlQuery = sqlQuery + "grp.valueDate BETWEEN :startDate AND :endDate ";
			params.put(START_DATE, startDate);
			params.put(END_DATE, endDate);
		}
		if(startDate!=null && endDate!=null && POST_DATE.matches(dateType)){
			sqlQuery = sqlQuery + "grp.postDate BETWEEN :startDate AND :endDate ";
			params.put(START_DATE, startDate);
			params.put(END_DATE, endDate);
		}
		if(profitCentre!=null){
			sqlQuery = sqlQuery + "AND grp.profitCentre = :profitCentre ";
			params.put(PROFIT_CENTRE, profitCentre);
		}
		if(ccy!=null){
			sqlQuery = sqlQuery + "AND grp.ccy = :ccy ";
			params.put(CCY, ccy);
		}
		if(glCode!=null){
			sqlQuery = sqlQuery + "AND grp.glCode = :glCode ";
			params.put(GL_CODE, glCode);
		}
		if(branch!=null){
			sqlQuery = sqlQuery + "AND grp.branch = :branch ";
			params.put(BRANCH, branch);
		}
		if(seqNo!=null){
			sqlQuery = sqlQuery + "AND grp.seqNo = :seqNo ";
			params.put(SEQ_NO, seqNo);
		}
		if(clientNo!=null){
			sqlQuery = sqlQuery + "AND grp.clientNo = :clientNo";
			params.put(CLIENT_NO, clientNo);
		}

		List<GlRelatedPostingQry> retList = new ArrayList<>();
		List<GlRelatedPostingQryJpe> jpeList = this.dataService.findWithQuery(sqlQuery, GlRelatedPostingQryJpe.class, params, null);
		if(jpeList != null){
			for(GlRelatedPostingQryJpe jpe: jpeList){
				GlRelatedPostingQry bdo = jaxbSdoHelper.wrap(jpe, GlRelatedPostingQry.class);
				if (DR_VALUE.matches(bdo.getAmountDrCr())){
					Double amt = bdo.getAmount() * -1;
					bdo.setAmount(amt);
				}
				retList.add(bdo);
			}
		}
		return retList;
	}

}
