package com.silverlakesymmetri.cbs.xps.svc.impl;

import java.io.StringReader;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.inject.Inject;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mysema.query.types.EntityPath;
import com.silverlakesymmetri.cbs.commons.jpa.util.BdoHelper;
import com.silverlakesymmetri.cbs.commons.restlet.JsonConvertionManager;
import com.silverlakesymmetri.cbs.commons.svc.AbstractXmlApiBusinessService;
import com.silverlakesymmetri.cbs.commons.xmlapi.enums.CbsXmlApiOperation;
import com.silverlakesymmetri.cbs.xps.bdo.sdo.ChargeDetails;
import com.silverlakesymmetri.cbs.xps.bdo.sdo.ChargeMaster;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.ChargeDetailsJpe;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.ChargeMasterJpe;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.QChargeMasterJpe;
import com.silverlakesymmetri.cbs.xps.listener.ChargeNoResolver;
import com.silverlakesymmetri.cbs.xps.svc.ChargeDefaultsService;
import com.silverlakesymmetri.cbs.xps.svc.mapper.ChargeDefaultsServiceMapper;
import com.silverlakesymmetri.cbs.xps.xmlapi.XPSCHARGEGETPRODDEFAULTDETAILSAPIType;

@Service
public class ChargeDefaultsServiceImpl extends AbstractXmlApiBusinessService<ChargeMaster, ChargeMasterJpe, Long, XPSCHARGEGETPRODDEFAULTDETAILSAPIType, XPSCHARGEGETPRODDEFAULTDETAILSAPIType> implements ChargeDefaultsService {

    @Autowired
    private ChargeDefaultsServiceMapper mapper;
	
    @Inject
    protected JsonConvertionManager jsonConversionMngr;

	@Inject
    private BdoHelper bdoHelper;

    public ChargeMaster preCreateValidation(ChargeMaster dataObject) {
    	return super.preCreateValidation(dataObject);
    }

    @Override
    public ChargeMaster create(ChargeMaster dataObject) {
        return super.create(dataObject);
    }

    @Override
    protected XPSCHARGEGETPRODDEFAULTDETAILSAPIType transformBdoToXmlApiRqCreate(ChargeMaster dataObject) {
        return transformBdoToXmlApiType(dataObject, CbsXmlApiOperation.INSERT);
    }

    @Override
    protected XPSCHARGEGETPRODDEFAULTDETAILSAPIType transformBdoToXmlApiRqUpdate(ChargeMaster dataObject) {
        return null;
    }

    @Override
    protected XPSCHARGEGETPRODDEFAULTDETAILSAPIType transformBdoToXmlApiRqDelete(ChargeMaster dataObject) {
        return null;
    }

    private XPSCHARGEGETPRODDEFAULTDETAILSAPIType transformBdoToXmlApiType(ChargeMaster dataObject, CbsXmlApiOperation oper) {
    	ChargeMasterJpe jpe = jaxbSdoHelper.unwrap(dataObject);
    	XPSCHARGEGETPRODDEFAULTDETAILSAPIType api = mapper.mapToApi(jpe, oper);
    	api.setOPERATION("QUERY");
        return api;
    }

    @Override
    protected Map<String, String> executeStoredProcedure(String xmlApiReq, String xmlHeaderIn) {
		String processAuthorizeOperation = "XPS_CHARGE_GET_PROD_DEFAULT_DETAILS_API OPERATION=\"QUERY\"";
		String xmlApiReqProcess = xmlApiReq.replaceAll(
				"XPS_CHARGE_GET_PROD_DEFAULT_DETAILS_API=\"(INSERT|UPDATE|DELETE|DO_PROCESS)\"", processAuthorizeOperation);
		//String xmlApiReqProcess = xmlApiReq.replaceAll("XPS_CHARGE_CALCULATE_API OPERATION=\"INSERT\"", "XPS_CHARGE_CALCULATE_API OPERATION=\"PROCESS_GENERIC\"");
        return super.executeStoredProcedure(xmlApiReqProcess, xmlHeaderIn);
    }

    @Override
	protected <A> A convertXmlStringToObject(String xmlString, Class<A> responseClass) throws JAXBException {
		//if (xmlString == null) {
        if (StringUtils.isEmpty(xmlString)) {
			return null;
		}
		JAXBContext jaxbContext = getJAXBContextFromPool(responseClass);
		Unmarshaller u = jaxbContext.createUnmarshaller();
		String trimmedXmlString = xmlString.replaceAll("<[a-zA-Z0-9_.-]*/>", "");
		StringReader reader = new StringReader(trimmedXmlString);
		return responseClass.cast(u.unmarshal(reader));
	}

    @Override
    protected ChargeMaster processXmlApiRs(ChargeMaster dataObject, XPSCHARGEGETPRODDEFAULTDETAILSAPIType xmlApiRs) {
    	ChargeMasterJpe jpe = jaxbSdoHelper.unwrap(dataObject);
    	if (xmlApiRs != null) {
            jpe = mapper.mapToJpe(xmlApiRs, jpe);
        }
        return jaxbSdoHelper.wrap(jpe);
    }

    @Override
    protected List<ChargeMaster> processXmlApiListRs(ChargeMaster dataObject, XPSCHARGEGETPRODDEFAULTDETAILSAPIType xmlApiRs) {
        return null;
    }

    @Override
    protected Class<XPSCHARGEGETPRODDEFAULTDETAILSAPIType> getXmlApiResponseClass() {
        return XPSCHARGEGETPRODDEFAULTDETAILSAPIType.class;
    }

    @Override
    protected Long getIdFromDataObjectInstance(ChargeMaster dataObject) {
        return dataObject.getInternalKey();
    }

    @Override
    protected EntityPath<ChargeMasterJpe> getEntityPath() {
        return QChargeMasterJpe.chargeMasterJpe;
    }

	@Override
	public List<ChargeDetails> getChargeProdDefaults(ChargeMaster master) {
		List<ChargeDetails> result = new ArrayList<ChargeDetails>();
		String masterCcy = master.getCcy();
		ChargeMaster response = this.createDataObject(master);

		if (response == null) {
		    return result;
        }

		ChargeMasterJpe jpe = jaxbSdoHelper.unwrap(response);
		if(jpe != null && jpe.getChargeDetailsList() != null && jpe.getChargeDetailsList().size() > 0){
			for(ChargeDetailsJpe details : jpe.getChargeDetailsList()){
				ChargeDetails bdo = jaxbSdoHelper.wrap(details);
				bdoHelper.callEntityListenerMethod(bdo, new Class<?>[] { ChargeNoResolver.class }, "postBuild");	
				if(bdo.getChargeFixedStructRec() != null){
					bdo.getChargeFixedStructRec().setCcy(masterCcy);
				} else if(bdo.getChargeRatedStructRec() != null){
					bdo.getChargeRatedStructRec().setCcy(masterCcy);
				} else if(bdo.getChargeInterestStructRec() != null){
					bdo.getChargeInterestStructRec().setCcy(masterCcy);
				} else if(bdo.getChargePeriodicStructRec() != null){
					bdo.getChargePeriodicStructRec().setCcy(masterCcy);
				} else if(bdo.getChargeTwoTierStructRec() != null){
					bdo.getChargeTwoTierStructRec().setCcy(masterCcy);
				}
				result.add(bdo);
			}
		}
		
		return result;
	}
	
	@Override
	protected ChargeMaster preCreateObject(ChargeMaster dataObject) {
		return dataObject;
	}
    

}
