package com.silverlakesymmetri.cbs.xps.svc;

import java.util.List;
import java.util.Map;

import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation;
import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation.ServiceOperationType;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.svc.BusinessService;
import com.silverlakesymmetri.cbs.xps.bdo.sdo.GftTransfersTranTypeQry;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.GftTransfersTranTypeQryJpe;

public interface GftTransfersTranTypeQryService extends BusinessService<GftTransfersTranTypeQry, GftTransfersTranTypeQryJpe> {

	public static final String XPS_OP_NAME_GFTTRANSFERSTRANTYPEQRYSERVICE_GET = "gftTransfersTranTypeQryService.get";
    public static final String XPS_OP_NAME_GFTTRANSFERSTRANTYPEQRYSERVICE_QUERY = "gftTransfersTranTypeQryService.query";
    public static final String XPS_OP_NAME_GFTTRANSFERSTRANTYPEQRYSERVICE_FIND = "gftTransfersTranTypeQryService.find";
    
    @ServiceOperation(name = XPS_OP_NAME_GFTTRANSFERSTRANTYPEQRYSERVICE_GET, type = ServiceOperationType.GET)
    public GftTransfersTranTypeQry getByPk(String publicKey, GftTransfersTranTypeQry reference);

    @ServiceOperation(name = XPS_OP_NAME_GFTTRANSFERSTRANTYPEQRYSERVICE_QUERY)
    public List<GftTransfersTranTypeQry> query(int offset, int resultLimit, String groupBy, String order, Map<String, Object> filters);
    
    @ServiceOperation(name = XPS_OP_NAME_GFTTRANSFERSTRANTYPEQRYSERVICE_FIND)
    public List<GftTransfersTranTypeQry> find(FindCriteria findCriteria, CbsHeader cbsHeader);
}
