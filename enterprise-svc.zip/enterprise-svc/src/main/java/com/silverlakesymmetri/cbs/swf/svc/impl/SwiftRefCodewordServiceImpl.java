package com.silverlakesymmetri.cbs.swf.svc.impl;

import com.mysema.query.types.EntityPath;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.svc.AbstractBusinessService;
import com.silverlakesymmetri.cbs.commons.svc.BusinessObjectValidationCapable;
import com.silverlakesymmetri.cbs.swf.bdo.sdo.SwiftRefCodeword;
import com.silverlakesymmetri.cbs.swf.jpa.mapping.sdo.SwiftRefCodewordJpe;
import com.silverlakesymmetri.cbs.swf.jpa.mapping.sdo.id.SwiftRefCodewordPk;
import com.silverlakesymmetri.cbs.swf.jpa.mapping.sdo.QSwiftRefCodewordJpe;
import com.silverlakesymmetri.cbs.swf.svc.SwiftRefCodewordService;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Map;

@Service
@Transactional
public class SwiftRefCodewordServiceImpl extends AbstractBusinessService<SwiftRefCodeword, SwiftRefCodewordJpe, SwiftRefCodewordPk>
        implements SwiftRefCodewordService, BusinessObjectValidationCapable<SwiftRefCodeword> {

    @Override
    protected SwiftRefCodewordPk getIdFromDataObjectInstance(SwiftRefCodeword dataObject) {
    	SwiftRefCodewordPk key = new SwiftRefCodewordPk(dataObject.getMessageType(), dataObject.getTag(), dataObject.getCodeword());
        return key;
    }

    @Override
    protected EntityPath<SwiftRefCodewordJpe> getEntityPath() {
        return QSwiftRefCodewordJpe.swiftRefCodewordJpe;
    }

    @Override
    public SwiftRefCodeword get(SwiftRefCodeword objectInstanceIdentifier) {
        return super.get(objectInstanceIdentifier);
    }

    @Override
    public List<SwiftRefCodeword> query(int offset, int resultLimit, String groupBy, String order,
                                    Map<String, Object> filters) {
        return super.query(offset, resultLimit, groupBy, order, filters);
    }

    @Override
    public List<SwiftRefCodeword> find(FindCriteria findCriteria, CbsHeader cbsHeader) {
        return super.find(findCriteria, cbsHeader);
    }

    @Override
    public SwiftRefCodeword getByPk(String publicKey, SwiftRefCodeword reference) {
        return super.getByPk(publicKey, reference);
    }

}
