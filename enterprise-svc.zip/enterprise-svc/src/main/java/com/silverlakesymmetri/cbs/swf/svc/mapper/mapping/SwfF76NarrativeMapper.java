package com.silverlakesymmetri.cbs.swf.svc.mapper.mapping;

import org.mapstruct.InheritInverseConfiguration;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Mappings;

import com.silverlakesymmetri.cbs.swf.jpa.mapping.sdo.SwfF76NarrativeJpe;
import com.silverlakesymmetri.cbs.swf.xmlapi.SWFF76NARRATIVETYPEType;

@Mapper
public interface SwfF76NarrativeMapper {
	
	@Mappings({
		@Mapping(target="INDEX", source="index"),
		@Mapping(target="ANSWERNO", source="code"),
		@Mapping(target="SUPPLEMENT1", source="supplement1"),
		@Mapping(target="SUPPLEMENT2", source="supplement2")
	})
	SWFF76NARRATIVETYPEType mapToApi(SwfF76NarrativeJpe jpe);
	
	@InheritInverseConfiguration(name = "mapToApi")
	SwfF76NarrativeJpe mapToJpe(SWFF76NARRATIVETYPEType api);

}