package com.silverlakesymmetri.cbs.xps.svc;

import com.mysema.query.types.EntityPath;
import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation;
import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation.ServiceOperationType;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.svc.BusinessService;
import com.silverlakesymmetri.cbs.xps.bdo.sdo.SapWorkUnitMap;
import com.silverlakesymmetri.cbs.xps.bdo.sdo.DocumentTrackingDtl;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.DocumentInventoryHdrJpe;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.QDocumentInventoryHdrJpe;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.SapWorkUnitMapJpe;

import java.util.List;
import java.util.Map;

public interface SapWorkUnitMapService extends BusinessService<SapWorkUnitMap, SapWorkUnitMapJpe> {

    public static final String SVC_OP_NAME_SAPWORKUNITMAPSERVICE_GET = "SapWorkUnitMapService.get";
    public static final String SVC_OP_NAME_SAPWORKUNITMAPSERVICE_QUERY = "SapWorkUnitMapService.query";
    public static final String SVC_OP_NAME_SAPWORKUNITMAPSERVICE_CREATE = "SapWorkUnitMapService.create";
    public static final String SVC_OP_NAME_SAPWORKUNITMAPSERVICE_UPDATE = "SapWorkUnitMapService.update";
    public static final String SVC_OP_NAME_SAPWORKUNITMAPSERVICE_DELETE = "SapWorkUnitMapService.delete";
    public static final String SVC_OP_NAME_SAPWORKUNITMAPSERVICE_FIND = "SapWorkUnitMapService.find";

    @ServiceOperation(name = SVC_OP_NAME_SAPWORKUNITMAPSERVICE_GET, type = ServiceOperationType.GET)
    public SapWorkUnitMap getByPk(String publicKey, SapWorkUnitMap reference);

    @ServiceOperation(name = SVC_OP_NAME_SAPWORKUNITMAPSERVICE_CREATE)
    public SapWorkUnitMap create(SapWorkUnitMap dataObject);

    @ServiceOperation(name = SVC_OP_NAME_SAPWORKUNITMAPSERVICE_UPDATE)
    public SapWorkUnitMap update(SapWorkUnitMap dataObject);

    @ServiceOperation(name = SVC_OP_NAME_SAPWORKUNITMAPSERVICE_DELETE)
    public boolean delete(SapWorkUnitMap dataObject);

    @ServiceOperation(name = SVC_OP_NAME_SAPWORKUNITMAPSERVICE_QUERY)
    public List<SapWorkUnitMap> query(int offset, int resultLimit, String groupBy, String order, Map<String, Object> filters);

    @ServiceOperation(name = SVC_OP_NAME_SAPWORKUNITMAPSERVICE_FIND)
    public List<SapWorkUnitMap> find(FindCriteria findCriteria, CbsHeader cbsHeader);

}
