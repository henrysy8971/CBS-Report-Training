package com.silverlakesymmetri.cbs.xps.svc.mapper;

import org.mapstruct.Context;
import org.mapstruct.DecoratedWith;
import org.mapstruct.InheritInverseConfiguration;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingTarget;
import org.mapstruct.Mappings;

import com.silverlakesymmetri.cbs.commons.jpa.util.DateTimeHelper;
import com.silverlakesymmetri.cbs.commons.xmlapi.enums.CbsXmlApiOperation;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.QuickLoanJpe;
import com.silverlakesymmetri.cbs.xps.svc.mapper.decorator.QuickLoanServiceDecorator;
import com.silverlakesymmetri.cbs.xps.xmlapi.XPSLNDQLOANAPIType;

@Mapper(uses={ DateTimeHelper.class})
@DecoratedWith(QuickLoanServiceDecorator.class)
public interface QuickLoanServiceMapper {

	@Mappings({
		@Mapping(expression = "java(oper != null ? oper.getOperation() : null)", target="OPERATION"),
		@Mapping(source="loanNo", target= "LOANNO"),
		@Mapping(source="loanKey", target= "LOANKEY"),
		@Mapping(source="loanType", target= "LOANTYPE"),
		@Mapping(source="loanSubType", target= "LOANSUBTYPE"),
		@Mapping(source="bookBranch", target= "BOOKBRANCH"),
		@Mapping(source="loanManagerNo", target= "LOANMANAGER"),
		@Mapping(source="borrower", target= "BORROWER"),
		@Mapping(source="acctExec", target= "ACCTEXEC"),
		@Mapping(source="profitCentre", target= "PROFITCENTRE"),
		@Mapping(source="startDate", target= "STARTDATE", qualifiedByName = {"DateTimeHelper", "convertDateToCbsXmlApiDate"}),
		@Mapping(source="periodNo", target= "PERIODNO"),
		@Mapping(source="periodType", target= "PERIODTYPE"),
		@Mapping(source="dateApplied", target= "DATEAPPLIED", qualifiedByName = {"DateTimeHelper", "convertDateToCbsXmlApiDate"}),
		@Mapping(source="signedDate", target= "SIGNEDDATE", qualifiedByName = {"DateTimeHelper", "convertDateToCbsXmlApiDate"}),
		@Mapping(source="matureDate", target= "MATUREDATE", qualifiedByName = {"DateTimeHelper", "convertDateToCbsXmlApiDate"}),
		@Mapping(source="status", target= "STATUS"),
		@Mapping(source="ccy", target= "CCY"),
		@Mapping(source="origLoanAmt", target= "ORIGLOANAMT"),
		@Mapping(source="olLoanAmt", target= "OLLOANAMT"),
		@Mapping(source="intBasis", target= "INTBASIS"),
		@Mapping(source="spreadRate", target= "SPREADRATE"),
		@Mapping(source="intRate", target= "INTRATE"),
		@Mapping(source="priRepayType", target= "PRIREPAYTYPE"),
		@Mapping(source="priRepayFreq", target= "PRIREPAYFREQ"),
		@Mapping(source="firstRepaymentDate", target= "FIRSTREPAYMENTDATE", qualifiedByName = {"DateTimeHelper", "convertDateToCbsXmlApiDate"}),
		@Mapping(source="firstRepaymentDay", target= "FIRSTREPAYMENTDAY"),
		@Mapping(source="intRepayFreq", target= "INTREPAYFREQ"),
		@Mapping(source="nextIntRepDate", target= "NEXTINTREPDATE", qualifiedByName = {"DateTimeHelper", "convertDateToCbsXmlApiDate"}),
		@Mapping(source="intRepayDay", target= "INTREPAYDAY"),
		@Mapping(source="purpose", target= "PURPOSE"),
		@Mapping(source="narrative", target= "NARRATIVE"),
		@Mapping(source="channel", target= "CHANNEL"),
		@Mapping(source="channelSource", target= "CHANNELSOURCE"),
		@Mapping(source="userId", target= "USERID"),
		@Mapping(source="wsId", target= "WSID"),
	})
	public XPSLNDQLOANAPIType mapToApi(QuickLoanJpe jpe, @Context CbsXmlApiOperation oper);

	@InheritInverseConfiguration(name = "mapToApi")
	@Mappings({
		@Mapping(source="DATEAPPLIED", target="dateApplied", qualifiedByName = {"DateTimeHelper", "convertCbsApiDateToString"}),
		@Mapping(source="SIGNEDDATE", target="signedDate", qualifiedByName = {"DateTimeHelper", "convertCbsApiDateToString"}),
		@Mapping(source="STARTDATE", target="startDate", qualifiedByName = {"DateTimeHelper", "convertCbsApiDateToString"}),
		@Mapping(source="MATUREDATE", target="matureDate", qualifiedByName = {"DateTimeHelper", "convertCbsApiDateToString"}),
		@Mapping(source="NEXTINTREPDATE", target="nextIntRepDate", qualifiedByName = {"DateTimeHelper", "convertCbsApiDateToString"}),
		@Mapping(source="FIRSTREPAYMENTDATE", target="firstRepaymentDate", qualifiedByName = {"DateTimeHelper", "convertCbsApiDateToString"})
	})
	public QuickLoanJpe mapToJpe(XPSLNDQLOANAPIType api, @MappingTarget QuickLoanJpe jpe);
}