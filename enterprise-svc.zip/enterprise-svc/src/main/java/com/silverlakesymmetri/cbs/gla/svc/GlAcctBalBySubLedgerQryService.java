package com.silverlakesymmetri.cbs.gla.svc;

import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation;
import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation.ServiceOperationType;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.svc.BusinessService;
import com.silverlakesymmetri.cbs.gla.bdo.sdo.GlAcctBalBySubledgerQry;
import com.silverlakesymmetri.cbs.gla.jpa.mapping.sdo.GlAcctBalBySubledgerQryJpe;

import java.util.List;
import java.util.Map;

public interface GlAcctBalBySubLedgerQryService extends BusinessService<GlAcctBalBySubledgerQry, GlAcctBalBySubledgerQryJpe> {

	public static final String SVC_OP_NAME_GLACCTBALBYSUBLEDGERSERVICE_GET = "GlAcctBalBySubledgerQryService.get";
	public static final String SVC_OP_NAME_GLACCTBALBYSUBLEDGERSERVICE_FIND = "GlAcctBalBySubledgerQryService.find";
	public static final String SVC_OP_NAME_GLACCTBALBYSUBLEDGERSERVICE_QUERY = "GlAcctBalBySubledgerQryService.query";
	
	@ServiceOperation(name = SVC_OP_NAME_GLACCTBALBYSUBLEDGERSERVICE_GET, type = ServiceOperationType.GET)
    public GlAcctBalBySubledgerQry getByPk(String publicKey, GlAcctBalBySubledgerQry reference);

    @ServiceOperation(name = SVC_OP_NAME_GLACCTBALBYSUBLEDGERSERVICE_FIND)
    public List<GlAcctBalBySubledgerQry> find(FindCriteria findCriteria, CbsHeader cbsHeader);
    
    @ServiceOperation(name = SVC_OP_NAME_GLACCTBALBYSUBLEDGERSERVICE_QUERY)
    public List<GlAcctBalBySubledgerQry> query(int offset, int resultLimit, String groupBy, String order, Map<String, Object> filters);
}
