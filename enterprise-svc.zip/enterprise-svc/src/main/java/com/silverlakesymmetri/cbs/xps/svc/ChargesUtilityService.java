package com.silverlakesymmetri.cbs.xps.svc;

import java.util.Date;
import java.util.List;
import java.util.Map;

import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation;
import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation.ServiceOperationType;
import com.silverlakesymmetri.cbs.commons.bdo.CbsBusinessDataObject;
import com.silverlakesymmetri.cbs.commons.ext.ServiceExtensionPoint;
import com.silverlakesymmetri.cbs.core.util.CcyConversionObject;
import com.silverlakesymmetri.cbs.pim.bdo.sdo.MessageKey;
import com.silverlakesymmetri.cbs.xps.bdo.sdo.ChargeDetails;
import com.silverlakesymmetri.cbs.xps.bdo.sdo.ChargeEventInfo;
import com.silverlakesymmetri.cbs.xps.bdo.sdo.ChargeEventSeqNoQry;
import com.silverlakesymmetri.cbs.xps.bdo.sdo.ChargeEventTypeQry;
import com.silverlakesymmetri.cbs.xps.bdo.sdo.ChargeInstrumentInfo;
import com.silverlakesymmetri.cbs.xps.bdo.sdo.ChargeMaster;
import com.silverlakesymmetri.cbs.xps.bdo.sdo.ChargeNoQry;
import com.silverlakesymmetri.cbs.xps.bdo.sdo.MsgGrpDefQry;
import com.silverlakesymmetri.cbs.xps.bdo.sdo.MsgGrpTypeQry;
import com.silverlakesymmetri.cbs.xps.svc.ext.BgtChargesServiceExt;
import com.silverlakesymmetri.cbs.xps.svc.ext.TfnChargesServiceExt;

public interface ChargesUtilityService {
	public static final String SVC_OP_NAME_CHARGESUTILLITYSERVICE_GET_EVENT_TYPE = "ChargesUtilityService.getEventType";
	public static final String SVC_OP_NAME_CHARGESUTILLITYSERVICE_GET_EVENT_SEQ = "ChargesUtilityService.getEventSeq";
	public static final String SVC_OP_NAME_CHARGESUTILLITYSERVICE_GET_CHARGE_NO = "ChargesUtilityService.getChargeNo";
	public static final String SVC_OP_NAME_CHARGESUTILLITYSERVICE_GET_MSG_GRP_DEF_QRY_LIST = "ChargesUtilityService.getMsgGrpDefQryList";
	public static final String SVC_OP_NAME_CHARGESUTILLITYSERVICE_GET_MSG_GRP_TYPE_QRY_LIST = "ChargesUtilityService.getMsgGrpTypeQryList";
	public static final String SVC_OP_NAME_CHARGESUTILLITYSERVICE_GET_CHARGE_INSTRUMENT_INFO = "ChargesUtilityService.getChargeInstrumentInfo";
	public static final String SVC_OP_NAME_CHARGESUTILLITYSERVICE_GET_CHARGE_EVENT_INFO = "ChargesUtilityService.getChargeEventInfo";
	public static final String SVC_OP_NAME_CHARGESUTILLITYSERVICE_COMPUTE_DEFAULT_CHARGES = "ChargesUtilityService.computeDefaultCharges";
	public static final String SVC_OP_NAME_CHARGESUTILLITYSERVICE_CALCULATE = "ChargesUtilityService.calculate";
	public static final String SVC_OP_NAME_CHARGESUTILLITYSERVICE_RECALCULATE = "ChargesUtilityService.recalculate";
	public static final String SVC_OP_NAME_CHARGESUTILLITYSERVICE_PERIODICRECALCULATE = "ChargesUtilityService.periodicRecalculate";
	public static final String SVC_OP_NAME_CHARGESUTILLITYSERVICE_CONVERT_BASE_AMOUNT = "ChargesUtilityService.convertBaseAmount";
	public static final String SVC_OP_NAME_CHARGESUTILLITYSERVICE_CONVERT_AMOUNT = "ChargesUtilityService.convertAmount";
	public static final String SVC_OP_NAME_CHARGESUTILLITYSERVICE_CALC_EQUIV_AMOUNT = "ChargesUtilityService.calculateEquivAmount";
	public static final String SVC_OP_NAME_CHARGESUTILLITYSERVICE_CALC_EQUIV_AMOUNT_REVERSE = "ChargesUtilityService.calculateEquivAmountReverse";
	public static final String SVC_OP_NAME_CHARGESUTILLITYSERVICE_GET_INT_BASIS_RATE = "ChargesUtilityService.getIntBasisRate";
	public static final String SVC_OP_NAME_CHARGESUTILLITYSERVICE_RECALCULATE_RATED_SLABS = "ChargesUtilityService.recalculateRatedSlabs";
	public static final String SVC_OP_NAME_CHARGESUTILLITYSERVICE_GET_NEXT_RECUR_DATE = "ChargesUtilityService.getNextRecurDate";

	public static final String TRADE_FINANCE_MODULE = "TFN";
	public static final String BANK_GUARANTEE_MODULE = "BGT";
	
	@ServiceOperation(name = SVC_OP_NAME_CHARGESUTILLITYSERVICE_GET_EVENT_TYPE, type = ServiceOperationType.READ, passParamAsMap = true)
	public List<ChargeEventTypeQry> getEventType(Map<String, Object> queryParams);

	@ServiceOperation(name = SVC_OP_NAME_CHARGESUTILLITYSERVICE_GET_EVENT_SEQ, type = ServiceOperationType.READ, passParamAsMap = true)
	public List<ChargeEventSeqNoQry> getEventSeq(Map<String, Object> queryParams);
	
	@ServiceOperation(name = SVC_OP_NAME_CHARGESUTILLITYSERVICE_GET_CHARGE_NO, type = ServiceOperationType.READ, passParamAsMap = true)
	public List<ChargeNoQry> getChargeNo(Map<String, Object> queryParams);
	
	@ServiceOperation(name = SVC_OP_NAME_CHARGESUTILLITYSERVICE_GET_MSG_GRP_DEF_QRY_LIST, type = ServiceOperationType.READ)
    public List<MsgGrpDefQry> getMsgGrpDefQryList(String domain, String msgGrp, String eventType, String prodType);
	
	@ServiceOperation(name = SVC_OP_NAME_CHARGESUTILLITYSERVICE_GET_MSG_GRP_TYPE_QRY_LIST, type = ServiceOperationType.READ)
    public List<MsgGrpTypeQry> getMsgGrpTypeQryList(String domain, String eventType, String prodType);
	
	@ServiceOperation(name = SVC_OP_NAME_CHARGESUTILLITYSERVICE_GET_CHARGE_INSTRUMENT_INFO, passParamAsMap = true)
    public ChargeInstrumentInfo getChargeInstrumentInfo(Map<String, Object> params);
	
	@ServiceOperation(name = SVC_OP_NAME_CHARGESUTILLITYSERVICE_GET_CHARGE_EVENT_INFO, passParamAsMap = true)
    public ChargeEventInfo getChargeEventInfo(Map<String, Object> params);
	
	@ServiceOperation(name = SVC_OP_NAME_CHARGESUTILLITYSERVICE_COMPUTE_DEFAULT_CHARGES, type = ServiceOperationType.EXECUTE)
    public List<ChargeDetails> computeDefaultCharges(ChargeMaster chargeMaster);
	
	@ServiceOperation(name = SVC_OP_NAME_CHARGESUTILLITYSERVICE_CALCULATE, type = ServiceOperationType.EXECUTE, passParamAsMap = true)
    public ChargeDetails calculate(Map<String, Object> params);
	
	@ServiceOperation(name = SVC_OP_NAME_CHARGESUTILLITYSERVICE_RECALCULATE, type = ServiceOperationType.EXECUTE, passParamAsMap = true)
    public ChargeDetails recalculate(Map<String, Object> params);
	
	@ServiceOperation(name = SVC_OP_NAME_CHARGESUTILLITYSERVICE_PERIODICRECALCULATE, type = ServiceOperationType.EXECUTE, passParamAsMap = true)
	public ChargeDetails periodicRecalculate(Map<String, Object> params);
	
	@ServiceOperation(name = SVC_OP_NAME_CHARGESUTILLITYSERVICE_CONVERT_AMOUNT, type = ServiceOperationType.EXECUTE)
    public CcyConversionObject convertAmount(CcyConversionObject conversionObj);
	
	@ServiceOperation(name = SVC_OP_NAME_CHARGESUTILLITYSERVICE_CONVERT_BASE_AMOUNT, type = ServiceOperationType.EXECUTE)
    public CcyConversionObject convertBaseAmount(CcyConversionObject conversionObj);
	
	@ServiceOperation(name = SVC_OP_NAME_CHARGESUTILLITYSERVICE_CALC_EQUIV_AMOUNT, type = ServiceOperationType.EXECUTE)
    public Double calculateEquivAmount(Double amount, Double exchRate, String exchQuote, String ccy);
	
	@ServiceOperation(name = SVC_OP_NAME_CHARGESUTILLITYSERVICE_CALC_EQUIV_AMOUNT_REVERSE, type = ServiceOperationType.EXECUTE)
    public Double calculateEquivAmountReverse(Double amount, Double exchRate, String exchQuote, String ccy);
	
	@ServiceOperation(name = SVC_OP_NAME_CHARGESUTILLITYSERVICE_GET_INT_BASIS_RATE, type = ServiceOperationType.EXECUTE)
    public Double getIntBasisRate(String intBasis, String basisCcy, Date valueDate);
	
	@ServiceOperation(name = SVC_OP_NAME_CHARGESUTILLITYSERVICE_RECALCULATE_RATED_SLABS, type = ServiceOperationType.EXECUTE, passParamAsMap = true)
    public ChargeDetails recalculateRatedSlabs(Map<String, Object> params);
	
	@ServiceOperation(name = SVC_OP_NAME_CHARGESUTILLITYSERVICE_GET_NEXT_RECUR_DATE, type = ServiceOperationType.EXECUTE, passParamAsMap = true)
    public String getNextRecurDate(Map<String, Object> params);

	public Long getTranKey(String refNo, String type, String instrumentType);
	
	public String getDestinationAddress(String module, CbsBusinessDataObject mainBdo, String refNo, MessageKey message, String instrumentType, String instrumentSubType, Map<String, Object> qParams);

	public TfnChargesServiceExt getTfnChargeServiceExtensionPoint();

	public BgtChargesServiceExt getBgtChargeServiceExtensionPoint();
	
	public Long getInternalKey(String api);
	
}
