package com.silverlakesymmetri.cbs.swf.svc.impl;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.inject.Inject;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.xhtmlrenderer.pdf.ITextRenderer;

import com.lowagie.text.DocumentException;
import com.lowagie.text.pdf.BaseFont;
import com.silverlakesymmetri.cbs.commons.bdo.sdo.DmsFile;
import com.silverlakesymmetri.cbs.commons.dms.DocumentManagementService;
import com.silverlakesymmetri.cbs.commons.exception.CbsRuntimeException;
import com.silverlakesymmetri.cbs.commons.jpa.extension.JaxbSdoHelper;
import com.silverlakesymmetri.cbs.commons.restlet.JsonConvertionManager;
import com.silverlakesymmetri.cbs.swf.bdo.sdo.SwfChargeNarrative;
import com.silverlakesymmetri.cbs.swf.bdo.sdo.SwfF74Narrative;
import com.silverlakesymmetri.cbs.swf.bdo.sdo.SwfF77Narrative;
import com.silverlakesymmetri.cbs.swf.bdo.sdo.SwfNonFinEntity;
import com.silverlakesymmetri.cbs.swf.bdo.sdo.SwfSndrRcvrNarrative;
import com.silverlakesymmetri.cbs.swf.jpa.util.SwiftFormatterUtil;
import com.silverlakesymmetri.cbs.swf.svc.SwiftNonFinEntityService;
import com.silverlakesymmetri.cbs.swf.svc.SwiftUtilityService;

@Service
public class SwiftUtilityServiceImpl implements SwiftUtilityService {

	@Autowired
	private SwiftNonFinEntityService swiftNonFinEntityService;

    @Inject
    protected JsonConvertionManager jsonConversionMngr;

    @Inject
    protected JaxbSdoHelper jaxbSdoHelper;

    @Autowired
    private DocumentManagementService cbsDmsService;

	@Override
	public boolean validateSwfNonFinEntity(SwfNonFinEntity dataObject) {
		return swiftNonFinEntityService.validateSwfNonFinEntity(dataObject);
	}

	@Override
	public String previewSndrRcvrNarrative(Map<String, Object> parameters){
		List<SwfSndrRcvrNarrative> narrativeList = new ArrayList<SwfSndrRcvrNarrative>();
		Integer charPerLine = parameters.get("charPerLine") != null ? Integer.parseInt(parameters.get("charPerLine").toString()) : 0;
		for(String key: parameters.keySet()){
			if(!key.equals("charPerLine")){
				SwfSndrRcvrNarrative narrative = jsonConversionMngr.convertToType(parameters.get(key), SwfSndrRcvrNarrative.class, null, null);
				narrativeList.add(narrative);
			}
		}
		
		if(narrativeList == null || narrativeList.size() == 0){
			return "";
		}
		StringBuilder swfNarrative = new StringBuilder();
		for(int i = 0; i < narrativeList.size(); i++) {
			SwfSndrRcvrNarrative narrative = narrativeList.get(i);
			String swfFormattedNarrative = SwiftFormatterUtil.formatNarrative(narrative.getCode(), null, null, null, narrative.getNarrative(), charPerLine);
			if(i > 0) swfNarrative.append("\n");
			swfNarrative.append(swfFormattedNarrative);
		}
		return swfNarrative.toString();
	}

	@Override
	public String previewChargeNarrative(Map<String, Object> parameters) {
		List<SwfChargeNarrative> narrativeList = new ArrayList<SwfChargeNarrative>();
		Integer charPerLine = parameters.get("charPerLine") != null ? Integer.parseInt(parameters.get("charPerLine").toString()) : 0;
		for(String key: parameters.keySet()){
			if(!key.equals("charPerLine")){
				SwfChargeNarrative narrative = jsonConversionMngr.convertToType(parameters.get(key), SwfChargeNarrative.class, null, null);
				narrativeList.add(narrative);
			}
		}
		
		if(narrativeList == null || narrativeList.size() == 0){
			return "";
		}
		StringBuilder swfNarrative = new StringBuilder();
		for(int i = 0; i < narrativeList.size(); i++) {
			SwfChargeNarrative narrative = narrativeList.get(i);
			String swfFormattedNarrative = SwiftFormatterUtil.formatNarrative(narrative.getCode(), narrative.getCurrency(), narrative.getAmount(), null, narrative.getNarrative(), charPerLine);
			if(i > 0) swfNarrative.append("\n");
			swfNarrative.append(swfFormattedNarrative);
		}
		return swfNarrative.toString();
	}

	@Override
	public String previewPlainNarrative(Map<String, Object> parameters) {
		String narrative = parameters.get("narrative") != null ? parameters.get("narrative").toString() : null;
		String code = parameters.get("code") != null ? parameters.get("code").toString() : null;
		Integer charPerLine = parameters.get("charPerLine") != null ? Integer.parseInt(parameters.get("charPerLine").toString()) : 0;
		String swfFormattedNarrative = SwiftFormatterUtil.formatNarrative(code, null, null, null, narrative, charPerLine);

		return swfFormattedNarrative;
	}

	@Override
	public String previewNarrativeList(Map<String, Object> parameters) {
		Integer charPerLine = parameters.get("charPerLine") != null ? Integer.parseInt(parameters.get("charPerLine").toString()) : 0;
		Integer tag = parameters.get("tag") != null ? Integer.parseInt(parameters.get("tag").toString()) : 0;

		StringBuilder swfNarrative = new StringBuilder();

		int count = 0;
		for(String key: parameters.keySet()){
			if(!key.equals("charPerLine") && !key.equals("tag")){
				String swfFormattedNarrative = null;
				count++;
				if(tag.intValue() == 74){
					SwfF74Narrative narrative = jsonConversionMngr.convertToType(parameters.get(key), SwfF74Narrative.class, null, null);
					swfFormattedNarrative = SwiftFormatterUtil.formatNarrative(narrative.getCode(), null, null, null, narrative.getNarrative(), charPerLine);
				} else if(tag.intValue() == 77){
					SwfF77Narrative narrative = jsonConversionMngr.convertToType(parameters.get(key), SwfF77Narrative.class, null, null);
					swfFormattedNarrative = SwiftFormatterUtil.formatNarrative(narrative.getCode(), null, null, narrative.getCountry(), narrative.getNarrative(), charPerLine);
				}
				if(count > 1) swfNarrative.append("\n");
				swfNarrative.append(swfFormattedNarrative);
			}
		}
		return swfNarrative.toString();
	}

	@Override
	public List<SwfSndrRcvrNarrative> formatSndrRcvrNarrative(Map<String, Object> parameters) {
		List<SwfSndrRcvrNarrative> narrativeList = new ArrayList<SwfSndrRcvrNarrative>();
		Integer charPerLine = parameters.get("charPerLine") != null ? Integer.parseInt(parameters.get("charPerLine").toString()) : 0;
		for(String key: parameters.keySet()){
			if(!key.equals("charPerLine")){
				SwfSndrRcvrNarrative narrative = jsonConversionMngr.convertToType(parameters.get(key), SwfSndrRcvrNarrative.class, null, null);
				narrativeList.add(narrative);
			}
		}
		
		if(narrativeList.size() == 0){
			return narrativeList;
		}
		for(int i = 0; i < narrativeList.size(); i++) {
			SwfSndrRcvrNarrative narrative = narrativeList.get(i);
			String swfFormattedNarrative = SwiftFormatterUtil.formatNarrative(narrative.getCode(), null, null, null, narrative.getNarrative(), charPerLine);
			swfFormattedNarrative = preFormatNarrative(narrative.getCode(), swfFormattedNarrative);
			narrativeList.get(i).setNarrative(swfFormattedNarrative);
		}
		return narrativeList;
	}

	@Override
	public List<SwfChargeNarrative> formatChargeNarrative(Map<String, Object> parameters) {
		List<SwfChargeNarrative> narrativeList = new ArrayList<SwfChargeNarrative>();
		Integer charPerLine = parameters.get("charPerLine") != null ? Integer.parseInt(parameters.get("charPerLine").toString()) : 0;
		for(String key: parameters.keySet()){
			if(!key.equals("charPerLine")){
				SwfChargeNarrative narrative = jsonConversionMngr.convertToType(parameters.get(key), SwfChargeNarrative.class, null, null);
				narrativeList.add(narrative);
			}
		}
		
		if(narrativeList == null || narrativeList.size() == 0){
			return narrativeList;
		}
		for(int i = 0; i < narrativeList.size(); i++) {
			SwfChargeNarrative narrative = narrativeList.get(i);
			String swfFormattedNarrative = SwiftFormatterUtil.formatNarrative(narrative.getCode(), narrative.getCurrency(), narrative.getAmount(), null, narrative.getNarrative(), charPerLine);
			String[] narrativeLines = swfFormattedNarrative.split("\n");
			for(int j = 0; j < narrativeLines.length; j++) {
				boolean optionalFieldsPresent = false;
				if(j == 0 && narrative.getCode() != null){
					narrativeLines[j] = narrativeLines[j].replace("/"+narrative.getCode(), "");
					optionalFieldsPresent = true;
				}
				if(j == 0 && narrative.getCurrency() != null){
					narrativeLines[j] = narrativeLines[j].replace("/"+narrative.getCurrency(), "");
					optionalFieldsPresent = true;
				}
				if(j == 0 && narrative.getAmount() != null){
					String swiftAmt = SwiftFormatterUtil.swiftFormatAmount(narrative.getAmount());
					narrativeLines[j] = narrativeLines[j].replace("/"+swiftAmt, "");
					optionalFieldsPresent = true;
				}
				if(j == 0 && optionalFieldsPresent) {
					narrativeLines[j] = narrativeLines[j].replaceFirst("/", "");
				} else {
					narrativeLines[j] = narrativeLines[j].replaceFirst("//", "");
				}
			}
			swfFormattedNarrative = String.join("\n", narrativeLines);
			narrativeList.get(i).setNarrative(swfFormattedNarrative);
		}
		return narrativeList;
	}

	@Override
	public String formatPlainNarrative(Map<String, Object> parameters) {
		String narrative = parameters.get("narrative") != null ? parameters.get("narrative").toString() : null;
		String code = parameters.get("code") != null ? parameters.get("code").toString() : null;
		Integer charPerLine = parameters.get("charPerLine") != null ? Integer.parseInt(parameters.get("charPerLine").toString()) : 0;
		String swfFormattedNarrative = SwiftFormatterUtil.formatNarrative(code, null, null, null, narrative, charPerLine);
		swfFormattedNarrative = preFormatNarrative(code, swfFormattedNarrative);

		return swfFormattedNarrative;
	}

	@Override
	public Map<String, Object> formatListNarrative(Map<String, Object> parameters) {
		Integer charPerLine = parameters.get("charPerLine") != null ? Integer.parseInt(parameters.get("charPerLine").toString()) : 0;
		Integer tag = parameters.get("tag") != null ? Integer.parseInt(parameters.get("tag").toString()) : 0;

		for(String key: parameters.keySet()){
			if(!key.equals("charPerLine") && !key.equals("tag")){
				String swfFormattedNarrative = null;
				if(tag.intValue() == 74){
					SwfF74Narrative narrative = jsonConversionMngr.convertToType(parameters.get(key), SwfF74Narrative.class, null, null);
					swfFormattedNarrative = SwiftFormatterUtil.formatNarrative(narrative.getCode(), null, null, null, narrative.getNarrative(), charPerLine);
					swfFormattedNarrative = preFormatNarrative(narrative.getCode(), swfFormattedNarrative);
					narrative.setNarrative(swfFormattedNarrative);
					parameters.put(key, narrative);
				} else if(tag.intValue() == 77){
					SwfF77Narrative narrative = jsonConversionMngr.convertToType(parameters.get(key), SwfF77Narrative.class, null, null);
					swfFormattedNarrative = SwiftFormatterUtil.formatNarrative(narrative.getCode(), null, null, narrative.getCountry(), narrative.getNarrative(), charPerLine);
					swfFormattedNarrative = preFormatNarrative(narrative.getCode(), swfFormattedNarrative);
					narrative.setNarrative(swfFormattedNarrative);
					parameters.put(key, narrative);
				}
			}
		}
		return parameters;
	}
	
	private String preFormatNarrative(String code, String swfFormattedNarrative){
		String[] narrativeLines = swfFormattedNarrative.split("\n");
		for(int j = 0; j < narrativeLines.length; j++) {
			if(j == 0 && code != null){
				narrativeLines[j] = narrativeLines[j].replace("/"+code+"/", "");
			} else {
				narrativeLines[j] = narrativeLines[j].replaceFirst("//", "");
			}
		}
		swfFormattedNarrative = String.join("\n", narrativeLines);
		return swfFormattedNarrative;
	}

	@Override
	public DmsFile downloadSwiftMessage(String message) {
		DmsFile dmsFile = null;
		String document = "SWIFT Preview";
		message = message.replaceAll("&nbsp;", " ");
		message = message.replaceAll("\\n", "<br />");

		try {
			final ByteArrayOutputStream iTextOut = new ByteArrayOutputStream();
			ITextRenderer renderer = new ITextRenderer();
			renderer.getFontResolver().addFont("/fonts/Arial/arial.ttf", BaseFont.IDENTITY_H, BaseFont.NOT_EMBEDDED);
			renderer.getFontResolver().addFont("/fonts/Calibri/calibri.ttf", BaseFont.IDENTITY_H, BaseFont.NOT_EMBEDDED);
			renderer.getFontResolver().addFont("/fonts/ComicSans/comic.ttf", BaseFont.IDENTITY_H, BaseFont.NOT_EMBEDDED);
			renderer.getFontResolver().addFont("/fonts/CourierNew/cour.ttf", BaseFont.IDENTITY_H, BaseFont.NOT_EMBEDDED);
			renderer.getFontResolver().addFont("/fonts/TimesNewRoman/times.ttf", BaseFont.IDENTITY_H, BaseFont.NOT_EMBEDDED);
			renderer.getFontResolver().addFont("/fonts/SansSerif/Roboto-Regular.ttf", BaseFont.IDENTITY_H, BaseFont.NOT_EMBEDDED);
			renderer.setDocumentFromString(message);
			renderer.layout();
			renderer.createPDF(iTextOut);
			byte[] reportInBytes = iTextOut.toByteArray();
			
			if (reportInBytes != null) {
				StringBuilder builder = new StringBuilder(document);
				builder.append("-");
				SimpleDateFormat sdFormat = new SimpleDateFormat("MMddyyHHmmssSSS");
				builder.append(sdFormat.format(new Date()));
				builder.append(".pdf");
			    dmsFile = jaxbSdoHelper.createSdoInstance(DmsFile.class);
			    dmsFile.setDmsFileId(document);
			    dmsFile.setName(builder.toString());
			    dmsFile.setContentType("application/pdf");
			    dmsFile.setContent(cbsDmsService.byteArrToContentString(reportInBytes, "application/pdf"));
			    dmsFile.setSize(new Long(reportInBytes.length));
			}
		} catch (DocumentException e) {
			throw new CbsRuntimeException(e.getMessage());
		} catch (IOException e) {
			throw new CbsRuntimeException(e.getMessage());
		}

		return dmsFile;
	}
	

}
