package com.silverlakesymmetri.cbs.xps.svc.batch.writer;

import com.silverlakesymmetri.cbs.commons.logging.CbsAppLogger;
import com.silverlakesymmetri.cbs.commons.logging.CbsAppLoggerFactory;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.MessageMasterJpe;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.util.XpsJpeConstants;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class SwiftIncomingPendingTranWriter extends IncomingMessagePendingTranBaseWriter {
	private final CbsAppLogger logger = CbsAppLoggerFactory.getLogger(SwiftIncomingPendingTranWriter.class);

	@Override
	protected void doBulkUpdate(String newStatus, List<Long> keys) {
		if (logger.isDebugEnabled()) {
			logger.debug("Following keys {} will be updated to {}", keys, newStatus);
		}

		Map<String, Object> params = new HashMap<>();
		params.put("status", newStatus);
		params.put("keys", keys);
		batchDataService.bulkUpdateWithNamedQuery(XpsJpeConstants.MESSAGE_MASTER_JPE_UPDATE_STATUS_ERROR, params,
				MessageMasterJpe.class);
	}

}
