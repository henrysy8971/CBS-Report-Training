package com.silverlakesymmetri.cbs.gla.svc;

import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation;
import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation.ServiceOperationType;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.svc.BusinessService;
import com.silverlakesymmetri.cbs.gla.bdo.sdo.GlManualBatchGlCodeQry;
import com.silverlakesymmetri.cbs.gla.jpa.mapping.sdo.GlManualBatchGlCodeQryJpe;

import java.util.List;
import java.util.Map;

public interface GlManualBatchGlCodeQryService extends BusinessService<GlManualBatchGlCodeQry, GlManualBatchGlCodeQryJpe> {

	public static final String SVC_OP_NAME_GLMANUALBATCHGLCODESSERVICE_GET = "GlManualBatchGlCodeQryService.get";
	public static final String SVC_OP_NAME_GLMANUALBATCHGLCODESSERVICE_FIND = "GlManualBatchGlCodeQryService.find";
	public static final String SVC_OP_NAME_GLMANUALBATCHGLCODESSERVICE_QUERY = "GlManualBatchGlCodeQryService.query";
	
	@ServiceOperation(name = SVC_OP_NAME_GLMANUALBATCHGLCODESSERVICE_GET, type = ServiceOperationType.GET)
    public GlManualBatchGlCodeQry getByPk(String publicKey, GlManualBatchGlCodeQry reference);

    @ServiceOperation(name = SVC_OP_NAME_GLMANUALBATCHGLCODESSERVICE_FIND)
    public List<GlManualBatchGlCodeQry> find(FindCriteria findCriteria, CbsHeader cbsHeader);
    
    @ServiceOperation(name = SVC_OP_NAME_GLMANUALBATCHGLCODESSERVICE_QUERY)
    public List<GlManualBatchGlCodeQry> query(int offset, int resultLimit, String groupBy, String order, Map<String, Object> filters);
}
