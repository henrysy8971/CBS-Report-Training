package com.silverlakesymmetri.cbs.xps.svc.impl;

import com.mysema.query.types.EntityPath;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.exception.CbsRuntimeException;
import com.silverlakesymmetri.cbs.commons.logging.CbsAppLogger;
import com.silverlakesymmetri.cbs.commons.logging.annotation.Logger;
import com.silverlakesymmetri.cbs.commons.svc.AbstractXmlApiBusinessService;
import com.silverlakesymmetri.cbs.commons.xmlapi.enums.CbsXmlApiOperation;
import com.silverlakesymmetri.cbs.commons.xmlapi.rs.CUTAPIHEADEROUTCPLXType;
import com.silverlakesymmetri.cbs.xps.bdo.sdo.IncomingMessageSwf;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.IncomingMessageSwfJpe;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.QIncomingMessageSwfJpe;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.id.IncomingMessageSwfPk;
import com.silverlakesymmetri.cbs.xps.svc.IncomingMessageSwfService;
import com.silverlakesymmetri.cbs.xps.xmlapi.XPSMESSAGEREPOSWFINAPIType;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.transform.stream.StreamResult;
import java.io.StringWriter;
import java.util.List;
import java.util.Map;

@Service
@Transactional
public class IncomingMessageSwfServiceImpl extends AbstractXmlApiBusinessService<IncomingMessageSwf, IncomingMessageSwfJpe, IncomingMessageSwfPk, XPSMESSAGEREPOSWFINAPIType, XPSMESSAGEREPOSWFINAPIType> implements IncomingMessageSwfService {

    protected static final String SP_RES_XML_API = "p_Response";
    protected static final String SP_RES_HEADER_OUT = "p_Response_Header";

    @Logger
    CbsAppLogger logger;

    @Override
    protected IncomingMessageSwfPk getIdFromDataObjectInstance(IncomingMessageSwf dataObject) {
        return new IncomingMessageSwfPk(dataObject.getInternalKey());
    }

    @Override
    protected EntityPath<IncomingMessageSwfJpe> getEntityPath() {
        return QIncomingMessageSwfJpe.incomingMessageSwfJpe;
    }

    @Override
    public List<IncomingMessageSwf> query(int offset, int resultLimit, String groupBy, String order,
                                     Map<String, Object> filters) {
        return super.query(offset, resultLimit, groupBy, order, filters);
    }

    @Override
    public List<IncomingMessageSwf> find(FindCriteria findCriteria, CbsHeader cbsHeader) {
        return super.find(findCriteria, cbsHeader);
    }

    @Override
    public String getMessageDetails(Long internalKey) {
        String message = "";

        XPSMESSAGEREPOSWFINAPIType xmlApiReq = new XPSMESSAGEREPOSWFINAPIType();
        xmlApiReq.setOPERATION(CbsXmlApiOperation.QUERY.getOperation());
        xmlApiReq.setINTERNALKEY(internalKey);

        try {
            String xmlApiReqStr = transformMessageDetailRequest(xmlApiReq);
            message = messageDetailRequest(xmlApiReqStr);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }

        return message;
    }

    private String transformMessageDetailRequest(XPSMESSAGEREPOSWFINAPIType xmlApiRq) throws JAXBException {
        JAXBContext jaxbContext = getJAXBContextFromPool(XPSMESSAGEREPOSWFINAPIType.class);
        Marshaller m = jaxbContext.createMarshaller();
        StringWriter writerIn = new StringWriter();
        StreamResult requestStream = new StreamResult(writerIn);
        m.marshal(xmlApiRq, requestStream);
        String xmlString = writerIn.toString();
        if (this.logger != null && this.logger.isDebugEnabled()) {
            this.logger.debug("XML_API_REQUEST>>>");
            this.logger.debug(xmlString);
        }

        return xmlString;
    }

    protected String messageDetailRequest(String xmlApiReq) {
        String message = "";
        try {
            String xmlHeaderIn = convertXmlApiRqToString(createHeader());
            Map<String, String> responseMap = executeStoredProcedure(xmlApiReq, xmlHeaderIn);
            processErrors(convertXmlStringToObject(responseMap.get(SP_RES_HEADER_OUT), CUTAPIHEADEROUTCPLXType.class), null, null);
            message = responseMap.get(SP_RES_XML_API);

            if (logger != null && logger.isDebugEnabled()) {
                logger.debug("XPS_MESSAGE_REPO_SWF_IN_APIType >>>");
                logger.debug(message);
            }
        } catch (CbsRuntimeException cre) {
            throw cre;
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
        return message;
    }

    @Override
    public IncomingMessageSwf getByPk(String publicKey, IncomingMessageSwf reference) {
        return super.getByPk(publicKey, reference);
    }

    @Override
    protected XPSMESSAGEREPOSWFINAPIType transformBdoToXmlApiRqCreate(IncomingMessageSwf incomingMessageSwf) {
        return null;
    }

    @Override
    protected XPSMESSAGEREPOSWFINAPIType transformBdoToXmlApiRqUpdate(IncomingMessageSwf incomingMessageSwf) {
        return null;
    }

    @Override
    protected XPSMESSAGEREPOSWFINAPIType transformBdoToXmlApiRqDelete(IncomingMessageSwf incomingMessageSwf) {
        return null;
    }

    @Override
    protected IncomingMessageSwf processXmlApiRs(IncomingMessageSwf dataObject, XPSMESSAGEREPOSWFINAPIType xpsmessagereposwfinapiType) {
        return dataObject;
    }

    @Override
    protected List<IncomingMessageSwf> processXmlApiListRs(IncomingMessageSwf incomingMessageSwf, XPSMESSAGEREPOSWFINAPIType xpsmessagereposwfinapiType) {
        return null;
    }

    @Override
    protected Class<XPSMESSAGEREPOSWFINAPIType> getXmlApiResponseClass() {
        return XPSMESSAGEREPOSWFINAPIType.class;
    }

    private XPSMESSAGEREPOSWFINAPIType transformBdoToXmlApiType(Long internalKey, CbsXmlApiOperation oper) {
        XPSMESSAGEREPOSWFINAPIType apiType = new XPSMESSAGEREPOSWFINAPIType();
        apiType.setOPERATION(oper.getOperation());
        apiType.setINTERNALKEY(internalKey);
        return apiType;
    }
}
