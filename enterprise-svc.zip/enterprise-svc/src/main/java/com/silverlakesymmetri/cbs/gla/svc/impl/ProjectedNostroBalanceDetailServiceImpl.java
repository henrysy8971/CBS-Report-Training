package com.silverlakesymmetri.cbs.gla.svc.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Service;

import com.mysema.query.types.EntityPath;
import com.silverlakesymmetri.cbs.commons.svc.AbstractXmlApiBusinessService;
import com.silverlakesymmetri.cbs.commons.xmlapi.enums.CbsXmlApiOperation;
import com.silverlakesymmetri.cbs.gla.bdo.sdo.ProjectedNostroBalanceDetail;
import com.silverlakesymmetri.cbs.gla.jpa.mapping.sdo.ProjectedNostroBalanceByAcctJpe;
import com.silverlakesymmetri.cbs.gla.jpa.mapping.sdo.ProjectedNostroBalanceDetailJpe;
import com.silverlakesymmetri.cbs.gla.jpa.mapping.sdo.QProjectedNostroBalanceDetailJpe;
import com.silverlakesymmetri.cbs.gla.jpa.mapping.sdo.id.ProjectedNostroBalanceDetailPk;
import com.silverlakesymmetri.cbs.gla.svc.ProjectedNostroBalanceDetailService;
import com.silverlakesymmetri.cbs.gla.xmlapi.GLAPROJBALCCYINFODTLCOLLType;
import com.silverlakesymmetri.cbs.gla.xmlapi.GLAPROJBALCCYINFODTLTYPEType;
import com.silverlakesymmetri.cbs.gla.xmlapi.GLAPROJECTEDBALANCESDTLQRYAPIType;

@Service
public class ProjectedNostroBalanceDetailServiceImpl 
extends AbstractXmlApiBusinessService<ProjectedNostroBalanceDetail, ProjectedNostroBalanceDetailJpe, ProjectedNostroBalanceDetailPk, GLAPROJECTEDBALANCESDTLQRYAPIType, GLAPROJECTEDBALANCESDTLQRYAPIType>
	implements ProjectedNostroBalanceDetailService{
	
	private static final Double DAYS = 12.0;
	private static final Double ZERO_BAL = 0.00;
	

	@Override
	public ProjectedNostroBalanceDetail getQueryDetailApi(Map<String, Object> queryParams) {
		String branch = (String) queryParams.get("branch");
		String ccy = (String) queryParams.get("ccy");
		GLAPROJECTEDBALANCESDTLQRYAPIType apiType = new GLAPROJECTEDBALANCESDTLQRYAPIType();
		apiType.setOPERATION(CbsXmlApiOperation.QUERY.getOperation());
    	apiType.setBRANCH(branch);
    	apiType.setCCY(ccy);
    	GLAPROJECTEDBALANCESDTLQRYAPIType result = queryXmlApiRs(apiType);
    	ProjectedNostroBalanceDetail dataObject = mapRundateSuspenseAmt(result, branch);
    	dataObject.setBranch(branch);
    	dataObject.setCcy(ccy);
		return dataObject;
	}
	
	private ProjectedNostroBalanceDetail mapRundateSuspenseAmt(GLAPROJECTEDBALANCESDTLQRYAPIType apiType, String branch) {
		ProjectedNostroBalanceDetailJpe jpe = new ProjectedNostroBalanceDetailJpe();
		
		if(apiType.getSUSPENSETOTALS() != null) {
			if(apiType.getSUSPENSETOTALS().getGLAAPITOTALDTLTYPE().size() == 12) {
				jpe.setRunDate1SuspenseAmt(apiType.getSUSPENSETOTALS().getGLAAPITOTALDTLTYPE().get(0).getTOTAL());
				jpe.setRunDate2SuspenseAmt(apiType.getSUSPENSETOTALS().getGLAAPITOTALDTLTYPE().get(1).getTOTAL());
				jpe.setRunDate3SuspenseAmt(apiType.getSUSPENSETOTALS().getGLAAPITOTALDTLTYPE().get(2).getTOTAL());
				jpe.setRunDate4SuspenseAmt(apiType.getSUSPENSETOTALS().getGLAAPITOTALDTLTYPE().get(3).getTOTAL());
				jpe.setRunDate5SuspenseAmt(apiType.getSUSPENSETOTALS().getGLAAPITOTALDTLTYPE().get(4).getTOTAL());
				jpe.setRunDate6SuspenseAmt(apiType.getSUSPENSETOTALS().getGLAAPITOTALDTLTYPE().get(5).getTOTAL());
				jpe.setRunDate7SuspenseAmt(apiType.getSUSPENSETOTALS().getGLAAPITOTALDTLTYPE().get(6).getTOTAL());
				jpe.setRunDate8SuspenseAmt(apiType.getSUSPENSETOTALS().getGLAAPITOTALDTLTYPE().get(7).getTOTAL());
				jpe.setRunDate9SuspenseAmt(apiType.getSUSPENSETOTALS().getGLAAPITOTALDTLTYPE().get(8).getTOTAL());
				jpe.setRunDate10SuspenseAmt(apiType.getSUSPENSETOTALS().getGLAAPITOTALDTLTYPE().get(9).getTOTAL());
				jpe.setRunDate11SuspenseAmt(apiType.getSUSPENSETOTALS().getGLAAPITOTALDTLTYPE().get(10).getTOTAL());
				jpe.setRunDate12SuspenseAmt(apiType.getSUSPENSETOTALS().getGLAAPITOTALDTLTYPE().get(11).getTOTAL());
			}
		}
		
		if(apiType.getCURRENCIES() != null) {
			jpe.setProjectedNostroBalanceByAcctList(mapBalByAcct(apiType.getCURRENCIES(), branch));
		}
		return jaxbSdoHelper.wrap(jpe);
	}
	
	private List<ProjectedNostroBalanceByAcctJpe> mapBalByAcct(GLAPROJBALCCYINFODTLCOLLType api, String branch){
		List<ProjectedNostroBalanceByAcctJpe> list = new ArrayList();
		for(GLAPROJBALCCYINFODTLTYPEType apiDetail : api.getGLAPROJBALCCYINFODTLTYPE()) {
			ProjectedNostroBalanceByAcctJpe newJpe = mapDetails(apiDetail, branch);
			list.add(newJpe);
		}
		return list;
	}
	
	private ProjectedNostroBalanceByAcctJpe mapDetails(GLAPROJBALCCYINFODTLTYPEType api, String branch) {
		ProjectedNostroBalanceByAcctJpe jpe = new ProjectedNostroBalanceByAcctJpe();
		jpe.setBranch(branch);
		jpe.setCcy(api.getCCY());
		jpe.setNosVosNo(api.getNOSVOSNO().intValue());
		jpe.setClientName(api.getCLIENTNAME());
		jpe.setClientNo(api.getCLIENTNO());
		jpe.setClientId(api.getCLIENTID());
		
		if(api.getBALANCES() != null) {
			if(api.getBALANCES().getGLAAPIAMOUNTDTLTYPE().size() == 12) {
				jpe.setRunDate1BalanceAmt(api.getBALANCES().getGLAAPIAMOUNTDTLTYPE().get(0).getAMOUNT());
				jpe.setRunDate2BalanceAmt(api.getBALANCES().getGLAAPIAMOUNTDTLTYPE().get(1).getAMOUNT());
				jpe.setRunDate3BalanceAmt(api.getBALANCES().getGLAAPIAMOUNTDTLTYPE().get(2).getAMOUNT());
				jpe.setRunDate4BalanceAmt(api.getBALANCES().getGLAAPIAMOUNTDTLTYPE().get(3).getAMOUNT());
				jpe.setRunDate5BalanceAmt(api.getBALANCES().getGLAAPIAMOUNTDTLTYPE().get(4).getAMOUNT());
				jpe.setRunDate6BalanceAmt(api.getBALANCES().getGLAAPIAMOUNTDTLTYPE().get(5).getAMOUNT());
				jpe.setRunDate7BalanceAmt(api.getBALANCES().getGLAAPIAMOUNTDTLTYPE().get(6).getAMOUNT());
				jpe.setRunDate8BalanceAmt(api.getBALANCES().getGLAAPIAMOUNTDTLTYPE().get(7).getAMOUNT());
				jpe.setRunDate9BalanceAmt(api.getBALANCES().getGLAAPIAMOUNTDTLTYPE().get(8).getAMOUNT());
				jpe.setRunDate10BalanceAmt(api.getBALANCES().getGLAAPIAMOUNTDTLTYPE().get(9).getAMOUNT());
				jpe.setRunDate11BalanceAmt(api.getBALANCES().getGLAAPIAMOUNTDTLTYPE().get(10).getAMOUNT());
				jpe.setRunDate12BalanceAmt(api.getBALANCES().getGLAAPIAMOUNTDTLTYPE().get(11).getAMOUNT());
			}
		}else {
			jpe.setRunDate1BalanceAmt(ZERO_BAL);
			jpe.setRunDate2BalanceAmt(ZERO_BAL);
			jpe.setRunDate3BalanceAmt(ZERO_BAL);
			jpe.setRunDate4BalanceAmt(ZERO_BAL);
			jpe.setRunDate5BalanceAmt(ZERO_BAL);
			jpe.setRunDate6BalanceAmt(ZERO_BAL);
			jpe.setRunDate7BalanceAmt(ZERO_BAL);
			jpe.setRunDate8BalanceAmt(ZERO_BAL);
			jpe.setRunDate9BalanceAmt(ZERO_BAL);
			jpe.setRunDate10BalanceAmt(ZERO_BAL);
			jpe.setRunDate11BalanceAmt(ZERO_BAL);
			jpe.setRunDate12BalanceAmt(ZERO_BAL);
		}
		
		return jpe;
		
	}

	@Override
	protected Class<GLAPROJECTEDBALANCESDTLQRYAPIType> getXmlApiResponseClass() {
		return GLAPROJECTEDBALANCESDTLQRYAPIType.class;
	}

	@Override
	protected List<ProjectedNostroBalanceDetail> processXmlApiListRs(ProjectedNostroBalanceDetail arg0,
			GLAPROJECTEDBALANCESDTLQRYAPIType arg1) {
		return null;
	}

	@Override
	protected ProjectedNostroBalanceDetail processXmlApiRs(ProjectedNostroBalanceDetail dataObject,
			GLAPROJECTEDBALANCESDTLQRYAPIType arg1) {
		return dataObject;
	}

	@Override
	protected GLAPROJECTEDBALANCESDTLQRYAPIType transformBdoToXmlApiRqCreate(ProjectedNostroBalanceDetail arg0) {
		return null;
	}

	@Override
	protected GLAPROJECTEDBALANCESDTLQRYAPIType transformBdoToXmlApiRqDelete(ProjectedNostroBalanceDetail arg0) {
		return null;
	}

	@Override
	protected GLAPROJECTEDBALANCESDTLQRYAPIType transformBdoToXmlApiRqUpdate(ProjectedNostroBalanceDetail arg0) {
		return null;
	}

	@Override
	protected ProjectedNostroBalanceDetailPk getIdFromDataObjectInstance(ProjectedNostroBalanceDetail dataObject) {
		return new ProjectedNostroBalanceDetailPk(dataObject.getBranch(), dataObject.getCcy());
	}
	
	@Override
	protected EntityPath<ProjectedNostroBalanceDetailJpe> getEntityPath() {
		return QProjectedNostroBalanceDetailJpe.projectedNostroBalanceDetailJpe;
	}

}
