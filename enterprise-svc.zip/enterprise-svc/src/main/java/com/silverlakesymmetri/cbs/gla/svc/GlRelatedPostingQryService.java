package com.silverlakesymmetri.cbs.gla.svc;

import java.util.List;
import java.util.Map;

import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation;
import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation.ServiceOperationType;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.svc.BusinessService;
import com.silverlakesymmetri.cbs.gla.bdo.sdo.GlRelatedPostingQry;
import com.silverlakesymmetri.cbs.gla.jpa.mapping.sdo.GlRelatedPostingQryJpe;

public interface GlRelatedPostingQryService extends BusinessService<GlRelatedPostingQry, GlRelatedPostingQryJpe> {

	public static final String SVC_OP_NAME_GLRELATEDPOSTINGQRYQRYSERVICE_GET = "GlRelatedPostingQryService.get";
	public static final String SVC_OP_NAME_GLRELATEDPOSTINGQRYSERVICE_FIND = "GlRelatedPostingQryService.find";
	public static final String SVC_OP_NAME_GLRELATEDPOSTINGQRYSERVICE_QUERY = "GlRelatedPostingQryService.query";
	
	@ServiceOperation(name = SVC_OP_NAME_GLRELATEDPOSTINGQRYQRYSERVICE_GET, type = ServiceOperationType.GET)
    public GlRelatedPostingQry getByPk(String publicKey, GlRelatedPostingQry reference);

    @ServiceOperation(name = SVC_OP_NAME_GLRELATEDPOSTINGQRYSERVICE_FIND)
    public List<GlRelatedPostingQry> find(FindCriteria findCriteria, CbsHeader cbsHeader);
    
    @ServiceOperation(name = SVC_OP_NAME_GLRELATEDPOSTINGQRYSERVICE_QUERY)
    public List<GlRelatedPostingQry> query(int offset, int resultLimit, String groupBy, String order, Map<String, Object> filters);
}
