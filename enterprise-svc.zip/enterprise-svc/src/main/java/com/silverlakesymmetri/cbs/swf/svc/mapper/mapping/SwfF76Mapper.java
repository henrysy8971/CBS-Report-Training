package com.silverlakesymmetri.cbs.swf.svc.mapper.mapping;

import org.apache.commons.lang3.StringUtils;
import org.mapstruct.InheritInverseConfiguration;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Mappings;

import com.silverlakesymmetri.cbs.swf.jpa.mapping.sdo.SwfF76Jpe;
import com.silverlakesymmetri.cbs.swf.xmlapi.SWFF76TYPEType;

@Mapper(imports=StringUtils.class, uses = { SwfF76NarrativeMapper.class })
public interface SwfF76Mapper {
	
	@Mappings({
		@Mapping(target = "OPT", source = "opt"),
		@Mapping(target = "DETAILS.SWFF76NARRATIVETYPE", source = "swfF76NarrativeList")
	})
	SWFF76TYPEType mapToApi(SwfF76Jpe jpe);

	@InheritInverseConfiguration(name = "mapToApi")
	@Mappings({
		@Mapping(target="opt", expression="java(StringUtils.isNotBlank(api.getOPT())?api.getOPT():null)"),
	})
	SwfF76Jpe mapToJpe(SWFF76TYPEType api);

}