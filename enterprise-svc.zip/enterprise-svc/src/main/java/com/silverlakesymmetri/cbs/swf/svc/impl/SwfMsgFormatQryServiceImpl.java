package com.silverlakesymmetri.cbs.swf.svc.impl;

import com.mysema.query.types.EntityPath;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.jpa.entity.FindCriteriaJpe;
import com.silverlakesymmetri.cbs.commons.svc.AbstractBusinessService;
import com.silverlakesymmetri.cbs.commons.svc.BusinessObjectValidationCapable;
import com.silverlakesymmetri.cbs.swf.bdo.sdo.SwfMsgFormatQry;
import com.silverlakesymmetri.cbs.swf.jpa.mapping.sdo.QSwfMsgFormatQryJpe;
import com.silverlakesymmetri.cbs.swf.jpa.mapping.sdo.SwfMsgFormatQryJpe;
import com.silverlakesymmetri.cbs.swf.jpa.mapping.sdo.id.SwfMsgFormatQryPk;
import com.silverlakesymmetri.cbs.swf.svc.SwfMsgFormatQryService;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Map;

@Service
@Transactional
public class SwfMsgFormatQryServiceImpl extends AbstractBusinessService<SwfMsgFormatQry, SwfMsgFormatQryJpe, SwfMsgFormatQryPk>
        implements SwfMsgFormatQryService, BusinessObjectValidationCapable<SwfMsgFormatQry> {

    @Override
    protected SwfMsgFormatQryPk getIdFromDataObjectInstance(SwfMsgFormatQry dataObject) {
    	SwfMsgFormatQryPk key = new SwfMsgFormatQryPk(dataObject.getDomain(), dataObject.getFormat(), dataObject.getFormatDesc());
        return key;
    }

    @Override
    protected EntityPath<SwfMsgFormatQryJpe> getEntityPath() {
        return QSwfMsgFormatQryJpe.swfMsgFormatQryJpe;
    }

    @Override
    public SwfMsgFormatQry get(SwfMsgFormatQry objectInstanceIdentifier) {
        return super.get(objectInstanceIdentifier);
    }

    @Override
    public SwfMsgFormatQry getByPk(String publicKey, SwfMsgFormatQryService reference) {
        return null;
    }

    @Override
    public List<SwfMsgFormatQry> query(int offset, int resultLimit, String groupBy, String order,
                                    Map<String, Object> filters) {
        return super.query(offset, resultLimit, groupBy, order, filters);
    }

    @Override
    public List<SwfMsgFormatQry> find(FindCriteria findCriteria, CbsHeader cbsHeader) {
        return super.find(findCriteria, cbsHeader);
    }

    @Override
    public SwfMsgFormatQry getByPk(String publicKey, SwfMsgFormatQry reference) {
        return super.getByPk(publicKey, reference);
    }

    @Override
    public Long count(FindCriteria findCriteria, CbsHeader cbsHeader) {
        if (findCriteria == null) {
            return dataService.getRowCount(this.getEntityPath());
        } else {
            FindCriteriaJpe fc = jaxbSdoHelper.unwrap(findCriteria);
            return dataService.getRowCount(SwfMsgFormatQryJpe.class, fc);
        }
    }


}
