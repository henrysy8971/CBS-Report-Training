package com.silverlakesymmetri.cbs.xps.svc.batch.listener;

import org.springframework.batch.core.BatchStatus;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobExecutionListener;
import org.springframework.beans.factory.annotation.Autowired;
import com.silverlakesymmetri.cbs.commons.batch.listener.CbsJobExecutionListener;
import com.silverlakesymmetri.cbs.commons.context.CbsSessionContext;
import com.silverlakesymmetri.cbs.commons.svc.CbsUiMessenger;
import com.silverlakesymmetri.cbs.commons.svc.context.CbsRuntimeContextManager;
import com.silverlakesymmetri.cbs.commons.svc.html5ui.impl.EventSourceDetail;

public class SendMessageJobListener extends CbsJobExecutionListener implements JobExecutionListener {

    private static final String USER_EVENT = "user-event";
    //private static final String JOB_NAME = "XpsMessageQueue.SendMessageJob";
    

    @Autowired
    private CbsUiMessenger cbsUiMessenger;

    @Autowired
    protected CbsRuntimeContextManager cbsRuntimeContextManager;

    @Override
    public void beforeJob(JobExecution exec) {
        super.beforeJob(exec);
    }

    @Override
    public void afterJob(JobExecution exec) {
        super.afterJob(exec);
        
        boolean hasErrors = exec.getAllFailureExceptions() != null && !exec.getAllFailureExceptions().isEmpty();
        String msg = null;
        if (exec.getStatus() == BatchStatus.COMPLETED && !hasErrors) {
            msg = "Job (" + exec.getJobConfigurationName() + ") completed successfully.";
        } else {
            msg = "Job (" + exec.getJobConfigurationName() + ") encountered errors. Please contact System Administrator.";
        }

        sendPushNotificationMsg(msg);
    }

    private void sendPushNotificationMsg(String msg) {
        EventSourceDetail eventSourceDetail = new EventSourceDetail();
        eventSourceDetail.setEventData(msg);
        eventSourceDetail.setEventName(USER_EVENT);

        CbsSessionContext sessionCtx = cbsRuntimeContextManager.getContext(CbsSessionContext.class);
        cbsUiMessenger.sendToUserChannel(sessionCtx.getUserCode(), CbsUiMessenger.DEFAULT_CHANNEL, eventSourceDetail);
    }

}
