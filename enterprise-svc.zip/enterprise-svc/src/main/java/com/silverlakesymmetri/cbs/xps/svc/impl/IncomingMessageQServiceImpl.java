package com.silverlakesymmetri.cbs.xps.svc.impl;

import com.mysema.query.types.EntityPath;
import com.silverlakesymmetri.cbs.commons.batch.bdo.sdo.JobInfo;
import com.silverlakesymmetri.cbs.commons.batch.svc.JobMaintenanceService;
import com.silverlakesymmetri.cbs.commons.exception.CbsRuntimeException;
import com.silverlakesymmetri.cbs.commons.exception.base.CbsServiceException;
import com.silverlakesymmetri.cbs.commons.logging.CbsAppLogger;
import com.silverlakesymmetri.cbs.commons.logging.CbsAppLoggerFactory;
import com.silverlakesymmetri.cbs.commons.svc.AbstractXmlApiBusinessService;
import com.silverlakesymmetri.cbs.commons.svc.BusinessObjectValidationCapable;
import com.silverlakesymmetri.cbs.commons.svc.util.CbsAsychronousTask;
import com.silverlakesymmetri.cbs.commons.svc.util.CbsAsychronousTaskSupport;
import com.silverlakesymmetri.cbs.commons.xmlapi.enums.CbsXmlApiOperation;
import com.silverlakesymmetri.cbs.xps.bdo.sdo.IncomingMessageQ;
import com.silverlakesymmetri.cbs.xps.bdo.sdo.IncomingMessageSwf;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.IncomingMessageQJpe;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.MessageMasterJpe;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.QIncomingMessageQJpe;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.util.XpsJpeConstants;
import com.silverlakesymmetri.cbs.xps.svc.IncomingMessageQService;
import com.silverlakesymmetri.cbs.xps.xmlapi.XPSSWFINASSIGNAPIType;
import com.silverlakesymmetri.cbs.xps.xmlapi.XPSSWFINASSIGNLISTTYPEType;
import com.silverlakesymmetri.cbs.xps.xmlapi.XPSSWFINASSIGNTYPEType;

import org.apache.commons.lang3.StringUtils;
import org.springframework.batch.core.JobParametersInvalidException;
import org.springframework.batch.core.UnexpectedJobExecutionException;
import org.springframework.batch.core.launch.JobOperator;
import org.springframework.batch.core.launch.JobParametersNotFoundException;
import org.springframework.batch.core.launch.NoSuchJobException;
import org.springframework.batch.core.repository.JobExecutionAlreadyRunningException;
import org.springframework.batch.core.repository.JobInstanceAlreadyCompleteException;
import org.springframework.batch.core.repository.JobRestartException;
import org.springframework.beans.BeansException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.inject.Inject;
import javax.persistence.PersistenceException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Service
@Transactional
public class IncomingMessageQServiceImpl extends AbstractXmlApiBusinessService<IncomingMessageQ, IncomingMessageQJpe, String, XPSSWFINASSIGNAPIType, XPSSWFINASSIGNAPIType>
        implements ApplicationContextAware, IncomingMessageQService,  BusinessObjectValidationCapable<IncomingMessageQ>{

	private static final String STATUS_FAILED = "F";
	private static final String JOB_NAME = "ProcessIncoming.SwiftMessageJob";
	private static final String LIST_DELIMITER = "~";
	private static final String ATTR_INTERNAL_KEY_LIST = "internalKeyList";
	private static final String ATTR_FIRE_TIME = "fireTime";
	private static final String EQUAL = "=";
	private static final String COMMA = ",";

    private CbsAppLogger logger = CbsAppLoggerFactory.getLogger(IncomingMessageQServiceImpl.class.getName());
    private ApplicationContext applicationContext;

	@Autowired
	private JobOperator _jobOperatorBean;
	@Inject
	private CbsAsychronousTaskSupport _asynchTaskSupport;
	@Autowired(required = true)
	JobMaintenanceService jobMaintenanceService;

    @Override
    protected String getIdFromDataObjectInstance(IncomingMessageQ dataObject) {
        return null;
    }

    @Override
    protected EntityPath<IncomingMessageQJpe> getEntityPath() {
        return QIncomingMessageQJpe.incomingMessageQJpe;
    }

    @Override
    public IncomingMessageQ updateIncomingMessage(IncomingMessageQ dataObject) {
        IncomingMessageQ bdo = this.update(dataObject);
        return bdo;
    }
    
    @Override
    public boolean processFile(List<Long> internalKeyList) {
    	try {
    		doJob(internalKeyList);
		} catch (Exception e) {
			logger.error("Error encountered while invoking doJob: {}", e.getMessage());
			e.printStackTrace();
			return false;
		}
    	return true;
    }

    @Override
    protected XPSSWFINASSIGNAPIType transformBdoToXmlApiRqCreate(IncomingMessageQ incomingMessageQ) {
        throw new CbsServiceException("Create operation is not allowed in this service!");
    }

    @Override
    protected XPSSWFINASSIGNAPIType transformBdoToXmlApiRqUpdate(IncomingMessageQ bdo) {
        IncomingMessageQJpe jpe = this.jaxbSdoHelper.unwrap(bdo, IncomingMessageQJpe.class);

        if (jpe.getIncomingMessageSwfStructList().isEmpty()){
            logger.warn("List is empty. Nothing to update!");
        }

        XPSSWFINASSIGNAPIType api = new XPSSWFINASSIGNAPIType();
        XPSSWFINASSIGNLISTTYPEType apiTypeDetails = new XPSSWFINASSIGNLISTTYPEType();

        jpe.getIncomingMessageSwfStructList().forEach(incomingMessageSwfJpe -> {
            XPSSWFINASSIGNTYPEType xpsswfinassigntypeType = new XPSSWFINASSIGNTYPEType();
            xpsswfinassigntypeType.setINTERNALKEY(incomingMessageSwfJpe.getInternalKey());
            xpsswfinassigntypeType.setDOMAIN(incomingMessageSwfJpe.getDomain());

            String ignore = (incomingMessageSwfJpe.getIgnore() == "N" || incomingMessageSwfJpe.getIgnore() == null) ? "N" : "Y";
            xpsswfinassigntypeType.setIGNORE(ignore);
            apiTypeDetails.getXPSSWFINASSIGNTYPE().add(xpsswfinassigntypeType);
        });
            api.setOPERATION(CbsXmlApiOperation.PROCESS_GENERIC.getOperation());
            api.setDETAILS(apiTypeDetails);
        return api;
    }

    @Override
    protected XPSSWFINASSIGNAPIType transformBdoToXmlApiRqDelete(IncomingMessageQ incomingMessageQ) {
        throw new CbsServiceException("Delete operation is not allowed in this service!");
    }

    @Override
    protected IncomingMessageQ processXmlApiRs(IncomingMessageQ dataObject, XPSSWFINASSIGNAPIType xpsswfinassignapiType) {
        return dataObject;
    }

    @Override
    protected List<IncomingMessageQ> processXmlApiListRs(IncomingMessageQ dataObject, XPSSWFINASSIGNAPIType xpsswfinassignapiType) {
        List<IncomingMessageQ> list = new ArrayList<>();
        return list;
    }

    @Override
    protected Class<XPSSWFINASSIGNAPIType> getXmlApiResponseClass() {
        return XPSSWFINASSIGNAPIType.class;
    }

    @Override
    public void setApplicationContext(ApplicationContext applicationContext) throws BeansException {
        this.applicationContext = applicationContext;
    }

    @Override
    protected void updateVirtualAttributes(IncomingMessageQJpe originalJpe, IncomingMessageQJpe updatedJpe) {
        try {
            super.updateVirtualAttributes(originalJpe, updatedJpe);
        } catch (PersistenceException pe) {
            // swallow NPE for virtual attributes
            //javax.persistence.PersistenceException: java.lang.NullPointerException&#xd;
            //at org.eclipse.persistence.internal.jpa.EntityManagerFactoryDelegate.getIdentifier(EntityManagerFactoryDelegate.java:730)&#xd;
            //at com.silverlakesymmetri.cbs.commons.jpa.service.CbsJpaBaseService.getIdentifier(CbsJpaBaseService.java:158)&#xd;
            //at com.silverlakesymmetri.cbs.commons.jpa.service.CbsJpaDataService.getIdentifier(CbsJpaDataService.java:34)&#xd;
            //at com.silverlakesymmetri.cbs.commons.jpa.service.CbsEntityMetaDataServiceImpl.getIdentifier(CbsEntityMetaDataServiceImpl.java:21)&#xd;
            //at com.silverlakesymmetri.cbs.commons.jpa.util.BdoHelperJpaImpl.createPublicKey(BdoHelperJpaImpl.java:131)&#xd;
            //at com.silverlakesymmetri.cbs.commons.svc.util.BdoHelperImpl.createPublicKey(BdoHelperImpl.java:85)&#xd;
            //at com.silverlakesymmetri.cbs.commons.jpa.util.BdoHelperJpaImpl.getBdoPublicKey(BdoHelperJpaImpl.java:189)&#xd;
            //at com.silverlakesymmetri.cbs.commons.jpa.metadata.VirtualAttributeManager$VirtualAttributeBdoVisitor.visitBdoInstance(VirtualAttributeManager.java:1092)&#xd;
            //at com.silverlakesymmetri.cbs.commons.jpa.util.visitor.AbstractBdoVisitor.visitInternal(AbstractBdoVisitor.java:175)&#xd;
            //at com.silverlakesymmetri.cbs.commons.jpa.util.visitor.AbstractBdoVisitor.visit(AbstractBdoVisitor.java:118)&#xd;
            //at com.silverlakesymmetri.cbs.commons.jpa.metadata.VirtualAttributeManager.processVirtualAttributes(VirtualAttributeManager.java:386)&#xd;
            //at com.silverlakesymmetri.cbs.commons.jpa.service.CbsGenericDataServiceImpl.updateVirtualAttributes(CbsGenericDataServiceImpl.java:114)&#xd;
            //at com.silverlakesymmetri.cbs.commons.jpa.service.CbsXmlApiDataServiceImpl.updateVirtualAttributes(CbsXmlApiDataServiceImpl.java:19)&#xd;
            //at com.silverlakesymmetri.cbs.commons.svc.AbstractXmlApiBusinessService.updateVirtualAttributes(AbstractXmlApiBusinessService.java:228)&#xd;

            pe.printStackTrace();
            if ("java.lang.NullPointerException".equals(pe.getMessage())) {
                logger.warn("error in updateVirtualAttributes:" + pe.getMessage());
            } else {
                throw pe;
            }
        }
    }

	private void doJob(List<Long> internalKeyList) {
		logger.info("Attempt to start job: {}", JOB_NAME);

		if (internalKeyList == null || internalKeyList.isEmpty()) {
			logger.warn("internalKeyList is empty! Nothing to Process!");
			return;
		}

		// invoke job
		JobInfo jobInfo = jobMaintenanceService.read(JOB_NAME);
		StringBuilder sb = new StringBuilder();
		sb.append(ATTR_INTERNAL_KEY_LIST).append(EQUAL).append(StringUtils.join(internalKeyList, LIST_DELIMITER)); // internalKeyList
		sb.append(COMMA).append(ATTR_FIRE_TIME).append(EQUAL).append(Long.toString(System.currentTimeMillis())); // DISCRIMINATOR
		String jobParam = sb.toString();

		boolean updateStatusToFail = false;
		try {
			jobMaintenanceService.start(jobInfo, jobParam);
		} catch (ClassCastException ccex) {
			logger.warn("Cast exception encountered during start: {}", ccex.getMessage());
			ccex.printStackTrace();
		} catch (Exception ex) {
			logger.error("Exception encountered while starting job: {}", JOB_NAME);
			ex.printStackTrace();
			updateStatusToFail = true;
		} finally {
			if (updateStatusToFail) {
				bulkUpdateStatusToFail(internalKeyList);
			}
		}
	}

	private void bulkUpdateStatusToFail(List<Long> internalKeyList) {
		logger.info("Updating the following internal keys to FAILED: {}", internalKeyList);
		
		Map<String, Object> params = new HashMap<>();
		params.put("status", STATUS_FAILED);
		params.put("keys", internalKeyList);
		dataService.bulkUpdateWithNamedQuery(XpsJpeConstants.MESSAGE_MASTER_JPE_UPDATE_STATUS_ERROR, params,
				MessageMasterJpe.class);
	}

	/*
	private class InternalJobOperatorImpl {
		public void startNewJobInstance(String jobName, IncomingMessageQ bdo) {
			_asynchTaskSupport.executeNoWait(new CbsAsychronousTask<Long>() {
				@Override
				public Long run() {
					try {
						// startTransaction(bdo);
						return _jobOperatorBean.startNextInstance(JOB_NAME);
					} catch (NoSuchJobException e) {
						e.printStackTrace();
					} catch (JobParametersNotFoundException e) {
						e.printStackTrace();
					} catch (JobRestartException e) {
						e.printStackTrace();
					} catch (JobExecutionAlreadyRunningException e) {
						e.printStackTrace();
					} catch (JobInstanceAlreadyCompleteException e) {
						e.printStackTrace();
					} catch (UnexpectedJobExecutionException e) {
						e.printStackTrace();
					} catch (JobParametersInvalidException e) {
						e.printStackTrace();
					}
					return null;
				}

				@Override
				public String getTaskName() {
					return "IncomingMessageListEventConsumer.startNewJobInstance";
				}

				@Override
				public void setSessionDetailsMap(Map<String, Object> sessionDetailsMap) {
				}
			});
		}
	}
	*/
}
