package com.silverlakesymmetri.cbs.xps.svc.ext;

import com.silverlakesymmetri.cbs.commons.bdo.BpmStatusEnum;
import com.silverlakesymmetri.cbs.commons.bdo.CbsBpmInfo;
import commonj.sdo.ChangeSummary;
import commonj.sdo.DataObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.silverlakesymmetri.cbs.commons.ext.impl.AbstractServiceExtPointImpl;
import com.silverlakesymmetri.cbs.mcl.bdo.sdo.Client;
import com.silverlakesymmetri.cbs.xps.svc.DepAcctClientIndService;

@Service
public class ClientIndServiceExtImpl extends AbstractServiceExtPointImpl {
	
	@Autowired
	DepAcctClientIndService depAcctClientIndService;
	
	@Override
	public String[] getExtendedBdoNames() {
		return new String[]{ "Client" };
	}

	@Override
	public String[] getExtendedServiceNames() {
		return new String[]{ "ClientService.update" };
	}

	@Override
	public void beforeService(Object[] serviceParameters) {
	}

	@Override
	public Object afterService(Object result, Object[] serviceParameters) {
		if (result != null && result instanceof Client) {
            Client dataObject = (Client) result;
            /**
             * If the transaction is still for approval. Updating client indicator should not be executed yet
             */
            if (dataObject.getHeader() != null && dataObject.getHeader().getBpmInfo() != null) {
                CbsBpmInfo cbsBpmInfo = dataObject.getHeader().getBpmInfo();
                if (cbsBpmInfo.getProcessInstanceId() != null && cbsBpmInfo.getProcessInstanceId() != 0 &&
                        cbsBpmInfo.getOutcomeStatus() != null && BpmStatusEnum.APPROVAL.getBpmStatusCode()
                        == cbsBpmInfo.getOutcomeStatus().intValue()) {
                    return dataObject;
                }
            }

            boolean isClientIndUpdated = false;

            ChangeSummary cs = dataObject.getChangeSummary();
            if (cs != null && cs.getChangedDataObjects() != null && !cs.getChangedDataObjects().isEmpty()) {
                for (Object object : cs.getChangedDataObjects()) {
                    if(cs.isModified((DataObject) object)) {
                        if(object instanceof Client){
                            DataObject obj = (DataObject) object;
                            ChangeSummary.Setting oldSett = cs.getOldValue(obj, obj.getInstanceProperty("clientIndicator"));
                            if(oldSett != null && oldSett.getValue() != null && !oldSett.getValue().toString().equalsIgnoreCase(dataObject.getClientIndicator())){
                                isClientIndUpdated = true;
                                break;
                            }
                        }
                    }
                }
            }
            if(isClientIndUpdated){
                updateAcctClientInd((Client) result);
            }
        }

        return result;
	}

	@Override
	public void beforeQuery(Object[] serviceParameters) {
	}

	@Override
	public Object afterQuery(Object result, Object[] serviceParameters) {
		return null;
	}

	@Override
	public Object afterValidationBeforeMainService(Object result) {
		return null;
	}

	private void updateAcctClientInd(Client dataObject) {		
		depAcctClientIndService.updClientAcct(dataObject);
	}
	
}
