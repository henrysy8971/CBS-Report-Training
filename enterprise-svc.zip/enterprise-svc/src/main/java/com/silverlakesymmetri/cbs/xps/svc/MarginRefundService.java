package com.silverlakesymmetri.cbs.xps.svc;

import java.util.List;
import java.util.Map;

import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation;
import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation.ServiceOperationType;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.svc.BusinessService;
import com.silverlakesymmetri.cbs.xps.bdo.sdo.MarginRefund;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.MarginRefundJpe;

public interface MarginRefundService extends BusinessService<MarginRefund, MarginRefundJpe> {
	public static final String XPS_MARGINREFUNDSERVICE_GET = "MarginRefundService.get";
    public static final String XPS_MARGINREFUNDSERVICE_FIND = "MarginRefundService.find";
    public static final String XPS_MARGINREFUNDSERVICE_QUERY = "MarginRefundService.query";
    public static final String XPS_MARGINREFUNDSERVICE_COUNT = "MarginRefundService.count";
    
    @ServiceOperation(name = XPS_MARGINREFUNDSERVICE_GET, type = ServiceOperationType.GET)
    public MarginRefund getByPk(String publicKey, MarginRefund reference);
    
    @ServiceOperation(name = XPS_MARGINREFUNDSERVICE_FIND)
    public List<MarginRefund> find(FindCriteria findCriteria, CbsHeader cbsHeader);
    
    @ServiceOperation(name = XPS_MARGINREFUNDSERVICE_QUERY)
    public List<MarginRefund> query(int offset, int resultLimit, String groupBy, String order, Map<String, Object> filters);
    
    @ServiceOperation(name = XPS_MARGINREFUNDSERVICE_COUNT, type = ServiceOperationType.GET)
    public Long count(FindCriteria findCriteria, CbsHeader cbsHeader);

}