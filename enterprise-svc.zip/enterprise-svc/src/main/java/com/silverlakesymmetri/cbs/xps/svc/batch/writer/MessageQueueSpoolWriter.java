package com.silverlakesymmetri.cbs.xps.svc.batch.writer;

import java.util.List;

import org.springframework.batch.item.ItemWriter;

import com.silverlakesymmetri.cbs.commons.jpa.service.CbsBatchGenericDataService;
import com.silverlakesymmetri.cbs.commons.logging.CbsAppLogger;
import com.silverlakesymmetri.cbs.commons.logging.CbsAppLoggerFactory;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.MessageQJpe;

public class MessageQueueSpoolWriter implements ItemWriter<MessageQJpe> {
	private CbsAppLogger logger = CbsAppLoggerFactory.getLogger(MessageQueueSpoolWriter.class.getName());

	CbsBatchGenericDataService batchDataService;
	public CbsBatchGenericDataService getBatchDataService() {
		return batchDataService;
	}
	public void setBatchDataService(CbsBatchGenericDataService batchDataService) {
		this.batchDataService = batchDataService;
	}

	@Override
	public void write(List<? extends MessageQJpe> items) throws Exception {
		if(items == null || items.isEmpty()){
			logger.warn("items is empty. Nothing to update!");
		}
		
		batchDataService.bulkUpdate(items);
	}

}
