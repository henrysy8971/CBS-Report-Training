package com.silverlakesymmetri.cbs.xps.svc.mapper;

import org.mapstruct.DecoratedWith;
import org.mapstruct.InheritInverseConfiguration;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingTarget;
import org.mapstruct.Mappings;

import com.silverlakesymmetri.cbs.commons.jpa.util.DateTimeHelper;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.ChargeInterestJpe;
import com.silverlakesymmetri.cbs.xps.svc.mapper.decorator.ChargeInterestServiceDecorator;
import com.silverlakesymmetri.cbs.xps.xmlapi.XPSTRANCHARGEDETAILAPIType;

@Mapper(uses = { DateTimeHelper.class, ChargeRatedSlabServiceMapper.class })
@DecoratedWith(ChargeInterestServiceDecorator.class)
public interface ChargeInterestServiceMapper {

	@Mappings({
		@Mapping(source="rateLadder", target = "RATELADDER"),
		@Mapping(source="noOfDays", target = "NOOFDAYS"),
		@Mapping(source="graceInd", target = "GRACEIND"),
		@Mapping(source="graceDays", target = "GRACEDAYS"),
		@Mapping(source="startDate", target = "STARTDATE", qualifiedByName = {"DateTimeHelper", "convertDateToCbsXmlApiDate"}),
		@Mapping(source="endDate", target = "ENDDATE", qualifiedByName = {"DateTimeHelper", "convertDateToCbsXmlApiDate"}),
		@Mapping(source="setupCcy", target = "SETUPCCY"),
		@Mapping(source="yearBasis", target = "YEARBASIS"),
		@Mapping(source="amtType", target = "AMTTYPE"),
		@Mapping(source="basisAmt", target = "BASISAMT"),
		@Mapping(source="basisCcy", target = "BASISCCY"),
		@Mapping(source="basisCalcAmt", target = "BASISCALCAMT"),
		@Mapping(source="exchRate", target = "EXCHRATE"),
		@Mapping(source="exchQuote", target = "EXCHQUOTE"),
		//@Mapping(source="ccy", target = ""), value from ChargeMaster
		@Mapping(source="amount", target = "AMOUNT"),
		@Mapping(source="calculatedAmt", target = "CALCULATEDAMT"),
		@Mapping(source="ratedSlabList", target = "SLABS.XPSTRANCHARGEDETAILSLABTYPE")
	})
	public XPSTRANCHARGEDETAILAPIType mapToApi(ChargeInterestJpe jpe, @MappingTarget XPSTRANCHARGEDETAILAPIType api);

	@InheritInverseConfiguration(name = "mapToApi")
	@Mappings({
		@Mapping(source = "STARTDATE", target = "startDate", qualifiedByName = {"DateTimeHelper", "convertCbsApiDateToString"}),
		@Mapping(source = "ENDDATE", target = "endDate", qualifiedByName = {"DateTimeHelper", "convertCbsApiDateToString"})
	})
	public ChargeInterestJpe mapToJpe(XPSTRANCHARGEDETAILAPIType api, @MappingTarget ChargeInterestJpe jpe);

	@InheritInverseConfiguration(name = "mapToApi")
	@Mappings({
		@Mapping(source = "STARTDATE", target = "startDate", qualifiedByName = {"DateTimeHelper", "convertCbsApiDateToString"}),
		@Mapping(source = "ENDDATE", target = "endDate", qualifiedByName = {"DateTimeHelper", "convertCbsApiDateToString"})
	})
	public ChargeInterestJpe mapToJpe(XPSTRANCHARGEDETAILAPIType api);
}