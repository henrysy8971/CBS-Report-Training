package com.silverlakesymmetri.cbs.swf.svc;


import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation;
import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation.ServiceOperationType;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.svc.BusinessService;
import com.silverlakesymmetri.cbs.swf.bdo.sdo.SwfMsgFormatQry;
import com.silverlakesymmetri.cbs.swf.jpa.mapping.sdo.SwfMsgFormatQryJpe;

import java.util.List;
import java.util.Map;

public interface SwfMsgFormatQryService extends BusinessService<SwfMsgFormatQry, SwfMsgFormatQryJpe> {

    String SVC_OP_NAME_SWF_MSG_FORMAT_QRY_SERVICE_GET = "SwfMsgFormatQryService.get";
    String SVC_OP_NAME_SWF_MSG_FORMAT_QRY_SERVICE_QUERY = "SwfMsgFormatQryService.query";
    String SVC_OP_NAME_SWF_MSG_FORMAT_QRY_SERVICE_FIND = "SwfMsgFormatQryService.find";
    String SVC_OP_NAME_SWF_MSG_FORMAT_QRY_SERVICE_COUNT = "SwfMsgFormatQryService.count";

    @ServiceOperation(name = SVC_OP_NAME_SWF_MSG_FORMAT_QRY_SERVICE_GET, type = ServiceOperationType.GET)
    SwfMsgFormatQry getByPk(String publicKey, SwfMsgFormatQryService reference);

    @ServiceOperation(name = SVC_OP_NAME_SWF_MSG_FORMAT_QRY_SERVICE_QUERY)
    List<SwfMsgFormatQry> query(int offset, int resultLimit, String groupBy, String order, Map<String, Object> filters);

    @ServiceOperation(name = SVC_OP_NAME_SWF_MSG_FORMAT_QRY_SERVICE_FIND)
    List<SwfMsgFormatQry> find(FindCriteria findCriteria, CbsHeader cbsHeader);

    @ServiceOperation(name = SVC_OP_NAME_SWF_MSG_FORMAT_QRY_SERVICE_COUNT, type = ServiceOperationType.GET)
    public Long count(FindCriteria findCriteria, CbsHeader cbsHeader);

}
