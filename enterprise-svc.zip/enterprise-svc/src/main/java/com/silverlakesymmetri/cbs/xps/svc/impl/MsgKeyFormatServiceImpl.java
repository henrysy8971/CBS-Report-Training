package com.silverlakesymmetri.cbs.xps.svc.impl;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.mysema.query.types.EntityPath;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.svc.AbstractBusinessService;
import com.silverlakesymmetri.cbs.commons.svc.BusinessObjectValidationCapable;
import com.silverlakesymmetri.cbs.xps.bdo.sdo.MsgKeyFormat;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.MsgKeyFormatJpe;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.QMsgKeyFormatJpe;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.id.MsgKeyFormatPk;
import com.silverlakesymmetri.cbs.xps.svc.MsgKeyFormatService;

@Service
@Transactional
public class MsgKeyFormatServiceImpl extends AbstractBusinessService<MsgKeyFormat, MsgKeyFormatJpe, MsgKeyFormatPk> implements MsgKeyFormatService, BusinessObjectValidationCapable<MsgKeyFormat>{

	@Override
	protected MsgKeyFormatPk getIdFromDataObjectInstance(MsgKeyFormat dataObject) {
		MsgKeyFormatPk msgKeyFormatPk = new MsgKeyFormatPk(dataObject.getModuleCode(), dataObject.getValue());
		msgKeyFormatPk.setModuleCode(dataObject.getModuleCode());
		msgKeyFormatPk.setValue(dataObject.getValue());
		return msgKeyFormatPk; 
		
	}

	@Override
	protected EntityPath<MsgKeyFormatJpe> getEntityPath() {
		return QMsgKeyFormatJpe.msgKeyFormatJpe;
	}

	@Override
	public MsgKeyFormat get(MsgKeyFormat objectInstanceIdentifier) {
		return super.get(objectInstanceIdentifier);
	}

	@Override
	public List<MsgKeyFormat> query(int offset, int resultLimit, String groupBy, String order,
			Map<String, Object> filters) {
		return super.query(offset, resultLimit, groupBy, order, filters);
	}

	@Override
	public List<MsgKeyFormat> find(FindCriteria findCriteria, CbsHeader cbsHeader) {
		return super.find(findCriteria, cbsHeader);
	}

	@Override
	public MsgKeyFormat getByPk(String publicKey, MsgKeyFormat reference) {
		return super.getByPk(publicKey, reference);
	}

}
