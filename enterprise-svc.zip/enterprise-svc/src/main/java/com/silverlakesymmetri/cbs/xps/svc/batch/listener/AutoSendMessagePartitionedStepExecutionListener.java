package com.silverlakesymmetri.cbs.xps.svc.batch.listener;

import org.apache.commons.lang3.StringUtils;
import org.springframework.batch.core.StepExecution;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.silverlakesymmetri.cbs.commons.batch.listener.CbsPartitionedStepExecutionListener;
import com.silverlakesymmetri.cbs.commons.exception.base.CbsServiceException;
import com.silverlakesymmetri.cbs.xps.enums.XpsGlobalConstants;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.util.XpsStorHelper;
import com.silverlakesymmetri.cbs.xps.svc.batch.processor.MessageQueueListItemProcessor;

@Transactional
@Component
public class AutoSendMessagePartitionedStepExecutionListener extends CbsPartitionedStepExecutionListener {

	@Autowired
	protected XpsStorHelper xpsStorHelper;

	@Override
	public void beforeStep(StepExecution stepExecution) {
		super.beforeStep(stepExecution);

		// add MessageQueueListItemProcessor field values for binding
		stepExecution.getExecutionContext().put(MessageQueueListItemProcessor.SWIFT_FILE_NAME_ATTR,
				getSwiftSpoolFileName());
	}

	protected String getSwiftSpoolFileName() {
		String fileName = xpsStorHelper.getFileName(null, null, XpsGlobalConstants.SWIFT_FORMAT);
		if (StringUtils.isBlank(fileName)) {
			throw new CbsServiceException("Created file name is empty!");
		}
		return fileName;
	}

}
