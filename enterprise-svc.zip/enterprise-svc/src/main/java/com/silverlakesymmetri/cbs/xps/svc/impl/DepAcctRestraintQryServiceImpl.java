package com.silverlakesymmetri.cbs.xps.svc.impl;

import com.mysema.query.types.EntityPath;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.svc.AbstractBusinessService;
import com.silverlakesymmetri.cbs.xps.bdo.sdo.DepAcctRestraintQry;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.DepAcctRestraintQryJpe;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.QDepAcctRestraintQryJpe;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.id.DepAcctRestraintQryPk;
import com.silverlakesymmetri.cbs.xps.svc.DepAcctRestraintQryService;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Map;

@Service
@Transactional
public class DepAcctRestraintQryServiceImpl extends AbstractBusinessService<DepAcctRestraintQry, DepAcctRestraintQryJpe, DepAcctRestraintQryPk>
        implements DepAcctRestraintQryService {

    @Override
    protected DepAcctRestraintQryPk getIdFromDataObjectInstance(DepAcctRestraintQry dataObject) {
        return new DepAcctRestraintQryPk(dataObject.getSeqNo());
    }

    @Override
    protected EntityPath<DepAcctRestraintQryJpe> getEntityPath() {
        return QDepAcctRestraintQryJpe.depAcctRestraintQryJpe;
    }

    @Override
    public List<DepAcctRestraintQry> query(int offset, int resultLimit, String groupBy, String order, Map<String, Object> filters) {
        return super.query(offset, resultLimit, groupBy, order, filters);
    }

    @Override
    public List<DepAcctRestraintQry> find(FindCriteria findCriteria, CbsHeader cbsHeader) {
        return super.find(findCriteria, cbsHeader);
    }

    @Override
    public DepAcctRestraintQry getByPk(String publicKey, DepAcctRestraintQry reference) {
        return super.getByPk(publicKey, reference);
    }
}
