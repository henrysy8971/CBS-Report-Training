package com.silverlakesymmetri.cbs.xps.svc.batch.processor;

import com.silverlakesymmetri.cbs.commons.bdo.CbsBusinessDataObject;
import com.silverlakesymmetri.cbs.commons.exception.CbsRuntimeException;
import com.silverlakesymmetri.cbs.commons.logging.CbsAppLogger;
import com.silverlakesymmetri.cbs.commons.logging.CbsAppLoggerFactory;
import com.silverlakesymmetri.cbs.xps.svc.batch.XmlApiBpmTaskResolver;
import com.silverlakesymmetri.cbs.xps.util.BpmTaskParamObject;
import commonj.sdo.DataObject;
import org.apache.commons.lang3.StringUtils;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.Map;

public abstract class IncomingMessagePendingTranBaseProcessor<T> implements ItemProcessor<T, BpmTaskParamObject> {
	private final CbsAppLogger logger = CbsAppLoggerFactory.getLogger(IncomingMessagePendingTranBaseProcessor.class.getName());

	@Autowired
	XmlApiBpmTaskResolver resolver;

	protected abstract Object getUniqueId(T item);
	protected abstract String getXmlTranDetails(T item);
	protected abstract String getTranRefNo(T item);

	@Override
	public BpmTaskParamObject process(T item) throws Exception {
		if (item == null) {
			logger.error("Item to be processed is null. Processing will fail");
			throw new CbsRuntimeException("Item to be processed is null. Cannot proceed!");
		}
		if (getUniqueId(item) == null) {
			logger.error("Cannot retrieve unique ID. Processing will fail");
			throw new CbsRuntimeException("Cannot retrieve unique ID. Cannot proceed!");
		}
		/*if (StringUtils.isBlank(getTranRefNo(item))) {
			logger.error("Cannot retrieve Transaction Reference Number. Processing will fail");
			throw new CbsRuntimeException("Cannot retrieve Transaction Reference Number. Cannot proceed!");
		}*/

		String xmlString = getXmlTranDetails(item);

		if (StringUtils.isBlank(xmlString)) {
			throw new CbsRuntimeException("Xml string is empty. Cannot proceed!");
		}
		
		DataObject sdo = resolver.mapToBdo(xmlString);
		if (sdo == null) {
			throw new CbsRuntimeException("Cannot retrieve bdo. Cannot proceed!");
		}
		
		CbsBusinessDataObject bdo = (CbsBusinessDataObject) sdo;
		
		String apiName = resolver.getApiName(xmlString);
		Map<String, String> apiDetails = resolver.getApiDetails(apiName);

		BpmTaskParamObject bpmObj = new BpmTaskParamObject();
		bpmObj.setInternalKey((Long) getUniqueId(item));
		bpmObj.setBdo(bdo);
		bpmObj.setServiceOperation(apiDetails.get(XmlApiBpmTaskResolver.SERVICE_NAME_KEY));
		bpmObj.setScreenUrl(apiDetails.get(XmlApiBpmTaskResolver.SCREEN_URL_KEY));
		bpmObj.setActivityName(apiDetails.get(XmlApiBpmTaskResolver.ACTIVITY_NAME_KEY));
		if (StringUtils.isBlank(getTranRefNo(item))) {
			//default BPM display
			bpmObj.setReferenceNo("new");
		} else {
			bpmObj.setReferenceNo(getTranRefNo(item));	
		}

		return bpmObj;
	}

}
