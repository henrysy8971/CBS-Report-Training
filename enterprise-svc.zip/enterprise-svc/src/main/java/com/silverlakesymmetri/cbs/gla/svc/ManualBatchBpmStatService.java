package com.silverlakesymmetri.cbs.gla.svc;

import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation;
import com.silverlakesymmetri.cbs.commons.svc.BusinessService;
import com.silverlakesymmetri.cbs.gla.bdo.sdo.ManualBatchBpmStat;
import com.silverlakesymmetri.cbs.gla.jpa.mapping.sdo.ManualBatchBpmStatJpe;

import java.util.Map;

/**
 * Created by Emerson.Sanchez on 20/12/2022.
 */
public interface ManualBatchBpmStatService {
    public static final String SVC_OP_NAME_MANUAL_BATCH_BPM_STAT_SERVICE_UNAPPROVED = "manualBatchBpmStatService.unapproved";
    public static final String SVC_OP_NAME_MANUAL_BATCH_BPM_STAT_SERVICE_APPROVED = "manualBatchBpmStatService.approved";

    @ServiceOperation(name = SVC_OP_NAME_MANUAL_BATCH_BPM_STAT_SERVICE_UNAPPROVED, type = ServiceOperation.ServiceOperationType.GET)
    public ManualBatchBpmStat getUnapproved();

    @ServiceOperation(name = SVC_OP_NAME_MANUAL_BATCH_BPM_STAT_SERVICE_APPROVED,
            type = ServiceOperation.ServiceOperationType.EXECUTE, passParamAsMap = true)
    public ManualBatchBpmStat getApproved(Map<String, Object> params);
}
