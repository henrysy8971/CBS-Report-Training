package com.silverlakesymmetri.cbs.swf.svc.impl;

import com.mysema.query.types.EntityPath;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.svc.AbstractBusinessService;
import com.silverlakesymmetri.cbs.commons.svc.BusinessObjectValidationCapable;
import com.silverlakesymmetri.cbs.swf.bdo.sdo.SwiftCodewordValidate;
import com.silverlakesymmetri.cbs.swf.jpa.mapping.sdo.QSwiftCodewordValidateJpe;
import com.silverlakesymmetri.cbs.swf.jpa.mapping.sdo.SwiftCodewordValidateJpe;
import com.silverlakesymmetri.cbs.swf.jpa.mapping.sdo.id.SwiftCodewordValidatePk;
import com.silverlakesymmetri.cbs.swf.svc.SwiftCodewordValidateService;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Map;

@Service
@Transactional
public class SwiftCodewordValidateServiceImpl extends AbstractBusinessService<SwiftCodewordValidate, SwiftCodewordValidateJpe, SwiftCodewordValidatePk>
        implements SwiftCodewordValidateService, BusinessObjectValidationCapable<SwiftCodewordValidate> {

    @Override
    protected SwiftCodewordValidatePk getIdFromDataObjectInstance(SwiftCodewordValidate dataObject) {
    	SwiftCodewordValidatePk key = new SwiftCodewordValidatePk(dataObject.getMessageType(), dataObject.getTag(), dataObject.getRefCodeValue());
        return key;
    }

    @Override
    protected EntityPath<SwiftCodewordValidateJpe> getEntityPath() {
        return QSwiftCodewordValidateJpe.swiftCodewordValidateJpe;
    }

    @Override
    public SwiftCodewordValidate get(SwiftCodewordValidate objectInstanceIdentifier) {
        return super.get(objectInstanceIdentifier);
    }

    @Override
    public List<SwiftCodewordValidate> query(int offset, int resultLimit, String groupBy, String order,
                                    Map<String, Object> filters) {
        return super.query(offset, resultLimit, groupBy, order, filters);
    }

    @Override
    public List<SwiftCodewordValidate> find(FindCriteria findCriteria, CbsHeader cbsHeader) {
        return super.find(findCriteria, cbsHeader);
    }

    @Override
    public SwiftCodewordValidate getByPk(String publicKey, SwiftCodewordValidate reference) {
        return super.getByPk(publicKey, reference);
    }

}
