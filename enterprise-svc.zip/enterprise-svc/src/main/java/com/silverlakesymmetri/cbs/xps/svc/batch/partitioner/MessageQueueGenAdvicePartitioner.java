package com.silverlakesymmetri.cbs.xps.svc.batch.partitioner;

import org.apache.commons.lang3.StringUtils;

import com.silverlakesymmetri.cbs.commons.batch.svc.impl.CustomQueryPartitioningServiceImpl;
import com.silverlakesymmetri.cbs.commons.logging.CbsAppLogger;
import com.silverlakesymmetri.cbs.commons.logging.CbsAppLoggerFactory;

public class MessageQueueGenAdvicePartitioner extends CustomQueryPartitioningServiceImpl {
	
	private static CbsAppLogger logger = CbsAppLoggerFactory.getLogger(MessageQueueGenAdvicePartitioner.class);
	
	private static final String SQL_QUERY =
			"SELECT DISTINCT PARTITION_KEY, FROM_ID||'~'||TO_ID AS BDO_PUBLIC_KEY "
			+ "FROM ( "
			+ "	SELECT "
			+ "		PARTITION_KEY, "
			+ "		min([SELECT_CLAUSE]) OVER(PARTITION BY PARTITION_KEY) AS FROM_ID, "
			+ "		max([SELECT_CLAUSE]) OVER(PARTITION BY PARTITION_KEY) AS TO_ID "
			+ "	FROM( "
			+ "		SELECT "
			+ "		      INNER_QRY.*, "
			+ "		      FLOOR(OVERALL_SUM / [PARTITION_SIZE]) AS PARTITION_KEY "
			+ "		    FROM "
			+ "		      ( "
			+ "		        SELECT "
			+ "		          [SELECT_CLAUSE], "
			+ "		          SUM(1) OVER( "
			+ "		            ORDER BY "
			+ "		              [SELECT_CLAUSE] "
			+ "		          ) AS OVERALL_SUM, "
			+ "		          COUNT(*) OVER() AS OVERALL_CNT "
			+ "		        FROM "
			+ "		          [TABLE_NAME] [WHERE_CLAUSE] "
			+ "		      ) INNER_QRY "
			+ "	) "
			+ ") "
			;

	@Override
	protected String buildNativeAnalyticalQuery(String partitioningType, String dbTableName, String selectClause,
			String whereClause, String groupByClause, int partitionCount, int partitionSize) {
		
		String returnQuery = StringUtils.replaceEach(SQL_QUERY,
				new String[] { "[SELECT_CLAUSE]", "[PARTITION_SIZE]", "[TABLE_NAME]", "[WHERE_CLAUSE]" },
				new String[] { selectClause, Integer.valueOf(partitionSize).toString(), dbTableName, whereClause });

		logger.debug("select statement is: {}", returnQuery);

		return returnQuery;
	}
	
}
