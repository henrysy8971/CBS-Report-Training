package com.silverlakesymmetri.cbs.swf.svc.mapper.decorator;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

import com.silverlakesymmetri.cbs.swf.jpa.mapping.sdo.SwfFinEntityJpe;
import com.silverlakesymmetri.cbs.swf.svc.mapper.mapping.SwfF55Mapper;
import com.silverlakesymmetri.cbs.swf.xmlapi.SWFF55TYPEType;

public abstract class SwfF55MapperDecorator implements SwfF55Mapper {
	
	@Autowired
	@Qualifier("delegate")
	protected SwfF55Mapper delegate;

	@Override
	public SWFF55TYPEType mapToApi(SwfFinEntityJpe jpe){
		SWFF55TYPEType swfF55 = delegate.mapToApi(jpe);
		if(swfF55 != null && swfF55.getACCOUNT() == null && swfF55.getADDRESS() == null && swfF55.getBIC() == null && swfF55.getBRANCHLOCATION() == null){
			return null;
		}
		return swfF55;
	}
	
	@Override
	public SwfFinEntityJpe mapToJpe(SWFF55TYPEType api){
		return delegate.mapToJpe(api);
	}
	
}
