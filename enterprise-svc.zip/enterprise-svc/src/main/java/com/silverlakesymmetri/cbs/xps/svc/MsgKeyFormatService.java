package com.silverlakesymmetri.cbs.xps.svc;

import java.util.List;
import java.util.Map;

import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation;
import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation.ServiceOperationType;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.svc.BusinessService;
import com.silverlakesymmetri.cbs.xps.bdo.sdo.MsgKeyFormat;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.MsgKeyFormatJpe;

/**
*
*  Service is used to Read, Create, Update, Delete MsgKeyFormat data.
*
* @author      rvo
* @since       2019-09-13
*/
public interface MsgKeyFormatService extends BusinessService<MsgKeyFormat, MsgKeyFormatJpe> {

    public static final String SVC_OP_NAME_MSGKEYFORMATSERVICE_GET = "MsgKeyFormatService.get";
    public static final String SVC_OP_NAME_MSGKEYFORMATSERVICE_QUERY = "MsgKeyFormatService.query";
    public static final String SVC_OP_NAME_MSGKEYFORMATSERVICE_CREATE = "MsgKeyFormatService.create";
    public static final String SVC_OP_NAME_MSGKEYFORMATSERVICE_UPDATE = "MsgKeyFormatService.update";
    public static final String SVC_OP_NAME_MSGKEYFORMATSERVICE_DELETE = "MsgKeyFormatService.delete";
    public static final String SVC_OP_NAME_MSGKEYFORMATSERVICE_FIND = "MsgKeyFormatService.find";
    
    @ServiceOperation(name = SVC_OP_NAME_MSGKEYFORMATSERVICE_GET, type = ServiceOperationType.GET)
    public MsgKeyFormat getByPk(String publicKey, MsgKeyFormat reference);

    @ServiceOperation(name = SVC_OP_NAME_MSGKEYFORMATSERVICE_CREATE)
    public MsgKeyFormat create(MsgKeyFormat dataObject);

    @ServiceOperation(name = SVC_OP_NAME_MSGKEYFORMATSERVICE_UPDATE)
    public MsgKeyFormat update(MsgKeyFormat dataObject);

    @ServiceOperation(name = SVC_OP_NAME_MSGKEYFORMATSERVICE_DELETE)
    public boolean delete(MsgKeyFormat dataObject);

    @ServiceOperation(name = SVC_OP_NAME_MSGKEYFORMATSERVICE_QUERY)
    public List<MsgKeyFormat> query(int offset, int resultLimit, String groupBy, String order, Map<String, Object> filters);

    @ServiceOperation(name = SVC_OP_NAME_MSGKEYFORMATSERVICE_FIND)
    public List<MsgKeyFormat> find(FindCriteria findCriteria, CbsHeader cbsHeader);


}
