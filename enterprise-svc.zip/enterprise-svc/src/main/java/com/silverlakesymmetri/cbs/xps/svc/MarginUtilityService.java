package com.silverlakesymmetri.cbs.xps.svc;

import java.util.List;
import java.util.Map;

import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation;
import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation.ServiceOperationType;
import com.silverlakesymmetri.cbs.xps.bdo.sdo.MarginInstrumentInfo;
import com.silverlakesymmetri.cbs.xps.bdo.sdo.MarginUtilizationInfo;
import com.silverlakesymmetri.cbs.xps.bdo.sdo.MsgGrpDefQry;
import com.silverlakesymmetri.cbs.xps.bdo.sdo.MsgGrpTypeQry;

public interface MarginUtilityService {
	public static final String SVC_OP_NAME_MARGINUTILLITYSERVICE_GET_MARGIN_INSTRUMENT_INFO = "MarginUtilityService.getMarginInstrumentInfo";
	public static final String SVC_OP_NAME_MARGINUTILLITYSERVICE_GET_MSG_GRP_TYPE_QRY_LIST = "MarginUtilityService.getMsgGrpTypeQryList";
	public static final String SVC_OP_NAME_MARGINUTILLITYSERVICE_GET_MSG_GRP_DEF_QRY_LIST = "MarginUtilityService.getMsgGrpDefQryList";
	public static final String SVC_OP_NAME_MARGINUTILLITYSERVICE_GET_MARGIN_UTILIZATION_INFO = "MarginUtilityService.getMarginUtilizationInfo";

	@ServiceOperation(name = SVC_OP_NAME_MARGINUTILLITYSERVICE_GET_MARGIN_INSTRUMENT_INFO, passParamAsMap = true)
    public MarginInstrumentInfo getMarginInstrumentInfo(Map<String, Object> params);

	@ServiceOperation(name = SVC_OP_NAME_MARGINUTILLITYSERVICE_GET_MSG_GRP_TYPE_QRY_LIST, type = ServiceOperationType.READ)
    public List<MsgGrpTypeQry> getMsgGrpTypeQryList(String domain, String eventType, String prodType);

	@ServiceOperation(name = SVC_OP_NAME_MARGINUTILLITYSERVICE_GET_MSG_GRP_DEF_QRY_LIST, type = ServiceOperationType.READ)
    public List<MsgGrpDefQry> getMsgGrpDefQryList(String domain, String msgGrp, String eventType, String prodType);
	
	public MarginUtilizationInfo getMarginUtilizationInfo(Long internalKey);

}
