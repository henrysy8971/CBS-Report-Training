package com.silverlakesymmetri.cbs.gla.svc.impl;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.mysema.query.types.EntityPath;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.svc.AbstractBusinessService;
import com.silverlakesymmetri.cbs.gla.bdo.sdo.GlAccount;
import com.silverlakesymmetri.cbs.gla.jpa.mapping.sdo.GlAccountJpe;
import com.silverlakesymmetri.cbs.gla.svc.GlAccountDistinctSeqNoService;
import com.silverlakesymmetri.cbs.gla.jpa.mapping.sdo.QGlAccountJpe;
import com.silverlakesymmetri.cbs.gla.jpa.mapping.sdo.util.GlaJpeConstants;
import com.silverlakesymmetri.cbs.mcl.jpa.mapping.sdo.util.MclJpeConstants;


@Service
@Transactional
public class GlAccountDistinctSeqNoServiceImpl extends AbstractBusinessService<GlAccount, GlAccountJpe, Long> implements GlAccountDistinctSeqNoService{
	
	private static final String BRANCH = "branch";
	private static final String CLIENT_NO = "clientNo";
	
	@Override
	protected Long getIdFromDataObjectInstance(GlAccount dataObject) {
		Map<String, Object> params = new HashMap<String, Object>();
        params.put(BRANCH, dataObject.getBranch());
        params.put("ccy", dataObject.getCcy());
        params.put("clientId", getClientId(dataObject.getClientNo()));
        params.put("profitCentre", dataObject.getProfitCentre());
        params.put("glCode", dataObject.getGlCode());
        params.put("seqNo", dataObject.getSeqNo());
        Long result = dataService.getWithNamedQuery(GlaJpeConstants.GLA_ACCOUNT_JPE_FIND_BY_PUBLIC_KEY, params, Long.class);
        
        return result;
	}

	@Override
	protected EntityPath<GlAccountJpe> getEntityPath() {
		return QGlAccountJpe.glAccountJpe;
	}
	
	private Long getClientId(String clientNo) {
        Map<String, Object> params = new HashMap<String, Object>();
        params.put(CLIENT_NO, clientNo);
        Long clientId = dataService.getWithNamedQuery(MclJpeConstants.CLIENT_JPE_FIND_CLIENT_ID_USING_CLIENT_NO, params, Long.class);       
        
        return clientId;
    }
	
	@Override
	public List<GlAccount> query(int offset, int resultLimit, String groupBy, String order,
			Map<String, Object> filters){
		
		List<GlAccount> list = new ArrayList<>();
		list = (List<GlAccount>) this.queryDistinct(offset, resultLimit, filters);
		return list;
	}
	
	
	private List<GlAccount> queryDistinct(int offset, int resultLimit, Map<String, Object> filters)
    {
    	List<GlAccount> glAccountList = new ArrayList<>();
    	
    	String distinctSeqNo = "SELECT DISTINCT NEW com.silverlakesymmetri.cbs.gla.jpa.mapping.sdo.GlAccountJpe(r.seqNo) from GlAccountJpe r";
    	StringBuilder criteria = new StringBuilder(distinctSeqNo);
    	
    	
    	if(filters.containsKey("seqNo")) {
			filters.put("seqNo", Integer.valueOf(filters.get("seqNo").toString()));
			criteria.append(" WHERE r.seqNo = :seqNo");
		}
    	
    	List<GlAccountJpe> jpeList = (List<GlAccountJpe>) dataService.findWithQuery(criteria.toString(), filters, offset, resultLimit, GlAccountJpe.class);
    	if(jpeList != null && !jpeList.isEmpty())
    	{
    		for(GlAccountJpe jpe : jpeList)
    		{
    			glAccountList.add(jaxbSdoHelper.wrap(jpe, GlAccount.class));
    		}
    	}
    	return glAccountList;
    }
	
	@Override
	public List<GlAccount> find(FindCriteria findCriteria, CbsHeader cbsHeader) {
		return super.find(findCriteria, cbsHeader);
	}
}
