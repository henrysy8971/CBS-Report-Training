package com.silverlakesymmetri.cbs.swf.svc.mapper.mapping;

import org.apache.commons.lang3.StringUtils;
import org.mapstruct.DecoratedWith;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Mappings;

import com.silverlakesymmetri.cbs.swf.jpa.mapping.sdo.SwfCustomerIdJpe;
import com.silverlakesymmetri.cbs.swf.svc.mapper.decorator.SwfCustomerIdMapperDecorator;
import com.silverlakesymmetri.cbs.swf.xmlapi.SWFCUSTOMERIDTYPEType;

@Mapper(imports = StringUtils.class)
@DecoratedWith(SwfCustomerIdMapperDecorator.class)
public interface SwfCustomerIdMapper {
	@Mappings({
		@Mapping(source="code", target="CODE"),
		@Mapping(source="country", target="COUNTRY"),
		@Mapping(source="id", target="ID")
	})
	SWFCUSTOMERIDTYPEType mapToApi(SwfCustomerIdJpe jpe);
	
	@Mappings({
		@Mapping(target="code", expression="java(StringUtils.isNotBlank(api.getCODE())?api.getCODE():null)"),
		@Mapping(target="country", expression="java(StringUtils.isNotBlank(api.getCOUNTRY())?api.getCOUNTRY():null)"),
		@Mapping(target="id", expression="java(StringUtils.isNotBlank(api.getID())?api.getID():null)"),
	})
	SwfCustomerIdJpe mapToJpe(SWFCUSTOMERIDTYPEType api);
}