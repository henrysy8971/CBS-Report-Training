package com.silverlakesymmetri.cbs.xps.svc.mapper.decorator;

import javax.inject.Inject;

import org.mapstruct.Context;
import org.mapstruct.MappingTarget;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

import com.silverlakesymmetri.cbs.commons.jpa.extension.JaxbSdoHelper;
import com.silverlakesymmetri.cbs.commons.jpa.util.BdoHelper;
import com.silverlakesymmetri.cbs.commons.xmlapi.enums.CbsXmlApiOperation;
import com.silverlakesymmetri.cbs.mcl.svc.ClientService;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.MarginMasterJpe;
import com.silverlakesymmetri.cbs.xps.svc.mapper.MarginMasterServiceMapper;
import com.silverlakesymmetri.cbs.xps.xmlapi.XPSTRANMARGINAPIType;

public abstract class MarginMasterServiceDecorator implements MarginMasterServiceMapper {
	
	@Autowired
	@Qualifier("delegate")
	protected MarginMasterServiceMapper delegate;
	
	@Autowired
	protected ClientService clientService;

	@Inject
    private BdoHelper bdoHelper;

	@Inject
	private JaxbSdoHelper jaxbSdoHelper;

	@Override
	public XPSTRANMARGINAPIType mapToApi(MarginMasterJpe jpe, @Context CbsXmlApiOperation oper){
		XPSTRANMARGINAPIType req = (XPSTRANMARGINAPIType) delegate.mapToApi(jpe, oper);
		return  req;
	}
	
	@Override
	public MarginMasterJpe mapToJpe(XPSTRANMARGINAPIType api, @MappingTarget MarginMasterJpe jpe){
		delegate.mapToJpe(api, jpe);
		return jpe;
	}

}


