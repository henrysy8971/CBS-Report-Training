package com.silverlakesymmetri.cbs.xps.svc.impl;

import com.mysema.query.types.EntityPath;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.helper.jpa.LinkTable;
import com.silverlakesymmetri.cbs.commons.helper.jpa.QueryCondition;
import com.silverlakesymmetri.cbs.commons.helper.jpa.QueryType;
import com.silverlakesymmetri.cbs.commons.jpa.entity.FindCriteriaJpe;
import com.silverlakesymmetri.cbs.commons.svc.AbstractBusinessService;
import com.silverlakesymmetri.cbs.commons.svc.BusinessObjectValidationCapable;
import com.silverlakesymmetri.cbs.pim.jpa.mapping.sdo.MasterDepositAcctQryJpe;
import com.silverlakesymmetri.cbs.xps.bdo.sdo.ScUncollQry;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.QScUncollQryJpe;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.ScUncollQryJpe;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.id.ScUncollQryPk;
import com.silverlakesymmetri.cbs.xps.svc.ScUncollQryService;
import org.springframework.stereotype.Service;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

@Service
public class ScUncollQryServiceImpl extends AbstractBusinessService<ScUncollQry, ScUncollQryJpe, ScUncollQryPk>
        implements ScUncollQryService, BusinessObjectValidationCapable<ScUncollQry> {

    private static LinkedHashMap<String, LinkTable> constructorMap;

    private static QueryCondition queryCondition;

    static {
        constructorMap = new LinkedHashMap<String, LinkTable>();
        constructorMap.put("acctNo", new LinkTable(MasterDepositAcctQryJpe.class));
        constructorMap.put("scUncollSeqNo", new LinkTable(ScUncollQryJpe.class));
        constructorMap.put("scUncollDate", new LinkTable(ScUncollQryJpe.class));
        constructorMap.put("scType", new LinkTable(ScUncollQryJpe.class));
        constructorMap.put("scRateType", new LinkTable(ScUncollQryJpe.class));
        constructorMap.put("origScAmt", new LinkTable(ScUncollQryJpe.class));
        constructorMap.put("origScTaxAmt", new LinkTable(ScUncollQryJpe.class));
        constructorMap.put("uncollScAmt", new LinkTable(ScUncollQryJpe.class));
        constructorMap.put("uncollScTaxAmt", new LinkTable(ScUncollQryJpe.class));
        constructorMap.put("lastScUncollDate", new LinkTable(ScUncollQryJpe.class));

        queryCondition = new QueryCondition();
        queryCondition.where("internalKey", QueryType.EQUALS, new LinkTable(MasterDepositAcctQryJpe.class, "internalKey"));
    }

    @Override
    protected ScUncollQryPk getIdFromDataObjectInstance(ScUncollQry dataObject) {
        ScUncollQryJpe jpe = jaxbSdoHelper.unwrap(dataObject);
        return new ScUncollQryPk(jpe.getInternalKey(), jpe.getScUncollSeqNo(), jpe.getScUncollDate());
    }

    @Override
    protected EntityPath<ScUncollQryJpe> getEntityPath() {
        return QScUncollQryJpe.scUncollQryJpe;
    }

    @Override
    public List<ScUncollQry> query(int offset, int resultLimit, String groupBy, String order, Map<String, Object> filters) {
        QueryCondition newCondition = convertFilters(queryCondition, filters, constructorMap);
        return super.query(newCondition, offset, resultLimit, groupBy, order, constructorMap);
    }

    @Override
    public List<ScUncollQry> find(FindCriteria findCriteria, CbsHeader cbsHeader) {
        return super.find(findCriteria, cbsHeader, constructorMap, queryCondition);

    }

    @Override
    public ScUncollQry getByPk(String publicKey, ScUncollQry reference) {
        return super.getByPk(publicKey, reference);
    }

    @Override
    public Long count(FindCriteria findCriteria, CbsHeader cbsHeader) {
        FindCriteriaJpe jpe = jaxbSdoHelper.unwrap(findCriteria, FindCriteriaJpe.class);
        return dataService.getRowCount(ScUncollQryJpe.class, jpe, constructorMap, queryCondition);
    }
}
