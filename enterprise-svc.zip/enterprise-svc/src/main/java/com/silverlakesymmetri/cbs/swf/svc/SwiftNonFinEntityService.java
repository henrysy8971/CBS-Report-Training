package com.silverlakesymmetri.cbs.swf.svc;

import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation;
import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation.ServiceOperationType;
import com.silverlakesymmetri.cbs.commons.svc.BusinessService;
import com.silverlakesymmetri.cbs.swf.bdo.sdo.SwfNonFinEntity;
import com.silverlakesymmetri.cbs.swf.jpa.mapping.sdo.SwfNonFinEntityJpe;

public interface SwiftNonFinEntityService extends BusinessService<SwfNonFinEntity, SwfNonFinEntityJpe> {

    String SWFNONFINENTITYSERVICE_VALIDATE_SWFF50 = "SwiftNonFinEntityService.validateSwfNonFinEntity";

    @ServiceOperation(name = SWFNONFINENTITYSERVICE_VALIDATE_SWFF50, type = ServiceOperationType.EXECUTE)
    boolean validateSwfNonFinEntity(SwfNonFinEntity dataObject);

}
