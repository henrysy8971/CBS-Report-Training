package com.silverlakesymmetri.cbs.xps.svc.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.velocity.VelocityContext;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.mysema.query.types.EntityPath;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.bdo.ViewCriteriaItem;
import com.silverlakesymmetri.cbs.commons.bdo.ViewCriteriaRow;
import com.silverlakesymmetri.cbs.commons.exception.base.CbsServiceProcessException;
import com.silverlakesymmetri.cbs.commons.jpa.entity.ConjunctionEnumJpe;
import com.silverlakesymmetri.cbs.commons.jpa.entity.ViewCriteriaItemJpe;
import com.silverlakesymmetri.cbs.commons.jpa.util.DateTimeHelper;
import com.silverlakesymmetri.cbs.commons.xmlapi.enums.CbsXmlApiOperation;
import com.silverlakesymmetri.cbs.mcl.bdo.sdo.Client;
import com.silverlakesymmetri.cbs.mcl.bdo.sdo.ClientContact;
import com.silverlakesymmetri.cbs.swf.bdo.sdo.SwfMessageGroup;
import com.silverlakesymmetri.cbs.xps.bdo.sdo.ChargeSettlement;
import com.silverlakesymmetri.cbs.xps.bdo.sdo.MarginMaster;
import com.silverlakesymmetri.cbs.xps.bdo.sdo.MarginSettlement;
import com.silverlakesymmetri.cbs.xps.bdo.sdo.MarginSettlementDetails;
import com.silverlakesymmetri.cbs.xps.bdo.sdo.MarginUtilizationInfo;
import com.silverlakesymmetri.cbs.xps.bdo.sdo.MarginWithSettlement;
import com.silverlakesymmetri.cbs.xps.bdo.sdo.MessageQOthers;
import com.silverlakesymmetri.cbs.xps.bdo.sdo.SettleMessagePreviewAddInfo;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.MarginWithSettlementJpe;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.QMarginWithSettlementJpe;
import com.silverlakesymmetri.cbs.xps.svc.AbstractXmlApiAdviceCapableBusinessService;
import com.silverlakesymmetri.cbs.xps.svc.ChargesUtilityService;
import com.silverlakesymmetri.cbs.xps.svc.MarginMasterService;
import com.silverlakesymmetri.cbs.xps.svc.MarginSettlementService;
import com.silverlakesymmetri.cbs.xps.svc.MarginUtilityService;
import com.silverlakesymmetri.cbs.xps.svc.MarginWithSettlementService;
import com.silverlakesymmetri.cbs.xps.svc.mapper.MarginSettlementServiceMapper;
import com.silverlakesymmetri.cbs.xps.svc.mapper.MarginWithSettlementServiceMapper;
import com.silverlakesymmetri.cbs.xps.xmlapi.XPSTRANCHARGESETTLEAPIType;
import com.silverlakesymmetri.cbs.xps.xmlapi.XPSTRANMARGINSETTLEAPIType;
import com.silverlakesymmetri.cbs.xps.xmlapi.XPSTRANMARGINWITHSETTLEAPIType;

@Service
@Transactional
public class MarginWithSettlementServiceImpl extends AbstractXmlApiAdviceCapableBusinessService<MarginWithSettlement, MarginWithSettlementJpe, Long, XPSTRANMARGINWITHSETTLEAPIType, XPSTRANMARGINWITHSETTLEAPIType> implements MarginWithSettlementService {
	

	protected static final String MARGIN_API = "XPS_TRAN_MARGIN_API";
	
    @Autowired
    private MarginWithSettlementServiceMapper mapper;

    @Autowired
    private MarginSettlementServiceMapper settlementMapper;
    
    @Autowired
    private ChargesUtilityService chargesUtility;
    
    @Autowired
    private MarginUtilityService marginUtility;
	
	@Autowired
	protected MarginMasterService marginMasterService;
	
	@Autowired
	protected MarginSettlementService marginSettlementService;

	@Autowired
	protected DateTimeHelper dateTimeHelper;


    @Override
    public MarginWithSettlement getByPk(String publicKey, MarginWithSettlement reference) {
    	Long internalKey = Long.parseLong(publicKey);
    	MarginWithSettlement bdo = jaxbSdoHelper.createSdoInstance(MarginWithSettlement.class);
    	XPSTRANMARGINWITHSETTLEAPIType request = new XPSTRANMARGINWITHSETTLEAPIType();
    	request.setINTERNALKEY(internalKey);
    	request.setOPERATION(CbsXmlApiOperation.QUERY.toString());
    	XPSTRANMARGINWITHSETTLEAPIType response = queryXmlApiRs(request);
    	MarginWithSettlement result = null;
    	if(response.getINTERNALKEY() != null){
    		result = processXmlApiRs(bdo, response);
			MarginUtilizationInfo util = marginUtility.getMarginUtilizationInfo(response.getINTERNALKEY());
			if(util != null){
				result.getMarginStructRec().setCollectedAmt(util.getCollectedAmt());
				result.getMarginStructRec().setUnCollectedAmt(util.getEarmarkedAmt());
				result.getMarginStructRec().setUtilisedAmt(util.getUtilisedAmt());
				result.getMarginStructRec().setUnUtilisedAmt(util.getUnutilisedAmt());
			}
    		if(result.getSettlementStructRec() == null && response.getSETTLEMENT() != null){
            	MarginSettlement settlement = marginSettlementService.getByPk(publicKey, null);
            	result.setSettlementStructRec(settlement);
    		}
    	}
    	return result;
    }

    @Override
    public MarginWithSettlement getAttachedMargin(Long attachedKey) {
    	MarginWithSettlement bdo = jaxbSdoHelper.createSdoInstance(MarginWithSettlement.class);
    	XPSTRANMARGINWITHSETTLEAPIType request = new XPSTRANMARGINWITHSETTLEAPIType();
    	request.setATTACHEDKEY(attachedKey);
    	request.setOPERATION(CbsXmlApiOperation.QUERY.toString());
    	XPSTRANMARGINWITHSETTLEAPIType response = queryXmlApiRs(request);
    	MarginWithSettlement result = null;
    	if(response.getINTERNALKEY() != null){
    		result = processXmlApiRs(bdo, response);
    	}
    	return result;
    }

    @Override
    public MarginWithSettlement getAttachedMarginWithUtilization(Map<String, Object> params) {
		String refNo = params.get("refNo") != null ? params.get("refNo").toString() : "";
		String instrumentType = params.get("instrumentType") != null ? params.get("instrumentType").toString() : "";
		String type = params.get("type") != null ? params.get("type").toString() : "";
		Long tranKey = chargesUtility.getTranKey(refNo, type, instrumentType);
		MarginWithSettlement margin = getAttachedMargin(tranKey);
		if(margin != null) {
			MarginUtilizationInfo util = marginUtility.getMarginUtilizationInfo(margin.getInternalKey());
			if(util != null){
				margin.getMarginStructRec().setCollectedAmt(util.getCollectedAmt());
				margin.getMarginStructRec().setUnCollectedAmt(util.getEarmarkedAmt());
				margin.getMarginStructRec().setUtilisedAmt(util.getUtilisedAmt());
				margin.getMarginStructRec().setUnUtilisedAmt(util.getUnutilisedAmt());
			}
		}
    	return margin;
    }
    
    @Override
    public MarginWithSettlement getActiveMarginWithSettlement(Map<String, Object> filters){
    	MarginWithSettlement activeMargin = null;
    	filters.put("tranStatus", "A");
		List<MarginMaster> resultList = marginMasterService.query(0, -1, null, null, filters);
		if(resultList != null && resultList.size() > 0){
			for(MarginMaster master : resultList){
				activeMargin = getByPk(master.getInternalKey().toString(), null);
				if(activeMargin != null){
					activeMargin.setTranKey(master.getTranKey());
					break;
				}
			}
		}
		return activeMargin;
    }

    @Override
    public List<MarginWithSettlement> find(FindCriteria findCriteria, CbsHeader cbsHeader) {
    	if(findCriteria.getFilter() != null && findCriteria.getFilter().getGroup() != null && findCriteria.getFilter().getGroup().size() > 0){
    		for(ViewCriteriaRow criteriaRow : findCriteria.getFilter().getGroup()){
    			if(criteriaRow.getItem() != null && criteriaRow.getItem().size() > 0){
    				String refNo = null;
    				String instrumentType = null;
    				String type = null;
    				ViewCriteriaItem instrumentTypeVci = null;
    				List<ViewCriteriaItemJpe> otherFilters = new ArrayList<ViewCriteriaItemJpe>();
    				for(ViewCriteriaItem item : criteriaRow.getItem()){
    					ViewCriteriaItemJpe vci = jaxbSdoHelper.unwrap(item, ViewCriteriaItemJpe.class);
    					if(item.getAttribute().equals("refNo")){
    						refNo = vci.getValue().get(0).toString();
    					} else if(item.getAttribute().equals("instrumentType")){
    						instrumentType = vci.getValue().get(0).toString();
    						instrumentTypeVci = item;
    					} else if(item.getAttribute().equals("type")){
    						if(item.getValue() != null && item.getValue().size() > 0){
        						type = vci.getValue().get(0) != null ? vci.getValue().get(0).toString() : null;
    						}
    					} else {
    						otherFilters.add(vci);
    					}
    				}
    				if(refNo != null && instrumentType != null){
    					Long tranKey = chargesUtility.getTranKey(refNo, type, instrumentType);
    					List<ViewCriteriaItem> modifiedItems = new ArrayList<ViewCriteriaItem>();
    					modifiedItems.add(instrumentTypeVci);
    					ViewCriteriaItemJpe vci = new ViewCriteriaItemJpe();	
    					List<Object> values = new ArrayList<Object>();
    					values.add(tranKey);
    					vci.setAttribute("tranKey");
    					vci.setOperator("=");
    					vci.setValue(values);
    					vci.setConjunction(ConjunctionEnumJpe.AND);
    					vci.setUpperCaseCompareYn(true);
    					modifiedItems.add(jaxbSdoHelper.wrap(vci));
    					for(ViewCriteriaItemJpe otherVci : otherFilters){
    						modifiedItems.add(jaxbSdoHelper.wrap(otherVci));
    					}
    					criteriaRow.setItem(modifiedItems);
    				}
    			}
    		}
    	}
        return super.find(findCriteria, cbsHeader);
    }

    @Override
    public List<MarginWithSettlement> query(int offset, int resultLimit, String groupBy, String order, Map<String, Object> filters) {
        return super.query(offset, resultLimit, groupBy, order, filters);
    }

    public MarginWithSettlement preCreateValidation(MarginWithSettlement dataObject) {
    	if(dataObject.getSettlementStructRec() == null){
            String msg = messageUtils.getMessage("CBS.B.XPS.MARGINSETTLEMENT.0002", new String[] {});
            CbsServiceProcessException exec = new CbsServiceProcessException("CBS.B.XPS.MARGINSETTLEMENT.0002", msg);
            throw exec;
    	} else if(dataObject.getSettlementStructRec().getMarginSettleDetailsList() != null){
    		if(dataObject.getSettlementStructRec().getMarginSettleDetailsList().size() > 1){
                String msg = messageUtils.getMessage("CBS.B.XPS.MARGINSETTLEMENT.0001", new String[] {});
                CbsServiceProcessException exec = new CbsServiceProcessException("CBS.B.XPS.MARGINSETTLEMENT.0001", msg);
                throw exec;
    		}
    		MarginMaster master = dataObject.getMarginStructRec();
        	if(dataObject.getSettlementStructRec().getMarginSettleDetailsList() != null && master != null){
        		Double totalSettlementAmount = new Double(0);
        		for(MarginSettlementDetails detail : dataObject.getSettlementStructRec().getMarginSettleDetailsList()){
    				if(detail.getAmount() != null){
    					totalSettlementAmount = totalSettlementAmount.doubleValue() + detail.getAmount().doubleValue();
    				}
    				if(detail.getIsEarmark() != null && detail.getIsEarmark().equals("Y") && (detail.getAcctType() == null || !"R".equals(detail.getAcctType()))){
    		            String msg = messageUtils.getMessage("CBS.B.XPS.MARGINSETTLEMENT.0006", new String[] {});
    		            CbsServiceProcessException exec = new CbsServiceProcessException("CBS.B.XPS.MARGINSETTLEMENT.0006", msg);
    		            throw exec;
    				}
        		}
        		if(totalSettlementAmount.compareTo(master.getAmount()) != 0){
    	            String msg = messageUtils.getMessage("CBS.B.XPS.MARGINSETTLEMENT.0005", new String[] {});
    	            CbsServiceProcessException exec = new CbsServiceProcessException("CBS.B.XPS.MARGINSETTLEMENT.0005", msg);
    	            throw exec;
    			}
        	}
        	dataObject.setInternalKey(master.getInternalKey());
    	}
    	Long internalKey = chargesUtility.getInternalKey(MARGIN_API);
    	Long tranKey = chargesUtility.getTranKey(dataObject.getMarginStructRec().getRefNo(), dataObject.getMarginStructRec().getDomainType(), dataObject.getMarginStructRec().getInstrumentType());
    	dataObject.getMarginStructRec().setTranKey(tranKey);
    	if(dataObject.getInternalKey() == null){
        	dataObject.setInternalKey(internalKey);
    	}
    	
    	if(dataObject.getMarginStructRec().getInternalKey() == null){
        	dataObject.getMarginStructRec().setInternalKey(internalKey);
    	}
    	return super.preCreateValidation(dataObject);
    }

    @Override
    public MarginWithSettlement create(MarginWithSettlement dataObject) {
        return super.create(dataObject);
    }

    @Override
    protected XPSTRANMARGINWITHSETTLEAPIType transformBdoToXmlApiRqCreate(MarginWithSettlement dataObject) {
        return transformBdoToXmlApiType(dataObject, CbsXmlApiOperation.INSERT);
    }

    @Override
    protected XPSTRANMARGINWITHSETTLEAPIType transformBdoToXmlApiRqUpdate(MarginWithSettlement dataObject) {
        return null;
    }

    @Override
    protected XPSTRANMARGINWITHSETTLEAPIType transformBdoToXmlApiRqDelete(MarginWithSettlement dataObject) {
        return null;
    }

    private XPSTRANMARGINWITHSETTLEAPIType transformBdoToXmlApiType(MarginWithSettlement dataObject, CbsXmlApiOperation oper) {
    	MarginWithSettlementJpe jpe = jaxbSdoHelper.unwrap(dataObject);
    	XPSTRANMARGINWITHSETTLEAPIType api = mapper.mapToApi(jpe, oper);
    	if(jpe.getSettlementStructRec() != null){
    		XPSTRANMARGINSETTLEAPIType settlement = settlementMapper.mapToApi(jpe.getSettlementStructRec(), oper);
    		super.setTechColsFromDataObject(dataObject.getSettlementStructRec(), settlement);
    		api.setSETTLEMENT(settlement);
    	}
    	super.setTechColsFromDataObject(dataObject, api);
        return api;
    }

    @Override
    protected Map<String, String> executeStoredProcedure(String xmlApiReq, String xmlHeaderIn) {
        String xmlApiReqProcess = xmlApiReq.replaceAll("XPS_TRAN_MARGIN_WITH_SETTLE_API OPERATION=\"INSERT\"", "XPS_TRAN_MARGIN_WITH_SETTLE_API OPERATION=\"PROCESS_AUTHORIZE\"");
        return super.executeStoredProcedure(xmlApiReqProcess, xmlHeaderIn);
    }

    @Override
    protected MarginWithSettlement processXmlApiRs(MarginWithSettlement dataObject, XPSTRANMARGINWITHSETTLEAPIType xmlApiRs) {
    	MarginWithSettlementJpe jpe = jaxbSdoHelper.unwrap(dataObject);
        jpe = mapper.mapToJpe(xmlApiRs, jpe);
        jpe.setInternalKey(xmlApiRs.getINTERNALKEY());
        return jaxbSdoHelper.wrap(jpe);
    }

    @Override
    protected List<MarginWithSettlement> processXmlApiListRs(MarginWithSettlement dataObject, XPSTRANMARGINWITHSETTLEAPIType xmlApiRs) {
        return null;
    }

    @Override
    protected Class<XPSTRANMARGINWITHSETTLEAPIType> getXmlApiResponseClass() {
        return XPSTRANMARGINWITHSETTLEAPIType.class;
    }

    @Override
    protected Long getIdFromDataObjectInstance(MarginWithSettlement dataObject) {
        return dataObject.getMarginStructRec().getInternalKey();
    }

    @Override
    protected EntityPath<MarginWithSettlementJpe> getEntityPath() {
        return QMarginWithSettlementJpe.marginWithSettlementJpe;
    }

	@Override
	public String generateSwfMessage(Map<String, Object> params) {
		String swfMessage = null;
    	SwfMessageGroup msgGroup = jsonConversionMngr.convertToType(params.get("msgGroup"), SwfMessageGroup.class, null, null);
		if(params.get("module") != null){
			msgGroup.setModule(params.get("module").toString());
		} 
    	MarginWithSettlement bdo = jsonConversionMngr.convertToType(params.get("transactionBdo"), MarginWithSettlement.class, null, null);
    	String swiftMessageFromQueue = getGeneratedSwiftMessage(bdo.getInternalKey(), "MST", msgGroup.getFormat(), msgGroup.getModule());
    	if(swiftMessageFromQueue != null){
    		return swiftMessageFromQueue;
    	}
    	XPSTRANMARGINWITHSETTLEAPIType xmlApiReq = transformBdoToXmlApiType(bdo, CbsXmlApiOperation.QUERY);
    	SettleMessagePreviewAddInfo addtlInfo = jsonConversionMngr.convertToType(params.get("parentInfo"), SettleMessagePreviewAddInfo.class, null, null);
    	swfMessage = transformToSwfFormat(xmlApiReq, msgGroup, addtlInfo);
		return swfMessage;
	}

	@Override
	protected MessageQOthers fillContext(Map<String, Object> adviceParams, VelocityContext context){
		MarginMaster master = jsonConversionMngr.convertToType(adviceParams.get("MarginMaster"), MarginMaster.class, null, null);
		context.put("MarginMaster", master);
		adviceParams.remove("MarginMaster");

		MarginSettlementDetails details = jsonConversionMngr.convertToType(adviceParams.get("bdo"), MarginSettlementDetails.class, null, null);
		context.put("MarginSettlementDetails", details);
		adviceParams.remove("bdo");

		if(details.getCommonSettleDepositRec() != null){
			context.put("CommonSettleDeposit", details.getCommonSettleDepositRec());
			Client client = clientService.getByPk(details.getCommonSettleDepositRec().getClientNo(), null);
			if(client != null){
				context.put("Client", client);
				adviceParams.put("Client", client);
				ClientContact contact = getClientContact(client, "POSTAL", null);
				context.put("ClientContact", contact);
			}
		}

		if(details.getInternalKey() != null) {
			Map<String, Object> filters = new HashMap<String, Object>();
			filters.put("tranInternalKey", details.getInternalKey());
			filters.put("tranEventType", "MTR");
			List<MessageQOthers> messageQList = messageQOthersService.query(0, -1, null, null, filters);
			if(messageQList != null && messageQList.size() > 0){
				return messageQList.get(0);
			}
		}
		return null;
	}


}
