package com.silverlakesymmetri.cbs.xps.svc.impl;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.velocity.VelocityContext;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mysema.query.types.EntityPath;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.bdo.ViewCriteriaItem;
import com.silverlakesymmetri.cbs.commons.bdo.ViewCriteriaRow;
import com.silverlakesymmetri.cbs.commons.bdo.sdo.DmsFile;
import com.silverlakesymmetri.cbs.commons.exception.base.CbsServiceProcessException;
import com.silverlakesymmetri.cbs.commons.jpa.entity.ConjunctionEnumJpe;
import com.silverlakesymmetri.cbs.commons.jpa.entity.ViewCriteriaItemJpe;
import com.silverlakesymmetri.cbs.commons.xmlapi.enums.CbsXmlApiOperation;
import com.silverlakesymmetri.cbs.csd.bdo.sdo.SettleMethod;
import com.silverlakesymmetri.cbs.mcl.bdo.sdo.Client;
import com.silverlakesymmetri.cbs.mcl.bdo.sdo.ClientContact;
import com.silverlakesymmetri.cbs.pim.bdo.sdo.MessageKey;
import com.silverlakesymmetri.cbs.swf.bdo.sdo.SwfMessageGroup;
import com.silverlakesymmetri.cbs.xps.bdo.sdo.AdvicePreview;
import com.silverlakesymmetri.cbs.xps.bdo.sdo.ChargeDetails;
import com.silverlakesymmetri.cbs.xps.bdo.sdo.ChargeSettlementDetails;
import com.silverlakesymmetri.cbs.xps.bdo.sdo.MessageQOthers;
import com.silverlakesymmetri.cbs.xps.bdo.sdo.PeriodicSlab;
import com.silverlakesymmetri.cbs.xps.bdo.sdo.RecurringChargeMaster;
import com.silverlakesymmetri.cbs.xps.bdo.sdo.SettleMessagePreviewAddInfo;
import com.silverlakesymmetri.cbs.xps.enums.XpsGlobalConstants;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.ChargeDetailsJpe;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.RecurringChargeMasterJpe;
import com.silverlakesymmetri.cbs.xps.svc.AbstractXmlApiAdviceCapableBusinessService;
import com.silverlakesymmetri.cbs.xps.svc.ChargesUtilityService;
import com.silverlakesymmetri.cbs.xps.svc.MessageQService;
import com.silverlakesymmetri.cbs.xps.svc.RecurringChargeMasterService;
import com.silverlakesymmetri.cbs.xps.svc.mapper.RecurringChargeMasterServiceMapper;
import com.silverlakesymmetri.cbs.xps.xmlapi.XPSTRANCHARGEDETAILAPIType;
import com.silverlakesymmetri.cbs.xps.xmlapi.XPSTRANCHARGESCHEDAPIType;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.QRecurringChargeMasterJpe;

@Service
public class RecurringChargeMasterServiceImpl extends AbstractXmlApiAdviceCapableBusinessService<RecurringChargeMaster, RecurringChargeMasterJpe, Long, XPSTRANCHARGESCHEDAPIType, XPSTRANCHARGESCHEDAPIType> 
	implements RecurringChargeMasterService {
	

    @Autowired
    private ChargesUtilityService chargeUtility;
    
    @Autowired
	protected MessageQService messageQueueService;
    
    @Autowired
    private RecurringChargeMasterServiceMapper mapper;

	private static final String CHARGE_TYPE_FIXED = "F";
	private static final String CHARGE_TYPE_INTEREST = "I";
	private static final String CHARGE_TYPE_PERIODIC = "P";
	private static final String CHARGE_TYPE_RATED = "R";
	private static final String CHARGE_TYPE_TWOTIER = "T";

	protected static final String BGT = "BGT";
	protected static final String BANK_GUARANTEE_REGISTRY = "BANK_GUARANTEE_REGISTRY";
	protected static final String TFN = "TFN";
	protected static final String TRADE_FINANCE_REGISTRY = "TRADE_FINANCE_REGISTRY";
	protected static final String CHARGE_API = "XPS_TRAN_CHARGE_SCHED_API";

	@Override
    public List<RecurringChargeMaster> query(int offset, int resultLimit, String groupBy, String order, Map<String, Object> filters) {
		if(filters.containsKey("refNo") && filters.containsKey("instrumentType")){
    		String type = filters.get("type") != null ? filters.get("type").toString() : null;
			Long tranKey = chargeUtility.getTranKey(filters.get("refNo").toString(), type, filters.get("instrumentType").toString());
			filters.put("tranKey", tranKey);
			filters.remove("refNo");
			filters.remove("type");
    	}
        return super.query(offset, resultLimit, groupBy, order, filters);
    }
	
	@Override
    public Long count(FindCriteria findCriteria, CbsHeader cbsHeader) {
    	List<RecurringChargeMaster> list = find(findCriteria, cbsHeader);
    	return list != null ? new Integer(list.size()).longValue() : 0L;
    }
	
	@Override
    public List<RecurringChargeMaster> find(FindCriteria findCriteria, CbsHeader cbsHeader) {
		if(findCriteria.getFilter() != null && findCriteria.getFilter().getGroup() != null && findCriteria.getFilter().getGroup().size() > 0){
    		for(ViewCriteriaRow criteriaRow : findCriteria.getFilter().getGroup()){
    			if(criteriaRow.getItem() != null && criteriaRow.getItem().size() > 0){
    				String refNo = null;
    				String instrumentType = null;
    				String type = null;
    				ViewCriteriaItem instrumentTypeVci = null;
    				List<ViewCriteriaItemJpe> otherFilters = new ArrayList<ViewCriteriaItemJpe>();
    				for(ViewCriteriaItem item : criteriaRow.getItem()){
    					ViewCriteriaItemJpe vci = jaxbSdoHelper.unwrap(item, ViewCriteriaItemJpe.class);
    					if(item.getAttribute().equals("refNo")){
    						refNo = vci.getValue().get(0).toString();
    					} else if(item.getAttribute().equals("instrumentType")){
    						instrumentType = vci.getValue().get(0).toString();
    						instrumentTypeVci = item;
    					} else if(item.getAttribute().equals("type")){
    						if(item.getValue() != null && item.getValue().size() > 0){
        						type = vci.getValue().get(0) != null ? vci.getValue().get(0).toString() : null;
    						}
    					} else {
    						otherFilters.add(vci);
    					}
    				}
    				if(refNo != null && instrumentType != null){
    					Long tranKey = chargeUtility.getTranKey(refNo, type, instrumentType);
    					List<ViewCriteriaItem> modifiedItems = new ArrayList<ViewCriteriaItem>();
    					modifiedItems.add(instrumentTypeVci);
    					ViewCriteriaItemJpe vci = new ViewCriteriaItemJpe();	
    					List<Object> values = new ArrayList<Object>();
    					values.add(tranKey);
    					vci.setAttribute("tranKey");
    					vci.setOperator("=");
    					vci.setValue(values);
    					vci.setConjunction(ConjunctionEnumJpe.AND);
    					vci.setUpperCaseCompareYn(true);
    					modifiedItems.add(jaxbSdoHelper.wrap(vci));
    					for(ViewCriteriaItemJpe otherVci : otherFilters){
    						modifiedItems.add(jaxbSdoHelper.wrap(otherVci));
    					}
    					criteriaRow.setItem(modifiedItems);
    				}
    			}
    		}
    	}
        return super.find(findCriteria, cbsHeader);
    }

	@Override
	public RecurringChargeMaster getByPk(String publicKey, RecurringChargeMaster reference) {
		XPSTRANCHARGESCHEDAPIType apiType = new XPSTRANCHARGESCHEDAPIType();
		super.setTechColumns(apiType);
		apiType.setINTERNALKEY(Long.valueOf(publicKey));
		apiType.setOPERATION(CbsXmlApiOperation.QUERY.getOperation());
		
		RecurringChargeMaster bdo = queryDataObject(apiType);
		return bdo;
	}
	
	@Override
	public RecurringChargeMaster preCreateValidation(RecurringChargeMaster dataObject) {
		Long tranKey = chargeUtility.getTranKey(dataObject.getRefNo(), dataObject.getDomainType(), dataObject.getInstrumentType());
    	Long internalKey = chargeUtility.getInternalKey(CHARGE_API);
    	dataObject.setTranKey(tranKey);
    	if(dataObject.getInternalKey() == null){
        	dataObject.setInternalKey(internalKey);
    	}
    	if(dataObject.getInternalKey() == null){
        	dataObject.setInternalKey(internalKey);
    	}
    	
    	if(dataObject.getChargeDetailsList() != null){
    		for(ChargeDetails details : dataObject.getChargeDetailsList()){
    			if(CHARGE_TYPE_RATED.equals(details.getChargeType()) || CHARGE_TYPE_PERIODIC.equals(details.getChargeType()) || CHARGE_TYPE_TWOTIER.equals(details.getChargeType())){
    				ChargeDetailsJpe jpe = jaxbSdoHelper.unwrap(details);
    				Date startDate = null;
    				Date endDate = null;
    				Date amendStartDate = null;
    				Date amendEndDate = null;
    				if(CHARGE_TYPE_RATED.equals(details.getChargeType()) && details.getChargeRatedStructRec() != null){
        				startDate = jpe.getChargeRatedStructRec().getStartDate();
        				endDate = jpe.getChargeRatedStructRec().getEndDate();
        				amendStartDate = jpe.getChargeRatedStructRec().getAmendStartDate();
        				amendEndDate = jpe.getChargeRatedStructRec().getAmendEndDate();
    				} else if(CHARGE_TYPE_PERIODIC.equals(details.getChargeType()) && details.getChargePeriodicStructRec() != null){
        				startDate = jpe.getChargePeriodicStructRec().getStartDate();
        				endDate = jpe.getChargePeriodicStructRec().getEndDate();
        				amendStartDate = jpe.getChargePeriodicStructRec().getAmendStartDate();
        				amendEndDate = jpe.getChargePeriodicStructRec().getAmendEndDate();
    				} else if(CHARGE_TYPE_TWOTIER.equals(details.getChargeType()) && details.getChargeTwoTierStructRec() != null){
        				startDate = jpe.getChargeTwoTierStructRec().getStartDate();
        				endDate = jpe.getChargeTwoTierStructRec().getEndDate();
        				amendStartDate = jpe.getChargeTwoTierStructRec().getAmendStartDate();
        				amendEndDate = jpe.getChargeTwoTierStructRec().getAmendEndDate();
    				}
    				if(startDate != null && endDate != null){
    					if(dateTimeHelper.isBefore(endDate, startDate)){
    			            String msg = messageUtils.getMessage("CBS.B.XPS.CHARGEWITHSETTLEMENTSERVICE.0001", new String[] {});
    			            CbsServiceProcessException exec = new CbsServiceProcessException("CBS.B.XPS.CHARGEWITHSETTLEMENTSERVICE.0001", msg);
    			            throw exec;
    					}
    				}
    				if(amendStartDate != null && amendEndDate != null){
    					if(dateTimeHelper.isBefore(amendEndDate, amendStartDate)){
    			            String msg = messageUtils.getMessage("CBS.B.XPS.CHARGEWITHSETTLEMENTSERVICE.0002", new String[] {});
    			            CbsServiceProcessException exec = new CbsServiceProcessException("CBS.B.XPS.CHARGEWITHSETTLEMENTSERVICE.0002", msg);
    			            throw exec;
    					}
    				}
    				if(startDate != null && amendStartDate != null){
    					if(dateTimeHelper.isBefore(amendStartDate, startDate)){
    			            String msg = messageUtils.getMessage("CBS.B.XPS.CHARGEWITHSETTLEMENTSERVICE.0003", new String[] {});
    			            CbsServiceProcessException exec = new CbsServiceProcessException("CBS.B.XPS.CHARGEWITHSETTLEMENTSERVICE.0003", msg);
    			            throw exec;
    					}
    				}
    			}
    			if(CHARGE_TYPE_PERIODIC.equals(details.getChargeType()) && details.getChargePeriodicStructRec() != null){
    				if(details.getChargePeriodicStructRec().getPeriodicSlabList() != null && details.getChargePeriodicStructRec().getPeriodicSlabList().size() > 0){
    					for(PeriodicSlab periodicSlab : details.getChargePeriodicStructRec().getPeriodicSlabList()){
    						boolean skippedRateExists = false;
    						if(periodicSlab.getRate12() != null && periodicSlab.getRate11() == null){
    							skippedRateExists = true;
    						}
    						if(periodicSlab.getRate11() != null && periodicSlab.getRate10() == null){
    							skippedRateExists = true;
    						}
    						if(periodicSlab.getRate10() != null && periodicSlab.getRate09() == null){
    							skippedRateExists = true;
    						}
    						if(periodicSlab.getRate09() != null && periodicSlab.getRate08() == null){
    							skippedRateExists = true;
    						}
    						if(periodicSlab.getRate08() != null && periodicSlab.getRate07() == null){
    							skippedRateExists = true;
    						}
    						if(periodicSlab.getRate07() != null && periodicSlab.getRate06() == null){
    							skippedRateExists = true;
    						}
    						if(periodicSlab.getRate06() != null && periodicSlab.getRate05() == null){
    							skippedRateExists = true;
    						}
    						if(periodicSlab.getRate05() != null && periodicSlab.getRate04() == null){
    							skippedRateExists = true;
    						}
    						if(periodicSlab.getRate04() != null && periodicSlab.getRate03() == null){
    							skippedRateExists = true;
    						}
    						if(periodicSlab.getRate03() != null && periodicSlab.getRate02() == null){
    							skippedRateExists = true;
    						}
    						if(periodicSlab.getRate02() != null && periodicSlab.getRate01() == null){
    							skippedRateExists = true;
    						}
    						if(skippedRateExists){
        			            String msg = messageUtils.getMessage("CBS.B.XPS.CHARGEWITHSETTLEMENTSERVICE.0004", new String[] {});
        			            CbsServiceProcessException exec = new CbsServiceProcessException("CBS.B.XPS.CHARGEWITHSETTLEMENTSERVICE.0004", msg);
        			            throw exec;
    						}
    					}
    				}
    			}
    		}
    	}
    	validateSettlementAmount(dataObject);
    	
    	return super.preCreateValidation(dataObject);
	}

	@Override
	public RecurringChargeMaster create(RecurringChargeMaster dataObject) {
		RecurringChargeMaster bdo = super.create(dataObject);
        generateMessageQueue(bdo);
        return bdo;
	}
	
	@Override
    public RecurringChargeMaster preUpdateValidation(RecurringChargeMaster dataObject) {
    	validateSettlementAmount(dataObject);
    	return super.preUpdateValidation(dataObject);
    }

	@Override
	public RecurringChargeMaster update(RecurringChargeMaster dataObject) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean delete(RecurringChargeMaster dataObject) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	protected MessageQOthers fillContext(Map<String, Object> adviceParams, VelocityContext context) {
		boolean isJsonParams = adviceParams.get("isJsonParams") == null ? false : Boolean.valueOf(adviceParams.get("isJsonParams").toString());

		RecurringChargeMaster master = null;
		if(isJsonParams){
			master = jsonConversionMngr.convertToType(adviceParams.get("RecurringChargeMaster"), RecurringChargeMaster.class, null, null);
		} else {
			master = (RecurringChargeMaster) adviceParams.get("RecurringChargeMaster");
		}
		context.put("RecurringChargeMaster", master);
		adviceParams.remove("RecurringChargeMaster");

		ChargeSettlementDetails details = null;
		if(isJsonParams){
			details = jsonConversionMngr.convertToType(adviceParams.get("bdo"), ChargeSettlementDetails.class, null, null);
		} else {
			details = (ChargeSettlementDetails) adviceParams.get("bdo");
		}
		context.put("ChargeSettlementDetails", details);
		adviceParams.remove("bdo");

		if(details.getCommonSettleDepositRec() != null){
			context.put("CommonSettleDeposit", details.getCommonSettleDepositRec());
			Client client = clientService.getByPk(details.getCommonSettleDepositRec().getClientNo(), null);
			if(client != null){
				context.put("Client", client);
				adviceParams.put("Client", client);
				ClientContact contact = getClientContact(client, "POSTAL", null);
				context.put("ClientContact", contact);
			}
		}

		if(details.getInternalKey() != null) {
			Map<String, Object> filters = new HashMap<String, Object>();
			filters.put("tranInternalKey", details.getInternalKey());
			filters.put("tranEventType", "ZST");
			List<MessageQOthers> messageQList = messageQOthersService.query(0, -1, null, null, filters);
			if(messageQList != null && messageQList.size() > 0){
				return messageQList.get(0);
			}
		}
		return null;
	}

	@Override
	public String generateSwfMessage(Map<String, Object> params) {
		String swfMessage = null;
    	SwfMessageGroup msgGroup = jsonConversionMngr.convertToType(params.get("msgGroup"), SwfMessageGroup.class, null, null);
		if(params.get("module") != null){
			msgGroup.setModule(params.get("module").toString());
		} 
		RecurringChargeMaster bdo = jsonConversionMngr.convertToType(params.get("transactionBdo"), RecurringChargeMaster.class, null, null);
    	String swiftMessageFromQueue = getGeneratedSwiftMessage(bdo.getInternalKey(), "ZEN", msgGroup.getFormat(), msgGroup.getModule());
    	if(swiftMessageFromQueue != null){
    		return swiftMessageFromQueue;
    	}
    	XPSTRANCHARGESCHEDAPIType xmlApiReq = transformBdoToXmlApiType(bdo, CbsXmlApiOperation.QUERY);
    	SettleMessagePreviewAddInfo addtlInfo = jsonConversionMngr.convertToType(params.get("parentInfo"), SettleMessagePreviewAddInfo.class, null, null);
    	swfMessage = transformToSwfFormat(xmlApiReq, msgGroup, addtlInfo);
		return swfMessage;
	}

	@Override
	protected XPSTRANCHARGESCHEDAPIType transformBdoToXmlApiRqCreate(RecurringChargeMaster dataObject) {
		return transformBdoToXmlApiType(dataObject, CbsXmlApiOperation.INSERT);
	}

	@Override
	protected XPSTRANCHARGESCHEDAPIType transformBdoToXmlApiRqUpdate(RecurringChargeMaster dataObject) {
		return null;
	}

	@Override
	protected XPSTRANCHARGESCHEDAPIType transformBdoToXmlApiRqDelete(RecurringChargeMaster dataObject) {
		return null;
	}
	
	private XPSTRANCHARGESCHEDAPIType transformBdoToXmlApiType(RecurringChargeMaster dataObject, CbsXmlApiOperation oper) {
		RecurringChargeMasterJpe jpe = jaxbSdoHelper.unwrap(dataObject);
    	XPSTRANCHARGESCHEDAPIType api = mapper.mapToApi(jpe, oper);
    	super.setTechColsFromDataObject(dataObject, api);
    	for(XPSTRANCHARGEDETAILAPIType detailApi : api.getDETAILS().getXPSTRANCHARGEDETAILAPI()){
    		for(ChargeDetails detailBdo : dataObject.getChargeDetailsList()){
    			if(detailBdo.getSeqNo().longValue() == detailApi.getSEQNO().longValue()){
    				super.setTechColsFromDataObject(detailBdo, detailApi);
    			}
    		}
    	}
        return api;
    }

	@Override
	protected RecurringChargeMaster processXmlApiRs(RecurringChargeMaster dataObject,
			XPSTRANCHARGESCHEDAPIType xmlApiRs) {
		RecurringChargeMasterJpe jpe = null;
		if(dataObject == null) {
			jpe = new RecurringChargeMasterJpe();
		}else {
			jpe = jaxbSdoHelper.unwrap(dataObject);
		}
        jpe = mapper.mapToJpe(xmlApiRs, jpe);
        return jaxbSdoHelper.wrap(jpe);
	}

	@Override
	protected List<RecurringChargeMaster> processXmlApiListRs(RecurringChargeMaster dataObject,
			XPSTRANCHARGESCHEDAPIType xmlApiRs) {
		return null;
	}

	@Override
	protected Class<XPSTRANCHARGESCHEDAPIType> getXmlApiResponseClass() {
		return XPSTRANCHARGESCHEDAPIType.class;
	}

	@Override
	protected Long getIdFromDataObjectInstance(RecurringChargeMaster dataObject) {
		return dataObject.getInternalKey();
	}

	@Override
	protected EntityPath<RecurringChargeMasterJpe> getEntityPath() {
		return QRecurringChargeMasterJpe.recurringChargeMasterJpe;
	}
	
	private void validateSettlementAmount(RecurringChargeMaster dataObject){
    	if( dataObject != null && dataObject.getChargeSettleDetailsList() != null ){
    		Double totalSettlementAmount = new Double(0);
    		for(ChargeSettlementDetails detail : dataObject.getChargeSettleDetailsList()){
				if(detail.getAmount() != null){
					totalSettlementAmount = totalSettlementAmount.doubleValue() + detail.getAmount().doubleValue();
				}
    		}
    		if(totalSettlementAmount.compareTo(dataObject.getAmount()) != 0){
	            String msg = messageUtils.getMessage("CBS.B.XPS.CHARGEWITHSETTLEMENT.0001", new String[] {});
	            CbsServiceProcessException exec = new CbsServiceProcessException("CBS.B.XPS.CHARGEWITHSETTLEMENT.0001", msg);
	            throw exec;
			}
    	}

    }
	
	@Override
	protected Map<String, String> executeStoredProcedure(String xmlApiReq, String xmlHeaderIn) {
		String xmlApiReqProcess = xmlApiReq.replaceAll("XPS_TRAN_CHARGE_SCHED_API OPERATION=\"INSERT\"", "XPS_TRAN_CHARGE_SCHED_API OPERATION=\"PROCESS_AUTHORIZE\"");
		return super.executeStoredProcedure(xmlApiReqProcess, xmlHeaderIn);
	}
	
	private void generateMessageQueue(RecurringChargeMaster bdo) {
		if(bdo != null && bdo.getChargeSettleDetailsList() != null 
				&& bdo.getChargeSettleDetailsList().size() > 0) {
			Long seqNo = 1L;
			for(ChargeSettlementDetails details : bdo.getChargeSettleDetailsList()){
				String destinationAddress = null;
				SettleMethod settleMethod = settleMethodService.getByPk(details.getSettleMethod()+"~"+bdo.getPayRec(), null);
				if(settleMethod != null && settleMethod.getDestClientType() != null && !settleMethod.getDestClientType().equals("N")){
					if(settleMethod.getRouteDest() != null && !settleMethod.getRouteDest().equals(XpsGlobalConstants.SWIFT_ROUTE)) {
						MessageKey messageKey = transformSettleMethodToMessageKey(settleMethod);
						if(settleMethod.getRouteDest().equals(XpsGlobalConstants.EMAIL_ROUTE)){
							AdvicePreview advice = null;
							Map<String, Object> params = new HashMap<String, Object>();
							params.put("bdo", details);
							params.put("RecurringChargeMaster", bdo);
							params.put("module", bdo.getDomain());
							params.put("payRec", bdo.getPayRec());
							params.put("settleMethod", settleMethod.getPublicKey());
							params.put("viaChargeSettlement", true);
							params.put("viaSettleMethod", true);
							params.put("isPreview", true);
							params.put("isJsonParams", false);
							try {
								advice = generateEmailPreview(params);
								//destinationAddress = msgQueueUtil.getDestinationAddress(null, qParams.get("refNo").toString(), messageKey, qParams.get("instrumentType").toString(), qParams.get("instrumentSubType").toString(), qParams);
							} catch (CbsServiceProcessException e) {
								continue;
							}
							//how to get tranKey???
							messageQueueService.createMessageQueueEntry(advice, null, bdo.getDomain(), details.getInternalKey(), bdo.getRefNo(), "ZST", 
									null, settleMethod.getRouteDest(), bdo.getBookBranch(), null, seqNo, advice.getRecipients(), null);
						} else {
							Map<String, Object> params = new HashMap<String, Object>();
							params.put("bdo", details);
							params.put("RecurringChargeMaster", bdo);
							params.put("module", bdo.getDomain());
							params.put("payRec", bdo.getPayRec());
							params.put("settleMethod", settleMethod.getPublicKey());
							params.put("viaChargeSettlement", true);
							params.put("viaSettleMethod", true);
							params.put("isPreview", true);
							params.put("isJsonParams", false);
							DmsFile document = null;
							try {
								document = generateAdvice(params);
								destinationAddress = chargeUtility.getDestinationAddress(bdo.getDomain(), null, bdo.getRefNo(), messageKey, bdo.getInstrumentType(), bdo.getDomainType(), new HashMap<String, Object>());
							} catch (CbsServiceProcessException e) {
								continue;
							}
							messageQueueService.createMessageQueueEntry(null, document, bdo.getDomain(), details.getInternalKey(), bdo.getRefNo(), "ZST", 
									null, settleMethod.getRouteDest(), bdo.getBookBranch(), null, seqNo, destinationAddress, null);
						}
					}
				}
			}
		}
	}
	
	private MessageKey transformSettleMethodToMessageKey(SettleMethod settleMethod){
		MessageKey msgKey = jaxbSdoHelper.createSdoInstance(MessageKey.class);
		msgKey.setReceiverClientType(settleMethod.getDestClientType());
		msgKey.setReceiverContactType(settleMethod.getRouteDest());
		msgKey.setReceiverContactSubType(settleMethod.getDestContactType());
		msgKey.setSenderContactType(settleMethod.getRouteSender());
		msgKey.setSenderContactSubType(settleMethod.getSendersContactType());
		msgKey.setFormat(settleMethod.getFormat());
		return msgKey;
	}

}
