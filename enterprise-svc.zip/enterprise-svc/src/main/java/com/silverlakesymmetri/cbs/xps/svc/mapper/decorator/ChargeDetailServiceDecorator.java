package com.silverlakesymmetri.cbs.xps.svc.mapper.decorator;

import org.mapstruct.Context;
import org.mapstruct.MappingTarget;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

import com.silverlakesymmetri.cbs.commons.xmlapi.enums.CbsXmlApiOperation;
import com.silverlakesymmetri.cbs.xps.bdo.sdo.Charges;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.ChargeDetailsJpe;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.ChargeFixedJpe;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.ChargeInterestJpe;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.ChargePeriodicJpe;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.ChargeRatedJpe;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.ChargeTwoTierJpe;
import com.silverlakesymmetri.cbs.xps.svc.ChargesService;
import com.silverlakesymmetri.cbs.xps.svc.mapper.ChargeDetailServiceMapper;
import com.silverlakesymmetri.cbs.xps.svc.mapper.ChargeFixedServiceMapper;
import com.silverlakesymmetri.cbs.xps.svc.mapper.ChargeInterestServiceMapper;
import com.silverlakesymmetri.cbs.xps.svc.mapper.ChargePeriodicServiceMapper;
import com.silverlakesymmetri.cbs.xps.svc.mapper.ChargeRatedServiceMapper;
import com.silverlakesymmetri.cbs.xps.svc.mapper.ChargeTwoTierServiceMapper;
import com.silverlakesymmetri.cbs.xps.xmlapi.XPSTRANCHARGEDETAILAPIType;

public abstract class ChargeDetailServiceDecorator implements ChargeDetailServiceMapper {
	
	private static final String FIXED_CHARGE_TYPE = "F";
	private static final String RATED_CHARGE_TYPE = "R";
	private static final String INTEREST_CHARGE_TYPE = "I";
	private static final String PERIODIC_CHARGE_TYPE = "P";
	private static final String TWOTIER_CHARGE_TYPE = "T";
	
	@Autowired
	@Qualifier("delegate")
	protected ChargeDetailServiceMapper delegate;

	@Autowired
	protected ChargesService chargeService;;

	@Autowired
	protected ChargeFixedServiceMapper fixedMapper;

	@Autowired
	protected ChargeRatedServiceMapper ratedMapper;

	@Autowired
	protected ChargeInterestServiceMapper interestMapper;

	@Autowired
	protected ChargePeriodicServiceMapper periodicMapper;

	@Autowired
	protected ChargeTwoTierServiceMapper twoTierMapper;

	@Override
	public XPSTRANCHARGEDETAILAPIType mapToApi(ChargeDetailsJpe jpe, @Context CbsXmlApiOperation oper){
		XPSTRANCHARGEDETAILAPIType req = (XPSTRANCHARGEDETAILAPIType) delegate.mapToApi(jpe, oper);
		if(jpe.getChargeFixedStructRec() != null){
			req = fixedMapper.mapToApi(jpe.getChargeFixedStructRec(), req);
		} else if(jpe.getChargeRatedStructRec()!= null){
			req = ratedMapper.mapToApi(jpe.getChargeRatedStructRec(), req);
		} else if(jpe.getChargeInterestStructRec() != null){
			req = interestMapper.mapToApi(jpe.getChargeInterestStructRec(), req);
		} else if(jpe.getChargePeriodicStructRec() != null){
			req = periodicMapper.mapToApi(jpe.getChargePeriodicStructRec(), req);
		} else if(jpe.getChargeTwoTierStructRec() != null){
			req = twoTierMapper.mapToApi(jpe.getChargeTwoTierStructRec(), req);
		}
		//should be blank
		req.setPCTOFBANKRATE(null);
		return  req;
	}
	
	@Override
	public ChargeDetailsJpe mapToJpe(XPSTRANCHARGEDETAILAPIType api, @MappingTarget ChargeDetailsJpe jpe){
		delegate.mapToJpe(api, jpe);
		
		Charges charge = chargeService.getByPk(api.getCHARGEREFNO(), null);
		if(charge != null) {
			if(charge.getChargeType().equals(FIXED_CHARGE_TYPE)){
				jpe.setChargeFixedStructRec(new ChargeFixedJpe());
				fixedMapper.mapToJpe(api, jpe.getChargeFixedStructRec());
			} else if(charge.getChargeType().equals(RATED_CHARGE_TYPE)){
				jpe.setChargeRatedStructRec(new ChargeRatedJpe());
				ratedMapper.mapToJpe(api, jpe.getChargeRatedStructRec());
			} else if(charge.getChargeType().equals(INTEREST_CHARGE_TYPE)){
				jpe.setChargeInterestStructRec(new ChargeInterestJpe());
				interestMapper.mapToJpe(api, jpe.getChargeInterestStructRec());
			} else if(charge.getChargeType().equals(PERIODIC_CHARGE_TYPE)){
				jpe.setChargePeriodicStructRec(new ChargePeriodicJpe());
				periodicMapper.mapToJpe(api, jpe.getChargePeriodicStructRec());
			} else if(charge.getChargeType().equals(TWOTIER_CHARGE_TYPE)){
				jpe.setChargeTwoTierStructRec(new ChargeTwoTierJpe());
				twoTierMapper.mapToJpe(api, jpe.getChargeTwoTierStructRec());
			}
		}

		return jpe;
	}

}


