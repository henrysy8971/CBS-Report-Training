package com.silverlakesymmetri.cbs.xps.svc.mapper;

import org.mapstruct.Context;
import org.mapstruct.DecoratedWith;
import org.mapstruct.InheritInverseConfiguration;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingTarget;
import org.mapstruct.Mappings;

import com.silverlakesymmetri.cbs.commons.jpa.util.DateTimeHelper;
import com.silverlakesymmetri.cbs.commons.xmlapi.enums.CbsXmlApiOperation;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.ChargesJpe;
import com.silverlakesymmetri.cbs.xps.svc.mapper.decorator.ChargeServiceDecorator;
import com.silverlakesymmetri.cbs.xps.xmlapi.XPSCHARGETYPEType;

@Mapper(uses = { DateTimeHelper.class, RatedSlabServiceMapper.class })
@DecoratedWith(ChargeServiceDecorator.class)
public interface ChargeServiceMapper {

	@Mappings({
		@Mapping(source="chargeRefNo", target = "REFNO"),
		@Mapping(source="chargeNo", target = "CHARGENO"),
		@Mapping(source="clientId", target = "CLIENTID"),
		@Mapping(source="chargeDesc", target = "DESCRIPTION"),
		@Mapping(source="chargeType", target = "TYPE"),
		@Mapping(source="defaultRate", target = "DEFAULTRATE"),
		@Mapping(source="recurring", target = "RECURRING"),
		@Mapping(source="pctOfBankRate", target = "PCTOFBANKRATE"),
		@Mapping(source="periodFreq", target = "PERIODFREQ"),
		@Mapping(source="ccy", target = "CCY"),
		@Mapping(source="amount", target = "AMOUNT"),
		@Mapping(source="intDays", target = "INTDAYS"),
		@Mapping(source="calcType", target = "CALCTYPE"),
		@Mapping(source="perPeriodDays", target = "PERPERIODDAYS"),
		@Mapping(source="graceDays", target = "GRACEDAYS"),
		@Mapping(source="yearBasis", target = "YEARBASIS"),
		@Mapping(source="rateLadder", target = "RATELADDER"),
		@Mapping(source="amtType", target = "AMTTYPE"),
		@Mapping(source="overallMinAmt", target = "OVERALLMINAMT"),
		@Mapping(source="overallMaxAmt", target = "OVERALLMAXAMT"),
		@Mapping(source="roundTrunc", target = "ROUNDTRUNC"),
		@Mapping(source="roundTruncDigits", target = "ROUNDTRUNCDIGITS"),
		@Mapping(source="useRateConstituents", target = "USERATECONSTITUENTS"),
		@Mapping(source="interestAction", target = "INTERESTACTION"),
		@Mapping(source="interestActionFreq", target = "INTERESTACTIONFREQ"),
		@Mapping(source="interestActionFreqDay", target = "INTERESTACTIONFREQDAY"),
		@Mapping(source="periodFreqDay", target = "PERIODFREQDAY"),
		@Mapping(source="periodYearStartInd", target = "PERIODYEARSTARTIND"),
		@Mapping(source="perAnnumMinAmt", target = "PERANNUMMINAMT"),
		@Mapping(source="perAnnumMaxAmt", target = "PERANNUMMAXAMT"),
		@Mapping(source="ratedSlabList", target = "SLABS.XPSCHARGESLABTYPE"),
	})
	public XPSCHARGETYPEType mapToApi(ChargesJpe jpe, @Context CbsXmlApiOperation oper);

	@InheritInverseConfiguration(name = "mapToApi")
	public ChargesJpe mapToJpe(XPSCHARGETYPEType api, @MappingTarget ChargesJpe jpe);

	@InheritInverseConfiguration(name = "mapToApi")
	public ChargesJpe mapToJpe(XPSCHARGETYPEType api);
}