package com.silverlakesymmetri.cbs.swf.svc.mapper.decorator;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

import com.silverlakesymmetri.cbs.swf.jpa.mapping.sdo.SwfF26Jpe;
import com.silverlakesymmetri.cbs.swf.svc.mapper.mapping.SwfF26Mapper;
import com.silverlakesymmetri.cbs.swf.xmlapi.SWFF26TYPEType;

public abstract class SwfF26MapperDecorator implements SwfF26Mapper {
	
	@Autowired
	@Qualifier("delegate")
	protected SwfF26Mapper delegate;

	@Override
	public SWFF26TYPEType mapToApi(SwfF26Jpe jpe){
		SWFF26TYPEType swfF26 = delegate.mapToApi(jpe);
		if(swfF26 != null && swfF26.getCODE() == null && swfF26.getSEQNO() == null){
			return null;
		}
		return swfF26;
	}
	
	@Override
	public SwfF26Jpe mapToJpe(SWFF26TYPEType api){
		return delegate.mapToJpe(api);
	}
	
}
