package com.silverlakesymmetri.cbs.xps.svc.batch.listener;

import java.util.Date;

import org.springframework.batch.core.ItemProcessListener;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.listener.StepExecutionListenerSupport;
import org.springframework.beans.factory.annotation.Autowired;

import com.silverlakesymmetri.cbs.commons.jpa.service.CbsBatchGenericDataService;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.MessageQJpe;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.MessageQStpJpe;
import com.silverlakesymmetri.cbs.xps.svc.util.MessageQueueUtil;

public abstract class AbstractMessageQueueProcessorListener<I, O> extends StepExecutionListenerSupport
		implements ItemProcessListener<I, O> {

	protected static final String LAST_FAILED_KEY = "lastFailedKey";
	protected StepExecution stepExecution;

	@Autowired
	protected CbsBatchGenericDataService batchDataService;

	@Override
	public void beforeStep(StepExecution stepExecution) {
		super.beforeStep(stepExecution);
		this.stepExecution = stepExecution;
	}

	@Override
	public void beforeProcess(I item) {
	}

	@Override
	public void afterProcess(I item, O result) {
		updateStatusToSent(result);
	}

	@Override
	public void onProcessError(I item, Exception e) {
	}

	protected void updateStatusToSent(O result) {
		if(result instanceof MessageQJpe){
			MessageQJpe jpe = (MessageQJpe) result;
			jpe.setStatus(MessageQueueUtil.MESSAGE_Q_STATUS_SENT);
			jpe.setDateSent(new Date());
			jpe.setErrorDetails(null);
			batchDataService.update(jpe);
		} else if(result instanceof MessageQStpJpe){
			MessageQStpJpe jpe = (MessageQStpJpe) result;
			jpe.setStatus(MessageQueueUtil.MESSAGE_Q_STATUS_SENT);
			jpe.setDateSent(new Date());
			jpe.setErrorDetails(null);
			batchDataService.update(jpe);
		}
	}

}
