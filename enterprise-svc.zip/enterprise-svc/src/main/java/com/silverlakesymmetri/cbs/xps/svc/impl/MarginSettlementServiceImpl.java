package com.silverlakesymmetri.cbs.xps.svc.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.velocity.VelocityContext;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.mysema.query.types.EntityPath;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.exception.base.CbsServiceProcessException;
import com.silverlakesymmetri.cbs.commons.jpa.util.DateTimeHelper;
import com.silverlakesymmetri.cbs.commons.xmlapi.enums.CbsXmlApiOperation;
import com.silverlakesymmetri.cbs.mcl.bdo.sdo.Client;
import com.silverlakesymmetri.cbs.mcl.bdo.sdo.ClientContact;
import com.silverlakesymmetri.cbs.swf.bdo.sdo.SwfMessageGroup;
import com.silverlakesymmetri.cbs.xps.bdo.sdo.MarginMaster;
import com.silverlakesymmetri.cbs.xps.bdo.sdo.MarginSettlement;
import com.silverlakesymmetri.cbs.xps.bdo.sdo.MarginSettlementDetails;
import com.silverlakesymmetri.cbs.xps.bdo.sdo.MessageQOthers;
import com.silverlakesymmetri.cbs.xps.bdo.sdo.SettleMessagePreviewAddInfo;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.MarginSettlementJpe;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.QMarginSettlementJpe;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.util.XpsJpeConstants;
import com.silverlakesymmetri.cbs.xps.svc.AbstractXmlApiAdviceCapableBusinessService;
import com.silverlakesymmetri.cbs.xps.svc.MarginMasterService;
import com.silverlakesymmetri.cbs.xps.svc.MarginSettlementService;
import com.silverlakesymmetri.cbs.xps.svc.mapper.MarginSettlementServiceMapper;
import com.silverlakesymmetri.cbs.xps.xmlapi.XPSTRANMARGINSETTLEAPIType;

@Service
@Transactional
public class MarginSettlementServiceImpl extends AbstractXmlApiAdviceCapableBusinessService<MarginSettlement, MarginSettlementJpe, Long, XPSTRANMARGINSETTLEAPIType, XPSTRANMARGINSETTLEAPIType> implements MarginSettlementService {

    @Autowired
    private MarginSettlementServiceMapper mapper;

    @Autowired
    private MarginMasterService marginMasterService;
    
	@Autowired
	protected DateTimeHelper dateTimeHelper;


    @Override
    public MarginSettlement getByPk(String publicKey, MarginSettlement reference) {
    	XPSTRANMARGINSETTLEAPIType request = new XPSTRANMARGINSETTLEAPIType();
    	request.setINTERNALKEY(new Long(publicKey));
    	request.setOPERATION(CbsXmlApiOperation.QUERY.getOperation());
		XPSTRANMARGINSETTLEAPIType resultApiType = queryXmlApiRs(request);
		MarginSettlement settlement = processXmlApiRs(null, resultApiType);
		if (settlement != null) {
			return settlement;
		}
    	return null;
    }

    @Override
    public List<MarginSettlement> find(FindCriteria findCriteria, CbsHeader cbsHeader) {
        return super.find(findCriteria, cbsHeader);
    }

    @Override
    public List<MarginSettlement> query(int offset, int resultLimit, String groupBy, String order, Map<String, Object> filters) {
        return super.query(offset, resultLimit, groupBy, order, filters);
    }

    @Override
    public MarginSettlement preCreateValidation(MarginSettlement dataObject) {
    	if(dataObject.getMarginSettleDetailsList() != null && dataObject.getMarginSettleDetailsList().size() > 1){
            String msg = messageUtils.getMessage("CBS.B.XPS.MARGINSETTLEMENT.0001", new String[] {});
            CbsServiceProcessException exec = new CbsServiceProcessException("CBS.B.XPS.MARGINSETTLEMENT.0001", msg);
            throw exec;
    	}
		MarginMaster master = marginMasterService.getByPk(dataObject.getInternalKey().toString(), null);
    	if(dataObject.getMarginSettleDetailsList() != null && master != null){
    		Double totalSettlementAmount = new Double(0);
    		for(MarginSettlementDetails detail : dataObject.getMarginSettleDetailsList()){
				if(detail.getAmount() != null){
					totalSettlementAmount = totalSettlementAmount.doubleValue() + detail.getAmount().doubleValue();
				}
				if(detail.getIsEarmark() != null && detail.getIsEarmark().equals("Y") && (detail.getAcctType() == null || !"R".equals(detail.getAcctType()))){
		            String msg = messageUtils.getMessage("CBS.B.XPS.MARGINSETTLEMENT.0006", new String[] {});
		            CbsServiceProcessException exec = new CbsServiceProcessException("CBS.B.XPS.MARGINSETTLEMENT.0006", msg);
		            throw exec;
				}
    		}
    		if(totalSettlementAmount.compareTo(master.getAmount()) != 0){
	            String msg = messageUtils.getMessage("CBS.B.XPS.MARGINSETTLEMENT.0005", new String[] {});
	            CbsServiceProcessException exec = new CbsServiceProcessException("CBS.B.XPS.MARGINSETTLEMENT.0005", msg);
	            throw exec;
			}
    	}
    	dataObject.setInternalKey(master.getInternalKey());
    	return super.preCreateValidation(dataObject);
    }

    @Override
    public MarginSettlement create(MarginSettlement dataObject) {
        return super.create(dataObject);
    }

    @Override
    public MarginSettlement update(MarginSettlement dataObject) {
        return super.create(dataObject);
    }

    @Override
    protected XPSTRANMARGINSETTLEAPIType transformBdoToXmlApiRqCreate(MarginSettlement dataObject) {
        return transformBdoToXmlApiType(dataObject, CbsXmlApiOperation.INSERT);
    }

    @Override
    protected XPSTRANMARGINSETTLEAPIType transformBdoToXmlApiRqUpdate(MarginSettlement dataObject) {
        return transformBdoToXmlApiType(dataObject, CbsXmlApiOperation.INSERT);
    }

    @Override
    protected XPSTRANMARGINSETTLEAPIType transformBdoToXmlApiRqDelete(MarginSettlement dataObject) {
        return null;
    }

    private XPSTRANMARGINSETTLEAPIType transformBdoToXmlApiType(MarginSettlement dataObject, CbsXmlApiOperation oper) {
    	MarginSettlementJpe jpe = jaxbSdoHelper.unwrap(dataObject);
    	XPSTRANMARGINSETTLEAPIType api = mapper.mapToApi(jpe, oper);
    	super.setTechColsFromDataObject(dataObject, api);
        return api;
    }

    @Override
    protected Map<String, String> executeStoredProcedure(String xmlApiReq, String xmlHeaderIn) {
        String xmlApiReqProcess = xmlApiReq.replaceAll("XPS_TRAN_MARGIN_SETTLE_API OPERATION=\"INSERT\"", "XPS_TRAN_MARGIN_SETTLE_API OPERATION=\"PROCESS_AUTHORIZE\"");
        return super.executeStoredProcedure(xmlApiReqProcess, xmlHeaderIn);
    }

    @Override
    protected MarginSettlement processXmlApiRs(MarginSettlement dataObject, XPSTRANMARGINSETTLEAPIType xmlApiRs) {
    	MarginSettlementJpe jpe = new MarginSettlementJpe();
        mapper.mapToJpe(xmlApiRs, jpe);
        MarginSettlement response = jaxbSdoHelper.wrap(jpe);
        return response;
    }

    @Override
    protected List<MarginSettlement> processXmlApiListRs(MarginSettlement dataObject, XPSTRANMARGINSETTLEAPIType xmlApiRs) {
        return null;
    }

    @Override
    protected Class<XPSTRANMARGINSETTLEAPIType> getXmlApiResponseClass() {
        return XPSTRANMARGINSETTLEAPIType.class;
    }

    @Override
    protected Long getIdFromDataObjectInstance(MarginSettlement dataObject) {
    	MarginSettlementJpe jpe = jaxbSdoHelper.unwrap(dataObject);
        return jpe.getInternalKey();
    }

    @Override
    protected EntityPath<MarginSettlementJpe> getEntityPath() {
        return QMarginSettlementJpe.marginSettlementJpe;
    }

	@Override
	public Long count(FindCriteria findCriteria, CbsHeader cbsHeader) {
		// TODO Auto-generated method stub
		return null;
	}
    

	@Override
	public String generateSwfMessage(Map<String, Object> params) {
		String swfMessage = null;
    	SwfMessageGroup msgGroup = jsonConversionMngr.convertToType(params.get("msgGroup"), SwfMessageGroup.class, null, null);
		if(params.get("module") != null){
			msgGroup.setModule(params.get("module").toString());
		} 
		MarginSettlement bdo = jsonConversionMngr.convertToType(params.get("transactionBdo"), MarginSettlement.class, null, null);
    	String swiftMessageFromQueue = getGeneratedSwiftMessage(bdo.getInternalKey(), "MST", msgGroup.getFormat(), msgGroup.getModule());
    	if(swiftMessageFromQueue != null){
    		return swiftMessageFromQueue;
    	}
		XPSTRANMARGINSETTLEAPIType xmlApiReq = transformBdoToXmlApiType(bdo, CbsXmlApiOperation.QUERY);
    	SettleMessagePreviewAddInfo addtlInfo = jsonConversionMngr.convertToType(params.get("parentInfo"), SettleMessagePreviewAddInfo.class, null, null);
    	swfMessage = transformToSwfFormat(xmlApiReq, msgGroup, addtlInfo);
		return swfMessage;
	}

	@Override
	protected MessageQOthers fillContext(Map<String, Object> adviceParams, VelocityContext context){
		MarginMaster master = jsonConversionMngr.convertToType(adviceParams.get("MarginMaster"), MarginMaster.class, null, null);
		context.put("MarginMaster", master);
		adviceParams.remove("MarginMaster");

		MarginSettlementDetails details = jsonConversionMngr.convertToType(adviceParams.get("bdo"), MarginSettlementDetails.class, null, null);
		context.put("MarginSettlementDetails", details);
		adviceParams.remove("bdo");

		if(details.getCommonSettleDepositRec() != null){
			context.put("CommonSettleDeposit", details.getCommonSettleDepositRec());
			Client client = clientService.getByPk(details.getCommonSettleDepositRec().getClientNo(), null);
			if(client != null){
				context.put("Client", client);
				adviceParams.put("Client", client);
				ClientContact contact = getClientContact(client, "POSTAL", null);
				context.put("ClientContact", contact);
			}
		}
		
		if(details.getInternalKey() != null) {
			Map<String, Object> filters = new HashMap<String, Object>();
			filters.put("tranInternalKey", details.getInternalKey());
			filters.put("tranEventType", "MTR");
			List<MessageQOthers> messageQList = messageQOthersService.query(0, -1, null, null, filters);
			if(messageQList != null && messageQList.size() > 0){
				return messageQList.get(0);
			}
		}
		return null;
	}

	

}
