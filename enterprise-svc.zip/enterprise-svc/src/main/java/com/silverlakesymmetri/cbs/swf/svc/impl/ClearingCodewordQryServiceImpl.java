package com.silverlakesymmetri.cbs.swf.svc.impl;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.mysema.query.types.EntityPath;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.exception.CbsRuntimeException;
import com.silverlakesymmetri.cbs.commons.jpa.entity.FindCriteriaJpe;
import com.silverlakesymmetri.cbs.commons.svc.AbstractBusinessService;
import com.silverlakesymmetri.cbs.swf.bdo.sdo.ClearingCodewordQry;
import com.silverlakesymmetri.cbs.swf.jpa.mapping.sdo.ClearingCodewordQryJpe;
import com.silverlakesymmetri.cbs.swf.jpa.mapping.sdo.SwfMsgFormatQryJpe;
import com.silverlakesymmetri.cbs.swf.jpa.mapping.sdo.id.ClearingCodewordQryPk;
import com.silverlakesymmetri.cbs.swf.svc.ClearingCodewordQryService;
import com.silverlakesymmetri.cbs.swf.jpa.mapping.sdo.QClearingCodewordQryJpe;

@Service
@Transactional
public class ClearingCodewordQryServiceImpl
		extends AbstractBusinessService<ClearingCodewordQry, ClearingCodewordQryJpe, ClearingCodewordQryPk>
		implements ClearingCodewordQryService {

	@Override
	public Long count(FindCriteria findCriteria, CbsHeader cbsHeader) {
        if (findCriteria == null) {
            return dataService.getRowCount(this.getEntityPath());
        } else {
            FindCriteriaJpe fc = jaxbSdoHelper.unwrap(findCriteria);
            return dataService.getRowCount(SwfMsgFormatQryJpe.class, fc);
        }
	}

	@Override
	protected ClearingCodewordQryPk getIdFromDataObjectInstance(ClearingCodewordQry bdo) {
		ClearingCodewordQryPk pk = new ClearingCodewordQryPk(bdo.getInternalKey(), bdo.getMessageType(), bdo.getTag());
		return pk;
	}

	@Override
	protected EntityPath<ClearingCodewordQryJpe> getEntityPath() {
		 return QClearingCodewordQryJpe.clearingCodewordQryJpe;
	}

	@Override
	public ClearingCodewordQry create(ClearingCodewordQry dataObject) {
		throw new CbsRuntimeException("Create operation is not supported by this service");
	}

	@Override
	public ClearingCodewordQry update(ClearingCodewordQry dataObject) {
		throw new CbsRuntimeException("Update operation is not supported by this service");
	}

	@Override
	public boolean delete(ClearingCodewordQry dataObject) {
		throw new CbsRuntimeException("Delete operation is not supported by this service");
	}

	@Override
	public List<ClearingCodewordQry> query(int offset, int resultLimit, String groupBy, String order,
			Map<String, Object> filters) {
		return super.query(offset, resultLimit, groupBy, order, filters);
	}

	@Override
	public List<ClearingCodewordQry> find(FindCriteria findCriteria, CbsHeader cbsHeader) {
		return super.find(findCriteria, cbsHeader);
	}

	@Override
	public ClearingCodewordQry getByPk(String publicKey, ClearingCodewordQry reference) {
		return super.getByPk(publicKey, reference);
	}

}
