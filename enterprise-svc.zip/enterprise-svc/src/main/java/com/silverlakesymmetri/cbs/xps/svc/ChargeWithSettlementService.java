package com.silverlakesymmetri.cbs.xps.svc;

import java.util.Map;

import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation;
import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation.ServiceOperationType;
import com.silverlakesymmetri.cbs.commons.bdo.sdo.DmsFile;
import com.silverlakesymmetri.cbs.commons.svc.BusinessService;
import com.silverlakesymmetri.cbs.xps.bdo.sdo.AdvicePreview;
import com.silverlakesymmetri.cbs.xps.bdo.sdo.ChargeWithSettlement;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.ChargeWithSettlementJpe;

public interface ChargeWithSettlementService extends BusinessService<ChargeWithSettlement, ChargeWithSettlementJpe> {
	public static final String XPS_CHARGESETTLEMENTSERVICE_GET = "ChargeWithSettlementService.get";
    public static final String XPS_CHARGESETTLEMENTSERVICE_CREATE = "ChargeWithSettlementService.create";
    public static final String XPS_CHARGESETTLEMENTSERVICE_UPDATE = "ChargeWithSettlementService.update";
    public static final String XPS_CHARGESETTLEMENTSERVICE_DELETE = "ChargeWithSettlementService.delete";
	public static final String SVC_OP_NAME_CHARGESETTLEMENTSERVICE_SWFMSG = "ChargeWithSettlementService.generateSwfMessage";
    public static final String SVC_OP_NAME_CHARGESETTLEMENTSERVICE_EMAILPREVIEW = "ChargeWithSettlementService.generateEmailPreview";
    public static final String SVC_OP_NAME_CHARGESETTLEMENTSERVICE_GENADVICE = "ChargeWithSettlementService.generateAdvice";
    
    @ServiceOperation(name = XPS_CHARGESETTLEMENTSERVICE_GET, type = ServiceOperationType.GET)
    public ChargeWithSettlement getByPk(String publicKey, ChargeWithSettlement reference);
    
    @ServiceOperation(name = XPS_CHARGESETTLEMENTSERVICE_CREATE)
    public ChargeWithSettlement create(ChargeWithSettlement dataObject);

    @ServiceOperation(name = XPS_CHARGESETTLEMENTSERVICE_UPDATE)
    public ChargeWithSettlement update(ChargeWithSettlement dataObject);

    @ServiceOperation(name = XPS_CHARGESETTLEMENTSERVICE_DELETE)
    public boolean delete(ChargeWithSettlement dataObject);

    @ServiceOperation(name = SVC_OP_NAME_CHARGESETTLEMENTSERVICE_SWFMSG, passParamAsMap = true)
    public String generateSwfMessage(Map<String, Object> params);
    
    @ServiceOperation(name = SVC_OP_NAME_CHARGESETTLEMENTSERVICE_EMAILPREVIEW, passParamAsMap = true)
    public AdvicePreview generateEmailPreview(Map<String, Object> params);
    
    @ServiceOperation(name = SVC_OP_NAME_CHARGESETTLEMENTSERVICE_GENADVICE, passParamAsMap = true)
    public DmsFile generateAdvice(Map<String, Object> params);
}