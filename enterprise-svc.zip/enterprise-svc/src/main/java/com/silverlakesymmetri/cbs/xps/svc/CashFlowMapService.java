package com.silverlakesymmetri.cbs.xps.svc;

import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.svc.BusinessService;
import com.silverlakesymmetri.cbs.xps.bdo.sdo.CashFlowMap;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.CashFlowMapJpe;

import java.util.List;
import java.util.Map;

public interface CashFlowMapService extends BusinessService<CashFlowMap, CashFlowMapJpe> {

    String SVC_OP_NAME_CASHFLOWMAPSERVICE_GET = "CashFlowMapService.get";
    String SVC_OP_NAME_CASHFLOWMAPSERVICE_QUERY = "CashFlowMapService.query";
    String SVC_OP_NAME_CASHFLOWMAPSERVICE_CREATE = "CashFlowMapService.create";
    String SVC_OP_NAME_CASHFLOWMAPSERVICE_UPDATE = "CashFlowMapService.update";
    String SVC_OP_NAME_CASHFLOWMAPSERVICE_DELETE = "CashFlowMapService.delete";
    String SVC_OP_NAME_CASHFLOWMAPSERVICE_FIND = "CashFlowMapService.find";

    @ServiceOperation(name = SVC_OP_NAME_CASHFLOWMAPSERVICE_GET, type = ServiceOperation.ServiceOperationType.GET)
    CashFlowMap getByPk(String publicKey, CashFlowMap reference);

    @ServiceOperation(name = SVC_OP_NAME_CASHFLOWMAPSERVICE_QUERY)
    List<CashFlowMap> query(int offset, int resultLimit, String groupBy, String order, Map<String, Object> filters);

    @ServiceOperation(name = SVC_OP_NAME_CASHFLOWMAPSERVICE_CREATE)
    CashFlowMap create(CashFlowMap dataObject);

    @ServiceOperation(name = SVC_OP_NAME_CASHFLOWMAPSERVICE_UPDATE)
    CashFlowMap update(CashFlowMap dataObject);

    @ServiceOperation(name = SVC_OP_NAME_CASHFLOWMAPSERVICE_DELETE)
    boolean delete(CashFlowMap dataObject);

    @ServiceOperation(name = SVC_OP_NAME_CASHFLOWMAPSERVICE_FIND)
    List<CashFlowMap> find(FindCriteria findCriteria, CbsHeader cbsHeader);
}
