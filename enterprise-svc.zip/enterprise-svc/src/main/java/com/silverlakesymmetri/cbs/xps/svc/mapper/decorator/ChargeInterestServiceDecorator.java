package com.silverlakesymmetri.cbs.xps.svc.mapper.decorator;

import org.mapstruct.MappingTarget;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.ChargeInterestJpe;
import com.silverlakesymmetri.cbs.xps.svc.mapper.ChargeInterestServiceMapper;
import com.silverlakesymmetri.cbs.xps.xmlapi.XPSTRANCHARGEDETAILAPIType;

public abstract class ChargeInterestServiceDecorator implements ChargeInterestServiceMapper {
	
	@Autowired
	@Qualifier("delegate")
	protected ChargeInterestServiceMapper delegate;

	@Override
	public XPSTRANCHARGEDETAILAPIType mapToApi(ChargeInterestJpe jpe, @MappingTarget XPSTRANCHARGEDETAILAPIType api){
		delegate.mapToApi(jpe, api);
		return api;
	}
	
	@Override
	public ChargeInterestJpe mapToJpe(XPSTRANCHARGEDETAILAPIType api, @MappingTarget ChargeInterestJpe jpe){
		delegate.mapToJpe(api, jpe);
		return jpe;
	}

}


