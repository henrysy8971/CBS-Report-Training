package com.silverlakesymmetri.cbs.xps.svc.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.velocity.VelocityContext;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.mysema.query.types.EntityPath;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.xmlapi.enums.CbsXmlApiOperation;
import com.silverlakesymmetri.cbs.mcl.bdo.sdo.Client;
import com.silverlakesymmetri.cbs.mcl.bdo.sdo.ClientContact;
import com.silverlakesymmetri.cbs.swf.bdo.sdo.SwfMessageGroup;
import com.silverlakesymmetri.cbs.xps.bdo.sdo.MarginAmendment;
import com.silverlakesymmetri.cbs.xps.bdo.sdo.MarginAmendmentWithSettlement;
import com.silverlakesymmetri.cbs.xps.bdo.sdo.MarginSettlement;
import com.silverlakesymmetri.cbs.xps.bdo.sdo.MarginSettlementDetails;
import com.silverlakesymmetri.cbs.xps.bdo.sdo.MarginWithSettlement;
import com.silverlakesymmetri.cbs.xps.bdo.sdo.MessageQOthers;
import com.silverlakesymmetri.cbs.xps.bdo.sdo.SettleMessagePreviewAddInfo;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.MarginAmendmentWithSettlementJpe;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.QMarginAmendmentWithSettlementJpe;
import com.silverlakesymmetri.cbs.xps.svc.AbstractXmlApiAdviceCapableBusinessService;
import com.silverlakesymmetri.cbs.xps.svc.ChargesUtilityService;
import com.silverlakesymmetri.cbs.xps.svc.MarginAmendmentWithSettlementService;
import com.silverlakesymmetri.cbs.xps.svc.MarginMasterService;
import com.silverlakesymmetri.cbs.xps.svc.MarginSettlementService;
import com.silverlakesymmetri.cbs.xps.svc.MarginWithSettlementService;
import com.silverlakesymmetri.cbs.xps.svc.ext.BgtChargesServiceExt;
import com.silverlakesymmetri.cbs.xps.svc.ext.TfnChargesServiceExt;
import com.silverlakesymmetri.cbs.xps.svc.mapper.MarginAmendmentWithSettlementServiceMapper;
import com.silverlakesymmetri.cbs.xps.svc.mapper.MarginSettlementServiceMapper;
import com.silverlakesymmetri.cbs.xps.xmlapi.XPSTRANMARGINAMENDMENTWITHSETTLEAPIType;
import com.silverlakesymmetri.cbs.xps.xmlapi.XPSTRANMARGINSETTLEAPIType;

@Service
@Transactional
public class MarginAmendmentWithSettlementServiceImpl extends AbstractXmlApiAdviceCapableBusinessService<MarginAmendmentWithSettlement, MarginAmendmentWithSettlementJpe, Long, XPSTRANMARGINAMENDMENTWITHSETTLEAPIType, XPSTRANMARGINAMENDMENTWITHSETTLEAPIType> 
	implements MarginAmendmentWithSettlementService {
	
	@Autowired
	private MarginAmendmentWithSettlementServiceMapper mapper; 
	
	@Autowired
    private MarginSettlementServiceMapper settlementMapper;
	
	@Autowired
	protected MarginSettlementService marginSettlementService;
	
	@Autowired
	protected MarginMasterService marginMasterService;
	
	@Autowired
	protected MarginWithSettlementService marginWithSettlementService;

	@Autowired
	private ChargesUtilityService chargesUtility;

	@Override
    public MarginAmendmentWithSettlement getByPk(String publicKey, MarginAmendmentWithSettlement reference) {
		Long internalKey = Long.parseLong(publicKey);
		MarginAmendmentWithSettlement bdo =  jaxbSdoHelper.createSdoInstance(MarginAmendmentWithSettlement.class);
		XPSTRANMARGINAMENDMENTWITHSETTLEAPIType request = new XPSTRANMARGINAMENDMENTWITHSETTLEAPIType();
		request.setINTERNALKEY(internalKey);
    	request.setOPERATION(CbsXmlApiOperation.QUERY.toString());
    	XPSTRANMARGINAMENDMENTWITHSETTLEAPIType response = queryXmlApiRs(request);
    	MarginAmendmentWithSettlement result = null;
    	if(response.getINTERNALKEY() != null){
    		result = processXmlApiRs(bdo, response);
    		if(result.getSettlementStructRec() == null && response.getSETTLEMENT() != null){
    			MarginSettlement settlement = marginSettlementService.getByPk(publicKey, null);
            	result.setSettlementStructRec(settlement);
    		}
    	}
    	return result;
	}
	
	@Override
	public MarginAmendmentWithSettlement getAttachedMarginAmendmentWithSettlement(Map<String, Object> params) {
		String refNo = params.get("refNo").toString();
		String instrumentType = params.get("instrumentType").toString();
    	Long eventSeq = Long.parseLong(params.get("eventSeq").toString());
    	Long relInternalKey = null;
    	if(instrumentType.equalsIgnoreCase("BG")){
    		BgtChargesServiceExt bgtChargesServiceExt = chargesUtility.getBgtChargeServiceExtensionPoint();
    		if(bgtChargesServiceExt != null){
	    		relInternalKey = bgtChargesServiceExt.getBgIssueAmendEventKey(refNo, eventSeq);
    		}
    	} else if(instrumentType.equalsIgnoreCase("LC")) {
    		TfnChargesServiceExt tfnChargesServiceExt = chargesUtility.getTfnChargeServiceExtensionPoint();
    		if(tfnChargesServiceExt != null){
	    		relInternalKey = tfnChargesServiceExt.getImportLcAmendEventKey(refNo, eventSeq);
    		}
    	}
    	
		XPSTRANMARGINAMENDMENTWITHSETTLEAPIType request = new XPSTRANMARGINAMENDMENTWITHSETTLEAPIType();
		request.setRELINTERNALKEY(relInternalKey);
    	request.setOPERATION(CbsXmlApiOperation.QUERY.toString());
    	XPSTRANMARGINAMENDMENTWITHSETTLEAPIType response  = queryXmlApiRs(request);
    	MarginAmendmentWithSettlement result = null;
    	if(response.getINTERNALKEY() != null && response.getMARGININTERNALKEY() != null){
    		result = processXmlApiRs(jaxbSdoHelper.createSdoInstance(MarginAmendmentWithSettlement.class), response);
    		MarginWithSettlement master = marginWithSettlementService.getByPk(response.getMARGININTERNALKEY().toString(), null);
        	result.setMarginStructRec(master.getMarginStructRec());
        	if(result.getSettlementStructRec() == null) {
        		result.setSettlementStructRec(master.getSettlementStructRec());
        	}
    	}
		return result;
	}

	@Override
	public List<MarginAmendmentWithSettlement> find(FindCriteria findCriteria, CbsHeader cbsHeader) {
	    return super.find(findCriteria, cbsHeader);
	}
	
	@Override
	public List<MarginAmendmentWithSettlement> query(int offset, int resultLimit, String groupBy, String order, Map<String, Object> filters) {
        return super.query(offset, resultLimit, groupBy, order, filters);
    }
	
	@Override
	public MarginAmendmentWithSettlement create(MarginAmendmentWithSettlement dataObject) {
		return super.create(dataObject);
	}

	@Override
	protected MessageQOthers fillContext(Map<String, Object> adviceParams, VelocityContext context) {
		MarginAmendment marginAmendment = jsonConversionMngr.convertToType(adviceParams.get("MarginAmendment"), MarginAmendment.class, null, null);
		context.put("MarginAmendment", marginAmendment);
		adviceParams.remove("MarginAmendment");
		
		MarginSettlementDetails details = jsonConversionMngr.convertToType(adviceParams.get("bdo"), MarginSettlementDetails.class, null, null);
		context.put("MarginSettlementDetails", details);
		adviceParams.remove("bdo");
		
		if(details.getCommonSettleDepositRec() != null){
			context.put("CommonSettleDeposit", details.getCommonSettleDepositRec());
			Client client = clientService.getByPk(details.getCommonSettleDepositRec().getClientNo(), null);
			if(client != null){
				context.put("Client", client);
				adviceParams.put("Client", client);
				ClientContact contact = getClientContact(client, "POSTAL", null);
				context.put("ClientContact", contact);
			}
		}

		if(details.getInternalKey() != null) {
			Map<String, Object> filters = new HashMap<String, Object>();
			filters.put("tranInternalKey", details.getInternalKey());
			filters.put("tranEventType", "MTR");
			List<MessageQOthers> messageQList = messageQOthersService.query(0, -1, null, null, filters);
			if(messageQList != null && messageQList.size() > 0){
				return messageQList.get(0);
			}
		}
		return null;
	}

	@Override
	public String generateSwfMessage(Map<String, Object> params) {
		String swfMessage = null;
    	SwfMessageGroup msgGroup = jsonConversionMngr.convertToType(params.get("msgGroup"), SwfMessageGroup.class, null, null);
		if(params.get("module") != null){
			msgGroup.setModule(params.get("module").toString());
		} 
		MarginAmendmentWithSettlement bdo = jsonConversionMngr.convertToType(params.get("transactionBdo"), MarginAmendmentWithSettlement.class, null, null);
    	String swiftMessageFromQueue = getGeneratedSwiftMessage(bdo.getInternalKey(), "MMD", msgGroup.getFormat(), msgGroup.getModule());
    	if(swiftMessageFromQueue != null){
    		return swiftMessageFromQueue;
    	}
    	XPSTRANMARGINAMENDMENTWITHSETTLEAPIType xmlApiReq = transformBdoToXmlApiType(bdo, CbsXmlApiOperation.QUERY);
    	SettleMessagePreviewAddInfo addtlInfo = jsonConversionMngr.convertToType(params.get("parentInfo"), SettleMessagePreviewAddInfo.class, null, null);
    	swfMessage = transformToSwfFormat(xmlApiReq, msgGroup, addtlInfo);
		return swfMessage;
	}
	
	private XPSTRANMARGINAMENDMENTWITHSETTLEAPIType transformBdoToXmlApiType(MarginAmendmentWithSettlement dataObject, CbsXmlApiOperation oper) {
		MarginAmendmentWithSettlementJpe jpe = jaxbSdoHelper.unwrap(dataObject);
		XPSTRANMARGINAMENDMENTWITHSETTLEAPIType api = mapper.mapToApi(jpe, oper);
		if(jpe.getSettlementStructRec() != null){
			XPSTRANMARGINSETTLEAPIType settlement = settlementMapper.mapToApi(jpe.getSettlementStructRec(), oper);
    		super.setTechColsFromDataObject(dataObject.getSettlementStructRec(), settlement);
    		api.setSETTLEMENT(settlement);
		}
		super.setTechColsFromDataObject(dataObject, api);
        return api;
	}

	@Override
	protected XPSTRANMARGINAMENDMENTWITHSETTLEAPIType transformBdoToXmlApiRqCreate(
			MarginAmendmentWithSettlement dataObject) {
		return transformBdoToXmlApiType(dataObject, CbsXmlApiOperation.INSERT);
	}

	@Override
	protected XPSTRANMARGINAMENDMENTWITHSETTLEAPIType transformBdoToXmlApiRqUpdate(
			MarginAmendmentWithSettlement dataObject) {
		return null;
	}

	@Override
	protected XPSTRANMARGINAMENDMENTWITHSETTLEAPIType transformBdoToXmlApiRqDelete(
			MarginAmendmentWithSettlement dataObject) {
		return null;
	}
	
	@Override
    protected Map<String, String> executeStoredProcedure(String xmlApiReq, String xmlHeaderIn) {
        String xmlApiReqProcess = xmlApiReq.replaceAll("XPS_TRAN_MARGIN_AMENDMENT_WITH_SETTLE_API OPERATION=\"INSERT\"", "XPS_TRAN_MARGIN_AMENDMENT_WITH_SETTLE_API OPERATION=\"PROCESS_AUTHORIZE\"");
        return super.executeStoredProcedure(xmlApiReqProcess, xmlHeaderIn);
    }

	@Override
	protected MarginAmendmentWithSettlement processXmlApiRs(MarginAmendmentWithSettlement dataObject,
			XPSTRANMARGINAMENDMENTWITHSETTLEAPIType xmlApiRs) {
		MarginAmendmentWithSettlementJpe jpe =  jaxbSdoHelper.unwrap(dataObject);
        jpe = mapper.mapToJpe(xmlApiRs, jpe);
        jpe.setInternalKey(xmlApiRs.getINTERNALKEY());
        return jaxbSdoHelper.wrap(jpe);
	}

	@Override
	protected List<MarginAmendmentWithSettlement> processXmlApiListRs(MarginAmendmentWithSettlement dataObject,
			XPSTRANMARGINAMENDMENTWITHSETTLEAPIType xmlApiRs) {
		return null;
	}

	@Override
	protected Class<XPSTRANMARGINAMENDMENTWITHSETTLEAPIType> getXmlApiResponseClass() {
		return XPSTRANMARGINAMENDMENTWITHSETTLEAPIType.class;
	}

	@Override
	protected Long getIdFromDataObjectInstance(MarginAmendmentWithSettlement dataObject) {
		return dataObject.getMarginStructRec().getInternalKey();
	}

	@Override
	protected EntityPath<MarginAmendmentWithSettlementJpe> getEntityPath() {
		return QMarginAmendmentWithSettlementJpe.marginAmendmentWithSettlementJpe;
	}


	
}
