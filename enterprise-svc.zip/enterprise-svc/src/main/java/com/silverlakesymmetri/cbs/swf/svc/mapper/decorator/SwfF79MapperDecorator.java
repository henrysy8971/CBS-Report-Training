package com.silverlakesymmetri.cbs.swf.svc.mapper.decorator;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

import com.silverlakesymmetri.cbs.swf.jpa.mapping.sdo.SwfF79Jpe;
import com.silverlakesymmetri.cbs.swf.svc.mapper.mapping.SwfF79Mapper;
import com.silverlakesymmetri.cbs.swf.xmlapi.SWFF79TYPEType;

public abstract class SwfF79MapperDecorator implements SwfF79Mapper {
	
	@Autowired
	@Qualifier("delegate")
	protected SwfF79Mapper delegate;

	@Override
	public SWFF79TYPEType mapToApi(SwfF79Jpe jpe){
		SWFF79TYPEType swfF79 = delegate.mapToApi(jpe);
		if(swfF79 != null && swfF79.getCODE() == null && swfF79.getNARRATIVE() == null){
			return null;
		}
		return swfF79;
	}
	
	@Override
	public SwfF79Jpe mapToJpe(SWFF79TYPEType api){
		return delegate.mapToJpe(api);
	}
	
}
