package com.silverlakesymmetri.cbs.xps.svc.impl;

import java.util.HashMap;
import java.util.Map;

import com.silverlakesymmetri.cbs.commons.bdo.BpmStatusEnum;
import com.silverlakesymmetri.cbs.commons.bdo.CbsBpmInfo;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.mysema.query.types.EntityPath;
import com.silverlakesymmetri.cbs.commons.svc.AbstractBusinessService;
import com.silverlakesymmetri.cbs.mcl.bdo.sdo.Client;
import com.silverlakesymmetri.cbs.mcl.jpa.mapping.sdo.ClientJpe;
import com.silverlakesymmetri.cbs.mcl.jpa.mapping.sdo.QClientJpe;
import com.silverlakesymmetri.cbs.mcl.jpa.mapping.sdo.util.MclJpeConstants;
import com.silverlakesymmetri.cbs.swf.bdo.sdo.BicDirectory;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.util.XpsDepstorHelper;
import com.silverlakesymmetri.cbs.xps.svc.DepAcctClientIndService;

import commonj.sdo.ChangeSummary;
import commonj.sdo.DataObject;
import commonj.sdo.ChangeSummary.Setting;

@Service
@Transactional
public class DepAcctClientIndServiceImpl extends AbstractBusinessService<Client, ClientJpe, Long> implements DepAcctClientIndService {

	@Autowired
	XpsDepstorHelper xpsDepstorHelper;
	
	@Override
	public Client updClientAcct(Client dataObject) {
		Map<String, Object> params = new HashMap<String, Object>();
        params.put("clientNo", dataObject.getClientNo());
        Long result = dataService.getWithNamedQuery(MclJpeConstants.CLIENT_JPE_FIND_CLIENT_ID_USING_CLIENT_NO, params, Long.class);
        xpsDepstorHelper.updateAcctClientInd(result, dataObject.getClientIndicator());
		return dataObject;
	}

	@Override
	protected Long getIdFromDataObjectInstance(Client dataObject) {
		Map<String, Object> params = new HashMap<String, Object>();
        params.put("clientNo", dataObject.getClientNo());
        Long result = dataService.getWithNamedQuery(MclJpeConstants.CLIENT_JPE_FIND_CLIENT_ID_USING_CLIENT_NO, params, Long.class);
		return result;
	}

	@Override
	protected EntityPath<ClientJpe> getEntityPath() {
		return QClientJpe.clientJpe;
	}

}
