package com.silverlakesymmetri.cbs.swf.svc.mapper.decorator;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

import com.silverlakesymmetri.cbs.swf.jpa.mapping.sdo.SwfF74Jpe;
import com.silverlakesymmetri.cbs.swf.svc.mapper.mapping.SwfF74Mapper;
import com.silverlakesymmetri.cbs.swf.xmlapi.SWFF74TYPEType;

public abstract class SwfF74MapperDecorator implements SwfF74Mapper {
	
	@Autowired
	@Qualifier("delegate")
	protected SwfF74Mapper delegate;

	@Override
	public SWFF74TYPEType mapToApi(SwfF74Jpe jpe){
		SWFF74TYPEType swfF74 = delegate.mapToApi(jpe);
		if(swfF74 != null){
			if(swfF74.getDETAILS() == null || swfF74.getDETAILS().getSWFF74NARRATIVETYPE() == null || swfF74.getDETAILS().getSWFF74NARRATIVETYPE().size() == 0){
				return null;
			}
		}
		return swfF74;
	}
	
	@Override
	public SwfF74Jpe mapToJpe(SWFF74TYPEType api){
		return delegate.mapToJpe(api);
	}
	
}
