package com.silverlakesymmetri.cbs.xps.svc.impl;

import com.mysema.query.types.EntityPath;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.svc.AbstractBusinessService;
import com.silverlakesymmetri.cbs.xps.bdo.sdo.DepDepositSettleQry;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.DepDepositSettleQryJpe;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.QDepDepositSettleQryJpe;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.id.DepDepositSettleQryPk;
import com.silverlakesymmetri.cbs.xps.svc.DepDepositSettleQryService;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Map;

@Service
@Transactional
public class DepDepositSettleQryServiceImpl extends AbstractBusinessService<DepDepositSettleQry, DepDepositSettleQryJpe, DepDepositSettleQryPk>
        implements DepDepositSettleQryService {

    @Override
    protected DepDepositSettleQryPk getIdFromDataObjectInstance(DepDepositSettleQry dataObject) {
        return new DepDepositSettleQryPk(dataObject.getSettleMethod(), dataObject.getPayRecCode());
    }

    @Override
    protected EntityPath<DepDepositSettleQryJpe> getEntityPath() {
        return QDepDepositSettleQryJpe.depDepositSettleQryJpe;
    }

    @Override
    public List<DepDepositSettleQry> query(int offset, int resultLimit, String groupBy, String order, Map<String, Object> filters) {
        return super.query(offset, resultLimit, groupBy, order, filters);
    }

    @Override
    public List<DepDepositSettleQry> find(FindCriteria findCriteria, CbsHeader cbsHeader) {
        return super.find(findCriteria, cbsHeader);
    }

    @Override
    public DepDepositSettleQry getByPk(String publicKey, DepDepositSettleQry reference) {
        return super.getByPk(publicKey, reference);
    }
}
