package com.silverlakesymmetri.cbs.xps.svc;

import java.util.List;
import java.util.Map;

import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation;
import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation.ServiceOperationType;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.svc.BusinessService;
import com.silverlakesymmetri.cbs.xps.bdo.sdo.MessageLinkingMaster;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.MessageLinkingMasterJpe;

public interface MessageLinkingMasterService extends BusinessService<MessageLinkingMaster, MessageLinkingMasterJpe> {
	public static final String XPS_OP_NAME_MESSAGELINKINGMASTERSERVICE_GET = "MessageLinkingMasterService.get";
    public static final String XPS_OP_NAME_MESSAGELINKINGMASTERSERVICE_QUERY = "MessageLinkingMasterService.query";
    public static final String XPS_OP_NAME_MESSAGELINKINGMASTERSERVICE_FIND = "MessageLinkingMasterService.find";
    public static final String XPS_OP_NAME_MESSAGELINKINGMASTERSERVICE_CREATE = "MessageLinkingMasterService.create";
    public static final String XPS_OP_NAME_MESSAGELINKINGMASTERSERVICE_UPDATE = "MessageLinkingMasterService.update";
    public static final String XPS_OP_NAME_MESSAGELINKINGMASTERSERVICE_DELETE = "MessageLinkingMasterService.delete";
    public static final String XPS_OP_NAME_MESSAGELINKINGMASTERSERVICE_GET_MSG = "MessageLinkingMasterService.getmessagedetails";
    
    @ServiceOperation(name = XPS_OP_NAME_MESSAGELINKINGMASTERSERVICE_GET, type = ServiceOperationType.GET)
    public MessageLinkingMaster getByPk(String publicKey, MessageLinkingMaster reference);

    @ServiceOperation(name = XPS_OP_NAME_MESSAGELINKINGMASTERSERVICE_QUERY)
    public List<MessageLinkingMaster> query(int offset, int resultLimit, String groupBy, String order, Map<String, Object> filters);
    
    @ServiceOperation(name = XPS_OP_NAME_MESSAGELINKINGMASTERSERVICE_FIND)
    public List<MessageLinkingMaster> find(FindCriteria findCriteria, CbsHeader cbsHeader);
    
    @ServiceOperation(name = XPS_OP_NAME_MESSAGELINKINGMASTERSERVICE_CREATE)
    public MessageLinkingMaster create(MessageLinkingMaster dataObject);

     @ServiceOperation(name = XPS_OP_NAME_MESSAGELINKINGMASTERSERVICE_UPDATE)
    public MessageLinkingMaster update(MessageLinkingMaster dataObject);

    @ServiceOperation(name = XPS_OP_NAME_MESSAGELINKINGMASTERSERVICE_DELETE)
    public boolean delete(MessageLinkingMaster dataObject);
    
    @ServiceOperation(name = XPS_OP_NAME_MESSAGELINKINGMASTERSERVICE_GET_MSG, type = ServiceOperation.ServiceOperationType.GET)
	public String getMessageDetails(Long internalKey, String direction);
}
