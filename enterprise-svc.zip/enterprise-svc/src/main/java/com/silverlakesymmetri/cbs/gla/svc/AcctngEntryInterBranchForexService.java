package com.silverlakesymmetri.cbs.gla.svc;

import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation;
import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation.ServiceOperationType;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.svc.BusinessService;
import com.silverlakesymmetri.cbs.csd.bdo.sdo.Currency;
import com.silverlakesymmetri.cbs.csd.bdo.sdo.ProfitCentre;
import com.silverlakesymmetri.cbs.gla.bdo.sdo.GlManualBatchGlCodeQry;
import com.silverlakesymmetri.cbs.gla.bdo.sdo.GlAccountingEntriesInterBranchForex;
import com.silverlakesymmetri.cbs.gla.jpa.mapping.sdo.GlAccountingEntriesInterBranchForexJpe;
import com.silverlakesymmetri.cbs.mcl.bdo.sdo.Client;

import java.util.List;
import java.util.Map;

public interface AcctngEntryInterBranchForexService extends BusinessService<GlAccountingEntriesInterBranchForex, GlAccountingEntriesInterBranchForexJpe> {

	public static final String SVC_OP_NAME_ACCTNGENTRYINTERBRANCHFXSERVICE_GET = "acctngEntriesInterBranchForexService.get";
	public static final String SVC_OP_NAME_ACCTNGENTRYINTERBRANCHFXSERVICE__PROCESS = "acctngEntriesInterBranchForexService.processAuthorize";


	@ServiceOperation(name = SVC_OP_NAME_ACCTNGENTRYINTERBRANCHFXSERVICE_GET, type = ServiceOperationType.GET)
	public GlAccountingEntriesInterBranchForex getByPk(String publicKey, GlAccountingEntriesInterBranchForex reference);

	@ServiceOperation(name = SVC_OP_NAME_ACCTNGENTRYINTERBRANCHFXSERVICE__PROCESS, type=ServiceOperationType.EXECUTE)
	public GlAccountingEntriesInterBranchForex processAuthorize(GlAccountingEntriesInterBranchForex dataObject);


}
