package com.silverlakesymmetri.cbs.xps.svc.mapper.decorator;

import org.mapstruct.Context;
import org.mapstruct.MappingTarget;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

import com.silverlakesymmetri.cbs.commons.xmlapi.enums.CbsXmlApiOperation;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.MessageQJpe;
import com.silverlakesymmetri.cbs.xps.svc.mapper.MessageQServiceMapper;
import com.silverlakesymmetri.cbs.xps.xmlapi.XPSMESSAGEQCUSTOMADVICEAPIType;

public abstract class MessageQServiceDecorator implements MessageQServiceMapper {
	
	@Autowired
	@Qualifier("delegate")
	protected MessageQServiceMapper delegate;

	@Override
	public XPSMESSAGEQCUSTOMADVICEAPIType mapToApi(MessageQJpe jpe, @Context CbsXmlApiOperation oper){
		XPSMESSAGEQCUSTOMADVICEAPIType req = (XPSMESSAGEQCUSTOMADVICEAPIType) delegate.mapToApi(jpe, oper);
		return  req;
	}
	
	@Override
	public MessageQJpe mapToJpe(XPSMESSAGEQCUSTOMADVICEAPIType api, @MappingTarget MessageQJpe jpe){
		delegate.mapToJpe(api, jpe);
		return jpe;
	}

}


