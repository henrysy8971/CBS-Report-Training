package com.silverlakesymmetri.cbs.lpm.svc;


import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation;
import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation.ServiceOperationType;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.svc.BusinessService;
import com.silverlakesymmetri.cbs.csd.gla.bdo.sdo.ChartAccount;
import com.silverlakesymmetri.cbs.lpm.bdo.sdo.ClearingDirectory;
import com.silverlakesymmetri.cbs.lpm.jpa.mapping.sdo.ClearingDirectoryJpe;

import java.util.List;
import java.util.Map;

public interface ClearingDirectoryService extends BusinessService<ClearingDirectory, ClearingDirectoryJpe> {

    public static final String SVC_OP_NAME_CLEARING_DIRECTORY_SERVICE_GET = "ClearingDirectoryService.get";
    public static final String SVC_OP_NAME_CLEARING_DIRECTORY_SERVICE_QUERY = "ClearingDirectoryService.query";
    public static final String SVC_OP_NAME_CLEARING_DIRECTORY_SERVICE_FIND = "ClearingDirectoryService.find";
    public static final String SVC_OP_NAME_CLEARING_DIRECTORY_SERVICE_CREATE = "ClearingDirectoryService.create";
    public static final String SVC_OP_NAME_CLEARING_DIRECTORY_SERVICE_UPDATE = "ClearingDirectoryService.update";
    public static final String SVC_OP_NAME_CLEARING_DIRECTORY_SERVICE_DELETE = "ClearingDirectoryService.delete";
    public static final String SVC_OP_NAME_CLEARING_DIRECTORY_SERVICE_BULK_CREATE = "ClearingDirectoryService.bulkCreate";

    @ServiceOperation(name = SVC_OP_NAME_CLEARING_DIRECTORY_SERVICE_GET, type = ServiceOperationType.GET)
    public ClearingDirectory getByPk(String publicKey, ClearingDirectory reference);

    @ServiceOperation(name = SVC_OP_NAME_CLEARING_DIRECTORY_SERVICE_QUERY)
    public List<ClearingDirectory> query(int offset, int resultLimit, String groupBy, String order, Map<String, Object> filters);

    @ServiceOperation(name = SVC_OP_NAME_CLEARING_DIRECTORY_SERVICE_FIND)
    public List<ClearingDirectory> find(FindCriteria findCriteria, CbsHeader cbsHeader);

    @ServiceOperation(name = SVC_OP_NAME_CLEARING_DIRECTORY_SERVICE_CREATE)
    public ClearingDirectory create(ClearingDirectory dataObject);

    @ServiceOperation(name = SVC_OP_NAME_CLEARING_DIRECTORY_SERVICE_UPDATE)
    public ClearingDirectory update(ClearingDirectory dataObject);

    @ServiceOperation(name = SVC_OP_NAME_CLEARING_DIRECTORY_SERVICE_DELETE)
    public boolean delete(ClearingDirectory dataObject);

    @ServiceOperation(name = SVC_OP_NAME_CLEARING_DIRECTORY_SERVICE_BULK_CREATE, type = ServiceOperationType.EXECUTE)
    public boolean bulkCreate(List<ClearingDirectory> bdoList);

}