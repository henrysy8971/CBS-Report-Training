package com.silverlakesymmetri.cbs.xps.svc.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.inject.Inject;

import org.apache.commons.lang3.StringUtils;
import org.springframework.batch.core.JobParametersInvalidException;
import org.springframework.batch.core.UnexpectedJobExecutionException;
import org.springframework.batch.core.launch.JobOperator;
import org.springframework.batch.core.launch.JobParametersNotFoundException;
import org.springframework.batch.core.launch.NoSuchJobException;
import org.springframework.batch.core.repository.JobExecutionAlreadyRunningException;
import org.springframework.batch.core.repository.JobInstanceAlreadyCompleteException;
import org.springframework.batch.core.repository.JobRestartException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.silverlakesymmetri.cbs.commons.batch.bdo.sdo.JobInfo;
import com.silverlakesymmetri.cbs.commons.batch.svc.JobMaintenanceService;
import com.silverlakesymmetri.cbs.commons.bdo.CbsBusinessDataObject;
import com.silverlakesymmetri.cbs.commons.event.CbsEvent;
import com.silverlakesymmetri.cbs.commons.event.CbsEventData;
import com.silverlakesymmetri.cbs.commons.event.impl.BpmAwareEventConsumer;
import com.silverlakesymmetri.cbs.commons.exception.CbsRuntimeException;
import com.silverlakesymmetri.cbs.commons.exception.base.CbsServiceException;
import com.silverlakesymmetri.cbs.commons.jpa.mapping.sdo.FileFormatOutJpe;
import com.silverlakesymmetri.cbs.commons.jpa.mapping.sdo.RegistryJpe;
import com.silverlakesymmetri.cbs.commons.jpa.mapping.sdo.id.FileFormatOutPk;
import com.silverlakesymmetri.cbs.commons.jpa.mapping.sdo.id.RegistryPk;
import com.silverlakesymmetri.cbs.commons.jpa.service.CbsGenericDataService;
import com.silverlakesymmetri.cbs.commons.logging.CbsAppLogger;
import com.silverlakesymmetri.cbs.commons.logging.CbsAppLoggerFactory;
import com.silverlakesymmetri.cbs.commons.svc.LoginService;
import com.silverlakesymmetri.cbs.commons.svc.util.CbsAsychronousTask;
import com.silverlakesymmetri.cbs.commons.svc.util.CbsAsychronousTaskSupport;
import com.silverlakesymmetri.cbs.commons.svc.util.CbsTransactionHelper;
import com.silverlakesymmetri.cbs.xps.bdo.sdo.MessageControlQWrapper;
import com.silverlakesymmetri.cbs.xps.enums.XpsGlobalConstants;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.MessageQJpe;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.util.XpsJpeConstants;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.util.XpsStorHelper;
import com.silverlakesymmetri.cbs.xps.svc.batch.processor.MessageQueueListItemProcessor;

@Service("messageControlQWrapperEventConsumer")
public class MessageControlQWrapperEventConsumerImpl extends BpmAwareEventConsumer {
	private CbsAppLogger logger = CbsAppLoggerFactory.getLogger(MessageControlQWrapperEventConsumerImpl.class.getName());
	
	private static final String STATUS_SENDING = "D"; 
	private static final String STATUS_FAILED = "F";
	private static final String JOB_NAME = "XpsMessageQueue.SendMessageJob";
	private static final String FILE_SEPARATOR = System.getProperty("file.separator");
	private static final String ATTR_SPOOL_DIR = "spoolDirectory";
	private static final String ATTR_INTERNAL_KEY_LIST = "internalKeyList";
	private static final String STEP_SPOOL = "SPOOL";
	private static final String JOB_WITH_FAILED_EXECUTION = "CBS.BATCH.JOB.MAINTENANCE.0001";
	private static final String COMMA = ",";
	private static final String EQUAL = "=";
	private static final String LIST_DELIMITER = "~";

    @Autowired(required = true)
    JobMaintenanceService jobMaintenanceService;
    @Autowired
    XpsStorHelper xpsStorHelper;
    @Autowired(required = true)
    @Qualifier("cbsGenericDataService")
    protected CbsGenericDataService dataService;
    @Autowired
    private JobOperator _jobOperatorBean;    
    @Inject
    private CbsAsychronousTaskSupport _asynchTaskSupport;
    @Autowired
    protected CbsTransactionHelper cbsTransactionHelper;
    @Autowired
    protected LoginService loginService;

	@Override
	protected boolean handleEvent(CbsEvent anEvent) {
		logger.info("Handling of event started");
		
		String warningMsg = null;
		
		try {
			CbsEventData<?> evtData = anEvent.getCbsEventData();
			if (evtData != null && evtData.getDataType() == CbsEventData.Type.BDO) {
				CbsBusinessDataObject bdo = (CbsBusinessDataObject) evtData.getEventData();
				if (bdo != null) {
					MessageControlQWrapper wrapper = (MessageControlQWrapper) bdo;
					if(STATUS_SENDING.equals(wrapper.getStatus()) && wrapper.getInternalKeyList() != null){
						//List<Long> internalKeyList = (List<Long>) wrapper.getInternalKeyList();
						doJob(wrapper);
					} else {
						warningMsg = "Job (" + JOB_NAME + ") was not invoked";						
					}
				} else {
					warningMsg = "evtData.getEventData is null";
				}
			}
			
			if(warningMsg!=null){				
				logger.warn(warningMsg);
			}
		} catch (Exception e) {
			logger.error(e.getMessage());
			e.printStackTrace();
			anEvent.setProcessingException(e);
		}
		
		return true;
	}
	
	private void doJob(MessageControlQWrapper bdo) {
		logger.info("Attempt to start job: {}", JOB_NAME);
		
		List<Long> internalKeyList = new ArrayList<>();
		for(Object key: bdo.getInternalKeyList()){
			internalKeyList.add((Long) key);
		}
		
		JobInfo jobInfo = jobMaintenanceService.read(JOB_NAME);
		
		String dir = xpsStorHelper.getFileDir(XpsGlobalConstants.SWIFT_FORMAT, STEP_SPOOL); 
		if(StringUtils.isBlank(dir)){
			dir = getSpoolDir();
		}
		if(FILE_SEPARATOR.equals("\\")){
			dir = dir.replaceAll("\\\\", "\\\\\\\\");
		}
		String swiftMessageSeparator = getSwiftMessageSeparator();
		if(StringUtils.isBlank(swiftMessageSeparator)){
			swiftMessageSeparator = XpsGlobalConstants.DEFAULT_SWIFT_MSG_SEPARATOR;
		}

		StringBuilder sb = new StringBuilder();
		sb.append(MessageQueueListItemProcessor.SWIFT_SPOOL_DIRECTORY_ATTR).append(EQUAL).append(dir); //directory
		sb.append(COMMA).append(MessageQueueListItemProcessor.SWIFT_MESSAGE_SEPARATOR_ATTR).append(EQUAL).append(swiftMessageSeparator); //separator
		sb.append(COMMA).append(MessageQueueListItemProcessor.SWIFT_FILE_NAME_ATTR).append(EQUAL).append(getFileName()); //filename
		sb.append(COMMA).append(ATTR_INTERNAL_KEY_LIST).append(EQUAL).append(StringUtils.join(internalKeyList, LIST_DELIMITER)); //internalKeyList
		String jobParam = sb.toString();
		
		boolean updateStatusToFail = false;
		try {				
			jobMaintenanceService.start(jobInfo, jobParam);
		} catch (CbsRuntimeException cbsEx) {
			//removeUniqueKeyFromMap = true;
			if (JOB_WITH_FAILED_EXECUTION.equals(cbsEx.getErrorCode())) {
				try {
					//_jobOperatorBean.startNextInstance(JOB_NAME);
					InternalJobOperatorImpl internalJob = new InternalJobOperatorImpl();
					internalJob.startNewJobInstance(JOB_NAME, bdo);
				} catch (Exception restartEx) {
					logger.error("Start next instance of job failed: " + JOB_NAME);
					restartEx.printStackTrace();
					//doCleanUpForStartNextInstance(JOB_NAME);
					updateStatusToFail = true;
				}
			} else {
				logger.error("Job did not start:" + JOB_NAME);
				updateStatusToFail = true;
			}
		} catch (ClassCastException ccex) {
			logger.warn("Cast exception encountered during start: " + ccex.getMessage());
			ccex.printStackTrace();
		} catch (Exception ex) {
			//removeUniqueKeyFromMap = true;
			ex.printStackTrace();
			updateStatusToFail = true;
		} finally {
			//if (removeUniqueKeyFromMap) {
			//	getXpsMessageQueueMap().remove(uniqueKey);
			//}
			if(updateStatusToFail){
				bulkUpdateStatusToFail(internalKeyList);
			}
		}
	}
	
	private String getSpoolDir(){
		RegistryPk pk = new RegistryPk("REGISTRY", XpsGlobalConstants.CROSS_MODULE_REGISTRY, ATTR_SPOOL_DIR, ATTR_SPOOL_DIR);
		RegistryJpe regJpe = dataService.find(RegistryJpe.class, pk);
		String dir = regJpe == null ? null : regJpe.getValueS();		
		
		if(StringUtils.isBlank(dir)){
			throw new CbsServiceException("Registry setup missing for " + XpsGlobalConstants.CROSS_MODULE_REGISTRY + "~" + ATTR_SPOOL_DIR);
		}

		return dir;
	}
	
	private String getFileName(){
		String fileName = xpsStorHelper.getFileName(null, null, XpsGlobalConstants.SWIFT_FORMAT);
		
		if(StringUtils.isBlank(fileName)){
			throw new CbsServiceException("Created file name is empty!");
		}
		
		return fileName;
	}
	
	private String getSwiftMessageSeparator(){
		FileFormatOutJpe jpe = this.dataService.find(FileFormatOutJpe.class, new FileFormatOutPk(XpsGlobalConstants.SWIFT_FORMAT));
		if(jpe == null){
			logger.warn("FileFormatOutJpe not found for format: {}", XpsGlobalConstants.SWIFT_FORMAT);
			return null;
		}

		return jpe.getSeparatorPattern();
	}
	
	private void bulkUpdateStatusToFail(List<Long> internalKeyList){
		Map<String, Object> params = new HashMap<>();
		params.put("status", STATUS_FAILED);
		params.put("keys", internalKeyList);
		dataService.bulkUpdateWithNamedQuery(XpsJpeConstants.MESSAGE_Q_JPE_UPDATE_STATUS, params, MessageQJpe.class);
	}
    
    private class InternalJobOperatorImpl {
    	public void startNewJobInstance(String jobName, MessageControlQWrapper bdo){
    		_asynchTaskSupport.executeNoWait(new CbsAsychronousTask<Long>() {
				@Override
				public Long run()  {
					try {
						//startTransaction(bdo);
						return _jobOperatorBean.startNextInstance(JOB_NAME);
					} catch (NoSuchJobException e) {
						e.printStackTrace();
					} catch (JobParametersNotFoundException e) {
						e.printStackTrace();
					} catch (JobRestartException e) {
						e.printStackTrace();
					} catch (JobExecutionAlreadyRunningException e) {
						e.printStackTrace();
					} catch (JobInstanceAlreadyCompleteException e) {
						e.printStackTrace();
					} catch (UnexpectedJobExecutionException e) {
						e.printStackTrace();
					} catch (JobParametersInvalidException e) {
						e.printStackTrace();
					}
					return null;
				}

				@Override
				public String getTaskName() {
					return "MessageControlQWrapperEventConsumer.startNewJobInstance";
				}
    		});
    	}
    }

}
