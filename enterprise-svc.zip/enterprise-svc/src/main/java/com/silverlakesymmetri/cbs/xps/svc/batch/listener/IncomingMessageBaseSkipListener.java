package com.silverlakesymmetri.cbs.xps.svc.batch.listener;

import com.silverlakesymmetri.cbs.commons.jpa.service.CbsBatchGenericDataService;
import com.silverlakesymmetri.cbs.commons.logging.CbsAppLogger;
import com.silverlakesymmetri.cbs.commons.logging.CbsAppLoggerFactory;
import com.silverlakesymmetri.cbs.xps.util.BpmTaskParamObject;
import org.springframework.batch.core.SkipListener;
import org.springframework.beans.factory.annotation.Autowired;

public abstract class IncomingMessageBaseSkipListener<T> implements SkipListener<T, BpmTaskParamObject> {

	private static CbsAppLogger logger = CbsAppLoggerFactory.getLogger(IncomingMessageBaseSkipListener.class);
	protected static final String STATUS_FAILED = "F";

	@Autowired
	protected CbsBatchGenericDataService batchDataService;

	@Override
	public void onSkipInRead(Throwable t) {
		logger.error("Error encountered during read");
		t.printStackTrace();
	}

	@Override
	public void onSkipInWrite(BpmTaskParamObject item, Throwable t) {
		logger.error("Error encountered during write");
		t.printStackTrace();
	}

	@Override
	public void onSkipInProcess(T item, Throwable t) {
		logger.error("Error encountered during process");
		t.printStackTrace();
		doBulkUpdate(STATUS_FAILED, getUniqueId(item));
	}

	protected abstract Object getUniqueId(T item);

	protected abstract void doBulkUpdate(String newStatus, Object uniqueId);

	/*protected void doBulkUpdate(String newStatus, Long internalKey) {
		if (logger.isDebugEnabled()) {
			logger.debug("Following keys {} will be updated to {}", internalKey, newStatus);
		}

		Map<String, Object> params = new HashMap<>();
		params.put("status", newStatus);
		params.put("keys", Arrays.asList(new Long[] { internalKey }));
		batchDataService.bulkUpdateWithNamedQuery(XpsJpeConstants.MESSAGE_MASTER_JPE_UPDATE_STATUS_ERROR, params,
				MessageMasterJpe.class);
	}*/

}
