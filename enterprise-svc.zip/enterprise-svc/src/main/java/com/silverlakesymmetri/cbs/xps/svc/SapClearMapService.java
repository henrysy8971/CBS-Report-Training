package com.silverlakesymmetri.cbs.xps.svc;

import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.svc.BusinessService;
import com.silverlakesymmetri.cbs.csd.bdo.sdo.Branch;
import com.silverlakesymmetri.cbs.csd.bdo.sdo.ProfitCentre;
import com.silverlakesymmetri.cbs.csd.gla.bdo.sdo.ChartAccount;
import com.silverlakesymmetri.cbs.gla.bdo.sdo.GlAccount;
import com.silverlakesymmetri.cbs.mcl.bdo.sdo.Client;
import com.silverlakesymmetri.cbs.pim.bdo.sdo.MasterDepositAcctQry;
import com.silverlakesymmetri.cbs.xps.bdo.sdo.SapClearMap;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.SapClearMapJpe;

import java.util.List;
import java.util.Map;

public interface SapClearMapService extends BusinessService<SapClearMap, SapClearMapJpe> {

    String SVC_OP_NAME_SAPCLEARMAPSERVICE_GET = "SapClearMapService.get";
    String SVC_OP_NAME_SAPCLEARMAPSERVICE_QUERY = "SapClearMapService.query";
    String SVC_OP_NAME_SAPCLEARMAPSERVICE_CREATE = "SapClearMapService.create";
    String SVC_OP_NAME_SAPCLEARMAPSERVICE_UPDATE = "SapClearMapService.update";
    String SVC_OP_NAME_SAPCLEARMAPSERVICE_DELETE = "SapClearMapService.delete";
    String SVC_OP_NAME_SAPCLEARMAPSERVICE_FIND = "SapClearMapService.find";
    String SVC_OP_NAME_SAPCLEARMAPSERVICE_FIND_CLIENT_NO = "SapClearMapService.findClientNo";
    String SVC_OP_NAME_SAPCLEARMAPSERVICE_FIND_BRANCH = "SapClearMapService.findBranch";
    String SVC_OP_NAME_SAPCLEARMAPSERVICE_FIND_PROFIT_CENTRE = "SapClearMapService.findProfitCentre";
    String SVC_OP_NAME_SAPCLEARMAPSERVICE_FIND_GL_CODE = "SapClearMapService.findGlCode";
    String SVC_OP_NAME_SAPCLEARMAPSERVICE_FIND_SEQ_NO = "SapClearMapService.findSeqNo";
    String SVC_OP_NAME_SAPCLEARMAPSERVICE_FIND_ACCT_NO = "SapClearMapService.findAcctNo";

    @ServiceOperation(name = SVC_OP_NAME_SAPCLEARMAPSERVICE_CREATE)
    SapClearMap create(SapClearMap sapClearMap);

    @ServiceOperation(name = SVC_OP_NAME_SAPCLEARMAPSERVICE_UPDATE)
    SapClearMap update(SapClearMap sapClearMap);

    @ServiceOperation(name = SVC_OP_NAME_SAPCLEARMAPSERVICE_DELETE)
    boolean delete(SapClearMap sapClearMap);

    @ServiceOperation(name = SVC_OP_NAME_SAPCLEARMAPSERVICE_QUERY)
    List<SapClearMap> query(int i, int i1, String s, String s1, Map<String, Object> map);

    @ServiceOperation(name = SVC_OP_NAME_SAPCLEARMAPSERVICE_FIND)
    List<SapClearMap> find(FindCriteria findCriteria, CbsHeader cbsHeader);

    @ServiceOperation(name = SVC_OP_NAME_SAPCLEARMAPSERVICE_GET, type = ServiceOperation.ServiceOperationType.GET)
    SapClearMap getByPk(String s, SapClearMap sapClearMap);

    @ServiceOperation(name = SVC_OP_NAME_SAPCLEARMAPSERVICE_FIND_CLIENT_NO,
            type = ServiceOperation.ServiceOperationType.READ, passParamAsMap = true)
    List<Client> findClientNo(Map<String, Object> queryParams);

    @ServiceOperation(name = SVC_OP_NAME_SAPCLEARMAPSERVICE_FIND_BRANCH,
            type = ServiceOperation.ServiceOperationType.READ, passParamAsMap = true)
    List<Branch> findBranch(Map<String, Object> queryParams);

    @ServiceOperation(name = SVC_OP_NAME_SAPCLEARMAPSERVICE_FIND_PROFIT_CENTRE,
            type = ServiceOperation.ServiceOperationType.READ, passParamAsMap = true)
    List<ProfitCentre> findProfitCentre(Map<String, Object> queryParams);

    @ServiceOperation(name = SVC_OP_NAME_SAPCLEARMAPSERVICE_FIND_GL_CODE,
            type = ServiceOperation.ServiceOperationType.READ, passParamAsMap = true)
    List<ChartAccount> findGlCode(Map<String, Object> queryParams);

    @ServiceOperation(name = SVC_OP_NAME_SAPCLEARMAPSERVICE_FIND_SEQ_NO,
            type = ServiceOperation.ServiceOperationType.READ, passParamAsMap = true)
    List<GlAccount> findSeqNo(Map<String, Object> queryParams);

    @ServiceOperation(name = SVC_OP_NAME_SAPCLEARMAPSERVICE_FIND_ACCT_NO,
            type = ServiceOperation.ServiceOperationType.READ, passParamAsMap = true)
    List<MasterDepositAcctQry> findAcctNo(Map<String, Object> queryParams);

}
