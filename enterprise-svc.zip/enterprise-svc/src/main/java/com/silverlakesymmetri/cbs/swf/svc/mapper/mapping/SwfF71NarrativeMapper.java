package com.silverlakesymmetri.cbs.swf.svc.mapper.mapping;

import org.mapstruct.DecoratedWith;
import org.mapstruct.InheritInverseConfiguration;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Mappings;

import com.silverlakesymmetri.cbs.swf.jpa.mapping.sdo.SwfF71NarrativeJpe;
import com.silverlakesymmetri.cbs.swf.svc.mapper.decorator.SwfF71NarrativeMapperDecorator;
import com.silverlakesymmetri.cbs.swf.xmlapi.SWFF71NARRATIVETYPEType;

@Mapper(uses = SwfChargeNarrativeMapper.class)
@DecoratedWith(SwfF71NarrativeMapperDecorator.class)
public interface SwfF71NarrativeMapper {
	@Mappings({
		@Mapping(source="opt", target="OPT"),
		@Mapping(source="swfChargeNarrativeList", target="DETAILS.SWFCHARGENARRATIVETYPE") 
	})
	SWFF71NARRATIVETYPEType mapToApi(SwfF71NarrativeJpe jpe);
	
	@InheritInverseConfiguration(name = "mapToApi")
	SwfF71NarrativeJpe mapToJpe(SWFF71NARRATIVETYPEType api);
}