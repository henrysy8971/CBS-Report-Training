package com.silverlakesymmetri.cbs.swf.svc.mapper.mapping;

import org.apache.commons.lang3.StringUtils;
import org.mapstruct.DecoratedWith;
import org.mapstruct.InheritInverseConfiguration;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Mappings;

import com.silverlakesymmetri.cbs.commons.jpa.util.DateTimeHelper;
import com.silverlakesymmetri.cbs.swf.jpa.mapping.sdo.SwfF11Jpe;
import com.silverlakesymmetri.cbs.swf.svc.mapper.decorator.SwfF11MapperDecorator;
import com.silverlakesymmetri.cbs.swf.xmlapi.SWFF11TYPEType;

@Mapper(imports=StringUtils.class, uses={DateTimeHelper.class})
@DecoratedWith(SwfF11MapperDecorator.class)
public interface SwfF11Mapper {
	@Mappings({
		@Mapping(source="opt", target="OPT"),
		@Mapping(source="messageNumber", target="MTNUMBER"),
		@Mapping(source="messageDate", target="SENDDATE", qualifiedByName = {"DateTimeHelper","convertDateToCbsXmlApiDate"}),
		@Mapping(source="sessionNumber", target="SESSIONNO"),
		@Mapping(source="inputSeqNo", target="ISN"),
		@Mapping(source="qualifier", target="QUALIFIER"),
		@Mapping(source="currency", target="CURRENCY"),
	})
	SWFF11TYPEType mapToApi(SwfF11Jpe jpe);
	
	@InheritInverseConfiguration(name = "mapToApi")
	@Mappings({
		@Mapping(target="opt", expression="java(StringUtils.isNotBlank(api.getOPT())?api.getOPT():null)"),
		@Mapping(target="messageDate", source="SENDDATE", qualifiedByName = { "DateTimeHelper", "convertCbsApiDateToString" }),
		@Mapping(target="currency", expression="java(StringUtils.isNotBlank(api.getCURRENCY())?api.getCURRENCY():null)"),
	})
	SwfF11Jpe mapToJpe(SWFF11TYPEType api);
}
