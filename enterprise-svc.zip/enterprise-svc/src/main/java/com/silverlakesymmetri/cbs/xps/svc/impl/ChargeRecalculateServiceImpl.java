package com.silverlakesymmetri.cbs.xps.svc.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.inject.Inject;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mysema.query.types.EntityPath;
import com.silverlakesymmetri.cbs.commons.restlet.JsonConvertionManager;
import com.silverlakesymmetri.cbs.commons.svc.AbstractXmlApiBusinessService;
import com.silverlakesymmetri.cbs.commons.xmlapi.enums.CbsXmlApiOperation;
import com.silverlakesymmetri.cbs.xps.bdo.sdo.ChargeDetails;
import com.silverlakesymmetri.cbs.xps.bdo.sdo.ChargeMaster;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.ChargeMasterJpe;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.QChargeMasterJpe;
import com.silverlakesymmetri.cbs.xps.svc.ChargeRecalculateService;
import com.silverlakesymmetri.cbs.xps.svc.mapper.ChargeRecalculateServiceMapper;
import com.silverlakesymmetri.cbs.xps.xmlapi.XPSCHARGERECALCULATEAPIType;
import com.silverlakesymmetri.cbs.xps.xmlapi.XPSCHARGERECALCULATEAPIType;

@Service
public class ChargeRecalculateServiceImpl extends AbstractXmlApiBusinessService<ChargeMaster, ChargeMasterJpe, Long, XPSCHARGERECALCULATEAPIType, XPSCHARGERECALCULATEAPIType> implements ChargeRecalculateService {

    @Autowired
    private ChargeRecalculateServiceMapper mapper;
	
    @Inject
    protected JsonConvertionManager jsonConversionMngr;
    
    private Integer whatChanged;

    public ChargeMaster preCreateValidation(ChargeMaster dataObject) {
    	return super.preCreateValidation(dataObject);
    }

    @Override
    public ChargeMaster create(ChargeMaster dataObject) {
        return super.create(dataObject);
    }

    @Override
    protected XPSCHARGERECALCULATEAPIType transformBdoToXmlApiRqCreate(ChargeMaster dataObject) {
        return transformBdoToXmlApiType(dataObject, CbsXmlApiOperation.INSERT);
    }

    @Override
    protected XPSCHARGERECALCULATEAPIType transformBdoToXmlApiRqUpdate(ChargeMaster dataObject) {
        return null;
    }

    @Override
    protected XPSCHARGERECALCULATEAPIType transformBdoToXmlApiRqDelete(ChargeMaster dataObject) {
        return null;
    }

    private XPSCHARGERECALCULATEAPIType transformBdoToXmlApiType(ChargeMaster dataObject, CbsXmlApiOperation oper) {
    	ChargeMasterJpe jpe = jaxbSdoHelper.unwrap(dataObject);
    	XPSCHARGERECALCULATEAPIType api = mapper.mapToApi(jpe, oper);
    	api.setWHATCHANGED(this.whatChanged);
    	api.setOPERATION("PROCESS_GENERIC");
        return api;
    }

    @Override
    protected Map<String, String> executeStoredProcedure(String xmlApiReq, String xmlHeaderIn) {
		String processAuthorizeOperation = "XPS_CHARGE_RECALCULATE_API OPERATION=\"PROCESS_GENERIC\"";
		String xmlApiReqProcess = xmlApiReq.replaceAll(
				"XPS_CHARGE_RECALCULATE_API=\"(INSERT|UPDATE|DELETE|DO_PROCESS)\"", processAuthorizeOperation);
        return super.executeStoredProcedure(xmlApiReqProcess, xmlHeaderIn);
    }

    @Override
    protected ChargeMaster processXmlApiRs(ChargeMaster dataObject, XPSCHARGERECALCULATEAPIType xmlApiRs) {
    	ChargeMasterJpe jpe = jaxbSdoHelper.unwrap(dataObject);
        jpe = mapper.mapToJpe(xmlApiRs, jpe);
        return jaxbSdoHelper.wrap(jpe);
    }

    @Override
    protected List<ChargeMaster> processXmlApiListRs(ChargeMaster dataObject, XPSCHARGERECALCULATEAPIType xmlApiRs) {
        return null;
    }

    @Override
    protected Class<XPSCHARGERECALCULATEAPIType> getXmlApiResponseClass() {
        return XPSCHARGERECALCULATEAPIType.class;
    }

    @Override
    protected Long getIdFromDataObjectInstance(ChargeMaster dataObject) {
        return dataObject.getInternalKey();
    }

    @Override
    protected EntityPath<ChargeMasterJpe> getEntityPath() {
        return QChargeMasterJpe.chargeMasterJpe;
    }

	@Override
	public ChargeDetails recalculate(Map<String, Object> params) {
		ChargeMaster master = jsonConversionMngr.convertToType(params.get("master"), ChargeMaster.class, null, null);
		ChargeDetails detail = jsonConversionMngr.convertToType(params.get("detail"), ChargeDetails.class, null, null);
		Integer whatChanged = Integer.parseInt(params.get("whatChanged").toString());
		this.whatChanged = whatChanged;
		
		master.setChargeDetailsList(new ArrayList<ChargeDetails>());
		master.getChargeDetailsList().add(detail);
		
		ChargeDetails relatedChargeBdo = null;
		if(params.get("relatedCharge") != null){
			relatedChargeBdo = jsonConversionMngr.convertToType(params.get("relatedCharge"), ChargeDetails.class, null, null);
			master.getChargeDetailsList().add(relatedChargeBdo);	
		}
		
		ChargeMaster response = this.createDataObject(master);
		ChargeDetails result = null;
		if(response != null && response.getChargeDetailsList() != null && response.getChargeDetailsList().size() > 0){
			result = response.getChargeDetailsList().get(0);
		}
		
		return result;
	}
	
	@Override
	protected ChargeMaster preCreateObject(ChargeMaster dataObject) {
		return dataObject;
	}
    

}
