package com.silverlakesymmetri.cbs.xps.svc.ext;

import java.util.Map;

import com.silverlakesymmetri.cbs.commons.bdo.CbsBusinessDataObject;
import com.silverlakesymmetri.cbs.pim.bdo.sdo.MessageKey;

public interface TfnChargesServiceExt {
	
	public static final String TFN_CHARGE = "TRADEFINANCE_CHARGES";
	public static final String TFN_CHARGE_UTILITY = "TfnChargesServiceExt.facilitate";

	public Long getImportLcTranKey(String refNo);
	
	public Long getExportLcTranKey(String refNo);
	
	public Long getImportNeTranKey(String refNo);
	
	public Long getExportNeTranKey(String refNo);
	
	public Long getImportDcTranKey(String refNo);
	
	public Long getExportDcTranKey(String refNo);
	
	public Long getSgTranKey(String refNo);
	
	public Long getClientId(String clientNo);
	
	public Long getImportLcAmendEventKey(String refNo, Long eventSeq);
	
	public String getDestinationAddress(CbsBusinessDataObject mainBdo, String refNo, MessageKey message, String instrumentType, String instrumentSubType, Map<String, Object> qParams);

}
