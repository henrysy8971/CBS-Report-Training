package com.silverlakesymmetri.cbs.gla.svc.impl;

import com.mysema.query.types.EntityPath;
import com.silverlakesymmetri.cbs.commons.jpa.util.DateTimeHelper;
import com.silverlakesymmetri.cbs.commons.svc.AbstractBusinessService;
import com.silverlakesymmetri.cbs.commons.util.BdoPublicKeyResolver;
import com.silverlakesymmetri.cbs.gla.bdo.sdo.GlAcctMovementQry;
import com.silverlakesymmetri.cbs.gla.jpa.mapping.sdo.GlAcctMovementQryJpe;
import com.silverlakesymmetri.cbs.gla.jpa.mapping.sdo.QGlAcctMovementQryJpe;
import com.silverlakesymmetri.cbs.gla.jpa.mapping.sdo.id.GlAcctMovementQryPk;
import com.silverlakesymmetri.cbs.gla.jpa.util.GlaAcctOpenCloseHelper;
import com.silverlakesymmetri.cbs.gla.svc.GlAcctMovementQryService;
import com.silverlakesymmetri.cbs.mcl.jpa.mapping.sdo.util.MclJpeConstants;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.*;

@Service
public class GlAcctMovementQryServiceImpl extends AbstractBusinessService<GlAcctMovementQry, GlAcctMovementQryJpe, GlAcctMovementQryPk> implements GlAcctMovementQryService {

    private static final String CLIENT_NO = "clientNo";
    private static final String CLIENT_ID = "clientId";
    private static final String BRANCH = "branch";
    private static final String CCY = "ccy";
    private static final String SEQ_NO = "seqNo";
    private static final String PROFIT_CENTRE = "profitCentre";
    private static final String GL_CODE = "glCode";
    private static final String START_DATE = "startDate";
    private static final String END_DATE = "endDate";
    private static final String DATE_TYPE = "dateType";

    @Autowired
    private GlaAcctOpenCloseHelper glaAcctOpenCloseHelper;

    @Autowired
    private DateTimeHelper dateTimeHelper;

    @Override
    protected GlAcctMovementQryPk getIdFromDataObjectInstance(GlAcctMovementQry dataObject) {
        return new GlAcctMovementQryPk(dataObject.getBranch(), dataObject.getCcy(), dataObject.getClientNo(), dataObject.getGlCode(), dataObject.getSeqNo(), dataObject.getProfitCentre());
    }

    @Override
    protected EntityPath<GlAcctMovementQryJpe> getEntityPath() {
        return QGlAcctMovementQryJpe.glAcctMovementQryJpe;
    }

    @Override
    public GlAcctMovementQry glAccountMovement(Map<String, Object> filters) {
        String dateTypes = "valueDate|postDate";

        String branch = (String) filters.get(BRANCH);
        String ccy = (String) filters.get(CCY);
        String clientNo = (String) filters.get(CLIENT_NO);
        String glCode = (String) filters.get(GL_CODE);
        Integer seqNo = Integer.parseInt((String) filters.get(SEQ_NO));
        String profitCentre = (String) filters.get(PROFIT_CENTRE);
        String dateType = (String) filters.get(DATE_TYPE);
        Date startDate = this.dateTimeHelper.getDate((String) filters.get(START_DATE));
        Date endDate = this.dateTimeHelper.getDate((String) filters.get(END_DATE));

        GlAcctMovementQryJpe jpe = new GlAcctMovementQryJpe(branch, ccy, clientNo, glCode,
                seqNo, profitCentre);
        jpe.setStartDate(startDate);
        jpe.setEndDate(endDate);
        jpe.setDateType(dateType);

        Map<String, Object> params = new HashMap<>();
        params.put(CLIENT_NO, filters.get(CLIENT_NO));
        Long clientIdStr = dataService.getWithNamedQuery(MclJpeConstants.CLIENT_JPE_FIND_CLIENT_ID_USING_CLIENT_NO, params, Long.class);
        jpe.setClientId(clientIdStr);

        if (jpe.getDateType() != null && dateTypes.contains(jpe.getDateType())) {
            if (jpe.getStartDate() != null && jpe.getEndDate() != null) {
                Map<String, Object> openCloseBal = glaAcctOpenCloseHelper.getAcctOpenCloseBal(jpe.getBranch(), jpe.getCcy(),
                        jpe.getClientId(), jpe.getGlCode(), jpe.getProfitCentre(), jpe.getSeqNo(), jpe.getStartDate(), jpe.getEndDate());
                jpe.setOpenActualBalance((Double) openCloseBal.get("p_actual_open_bal"));
                jpe.setCloseActualBalance((Double) openCloseBal.get("p_actual_close_bal"));
                jpe.setOpenLedgerBal((Double) openCloseBal.get("p_ledger_open_bal"));
                jpe.setCloseLedgerBal((Double) openCloseBal.get("p_ledger_close_bal"));
            }
        }

        GlAcctMovementQry bdo = jaxbSdoHelper.wrap(jpe);
        return bdo;
    }

    @Override
    public GlAcctMovementQry getByPk(String publicKey, GlAcctMovementQry dataObject) {
        String[] pkValues = publicKey.split(BdoPublicKeyResolver.PUBLIC_KEY_SEPARATOR);

        GlAcctMovementQryJpe jpe = new GlAcctMovementQryJpe(pkValues[0], pkValues[1], pkValues[2], pkValues[3],
                Integer.parseInt(pkValues[5]), pkValues[4]);

        Map<String, Object> params = new HashMap<>();
        params.put(CLIENT_NO, jpe.getClientNo());
        Long clientIdStr = dataService.getWithNamedQuery(MclJpeConstants.CLIENT_JPE_FIND_CLIENT_ID_USING_CLIENT_NO, params, Long.class);
        jpe.setClientId(clientIdStr);

        GlAcctMovementQry bdo = jaxbSdoHelper.wrap(jpe);
        return bdo;
    }

}
