package com.silverlakesymmetri.cbs.xps.svc.mapper.mapping;

import com.silverlakesymmetri.cbs.xps.xmlapi.XPSSETTLEMESSAGETYPEType;
import com.silverlakesymmetri.cbs.xps.xmlapi.XPSSWFSETTLEAPIType;

public interface CommonSettelementApiInterface {

	public String getACCTTYPE();
	
	public Long getACCTINTERNALKEY();
	public void setACCTINTERNALKEY(Long value);

	public String getREMARKS();
	public void setREMARKS(String value);

	public String getGLCODE();
	public void setGLCODE(String value);

	public XPSSWFSETTLEAPIType getSWIFT();
	public void setSWIFT(XPSSWFSETTLEAPIType value);

	public XPSSETTLEMESSAGETYPEType getMESSAGE();
	public void setMESSAGE(XPSSETTLEMESSAGETYPEType value);

}
