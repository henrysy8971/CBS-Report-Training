package com.silverlakesymmetri.cbs.xps.svc.ext;

import java.util.Map;

import com.silverlakesymmetri.cbs.commons.bdo.CbsBusinessDataObject;
import com.silverlakesymmetri.cbs.pim.bdo.sdo.MessageKey;

public interface BgtChargesServiceExt {

	public static final String BGT_CHARGE = "BANKGUARANTEE_CHARGES";
	public static final String BGT_CHARGE_UTILITY = "BgtChargesServiceExt.facilitate";

	public Long getIssuanceTranKey(String refNo);
	
	public Long getAdvisingTranKey(String refNo);
	
	public Long getBgIssueAmendEventKey(String refNo, Long eventSeq);

	public Long getBgIssueEventRelInternalKey(String relEventType, String refNo, Long eventSeq);

	public String getDestinationAddress(CbsBusinessDataObject mainBdo, String refNo, MessageKey message, String instrumentType, String instrumentSubType, Map<String, Object> qParams);

}
