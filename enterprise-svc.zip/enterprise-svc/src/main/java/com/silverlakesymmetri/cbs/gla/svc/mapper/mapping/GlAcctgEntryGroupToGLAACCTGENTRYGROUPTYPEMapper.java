package com.silverlakesymmetri.cbs.gla.svc.mapper.mapping;

import com.silverlakesymmetri.cbs.commons.jpa.util.DateTimeHelper;
import com.silverlakesymmetri.cbs.gla.jpa.mapping.sdo.GlAccountingEntryGroupJpe;
import com.silverlakesymmetri.cbs.gla.xmlapi.GLAACCOUNTINGENTRYGROUPTYPEType;
import org.mapstruct.InheritInverseConfiguration;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Mappings;

@Mapper(uses={ DateTimeHelper.class})
public interface GlAcctgEntryGroupToGLAACCTGENTRYGROUPTYPEMapper {
	
	@Mappings({
		@Mapping(source="ccy", target="CCY"),
		@Mapping(source="branch", target="BRANCH"),
		@Mapping(source="exchangeRateType", target="EXCHANGERATETYPE"),
		@Mapping(source="exchangeType", target="EXCHANGETYPE")
	})
	public GLAACCOUNTINGENTRYGROUPTYPEType mapToApi(GlAccountingEntryGroupJpe jpe);

	@InheritInverseConfiguration(name = "mapToApi")
	public GlAccountingEntryGroupJpe mapToJpe(GLAACCOUNTINGENTRYGROUPTYPEType api);
}
