package com.silverlakesymmetri.cbs.xps.svc.impl;

import com.mysema.query.types.EntityPath;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.svc.AbstractBusinessService;
import com.silverlakesymmetri.cbs.commons.svc.BusinessObjectValidationCapable;
import com.silverlakesymmetri.cbs.csd.bdo.sdo.Branch;
import com.silverlakesymmetri.cbs.csd.bdo.sdo.ProfitCentre;
import com.silverlakesymmetri.cbs.csd.gla.bdo.sdo.ChartAccount;
import com.silverlakesymmetri.cbs.csd.gla.jpa.mapping.sdo.ChartAccountJpe;
import com.silverlakesymmetri.cbs.csd.jpa.mapping.sdo.BranchJpe;
import com.silverlakesymmetri.cbs.csd.jpa.mapping.sdo.ProfitCentreJpe;
import com.silverlakesymmetri.cbs.gla.bdo.sdo.GlAccount;
import com.silverlakesymmetri.cbs.gla.jpa.mapping.sdo.GlAccountJpe;
import com.silverlakesymmetri.cbs.mcl.bdo.sdo.Client;
import com.silverlakesymmetri.cbs.mcl.jpa.mapping.sdo.ClientJpe;
import com.silverlakesymmetri.cbs.pim.bdo.sdo.MasterDepositAcctQry;
import com.silverlakesymmetri.cbs.pim.jpa.mapping.sdo.MasterDepositAcctQryJpe;
import com.silverlakesymmetri.cbs.xps.bdo.sdo.SapClearMap;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.QSapClearMapJpe;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.SapClearMapJpe;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.id.SapClearMapPk;
import com.silverlakesymmetri.cbs.xps.svc.SapClearMapService;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.persistence.PersistenceException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static com.silverlakesymmetri.cbs.gla.jpa.mapping.sdo.util.GlaJpeConstants.*;
import static com.silverlakesymmetri.cbs.mcl.jpa.mapping.sdo.util.MclJpeConstants.CLIENT_JPE_GET_CLIENT_FROM_CLIENT_NO;

@Service
@Transactional
public class SapClearMapServiceImpl extends AbstractBusinessService<SapClearMap, SapClearMapJpe, SapClearMapPk>
        implements SapClearMapService, BusinessObjectValidationCapable<SapClearMap> {

    private static final int DEFAULT_LIMIT = 10;
    private static final int DEFAULT_OFFSET = 0;

    @Override
    protected SapClearMapPk getIdFromDataObjectInstance(SapClearMap sapClearMap) {
        return new SapClearMapPk(sapClearMap.getSapGlAcct(), sapClearMap.getSapCcy(), sapClearMap.getSapClearAc());
    }

    @Override
    protected EntityPath<SapClearMapJpe> getEntityPath() {
        return QSapClearMapJpe.sapClearMapJpe;
    }

    @Override
    public List<SapClearMap> query(int offset, int resultLimit, String groupBy, String order, Map<String, Object> filters) {
        return super.query(offset, resultLimit, groupBy, order, filters);
    }

    @Override
    public List<SapClearMap> find(FindCriteria findCriteria, CbsHeader cbsHeader) {
        return super.find(findCriteria, cbsHeader);
    }

    @Override
    public SapClearMap create(SapClearMap dataObject) {
        return super.create(dataObject);
    }

    @Override
    public SapClearMap update(SapClearMap dataObject) {
        return super.update(dataObject);
    }

    @Override
    public boolean delete(SapClearMap dataObject) {
        return super.delete(dataObject);
    }

    @Override
    public SapClearMap getByPk(String publicKey, SapClearMap reference) {
        return super.getByPk(publicKey, reference);
    }

    @Override
    public List<Client> findClientNo(Map<String, Object> queryParams) {
        int limit = getLimit(queryParams);
        int offset = getOffset(queryParams);
        String groupBy = (String) queryParams.get("groupBy");
        String order = (String) queryParams.get("order");
        String query = SAP_CLEAR_MAP_CLIENT_NO_LOV_QUERY;
        String clientNo = (String) queryParams.get("clientNo");
        String clientShort = (String) queryParams.get("clientShort");

        queryParams.remove("groupBy");
        queryParams.remove("order");

        if(clientNo != null) {
            query = query + " AND c.clientNo = :clientNo ";
        }

        if(clientShort != null) {
            query = query + " AND c.clientShort = :clientShort";
        }

        if (groupBy != null) {
            query = appendOrderByToQuery(query, "c", groupBy, order);
        }
        List<ClientJpe> clientJpeList = dataService.findWithQuery(query, queryParams, offset, limit, ClientJpe.class);

        List<Client> clientList = new ArrayList<>();

        for (ClientJpe clientJpe : clientJpeList) {
            Client client = jaxbSdoHelper.wrap(clientJpe);
            clientList.add(client);
        }
        return clientList;
    }

    @Override
    public List<Branch> findBranch(Map<String, Object> queryParams) {
        int limit = getLimit(queryParams);
        int offset = getOffset(queryParams);
        String groupBy = (String) queryParams.get("groupBy");
        String order = (String) queryParams.get("order");
        String query = SAP_CLEAR_MAP_BRANCH_LOV_QUERY;
        String branch = (String) queryParams.get("branch");
        String branchDesc = (String) queryParams.get("branchDesc");

        queryParams.remove("groupBy");
        queryParams.remove("order");

        if(branch != null){
            query = query + " AND b.branch = :branch";
        }

        if(branchDesc != null){
            query = query + " AND b.branchDesc = :branchDesc";
        }

        if (groupBy != null) {
            query = appendOrderByToQuery(query, "b", groupBy, order);
        }

        Long clientId = resolveClientId(queryParams);
        queryParams.put("clientId", clientId);

        List<BranchJpe> branchJpeList = dataService.findWithQuery(query, queryParams, offset, limit, BranchJpe.class);

        List<Branch> branchList = new ArrayList<>();

        for (BranchJpe branchJpe : branchJpeList) {
            Branch branchBdo = jaxbSdoHelper.wrap(branchJpe);
            branchList.add(branchBdo);
        }
        return branchList;
    }

    @Override
    public List<ProfitCentre> findProfitCentre(Map<String, Object> queryParams) {
        int limit = getLimit(queryParams);
        int offset = getOffset(queryParams);
        String groupBy = (String) queryParams.get("groupBy");
        String order = (String) queryParams.get("order");
        String query = SAP_CLEAR_MAP_PROFIT_CENTRE_LOV_QUERY;
        String profitCentre = (String) queryParams.get("profitCentre");
        String profitCentreDesc = (String) queryParams.get("profitCentreDesc");

        queryParams.remove("groupBy");
        queryParams.remove("order");

        if(profitCentre != null){
            query = query + " AND pc.profitCentre = :profitCentre";
        }

        if(profitCentreDesc != null){
            query = query + " AND pc.profitCentreDesc = :profitCentreDesc";
        }

        if (groupBy != null) {
            query = appendOrderByToQuery(query, "pc", groupBy, order);
        }

        Long clientId = resolveClientId(queryParams);
        queryParams.put("clientId", clientId);

        List<ProfitCentreJpe> profitCentreJpeList = dataService.findWithQuery(query, queryParams, offset, limit, ProfitCentreJpe.class);

        List<ProfitCentre> profitCentreList = new ArrayList<>();

        for (ProfitCentreJpe profitCentreJpe : profitCentreJpeList) {
            ProfitCentre profitCentreBdo = jaxbSdoHelper.wrap(profitCentreJpe);
            profitCentreList.add(profitCentreBdo);
        }
        return profitCentreList;
    }

    @Override
    public List<ChartAccount> findGlCode(Map<String, Object> queryParams) {
        int limit = getLimit(queryParams);
        int offset = getOffset(queryParams);
        String groupBy = (String) queryParams.get("groupBy");
        String order = (String) queryParams.get("order");
        String query = SAP_CLEAR_MAP_GL_CODE_LOV_QUERY;
        String glCode = (String) queryParams.get("glCode");
        String glCodeDesc = (String) queryParams.get("glCodeDesc");

        queryParams.remove("groupBy");
        queryParams.remove("order");

        if(glCode != null){
            query = query + " AND ca.glCode = :glCode";
        }

        if(glCodeDesc != null){
            query = query + " AND ca.glCodeDesc = :glCodeDesc";
        }

        if (groupBy != null) {
            query = appendOrderByToQuery(query, "ca", groupBy, order);
        }

        Long clientId = resolveClientId(queryParams);
        queryParams.put("clientId", clientId);

        List<ChartAccountJpe> chartAccountJpeList = dataService.findWithQuery(query, queryParams, offset, limit, ChartAccountJpe.class);

        List<ChartAccount> chartAccountList = new ArrayList<>();

        for (ChartAccountJpe chartAccountJpe : chartAccountJpeList) {
            ChartAccount chartAccount = jaxbSdoHelper.wrap(chartAccountJpe);
            chartAccountList.add(chartAccount);
        }
        return chartAccountList;
    }

    @Override
    public List<GlAccount> findSeqNo(Map<String, Object> queryParams) {
        int limit = getLimit(queryParams);
        int offset = getOffset(queryParams);
        String groupBy = (String) queryParams.get("groupBy");
        String order = (String) queryParams.get("order");
        String query = SAP_CLEAR_MAP_SEQ_NO_LOV_QUERY;
        String seqNo = (String) queryParams.get("seqNo");

        queryParams.remove("groupBy");
        queryParams.remove("order");

        if(seqNo != null){
            queryParams.put("seqNo", Integer.valueOf(seqNo));
            query = query + " AND ga.seqNo = :seqNo";
        }
        if (groupBy != null) {
            query = appendOrderByToQuery(query, "ga", groupBy, order);
        }

        Long clientId = resolveClientId(queryParams);
        queryParams.put("clientId", clientId);

        List<GlAccountJpe> glAccountJpeList = dataService.findWithQuery(query, queryParams, offset, limit, GlAccountJpe.class);

        List<GlAccount> glAccountList = new ArrayList<>();

        for (GlAccountJpe glAccountJpe : glAccountJpeList) {
            GlAccount glAccount = jaxbSdoHelper.wrap(glAccountJpe);
            glAccountList.add(glAccount);
        }
        return glAccountList;
    }

    @Override
    public List<MasterDepositAcctQry> findAcctNo(Map<String, Object> queryParams) {
        int limit = getLimit(queryParams);
        int offset = getOffset(queryParams);
        String groupBy = (String) queryParams.get("groupBy");
        String order = (String) queryParams.get("order");
        String query = SAP_CLEAR_MAP_ACCT_NO_LOV_QUERY;
        String acctNo = (String) queryParams.get("acctNo");
        String acctDesc = (String) queryParams.get("acctDesc");

        queryParams.remove("groupBy");
        queryParams.remove("order");

        if(acctNo != null){
            query = query + " AND m.acctNo = :acctNo";
        }

        if(acctDesc != null){
            query = query + " AND m.acctDesc = :acctDesc";
        }

        if (groupBy != null) {
            query = appendOrderByToQuery(query, "m", groupBy, order);
        }

        List<MasterDepositAcctQryJpe> jpeList = dataService.findWithQuery(query, queryParams, offset, limit,
                MasterDepositAcctQryJpe.class);

        List<MasterDepositAcctQry> bdoList = new ArrayList<>();

        for (MasterDepositAcctQryJpe jpe : jpeList) {
            MasterDepositAcctQry bdo = jaxbSdoHelper.wrap(jpe);
            bdoList.add(bdo);
        }
        return bdoList;
    }

    private Long resolveClientId(Map<String, Object> queryParams) {
        String clientNo = (String) queryParams.get("clientNo");
        queryParams.remove("clientNo");
        Map<String, Object> paramsMap = new HashMap<>();
        paramsMap.put("clientNo", clientNo);
        try {
            ClientJpe client = dataService.getWithNamedQuery(CLIENT_JPE_GET_CLIENT_FROM_CLIENT_NO, paramsMap, ClientJpe.class);

            return client.getClientId();
        } catch (PersistenceException e) {
            //NOTHING TO DO HERE. ClientJpe is nullable
        }
        return null;
    }

    private int getLimit(Map<String, Object> queryParams) {
        String limitParam = (String) queryParams.get("limit");
        queryParams.remove("limit");
        if (limitParam != null) {
            return Integer.parseInt(limitParam);
        } else {
            return DEFAULT_LIMIT;
        }
    }

    private int getOffset(Map<String, Object> queryParams) {
        String offsetParam = (String) queryParams.get("offset");
        queryParams.remove("offset");
        if (offsetParam != null) {
            return Integer.parseInt(offsetParam);
        } else {
            return DEFAULT_OFFSET;
        }
    }

}
