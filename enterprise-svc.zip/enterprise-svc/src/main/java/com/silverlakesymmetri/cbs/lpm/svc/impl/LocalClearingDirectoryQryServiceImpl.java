package com.silverlakesymmetri.cbs.lpm.svc.impl;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.mysema.query.types.EntityPath;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.exception.CbsRuntimeException;
import com.silverlakesymmetri.cbs.commons.svc.AbstractBusinessService;
import com.silverlakesymmetri.cbs.lpm.bdo.sdo.LocalClearingDirectoryQry;
import com.silverlakesymmetri.cbs.lpm.jpa.mapping.sdo.LocalClearingDirectoryQryJpe;
import com.silverlakesymmetri.cbs.lpm.jpa.mapping.sdo.QLocalClearingDirectoryQryJpe;
import com.silverlakesymmetri.cbs.lpm.svc.LocalClearingDirectoryQryService;

@Service
@Transactional
public class LocalClearingDirectoryQryServiceImpl extends AbstractBusinessService<LocalClearingDirectoryQry, LocalClearingDirectoryQryJpe, Long>
		implements LocalClearingDirectoryQryService {

	@Override
	protected Long getIdFromDataObjectInstance(LocalClearingDirectoryQry bdo) {
		LocalClearingDirectoryQryJpe jpe = jaxbSdoHelper.unwrap(bdo);
		return jpe.getInternalKey();
	}

	@Override
	protected EntityPath<LocalClearingDirectoryQryJpe> getEntityPath() {
		 return QLocalClearingDirectoryQryJpe.localClearingDirectoryQryJpe;
	}

	@Override
	public LocalClearingDirectoryQry create(LocalClearingDirectoryQry dataObject) {
		throw new CbsRuntimeException("Create operation is not supported by this service");
	}

	@Override
	public LocalClearingDirectoryQry update(LocalClearingDirectoryQry dataObject) {
		throw new CbsRuntimeException("Update operation is not supported by this service");
	}

	@Override
	public boolean delete(LocalClearingDirectoryQry dataObject) {
		throw new CbsRuntimeException("Delete operation is not supported by this service");
	}

	@Override
	public List<LocalClearingDirectoryQry> query(int offset, int resultLimit, String groupBy, String order,
			Map<String, Object> filters) {
		return super.query(offset, resultLimit, groupBy, order, filters);
	}

	@Override
	public List<LocalClearingDirectoryQry> find(FindCriteria findCriteria, CbsHeader cbsHeader) {
		return super.find(findCriteria, cbsHeader);
	}

	@Override
	public LocalClearingDirectoryQry getByPk(String publicKey, LocalClearingDirectoryQry reference) {
		return super.getByPk(publicKey, reference);
	}

}
