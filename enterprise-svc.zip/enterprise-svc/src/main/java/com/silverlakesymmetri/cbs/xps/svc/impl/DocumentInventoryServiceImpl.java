package com.silverlakesymmetri.cbs.xps.svc.impl;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.mysema.query.types.EntityPath;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.jpa.util.BdoHelper;
import com.silverlakesymmetri.cbs.commons.jpa.util.DateTimeHelper;
import com.silverlakesymmetri.cbs.commons.svc.AbstractBusinessService;
import com.silverlakesymmetri.cbs.commons.svc.BusinessObjectBpmMergeCapable;
import com.silverlakesymmetri.cbs.commons.svc.BusinessObjectValidationCapable;
import com.silverlakesymmetri.cbs.commons.svc.ref.ReferenceNumberGeneratorService;
import com.silverlakesymmetri.cbs.xps.bdo.sdo.DocumentInventoryDtl;
import com.silverlakesymmetri.cbs.xps.bdo.sdo.DocumentInventoryHdr;
import com.silverlakesymmetri.cbs.xps.bdo.sdo.DocumentTrackingDtl;
import com.silverlakesymmetri.cbs.xps.enums.XpsGlobalConstants;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.DocumentInventoryHdrJpe;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.DocumentTrackingDtlJpe;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.QDocumentInventoryHdrJpe;
import com.silverlakesymmetri.cbs.xps.svc.DocumentInventoryService;

/**
 * Copyright SunGard 2014
 *
 * Service is used to Read, Create, Update, Delete DocumentInventoryHdr data.
 *
 * @author Ryan Vargas
 * @since 2014-10-08
 */

@Service
@Transactional
public class DocumentInventoryServiceImpl extends AbstractBusinessService<DocumentInventoryHdr, DocumentInventoryHdrJpe, String>
        implements DocumentInventoryService, BusinessObjectValidationCapable<DocumentInventoryHdr>, BusinessObjectBpmMergeCapable {
    public static final String PK_PROPERTY = "publicKey";
    public static final String TEMP_PREFIX = "temp";

    @Autowired
    private ReferenceNumberGeneratorService referenceNumberGeneratorService;

    @Autowired
    private DateTimeHelper _dtHelper;

    @Autowired
    private BdoHelper _bdoHelper;

    @Override
    protected String getIdFromDataObjectInstance(DocumentInventoryHdr dataObject) {
        return dataObject.getDocInvRefNo();
    }

    @Override
    protected EntityPath<DocumentInventoryHdrJpe> getEntityPath() {
        return QDocumentInventoryHdrJpe.documentInventoryHdrJpe;
    }

    @Override
    protected DocumentInventoryHdr preCreateValidation(DocumentInventoryHdr dataObject) {
        setDefaulting(dataObject, true);
        return dataObject;
    }

    @Override
    protected DocumentInventoryHdr preUpdateValidation(DocumentInventoryHdr dataObject) {
        setDefaulting(dataObject, false);
        return dataObject;
    }

    protected void setDefaulting(DocumentInventoryHdr dataObject, boolean isCreate) {
        String docInvRefNo = "";
        if (dataObject.getDocInvRefNo() == null || dataObject.getDocInvRefNo().isEmpty()) {
            referenceNumberGeneratorService.getNewRefNo(dataObject, "docInvRefNo");
        }
        docInvRefNo = dataObject.getDocInvRefNo();

        // make sure docInvDtlRefNo is the same for documentInventoryDtl to equivalent documentTrackingDtl
        List<DocumentInventoryDtl> documentInventoryDtlList = dataObject.getDocInvDtlList();
        if (documentInventoryDtlList != null && !documentInventoryDtlList.isEmpty()) {
            for (DocumentInventoryDtl documentInventoryDtl : documentInventoryDtlList) {
                if (isCreate && StringUtils.isNotBlank(docInvRefNo)) {
                    documentInventoryDtl.setDocInvRefNo(docInvRefNo);
                }
                setDocInvDtlDefaulting(documentInventoryDtl, dataObject);
            }
        }
        List<DocumentTrackingDtl> documentTrackingDtlList = dataObject.getTrackingDtlList();
        if (documentTrackingDtlList != null && !documentTrackingDtlList.isEmpty()) {
            for (DocumentTrackingDtl documentTrackingDtl : documentTrackingDtlList) {
                if (isCreate && StringUtils.isNotBlank(docInvRefNo)) {
                    documentTrackingDtl.setDocInvRefNo(docInvRefNo);
                }
                setTrackingDefaulting(documentTrackingDtl, dataObject);
            }
        }
        dataObject = setTransientFields(dataObject);
    }

    protected void setDocInvDtlDefaulting(DocumentInventoryDtl dataObject, DocumentInventoryHdr parent) {
        if (dataObject.getDocInvDtlRefNo() == null || dataObject.getDocInvDtlRefNo().isEmpty()) {
            referenceNumberGeneratorService.getNewRefNo(dataObject, "docInvDtlRefNo");
        }
        if (dataObject.getDocInvRefNo() == null || !parent.getDocInvRefNo().equals(dataObject.getDocInvRefNo())) {
            dataObject.setDocInvRefNo(parent.getDocInvRefNo());
        }
    }

    protected void setTrackingDefaulting(DocumentTrackingDtl dataObject, DocumentInventoryHdr parent) {
        if (dataObject.getTrackingDtlRefNo() == null || dataObject.getTrackingDtlRefNo().isEmpty()) {
            referenceNumberGeneratorService.getNewRefNo(dataObject, "trackingDtlRefNo");
        }
        if (dataObject.getDocInvRefNo() == null || !parent.getDocInvRefNo().equals(dataObject.getDocInvRefNo())) {
            dataObject.setDocInvRefNo(parent.getDocInvRefNo());
        }

        if (dataObject.getDocMovementCount() == null) {
            dataObject.setDocMovementCount(new Integer(0));
        }

        if (dataObject.getDocMovementDt() == null || dataObject.getDocMovementDt().isEmpty()) {
            SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
            Date runDate = _dtHelper.getRunDate();
            dataObject.setDocMovementDt(dateFormat.format(runDate));
        }

        if (dataObject.getDocInvDtlRefNo().startsWith(TEMP_PREFIX)) {
            for (DocumentInventoryDtl documentInventoryDtl : parent.getDocInvDtlList()) {
                if (documentInventoryDtl.getPublicKey() != null && documentInventoryDtl.getPublicKey().startsWith(TEMP_PREFIX)
                        && documentInventoryDtl.getPublicKey().equals(dataObject.getDocInvDtlRefNo())) {
                    dataObject.setDocInvDtlRefNo(documentInventoryDtl.getDocInvDtlRefNo());
                    documentInventoryDtl.setString(PK_PROPERTY, documentInventoryDtl.getDocInvDtlRefNo());
                    break;
                }
            }
        }
    }

    private Map<String, Integer> calcDocMovementCount(DocumentInventoryHdr dataObject) {
        Map<String, Integer> map = new HashMap<String, Integer>();
        if (dataObject == null) {
            return map;
        }
        for (DocumentTrackingDtl documentTrackingDtl : dataObject.getTrackingDtlList()) {
            String docInvDtlRefNo = documentTrackingDtl.getDocInvDtlRefNo();
            Integer remainingDocCount = 0;
            if (map.containsKey(docInvDtlRefNo)) {
                remainingDocCount = map.get(docInvDtlRefNo);
            }
            if (documentTrackingDtl.getAction() != null && documentTrackingDtl.getAction().equals(XpsGlobalConstants.SAFEKEEP_ACTION)) {
                if (documentTrackingDtl.getDocMovementCount() != null) {
                    remainingDocCount = remainingDocCount + documentTrackingDtl.getDocMovementCount();
                }
            } else {
                if (documentTrackingDtl.getDocMovementCount() != null) {
                    remainingDocCount = remainingDocCount - documentTrackingDtl.getDocMovementCount();
                }
            }
            map.put(docInvDtlRefNo, remainingDocCount);
        }
        return map;
    }

    private DocumentInventoryHdr setTransientFields(DocumentInventoryHdr dataObject) {
        Integer totalDocumentCount = 0;
        if (dataObject == null) {
            return dataObject;
        }
        //
        Map<String, Integer> map = calcDocMovementCount(dataObject);
        //
        for (DocumentInventoryDtl documentInventoryDtl : dataObject.getDocInvDtlList()) {
            Integer remainingDocCount = 0;
            String docInvDtlRefNo = documentInventoryDtl.getDocInvDtlRefNo();
            if (map.containsKey(docInvDtlRefNo)) {
                remainingDocCount = map.get(docInvDtlRefNo);
            }
            documentInventoryDtl.setRemainingDocumentCount(remainingDocCount);
            if (documentInventoryDtl.getRemainingDocumentCount() != null) {
                totalDocumentCount = totalDocumentCount + documentInventoryDtl.getRemainingDocumentCount();
            }
        }
        dataObject.setTotalDocumentCount(totalDocumentCount);
        return dataObject;
    }

    @Override
    public DocumentInventoryHdr get(DocumentInventoryHdr objectInstanceIdentifier) {
        return setTransientFields(super.get(objectInstanceIdentifier));
    }

    @Override
    public DocumentInventoryHdr create(DocumentInventoryHdr dataObject) {
        return setTransientFields(super.create(dataObject));
    }

    @Override
    public DocumentInventoryHdr update(DocumentInventoryHdr dataObject) {
        updateDocumentInventoryDtlMovementCount(dataObject);
        return setTransientFields(super.update(dataObject));
    }

    private void updateDocumentInventoryDtlMovementCount(DocumentInventoryHdr documentInventoryHdr) {
        Map<String, Integer> map = calcDocMovementCount(documentInventoryHdr);
        for (DocumentInventoryDtl documentInventoryDtl : documentInventoryHdr.getDocInvDtlList()) {
            int documentMovementCount = map.get(documentInventoryDtl.getDocInvDtlRefNo());
            if (documentInventoryDtl.getDocMovementCount() == null
                    || !(documentMovementCount == documentInventoryDtl.getDocMovementCount())) {
                documentInventoryDtl.setDocMovementCount(documentMovementCount);
            }
        }
    }

    @Override
    public boolean delete(DocumentInventoryHdr dataObject) {
        return super.delete(dataObject);
    }

    @Override
    public List<DocumentInventoryHdr> query(int offset, int resultLimit, String groupBy, String order, Map<String, Object> filters) {
        List<DocumentInventoryHdr> docInventoryList = super.query(offset, resultLimit, groupBy, order, filters);
        if (docInventoryList != null) {
            for (DocumentInventoryHdr docInventory : docInventoryList) {
                setTransientFields(docInventory);
            }
        }
        return docInventoryList;
    }

    @Override
    public List<DocumentInventoryHdr> find(FindCriteria findCriteria, CbsHeader cbsHeader) {
        List<DocumentInventoryHdr> docInventoryList = super.find(findCriteria, cbsHeader);
        if (docInventoryList != null) {
            for (DocumentInventoryHdr docInventory : docInventoryList) {
                setTransientFields(docInventory);
            }
        }
        return docInventoryList;
    }

    @Override
    public DocumentInventoryHdr getByPk(String publicKey, DocumentInventoryHdr reference) {
        return setTransientFields(super.getByPk(publicKey, reference));
    }

    @Override
    public List<DocumentTrackingDtl> getDocumentTrackingHistory(String docInvRefNo, String docInvDtlRefNo) {
        List<DocumentTrackingDtl> trackingHistory = new ArrayList<DocumentTrackingDtl>();
        Map<String, Object> filters = new HashMap<>();
        filters.put("docInvRefNo", docInvRefNo);
        filters.put("docInvDtlRefNo", docInvDtlRefNo);
        List<DocumentTrackingDtlJpe> trackingHistoryJpe = dataService.findWithNamedQuery(XpsGlobalConstants.GET_DOC_TRACKING_HISTORY,
                filters, DocumentTrackingDtlJpe.class);
        for (DocumentTrackingDtlJpe documentTrackingDtlJpe : trackingHistoryJpe) {
            DocumentTrackingDtl documentTrackingDtl = jaxbSdoHelper.wrap(documentTrackingDtlJpe, DocumentTrackingDtl.class);
            trackingHistory.add(documentTrackingDtl);
        }
        return trackingHistory;
    }

    @SuppressWarnings("unchecked")
    @Override
    public <T> T bpmMergeWithPersistent(T sourceBdo) {
        DocumentInventoryHdr sourceInvetoryHdr = (DocumentInventoryHdr) sourceBdo;
        DocumentInventoryHdr sourceInvetoryHdrCopy = _bdoHelper.cloneBdo(sourceInvetoryHdr, true);
        DocumentInventoryHdr targetInventoryHdr = super.getByPk(sourceInvetoryHdr.getPublicKey(), null);
        DocumentInventoryHdr targetInventoryHdrCopy = _bdoHelper.cloneBdo(targetInventoryHdr, true);
        sourceInvetoryHdrCopy.getHeader().setBpmInfo(null);
        DocumentInventoryHdr mergedObject = (DocumentInventoryHdr) _bdoHelper.merge(sourceInvetoryHdrCopy, targetInventoryHdrCopy);
        mergedObject.setHeader(sourceInvetoryHdr.getHeader());
        mergedObject = setTransientFields(mergedObject);
        return (T) mergedObject;
    }
}
