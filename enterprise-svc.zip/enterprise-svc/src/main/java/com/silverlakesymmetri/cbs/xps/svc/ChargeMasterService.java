package com.silverlakesymmetri.cbs.xps.svc;

import java.util.List;
import java.util.Map;

import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation;
import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation.ServiceOperationType;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.svc.BusinessService;
import com.silverlakesymmetri.cbs.xps.bdo.sdo.ChargeMaster;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.ChargeMasterJpe;

public interface ChargeMasterService extends BusinessService<ChargeMaster, ChargeMasterJpe> {
	public static final String XPS_CHARGEMASTERSERVICE_GET = "ChargeMasterService.get";
    public static final String XPS_CHARGEMASTERSERVICE_QUERY = "ChargeMasterService.query";
    public static final String XPS_CHARGEMASTERSERVICE_FIND = "ChargeMasterService.find";
    public static final String XPS_CHARGEMASTERSERVICE_CREATE = "ChargeMasterService.create";
    public static final String XPS_CHARGEMASTERSERVICE_UPDATE = "ChargeMasterService.update";
    public static final String XPS_CHARGEMASTERSERVICE_DELETE = "ChargeMasterService.delete";
    public static final String XPS_CHARGEMASTERSERVICE_COUNT = "ChargeMasterService.count";
    
    @ServiceOperation(name = XPS_CHARGEMASTERSERVICE_GET, type = ServiceOperationType.GET)
    public ChargeMaster getByPk(String publicKey, ChargeMaster reference);

    @ServiceOperation(name = XPS_CHARGEMASTERSERVICE_QUERY)
    public List<ChargeMaster> query(int offset, int resultLimit, String groupBy, String order, Map<String, Object> filters);
    
    @ServiceOperation(name = XPS_CHARGEMASTERSERVICE_FIND)
    public List<ChargeMaster> find(FindCriteria findCriteria, CbsHeader cbsHeader);
    
    @ServiceOperation(name = XPS_CHARGEMASTERSERVICE_COUNT, type = ServiceOperationType.GET)
    public Long count(FindCriteria findCriteria, CbsHeader cbsHeader);
    
    @ServiceOperation(name = XPS_CHARGEMASTERSERVICE_CREATE)
    public ChargeMaster create(ChargeMaster dataObject);

    @ServiceOperation(name = XPS_CHARGEMASTERSERVICE_UPDATE)
    public ChargeMaster update(ChargeMaster dataObject);

    @ServiceOperation(name = XPS_CHARGEMASTERSERVICE_DELETE)
    public boolean delete(ChargeMaster dataObject);
}