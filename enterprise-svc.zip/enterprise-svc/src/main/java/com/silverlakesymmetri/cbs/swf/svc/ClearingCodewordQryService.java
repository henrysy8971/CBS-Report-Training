package com.silverlakesymmetri.cbs.swf.svc;


import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation;
import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation.ServiceOperationType;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.svc.BusinessService;
import com.silverlakesymmetri.cbs.swf.bdo.sdo.ClearingCodewordQry;
import com.silverlakesymmetri.cbs.swf.jpa.mapping.sdo.ClearingCodewordQryJpe;

import java.util.List;
import java.util.Map;

public interface ClearingCodewordQryService extends BusinessService<ClearingCodewordQry, ClearingCodewordQryJpe> {

    String SVC_OP_NAME_CLEARING_CODEWORD_SERVICE_GET = "ClearingCodewordQryService.get";
    String SVC_OP_NAME_CLEARING_CODEWORD_SERVICE_QUERY = "ClearingCodewordQryService.query";
    String SVC_OP_NAME_CLEARING_CODEWORD_SERVICE_CREATE = "ClearingCodewordQryService.create";
    String SVC_OP_NAME_CLEARING_CODEWORD_SERVICE_UPDATE = "ClearingCodewordQryService.update";
    String SVC_OP_NAME_CLEARING_CODEWORD_SERVICE_DELETE = "ClearingCodewordQryService.delete";
    String SVC_OP_NAME_CLEARING_CODEWORD_SERVICE_FIND = "ClearingCodewordQryService.find";
    String SVC_OP_NAME_CLEARING_CODEWORD_SERVICE_COUNT = "ClearingCodewordQryService.count";

    @ServiceOperation(name = SVC_OP_NAME_CLEARING_CODEWORD_SERVICE_GET, type = ServiceOperationType.GET)
    ClearingCodewordQry getByPk(String publicKey, ClearingCodewordQry reference);

    @ServiceOperation(name = SVC_OP_NAME_CLEARING_CODEWORD_SERVICE_CREATE)
    ClearingCodewordQry create(ClearingCodewordQry dataObject);

    @ServiceOperation(name = SVC_OP_NAME_CLEARING_CODEWORD_SERVICE_UPDATE)
    ClearingCodewordQry update(ClearingCodewordQry dataObject);

    @ServiceOperation(name = SVC_OP_NAME_CLEARING_CODEWORD_SERVICE_QUERY)
    List<ClearingCodewordQry> query(int offset, int resultLimit, String groupBy, String order, Map<String, Object> filters);

    @ServiceOperation(name = SVC_OP_NAME_CLEARING_CODEWORD_SERVICE_DELETE)
    boolean delete(ClearingCodewordQry dataObject);

    @ServiceOperation(name = SVC_OP_NAME_CLEARING_CODEWORD_SERVICE_FIND)
    List<ClearingCodewordQry> find(FindCriteria findCriteria, CbsHeader cbsHeader);

    @ServiceOperation(name = SVC_OP_NAME_CLEARING_CODEWORD_SERVICE_COUNT, type = ServiceOperationType.GET)
    public Long count(FindCriteria findCriteria, CbsHeader cbsHeader);

}
