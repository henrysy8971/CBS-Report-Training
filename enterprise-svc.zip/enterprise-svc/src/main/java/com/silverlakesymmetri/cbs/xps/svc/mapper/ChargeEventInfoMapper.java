package com.silverlakesymmetri.cbs.xps.svc.mapper;

import org.mapstruct.Context;
import org.mapstruct.DecoratedWith;
import org.mapstruct.InheritInverseConfiguration;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingTarget;
import org.mapstruct.Mappings;

import com.silverlakesymmetri.cbs.commons.jpa.util.DateTimeHelper;
import com.silverlakesymmetri.cbs.commons.xmlapi.enums.CbsXmlApiOperation;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.ChargeEventInfoJpe;
import com.silverlakesymmetri.cbs.xps.svc.mapper.decorator.ChargeEventInfoDecorator;
import com.silverlakesymmetri.cbs.xps.xmlapi.XPSCHARGEEVENTTYPEType;

@Mapper(uses = { DateTimeHelper.class })
@DecoratedWith(ChargeEventInfoDecorator.class)
public interface ChargeEventInfoMapper {

	@Mappings({
		@Mapping(source="eventType", target = "EVENTTYPE"),
		@Mapping(source="eventKey", target = "EVENTKEY"),
		@Mapping(source="status", target = "STATUS"),
		@Mapping(source="seqNo", target = "SEQNO"),
		@Mapping(source="eventDate", target = "EVENTDATE", qualifiedByName = {"DateTimeHelper", "convertDateToCbsXmlApiDate"}),
		@Mapping(source="expiryDate", target = "EXPIRYDATE", qualifiedByName = {"DateTimeHelper", "convertDateToCbsXmlApiDate"}),
		@Mapping(source="attached", target = "ATTACHED"),
		@Mapping(source="ccy", target = "CCY"),
		@Mapping(source="ccyTo", target = "CCYTO"),
		@Mapping(source="amount", target = "AMOUNT"),
		@Mapping(source="amountBy", target = "AMOUNTBY"),
		@Mapping(source="amountTo", target = "AMOUNTTO"),
		@Mapping(source="toleranceAdd", target = "TOLERANCEADD"),
		@Mapping(source="exchRate", target = "EXCHRATE"),
		@Mapping(source="exchQuote", target = "EXCHQUOTE"),
		@Mapping(source="baseRate", target = "BASERATE"),
		@Mapping(source="baseQuote", target = "BASEQUOTE"),
		@Mapping(source="localRate", target = "LOCALRATE"),
		@Mapping(source="localQuote", target = "LOCALQUOTE"),
		@Mapping(source="baseEquiv", target = "BASEEQUIV"),
		@Mapping(source="baseEquivBy", target = "BASEEQUIVBY"),
		@Mapping(source="localEquiv", target = "LOCALEQUIV"),
		@Mapping(source="localEquivBy", target = "LOCALEQUIVBY"),
		@Mapping(source="incrDecrInd", target = "INCRDECRIND"),
		@Mapping(source="oldExpiryDate", target = "OLDEXPIRYDATE", qualifiedByName = {"DateTimeHelper", "convertDateToCbsXmlApiDate"}),
		@Mapping(source="latestOldExpiryDate", target = "LATESTOLDEXPIRYDATE", qualifiedByName = {"DateTimeHelper", "convertDateToCbsXmlApiDate"})
	})
	public XPSCHARGEEVENTTYPEType mapToApi(ChargeEventInfoJpe jpe, @Context CbsXmlApiOperation oper);

	@InheritInverseConfiguration(name = "mapToApi")
	@Mappings({
		@Mapping(source="EVENTDATE", target="eventDate", qualifiedByName = {"DateTimeHelper", "convertCbsApiDateToString"}),
		@Mapping(source="EXPIRYDATE", target="expiryDate", qualifiedByName = {"DateTimeHelper", "convertCbsApiDateToString"}),
		@Mapping(source="OLDEXPIRYDATE", target="oldExpiryDate", qualifiedByName = {"DateTimeHelper", "convertCbsApiDateToString"}),
		@Mapping(source="LATESTOLDEXPIRYDATE", target="latestOldExpiryDate", qualifiedByName = {"DateTimeHelper", "convertCbsApiDateToString"})
	})
	public ChargeEventInfoJpe mapToJpe(XPSCHARGEEVENTTYPEType api, @MappingTarget ChargeEventInfoJpe jpe);
}