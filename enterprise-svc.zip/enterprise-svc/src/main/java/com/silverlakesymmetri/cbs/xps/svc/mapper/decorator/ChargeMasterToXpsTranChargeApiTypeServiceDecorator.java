package com.silverlakesymmetri.cbs.xps.svc.mapper.decorator;

import java.util.ArrayList;

import javax.inject.Inject;

import org.mapstruct.Context;
import org.mapstruct.MappingTarget;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

import com.silverlakesymmetri.cbs.commons.jpa.extension.JaxbSdoHelper;
import com.silverlakesymmetri.cbs.commons.jpa.util.BdoHelper;
import com.silverlakesymmetri.cbs.commons.xmlapi.enums.CbsXmlApiOperation;
import com.silverlakesymmetri.cbs.mcl.jpa.mapping.sdo.ClientJpe;
import com.silverlakesymmetri.cbs.mcl.svc.ClientService;
import com.silverlakesymmetri.cbs.xps.bdo.sdo.ChargeDetails;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.ChargeDetailsJpe;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.ChargeMasterJpe;
import com.silverlakesymmetri.cbs.xps.listener.ChargeNoResolver;
import com.silverlakesymmetri.cbs.xps.svc.mapper.ChargeDetailServiceMapper;
import com.silverlakesymmetri.cbs.xps.svc.mapper.ChargeFixedServiceMapper;
import com.silverlakesymmetri.cbs.xps.svc.mapper.ChargeInterestServiceMapper;
import com.silverlakesymmetri.cbs.xps.svc.mapper.ChargeMasterToXpsTranChargeApiTypeServiceMapper;
import com.silverlakesymmetri.cbs.xps.svc.mapper.ChargeRatedServiceMapper;
import com.silverlakesymmetri.cbs.xps.xmlapi.XPSTRANCHARGEAPIType;
import com.silverlakesymmetri.cbs.xps.xmlapi.XPSTRANCHARGEDETAILAPIType;
import com.silverlakesymmetri.cbs.xps.xmlapi.XPSTRANCHARGEDETAILLISTTYPEType;

public abstract class ChargeMasterToXpsTranChargeApiTypeServiceDecorator
		implements ChargeMasterToXpsTranChargeApiTypeServiceMapper {

	private static final String CHARGE_TYPE_FIXED = "F";
	private static final String CHARGE_TYPE_INTEREST = "I";
	private static final String CHARGE_TYPE_RATED = "R";

	@Autowired
	@Qualifier("delegate")
	protected ChargeMasterToXpsTranChargeApiTypeServiceMapper delegate;

	@Autowired
	protected ChargeDetailServiceMapper detailMapper;

	@Autowired
	protected ChargeFixedServiceMapper fixedMapper;

	@Autowired
	protected ChargeRatedServiceMapper ratedMapper;

	@Autowired
	protected ChargeInterestServiceMapper interestMapper;

	@Autowired
	protected ClientService clientService;

    @Inject
    private BdoHelper bdoHelper;

    @Inject
    private JaxbSdoHelper jaxbSdoHelper;

	@Override
	public XPSTRANCHARGEAPIType mapToApi(ChargeMasterJpe jpe, @Context CbsXmlApiOperation oper) {
		if (jpe == null) {
			return null;
		}

		XPSTRANCHARGEAPIType req = (XPSTRANCHARGEAPIType) delegate.mapToApi(jpe, oper);
		if(jpe != null) {
			ClientJpe client = clientService.getClientDetails(jpe.getPartyClientNo());
			if (client != null) {
				req.setPARTYCLIENTID(client.getClientId());
			}
			
			if (jpe.getChargeDetailsList() != null && jpe.getChargeDetailsList().size() > 0) {
				for (ChargeDetailsJpe detailsJpe : jpe.getChargeDetailsList()) {
					XPSTRANCHARGEDETAILAPIType detailApi = detailMapper.mapToApi(detailsJpe, oper);
					if (req.getDETAILS() == null) {
						req.setDETAILS(new XPSTRANCHARGEDETAILLISTTYPEType());
					}
					if (CHARGE_TYPE_FIXED.equals(detailsJpe.getChargeType())) {
						detailApi = fixedMapper.mapToApi(detailsJpe.getChargeFixedStructRec(), detailApi);
					} else if (CHARGE_TYPE_RATED.equals(detailsJpe.getChargeType())) {
						detailApi = ratedMapper.mapToApi(detailsJpe.getChargeRatedStructRec(), detailApi);
					} else if (CHARGE_TYPE_INTEREST.equals(detailsJpe.getChargeType())) {
						detailApi = interestMapper.mapToApi(detailsJpe.getChargeInterestStructRec(), detailApi);
					}
					detailApi.setWAIVED("N");
					req.getDETAILS().getXPSTRANCHARGEDETAILAPI().add(detailApi);
				}
			}
		}
		return req;
	}

	@Override
	public ChargeMasterJpe mapToJpe(XPSTRANCHARGEAPIType api, @MappingTarget ChargeMasterJpe jpe) {
		if (api == null) {
			return null;
		}

		delegate.mapToJpe(api, jpe);
		if (api.getDETAILS() != null && api.getDETAILS().getXPSTRANCHARGEDETAILAPI().size() > 0) {
			for (XPSTRANCHARGEDETAILAPIType detailApi : api.getDETAILS().getXPSTRANCHARGEDETAILAPI()) {
				ChargeDetailsJpe detailsJpe = new ChargeDetailsJpe();
				detailMapper.mapToJpe(detailApi, detailsJpe);
				if (CHARGE_TYPE_FIXED.equals(detailsJpe.getChargeType())) {
					detailsJpe.setChargeFixedStructRec(
							fixedMapper.mapToJpe(detailApi, detailsJpe.getChargeFixedStructRec()));
				} else if (CHARGE_TYPE_RATED.equals(detailsJpe.getChargeType())) {
					detailsJpe.setChargeRatedStructRec(
							ratedMapper.mapToJpe(detailApi, detailsJpe.getChargeRatedStructRec()));
				} else if (CHARGE_TYPE_INTEREST.equals(detailsJpe.getChargeType())) {
					detailsJpe.setChargeInterestStructRec(
							interestMapper.mapToJpe(detailApi, detailsJpe.getChargeInterestStructRec()));
				}
				if (jpe.getChargeDetailsList() == null) {
					jpe.setChargeDetailsList(new ArrayList<ChargeDetailsJpe>());
				}
                ChargeDetails bdo = jaxbSdoHelper.wrap(detailsJpe);
                bdoHelper.callEntityListenerMethod(bdo, new Class<?>[] { ChargeNoResolver.class }, "postBuild");    
                jpe.getChargeDetailsList().add(jaxbSdoHelper.unwrap(bdo));
			}
		}
		return jpe;
	}

}
