package com.silverlakesymmetri.cbs.xps.svc;

import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation;
import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation.ServiceOperationType;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.svc.BusinessService;
import com.silverlakesymmetri.cbs.xps.bdo.sdo.DepAcctRestraintQry;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.DepAcctRestraintQryJpe;

import java.util.List;
import java.util.Map;


public interface DepAcctRestraintQryService extends BusinessService<DepAcctRestraintQry, DepAcctRestraintQryJpe> {

    public static final String SVC_OP_NAME_DEPACCTRESTRAINTQRY_GET = "DepAcctRestraintQryService.get";
    public static final String SVC_OP_NAME_DEPACCTRESTRAINTQRY_QUERY = "DepAcctRestraintQryService.query";
    public static final String SVC_OP_NAME_DEPACCTRESTRAINTQRY_FIND = "DepAcctRestraintQryService.find";

    @ServiceOperation(name = SVC_OP_NAME_DEPACCTRESTRAINTQRY_GET, type = ServiceOperationType.GET)
    public DepAcctRestraintQry getByPk(String publicKey, DepAcctRestraintQry reference);
    
    @ServiceOperation(name = SVC_OP_NAME_DEPACCTRESTRAINTQRY_QUERY)
    public List<DepAcctRestraintQry> query(int offset, int resultLimit, String groupBy, String order, Map<String, Object> filters);

    @ServiceOperation(name = SVC_OP_NAME_DEPACCTRESTRAINTQRY_FIND)
    public List<DepAcctRestraintQry> find(FindCriteria findCriteria, CbsHeader cbsHeader);


}
