package com.silverlakesymmetri.cbs.xps.svc.impl;

import com.mysema.query.types.EntityPath;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.jpa.service.CbsEntityManagerAware;
import com.silverlakesymmetri.cbs.commons.svc.AbstractBusinessService;
import com.silverlakesymmetri.cbs.xps.bdo.sdo.CommonOnlineAcctgEntriesQry;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.*;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.QCommonOnlineAcctgEntriesQryJpe;
import com.silverlakesymmetri.cbs.xps.svc.CommonOnlineAcctgEntriesQryService;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.persistence.TypedQuery;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import org.apache.commons.lang3.StringUtils;

@Service
@Transactional
public class CommonOnlineAcctgEntriesQryServiceImpl extends AbstractBusinessService<CommonOnlineAcctgEntriesQry, CommonOnlineAcctgEntriesQryJpe, Long> implements CommonOnlineAcctgEntriesQryService {
	

	private static final String BGT = "BGT";
	private static final String DEP = "DEP";
	private static final String GFT = "GFT";
	private static final String LND = "LND";


    @Override
    public CommonOnlineAcctgEntriesQry getByPk(String publicKey, CommonOnlineAcctgEntriesQry reference) {
    	return null;
    }

    @Override
    public List<CommonOnlineAcctgEntriesQry> find(FindCriteria findCriteria, CbsHeader cbsHeader) {
        return super.find(findCriteria, cbsHeader);
    }
    
    @Override
    public List<CommonOnlineAcctgEntriesQry> query(int offset, int resultLimit, String groupBy, String order, Map<String, Object> filters){
    	if(filters.containsKey("journalNo") && filters.containsKey("sourceModule")){
			String sourceModule = filters.get("sourceModule") != null ? filters.get("sourceModule").toString(): null;
			filters.remove("sourceModule");

			return queryAcctEntries(offset, resultLimit, groupBy, order, filters, sourceModule);
    	}
    	return super.query(offset, resultLimit, groupBy, order, filters);
    }

	@Override
    protected Long getIdFromDataObjectInstance(CommonOnlineAcctgEntriesQry dataObject) {
        return null;
    }

    @Override
    protected EntityPath<CommonOnlineAcctgEntriesQryJpe> getEntityPath() {
        return QCommonOnlineAcctgEntriesQryJpe.commonOnlineAcctgEntriesQryJpe;
    }
    
    @Override
    public Long count(FindCriteria findCriteria, CbsHeader cbsHeader) {
    	List<CommonOnlineAcctgEntriesQry> list = find(findCriteria, cbsHeader);
    	return list != null ? new Integer(list.size()).longValue() : 0L;
    }


	public List<CommonOnlineAcctgEntriesQry> queryAcctEntries(int offset, int resultLimit, String groupBy, String order, Map<String, Object> filters, String sourceModule) {
    	List<CommonOnlineAcctgEntriesQry> sdoResult = new ArrayList<CommonOnlineAcctgEntriesQry>();
		int i=0;
		StringBuilder queryString = new StringBuilder();

		queryString.append("SELECT a FROM " );

		if(BGT.equalsIgnoreCase(sourceModule)) {
			queryString.append(" BgtOnlineAcctgEntriesQryJpe a " );
		} else if(DEP.equalsIgnoreCase(sourceModule)) {
			queryString.append(" DepOnlineAcctgEntriesQryJpe a " );
		} else if(GFT.equalsIgnoreCase(sourceModule)) {
			queryString.append(" GftOnlineAcctgEntriesQryJpe a " );
		} else if(LND.equalsIgnoreCase(sourceModule)) {
			queryString.append(" LndOnlineAcctgEntriesQryJpe a " );
		} else {
			queryString.append(" TfnOnlineAcctgEntriesQryJpe a " );
		}

		if(filters != null) {
			for (Map.Entry<String, Object> entry : filters.entrySet()) {
				if(i == 0) {
					queryString.append(" WHERE " );
				} else {
					queryString.append(" AND ");
				}
				queryString.append("a.").append(entry.getKey()).append("=:").append(entry.getKey()).append(" ");
				i++;
			}
		}

		String q = (groupBy == null || groupBy.isEmpty()) ? queryString.toString() : appendOrderByToQuery(queryString.toString(), "a", groupBy, order);


		TypedQuery query;

		if(BGT.equalsIgnoreCase(sourceModule)) {
			 query = ((CbsEntityManagerAware) dataService).getMyEntityManager().createQuery(
					q , BgtOnlineAcctgEntriesQryJpe.class);
		} else if(DEP.equalsIgnoreCase(sourceModule)) {
			 query = ((CbsEntityManagerAware) dataService).getMyEntityManager().createQuery(
					q , DepOnlineAcctgEntriesQryJpe.class);
		} else if(GFT.equalsIgnoreCase(sourceModule)) {
			 query = ((CbsEntityManagerAware) dataService).getMyEntityManager().createQuery(
					q , GftOnlineAcctgEntriesQryJpe.class);
		} else if(LND.equalsIgnoreCase(sourceModule)) {
			 query = ((CbsEntityManagerAware) dataService).getMyEntityManager().createQuery(
					q , LndOnlineAcctgEntriesQryJpe.class);
		} else {
			 query = ((CbsEntityManagerAware) dataService).getMyEntityManager().createQuery(
					q , TfnOnlineAcctgEntriesQryJpe.class);
		}


		if(filters != null) {
			for (Map.Entry<String, Object> entry : filters.entrySet()) {

			    if("journalNo".equalsIgnoreCase(entry.getKey())) {
			    	if(entry.getValue().equals("null")) {
			    		return sdoResult;
			    	}
                    query.setParameter(entry.getKey(), Long.valueOf(entry.getValue().toString()));
                } else {
                    query.setParameter(entry.getKey(), entry.getValue());
                }

			}
		}


		query.setFirstResult(offset);
		query.setMaxResults(resultLimit);

		List<Object> jpeResult = query.getResultList();

		if(jpeResult != null && jpeResult.size() > 0) {
			sdoResult = jpeResult.stream()
					.map(jpe -> jaxbSdoHelper.wrap(jpe, CommonOnlineAcctgEntriesQry.class))
					.collect(Collectors.toList());
		}


		//do sorting and filtering here


		return sdoResult;
	}

}
