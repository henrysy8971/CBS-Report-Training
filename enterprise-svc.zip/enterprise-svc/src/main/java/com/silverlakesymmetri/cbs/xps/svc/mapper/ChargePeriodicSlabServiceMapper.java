package com.silverlakesymmetri.cbs.xps.svc.mapper;

import org.mapstruct.DecoratedWith;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingTarget;
import org.mapstruct.Mappings;

import com.silverlakesymmetri.cbs.commons.jpa.util.DateTimeHelper;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.PeriodicSlabJpe;
import com.silverlakesymmetri.cbs.xps.svc.mapper.decorator.ChargePeriodicSlabServiceDecorator;
import com.silverlakesymmetri.cbs.xps.xmlapi.XPSTRANCHARGEDETAILSLABTYPEType;

@Mapper(uses = { DateTimeHelper.class })
@DecoratedWith(ChargePeriodicSlabServiceDecorator.class)
public interface ChargePeriodicSlabServiceMapper {

	@Mappings({
		@Mapping(source="balance", target = "BALANCE"),
		@Mapping(source="calculatedAmt", target = "CALCULATEDAMT"),
		@Mapping(source="actualAmt", target = "ACTUALAMT"),
		@Mapping(source="tranRateAmt", target = "TRANRATEAMT"),
		@Mapping(source="tranRateBalance", target = "TRANRATEBALANCE"),
		@Mapping(source="seqNo", target = "SEQNO"),
		@Mapping(source="relDetailKey", target = "RELDETAILKEY")
	})
	public XPSTRANCHARGEDETAILSLABTYPEType mapToApi(PeriodicSlabJpe jpe, @MappingTarget XPSTRANCHARGEDETAILSLABTYPEType api);

	@Mappings({
		@Mapping(source="balance", target = "BALANCE"),
		@Mapping(source="calculatedAmt", target = "CALCULATEDAMT"),
		@Mapping(source="actualAmt", target = "ACTUALAMT"),
		@Mapping(source="tranRateAmt", target = "TRANRATEAMT"),
		@Mapping(source="tranRateBalance", target = "TRANRATEBALANCE"),
		@Mapping(source="seqNo", target = "SEQNO"),
		@Mapping(source="relDetailKey", target = "RELDETAILKEY")
	})
	public XPSTRANCHARGEDETAILSLABTYPEType mapToApi(PeriodicSlabJpe jpe);

	@Mappings({
		@Mapping(target="balance", source = "BALANCE"),
		@Mapping(target="calculatedAmt", source = "CALCULATEDAMT"),
		@Mapping(target="actualAmt", source = "ACTUALAMT"),
		@Mapping(target="tranRateAmt", source = "TRANRATEAMT"),
		@Mapping(target="tranRateBalance", source = "TRANRATEBALANCE"),
		@Mapping(target="seqNo", source = "SEQNO"),
		@Mapping(target="relDetailKey", source = "RELDETAILKEY")
	})
	public PeriodicSlabJpe mapToJpe(XPSTRANCHARGEDETAILSLABTYPEType api, @MappingTarget PeriodicSlabJpe jpe);

	@Mappings({
		@Mapping(target="balance", source = "BALANCE"),
		@Mapping(target="calculatedAmt", source = "CALCULATEDAMT"),
		@Mapping(target="actualAmt", source = "ACTUALAMT"),
		@Mapping(target="tranRateAmt", source = "TRANRATEAMT"),
		@Mapping(target="tranRateBalance", source = "TRANRATEBALANCE"),
		@Mapping(target="seqNo", source = "SEQNO"),
		@Mapping(target="relDetailKey", source = "RELDETAILKEY")
	})
	public PeriodicSlabJpe mapToJpe(XPSTRANCHARGEDETAILSLABTYPEType api);

}