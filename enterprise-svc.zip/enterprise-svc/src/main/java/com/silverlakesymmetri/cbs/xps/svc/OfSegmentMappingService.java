package com.silverlakesymmetri.cbs.xps.svc;

import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.svc.BusinessService;
import com.silverlakesymmetri.cbs.xps.bdo.sdo.OfSegmentMapping;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.OfSegmentMappingJpe;

import java.util.List;
import java.util.Map;

public interface OfSegmentMappingService extends BusinessService<OfSegmentMapping, OfSegmentMappingJpe> {

    public static final String XPS_OP_NAME_OFSEGMENTMAPPING_GET = "OfSegmentMapping.get";
    public static final String XPS_OP_NAME_OFSEGMENTMAPPING_CREATE = "OfSegmentMapping.create";
    public static final String XPS_OP_NAME_OFSEGMENTMAPPING_UPDATE = "OfSegmentMapping.update";
    public static final String XPS_OP_NAME_OFSEGMENTMAPPING_DELETE = "OfSegmentMapping.delete";
    public static final String XPS_OP_NAME_OFSEGMENTMAPPING_FIND = "OfSegmentMapping.find";
    public static final String XPS_OP_NAME_OFSEGMENTMAPPING_QUERY = "OfSegmentMapping.query";

    @ServiceOperation(name = XPS_OP_NAME_OFSEGMENTMAPPING_GET, type = ServiceOperation.ServiceOperationType.GET)
    public OfSegmentMapping getByPk(String publicKey, OfSegmentMapping reference);

    @ServiceOperation(name = XPS_OP_NAME_OFSEGMENTMAPPING_CREATE)
    public OfSegmentMapping create(OfSegmentMapping dataObject);

    @ServiceOperation(name = XPS_OP_NAME_OFSEGMENTMAPPING_UPDATE)
    public OfSegmentMapping update(OfSegmentMapping bdoInstance);

    @ServiceOperation(name = XPS_OP_NAME_OFSEGMENTMAPPING_DELETE)
    public boolean delete(OfSegmentMapping bdoInstance);

    @ServiceOperation(name = XPS_OP_NAME_OFSEGMENTMAPPING_QUERY)
    public List<OfSegmentMapping> query(int offset, int resultLimit, String groupBy, String order, Map<String, Object> filters);

    @ServiceOperation(name = XPS_OP_NAME_OFSEGMENTMAPPING_FIND)
    public List<OfSegmentMapping> find(FindCriteria findCriteria, CbsHeader cbsHeader);
}
