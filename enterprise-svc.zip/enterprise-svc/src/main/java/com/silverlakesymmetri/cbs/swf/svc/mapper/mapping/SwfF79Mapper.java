package com.silverlakesymmetri.cbs.swf.svc.mapper.mapping;

import org.apache.commons.lang3.StringUtils;
import org.mapstruct.DecoratedWith;
import org.mapstruct.InheritInverseConfiguration;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingTarget;
import org.mapstruct.Mappings;

import com.silverlakesymmetri.cbs.swf.jpa.mapping.sdo.SwfF79Jpe;
import com.silverlakesymmetri.cbs.swf.svc.mapper.decorator.SwfF79MapperDecorator;
import com.silverlakesymmetri.cbs.swf.xmlapi.SWFF79TYPEType;


@Mapper(imports=StringUtils.class)
@DecoratedWith(SwfF79MapperDecorator.class)
public interface SwfF79Mapper {

	@Mappings({
		@Mapping(source = "opt", target = "OPT"),
		@Mapping(source = "code", target = "CODE"),
		@Mapping(source = "narrative", target = "NARRATIVE")
	})
	SWFF79TYPEType mapToApi(SwfF79Jpe jpe);
	
	@Mappings({
		@Mapping(target="opt", expression="java(StringUtils.isNotBlank(api.getOPT())?api.getOPT():null)"),
	})
	@InheritInverseConfiguration(name = "mapToApi")
	SwfF79Jpe mapToJpe(SWFF79TYPEType api, @MappingTarget SwfF79Jpe jpe);
	
	@Mappings({
		@Mapping(target="opt", expression="java(StringUtils.isNotBlank(api.getOPT())?api.getOPT():null)"),
	})
	@InheritInverseConfiguration(name = "mapToApi")
	SwfF79Jpe mapToJpe(SWFF79TYPEType api);
}
