package com.silverlakesymmetri.cbs.gla.svc.mapper.mapping;

import com.silverlakesymmetri.cbs.commons.jpa.util.DateTimeHelper;
import com.silverlakesymmetri.cbs.gla.jpa.mapping.sdo.GlAcctClosureJpe;
import com.silverlakesymmetri.cbs.gla.xmlapi.GLAACCTCLOSUREAPIType;
import org.mapstruct.InheritInverseConfiguration;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Mappings;

/**
 * Created by Emerson.Sanchez on 26/7/2019.
 */
@Mapper(uses = { DateTimeHelper.class })
public interface GlAcctClosureToGLAACCTCLOSUREAPITypeMapper {
    @Mappings({
            @Mapping(target = "glType", source = "GLTYPE"),
            @Mapping(target = "branch", source = "BRANCH"),
            @Mapping(target = "ccy", source = "CCY"),
            @Mapping(target = "glCode", source = "GLCODE"),
            @Mapping(target = "seqNo", source = "SEQNO"),
            @Mapping(target = "profitCentre", source = "PROFITCENTRE"),
            @Mapping(target = "nosVosNo", source = "NOSVOSNO"),
            @Mapping(target = "olLedgerBal", source = "OLLEDGERBAL"),
            @Mapping(target = "olLedgerBalDrCr", source = "OLLEDGERBALDRCRIND"),
            @Mapping(target = "closingBalance", source = "CLOSINGBALANCE"),
            @Mapping(target = "closingBalanceDrCr", source = "CLOSINGBALANCEDRCRIND"),
            @Mapping(target = "acctCloseReason", source = "ACCTCLOSEREASON"),
            @Mapping(target = "confirmFlag", source = "CONFIRMIND"),
            @Mapping(target = "sweepFlag", source = "SWEEPIND"),
            @Mapping(target = "capFlag", source = "CAPIND"),
            @Mapping(target = "drNextCycleDate", source = "DRNEXTCYCLEDATE", qualifiedByName = {"DateTimeHelper","convertCbsApiDateToString"}),
            @Mapping(target = "crNextCycleDate", source = "CRNEXTCYCLEDATE", qualifiedByName = {"DateTimeHelper","convertCbsApiDateToString"}),
            @Mapping(target = "olActualBal", source = "OLACTUALBAL"),
            @Mapping(target = "accruedBal", source = "ACCRUEDBAL"),
            @Mapping(target = "acctStatus", source = "ACCTSTATUS"),
            @Mapping(target = "ledgerBal", source = "LEDGERBAL"),
            @Mapping(target = "actualBal", source = "ACTUALBAL"),
            @Mapping(target = "internalKey", source = "INTERNALKEY"),
            @Mapping(target = "acctType", source = "ACCTTYPE")
    })
    public GlAcctClosureJpe apiTypeToJpe(GLAACCTCLOSUREAPIType apiType);

    @Mappings({
            @Mapping(source = "drNextCycleDate", target = "DRNEXTCYCLEDATE", qualifiedByName = {"DateTimeHelper","convertDateToCbsXmlApiDate"}),
            @Mapping(source = "crNextCycleDate", target = "CRNEXTCYCLEDATE", qualifiedByName = {"DateTimeHelper","convertDateToCbsXmlApiDate"}),
    })
    @InheritInverseConfiguration
    public GLAACCTCLOSUREAPIType jpeToApiType(GlAcctClosureJpe jpe);
}
