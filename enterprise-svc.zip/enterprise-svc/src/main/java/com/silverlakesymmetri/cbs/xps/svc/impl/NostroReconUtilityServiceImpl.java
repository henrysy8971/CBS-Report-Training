package com.silverlakesymmetri.cbs.xps.svc.impl;

import static java.util.stream.Collectors.toMap;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.silverlakesymmetri.cbs.commons.context.CbsRuntimeContextManager;
import com.silverlakesymmetri.cbs.commons.context.CbsSessionContext;
import com.silverlakesymmetri.cbs.commons.jpa.extension.JaxbSdoHelper;
import com.silverlakesymmetri.cbs.commons.jpa.service.CbsGenericDataService;
import com.silverlakesymmetri.cbs.commons.jpa.util.DateTimeHelper;
import com.silverlakesymmetri.cbs.commons.svc.context.impl.CbsRuntimeContextManagerImpl;
import com.silverlakesymmetri.cbs.xps.enums.NostroReconEnum;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.NrPostJpe;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.NrStmtDetailJpe;
import com.silverlakesymmetri.cbs.xps.svc.NostroReconUtilityService;
import com.silverlakesymmetri.cbs.xps.util.NostroReconciliationObject;

@Service
public class NostroReconUtilityServiceImpl implements NostroReconUtilityService{
	
	private static final String MATCH_TYPE_SKIP = "S";
	private static final String MATCH_TYPE_FORCEMATCH = "F";
	private static final String SEQUENCE_NAME = "XPS_NR_RECON_SEQ_NO_S";
	
	@Autowired(required = true)
    @Qualifier("cbsGenericDataService")
    protected CbsGenericDataService dataService;

	@Autowired
    protected JaxbSdoHelper jaxbSdoHelper;

	@Autowired
    protected DateTimeHelper dateHelper;
    
    @Autowired
    private CbsRuntimeContextManager ctxMngr;

	@Override
	public NostroReconciliationObject reconcile(NostroReconciliationObject nrObj) {
		if(NostroReconEnum.FORCEMATCH.toString().equals(nrObj.getAction())){
			doForceMatch(nrObj);
		}else if(NostroReconEnum.UNMATCH.toString().equals(nrObj.getAction())){
			doUnmatch(nrObj);
		}else if(NostroReconEnum.SKIP.toString().equals(nrObj.getAction())){
			doSkip(nrObj);
		}else if(NostroReconEnum.UNSKIP.toString().equals(nrObj.getAction())){
			doUnskip(nrObj);
		}
		return nrObj;
	}

	private void doUnskip(NostroReconciliationObject nrObj) {
		List<NrStmtDetailJpe> exList = getExternalJpeList(nrObj, null);
		for(NrStmtDetailJpe jpe: exList){
			jpe.setMatchType(null);
			jpe.setUnskipBy(getCurrentUser());
			jpe.setUnskipDate(dateHelper.getRunDate());
			this.dataService.update(jpe);
		}

		List<NrPostJpe> intList = getInternalJpeList(nrObj, null);
		for(NrPostJpe jpe: intList){
			jpe.setMatchType(null);
			jpe.setUnskipBy(getCurrentUser());
			jpe.setUnskipDate(dateHelper.getRunDate());
			this.dataService.update(jpe);
		}
	}

	private void doSkip(NostroReconciliationObject nrObj) {
		List<NrStmtDetailJpe> exList = getExternalJpeList(nrObj, null);
		for(NrStmtDetailJpe jpe: exList){
			jpe.setMatchType(MATCH_TYPE_SKIP);
			jpe.setSkipBy(getCurrentUser());
			jpe.setSkipDate(dateHelper.getRunDate());
			this.dataService.update(jpe);
		}

		List<NrPostJpe> intList = getInternalJpeList(nrObj, null);
		for(NrPostJpe jpe: intList){
			jpe.setMatchType(MATCH_TYPE_SKIP);
			jpe.setSkipBy(getCurrentUser());
			jpe.setSkipDate(dateHelper.getRunDate());
			this.dataService.update(jpe);
		}
	}

	private void doUnmatch(NostroReconciliationObject nrObj) {
		List<NrStmtDetailJpe> exList = getExternalListByRecon(nrObj);
		for(NrStmtDetailJpe jpe: exList){
			jpe.setReconSeqNo(null);
			jpe.setMatchType(null);
			jpe.setUnmatchBy(getCurrentUser());
			jpe.setUnmatchDate(dateHelper.getRunDate());
			jpe.setOutstandingAmt(null);
			this.dataService.update(jpe);
		}

		List<NrPostJpe> intList = getInternalListByRecon(nrObj);
		for(NrPostJpe jpe: intList){
			jpe.setReconSeqNo(null);
			jpe.setMatchType(null);
			jpe.setUnmatchBy(getCurrentUser());
			jpe.setUnmatchDate(dateHelper.getRunDate());
			jpe.setOutstandingAmt(null);
			this.dataService.update(jpe);
		}
	}

	private void doForceMatch(NostroReconciliationObject nrObj) {
		//external
		Map<Long, Double> extAmtMap = new HashMap<>();
		List<NrStmtDetailJpe> exList = getExternalJpeList(nrObj, extAmtMap);
		Map<Long, Double> extSortedAmtMap = this.sortByValue(extAmtMap);
		Double extTotal = extAmtMap.values().stream().reduce(0d, Double::sum);
		
		//internal
		Map<Long, Double> intAmtMap = new HashMap<>();
		List<NrPostJpe> intList = getInternalJpeList(nrObj, intAmtMap);
		Map<Long, Double> intSortedAmtMap = this.sortByValue(intAmtMap);
		Double intTotal = intAmtMap.values().stream().reduce(0d, Double::sum);

		//logic
		Double diff = Math.abs(extTotal - intTotal);
		boolean updExtOutstanding = false;
		boolean updIntOutstanding = false;
		Map.Entry<Long, Double> extWithHighestAmt = null;
		Map.Entry<Long, Double> intWithHighestAmt = null;
		if(diff > 0){
			updExtOutstanding = extTotal > intTotal;
			updIntOutstanding = intTotal > extTotal;
			if(updExtOutstanding){
				extWithHighestAmt = extSortedAmtMap.entrySet().iterator().next();
			}
			if(updIntOutstanding){
				intWithHighestAmt = intSortedAmtMap.entrySet().iterator().next();
			}
		}
		
		//update
		Long reconSeqNo = dataService.nextSequenceValue(SEQUENCE_NAME);
		for(NrStmtDetailJpe jpe: exList){
			jpe.setReconSeqNo(reconSeqNo.intValue());
			jpe.setMatchType(MATCH_TYPE_FORCEMATCH);
			jpe.setMatchBy(getCurrentUser());
			jpe.setMatchDate(dateHelper.getRunDate());
			if(updExtOutstanding && extWithHighestAmt != null){
				if(jpe.getInternalKey().equals(extWithHighestAmt.getKey())){
					jpe.setOutstandingAmt(diff);
				}
			}
			this.dataService.update(jpe);
		}
		for(NrPostJpe jpe: intList){
			jpe.setReconSeqNo(reconSeqNo.intValue());
			jpe.setMatchType(MATCH_TYPE_FORCEMATCH);
			jpe.setMatchBy(getCurrentUser());
			jpe.setMatchDate(dateHelper.getRunDate());
			if(updIntOutstanding && intWithHighestAmt != null){
				if(jpe.getInternalKey().equals(intWithHighestAmt.getKey())){
					jpe.setOutstandingAmt(diff);
				}
			}
			this.dataService.update(jpe);
		}
	}

	/*
	private List<NrStmtDetail> getExternalBdoList(NostroReconciliationObject nrObj){
		Double total = 0d;
		return getExternalBdoList(nrObj,total);
	}
	
	private List<NrStmtDetail> getExternalBdoList(NostroReconciliationObject nrObj, Double total){
		Map<Long, Double> amountMap = new HashMap<Long, Double>();
		return getExternalBdoList(nrObj,total,amountMap);
	}
	
	private List<NrStmtDetail> getExternalBdoList(NostroReconciliationObject nrObj, Double total, Map<Long, Double> amountMap){
		List<NrStmtDetail> externalBdoList = new ArrayList<>();
		total = 0d;

		if(nrObj.getExternalPkList() !=null && !nrObj.getExternalPkList().isEmpty()){
			String query = "select e from NrStmtDetailJpe e where e.internalKey IN :keys";
			Map<String, Object> filters = new HashMap<>();
			filters.put("keys", nrObj.getExternalPkList());

			List<NrStmtDetailJpe> externalList = dataService.findWithQuery(query, NrStmtDetailJpe.class, filters, null);
			if(externalList!=null){
				for(NrStmtDetailJpe jpe : externalList){
					total = total + jpe.getAmount();
					amountMap.put(jpe.getInternalKey(), jpe.getAmount());
					externalBdoList.add(jaxbSdoHelper.wrap(jpe, NrStmtDetail.class));
				}
			}
		}
		
		return externalBdoList;
	}
	*/
	
	private List<NrStmtDetailJpe> getExternalJpeList(NostroReconciliationObject nrObj, Map<Long, Double> amountMap){
		List<NrStmtDetailJpe> externalList = new ArrayList<>();
		if(amountMap==null){amountMap = new HashMap<>();}
		
		if(nrObj.getExternalPkList() !=null && !nrObj.getExternalPkList().isEmpty()){
			String query = "select e from NrStmtDetailJpe e where e.internalKey IN :keys";
			Map<String, Object> filters = new HashMap<>();
			filters.put("keys", nrObj.getExternalPkList());
			
			externalList = dataService.findWithQuery(query, NrStmtDetailJpe.class, filters, null);
			if(externalList!=null){
				for(NrStmtDetailJpe jpe : externalList){
					amountMap.put(jpe.getInternalKey(), jpe.getAmount());
				}
			}
		}
		
		return externalList;
	}

	private List<NrStmtDetailJpe> getExternalListByRecon(NostroReconciliationObject nrObj){
		List<NrStmtDetailJpe> externalList = new ArrayList<>();

		if(nrObj.getExternalPkList() !=null && !nrObj.getExternalPkList().isEmpty()){
			String query = "select e1 from NrStmtDetailJpe e1 where EXISTS "
					+ "(select 1 from NrStmtDetailJpe e2 where e2.reconSeqNo = e1.reconSeqNo and e2.internalKey in :keys)";

			Map<String, Object> filters = new HashMap<>();
			filters.put("keys", nrObj.getExternalPkList());
			externalList = dataService.findWithQuery(query, NrStmtDetailJpe.class, filters, null);
		}
		
		return externalList;
	}
	
	/*
	private List<NrPost> getInternalBdoList(NostroReconciliationObject nrObj){
		Double total = 0d;
		return getInternalBdoList(nrObj, total);
	}
	
	private List<NrPost> getInternalBdoList(NostroReconciliationObject nrObj, Double total){
		Map<Long, Double> amountMap = new HashMap<>();
		return getInternalBdoList(nrObj, total, amountMap);
	}
	
	private List<NrPost> getInternalBdoList(NostroReconciliationObject nrObj, Double total, Map<Long, Double> amountMap){
		List<NrPost> internalBdoList = new ArrayList<>();
		total = 0d;
		
		if(nrObj.getInternalPkList() !=null && !nrObj.getInternalPkList().isEmpty()){
			String query = "select e from NrPostJpe e where e.internalKey IN :keys";
			
			Map<String, Object> filters = new HashMap<>();
			filters.put("keys", nrObj.getInternalPkList());

			List<NrPostJpe> internalList = dataService.findWithQuery(query, NrPostJpe.class, filters, null);
			
			if(internalList!=null){
				for(NrPostJpe jpe : internalList){
					total = total + jpe.getAmount();
					amountMap.put(jpe.getInternalKey(), jpe.getAmount());
					internalBdoList.add(jaxbSdoHelper.wrap(jpe, NrPost.class));
				}
			}
		}
		
		return internalBdoList;
	}
	*/
	
	private List<NrPostJpe> getInternalJpeList(NostroReconciliationObject nrObj, Map<Long, Double> amountMap){
		List<NrPostJpe> internalList = new ArrayList<>();
		if(amountMap==null){amountMap=new HashMap<>();}
		
		if(nrObj.getInternalPkList() !=null && !nrObj.getInternalPkList().isEmpty()){
			String query = "select e from NrPostJpe e where e.internalKey IN :keys";
			
			Map<String, Object> filters = new HashMap<>();
			filters.put("keys", nrObj.getInternalPkList());
			
			internalList = dataService.findWithQuery(query, NrPostJpe.class, filters, null);
			
			if(internalList!=null){
				for(NrPostJpe jpe : internalList){
					amountMap.put(jpe.getInternalKey(), jpe.getAmount());
				}
			}
		}
		
		return internalList;
	}

	private List<NrPostJpe> getInternalListByRecon(NostroReconciliationObject nrObj){
		List<NrPostJpe> internalList = new ArrayList<>();

		if(nrObj.getInternalPkList() !=null && !nrObj.getInternalPkList().isEmpty()){
			String query = "select e1 from NrPostJpe e1 where EXISTS "
					+ "(select 1 from NrPostJpe e2 where e2.reconSeqNo = e1.reconSeqNo and e2.internalKey in :keys)";

			Map<String, Object> filters = new HashMap<>();
			filters.put("keys", nrObj.getInternalPkList());
			internalList = dataService.findWithQuery(query, NrPostJpe.class, filters, null);
		}
		
		return internalList;
	}

    private Map<Long, Double> sortByValue(Map<Long, Double> amountMap) {
        return amountMap.entrySet()
                .stream()
                .sorted(Map.Entry.<Long, Double>comparingByValue().reversed())
                .collect(toMap(Map.Entry::getKey, Map.Entry::getValue, (e1, e2) -> e1, LinkedHashMap::new));
    }

	private String getCurrentUser(){
		CbsSessionContext sessionCtx = ((CbsRuntimeContextManagerImpl) ctxMngr).getContext(CbsSessionContext.class);
		return sessionCtx.getUserCode();
	}
	
}
