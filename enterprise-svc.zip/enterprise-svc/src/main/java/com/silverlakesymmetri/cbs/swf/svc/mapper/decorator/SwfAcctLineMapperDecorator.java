package com.silverlakesymmetri.cbs.swf.svc.mapper.decorator;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

import com.silverlakesymmetri.cbs.swf.jpa.mapping.sdo.SwfAcctLineJpe;
import com.silverlakesymmetri.cbs.swf.svc.mapper.mapping.SwfAcctLineMapper;
import com.silverlakesymmetri.cbs.swf.xmlapi.SWFACCTLINETYPEType;

public abstract class SwfAcctLineMapperDecorator implements SwfAcctLineMapper {
	
	@Autowired
	@Qualifier("delegate")
	protected SwfAcctLineMapper delegate;

	@Override
	public SWFACCTLINETYPEType mapToApi(SwfAcctLineJpe jpe){
		SWFACCTLINETYPEType acctLine = delegate.mapToApi(jpe);
		if(acctLine != null && acctLine.getACCOUNTNO() == null && acctLine.getACCTIDENTIFICATION() == null && acctLine.getCLEARINGSYSTEMCODE() == null){
			return null;
		}
		return acctLine;
	}
	
	@Override
	public SwfAcctLineJpe mapToJpe(SWFACCTLINETYPEType api){
		return delegate.mapToJpe(api);
	}
	
}
