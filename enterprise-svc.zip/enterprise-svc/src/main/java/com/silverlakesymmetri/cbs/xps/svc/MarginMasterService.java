package com.silverlakesymmetri.cbs.xps.svc;

import java.util.List;
import java.util.Map;

import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation;
import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation.ServiceOperationType;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.svc.BusinessService;
import com.silverlakesymmetri.cbs.xps.bdo.sdo.MarginMaster;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.MarginMasterJpe;

public interface MarginMasterService extends BusinessService<MarginMaster, MarginMasterJpe> {
	public static final String XPS_MARGINMASTERSERVICE_GET = "MarginMasterService.get";
    public static final String XPS_MARGINMASTERSERVICE_QUERY = "MarginMasterService.query";
    public static final String XPS_MARGINMASTERSERVICE_FIND = "MarginMasterService.find";
    public static final String XPS_MARGINMASTERSERVICE_CREATE = "MarginMasterService.create";
    public static final String XPS_MARGINMASTERSERVICE_UPDATE = "MarginMasterService.update";
    public static final String XPS_MARGINMASTERSERVICE_DELETE = "MarginMasterService.delete";
    public static final String XPS_MARGINMASTERSERVICE_COUNT = "MarginMasterService.count";
    
    @ServiceOperation(name = XPS_MARGINMASTERSERVICE_GET, type = ServiceOperationType.GET)
    public MarginMaster getByPk(String publicKey, MarginMaster reference);

    @ServiceOperation(name = XPS_MARGINMASTERSERVICE_QUERY)
    public List<MarginMaster> query(int offset, int resultLimit, String groupBy, String order, Map<String, Object> filters);
    
    @ServiceOperation(name = XPS_MARGINMASTERSERVICE_FIND)
    public List<MarginMaster> find(FindCriteria findCriteria, CbsHeader cbsHeader);
    
    @ServiceOperation(name = XPS_MARGINMASTERSERVICE_COUNT, type = ServiceOperationType.GET)
    public Long count(FindCriteria findCriteria, CbsHeader cbsHeader);
    
    @ServiceOperation(name = XPS_MARGINMASTERSERVICE_CREATE)
    public MarginMaster create(MarginMaster dataObject);

    @ServiceOperation(name = XPS_MARGINMASTERSERVICE_UPDATE)
    public MarginMaster update(MarginMaster dataObject);

    @ServiceOperation(name = XPS_MARGINMASTERSERVICE_DELETE)
    public boolean delete(MarginMaster dataObject);
}