package com.silverlakesymmetri.cbs.xps.svc;

import java.util.Map;

import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation;
import com.silverlakesymmetri.cbs.commons.svc.BusinessService;
import com.silverlakesymmetri.cbs.xps.bdo.sdo.ChargeDetails;
import com.silverlakesymmetri.cbs.xps.bdo.sdo.ChargeMaster;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.ChargeMasterJpe;

public interface ChargeRecalculateService extends BusinessService<ChargeMaster, ChargeMasterJpe> {

	public static final String XPS_CHARGERECALCULATESERVICE_RECALCULATE = "ChargeRecalculateService.recalculate";

	@ServiceOperation(name = XPS_CHARGERECALCULATESERVICE_RECALCULATE, passParamAsMap = true)
    public ChargeDetails recalculate(Map<String, Object> params);
	
}