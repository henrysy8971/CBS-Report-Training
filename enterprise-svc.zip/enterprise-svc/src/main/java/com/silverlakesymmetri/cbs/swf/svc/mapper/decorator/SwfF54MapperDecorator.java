package com.silverlakesymmetri.cbs.swf.svc.mapper.decorator;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

import com.silverlakesymmetri.cbs.swf.jpa.mapping.sdo.SwfFinEntityJpe;
import com.silverlakesymmetri.cbs.swf.svc.mapper.mapping.SwfF54Mapper;
import com.silverlakesymmetri.cbs.swf.xmlapi.SWFF54TYPEType;

public abstract class SwfF54MapperDecorator implements SwfF54Mapper {
	
	@Autowired
	@Qualifier("delegate")
	protected SwfF54Mapper delegate;

	@Override
	public SWFF54TYPEType mapToApi(SwfFinEntityJpe jpe){
		SWFF54TYPEType swfF54 = delegate.mapToApi(jpe);
		if(swfF54 != null && swfF54.getACCOUNT() == null && swfF54.getADDRESS() == null && swfF54.getBIC() == null && swfF54.getBRANCHLOCATION() == null){
			return null;
		}
		return swfF54;
	}
	
	@Override
	public SwfFinEntityJpe mapToJpe(SWFF54TYPEType api){
		return delegate.mapToJpe(api);
	}
	
}
