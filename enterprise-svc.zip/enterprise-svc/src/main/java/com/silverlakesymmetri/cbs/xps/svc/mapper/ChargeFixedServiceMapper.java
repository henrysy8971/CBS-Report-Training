package com.silverlakesymmetri.cbs.xps.svc.mapper;

import org.mapstruct.DecoratedWith;
import org.mapstruct.InheritInverseConfiguration;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingTarget;
import org.mapstruct.Mappings;

import com.silverlakesymmetri.cbs.commons.jpa.util.DateTimeHelper;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.ChargeFixedJpe;
import com.silverlakesymmetri.cbs.xps.svc.mapper.decorator.ChargeFixedServiceDecorator;
import com.silverlakesymmetri.cbs.xps.xmlapi.XPSTRANCHARGEDETAILAPIType;

@Mapper(uses = { DateTimeHelper.class })
@DecoratedWith(ChargeFixedServiceDecorator.class)
public interface ChargeFixedServiceMapper {

	@Mappings({
		@Mapping(source="setupCcy", target = "SETUPCCY"),
		@Mapping(source="setupAmt", target = "SETUPAMT"),
		@Mapping(source="exchRate", target = "EXCHRATE"),
		@Mapping(source="exchQuote", target = "EXCHQUOTE"),
		@Mapping(source="calculatedAmt", target = "CALCULATEDAMT")
	})
	public XPSTRANCHARGEDETAILAPIType mapToApi(ChargeFixedJpe jpe, @MappingTarget XPSTRANCHARGEDETAILAPIType api);

	@InheritInverseConfiguration(name = "mapToApi")
	public ChargeFixedJpe mapToJpe(XPSTRANCHARGEDETAILAPIType api, @MappingTarget ChargeFixedJpe jpe);
}