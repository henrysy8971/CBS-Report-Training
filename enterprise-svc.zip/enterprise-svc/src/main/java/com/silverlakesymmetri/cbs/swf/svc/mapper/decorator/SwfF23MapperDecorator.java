package com.silverlakesymmetri.cbs.swf.svc.mapper.decorator;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

import com.silverlakesymmetri.cbs.swf.jpa.mapping.sdo.SwfF23Jpe;
import com.silverlakesymmetri.cbs.swf.svc.mapper.mapping.SwfF23Mapper;
import com.silverlakesymmetri.cbs.swf.xmlapi.SWFF23TYPEType;

public abstract class SwfF23MapperDecorator implements SwfF23Mapper {
	
	@Autowired
	@Qualifier("delegate")
	protected SwfF23Mapper delegate;

	@Override
	public SWFF23TYPEType mapToApi(SwfF23Jpe jpe){
		SWFF23TYPEType swfF23 = delegate.mapToApi(jpe);
		if(swfF23 != null && swfF23.getCODE() == null && swfF23.getDETAILS() == null && swfF23.getREFERENCE() == null){
			return null;
		}
		return swfF23;
	}
	
	@Override
	public SwfF23Jpe mapToJpe(SWFF23TYPEType api){
		return delegate.mapToJpe(api);
	}
	
}
