package com.silverlakesymmetri.cbs.swf.svc.mapper.mapping;

import org.apache.commons.lang3.StringUtils;
import org.mapstruct.DecoratedWith;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Mappings;

import com.silverlakesymmetri.cbs.swf.jpa.mapping.sdo.SwfF74Jpe;
import com.silverlakesymmetri.cbs.swf.svc.mapper.decorator.SwfF74MapperDecorator;
import com.silverlakesymmetri.cbs.swf.xmlapi.SWFF74TYPEType;

@Mapper(imports=StringUtils.class, uses = SwfF74NarrativeMapper.class)
@DecoratedWith(SwfF74MapperDecorator.class)
public interface SwfF74Mapper {
	@Mappings({
		@Mapping(source="opt", target="OPT"),
		@Mapping(source="swfF74NarrativeList", target="DETAILS.SWFF74NARRATIVETYPE")
	})
	SWFF74TYPEType mapToApi(SwfF74Jpe jpe);
	
	@Mappings({
		@Mapping(target="opt", expression="java(StringUtils.isNotBlank(api.getOPT())?api.getOPT():null)"),
		@Mapping(target="swfF74NarrativeList", source="DETAILS.SWFF74NARRATIVETYPE")
	})
	SwfF74Jpe mapToJpe(SWFF74TYPEType api);
}