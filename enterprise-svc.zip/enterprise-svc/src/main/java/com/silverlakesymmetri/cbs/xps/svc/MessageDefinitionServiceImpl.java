package com.silverlakesymmetri.cbs.xps.svc;

import com.mysema.query.types.EntityPath;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.jpa.entity.FindCriteriaJpe;
import com.silverlakesymmetri.cbs.commons.svc.AbstractBusinessService;
import com.silverlakesymmetri.cbs.commons.svc.BusinessObjectValidationCapable;
import com.silverlakesymmetri.cbs.xps.bdo.sdo.MessageDefinition;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.MessageDefinitionJpe;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.QMessageDefinitionJpe;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.id.MessageDefinitionPk;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Map;

@Service
@Transactional
public class MessageDefinitionServiceImpl extends AbstractBusinessService<MessageDefinition, MessageDefinitionJpe, MessageDefinitionPk>
        implements MessageDefinitionService, BusinessObjectValidationCapable<MessageDefinition> {

    @Override
    protected MessageDefinitionPk getIdFromDataObjectInstance(MessageDefinition dataObject) {
    	MessageDefinitionPk key = new MessageDefinitionPk(dataObject.getDomain(), dataObject.getFormat());
        return key;
    }

    @Override
    protected EntityPath<MessageDefinitionJpe> getEntityPath() {
        return QMessageDefinitionJpe.messageDefinitionJpe;
    }

    @Override
    public MessageDefinition get(MessageDefinition objectInstanceIdentifier) {
        return super.get(objectInstanceIdentifier);
    }

    @Override
    public List<MessageDefinition> query(int offset, int resultLimit, String groupBy, String order,
                                    Map<String, Object> filters) {
        return super.query(offset, resultLimit, groupBy, order, filters);
    }

    @Override
    public List<MessageDefinition> find(FindCriteria findCriteria, CbsHeader cbsHeader) {
        return super.find(findCriteria, cbsHeader);
    }

    @Override
    public Long count(FindCriteria findCriteria, CbsHeader cbsHeader) {
        if (findCriteria == null) {
            return dataService.getRowCount(this.getEntityPath());
        } else {
            FindCriteriaJpe fc = jaxbSdoHelper.unwrap(findCriteria);
            return dataService.getRowCount(MessageDefinitionJpe.class, fc);
        }
    }

    @Override
    public MessageDefinition getByPk(String publicKey, MessageDefinition reference) {
        return super.getByPk(publicKey, reference);
    }

    @Override
    public MessageDefinition update(MessageDefinition dataObject) {
        return super.update(dataObject);
    }

}
