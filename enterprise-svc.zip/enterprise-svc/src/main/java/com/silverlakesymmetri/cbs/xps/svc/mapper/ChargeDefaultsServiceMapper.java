package com.silverlakesymmetri.cbs.xps.svc.mapper;

import org.mapstruct.Context;
import org.mapstruct.DecoratedWith;
import org.mapstruct.InheritInverseConfiguration;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingTarget;
import org.mapstruct.Mappings;

import com.silverlakesymmetri.cbs.commons.jpa.util.DateTimeHelper;
import com.silverlakesymmetri.cbs.commons.xmlapi.enums.CbsXmlApiOperation;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.ChargeMasterJpe;
import com.silverlakesymmetri.cbs.xps.svc.mapper.decorator.ChargeDefaultsServiceDecorator;
import com.silverlakesymmetri.cbs.xps.xmlapi.XPSCHARGEGETPRODDEFAULTDETAILSAPIType;

@Mapper(uses = { DateTimeHelper.class, ChargeEventInfoMapper.class, ChargeInstrumentInfoMapper.class })
@DecoratedWith(ChargeDefaultsServiceDecorator.class)
public interface ChargeDefaultsServiceMapper {

	@Mappings({
		@Mapping(source="domain", target = "DOMAIN"),
		@Mapping(source="ccy", target = "CCY"),
		@Mapping(source="partyCharged", target = "PARTYCHARGE"),
		@Mapping(source="partyClientId", target = "PARTYCLIENTID"),
		@Mapping(source="bookBranch", target = "BRANCH"),
		@Mapping(source="chargeInstrumentInfoStructRec", target = "INSTRUMENT"),
		@Mapping(source="chargeEventInfoStructRec", target = "EVENT"),
		@Mapping(source="valueDate", target = "VALUEDATE", qualifiedByName = {"DateTimeHelper", "convertDateToCbsXmlApiDate"}),
		@Mapping(source="prodRateType", target = "RATETYPE")
	})
	public XPSCHARGEGETPRODDEFAULTDETAILSAPIType mapToApi(ChargeMasterJpe jpe, @Context CbsXmlApiOperation oper);

	@InheritInverseConfiguration(name = "mapToApi")
	@Mappings({
		@Mapping(source="VALUEDATE", target="valueDate", qualifiedByName = {"DateTimeHelper", "convertCbsApiDateToString"})
	})
	public ChargeMasterJpe mapToJpe(XPSCHARGEGETPRODDEFAULTDETAILSAPIType api, @MappingTarget ChargeMasterJpe jpe);
}