package com.silverlakesymmetri.cbs.xps.svc.impl;

import com.mysema.query.types.EntityPath;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.jpa.util.DateTimeHelper;
import com.silverlakesymmetri.cbs.commons.svc.AbstractBusinessService;
import com.silverlakesymmetri.cbs.commons.svc.BusinessObjectValidationCapable;
import com.silverlakesymmetri.cbs.commons.svc.ref.ReferenceNumberGeneratorService;
import com.silverlakesymmetri.cbs.xps.bdo.sdo.SapGlCode;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.QSapGlCodeJpe;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.SapGlCodeJpe;
import com.silverlakesymmetri.cbs.xps.svc.SapGlCodeService;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Map;

@Service
@Transactional
public class SapGlCodeServiceImpl extends AbstractBusinessService<SapGlCode, SapGlCodeJpe, String>
        implements SapGlCodeService, BusinessObjectValidationCapable<SapGlCode> {


    @Autowired
    private ReferenceNumberGeneratorService referenceNumberGeneratorService;

    @Autowired
    private DateTimeHelper dateTimeHelper;

    @Override
    protected String getIdFromDataObjectInstance(SapGlCode dataObject) {
        return dataObject.getGlCodeMapRefNo();
    }

    @Override
    protected EntityPath<SapGlCodeJpe> getEntityPath() {
        return QSapGlCodeJpe.sapGlCodeJpe;
    }

    @Override
    protected SapGlCode preCreateValidation(SapGlCode dataObject) {

        setDefaults(dataObject);
        return super.preCreateValidation(dataObject);
    }

    private void setDefaults(SapGlCode dataObject) {
    	if(StringUtils.isBlank(dataObject.getGlCodeMapRefNo())){    		
    		referenceNumberGeneratorService.getNewRefNo(dataObject, "glCodeMapRefNo");
    	}
        if (dataObject.getEffectDateFrom() == null || dataObject.getEffectDateFrom().isEmpty()) {
            String runDate = dateTimeHelper.getSDODateTime(dateTimeHelper.getRunDate());
            dataObject.setEffectDateFrom(runDate);
        }
    }

    @Override
    public SapGlCode create(SapGlCode dataObject) {

        return super.create(dataObject);
    }

    @Override
    public SapGlCode get(SapGlCode objectInstanceIdentifier) {
        return super.get(objectInstanceIdentifier);
    }

    @Override
    public List<SapGlCode> query(int offset, int resultLimit, String groupBy, String order,
                                 Map<String, Object> filters) {
        return super.query(offset, resultLimit, groupBy, order, filters);
    }

    @Override
    public SapGlCode update(SapGlCode dataObject) {
        return super.update(dataObject);
    }

    @Override
    public boolean delete(SapGlCode dataObject) {
        return super.delete(dataObject);
    }

    @Override
    public List<SapGlCode> find(FindCriteria findCriteria, CbsHeader cbsHeader) {
        return super.find(findCriteria, cbsHeader);
    }

    @Override
    public SapGlCode getByPk(String publicKey, SapGlCode reference) {
        return super.getByPk(publicKey, reference);
    }

}
