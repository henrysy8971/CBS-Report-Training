package com.silverlakesymmetri.cbs.xps.svc;

import java.util.List;
import java.util.Map;

import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation;
import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation.ServiceOperationType;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.svc.BusinessService;
import com.silverlakesymmetri.cbs.xps.bdo.sdo.MarginAmendment;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.MarginAmendmentJpe;

public interface MarginAmendmentService extends BusinessService<MarginAmendment, MarginAmendmentJpe> {
	public static final String XPS_MARGINAMENDMENTSERVICE_GET = "MarginAmendmentService.get";
	public static final String XPS_MARGINAMENDMENTSERVICE_QUERY = "MarginAmendmentService.query";
	public static final String XPS_MARGINAMENDMENTSERVICE_FIND = "MarginAmendmentService.find";
	public static final String XPS_MARGINAMENDMENTSERVICE_CREATE = "MarginAmendmentService.create";
	public static final String XPS_MARGINAMENDMENTSERVICE_UPDATE = "MarginAmendmentService.update";
	public static final String XPS_MARGINAMENDMENTSERVICE_DELETE = "MarginAmendmentService.delete";
	public static final String XPS_MARGINAMENDMENTSERVICE_COUNT = "MarginAmendmentService.count";
	
	@ServiceOperation(name = XPS_MARGINAMENDMENTSERVICE_GET, type = ServiceOperationType.GET)
    public MarginAmendment getByPk(String publicKey, MarginAmendment reference);

    @ServiceOperation(name = XPS_MARGINAMENDMENTSERVICE_QUERY)
    public List<MarginAmendment> query(int offset, int resultLimit, String groupBy, String order, Map<String, Object> filters);
    
    @ServiceOperation(name = XPS_MARGINAMENDMENTSERVICE_FIND)
    public List<MarginAmendment> find(FindCriteria findCriteria, CbsHeader cbsHeader);
    
    @ServiceOperation(name = XPS_MARGINAMENDMENTSERVICE_COUNT, type = ServiceOperationType.GET)
    public Long count(FindCriteria findCriteria, CbsHeader cbsHeader);
    
    @ServiceOperation(name = XPS_MARGINAMENDMENTSERVICE_CREATE)
    public MarginAmendment create(MarginAmendment dataObject);

    @ServiceOperation(name = XPS_MARGINAMENDMENTSERVICE_UPDATE)
    public MarginAmendment update(MarginAmendment dataObject);

    @ServiceOperation(name = XPS_MARGINAMENDMENTSERVICE_DELETE)
    public boolean delete(MarginAmendment dataObject);
}
