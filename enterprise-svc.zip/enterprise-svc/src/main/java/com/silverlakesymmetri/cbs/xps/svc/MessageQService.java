package com.silverlakesymmetri.cbs.xps.svc;

import java.util.List;
import java.util.Map;

import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation;
import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation.ServiceOperationType;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.bdo.sdo.DmsFile;
import com.silverlakesymmetri.cbs.commons.context.CbsSessionContext;
import com.silverlakesymmetri.cbs.commons.svc.BusinessService;
import com.silverlakesymmetri.cbs.xps.bdo.sdo.AdvicePreview;
import com.silverlakesymmetri.cbs.xps.bdo.sdo.MessageQ;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.MessageQJpe;

/**
*
*  Service is used to Read, Create, Update, Delete MessageQ data.
*
* @author      rvo
* @since       2019-09-13
*/
public interface MessageQService extends BusinessService<MessageQ, MessageQJpe> {

    public static final String SVC_OP_NAME_MESSAGEQSERVICE_GET = "MessageQService.get";
    public static final String SVC_OP_NAME_MESSAGEQSERVICE_QUERY = "MessageQService.query";
    public static final String SVC_OP_NAME_MESSAGEQSERVICE_CREATE = "MessageQService.create";
    public static final String SVC_OP_NAME_MESSAGEQSERVICE_UPDATE = "MessageQService.update";
    public static final String SVC_OP_NAME_MESSAGEQSERVICE_DELETE = "MessageQService.delete";
    public static final String SVC_OP_NAME_MESSAGEQSERVICE_FIND = "MessageQService.find";
    
    @ServiceOperation(name = SVC_OP_NAME_MESSAGEQSERVICE_GET, type = ServiceOperationType.GET)
    public MessageQ getByPk(String publicKey, MessageQ reference);

    @ServiceOperation(name = SVC_OP_NAME_MESSAGEQSERVICE_CREATE)
    public MessageQ create(MessageQ dataObject);

    @ServiceOperation(name = SVC_OP_NAME_MESSAGEQSERVICE_UPDATE)
    public MessageQ update(MessageQ dataObject);

    @ServiceOperation(name = SVC_OP_NAME_MESSAGEQSERVICE_DELETE)
    public boolean delete(MessageQ dataObject);

    @ServiceOperation(name = SVC_OP_NAME_MESSAGEQSERVICE_QUERY)
    public List<MessageQ> query(int offset, int resultLimit, String groupBy, String order, Map<String, Object> filters);

    @ServiceOperation(name = SVC_OP_NAME_MESSAGEQSERVICE_FIND)
    public List<MessageQ> find(FindCriteria findCriteria, CbsHeader cbsHeader);
    
    public MessageQ createMessageQueueEntry(AdvicePreview advice, DmsFile file, String domain, Long tranInternalKey, String refNo, String eventType, String tranDate, String route, String branch, String sourceType, Long seqNo, String destination, String errorMsg);
    
    public MessageQ createMessageQueueEntry(AdvicePreview advice, DmsFile file, String domain, Long tranInternalKey, String refNo, String eventType, String tranDate, String route, String branch, String sourceType, Long seqNo, String destination, String sender, String errorMsg);

    public MessageQJpe updateMessageQueueEntry(AdvicePreview advice, DmsFile file, MessageQJpe messageQueue);

	public MessageQ createMessageQueueEntry(AdvicePreview advice, DmsFile file, String domain, Long tranInternalKey, String refNo, String eventType, 
			String tranDate, String route, String branch, String sourceType, Long seqNo, String destination, String errorMsg, CbsSessionContext sessionCtx);

	public MessageQ createMessageQueueEntry(AdvicePreview advice, DmsFile file, String domain, Long tranInternalKey, String refNo, String eventType, 
			String tranDate, String route, String branch, String sourceType, Long seqNo, String destination, String sender, String errorMsg, CbsSessionContext sessionCtx);

}
