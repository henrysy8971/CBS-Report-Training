package com.silverlakesymmetri.cbs.xps.svc;

import java.util.Map;

import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation;
import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation.ServiceOperationType;
import com.silverlakesymmetri.cbs.commons.bdo.sdo.DmsFile;
import com.silverlakesymmetri.cbs.commons.svc.BusinessService;
import com.silverlakesymmetri.cbs.xps.bdo.sdo.AdvicePreview;
import com.silverlakesymmetri.cbs.xps.bdo.sdo.MarginAmendmentWithSettlement;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.MarginAmendmentWithSettlementJpe;

public interface MarginAmendmentWithSettlementService extends BusinessService<MarginAmendmentWithSettlement, MarginAmendmentWithSettlementJpe> {
	public static final String XPS_MARGINAMENDMENTWITHSETTLEMENTSERVICE_GET = "MarginAmendmentWithSettlementService.get";
	public static final String XPS_MARGINAMENDMENTWITHSETTLEMENTSERVICE_CREATE = "MarginAmendmentWithSettlementService.create";
	public static final String XPS_MARGINAMENDMENTWITHSETTLEMENTSERVICE_UPDATE = "MarginAmendmentWithSettlementService.update";
	public static final String XPS_MARGINAMENDMENTWITHSETTLEMENTSERVICE_DELETE = "MarginAmendmentWithSettlementService.delete";
	public static final String SVC_OP_NAME_MARGINAMENDMENTWITHSETTLEMENTSERVICE_SWFMSG = "MarginAmendmentWithSettlementService.generateSwfMessage";
	public static final String SVC_OP_NAME_MARGINAMENDMENTWITHSETTLEMENTSERVICE_EMAILPREVIEW = "MarginAmendmentWithSettlementService.generateEmailPreview";
	public static final String SVC_OP_NAME_MARGINAMENDMENTWITHSETTLEMENTSERVICE_GENADVIC = "MarginAmendmentWithSettlementService.generateAdvice";
	public static final String SVC_OP_NAME_MARGINAMENDMENTWITHSETTLEMENTSERVICE_GETATTACHED = "MarginAmendmentWithSettlementService.getAttachedMarginAmendmentWithSettlement";

	@ServiceOperation(name = XPS_MARGINAMENDMENTWITHSETTLEMENTSERVICE_GET, type = ServiceOperationType.GET)
    public MarginAmendmentWithSettlement getByPk(String publicKey, MarginAmendmentWithSettlement reference);
    
    @ServiceOperation(name = XPS_MARGINAMENDMENTWITHSETTLEMENTSERVICE_CREATE)
    public MarginAmendmentWithSettlement create(MarginAmendmentWithSettlement dataObject);

    @ServiceOperation(name = XPS_MARGINAMENDMENTWITHSETTLEMENTSERVICE_UPDATE)
    public MarginAmendmentWithSettlement update(MarginAmendmentWithSettlement dataObject);

    @ServiceOperation(name = XPS_MARGINAMENDMENTWITHSETTLEMENTSERVICE_DELETE)
    public boolean delete(MarginAmendmentWithSettlement dataObject);

    @ServiceOperation(name = SVC_OP_NAME_MARGINAMENDMENTWITHSETTLEMENTSERVICE_SWFMSG, passParamAsMap = true)
    public String generateSwfMessage(Map<String, Object> params);
    
    @ServiceOperation(name = SVC_OP_NAME_MARGINAMENDMENTWITHSETTLEMENTSERVICE_EMAILPREVIEW, passParamAsMap = true)
    public AdvicePreview generateEmailPreview(Map<String, Object> params);
    
    @ServiceOperation(name = SVC_OP_NAME_MARGINAMENDMENTWITHSETTLEMENTSERVICE_GENADVIC, passParamAsMap = true)
    public DmsFile generateAdvice(Map<String, Object> params);
    
    @ServiceOperation(name = SVC_OP_NAME_MARGINAMENDMENTWITHSETTLEMENTSERVICE_GETATTACHED, passParamAsMap = true)
    public MarginAmendmentWithSettlement getAttachedMarginAmendmentWithSettlement(Map<String, Object> params);
    
}
