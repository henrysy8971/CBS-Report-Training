package com.silverlakesymmetri.cbs.xps.svc.mapper;

import org.mapstruct.Context;
import org.mapstruct.DecoratedWith;
import org.mapstruct.InheritInverseConfiguration;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingTarget;
import org.mapstruct.Mappings;

import com.silverlakesymmetri.cbs.commons.jpa.util.DateTimeHelper;
import com.silverlakesymmetri.cbs.commons.xmlapi.enums.CbsXmlApiOperation;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.MarginWithSettlementJpe;
import com.silverlakesymmetri.cbs.xps.svc.mapper.decorator.MarginWithSettlementServiceDecorator;
import com.silverlakesymmetri.cbs.xps.xmlapi.XPSTRANMARGINWITHSETTLEAPIType;

@Mapper(uses={ DateTimeHelper.class, MarginSettlementServiceMapper.class })
@DecoratedWith(MarginWithSettlementServiceDecorator.class)
public interface MarginWithSettlementServiceMapper {

	@Mappings({
		@Mapping(expression = "java(oper != null ? oper.getOperation() : null)", target="OPERATION"),
		@Mapping(source="marginStructRec.domain", target = "DOMAIN"),
		@Mapping(source="marginStructRec.internalKey", target = "INTERNALKEY"),
		@Mapping(source="marginStructRec.tranKey", target = "TRANKEY"),
		@Mapping(source="marginStructRec.seqNo", target = "SEQNO"),
		@Mapping(source="marginStructRec.valueDate", target = "VALUEDATE", qualifiedByName = {"DateTimeHelper", "convertDateToCbsXmlApiDate"}),
		@Mapping(source="marginStructRec.tranStatus", target = "TRANSTATUS"),
		@Mapping(source="marginStructRec.ccy", target = "CCY"),
		@Mapping(source="marginStructRec.amount", target = "AMOUNT"),
		@Mapping(source="marginStructRec.baseRate", target = "BASERATE"),
		@Mapping(source="marginStructRec.baseQuote", target = "BASEQUOTE"),
		@Mapping(source="marginStructRec.baseEquiv", target = "BASEEQUIV"),
		@Mapping(source="marginStructRec.localRate", target = "LOCALRATE"),
		@Mapping(source="marginStructRec.localQuote", target = "LOCALQUOTE"),
		@Mapping(source="marginStructRec.localEquiv", target = "LOCALEQUIV"),
		@Mapping(source="marginStructRec.forwardCoverAvail", target = "FORWARDCOVERAVAIL"),
		@Mapping(source="marginStructRec.percentage", target = "PERCENTAGE"),
		@Mapping(source="marginStructRec.instrumentType", target = "INSTRUMENTTYPE"),
		@Mapping(source="marginStructRec.tranCcy", target = "TRANCCY"),
		@Mapping(source="marginStructRec.tranEquivAmt", target = "TRANEQUIVAMT"),
		@Mapping(source="marginStructRec.exchRate", target = "EXCHRATE"),
		@Mapping(source="marginStructRec.exchQuote", target = "EXCHQUOTE"),
		@Mapping(source="settlementStructRec", target = "SETTLEMENT")
	})
	public XPSTRANMARGINWITHSETTLEAPIType mapToApi(MarginWithSettlementJpe jpe, @Context CbsXmlApiOperation oper);

	@InheritInverseConfiguration(name = "mapToApi")
	@Mappings({
		@Mapping(source="VALUEDATE", target="marginStructRec.valueDate", qualifiedByName = {"DateTimeHelper", "convertCbsApiDateToString"})
	})
	public MarginWithSettlementJpe mapToJpe(XPSTRANMARGINWITHSETTLEAPIType api, @MappingTarget MarginWithSettlementJpe jpe);

	@InheritInverseConfiguration(name = "mapToApi")
	@Mappings({
		@Mapping(source="VALUEDATE", target="marginStructRec.valueDate", qualifiedByName = {"DateTimeHelper", "convertCbsApiDateToString"})
	})
	public MarginWithSettlementJpe mapToJpe(XPSTRANMARGINWITHSETTLEAPIType api);
}