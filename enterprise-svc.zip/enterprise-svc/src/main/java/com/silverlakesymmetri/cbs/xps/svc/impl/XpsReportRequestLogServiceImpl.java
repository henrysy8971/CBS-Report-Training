package com.silverlakesymmetri.cbs.xps.svc.impl;

import java.io.IOException;
import java.io.InputStream;
import java.util.*;

import com.silverlakesymmetri.cbs.commons.constants.ReportConstants;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.mysema.query.types.EntityPath;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.bdo.sdo.ReportRequestLog;
import com.silverlakesymmetri.cbs.commons.context.CbsSessionContext;
import com.silverlakesymmetri.cbs.commons.exception.base.CbsServiceException;
import com.silverlakesymmetri.cbs.commons.jpa.mapping.sdo.QReportRequestLogJpe;
import com.silverlakesymmetri.cbs.commons.jpa.mapping.sdo.RegistryJpe;
import com.silverlakesymmetri.cbs.commons.jpa.mapping.sdo.ReportRequestLogJpe;
import com.silverlakesymmetri.cbs.commons.jpa.mapping.sdo.id.ReportRequestLogPk;
import com.silverlakesymmetri.cbs.commons.svc.AbstractReportRequestLogService;
import com.silverlakesymmetri.cbs.xps.svc.XpsReportRequestLogService;

import net.sf.jasperreports.engine.JRException;

@Service
@Transactional
public class XpsReportRequestLogServiceImpl extends AbstractReportRequestLogService<ReportRequestLog, ReportRequestLogJpe, ReportRequestLogPk> implements XpsReportRequestLogService {


	@Override
	protected ReportRequestLogPk getIdFromDataObjectInstance(ReportRequestLog dataObject) {
		ReportRequestLogPk id = new ReportRequestLogPk(dataObject.getReportId(), dataObject.getRequestedBy(), dateHelper.getDate(dataObject.getRequestDate()));
		return id;
	}

	@Override
	protected EntityPath<ReportRequestLogJpe> getEntityPath() {
		return QReportRequestLogJpe.reportRequestLogJpe;
	}

	@Override
    public ReportRequestLog getByPk(String publicKey, ReportRequestLog reference) {
    	return super.getByPk(publicKey, reference);
    }

	@Override
    public ReportRequestLog create(ReportRequestLog dataObject) {
		return super.create(dataObject);
    }

	@Override
    public ReportRequestLog update(ReportRequestLog dataObject) {
		return super.update(dataObject);
    }

	@Override
    public boolean delete(ReportRequestLog dataObject) {
		return super.delete(dataObject);
    }

	@Override
    public List<ReportRequestLog> query(int offset, int resultLimit, String groupBy, String order, Map<String, Object> filters){
		return super.query(offset, resultLimit, groupBy, order, filters);
    }

	@Override
    public List<ReportRequestLog> find(FindCriteria findCriteria, CbsHeader cbsHeader){
		return super.find(findCriteria, cbsHeader);
    }

	@Override
    public InputStream getReportStream(String screenPath) {
    	return getClass().getClassLoader().getResourceAsStream(screenPath);
    }
	
	@Override
	public void addModuleRelatedParameters(Map<String, Object> reportParams) {
		Map<String, RegistryJpe> registries = registryService.getMapByMetaCodeModuleCode("CSD", "CORE_REGISTRY");
		if(registries != null && registries.size() > 0) {
			RegistryJpe reg = registries.get("localCcy");
			if(reg != null) {
				reportParams.put(ReportConstants.LOCAL_CCY, reg.getValue());
			}
			reg = registries.get("ccyBase");
			if(reg != null) {
				reportParams.put(ReportConstants.BASE_CCY, reg.getValue());
			}
		}

        Locale locale = (Locale) reportParams.get(ReportConstants.REPORT_LOCALE);
        ResourceBundle bundle = ResourceBundle.getBundle(ReportConstants.XPS_RESOURCE_BUNDLE_LOCATION, locale);
        if(Boolean.TRUE.equals(reportParams.get("isIslamicUserSession")) && sessionCtx.isIslamicConfigOn()){
			bundle = ResourceBundle.getBundle(ReportConstants.XPS_ISL_RESOURCE_BUNDLE_LOCATION, locale);
		}
		reportParams.put(ReportConstants.REPORT_RESOURCE_BUNDLE, bundle);
	}

	@Override
	public String getModuleCode() {
		return "XPS";
	}

	@Override
	public ReportRequestLog start(Map<String, Object> params) {
		return super.start(params);
	}

	@Override
	public ReportRequestLog createRequest(Map<String, Object> params) {
		return super.generate(params);
	}

}
