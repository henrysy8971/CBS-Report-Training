package com.silverlakesymmetri.cbs.xps.svc.batch.listener;

import org.springframework.batch.core.SkipListener;

import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.MessageQJpe;

public class MessageQueueSendSkipListener extends AbstractMessageQueueSkipListener<MessageQJpe, MessageQJpe>
		implements SkipListener<MessageQJpe, MessageQJpe> {

	@Override
	protected void updateStatusToFailed(MessageQJpe item, Throwable t) {
		super.updateStatusToFailed(item, t);
	}

}
