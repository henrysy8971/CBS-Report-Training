package com.silverlakesymmetri.cbs.swf.svc.mapper.decorator;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

import com.silverlakesymmetri.cbs.swf.jpa.mapping.sdo.SwfF72Jpe;
import com.silverlakesymmetri.cbs.swf.svc.mapper.mapping.SwfF72Mapper;
import com.silverlakesymmetri.cbs.swf.xmlapi.SWFF72TYPEType;

public abstract class SwfF72MapperDecorator implements SwfF72Mapper {
	
	@Autowired
	@Qualifier("delegate")
	protected SwfF72Mapper delegate;

	@Override
	public SWFF72TYPEType mapToApi(SwfF72Jpe jpe){
		SWFF72TYPEType swfF72 = delegate.mapToApi(jpe);
		if(swfF72 != null){
			if(swfF72.getDETAILS() == null || swfF72.getDETAILS().getSWFSNDRRCVRNARRATIVETYPE() == null || swfF72.getDETAILS().getSWFSNDRRCVRNARRATIVETYPE().size() == 0){
				return null;
			}
		}
		return swfF72;
	}
	
	@Override
	public SwfF72Jpe mapToJpe(SWFF72TYPEType api){
		return delegate.mapToJpe(api);
	}
	
}
