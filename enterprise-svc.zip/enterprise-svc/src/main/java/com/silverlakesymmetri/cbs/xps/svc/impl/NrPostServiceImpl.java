package com.silverlakesymmetri.cbs.xps.svc.impl;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.mysema.query.types.EntityPath;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.bdo.ViewCriteriaItem;
import com.silverlakesymmetri.cbs.commons.bdo.ViewCriteriaRow;
import com.silverlakesymmetri.cbs.commons.jpa.entity.FindCriteriaJpe;
import com.silverlakesymmetri.cbs.commons.jpa.entity.ViewCriteriaItemJpe;
import com.silverlakesymmetri.cbs.commons.jpa.entity.ViewCriteriaRowJpe;
import com.silverlakesymmetri.cbs.commons.logging.CbsAppLogger;
import com.silverlakesymmetri.cbs.commons.logging.CbsAppLoggerFactory;
import com.silverlakesymmetri.cbs.commons.svc.AbstractBusinessService;
import com.silverlakesymmetri.cbs.commons.svc.BusinessObjectValidationCapable;
import com.silverlakesymmetri.cbs.xps.bdo.sdo.NrPost;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.NrPostJpe;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.QNrPostJpe;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.id.NrPostPk;
import com.silverlakesymmetri.cbs.xps.svc.NrPostService;

@Service
@Transactional
public class NrPostServiceImpl extends AbstractBusinessService<NrPost, NrPostJpe, NrPostPk> implements NrPostService, BusinessObjectValidationCapable<NrPost> {

	private static final String ATTR_ACCTNO = "acctNo";
	private static final String ATTR_ACCTINTERNALKEY = "acctInternalKey";
	private static final String ATTR_VALUEDATEFROM = "valueDateFrom";
	private static final String ATTR_VALUEDATETO = "valueDateTo";
	private static final String ATTR_POSTDATEFROM = "postDateFrom";
	private static final String ATTR_POSTDATETO = "postDateTo";
	private static final String ATTR_CCY = "ccy";
	private static final String ATTR_MATCH_TYPE = "matchType";
	private static final String MATCH_TYPE_ALL = "L";
	private static final String MATCH_TYPE_UNMATCHED = "U";
	private static final String NULL = "null";

	private static final CbsAppLogger LOGGER = CbsAppLoggerFactory.getLogger(NrPostServiceImpl.class); 
	
	@Override
	protected NrPostPk getIdFromDataObjectInstance(NrPost dataObject) {
		NrPostJpe jpe = jaxbSdoHelper.unwrap(dataObject);
		return new NrPostPk(jpe.getInternalKey());
	}

	@Override
	protected EntityPath<NrPostJpe> getEntityPath() {
		return QNrPostJpe.nrPostJpe;
	}

	@Override
	public NrPost getByPk(String publicKey, NrPost reference) {
		NrPost bdo = super.getByPk(publicKey, reference);
		return bdo;
	}

	@Override
	public List<NrPost> query(int offset, int resultLimit, String groupBy, String order, Map<String, Object> filters) {
		return super.query(offset, resultLimit, groupBy, order, filters);
	}
	
	@Override
	public List<NrPost> find(FindCriteria fc, CbsHeader cbsHeader){
		String vdFields = "valueDateFrom|valueDateTo";
		String pdFields = "postDateFrom|postDateTo";
		boolean hasRange = false;

		if(fc.getFilter() != null && fc.getFilter().getGroup() != null){
			for(ViewCriteriaRow vcr:fc.getFilter().getGroup()){
				for(ViewCriteriaItem vci: vcr.getItem()){
					if(vdFields.contains(vci.getAttribute()) || pdFields.contains(vci.getAttribute())){
						hasRange = true;
						break;
					}
				}
			}
		}

		if(hasRange){
			return getInternalList(fc);
		}else{			
			return super.find(fc, cbsHeader);
		}
	}

	@Override
	public NrPost create(NrPost dataObject) {
		return super.create(dataObject);
	}

	@Override
	public NrPost update(NrPost dataObject) {
		return super.update(dataObject);
	}
	
	@Override
	public boolean delete(NrPost dataObject) {
		return super.delete(dataObject);
	}
	
	private List<NrPost> getInternalList(FindCriteria fc) {
		FindCriteriaJpe fcJpe = jaxbSdoHelper.unwrap(fc);
		
		String acctNo = null;
		Date valueDateFrom = null;
		Date valueDateTo = null;
		Date postDateFrom = null;
		Date postDateTo = null;
		String ccy = null;
		String matchType = null;

		if(fcJpe.getFilter() != null && fcJpe.getFilter().getGroup() != null){
			for(ViewCriteriaRowJpe vcr:fcJpe.getFilter().getGroup()){
				for (ViewCriteriaItemJpe vci : vcr.getItem()) {
					if (ATTR_ACCTNO.equals(vci.getAttribute())) {
						acctNo = (String) vci.getValue().get(0);
					}
					if (ATTR_VALUEDATEFROM.equals(vci.getAttribute())) {
						Date vdFrom = this.dateTimeHelper.getDate((String) vci.getValue().get(0));
						valueDateFrom = vdFrom;
					}
					if (ATTR_VALUEDATETO.equals(vci.getAttribute())) {
						Date vdTo = this.dateTimeHelper.getDate((String) vci.getValue().get(0));
						valueDateTo = vdTo;
					}
					if (ATTR_POSTDATEFROM.equals(vci.getAttribute())) {
						Date pdFrom = this.dateTimeHelper.getDate((String) vci.getValue().get(0));
						postDateFrom = pdFrom;
					}
					if (ATTR_POSTDATETO.equals(vci.getAttribute())) {
						Date pdTo = this.dateTimeHelper.getDate((String) vci.getValue().get(0));
						postDateTo = pdTo;
					}
					if (ATTR_CCY.equals(vci.getAttribute())) {
						ccy = (String) vci.getValue().get(0);
					}
					if (ATTR_MATCH_TYPE.equals(vci.getAttribute())) {
						matchType = (String) vci.getValue().get(0);
					}
				}
			}
		}
		
		Long acctInternalKey = getAcctInternalKey(acctNo);
		List<NrPost> retList = new ArrayList<>();

		if(acctInternalKey!=null){
			String sqlQuery = "SELECT e FROM NrPostJpe e WHERE e.acctInternalKey = :acctInternalKey AND e.ccy = :ccy";
			Map<String, Object> params = new HashMap<>();
			params.put(ATTR_ACCTINTERNALKEY, acctInternalKey);
			params.put(ATTR_CCY, ccy);
			if(valueDateFrom!=null && valueDateTo!=null){
				sqlQuery = sqlQuery + " AND e.valueDate BETWEEN :valueDateFrom AND :valueDateTo";
				params.put(ATTR_VALUEDATEFROM, valueDateFrom);
				params.put(ATTR_VALUEDATETO, valueDateTo);
			}
			if(postDateFrom!=null && postDateTo!=null){
				sqlQuery = sqlQuery + " AND e.postDate BETWEEN :postDateFrom AND :postDateTo";
				params.put(ATTR_POSTDATEFROM, postDateFrom);
				params.put(ATTR_POSTDATETO, postDateTo);
			}
			if(StringUtils.isNotBlank(matchType)){
				if(matchType.equalsIgnoreCase(NULL)){
					sqlQuery = sqlQuery + " AND e.matchType IS NULL";
				}else if(!matchType.equals(MATCH_TYPE_ALL)){
					sqlQuery = sqlQuery + " AND e.matchType = :matchType";
					params.put(ATTR_MATCH_TYPE, matchType);
				}
			}
			
			List<NrPostJpe> jpeList = this.dataService.findWithQuery(sqlQuery, NrPostJpe.class, params, null);
			if(jpeList != null){
				for(NrPostJpe jpe: jpeList){
					retList.add(jaxbSdoHelper.wrap(jpe, NrPost.class));
				}
			}
		}
		
		return retList; 
	}
	
	private Long getAcctInternalKey(String acctNo){
		String qlString = "SELECT t.internalKey FROM GlAccountJpe t WHERE t.acctNo = :acctNo";
        Map<String, Object> params = new HashMap<String, Object>();
        params.put(ATTR_ACCTNO, acctNo);
        List<Long> keyList = null;
        try {
        	keyList = dataService.findWithQuery(qlString, Long.class, params, null);
		} catch (Exception e) {
			LOGGER.warn("Account Internal Key not retrieved for account:" + acctNo);
			e.printStackTrace();
		}
        
        if(keyList!=null && !keyList.isEmpty()){        	
        	return keyList.get(0);
        }
        
        return null;
	}
}