package com.silverlakesymmetri.cbs.swf.svc.mapper.decorator;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

import com.silverlakesymmetri.cbs.swf.jpa.mapping.sdo.SwfCustomerDetailsJpe;
import com.silverlakesymmetri.cbs.swf.svc.mapper.mapping.SwfCustomerDetailsMapper;
import com.silverlakesymmetri.cbs.swf.xmlapi.SWFCUSTOMERDETAILSTYPEType;

public abstract class SwfCustomerDetailsMapperDecorator implements SwfCustomerDetailsMapper {
	
	@Autowired
	@Qualifier("delegate")
	protected SwfCustomerDetailsMapper delegate;

	@Override
	public SWFCUSTOMERDETAILSTYPEType mapToApi(SwfCustomerDetailsJpe jpe){
		SWFCUSTOMERDETAILSTYPEType custDetails = delegate.mapToApi(jpe);
		if(custDetails != null) {
			if(custDetails.getADDITIONALINFO() == null && custDetails.getADDITIONALINFOCODE() == null && custDetails.getADDRESS() == null 
					&& custDetails.getBIRTHCOUNTRY() == null && custDetails.getBIRTHDATE() == null && custDetails.getBIRTHPLACE() == null 
					&& custDetails.getCOUNTRY() == null && custDetails.getCUSTOMERID() == null && custDetails.getCUSTOMERIDCOUNTRY() == null 
					&& custDetails.getCUSTOMERIDISSUER() == null && custDetails.getNAME() == null && custDetails.getNATIONALID() == null 
					&& custDetails.getNATIONALIDCOUNTRY() == null && custDetails.getPOSTALCODE() == null && custDetails.getSTATE() == null 
					&& custDetails.getTOWN() == null){
				return null;
			}
		}
		return custDetails;
	}
	
	@Override
	public SwfCustomerDetailsJpe mapToJpe(SWFCUSTOMERDETAILSTYPEType api){
		return delegate.mapToJpe(api);
	}
	
}
