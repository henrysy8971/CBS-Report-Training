package com.silverlakesymmetri.cbs.gla.svc.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Service;

import com.mysema.query.types.EntityPath;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.context.CbsSessionContext;
import com.silverlakesymmetri.cbs.commons.svc.AbstractBusinessService;
import com.silverlakesymmetri.cbs.gla.bdo.sdo.CashFlowDtlQry;
import com.silverlakesymmetri.cbs.gla.jpa.mapping.sdo.CashFlowDtlQryJpe;
import com.silverlakesymmetri.cbs.gla.jpa.mapping.sdo.QCashFlowDtlQryJpe;
import com.silverlakesymmetri.cbs.gla.jpa.mapping.sdo.id.CashFlowDtlQryPk;
import com.silverlakesymmetri.cbs.gla.jpa.mapping.sdo.util.GlaJpeConstants;
import com.silverlakesymmetri.cbs.gla.svc.CashFlowDtlsService;

@Service
public class CashFlowDtlsServiceImpl extends AbstractBusinessService<CashFlowDtlQry, CashFlowDtlQryJpe, CashFlowDtlQryPk> implements CashFlowDtlsService {

	@Override
	protected CashFlowDtlQryPk getIdFromDataObjectInstance(CashFlowDtlQry dataObject) {
		return new CashFlowDtlQryPk(dataObject.getRowId());
	}

	@Override
	protected EntityPath<CashFlowDtlQryJpe> getEntityPath() {
		return QCashFlowDtlQryJpe.cashFlowDtlQryJpe;
	}
	
	@Override
	public CashFlowDtlQry getByPk(String publicKey, CashFlowDtlQry reference) {
		return super.getByPk(publicKey, reference);
	}
	
	@Override
	public List<CashFlowDtlQry> query(int offset, int resultLimit, String groupBy, String order,
			Map<String, Object> filters) {
		return super.query(offset, resultLimit, groupBy, order, filters);
	}
	
	@Override
	public List<CashFlowDtlQry> find(FindCriteria findCriteria, CbsHeader cbsHeader) {
		return super.find(findCriteria, cbsHeader);
	}
	
	@Override
	public CashFlowDtlQry get(CashFlowDtlQry objectInstanceIdentifier) {
		return super.get(objectInstanceIdentifier);
	}
	
	@Override
	public List<CashFlowDtlQry> findNostroCashFlow(Map<String, Object> queryParams){
		long orgId = cbsRuntimeContextManager.getContext(CbsSessionContext.class).getOrgId();
		String branch = (String) queryParams.get("branch");
		String ccy = (String) queryParams.get("ccy");
		String nosVosNo = (String) queryParams.get("nosVosNo");
		int limit = queryParams.get("limit") != null ? Integer.parseInt((String)queryParams.get("limit")) : 10;
		int offset = queryParams.get("offset") != null ? Integer.parseInt((String)queryParams.get("offset")) : 0;
		
		List<CashFlowDtlQry> result = new ArrayList<CashFlowDtlQry>();
		final Map<String, Object> param = new HashMap<>();
		
		param.put("branch", branch);
		param.put("ccy", ccy);
		param.put("nosVosNo", nosVosNo);
		param.put("org_id", orgId);
		
		
		List<CashFlowDtlQryJpe> list = dataService.findWithNativeQuery(GlaJpeConstants.GLCASH_FLOW_DTL_JPE_FIND_PROJECTED_NOSTRO_BALANCE_QUERY, param, offset,  limit, CashFlowDtlQryJpe.class);
		
		if(!list.isEmpty() && list.size() > 0) {
			for (CashFlowDtlQryJpe jpe : list) {
				result.add(jaxbSdoHelper.wrap(jpe, CashFlowDtlQry.class));
			}
		}
		
		return result;
		
	}

}
