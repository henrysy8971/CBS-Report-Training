package com.silverlakesymmetri.cbs.lpm.svc.mapper.decorator;

import org.mapstruct.Context;
import org.mapstruct.MappingTarget;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

import com.silverlakesymmetri.cbs.commons.xmlapi.enums.CbsXmlApiOperation;
import com.silverlakesymmetri.cbs.lpm.jpa.mapping.sdo.DomesticClearingUaeFtsCb103Jpe;
import com.silverlakesymmetri.cbs.lpm.svc.mapper.DomesticClearingUaeFtsCb103ToLPMSETTLEAPITypeMapper;
import com.silverlakesymmetri.cbs.lpm.xmlapi.LPMSETTLEAPIType;

public abstract class DomesticClearingUaeFtsCb103MapperDecorator implements DomesticClearingUaeFtsCb103ToLPMSETTLEAPITypeMapper {
	
	@Autowired
	@Qualifier("delegate")
	protected DomesticClearingUaeFtsCb103ToLPMSETTLEAPITypeMapper delegate;

	@Override
	public LPMSETTLEAPIType mapToApi(DomesticClearingUaeFtsCb103Jpe jpe, @Context CbsXmlApiOperation oper){
		LPMSETTLEAPIType req = (LPMSETTLEAPIType) delegate.mapToApi(jpe, oper);
		return  req;
	}
	
	@Override
	public DomesticClearingUaeFtsCb103Jpe mapToJpe(LPMSETTLEAPIType api, @MappingTarget DomesticClearingUaeFtsCb103Jpe jpe){
		delegate.mapToJpe(api, jpe);
		return jpe;
	}

}


