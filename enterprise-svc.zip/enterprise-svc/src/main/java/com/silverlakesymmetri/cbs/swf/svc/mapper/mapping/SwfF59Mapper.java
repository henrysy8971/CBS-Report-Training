package com.silverlakesymmetri.cbs.swf.svc.mapper.mapping;

import org.apache.commons.lang3.StringUtils;
import org.mapstruct.DecoratedWith;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Mappings;

import com.silverlakesymmetri.cbs.swf.jpa.mapping.sdo.SwfNonFinEntityJpe;
import com.silverlakesymmetri.cbs.swf.svc.mapper.decorator.SwfF59MapperDecorator;
import com.silverlakesymmetri.cbs.swf.xmlapi.SWFF59TYPEType;

@Mapper(imports = StringUtils.class, uses = { SwiftMapperHelper.class, SwfAcctLineMapper.class, SwfCustomerIdMapper.class, SwfCustomerDetailsMapper.class })
@DecoratedWith(SwfF59MapperDecorator.class)
public interface SwfF59Mapper {
	@Mappings({
		@Mapping(source="opt", target="OPT", qualifiedByName = {"SwiftMapperHelper", "resolveFOption"}),
		@Mapping(source="swfAcctLineStructRec", target="ACCOUNT"),
		@Mapping(source="address", target="ADDRESS"),
		@Mapping(source="bic", target="BIC"),
		@Mapping(source="swfCustomerIdStructRec", target="CUSTOMERID"),
		@Mapping(source="swfCustomerDetailsStructRec", target="CUSTOMERDETAILS")
	})
	SWFF59TYPEType mapToApi(SwfNonFinEntityJpe jpe);
	
	@Mappings({
		@Mapping(target="opt", expression="java(StringUtils.isNotBlank(api.getOPT())?api.getOPT():null)"),
		@Mapping(target="address", expression="java(StringUtils.isNotBlank(api.getADDRESS())?api.getADDRESS():null)"),
		@Mapping(target="bic", expression="java(StringUtils.isNotBlank(api.getBIC())?api.getBIC():null)"),
		@Mapping(target="swfAcctLineStructRec", source="ACCOUNT"),
		@Mapping(target="swfCustomerIdStructRec", source="CUSTOMERID"),
		@Mapping(target="swfCustomerDetailsStructRec", source="CUSTOMERDETAILS")
	})
	SwfNonFinEntityJpe mapToJpe(SWFF59TYPEType api);
}