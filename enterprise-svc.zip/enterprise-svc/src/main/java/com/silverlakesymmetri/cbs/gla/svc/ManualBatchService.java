package com.silverlakesymmetri.cbs.gla.svc;

import java.util.List;
import java.util.Map;

import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation;
import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation.ServiceOperationType;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.svc.BusinessService;
import com.silverlakesymmetri.cbs.csd.bdo.sdo.Currency;
import com.silverlakesymmetri.cbs.csd.bdo.sdo.ProfitCentre;
import com.silverlakesymmetri.cbs.csd.gla.bdo.sdo.ChartAccount;
import com.silverlakesymmetri.cbs.gla.bdo.sdo.GlManualBatchGlCodeQry;
import com.silverlakesymmetri.cbs.gla.bdo.sdo.ManualBatchHdr;
import com.silverlakesymmetri.cbs.gla.jpa.mapping.sdo.ManualBatchHdrJpe;
import com.silverlakesymmetri.cbs.mcl.bdo.sdo.Client;

public interface ManualBatchService extends BusinessService<ManualBatchHdr, ManualBatchHdrJpe> {

	public static final String SVC_OP_NAME_MANUALBATCHSERVICE_GET = "manualBatchService.get";
	public static final String SVC_OP_NAME_MANUALBATCHSERVICE_FIND = "manualBatchService.find";
	public static final String SVC_OP_NAME_MANUALBATCHSERVICE_QUERY = "manualBatchService.query";
	public static final String SVC_OP_NAME_MANUALBATCHSERVICE_CREATE = "manualBatchService.create";
	public static final String SVC_OP_NAME_MANUALBATCHSERVICE_UPDATE = "manualBatchService.update";
	public static final String SVC_OP_NAME_MANUALBATCHSERVICE_DELETE = "manualBatchService.delete";
	public static final String SVC_OP_NAME_MANUALBATCHSERVICE_FIND_PROFIT_CENTRE = "manualBatchService.findProfitCentre";
	public static final String SVC_OP_NAME_MANUALBATCHSERVICE_FIND_CURRENCY = "manualBatchService.findCurrency";
	public static final String SVC_OP_NAME_MANUALBATCHSERVICE_FIND_CLIENT = "manualBatchService.findClient";
	public static final String SVC_OP_NAME_MANUALBATCHSERVICE_SUBMIT_TO_BPM = "manualBatchService.submittobpm";
	public static final String SVC_OP_NAME_MANUALBATCHSERVICE_FIND_FOR_BATCH_MAINTENANCE =
			"manualBatchService.findForBatchMaintenance";

	@ServiceOperation(name = SVC_OP_NAME_MANUALBATCHSERVICE_GET, type = ServiceOperationType.GET)
	public ManualBatchHdr getByPk(String publicKey, ManualBatchHdr reference);

	@ServiceOperation(name = SVC_OP_NAME_MANUALBATCHSERVICE_FIND)
	public List<ManualBatchHdr> find(FindCriteria findCriteria, CbsHeader cbsHeader);

	@ServiceOperation(name = SVC_OP_NAME_MANUALBATCHSERVICE_QUERY)
	public List<ManualBatchHdr> query(int offset, int resultLimit, String groupBy, String order,
			Map<String, Object> filters);

	@ServiceOperation(name = SVC_OP_NAME_MANUALBATCHSERVICE_CREATE)
	public ManualBatchHdr create(ManualBatchHdr dataObject);

	@ServiceOperation(name = SVC_OP_NAME_MANUALBATCHSERVICE_UPDATE)
	public ManualBatchHdr update(ManualBatchHdr dataObject);

	@ServiceOperation(name = SVC_OP_NAME_MANUALBATCHSERVICE_DELETE)
	public boolean delete(ManualBatchHdr dataObject);

	@ServiceOperation(name = SVC_OP_NAME_MANUALBATCHSERVICE_FIND_PROFIT_CENTRE, type = ServiceOperationType.READ, passParamAsMap = true)
	public List<ProfitCentre> findProfitCentre(Map<String, Object> queryParams);

	@ServiceOperation(name = SVC_OP_NAME_MANUALBATCHSERVICE_SUBMIT_TO_BPM)
	public ManualBatchHdr submitToBpm(ManualBatchHdr dataObject);

	@ServiceOperation(name = SVC_OP_NAME_MANUALBATCHSERVICE_FIND_CURRENCY, type = ServiceOperationType.READ, passParamAsMap = true)
	public List<Currency> findCurrency(Map<String, Object> queryParams);

	@ServiceOperation(name = SVC_OP_NAME_MANUALBATCHSERVICE_FIND_CLIENT, type = ServiceOperationType.READ, passParamAsMap = true)
	public List<Client> findClient(Map<String, Object> queryParams);

	@ServiceOperation(name = SVC_OP_NAME_MANUALBATCHSERVICE_FIND_FOR_BATCH_MAINTENANCE ,
			type = ServiceOperationType.READ, passParamAsMap = true)
	public List<GlManualBatchGlCodeQry> findForBatchMaintenance(Map<String, Object> queryParams);
}
