package com.silverlakesymmetri.cbs.gla.svc.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;

import com.mysema.query.types.EntityPath;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.svc.AbstractBusinessService;
import com.silverlakesymmetri.cbs.gla.bdo.sdo.GlBatchTmpQry;
import com.silverlakesymmetri.cbs.gla.jpa.mapping.sdo.GlBatchTmpQryJpe;
import com.silverlakesymmetri.cbs.gla.jpa.mapping.sdo.QGlBatchTmpQryJpe;
import com.silverlakesymmetri.cbs.gla.jpa.mapping.sdo.id.GlBatchTmpQryPk;
import com.silverlakesymmetri.cbs.gla.svc.GlBatchTmpQryService;
import com.silverlakesymmetri.cbs.mcl.jpa.mapping.sdo.util.MclJpeConstants;

@Service
public class GlBatchTmpQryServiceImpl extends AbstractBusinessService<GlBatchTmpQry, GlBatchTmpQryJpe, GlBatchTmpQryPk>
		implements GlBatchTmpQryService {

	@Override
	protected EntityPath<GlBatchTmpQryJpe> getEntityPath() {
		return QGlBatchTmpQryJpe.glBatchTmpQryJpe;
	}

	@Override
	protected GlBatchTmpQryPk getIdFromDataObjectInstance(GlBatchTmpQry dataObject) {
		return new GlBatchTmpQryPk(dataObject.getBranch(), dataObject.getCcy(), getClientId(dataObject.getClientNo()),
				dataObject.getGlCode(), dataObject.getSeqNo(), dataObject.getProfitCentre());
	}

	@Override
	public GlBatchTmpQry getByPk(String publicKey, GlBatchTmpQry dataObject) {
		return super.getByPk(publicKey, dataObject);
	}

	@Override
	public List<GlBatchTmpQry> query(int offset, int resultLimit, String groupBy, String order,
			Map<String, Object> filters) {
		return super.query(offset, resultLimit, groupBy, order, filters);
	}

	@Override
	public List<GlBatchTmpQry> find(FindCriteria fc, CbsHeader cbsHeader) {
		return super.find(fc, cbsHeader);
	}

	private Long getClientId(String clientNo) {
		if (StringUtils.isBlank(clientNo)) {
			return null;
		}

		Map<String, Object> params = new HashMap<String, Object>();
		params.put("clientNo", clientNo);
		Long clientId = dataService.getWithNamedQuery(MclJpeConstants.CLIENT_JPE_FIND_CLIENT_ID_USING_CLIENT_NO, params,
				Long.class);

		return clientId;
	}

	@Override
	public List<GlBatchTmpQry> getTradeNos(Map<String, Object> queryParams) {

		List<GlBatchTmpQry> retList = new ArrayList<GlBatchTmpQry>();

		if (queryParams == null) {
			return retList;
		}

		String tradeNo = (String) queryParams.get("tradeNo");
		String sourceModule = (String) queryParams.get("sourceModule");
		int limit = queryParams.get("limit") != null ? Integer.parseInt((String) queryParams.get("limit")) : 10;
		int offset = queryParams.get("offset") != null ? Integer.parseInt((String) queryParams.get("offset")) : 0;
		StringBuilder query = new StringBuilder("SELECT DISTINCT t.tradeNo FROM GlBatchTmpQryJpe t WHERE 1=1 ");
		final Map<String, Object> params = new HashMap<>();

		if (!StringUtils.isBlank(tradeNo)) {
			query.append(" AND UPPER(t.tradeNo) LIKE :tradeNo ");
			params.put("tradeNo", tradeNo.toUpperCase());
		}

		if (!StringUtils.isBlank(sourceModule)) {
			query.append(" AND UPPER(t.sourceModule) LIKE :sourceModule ");
			params.put("sourceModule", sourceModule.toUpperCase());
		}

		query.append(" ORDER BY t.tradeNo");
		List<String> resultList = dataService.findWithQuery(query.toString(), params, offset, limit, String.class);

		if (resultList != null) {
			for (String tmpStr : resultList) {
				GlBatchTmpQry bdo = jaxbSdoHelper.createSdoInstance(GlBatchTmpQry.class);
				bdo.setTradeNo(tmpStr);
				retList.add(bdo);
			}
		}

		return retList;

	}

	@Override
	public List<GlBatchTmpQry> getRefNos(Map<String, Object> queryParams) {

		List<GlBatchTmpQry> retList = new ArrayList<GlBatchTmpQry>();

		if (queryParams == null) {
			return retList;
		}

		String reference = (String) queryParams.get("reference");
		String sourceModule = (String) queryParams.get("sourceModule");
		int limit = queryParams.get("limit") != null ? Integer.parseInt((String) queryParams.get("limit")) : 10;
		int offset = queryParams.get("offset") != null ? Integer.parseInt((String) queryParams.get("offset")) : 0;
		StringBuilder query = new StringBuilder("SELECT DISTINCT t.reference FROM GlBatchTmpQryJpe t WHERE 1=1 ");
		final Map<String, Object> params = new HashMap<>();

		if (!StringUtils.isBlank(reference)) {
			query.append(" AND UPPER(t.reference) LIKE :reference ");
			params.put("reference", reference.toUpperCase());
		}

		if (!StringUtils.isBlank(sourceModule)) {
			query.append(" AND UPPER(t.sourceModule) LIKE :sourceModule ");
			params.put("sourceModule", sourceModule.toUpperCase());
		}

		query.append(" ORDER BY t.reference");
		List<String> resultList = dataService.findWithQuery(query.toString(), params, offset, limit, String.class);

		if (resultList != null) {
			for (String tmpStr : resultList) {
				GlBatchTmpQry bdo = jaxbSdoHelper.createSdoInstance(GlBatchTmpQry.class);
				bdo.setReference(tmpStr);
				retList.add(bdo);
			}
		}

		return retList;

	}

}
