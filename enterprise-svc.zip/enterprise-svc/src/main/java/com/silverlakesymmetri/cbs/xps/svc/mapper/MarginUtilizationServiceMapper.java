package com.silverlakesymmetri.cbs.xps.svc.mapper;

import org.mapstruct.Context;
import org.mapstruct.InheritInverseConfiguration;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingTarget;
import org.mapstruct.Mappings;

import com.silverlakesymmetri.cbs.commons.jpa.util.DateTimeHelper;
import com.silverlakesymmetri.cbs.commons.xmlapi.enums.CbsXmlApiOperation;
import com.silverlakesymmetri.cbs.xps.jpa.MarginUtilizable;
import com.silverlakesymmetri.cbs.xps.xmlapi.XPSTRANMARGINUTILIZATIONAPIType;

@Mapper(uses={ DateTimeHelper.class })
public interface MarginUtilizationServiceMapper {

	@Mappings({
		@Mapping(expression = "java(oper != null ? oper.getOperation() : null)", target="OPERATION"),
		@Mapping(source="marginInternalKey", target = "MARGININTERNALKEY"),
		@Mapping(source="relInternalKey", target = "RELINTERNALKEY"),
		@Mapping(source="seqNo", target = "SEQNO"),
		@Mapping(source="marginAmt", target = "AMOUNT"),
		@Mapping(source="baseRate", target = "BASERATE"),
		@Mapping(source="baseQuote", target = "BASEQUOTE"),
		@Mapping(source="baseEquiv", target = "BASEEQUIV"),
		@Mapping(source="localRate", target = "LOCALRATE"),
		@Mapping(source="localQuote", target = "LOCALQUOTE"),
		@Mapping(source="localEquiv", target = "LOCALEQUIV"),
		@Mapping(source="exchQuote", target = "EXCHQUOTE"),
		@Mapping(source="exchSpotRate", target = "EXCHSPOTRATE"),
		@Mapping(source="exchRate", target = "EXCHRATE"),
		@Mapping(source="exchFwdPoints", target = "EXCHFWDPOINTS"),
		@Mapping(source="exchSpread", target = "EXCHSPREAD"),
		@Mapping(source="exchClientSpread", target = "EXCHCLIENTSPREAD"),
		@Mapping(source="settleBaseRate", target = "SETTLEBASERATE"),
		@Mapping(source="settleBaseQuote", target = "SETTLEBASEQUOTE"),
		@Mapping(source="amount", target = "TRANSETTLEAMT"),
		//@Mapping(source="", target = "SETTLEACCTTRANSACTIONKEY"),
		//@Mapping(source="", target = "SETTLEOLDACCTRESTRAINTKEY"),
		//@Mapping(constant="V", target = "TRANSTATUS"),
	})
	public XPSTRANMARGINUTILIZATIONAPIType mapToApi(MarginUtilizable jpe, @Context CbsXmlApiOperation oper);

	@InheritInverseConfiguration(name = "mapToApi")
	public MarginUtilizable mapToJpe(XPSTRANMARGINUTILIZATIONAPIType api, @MappingTarget MarginUtilizable jpe);
}