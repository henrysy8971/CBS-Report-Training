package com.silverlakesymmetri.cbs.xps.svc.mapper.decorator;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.mapstruct.Context;
import org.mapstruct.MappingTarget;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

import com.silverlakesymmetri.cbs.commons.jpa.service.CbsGenericDataService;
import com.silverlakesymmetri.cbs.commons.xmlapi.enums.CbsXmlApiOperation;
import com.silverlakesymmetri.cbs.mcl.jpa.mapping.sdo.ClientJpe;
import com.silverlakesymmetri.cbs.mcl.jpa.mapping.sdo.util.MclJpeConstants;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.ChargeInstrumentInfoJpe;
import com.silverlakesymmetri.cbs.xps.svc.mapper.ChargeInstrumentInfoMapper;
import com.silverlakesymmetri.cbs.xps.xmlapi.XPSCHARGEINSTRUMENTTYPEType;

public abstract class ChargeInstrumentInfoDecorator implements ChargeInstrumentInfoMapper {
	
	@Autowired
	@Qualifier("delegate")
	protected ChargeInstrumentInfoMapper delegate;
	
    @Autowired(required = true)
    @Qualifier("cbsGenericDataService")
    protected CbsGenericDataService dataService;

	@Override
	public XPSCHARGEINSTRUMENTTYPEType mapToApi(ChargeInstrumentInfoJpe jpe, @Context CbsXmlApiOperation oper){
		XPSCHARGEINSTRUMENTTYPEType req = (XPSCHARGEINSTRUMENTTYPEType) delegate.mapToApi(jpe, oper);
		return  req;
	}
	
	@Override
	public ChargeInstrumentInfoJpe mapToJpe(XPSCHARGEINSTRUMENTTYPEType api, @MappingTarget ChargeInstrumentInfoJpe jpe){
		delegate.mapToJpe(api, jpe);
		Map<String, Object> params = new HashMap<String, Object>();
		if(jpe.getAgentClientId() != null){
			params.put("clientId", jpe.getAgentClientId());
			List<ClientJpe> agent = dataService.findWithNamedQuery(MclJpeConstants.CLIENT_JPE_GET_CLIENT_FROM_ID, params, ClientJpe.class);
			if(agent != null && agent.size() > 0){
				jpe.setAgentClientNo(agent.get(0).getClientNo());
			}
		}
		if(jpe.getCustomerClientId() != null){
			params.put("clientId", jpe.getCustomerClientId());
			List<ClientJpe> customer = dataService.findWithNamedQuery(MclJpeConstants.CLIENT_JPE_GET_CLIENT_FROM_ID, params, ClientJpe.class);
			if(customer != null && customer.size() > 0){
				jpe.setCustomerClientNo(customer.get(0).getClientNo());
			}
		}
		
		return jpe;
	}

}


