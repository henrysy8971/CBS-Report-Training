package com.silverlakesymmetri.cbs.gla.svc.mapper.mapping;

import com.silverlakesymmetri.cbs.commons.jpa.util.DateTimeHelper;
import com.silverlakesymmetri.cbs.gla.jpa.mapping.sdo.GlAccountingEntryJpe;
import com.silverlakesymmetri.cbs.gla.xmlapi.GLAACCOUNTINGENTRYTYPEType;
import org.mapstruct.InheritInverseConfiguration;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Mappings;

@Mapper(uses={ DateTimeHelper.class})
public interface GlAcctgEntryToGLAACCOUNTINGENTRYTYPEMapper {
	
	@Mappings({
		@Mapping(source="sourceModule", target="SOURCEMODULE"),
		@Mapping(source="valueDate", target="VALUEDATE", qualifiedByName = {"DateTimeHelper", "convertDateToCbsXmlApiDate"}),
	})
	public GLAACCOUNTINGENTRYTYPEType mapToApi(GlAccountingEntryJpe jpe);

	@InheritInverseConfiguration(name = "mapToApi")
	@Mappings({
		@Mapping(source="VALUEDATE", target="valueDate", qualifiedByName = {"DateTimeHelper", "convertCbsApiDateToString"})
	})
	public GlAccountingEntryJpe mapToJpe(GLAACCOUNTINGENTRYTYPEType api);
}
