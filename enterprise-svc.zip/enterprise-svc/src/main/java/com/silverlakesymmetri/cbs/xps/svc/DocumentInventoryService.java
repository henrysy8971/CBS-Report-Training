package com.silverlakesymmetri.cbs.xps.svc;

import java.util.List;
import java.util.Map;

import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation;
import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation.ServiceOperationType;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.svc.BusinessService;
import com.silverlakesymmetri.cbs.xps.bdo.sdo.DocumentInventoryHdr;
import com.silverlakesymmetri.cbs.xps.bdo.sdo.DocumentTrackingDtl;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.DocumentInventoryHdrJpe;

/**
*  Copyright SunGard 2014 
*
*  Service is used to Read, Create, Update, Delete DocumentInventoryHdr data.
*
* @author      Ryan Vargas
* @since       2014-10-08
*/
public interface DocumentInventoryService extends BusinessService<DocumentInventoryHdr, DocumentInventoryHdrJpe> {

    public static final String SVC_OP_NAME_DOCUMENTINVENTORYSERVICE_GET = "DocumentInventoryService.get";
    public static final String SVC_OP_NAME_DOCUMENTINVENTORYSERVICE_QUERY = "DocumentInventoryService.query";
    public static final String SVC_OP_NAME_DOCUMENTINVENTORYSERVICE_CREATE = "DocumentInventoryService.create";
    public static final String SVC_OP_NAME_DOCUMENTINVENTORYSERVICE_UPDATE = "DocumentInventoryService.update";
    public static final String SVC_OP_NAME_DOCUMENTINVENTORYSERVICE_DELETE = "DocumentInventoryService.delete";
    public static final String SVC_OP_NAME_DOCUMENTINVENTORYSERVICE_FIND = "DocumentInventoryService.find";
    public static final String SVC_OP_NAME_DOCUMENTINVENTORYSERVICE_GETDOCTRACKINGHISTORY = "DocumentInventoryService.getdocumenttrackinghistory";
    
    @ServiceOperation(name = SVC_OP_NAME_DOCUMENTINVENTORYSERVICE_GET, type = ServiceOperationType.GET)
    public DocumentInventoryHdr getByPk(String publicKey, DocumentInventoryHdr reference);

    @ServiceOperation(name = SVC_OP_NAME_DOCUMENTINVENTORYSERVICE_CREATE)
    public DocumentInventoryHdr create(DocumentInventoryHdr dataObject);

    @ServiceOperation(name = SVC_OP_NAME_DOCUMENTINVENTORYSERVICE_UPDATE)
    public DocumentInventoryHdr update(DocumentInventoryHdr dataObject);

    @ServiceOperation(name = SVC_OP_NAME_DOCUMENTINVENTORYSERVICE_DELETE)
    public boolean delete(DocumentInventoryHdr dataObject);

    @ServiceOperation(name = SVC_OP_NAME_DOCUMENTINVENTORYSERVICE_QUERY)
    public List<DocumentInventoryHdr> query(int offset, int resultLimit, String groupBy, String order, Map<String, Object> filters);

    @ServiceOperation(name = SVC_OP_NAME_DOCUMENTINVENTORYSERVICE_FIND)
    public List<DocumentInventoryHdr> find(FindCriteria findCriteria, CbsHeader cbsHeader);

    @ServiceOperation(name = SVC_OP_NAME_DOCUMENTINVENTORYSERVICE_GETDOCTRACKINGHISTORY, type = ServiceOperationType.READ)
    public List<DocumentTrackingDtl> getDocumentTrackingHistory(String docInvRefNo, String docInvDtlRefNo);

}
