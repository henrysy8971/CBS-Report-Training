package com.silverlakesymmetri.cbs.xps.svc;

import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation;
import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation.ServiceOperationType;
import com.silverlakesymmetri.cbs.xps.util.NostroReconciliationObject;

public interface NostroReconUtilityService {

	public static final String SVC_OP_NAME_NOSTRORECONUTILITYSERVICE_RECONCILE = "NostroReconUtilityService.reconcile";

	@ServiceOperation(name = SVC_OP_NAME_NOSTRORECONUTILITYSERVICE_RECONCILE, type = ServiceOperationType.EXECUTE)
    public NostroReconciliationObject reconcile(NostroReconciliationObject nrObject);

}
