package com.silverlakesymmetri.cbs.swf.svc;

import java.util.List;
import java.util.Map;

import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation;
import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation.ServiceOperationType;
import com.silverlakesymmetri.cbs.commons.bdo.sdo.DmsFile;
import com.silverlakesymmetri.cbs.swf.bdo.sdo.SwfChargeNarrative;
import com.silverlakesymmetri.cbs.swf.bdo.sdo.SwfNonFinEntity;
import com.silverlakesymmetri.cbs.swf.bdo.sdo.SwfSndrRcvrNarrative;

public interface SwiftUtilityService {

    public static final String SWFUTILITYSERVICE_VALIDATE_SWFF50 = "SwiftUtilityService.validateSwfNonFinEntity";
    public static final String SWFUTILITYSERVICE_PREVIEW_SNDRRCVR = "SwiftUtilityService.previewSndrRcvrNarrative";
    public static final String SWFUTILITYSERVICE_PREVIEW_PLAIN = "SwiftUtilityService.previewPlainNarrative";
    public static final String SWFUTILITYSERVICE_PREVIEW_CHARGE = "SwiftUtilityService.previewChargeNarrative";
    public static final String SWFUTILITYSERVICE_PREVIEW_LIST = "SwiftUtilityService.previewListNarrative";
    public static final String SWFUTILITYSERVICE_FORMAT_SNDRRCVR = "SwiftUtilityService.formatSndrRcvrNarrative";
    public static final String SWFUTILITYSERVICE_FORMAT_PLAIN = "SwiftUtilityService.formatPlainNarrative";
    public static final String SWFUTILITYSERVICE_FORMAT_CHARGE = "SwiftUtilityService.formatChargeNarrative";
    public static final String SWFUTILITYSERVICE_FORMAT_LIST = "SwiftUtilityService.formatListNarrative";
    public static final String SWFUTILITYSERVICE_DOWNLOAD_SWIFT = "SwiftUtilityService.downloadSwiftMessage";

    @ServiceOperation(name = SWFUTILITYSERVICE_VALIDATE_SWFF50, type = ServiceOperationType.EXECUTE)
    public boolean validateSwfNonFinEntity(SwfNonFinEntity dataObject);

    @ServiceOperation(name = SWFUTILITYSERVICE_PREVIEW_SNDRRCVR, type = ServiceOperationType.EXECUTE, passParamAsMap = true)
    public String previewSndrRcvrNarrative(Map<String, Object> parameters);

    @ServiceOperation(name = SWFUTILITYSERVICE_PREVIEW_CHARGE, type = ServiceOperationType.EXECUTE, passParamAsMap = true)
    public String previewChargeNarrative(Map<String, Object> parameters);

    @ServiceOperation(name = SWFUTILITYSERVICE_PREVIEW_PLAIN, type = ServiceOperationType.EXECUTE, passParamAsMap = true)
    public String previewPlainNarrative(Map<String, Object> parameters);
    
    @ServiceOperation(name = SWFUTILITYSERVICE_PREVIEW_LIST, type = ServiceOperationType.EXECUTE, passParamAsMap = true)
    public String previewNarrativeList(Map<String, Object> parameters);
    
    @ServiceOperation(name = SWFUTILITYSERVICE_FORMAT_SNDRRCVR, type = ServiceOperationType.EXECUTE, passParamAsMap = true)
    public List<SwfSndrRcvrNarrative> formatSndrRcvrNarrative(Map<String, Object> parameters);

    @ServiceOperation(name = SWFUTILITYSERVICE_FORMAT_CHARGE, type = ServiceOperationType.EXECUTE, passParamAsMap = true)
    public List<SwfChargeNarrative> formatChargeNarrative(Map<String, Object> parameters);

    @ServiceOperation(name = SWFUTILITYSERVICE_FORMAT_PLAIN, type = ServiceOperationType.EXECUTE, passParamAsMap = true)
    public String formatPlainNarrative(Map<String, Object> parameters);
    
    @ServiceOperation(name = SWFUTILITYSERVICE_FORMAT_LIST, type = ServiceOperationType.EXECUTE, passParamAsMap = true)
    public Map<String, Object> formatListNarrative(Map<String, Object> parameters);
    
    @ServiceOperation(name = SWFUTILITYSERVICE_DOWNLOAD_SWIFT, type = ServiceOperationType.EXECUTE)
    public DmsFile downloadSwiftMessage(String message);

}
