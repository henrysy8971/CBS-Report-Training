package com.silverlakesymmetri.cbs.xps.svc;

import java.util.List;
import java.util.Map;

import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation;
import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation.ServiceOperationType;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.svc.BusinessService;
import com.silverlakesymmetri.cbs.xps.bdo.sdo.AdviceTemplate;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.AdviceTemplateJpe;

public interface AdviceTemplateService extends BusinessService<AdviceTemplate, AdviceTemplateJpe> {
	public static final String XPS_OP_NAME_ADVICETEMPLATESERVICE_GET = "AdviceTemplateService.get";
    public static final String XPS_OP_NAME_ADVICETEMPLATESERVICE_QUERY = "AdviceTemplateService.query";
    public static final String XPS_OP_NAME_ADVICETEMPLATESERVICE_FIND = "AdviceTemplateService.find";
    public static final String XPS_OP_NAME_ADVICETEMPLATESERVICE_CREATE = "AdviceTemplateService.create";
    public static final String XPS_OP_NAME_ADVICETEMPLATESERVICE_UPDATE = "AdviceTemplateService.update";
    public static final String XPS_OP_NAME_ADVICETEMPLATESERVICE_DELETE = "AdviceTemplateService.delete";
    
    @ServiceOperation(name = XPS_OP_NAME_ADVICETEMPLATESERVICE_GET, type = ServiceOperationType.GET)
    public AdviceTemplate getByPk(String publicKey, AdviceTemplate reference);

    @ServiceOperation(name = XPS_OP_NAME_ADVICETEMPLATESERVICE_QUERY)
    public List<AdviceTemplate> query(int offset, int resultLimit, String groupBy, String order, Map<String, Object> filters);
    
    @ServiceOperation(name = XPS_OP_NAME_ADVICETEMPLATESERVICE_FIND)
    public List<AdviceTemplate> find(FindCriteria findCriteria, CbsHeader cbsHeader);
    
    @ServiceOperation(name = XPS_OP_NAME_ADVICETEMPLATESERVICE_CREATE)
    public AdviceTemplate create(AdviceTemplate dataObject);

     @ServiceOperation(name = XPS_OP_NAME_ADVICETEMPLATESERVICE_UPDATE)
    public AdviceTemplate update(AdviceTemplate dataObject);

    @ServiceOperation(name = XPS_OP_NAME_ADVICETEMPLATESERVICE_DELETE)
    public boolean delete(AdviceTemplate dataObject);
}