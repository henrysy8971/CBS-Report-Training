package com.silverlakesymmetri.cbs.xps.svc.batch.reader;

import com.silverlakesymmetri.cbs.commons.logging.CbsAppLogger;
import com.silverlakesymmetri.cbs.commons.logging.CbsAppLoggerFactory;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.IncomingMessageSwfJpe;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.util.XpsJpeConstants;

import java.util.*;
import java.util.stream.Collectors;

public class SwiftIncomingPendingTranReader extends IncomingMessagePendingTranBaseReader<IncomingMessageSwfJpe> {
	private final CbsAppLogger logger = CbsAppLoggerFactory.getLogger(SwiftIncomingPendingTranReader.class.getName());

	@Override
	protected List<IncomingMessageSwfJpe> getDomainListProcessing(String domainListStr, String statusListStr) {
		String[] domainArray = domainListStr.split(LIST_DELIMITER);
		List<String> domainList = new ArrayList<>();
		if (domainArray.length > 0) {
			domainList = Arrays.asList(domainArray);
		}

		String[] statusArray = statusListStr.split(LIST_DELIMITER);
		List<String> statusList = new ArrayList<>();
		if (statusArray.length > 0) {
			statusList = Arrays.asList(statusArray);
		}

		if (domainList.isEmpty() || statusList.isEmpty()) {
			logger.warn("Noting to process. Domain/Status list are empty");
			return Collections.emptyList();
		}

		Map<String, Object> params = new HashMap<>();
		params.put("domains", domainList);
		params.put("statuses", statusList);
		List<IncomingMessageSwfJpe> jpeList = this.cbsBatchGenericDataService
				.findWithNamedQuery(XpsJpeConstants.INCOMING_MESSAGE_SWF_JPE_FIND_BY_DOMAIN_AND_STATUS, params, IncomingMessageSwfJpe.class);

		if (jpeList == null || jpeList.isEmpty()) {
			logger.warn("No IncomingMessageSwfJpe found for domain/status: {}/{}", domainList, statusList);
		} else {
			List<Long> keys = jpeList.stream().map(IncomingMessageSwfJpe::getInternalKey).collect(Collectors.toList());
			logger.info("Keys that are read: {}", keys);
		}

		return jpeList;
	}

	@Override
	protected List<IncomingMessageSwfJpe> getInternalKeyListProcessing(String internalKeyListStr) {
		String[] keysArray = internalKeyListStr.split(LIST_DELIMITER);
		if (keysArray.length > 0) {
			List<String> keysListStr = Arrays.asList(keysArray);
			List<Long> keyList = keysListStr.stream().map(Long::valueOf).collect(Collectors.toList());

			Map<String, Object> params = new HashMap<>();
			params.put("statuses", Arrays.asList(STATUS_PENDING_PROCESS, STATUS_FAILED));
			params.put("keys", keyList);
			List<IncomingMessageSwfJpe> jpeList = this.cbsBatchGenericDataService
					.findWithNamedQuery(XpsJpeConstants.INCOMING_MESSAGE_SWF_JPE_FIND_BY_STATUS_AND_KEYS, params, IncomingMessageSwfJpe.class);

			if (jpeList == null || jpeList.isEmpty()) {
				logger.warn("No IncomingMessageSwfJpe found for status/keys: {}/{}", STATUS_PENDING_PROCESS + "," + STATUS_FAILED, keyList);
			} else {
				List<Long> keys = jpeList.stream().map(IncomingMessageSwfJpe::getInternalKey).collect(Collectors.toList());
				logger.info("Keys that are read: {}", keys);
			}

			return jpeList;
		} else {
			logger.warn("Noting to process. keysArray is empty");
		}

		return Collections.emptyList();
	}
}
