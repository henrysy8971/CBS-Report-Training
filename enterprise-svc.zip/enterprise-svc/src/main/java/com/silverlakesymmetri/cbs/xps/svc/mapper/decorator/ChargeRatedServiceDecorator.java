package com.silverlakesymmetri.cbs.xps.svc.mapper.decorator;

import org.mapstruct.MappingTarget;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.ChargeRatedJpe;
import com.silverlakesymmetri.cbs.xps.svc.mapper.ChargeRatedServiceMapper;
import com.silverlakesymmetri.cbs.xps.xmlapi.XPSTRANCHARGEDETAILAPIType;

public abstract class ChargeRatedServiceDecorator implements ChargeRatedServiceMapper {
	
	@Autowired
	@Qualifier("delegate")
	protected ChargeRatedServiceMapper delegate;

	@Override
	public XPSTRANCHARGEDETAILAPIType mapToApi(ChargeRatedJpe jpe, @MappingTarget XPSTRANCHARGEDETAILAPIType api){
		delegate.mapToApi(jpe, api);
		return api;
	}
	
	@Override
	public ChargeRatedJpe mapToJpe(XPSTRANCHARGEDETAILAPIType api, @MappingTarget ChargeRatedJpe jpe){
		delegate.mapToJpe(api, jpe);
		return jpe;
	}

}


