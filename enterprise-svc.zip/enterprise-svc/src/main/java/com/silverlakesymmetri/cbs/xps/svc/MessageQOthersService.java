package com.silverlakesymmetri.cbs.xps.svc;

import java.util.List;
import java.util.Map;

import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation;
import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation.ServiceOperationType;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.svc.BusinessService;
import com.silverlakesymmetri.cbs.xps.bdo.sdo.MessageQOthers;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.MessageQOthersJpe;

public interface MessageQOthersService extends BusinessService<MessageQOthers, MessageQOthersJpe> {

    public static final String SVC_OP_NAME_MESSAGEQOTHERSSERVICE_GET = "MessageQOthersService.get";
    public static final String SVC_OP_NAME_MESSAGEQOTHERSSERVICE_QUERY = "MessageQOthersService.query";
    public static final String SVC_OP_NAME_MESSAGEQOTHERSSERVICE_CREATE = "MessageQOthersService.create";
    public static final String SVC_OP_NAME_MESSAGEQOTHERSSERVICE_UPDATE = "MessageQOthersService.update";
    public static final String SVC_OP_NAME_MESSAGEQOTHERSSERVICE_DELETE = "MessageQOthersService.delete";
    public static final String SVC_OP_NAME_MESSAGEQOTHERSSERVICE_FIND = "MessageQOthersService.find";
    
    @ServiceOperation(name = SVC_OP_NAME_MESSAGEQOTHERSSERVICE_GET, type = ServiceOperationType.GET)
    public MessageQOthers getByPk(String publicKey, MessageQOthers reference);

    @ServiceOperation(name = SVC_OP_NAME_MESSAGEQOTHERSSERVICE_CREATE)
    public MessageQOthers create(MessageQOthers dataObject);

    @ServiceOperation(name = SVC_OP_NAME_MESSAGEQOTHERSSERVICE_UPDATE)
    public MessageQOthers update(MessageQOthers dataObject);

    @ServiceOperation(name = SVC_OP_NAME_MESSAGEQOTHERSSERVICE_DELETE)
    public boolean delete(MessageQOthers dataObject);

    @ServiceOperation(name = SVC_OP_NAME_MESSAGEQOTHERSSERVICE_QUERY)
    public List<MessageQOthers> query(int offset, int resultLimit, String groupBy, String order, Map<String, Object> filters);

    @ServiceOperation(name = SVC_OP_NAME_MESSAGEQOTHERSSERVICE_FIND)
    public List<MessageQOthers> find(FindCriteria findCriteria, CbsHeader cbsHeader);

}
