package com.silverlakesymmetri.cbs.xps.svc.ext;

import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import javax.validation.ConstraintViolation;
import javax.validation.Path;
import javax.validation.metadata.ConstraintDescriptor;

import com.silverlakesymmetri.cbs.commons.ext.impl.AbstractServiceExtPointImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.silverlakesymmetri.cbs.commons.bdo.sdo.Registry;
import com.silverlakesymmetri.cbs.commons.ext.ServiceExtensionPoint;
import com.silverlakesymmetri.cbs.commons.jpa.extension.JaxbSdoHelper;
import com.silverlakesymmetri.cbs.commons.jpa.mapping.sdo.RegistryJpe;
import com.silverlakesymmetri.cbs.commons.jpa.repository.RegistryRepository;
import com.silverlakesymmetri.cbs.commons.svc.EnterpriseModuleRegistryServiceExt;
import com.silverlakesymmetri.cbs.commons.util.MessageUtils;

@Service
public class EnterpriseModuleRegistryServiceExtImpl extends AbstractServiceExtPointImpl implements ServiceExtensionPoint,
        EnterpriseModuleRegistryServiceExt {

	private static final String RELAX_MATCH_AMT_DIFF = "relaxMatchAmtDiff";
	private static final String CBS_B_XPS_ENTERPRISEREGISTRYEXT_SERVICE_0001 = "{CBS.B.XPS.ENTERPRISEREGISTRYEXT_SERVICE.0001}";
	private static final String CBS_B_XPS_ENTERPRISEREGISTRYEXT_SERVICE_0002 = "{CBS.B.XPS.ENTERPRISEREGISTRYEXT_SERVICE.0002}";
	private static final String RELAX_MATCH_AMOUNT = "relaxMatchAmount";
	private static final String RELAX_MATCH_REF_OWNER = "relaxMatchRefOwner";
	private static final String RELAX_MATCH_VALUE_DATE = "relaxMatchValueDate";
	private static final String ATTRS_FOR_VALIDATION1 = "relaxMatchValueDate|relaxMatchRefOwner|relaxMatchAmount";
	private static final String ATTRS_FOR_VALIDATION2 = "relaxMatchAmtDiff|relaxMatchAmount";
	private static final String META_TYPE = "REGISTRY";
	
	@Autowired
	private JaxbSdoHelper jaxbSdoHelper;
	
	@Autowired
	private RegistryRepository registryRepository;
	
	@Autowired
	protected MessageUtils messageUtils;
	
	@Override
	public String[] getExtendedBdoNames() {
		return new String[] {NOSTRO_RECON_REGISTRY};
	}

	@Override
	public String[] getExtendedServiceNames() {
		return new String[] {ENTERPRISE_MODULE_REGISTRY_SERVICE_EXT_VALIDATE};
	}

	@Override
	public void beforeService(Object[] serviceParameters) {
		// TODO Auto-generated method stub
	}

	@Override
	public Object afterService(Object result, Object[] serviceParameters) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void beforeQuery(Object[] serviceParameters) {
		// TODO Auto-generated method stub
	}

	@Override
	public Object afterQuery(Object result, Object[] serviceParameters) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Set<ConstraintViolation<RegistryJpe>> validateList(List<Registry> registryList) {
		final Set<ConstraintViolation<RegistryJpe>> constraintViolations = new HashSet<>();
		
		if (registryList == null || registryList.isEmpty()) return constraintViolations; 
			
		Map<String, RegistryJpe> valMap1 = new HashMap<>();
		Map<String, RegistryJpe> valMap2 = new HashMap<>();
		for (Registry registry : registryList) {
			if (registry != null && META_TYPE.equals(registry.getMetaType()) && NOSTRO_RECON_REGISTRY.equals(registry.getMetaCode())
					&& registry.getAttributeCode() != null) {
				if (registry.getAttributeCode().matches(ATTRS_FOR_VALIDATION1)) {
					valMap1.put(registry.getAttributeCode(), jaxbSdoHelper.unwrap(registry, true));
				}
				if (registry.getAttributeCode().matches(ATTRS_FOR_VALIDATION2)) {
					valMap2.put(registry.getAttributeCode(), jaxbSdoHelper.unwrap(registry, true));
				}
			}		
		}
		
		validateCheckboxGroupValidity(constraintViolations, valMap1);
		validateRelaxMatchAmtDiff(constraintViolations, valMap2);
		
		return constraintViolations;
	}

	private void validateRelaxMatchAmtDiff(Set<ConstraintViolation<RegistryJpe>> constraintViolations,
			Map<String, RegistryJpe> valMap) {
		if (valMap.isEmpty()) return;
		
		if (!valMap.containsKey(RELAX_MATCH_AMT_DIFF)) {
			valMap.put(RELAX_MATCH_AMT_DIFF, registryRepository.find(NOSTRO_RECON_REGISTRY, RELAX_MATCH_AMT_DIFF));
		}
		if (!valMap.containsKey(RELAX_MATCH_AMOUNT)) {
			valMap.put(RELAX_MATCH_AMOUNT, registryRepository.find(NOSTRO_RECON_REGISTRY, RELAX_MATCH_AMOUNT));
		}
		
		if ("N".equals(valMap.get(RELAX_MATCH_AMOUNT).getValueS()) && valMap.get(RELAX_MATCH_AMOUNT).getValueN() != null) {
			constraintViolations.add(createConstraintViolation(
					valMap.get(RELAX_MATCH_AMOUNT).getValueN(), CBS_B_XPS_ENTERPRISEREGISTRYEXT_SERVICE_0002, new Object[] { }));
		}
	}

	private void validateCheckboxGroupValidity(Set<ConstraintViolation<RegistryJpe>> constraintViolations,
			Map<String, RegistryJpe> valMap) {
		if (valMap.isEmpty()) return;
		
		if (!valMap.containsKey(RELAX_MATCH_VALUE_DATE)) {
			valMap.put(RELAX_MATCH_VALUE_DATE, registryRepository.find(NOSTRO_RECON_REGISTRY, RELAX_MATCH_VALUE_DATE));
		}
		if (!valMap.containsKey(RELAX_MATCH_REF_OWNER)) {
			valMap.put(RELAX_MATCH_REF_OWNER, registryRepository.find(NOSTRO_RECON_REGISTRY, RELAX_MATCH_REF_OWNER));
		}
		if (!valMap.containsKey(RELAX_MATCH_AMOUNT)) {
			valMap.put(RELAX_MATCH_AMOUNT, registryRepository.find(NOSTRO_RECON_REGISTRY, RELAX_MATCH_AMOUNT));
		}

		
		int cnt = 0;
		for (Entry<String, RegistryJpe> mapEntry : valMap.entrySet()) {
			RegistryJpe jpe = mapEntry.getValue();
			if ("Y".equals(jpe.getValueS())) {
				cnt++;
			}
		}
		if (cnt > 1) {
			constraintViolations.add(createConstraintViolation("Y", CBS_B_XPS_ENTERPRISEREGISTRYEXT_SERVICE_0001, new Object[] { }));
		}
	}

	private ConstraintViolation<RegistryJpe> createConstraintViolation(final Object value, String errMessage, Object[] messageParams) {
		final String messageTempalte = errMessage.replaceAll("[\\{\\}]", "");
		final String message = messageUtils.getMessage(messageTempalte, messageParams);
		final ConstraintViolation<RegistryJpe> violation = new ConstraintViolation<RegistryJpe>() {
			@Override
			public String getMessage() {
				return message;
			}

			@Override
			public String getMessageTemplate() {
				return messageTempalte;
			}

			@Override
			public RegistryJpe getRootBean() {
				return null;
			}

			@Override
			public Class<RegistryJpe> getRootBeanClass() {
				return RegistryJpe.class;
			}

			@Override
			public Object getLeafBean() {
				return null;
			}

			@Override
			public Path getPropertyPath() {
				return null;
			}

			@Override
			public Object getInvalidValue() {
				return value;
			}

			@Override
			public ConstraintDescriptor<?> getConstraintDescriptor() {
				return null;
			}

			@Override
			public Object[] getExecutableParameters() {
				return null;
			}

			@Override
			public Object getExecutableReturnValue() {
				return null;
			}

			@Override
			public <U> U unwrap(Class<U> arg0) {
				return null;
			}
		};
		return violation;
	}
}
