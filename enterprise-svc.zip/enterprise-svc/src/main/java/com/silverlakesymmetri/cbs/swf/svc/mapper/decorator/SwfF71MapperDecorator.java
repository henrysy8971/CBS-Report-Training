package com.silverlakesymmetri.cbs.swf.svc.mapper.decorator;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

import com.silverlakesymmetri.cbs.swf.jpa.mapping.sdo.SwfF71Jpe;
import com.silverlakesymmetri.cbs.swf.svc.mapper.mapping.SwfF71Mapper;
import com.silverlakesymmetri.cbs.swf.xmlapi.SWFF71TYPEType;

public abstract class SwfF71MapperDecorator implements SwfF71Mapper {
	
	@Autowired
	@Qualifier("delegate")
	protected SwfF71Mapper delegate;

	@Override
	public SWFF71TYPEType mapToApi(SwfF71Jpe jpe){
		SWFF71TYPEType swfF71 = delegate.mapToApi(jpe);
		if(swfF71 != null && swfF71.getAMOUNT() == null && swfF71.getCODE() == null && swfF71.getSETTLEEQUIVAMT() == null){
			return null;
		}
		return swfF71;
	}
	
	@Override
	public SwfF71Jpe mapToJpe(SWFF71TYPEType api){
		return delegate.mapToJpe(api);
	}
	
}
