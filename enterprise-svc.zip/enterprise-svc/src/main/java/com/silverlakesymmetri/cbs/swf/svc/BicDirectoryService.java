package com.silverlakesymmetri.cbs.swf.svc;


import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation;
import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation.ServiceOperationType;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.svc.BusinessService;
import com.silverlakesymmetri.cbs.swf.bdo.sdo.BicDirectory;
import com.silverlakesymmetri.cbs.swf.jpa.mapping.sdo.BicDirectoryJpe;

import java.util.List;
import java.util.Map;

public interface BicDirectoryService extends BusinessService<BicDirectory, BicDirectoryJpe> {

    String SVC_OP_NAME_BIC_DIRECTORY_SERVICE_GET = "BicDirectoryService.get";
    String SVC_OP_NAME_BIC_DIRECTORY_SERVICE_QUERY = "BicDirectoryService.query";
    String SVC_OP_NAME_BIC_DIRECTORY_SERVICE_CREATE = "BicDirectoryService.create";
    String SVC_OP_NAME_BIC_DIRECTORY_SERVICE_UPDATE = "BicDirectoryService.update";
    String SVC_OP_NAME_BIC_DIRECTORY_SERVICE_DELETE = "BicDirectoryService.delete";
    String SVC_OP_NAME_BIC_DIRECTORY_SERVICE_FIND = "BicDirectoryService.find";

    @ServiceOperation(name = SVC_OP_NAME_BIC_DIRECTORY_SERVICE_GET, type = ServiceOperationType.GET)
    BicDirectory getByPk(String publicKey, BicDirectory reference);

    @ServiceOperation(name = SVC_OP_NAME_BIC_DIRECTORY_SERVICE_CREATE)
    BicDirectory create(BicDirectory dataObject);

    @ServiceOperation(name = SVC_OP_NAME_BIC_DIRECTORY_SERVICE_UPDATE)
    BicDirectory update(BicDirectory dataObject);

    @ServiceOperation(name = SVC_OP_NAME_BIC_DIRECTORY_SERVICE_QUERY)
    List<BicDirectory> query(int offset, int resultLimit, String groupBy, String order, Map<String, Object> filters);

    @ServiceOperation(name = SVC_OP_NAME_BIC_DIRECTORY_SERVICE_DELETE)
    boolean delete(BicDirectory dataObject);

    @ServiceOperation(name = SVC_OP_NAME_BIC_DIRECTORY_SERVICE_FIND)
    List<BicDirectory> find(FindCriteria findCriteria, CbsHeader cbsHeader);

}
