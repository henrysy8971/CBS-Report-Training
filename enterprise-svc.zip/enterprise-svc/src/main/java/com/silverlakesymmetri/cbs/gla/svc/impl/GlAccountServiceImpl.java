package com.silverlakesymmetri.cbs.gla.svc.impl;

import java.util.*;

import com.silverlakesymmetri.cbs.commons.bdo.ViewCriteriaItem;
import com.silverlakesymmetri.cbs.commons.bdo.ViewCriteriaRow;
import com.silverlakesymmetri.cbs.commons.context.CbsRuntimeContextManager;
import com.silverlakesymmetri.cbs.commons.context.CbsSessionContext;
import com.silverlakesymmetri.cbs.commons.jpa.entity.FindCriteriaJpe;
import com.silverlakesymmetri.cbs.csd.gla.jpa.mapping.sdo.ChartAccountJpe;
import com.silverlakesymmetri.cbs.gla.jpa.mapping.sdo.GlManualBatchGlCodeQryJpe;
import com.silverlakesymmetri.cbs.mcl.jpa.mapping.sdo.ClientJpe;
import com.silverlakesymmetri.cbs.pim.jpa.mapping.sdo.MasterSdbAcctJpe;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.mysema.query.types.EntityPath;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.jpa.service.CbsGenericDataService;
import com.silverlakesymmetri.cbs.commons.svc.AbstractXmlApiBusinessService;
import com.silverlakesymmetri.cbs.commons.xmlapi.enums.CbsXmlApiOperation;
import com.silverlakesymmetri.cbs.csd.jpa.mapping.sdo.util.CsdJpeConstants;
import com.silverlakesymmetri.cbs.gla.bdo.sdo.GlAccount;
import com.silverlakesymmetri.cbs.gla.jpa.mapping.sdo.GlAccountJpe;
import com.silverlakesymmetri.cbs.gla.jpa.mapping.sdo.QGlAccountJpe;
import com.silverlakesymmetri.cbs.gla.jpa.mapping.sdo.id.GlAccountPk;
import com.silverlakesymmetri.cbs.gla.jpa.mapping.sdo.util.GlaJpeConstants;
import com.silverlakesymmetri.cbs.gla.svc.GlAccountService;
import com.silverlakesymmetri.cbs.gla.xmlapi.GLAACCTAPIType;
import com.silverlakesymmetri.cbs.mcl.jpa.mapping.sdo.util.MclJpeConstants;
import com.silverlakesymmetri.cbs.commons.helper.jpa.LinkTable;
import com.silverlakesymmetri.cbs.commons.helper.jpa.QueryCondition;
import com.silverlakesymmetri.cbs.commons.helper.jpa.QueryType;
@SuppressWarnings("OverwrittenKey")
@Service
@Transactional
public class GlAccountServiceImpl extends AbstractXmlApiBusinessService<GlAccount, GlAccountJpe, Long, GLAACCTAPIType, GLAACCTAPIType> implements GlAccountService {

	@Autowired
	private CbsGenericDataService dataService;

    @Autowired
    private CbsRuntimeContextManager cbsRuntimeContextManager;

	private static final String PERCENT = "%";
	private static final String ACCT_NO = "acctNo";
	private static final String CLIENT_NO = "clientNo";
	private static final String NOS_VOS_NO = "nosVosNo";
	private static final String CCY = "ccy";
	private static final String BRANCH = "branch";
	private static final String VALID_NOS_VOS_NO_LIST = "validNosVosNoList";
    private static LinkedHashMap<String, LinkTable> constructorMap;
    private static QueryCondition condition;
    static {
        constructorMap = new LinkedHashMap<String, LinkTable>();
        constructorMap.put("internalKey", new LinkTable(GlAccountJpe.class));
        constructorMap.put("glType", new LinkTable(GlAccountJpe.class));
        constructorMap.put("branch", new LinkTable(GlAccountJpe.class));
        constructorMap.put("ccy", new LinkTable(GlAccountJpe.class));
        constructorMap.put("clientId", new LinkTable(GlAccountJpe.class));
        constructorMap.put("clientNo", new LinkTable(ClientJpe.class));
        constructorMap.put("acctType", new LinkTable(GlAccountJpe.class));
        constructorMap.put("glCode", new LinkTable(GlAccountJpe.class));
        constructorMap.put("profitCentre", new LinkTable(GlAccountJpe.class));
        constructorMap.put("seqNo", new LinkTable(GlAccountJpe.class));
        constructorMap.put("acctOpenDate", new LinkTable(GlAccountJpe.class));
        constructorMap.put("acctDesc", new LinkTable(GlAccountJpe.class));
        constructorMap.put("nosVosNo", new LinkTable(GlAccountJpe.class));
        constructorMap.put("acctNo", new LinkTable(GlAccountJpe.class));
        constructorMap.put("nrRecon", new LinkTable(GlAccountJpe.class));
        constructorMap.put("acctCloseDate", new LinkTable(GlAccountJpe.class));
        constructorMap.put("acctStatus", new LinkTable(GlAccountJpe.class));
        constructorMap.put("ledgerBal", new LinkTable(GlAccountJpe.class));
        constructorMap.put("actualBal", new LinkTable(GlAccountJpe.class));
        constructorMap.put("olLedgerBal", new LinkTable(GlAccountJpe.class));
        constructorMap.put("olActualBal", new LinkTable(GlAccountJpe.class));
        constructorMap.put("glCtrlDate", new LinkTable(GlAccountJpe.class));
        constructorMap.put("aggBalCtd", new LinkTable(GlAccountJpe.class));
        constructorMap.put("ctdDays", new LinkTable(GlAccountJpe.class));
        constructorMap.put("aggBalMtd", new LinkTable(GlAccountJpe.class));
        constructorMap.put("mtdDays", new LinkTable(GlAccountJpe.class));
        constructorMap.put("aggBalYtd", new LinkTable(GlAccountJpe.class));
        constructorMap.put("ytdDays", new LinkTable(GlAccountJpe.class));
        constructorMap.put("accruedBal", new LinkTable(GlAccountJpe.class));
        constructorMap.put("acctCloseReason", new LinkTable(GlAccountJpe.class));
        constructorMap.put("wsId", new LinkTable(GlAccountJpe.class));
        constructorMap.put("openTranDate", new LinkTable(GlAccountJpe.class));
        constructorMap.put("mtdBal", new LinkTable(GlAccountJpe.class));
        constructorMap.put("ytdBal", new LinkTable(GlAccountJpe.class));
        constructorMap.put("baseEffectRate", new LinkTable(GlAccountJpe.class));
        constructorMap.put("baseQuote", new LinkTable(GlAccountJpe.class));
        constructorMap.put("baseEquiv", new LinkTable(GlAccountJpe.class));
        constructorMap.put("localEffectRate", new LinkTable(GlAccountJpe.class));
        constructorMap.put("localQuote", new LinkTable(GlAccountJpe.class));
        constructorMap.put("localEquiv", new LinkTable(GlAccountJpe.class));
        constructorMap.put("actualAggBalCtd", new LinkTable(GlAccountJpe.class));
        constructorMap.put("actualAggBalMtd", new LinkTable(GlAccountJpe.class));
        constructorMap.put("actualAggBalYtd", new LinkTable(GlAccountJpe.class));
        constructorMap.put("actualMtdBal", new LinkTable(GlAccountJpe.class));
        constructorMap.put("actualYtdBal", new LinkTable(GlAccountJpe.class));
        constructorMap.put("actualCtdDays", new LinkTable(GlAccountJpe.class));
        constructorMap.put("actualMtdDays", new LinkTable(GlAccountJpe.class));
        constructorMap.put("actualYtdDays", new LinkTable(GlAccountJpe.class));
        constructorMap.put("ledgerBalO", new LinkTable(GlAccountJpe.class));
        constructorMap.put("actualBalO", new LinkTable(GlAccountJpe.class));
        constructorMap.put("ledgerBalV", new LinkTable(GlAccountJpe.class));
        constructorMap.put("actualBalV", new LinkTable(GlAccountJpe.class));
        constructorMap.put("ledgerBalT", new LinkTable(GlAccountJpe.class));
        constructorMap.put("actualBalT", new LinkTable(GlAccountJpe.class));
        constructorMap.put("ledgerBalR", new LinkTable(GlAccountJpe.class));
        constructorMap.put("actualBalR", new LinkTable(GlAccountJpe.class));
        constructorMap.put("crAcctLevelIntRate", new LinkTable(GlAccountJpe.class));
        constructorMap.put("crIntType", new LinkTable(GlAccountJpe.class));
        constructorMap.put("expenseGlCode", new LinkTable(GlAccountJpe.class));
        constructorMap.put("taxableInd", new LinkTable(GlAccountJpe.class));
        constructorMap.put("taxType", new LinkTable(GlAccountJpe.class));
        constructorMap.put("taxGlCode", new LinkTable(GlAccountJpe.class));
        constructorMap.put("crPeriodFreq", new LinkTable(GlAccountJpe.class));
        constructorMap.put("crNextCycleDate", new LinkTable(GlAccountJpe.class));
        constructorMap.put("crIntDay", new LinkTable(GlAccountJpe.class));
        constructorMap.put("crIntCap", new LinkTable(GlAccountJpe.class));
        constructorMap.put("crIntAccruedCtd", new LinkTable(GlAccountJpe.class));
        constructorMap.put("crIntCalcCtd", new LinkTable(GlAccountJpe.class));
        constructorMap.put("crIntAccruedMtd", new LinkTable(GlAccountJpe.class));
        constructorMap.put("intPaidYtd", new LinkTable(GlAccountJpe.class));
        constructorMap.put("intPaidMtd", new LinkTable(GlAccountJpe.class));
        constructorMap.put("intPaidLastYear", new LinkTable(GlAccountJpe.class));
        constructorMap.put("crIntPosted", new LinkTable(GlAccountJpe.class));
        constructorMap.put("crIntAdj", new LinkTable(GlAccountJpe.class));
        constructorMap.put("crLastAccruedDate", new LinkTable(GlAccountJpe.class));
        constructorMap.put("crLastCycleDate", new LinkTable(GlAccountJpe.class));
        constructorMap.put("crBaseEffectRate", new LinkTable(GlAccountJpe.class));
        constructorMap.put("crBaseQuote", new LinkTable(GlAccountJpe.class));
        constructorMap.put("crBaseEquiv", new LinkTable(GlAccountJpe.class));
        constructorMap.put("crLocalEffectRate", new LinkTable(GlAccountJpe.class));
        constructorMap.put("crLocalQuote", new LinkTable(GlAccountJpe.class));
        constructorMap.put("crLocalEquiv", new LinkTable(GlAccountJpe.class));
        constructorMap.put("drAcctLevelIntRate", new LinkTable(GlAccountJpe.class));
        constructorMap.put("drIntType", new LinkTable(GlAccountJpe.class));
        constructorMap.put("incomeGlCode", new LinkTable(GlAccountJpe.class));
        constructorMap.put("drPeriodFreq", new LinkTable(GlAccountJpe.class));
        constructorMap.put("drNextCycleDate", new LinkTable(GlAccountJpe.class));
        constructorMap.put("drIntDay", new LinkTable(GlAccountJpe.class));
        constructorMap.put("drIntCap", new LinkTable(GlAccountJpe.class));
        constructorMap.put("drIntAccruedCtd", new LinkTable(GlAccountJpe.class));
        constructorMap.put("drIntCalcCtd", new LinkTable(GlAccountJpe.class));
        constructorMap.put("drIntAccruedMtd", new LinkTable(GlAccountJpe.class));
        constructorMap.put("intCollYtd", new LinkTable(GlAccountJpe.class));
        constructorMap.put("intCollMtd", new LinkTable(GlAccountJpe.class));
        constructorMap.put("intCollLastYear", new LinkTable(GlAccountJpe.class));
        constructorMap.put("drIntPosted", new LinkTable(GlAccountJpe.class));
        constructorMap.put("drIntAdj", new LinkTable(GlAccountJpe.class));
        constructorMap.put("drLastAccruedDate", new LinkTable(GlAccountJpe.class));
        constructorMap.put("drLastCycleDate", new LinkTable(GlAccountJpe.class));
        constructorMap.put("drBaseEffectRate", new LinkTable(GlAccountJpe.class));
        constructorMap.put("drBaseQuote", new LinkTable(GlAccountJpe.class));
        constructorMap.put("drBaseEquiv", new LinkTable(GlAccountJpe.class));
        constructorMap.put("drLocalEffectRate", new LinkTable(GlAccountJpe.class));
        constructorMap.put("drLocalQuote", new LinkTable(GlAccountJpe.class));
        constructorMap.put("drLocalEquiv", new LinkTable(GlAccountJpe.class));
        constructorMap.put("nbcCode", new LinkTable(GlAccountJpe.class));
        constructorMap.put("repCode", new LinkTable(GlAccountJpe.class));
        constructorMap.put("glCodeDesc", new LinkTable(ChartAccountJpe.class));
        constructorMap.put("activeYn", new LinkTable(ChartAccountJpe.class));
        constructorMap.put("restrictManualBatchYn", new LinkTable(ChartAccountJpe.class));

        condition = new QueryCondition();
        condition.where("glCode", QueryType.EQUALS, new LinkTable(ChartAccountJpe.class, "glCode"))
                .and("clientId", QueryType.EQUALS, new LinkTable(ClientJpe.class, "clientId"))
                .and("orgId", QueryType.EQUALS, new LinkTable(ChartAccountJpe.class, "orgId"));
    }

	@Override
	protected Long getIdFromDataObjectInstance(GlAccount dataObject) {
        Map<String, Object> params = new HashMap<String, Object>();
        params.put(BRANCH, dataObject.getBranch());
        params.put("ccy", dataObject.getCcy());
        params.put("clientId", getClientId(dataObject.getClientNo()));
        params.put("profitCentre", dataObject.getProfitCentre());
        params.put("glCode", dataObject.getGlCode());
        params.put("seqNo", dataObject.getSeqNo());
        Long result = dataService.getWithNamedQuery(GlaJpeConstants.GLA_ACCOUNT_JPE_FIND_BY_PUBLIC_KEY, params, Long.class);

        return result;
	}

	@Override
	protected EntityPath<GlAccountJpe> getEntityPath() {
		return QGlAccountJpe.glAccountJpe;
	}

	@Override
	public GlAccount create(GlAccount dataObject) {
		return super.create(dataObject);
	}

	@Override
	protected GlAccount preCreateValidation(GlAccount dataObject) {
		performDefaulting(dataObject);
		return super.preCreateValidation(dataObject);
	}
	
	@Override
	protected GlAccount preUpdateValidation(GlAccount dataObject) {
		return super.preUpdateValidation(dataObject);
	}

	private void performDefaulting(GlAccount dataObject) {
		if (null != dataObject) {
			if (null == dataObject.getCrIntCap()) {
			    dataObject.setCrIntCap("N");
			}
			if (null == dataObject.getDrIntCap()) {
			    dataObject.setDrIntCap("N");
			}
			if (null == dataObject.getNrRecon()) {
			    dataObject.setNrRecon("N");
			}
			if (null == dataObject.getTaxableInd()) {
			    dataObject.setTaxableInd("N");
			}
			if (null == dataObject.getAcctStatus()) {
                dataObject.setAcctStatus("N");
            }
			
			//numeric defaulting to zero
			if(dataObject.getLedgerBal() == null){ dataObject.setLedgerBal(0.0); }
			if(dataObject.getActualBal() == null){ dataObject.setActualBal(0.0); }
			if(dataObject.getOlLedgerBal() == null){ dataObject.setOlLedgerBal(0.0); }
			if(dataObject.getOlActualBal() == null){ dataObject.setOlActualBal(0.0); }
			if(dataObject.getAggBalCtd() == null){ dataObject.setAggBalCtd(0.0); }
			if(dataObject.getCtdDays() == null){ dataObject.setCtdDays(0.0); }
			if(dataObject.getAggBalMtd() == null){ dataObject.setAggBalMtd(0.0); }
			if(dataObject.getMtdDays() == null){ dataObject.setMtdDays(0.0); }
			if(dataObject.getAggBalYtd() == null){ dataObject.setAggBalYtd(0.0); }
			if(dataObject.getYtdDays() == null){ dataObject.setYtdDays(0.0); }
			if(dataObject.getAccruedBal() == null){ dataObject.setAccruedBal(0.0); }
			if(dataObject.getMtdBal() == null){ dataObject.setMtdBal(0.0); }
			if(dataObject.getYtdBal() == null){ dataObject.setYtdBal(0.0); }
			if(dataObject.getActualAggBalCtd() == null){ dataObject.setActualAggBalCtd(0.0); }
			if(dataObject.getActualAggBalMtd() == null){ dataObject.setActualAggBalMtd(0.0); }
			if(dataObject.getActualAggBalYtd() == null){ dataObject.setActualAggBalYtd(0.0); }
			if(dataObject.getActualMtdBal() == null){ dataObject.setActualMtdBal(0.0); }
			if(dataObject.getActualYtdBal() == null){ dataObject.setActualYtdBal(0.0); }
			if(dataObject.getActualCtdDays() == null){ dataObject.setActualCtdDays(0.0); }
			if(dataObject.getActualMtdDays() == null){ dataObject.setActualMtdDays(0.0); }
			if(dataObject.getActualYtdDays() == null){ dataObject.setActualYtdDays(0.0); }
		}
	}
	
	@Override
	public GlAccount get(GlAccount objectInstanceIdentifier) {
		return super.get(objectInstanceIdentifier);
	}

	@Override
	public List<GlAccount> query(int offset, int resultLimit, String groupBy, String order,
			Map<String, Object> filters) {
		if (filters != null) {
			if (filters.get(VALID_NOS_VOS_NO_LIST) != null && 
					Boolean.parseBoolean(filters.remove(VALID_NOS_VOS_NO_LIST).toString())) {				
				if (filters.get(BRANCH) == null) {
					filters.put(BRANCH, PERCENT);					
				}
				if (filters.get(CCY) == null) {
					filters.put(CCY, PERCENT);
				}
				if (filters.get(NOS_VOS_NO) == null) {
					filters.put(NOS_VOS_NO, PERCENT);
				}
				if (filters.get(CLIENT_NO) == null) {
					filters.put(CLIENT_NO, PERCENT);
				}
				if (filters.get(ACCT_NO) == null) {
					filters.put(ACCT_NO, PERCENT);
				}
				
				List<GlAccountJpe> jpeList = dataService.findWithNamedQuery(
						GlaJpeConstants.GLA_ACCOUNT_JPE_FIND_VALID_NOS_VOS_NO, filters, offset, resultLimit, GlAccountJpe.class);
				
				List<GlAccount> returnList = new ArrayList<>();
				if (jpeList != null && jpeList.size() > 0) {
					for (GlAccountJpe jpe : jpeList) {
						GlAccount bdo = jaxbSdoHelper.wrap(jpe, GlAccount.class);
						returnList.add(bdo);
					}
				}
				return returnList;
			}
		}
        QueryCondition newCondition = convertFilters(condition, filters, constructorMap);
        return super.query(newCondition, offset, resultLimit, groupBy, order, constructorMap);
    }

	@Override
	public GlAccount update(GlAccount dataObject) {
		return super.update(dataObject);
	}

	@Override
	public boolean delete(GlAccount dataObject) {
		return super.delete(dataObject);
	}

	@Override
	public List<GlAccount> find(FindCriteria findCriteria, CbsHeader cbsHeader) {
        //To map correct attributes
        FindCriteriaJpe findCriteriaJpe = (FindCriteriaJpe)this.jaxbSdoHelper.unwrap(findCriteria, true);
        findCriteriaJpe.getFindAttribute().clear();
        return super.find(findCriteria, cbsHeader, constructorMap, condition);
	}

    @Override
    public Long count(FindCriteria findCriteria, CbsHeader cbsHeader) {
        if(findCriteria == null){
            return dataService.getRowCount(this.getEntityPath());
        }
        else{
            FindCriteriaJpe jpe = jaxbSdoHelper.unwrap(findCriteria, FindCriteriaJpe.class);
            return dataService.getRowCount(GlAccountJpe.class, jpe, constructorMap, condition);
        }
    }

	@Override
	public GlAccount getByPk(String publicKey, GlAccount reference) {
		return super.getByPk(publicKey, reference);
	}

    @Override
    protected Class<GLAACCTAPIType> getXmlApiResponseClass() {
        return GLAACCTAPIType.class;
    }

    @Override
    protected List<GlAccount> processXmlApiListRs(GlAccount arg0, GLAACCTAPIType arg1) {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    protected GlAccount processXmlApiRs(GlAccount arg0, GLAACCTAPIType arg1) {
        //TODO Auto-generated method stub
        if (arg1 != null) {
            Long internalKey = arg1.getINTERNALKEY();
            if (internalKey != null) {
                GlAccountJpe glAcctJpe = dataService.find(GlAccountJpe.class, new GlAccountPk(internalKey));
                return jaxbSdoHelper.wrap(glAcctJpe, GlAccount.class);
            }
        }
        
        return arg0;
    }

    @Override
    protected GLAACCTAPIType transformBdoToXmlApiRqCreate(GlAccount dataObject) {
        return tranformGlAccountToGLAACCTAPIType(dataObject, CbsXmlApiOperation.INSERT);
    }

    @Override
    protected GLAACCTAPIType transformBdoToXmlApiRqDelete(GlAccount dataObject) {
        return tranformGlAccountToGLAACCTAPIType(dataObject, CbsXmlApiOperation.DELETE);
    }

    @Override
    protected GLAACCTAPIType transformBdoToXmlApiRqUpdate(GlAccount dataObject) {
        return tranformGlAccountToGLAACCTAPIType(dataObject, CbsXmlApiOperation.UPDATE);
    }
    
    private GLAACCTAPIType tranformGlAccountToGLAACCTAPIType(GlAccount bdo, CbsXmlApiOperation oper) {
        GLAACCTAPIType xmlApiObj = new GLAACCTAPIType();
        xmlApiObj.setOPERATION(oper.getOperation());
        
        super.setTechColsFromDataObject(bdo, xmlApiObj);

        xmlApiObj.setOPERATION(oper.getOperation());
        
        xmlApiObj.setGLTYPE(bdo.getGlType());
        
        xmlApiObj.setBRANCH(bdo.getBranch());
        
        xmlApiObj.setCCY(bdo.getCcy());
        
        xmlApiObj.setCLIENTNO(getClientId(bdo.getClientNo()));
        
        xmlApiObj.setACCTTYPE(bdo.getAcctType());
        
        xmlApiObj.setGLCODE(bdo.getGlCode());
        
        xmlApiObj.setSEQNO(bdo.getSeqNo());

        xmlApiObj.setPROFITCENTRE(bdo.getProfitCentre());

        xmlApiObj.setACCTOPENDATE(dateTimeHelper.convertToCbsXmlApiDate(bdo.getAcctOpenDate()));
        
        xmlApiObj.setACCTDESC(bdo.getAcctDesc());
        
        xmlApiObj.setNOSVOSNO(bdo.getNosVosNo());
        
        xmlApiObj.setACCTNO(bdo.getAcctNo());
        
        xmlApiObj.setNRRECON(bdo.getNrRecon());

        xmlApiObj.setINTERNALKEY(getInternalKey(bdo));
        
        xmlApiObj.setACCTCLOSEDATE(dateTimeHelper.convertToCbsXmlApiDate(bdo.getAcctCloseDate()));
        
        xmlApiObj.setACCTSTATUS(bdo.getAcctStatus());
        
        xmlApiObj.setLEDGERBAL(bdo.getLedgerBal());
        
        xmlApiObj.setACTUALBAL(bdo.getAccruedBal());
        
        xmlApiObj.setOLLEDGERBAL(bdo.getOlLedgerBal());
        
        xmlApiObj.setOLACTUALBAL(bdo.getOlActualBal());
        
        xmlApiObj.setGLCTRLDATE(dateTimeHelper.convertToCbsXmlApiDate(bdo.getGlCtrlDate()));
        
        xmlApiObj.setAGGBALCTD(bdo.getAggBalCtd());
        
        xmlApiObj.setCTDDAYS(bdo.getCtdDays());
        
        xmlApiObj.setAGGBALMTD(bdo.getAggBalMtd());
        
        xmlApiObj.setMTDDAYS(bdo.getMtdDays());
        
        xmlApiObj.setAGGBALYTD(bdo.getAggBalYtd());
        
        xmlApiObj.setYTDDAYS(bdo.getYtdDays());
        
        xmlApiObj.setACCRUEDBAL(bdo.getAccruedBal());
        
        xmlApiObj.setACCTCLOSEREASON(bdo.getAcctCloseReason());
        
        xmlApiObj.setWSID(bdo.getWsId());
        
        xmlApiObj.setOPENTRANDATE(dateTimeHelper.convertToCbsXmlApiDate(bdo.getOpenTranDate()));
        
        xmlApiObj.setMTDBAL(bdo.getMtdBal());
        
        xmlApiObj.setYTDBAL(bdo.getYtdBal());
        
        xmlApiObj.setBASEEFFECTRATE(bdo.getBaseEffectRate());
        
        xmlApiObj.setBASEQUOTE(bdo.getBaseQuote());
        
        xmlApiObj.setBASEEQUIV(bdo.getBaseEquiv());
        
        xmlApiObj.setLOCALEFFECTRATE(bdo.getLocalEffectRate());
        
        xmlApiObj.setLOCALQUOTE(bdo.getLocalQuote());
        
        xmlApiObj.setLOCALEQUIV(bdo.getLocalEquiv());
        
        xmlApiObj.setACTUALAGGBALCTD(bdo.getActualAggBalCtd());
        
        xmlApiObj.setACTUALAGGBALMTD(bdo.getActualAggBalMtd());
        
        xmlApiObj.setACTUALAGGBALYTD(bdo.getActualAggBalYtd());
        
        xmlApiObj.setACTUALMTDBAL(bdo.getActualMtdBal());
        
        xmlApiObj.setACTUALYTDBAL(bdo.getActualYtdBal());
        
        xmlApiObj.setACTUALCTDDAYS(bdo.getActualCtdDays());
        
        xmlApiObj.setACTUALMTDDAYS(bdo.getActualMtdDays());
        
        xmlApiObj.setACTUALYTDDAYS(bdo.getActualYtdDays());
        
        xmlApiObj.setLEDGERBALO(bdo.getLedgerBalO());
        
        xmlApiObj.setACTUALBALO(bdo.getActualBalO());
        
        xmlApiObj.setLEDGERBALV(bdo.getLedgerBalV());
        
        xmlApiObj.setACTUALBALV(bdo.getActualBalV());
        
        xmlApiObj.setLEDGERBALT(bdo.getLedgerBalT());
        
        xmlApiObj.setACTUALBALT(bdo.getActualBalT());
        
        xmlApiObj.setLEDGERBALR(bdo.getLedgerBalR());
        
        xmlApiObj.setACTUALBALR(bdo.getActualBalR());

        xmlApiObj.setCRACCTLEVELINTRATE(bdo.getCrAcctLevelIntRate());
        
        xmlApiObj.setCRINTTYPE(bdo.getCrIntType());
        
        xmlApiObj.setEXPENSEGLCODE(bdo.getExpenseGlCode());
        
        xmlApiObj.setTAXABLEIND(bdo.getTaxableInd());
        
        xmlApiObj.setTAXTYPE(bdo.getTaxType());
        
        xmlApiObj.setTAXGLCODE(bdo.getTaxGlCode());
        
        xmlApiObj.setCRPERIODFREQ(bdo.getCrPeriodFreq());
        
        xmlApiObj.setCRNEXTCYCLEDATE(dateTimeHelper.convertToCbsXmlApiDate(bdo.getCrNextCycleDate()));
        
        xmlApiObj.setCRINTDAY(bdo.getCrIntDay());
        
        xmlApiObj.setCRINTCAP(bdo.getCrIntCap());
        
        xmlApiObj.setCRINTACCRUEDCTD(bdo.getCrIntAccruedCtd());
        
        xmlApiObj.setCRINTCALCCTD(bdo.getCrIntCalcCtd());
        
        xmlApiObj.setCRINTACCRUEDMTD(bdo.getCrIntAccruedMtd());
        
        xmlApiObj.setINTPAIDYTD(bdo.getIntPaidYtd());
        
        xmlApiObj.setINTPAIDMTD(bdo.getIntPaidMtd());
        
        xmlApiObj.setINTPAIDLASTYEAR(bdo.getIntPaidLastYear());
        
        xmlApiObj.setCRINTPOSTED(bdo.getCrIntPosted());
        
        xmlApiObj.setCRINTADJ(bdo.getCrIntAdj());
        
        xmlApiObj.setCRLASTACCRUEDDATE(dateTimeHelper.convertToCbsXmlApiDate(bdo.getCrLastAccruedDate()));
        
        xmlApiObj.setCRLASTCYCLEDATE(dateTimeHelper.convertToCbsXmlApiDate(bdo.getCrLastCycleDate()));
        
        xmlApiObj.setCRBASEEFFECTRATE(bdo.getCrBaseEffectRate());
        
        xmlApiObj.setCRBASEQUOTE(bdo.getCrBaseQuote());
        
        xmlApiObj.setCRBASEEQUIV(bdo.getCrBaseEquiv());
        
        xmlApiObj.setCRLOCALEFFECTRATE(bdo.getCrLocalEffectRate());
        
        xmlApiObj.setCRLOCALQUOTE(bdo.getCrLocalQuote());
        
        xmlApiObj.setCRLOCALEQUIV(bdo.getCrLocalEquiv());
        
        xmlApiObj.setDRACCTLEVELINTRATE(bdo.getDrAcctLevelIntRate());
        
        xmlApiObj.setDRINTTYPE(bdo.getDrIntType());
        
        xmlApiObj.setINCOMEGLCODE(bdo.getIncomeGlCode());
        
        xmlApiObj.setDRPERIODFREQ(bdo.getDrPeriodFreq());
        
        xmlApiObj.setDRNEXTCYCLEDATE(dateTimeHelper.convertToCbsXmlApiDate(bdo.getDrNextCycleDate()));
        
        xmlApiObj.setDRINTDAY(bdo.getDrIntDay());
        
        xmlApiObj.setDRINTCAP(bdo.getDrIntCap());
        
        xmlApiObj.setDRINTACCRUEDCTD(bdo.getDrIntAccruedCtd());
        
        xmlApiObj.setDRINTCALCCTD(bdo.getDrIntCalcCtd());
        
        xmlApiObj.setDRINTACCRUEDMTD(bdo.getDrIntAccruedMtd());
        
        xmlApiObj.setINTCOLLYTD(bdo.getIntCollYtd());
        
        xmlApiObj.setINTCOLLMTD(bdo.getIntCollMtd());
        
        xmlApiObj.setINTCOLLLASTYEAR(bdo.getIntCollLastYear());
        
        xmlApiObj.setDRINTPOSTED(bdo.getDrIntPosted());
        
        xmlApiObj.setDRINTADJ(bdo.getDrIntAdj());
        
        xmlApiObj.setDRLASTACCRUEDDATE(dateTimeHelper.convertToCbsXmlApiDate(bdo.getDrLastAccruedDate()));
        
        xmlApiObj.setDRLASTCYCLEDATE(dateTimeHelper.convertToCbsXmlApiDate(bdo.getDrLastCycleDate()));
        
        xmlApiObj.setDRBASEEFFECTRATE(bdo.getDrBaseEffectRate());
        
        xmlApiObj.setDRBASEQUOTE(bdo.getDrBaseQuote());
        
        xmlApiObj.setDRBASEEQUIV(bdo.getDrBaseEquiv());
        
        xmlApiObj.setDRLOCALEFFECTRATE(bdo.getDrLocalEffectRate());
        
        xmlApiObj.setDRLOCALQUOTE(bdo.getDrLocalQuote());
        
        xmlApiObj.setDRLOCALEQUIV(bdo.getDrLocalEquiv());
        xmlApiObj.setNBCCODE(bdo.getNbcCode());
        if (bdo.getRepCode() != null) {
            xmlApiObj.setREPCODE(new Long(bdo.getRepCode()));
        }
        


        if (CbsXmlApiOperation.INSERT.equals(oper)) {
            

        } else if (CbsXmlApiOperation.UPDATE.equals(oper)) {
            
        }
        return xmlApiObj;
    }

    private Long getClientId(String clientNo) {
        Map<String, Object> params = new HashMap<String, Object>();
        params.put(CLIENT_NO, clientNo);
        Long clientId = dataService.getWithNamedQuery(MclJpeConstants.CLIENT_JPE_FIND_CLIENT_ID_USING_CLIENT_NO, params, Long.class);       
        
        return clientId;
    }
    
    private Long getInternalKey(GlAccount glAccount) {
        Long internalKey=null;
        Map<String, Object> params = new HashMap<String, Object>();
        params.put(BRANCH, glAccount.getBranch());
        params.put("ccy", glAccount.getCcy());
        params.put("clientId", getClientId(glAccount.getClientNo()));
        params.put("profitCentre", glAccount.getProfitCentre());
        params.put("glCode", glAccount.getGlCode());
        params.put("seqNo", glAccount.getSeqNo());
        List <GlAccountJpe> glList = dataService.findWithNamedQuery(GlaJpeConstants.GLA_ACCOUNT_JPE_FIND_BY_PUBLIC_KEY, params, GlAccountJpe.class); 
        if (glList.size()> 0) {
            internalKey = glList.get(0).getInternalKey();
        }
        return internalKey;
    }

	@Override
	public List<String> getautointacctcreationglcodes() {
		return dataService.findWithQuery("SELECT DISTINCT t.glCode FROM GlAccountJpe t WHERE t.acctStatus NOT IN ('C','P')", String.class);
	}

    @Override
    public List<GlAccount> findGlCodeForDwp(Map<String, Object> queryParams) {
        String glCode = (String) queryParams.get("glCode");
        String glDesc = (String) queryParams.get("acctDesc"); //GlAccount BDO doesn't have glDesc that is why we are using a different field as a work around
        String ccy = (String) queryParams.get("ccy");
        String clientNo = (String) queryParams.get("clientNo");
        String acctType = (String) queryParams.get("acctType");
        String branch = (String) queryParams.get("branch");
        String seqNo = (String) queryParams.get("seqNo");
        String profitCentre = (String) queryParams.get("profitCentre");

        int limit = queryParams.get("limit") != null ? Integer.parseInt((String)queryParams.get("limit")) : 10;
        int offset = queryParams.get("offset") != null ? Integer.parseInt((String)queryParams.get("offset")) : 0;

        long orgId = cbsRuntimeContextManager.getContext(CbsSessionContext.class).getOrgId();

        Long clientId = null;
        if(clientNo != null) {
            clientId = getClientId(clientNo);
        }
        List<GlAccount> result = new ArrayList<>();
        String query = GlaJpeConstants.DEFAULT_WAY_PAYMENT_FIND_GL_CODE_QUERY;
        final Map<String, Object> params = new HashMap<>();
        params.put("ccy", ccy);
        params.put("client_no", clientId);
        params.put("acct_type", acctType);
        params.put("org_id", orgId);

        if(glCode != null){
            query = query + " AND gm.gl_code like ?glCode";
            params.put("glCode", "%" + glCode + "%");
        }

        if(glDesc != null) {
            query = query + " AND gm.gl_code_desc like ?glDesc";
            params.put("glDesc", "%" + glDesc.toUpperCase() + "%");
        }

        if(branch != null) {
            query = query + " AND ga.branch like ?branch";
            params.put("branch", "%" + branch.toUpperCase() + "%");
        }

        if(seqNo != null) {
            query = query + " AND ga.seq_no = ?seqNo";
            params.put("seqNo", seqNo.toUpperCase());
        }

        if(profitCentre != null) {
            query = query + " AND ga.profit_centre like ?profitCentre";
            params.put("profitCentre", "%" + profitCentre.toUpperCase() + "%");
        }

        List<GlAccountJpe> list = dataService.findWithNativeQuery(query, params, offset, limit, GlAccountJpe.class);

        for (GlAccountJpe o : list) {
            GlAccount bdo = jaxbSdoHelper.wrap(o, GlAccount.class);
            result.add(bdo);
        }

        return result;
    }
    
    @Override
    public List<GlAccount> lovForSeqNoCashFlowMap(Map<String, Object> queryParams) {
        String ccy = (String) queryParams.get("ccy");
        String clientNo = (String) queryParams.get("clientNo");
        String branch = (String) queryParams.get("branch");
        String profitCentre = (String) queryParams.get("profitCentre");
        String glCode = (String) queryParams.get("glCode");
        String seqNo = (String) queryParams.get("seqNo");
        String acctNo = (String) queryParams.get("acctNo");
        String acctDesc = (String) queryParams.get("acctDesc");
        int limit = queryParams.get("limit") != null ? Integer.parseInt((String)queryParams.get("limit")) : 10;
        int offset = queryParams.get("offset") != null ? Integer.parseInt((String)queryParams.get("offset")) : 0;
        String groupBy = (String) queryParams.get("groupBy");
        String order = (String) queryParams.get("order");

        String query = CsdJpeConstants.CASH_FLOW_MAP_SEQ_NO;

        List<GlAccount> list = new ArrayList<GlAccount>();
        final Map<String, Object> parameters = new HashMap<>();
        
        if(seqNo != null){
			query = query + " AND ga.seqNo = :seqNo";
			parameters.put("seqNo", Integer.valueOf(seqNo));
        }
        
        if(acctNo != null){
			query = query + " AND ga.acctNo = :acctNo";
			parameters.put("acctNo", acctNo);
        }
        
        if(acctDesc != null){
			query = query + " AND ga.acctDesc = :acctDesc";
			parameters.put("acctDesc", acctDesc);
        }
        
        if(glCode != null){
			query = query + " AND ga.glCode = :glCode";
			parameters.put("glCode", glCode);
        }
        
        if(profitCentre != null){
			query = query + " AND ga.profitCentre = :profitCentre";
			parameters.put("profitCentre", profitCentre);
        }
        
        if(branch != null){
			query = query + " AND ga.branch = :branch";
			parameters.put("branch", branch);
        }
        
        if(ccy != null){
			query = query + " AND ga.ccy = :ccy";
			parameters.put("ccy", ccy);
        }

        if(clientNo != null) {
    		Long clientId = getClientId(clientNo);
			query = query + " AND ga.clientId = :clientId";
			parameters.put("clientId", clientId);
        }

        appendOrderByToQuery(query, "ga", groupBy, order);
        List<GlAccountJpe> jpeList = dataService.findWithQuery(query, parameters, offset, limit, GlAccountJpe.class);
        
        if(jpeList != null && !jpeList.isEmpty()) {
	        for (GlAccountJpe jpe : jpeList) {
	        	list.add(jaxbSdoHelper.wrap(jpe, GlAccount.class));
	        }
        }
        return list;
    }

    @Override
    public List<GlAccount> findSeqNoForBatch(Map<String, Object> queryParams) {
        String acctNo = (String) queryParams.get("acctNo");
        String ccy = (String) queryParams.get("ccy");
        String clientNo = (String) queryParams.get("clientNo");
        String glCode = (String) queryParams.get("glCode");
        String glType = (String) queryParams.get("glType");
        String branch = (String) queryParams.get("branch");
        String seqNo = (String) queryParams.get("seqNo");

        int limit = queryParams.get("limit") != null ? Integer.parseInt((String)queryParams.get("limit")) : 10;
        int offset = queryParams.get("offset") != null ? Integer.parseInt((String)queryParams.get("offset")) : 0;

        if(glType == null) {
            Map<String, Object> glParams = new HashMap<>();
            glParams.put("glCode", glCode);
            List<ChartAccountJpe> chartAccountJpeList = dataService.findWithNamedQuery(CsdJpeConstants.GLA_MANUAL_BATCH_DTL_GL_CODE_JPE_LOV_VALIDATION, glParams, ChartAccountJpe.class);
            if(chartAccountJpeList != null) {
                glType = chartAccountJpeList.get(0).getGlType();
            }
        }

        Long clientId = null;
        if(clientNo != null) {
            clientId = getClientId(clientNo);
        }
        List<GlAccount> result = new ArrayList<>();
        String query = GlaJpeConstants.MANUAL_BATCH_DTL_SEQ_NO_LOV_VALIDATION_QUERY;
        final Map<String, Object> params = new HashMap<>();
        params.put("ccy", ccy);
        params.put("clientNo", clientId);
        params.put("branch", branch);
        params.put("glCode", glCode);
        params.put("glType", glType);

        if(seqNo != null) {
            query = query + " AND g.seq_no = :seqNo";
            params.put("seqNo", Integer.valueOf(seqNo));
        }

        if(acctNo != null) {
            query = query + " AND g.acctNo like :acctNo";
            params.put("acctNo", "%" + acctNo.toUpperCase() + "%");
        }

        List<GlAccountJpe> list = dataService.findWithQuery(query, params, offset, limit, GlAccountJpe.class);

        for (GlAccountJpe o : list) {
            GlAccount bdo = jaxbSdoHelper.wrap(o, GlAccount.class);
            result.add(bdo);
        }

        return result;
    }

}
