package com.silverlakesymmetri.cbs.xps.svc;

import java.util.List;
import java.util.Map;

import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation;
import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation.ServiceOperationType;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.svc.BusinessService;
import com.silverlakesymmetri.cbs.xps.bdo.sdo.NrStmtDetail;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.NrStmtDetailJpe;

public interface NrStmtDetailService extends BusinessService<NrStmtDetail, NrStmtDetailJpe> {
	public static final String XPS_OP_NAME_NRSTMTDETAILSERVICE_GET = "NrStmtDetailService.get";
    public static final String XPS_OP_NAME_NRSTMTDETAILSERVICE_QUERY = "NrStmtDetailService.query";
    public static final String XPS_OP_NAME_NRSTMTDETAILSERVICE_FIND = "NrStmtDetailService.find";
    public static final String XPS_OP_NAME_NRSTMTDETAILSERVICE_CREATE = "NrStmtDetailService.create";
    public static final String XPS_OP_NAME_NRSTMTDETAILSERVICE_UPDATE = "NrStmtDetailService.update";
    public static final String XPS_OP_NAME_NRSTMTDETAILSERVICE_DELETE = "NrStmtDetailService.delete";
    
    @ServiceOperation(name = XPS_OP_NAME_NRSTMTDETAILSERVICE_GET, type = ServiceOperationType.GET)
    public NrStmtDetail getByPk(String publicKey, NrStmtDetail reference);

    @ServiceOperation(name = XPS_OP_NAME_NRSTMTDETAILSERVICE_QUERY)
    public List<NrStmtDetail> query(int offset, int resultLimit, String groupBy, String order, Map<String, Object> filters);
    
    @ServiceOperation(name = XPS_OP_NAME_NRSTMTDETAILSERVICE_FIND)
    public List<NrStmtDetail> find(FindCriteria findCriteria, CbsHeader cbsHeader);
    
    @ServiceOperation(name = XPS_OP_NAME_NRSTMTDETAILSERVICE_CREATE)
    public NrStmtDetail create(NrStmtDetail dataObject);

     @ServiceOperation(name = XPS_OP_NAME_NRSTMTDETAILSERVICE_UPDATE)
    public NrStmtDetail update(NrStmtDetail dataObject);

    @ServiceOperation(name = XPS_OP_NAME_NRSTMTDETAILSERVICE_DELETE)
    public boolean delete(NrStmtDetail dataObject);
}