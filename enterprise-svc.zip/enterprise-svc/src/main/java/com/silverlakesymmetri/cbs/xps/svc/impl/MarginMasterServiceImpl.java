package com.silverlakesymmetri.cbs.xps.svc.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.mysema.query.types.EntityPath;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.bdo.ViewCriteriaItem;
import com.silverlakesymmetri.cbs.commons.bdo.ViewCriteriaRow;
import com.silverlakesymmetri.cbs.commons.jpa.entity.ConjunctionEnumJpe;
import com.silverlakesymmetri.cbs.commons.jpa.entity.ViewCriteriaItemJpe;
import com.silverlakesymmetri.cbs.commons.svc.AbstractBusinessService;
import com.silverlakesymmetri.cbs.xps.bdo.sdo.MarginMaster;
import com.silverlakesymmetri.cbs.xps.bdo.sdo.MarginUtilizationInfo;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.MarginMasterJpe;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.QMarginMasterJpe;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.util.XpsJpeConstants;
import com.silverlakesymmetri.cbs.xps.svc.ChargesUtilityService;
import com.silverlakesymmetri.cbs.xps.svc.MarginMasterService;
import com.silverlakesymmetri.cbs.xps.svc.MarginUtilityService;

@Service
@Transactional
public class MarginMasterServiceImpl extends AbstractBusinessService<MarginMaster, MarginMasterJpe, Long> implements MarginMasterService {

	@Autowired
	private ChargesUtilityService chargesUtility;
    
    @Autowired
    private MarginUtilityService marginUtility;

    @Override
    public MarginMaster getByPk(String publicKey, MarginMaster reference) {
    	Map<String, Object> params = new HashMap<String, Object>();
    	params.put("internalKey", new Long(publicKey));
    	List<MarginMasterJpe> result = dataService.findWithNamedQuery(XpsJpeConstants.FIND_MARGIN_MASTER_BY_INTERNAL_KEY, params, MarginMasterJpe.class);
    	if(result != null && result.size() > 0){
    		MarginMasterJpe jpe = result.get(0);
			MarginUtilizationInfo util = marginUtility.getMarginUtilizationInfo(jpe.getInternalKey());
			if(util != null){
				jpe.setCollectedAmt(util.getCollectedAmt());
				jpe.setUnCollectedAmt(util.getEarmarkedAmt());
				jpe.setUtilisedAmt(util.getUtilisedAmt());
				jpe.setUnUtilisedAmt(util.getUnutilisedAmt());
			}
    		return jaxbSdoHelper.wrap(jpe, MarginMaster.class);
    	}
    	return null;
    }

    @Override
    public List<MarginMaster> find(FindCriteria findCriteria, CbsHeader cbsHeader) {
    	if(findCriteria.getFilter() != null && findCriteria.getFilter().getGroup() != null && findCriteria.getFilter().getGroup().size() > 0){
    		for(ViewCriteriaRow criteriaRow : findCriteria.getFilter().getGroup()){
    			if(criteriaRow.getItem() != null && criteriaRow.getItem().size() > 0){
    				String refNo = null;
    				String instrumentType = null;
    				String type = null;
    				ViewCriteriaItem instrumentTypeVci = null;
    				List<ViewCriteriaItemJpe> otherFilters = new ArrayList<ViewCriteriaItemJpe>();
    				for(ViewCriteriaItem item : criteriaRow.getItem()){
    					ViewCriteriaItemJpe vci = jaxbSdoHelper.unwrap(item, ViewCriteriaItemJpe.class);
    					if(item.getAttribute().equals("refNo")){
    						refNo = vci.getValue().get(0).toString();
    					} else if(item.getAttribute().equals("instrumentType")){
    						instrumentType = vci.getValue().get(0).toString();
    						instrumentTypeVci = item;
    					} else if(item.getAttribute().equals("type")){
    						if(item.getValue() != null && item.getValue().size() > 0){
        						type = vci.getValue().get(0) != null ? vci.getValue().get(0).toString() : null;
    						}
    					} else {
    						otherFilters.add(vci);
    					}
    				}
    				if(refNo != null && instrumentType != null){
    					Long tranKey = chargesUtility.getTranKey(refNo, type, instrumentType);
    					List<ViewCriteriaItem> modifiedItems = new ArrayList<ViewCriteriaItem>();
    					modifiedItems.add(instrumentTypeVci);
    					ViewCriteriaItemJpe vci = new ViewCriteriaItemJpe();	
    					List<Object> values = new ArrayList<Object>();
    					values.add(tranKey);
    					vci.setAttribute("tranKey");
    					vci.setOperator("=");
    					vci.setValue(values);
    					vci.setConjunction(ConjunctionEnumJpe.AND);
    					vci.setUpperCaseCompareYn(true);
    					modifiedItems.add(jaxbSdoHelper.wrap(vci));
    					for(ViewCriteriaItemJpe otherVci : otherFilters){
    						modifiedItems.add(jaxbSdoHelper.wrap(otherVci));
    					}
    					criteriaRow.setItem(modifiedItems);
    				}
    			}
    		}
    	}
        return super.find(findCriteria, cbsHeader);
    }

    @Override
    public Long count(FindCriteria findCriteria, CbsHeader cbsHeader) {
    	List<MarginMaster> list = find(findCriteria, cbsHeader);
    	return list != null ? new Integer(list.size()).longValue() : 0L;
    }

    @Override
    public List<MarginMaster> query(int offset, int resultLimit, String groupBy, String order, Map<String, Object> filters) {
    	if(filters.containsKey("refNo") && filters.containsKey("instrumentType")){
    		String type = filters.get("type") != null ? filters.get("type").toString() : null;
			Long tranKey = chargesUtility.getTranKey(filters.get("refNo").toString(), type, filters.get("instrumentType").toString());
			filters.put("tranKey", tranKey);
			filters.remove("refNo");
			filters.remove("type");
    	}
        return super.query(offset, resultLimit, groupBy, order, filters);
    }

    @Override
    protected Long getIdFromDataObjectInstance(MarginMaster dataObject) {
        return dataObject.getInternalKey();
    }

    @Override
    protected EntityPath<MarginMasterJpe> getEntityPath() {
        return QMarginMasterJpe.marginMasterJpe;
    }
    
    @Override
    public MarginMaster create(MarginMaster dataObject){
    	return null;
    }

    @Override
    public MarginMaster update(MarginMaster dataObject){
    	return null;
    }

    @Override
    public boolean delete(MarginMaster dataObject){
    	return true;
    }

    
}
