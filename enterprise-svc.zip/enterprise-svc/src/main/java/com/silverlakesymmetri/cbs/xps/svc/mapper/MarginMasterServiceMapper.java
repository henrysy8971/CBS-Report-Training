package com.silverlakesymmetri.cbs.xps.svc.mapper;

import org.mapstruct.Context;
import org.mapstruct.DecoratedWith;
import org.mapstruct.InheritInverseConfiguration;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingTarget;
import org.mapstruct.Mappings;

import com.silverlakesymmetri.cbs.commons.jpa.util.DateTimeHelper;
import com.silverlakesymmetri.cbs.commons.xmlapi.enums.CbsXmlApiOperation;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.MarginMasterJpe;
import com.silverlakesymmetri.cbs.xps.svc.mapper.decorator.MarginMasterServiceDecorator;
import com.silverlakesymmetri.cbs.xps.xmlapi.XPSTRANMARGINAPIType;

@Mapper(uses={ DateTimeHelper.class })
@DecoratedWith(MarginMasterServiceDecorator.class)
public interface MarginMasterServiceMapper {

	@Mappings({
		@Mapping(expression = "java(oper != null ? oper.getOperation() : null)", target="OPERATION"),
		@Mapping(source="domain", target = "DOMAIN"),
		@Mapping(source="internalKey", target = "INTERNALKEY"),
		@Mapping(source="tranKey", target = "TRANKEY"),
		@Mapping(source="seqNo", target = "SEQNO"),
		@Mapping(source="instrumentType", target = "INSTRUMENTTYPE"),
		@Mapping(source="valueDate", target = "VALUEDATE", qualifiedByName = {"DateTimeHelper", "convertDateToCbsXmlApiDate"}),
		@Mapping(source="tranStatus", target = "TRANSTATUS"),
		@Mapping(source="ccy", target = "CCY"),
		@Mapping(source="amount", target = "AMOUNT"),
		@Mapping(source="baseRate", target = "BASERATE"),
		@Mapping(source="baseQuote", target = "BASEQUOTE"),
		@Mapping(source="baseEquiv", target = "BASEEQUIV"),
		@Mapping(source="localRate", target = "LOCALRATE"),
		@Mapping(source="localQuote", target = "LOCALQUOTE"),
		@Mapping(source="localEquiv", target = "LOCALEQUIV"),
		@Mapping(source="forwardCoverAvail", target = "FORWARDCOVERAVAIL"),
		@Mapping(source="percentage", target = "PERCENTAGE"),
		@Mapping(source="tranCcy", target = "TRANCCY"),
		@Mapping(source="tranEquivAmt", target = "TRANEQUIVAMT"),
		@Mapping(source="exchRate", target = "EXCHRATE"),
		@Mapping(source="exchQuote", target = "EXCHQUOTE")
	})
	public XPSTRANMARGINAPIType mapToApi(MarginMasterJpe jpe, @Context CbsXmlApiOperation oper);

	@InheritInverseConfiguration(name = "mapToApi")
	@Mappings({
		@Mapping(source="VALUEDATE", target="valueDate", qualifiedByName = {"DateTimeHelper", "convertCbsApiDateToString"})
	})
	public MarginMasterJpe mapToJpe(XPSTRANMARGINAPIType api, @MappingTarget MarginMasterJpe jpe);
}