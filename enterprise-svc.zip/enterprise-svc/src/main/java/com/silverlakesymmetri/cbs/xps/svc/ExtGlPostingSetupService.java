package com.silverlakesymmetri.cbs.xps.svc;

import java.util.List;
import java.util.Map;

import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation;
import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation.ServiceOperationType;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.svc.BusinessService;
import com.silverlakesymmetri.cbs.xps.bdo.sdo.ExtGlPostingSetup;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.ExtGlPostingSetupJpe;

public interface ExtGlPostingSetupService extends BusinessService<ExtGlPostingSetup, ExtGlPostingSetupJpe> {
	
	public static final String XPS_OP_NAME_EXTGLPOSTINGSETUPSERVICE_GET = "ExtGlPostingSetupService.get";
    public static final String XPS_OP_NAME_EXTGLPOSTINGSETUPSERVICE_QUERY = "ExtGlPostingSetupService.query";
    public static final String XPS_OP_NAME_EXTGLPOSTINGSETUPSERVICE_CREATE = "ExtGlPostingSetupService.create";
    public static final String XPS_OP_NAME_EXTGLPOSTINGSETUPSERVICE_UPDATE = "ExtGlPostingSetupService.update";
    public static final String XPS_OP_NAME_EXTGLPOSTINGSETUPSERVICE_DELETE = "ExtGlPostingSetupService.delete";
    public static final String XPS_OP_NAME_EXTGLPOSTINGSETUPSERVICE_FIND = "ExtGlPostingSetupService.find";
    
    @ServiceOperation(name = XPS_OP_NAME_EXTGLPOSTINGSETUPSERVICE_GET, type = ServiceOperationType.GET)
    public ExtGlPostingSetup getByPk(String publicKey, ExtGlPostingSetup reference);

    @ServiceOperation(name = XPS_OP_NAME_EXTGLPOSTINGSETUPSERVICE_CREATE)
    public ExtGlPostingSetup create(ExtGlPostingSetup dataObject);

     @ServiceOperation(name = XPS_OP_NAME_EXTGLPOSTINGSETUPSERVICE_UPDATE)
    public ExtGlPostingSetup update(ExtGlPostingSetup dataObject);

    @ServiceOperation(name = XPS_OP_NAME_EXTGLPOSTINGSETUPSERVICE_QUERY)
    public List<ExtGlPostingSetup> query(int offset, int resultLimit, String groupBy, String order, Map<String, Object> filters);

    @ServiceOperation(name = XPS_OP_NAME_EXTGLPOSTINGSETUPSERVICE_DELETE)
    public boolean delete(ExtGlPostingSetup dataObject);

    @ServiceOperation(name = XPS_OP_NAME_EXTGLPOSTINGSETUPSERVICE_FIND)
    public List<ExtGlPostingSetup> find(FindCriteria findCriteria, CbsHeader cbsHeader);

}
