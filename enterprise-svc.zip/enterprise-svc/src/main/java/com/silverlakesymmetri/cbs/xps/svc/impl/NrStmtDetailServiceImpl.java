package com.silverlakesymmetri.cbs.xps.svc.impl;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.mysema.query.types.EntityPath;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.bdo.ViewCriteriaItem;
import com.silverlakesymmetri.cbs.commons.bdo.ViewCriteriaRow;
import com.silverlakesymmetri.cbs.commons.jpa.entity.FindCriteriaJpe;
import com.silverlakesymmetri.cbs.commons.jpa.entity.ViewCriteriaItemJpe;
import com.silverlakesymmetri.cbs.commons.jpa.entity.ViewCriteriaRowJpe;
import com.silverlakesymmetri.cbs.commons.svc.AbstractBusinessService;
import com.silverlakesymmetri.cbs.commons.svc.BusinessObjectValidationCapable;
import com.silverlakesymmetri.cbs.xps.bdo.sdo.NrStmtDetail;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.NrStmtDetailJpe;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.QNrStmtDetailJpe;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.id.NrStmtDetailPk;
import com.silverlakesymmetri.cbs.xps.svc.NrStmtDetailService;

@Service
@Transactional
public class NrStmtDetailServiceImpl extends AbstractBusinessService<NrStmtDetail, NrStmtDetailJpe, NrStmtDetailPk> implements NrStmtDetailService, BusinessObjectValidationCapable<NrStmtDetail> {

	private static final String ATTR_ACCTNO = "acctNo";
	private static final String ATTR_VALUEDATEFROM = "valueDateFrom";
	private static final String ATTR_VALUEDATETO = "valueDateTo";
	private static final String ATTR_POSTDATEFROM = "postDateFrom";
	private static final String ATTR_POSTDATETO = "postDateTo";
	private static final String ATTR_CCY = "ccy";
	private static final String ATTR_MATCH_TYPE = "matchType";
	private static final String MATCH_TYPE_ALL = "L";
	private static final String MATCH_TYPE_UNMATCHED = "U";
	private static final String NULL = "null";
	
	@Override
	protected NrStmtDetailPk getIdFromDataObjectInstance(NrStmtDetail dataObject) {
		NrStmtDetailJpe jpe = jaxbSdoHelper.unwrap(dataObject);
		return new NrStmtDetailPk(jpe.getInternalKey());
	}

	@Override
	protected EntityPath<NrStmtDetailJpe> getEntityPath() {
		return QNrStmtDetailJpe.nrStmtDetailJpe;
	}

	@Override
	public NrStmtDetail getByPk(String publicKey, NrStmtDetail reference) {
		NrStmtDetail bdo = super.getByPk(publicKey, reference);
		return bdo;
	}

	@Override
	public List<NrStmtDetail> query(int offset, int resultLimit, String groupBy, String order, Map<String, Object> filters) {
		return super.query(offset, resultLimit, groupBy, order, filters);
	}
	
	@Override
	public List<NrStmtDetail> find(FindCriteria fc, CbsHeader cbsHeader){
		String vdFields = "valueDateFrom|valueDateTo";
		String pdFields = "postDateFrom|postDateTo";
		boolean hasRange = false;

		if(fc.getFilter() != null && fc.getFilter().getGroup() != null){
			for(ViewCriteriaRow vcr:fc.getFilter().getGroup()){
				for(ViewCriteriaItem vci: vcr.getItem()){
					if(vdFields.contains(vci.getAttribute()) || pdFields.contains(vci.getAttribute())){
						hasRange = true;
						break;
					}
				}
			}
		}
		
		if(hasRange){
			return getExternalList(fc);
		}else{			
			return super.find(fc, cbsHeader);
		}
	}
	
	@Override
	public NrStmtDetail create(NrStmtDetail dataObject) {
		return super.create(dataObject);
	}

	@Override
	public NrStmtDetail update(NrStmtDetail dataObject) {
		return super.update(dataObject);
	}
	
	@Override
	public boolean delete(NrStmtDetail dataObject) {
		return super.delete(dataObject);
	}
	
	private List<NrStmtDetail> getExternalList(FindCriteria fc){
		FindCriteriaJpe fcJpe = jaxbSdoHelper.unwrap(fc);
		
		String acctNo = null;
		Date valueDateFrom = null;
		Date valueDateTo = null;
		Date postDateFrom = null;
		Date postDateTo = null;
		String ccy = null;
		String matchType = null;

		if(fcJpe.getFilter() != null && fcJpe.getFilter().getGroup() != null){
			for(ViewCriteriaRowJpe vcr:fcJpe.getFilter().getGroup()){
				for (ViewCriteriaItemJpe vci : vcr.getItem()) {
					if (ATTR_ACCTNO.equals(vci.getAttribute())) {
						acctNo = (String) vci.getValue().get(0);
					}
					if (ATTR_VALUEDATEFROM.equals(vci.getAttribute())) {
						Date vdFrom = this.dateTimeHelper.getDate((String) vci.getValue().get(0));
						valueDateFrom = vdFrom;
					}
					if (ATTR_VALUEDATETO.equals(vci.getAttribute())) {
						Date vdTo = this.dateTimeHelper.getDate((String) vci.getValue().get(0));
						valueDateTo = vdTo;
					}
					if (ATTR_POSTDATEFROM.equals(vci.getAttribute())) {
						Date pdFrom = this.dateTimeHelper.getDate((String) vci.getValue().get(0));
						postDateFrom = pdFrom;
					}
					if (ATTR_POSTDATETO.equals(vci.getAttribute())) {
						Date pdTo = this.dateTimeHelper.getDate((String) vci.getValue().get(0));
						postDateTo = pdTo;
					}
					if (ATTR_CCY.equals(vci.getAttribute())) {
						ccy = (String) vci.getValue().get(0);
					}
					if (ATTR_MATCH_TYPE.equals(vci.getAttribute())) {
						matchType = (String) vci.getValue().get(0);
					}
				}
			}
		}
		
		String sqlQuery = "SELECT e FROM NrStmtDetailJpe e WHERE e.acctNo = :acctNo AND e.ccy = :ccy";
		Map<String, Object> params = new HashMap<>();
		params.put(ATTR_ACCTNO, acctNo);
		params.put(ATTR_CCY, ccy);
		if(valueDateFrom!=null && valueDateTo!=null){
			sqlQuery = sqlQuery + " AND e.valueDate BETWEEN :valueDateFrom AND :valueDateTo";
			params.put(ATTR_VALUEDATEFROM, valueDateFrom);
			params.put(ATTR_VALUEDATETO, valueDateTo);
		}
		if(postDateFrom!=null && postDateTo!=null){
			sqlQuery = sqlQuery + " AND e.entryDate BETWEEN :postDateFrom AND :postDateTo";
			params.put(ATTR_POSTDATEFROM, postDateFrom);
			params.put(ATTR_POSTDATETO, postDateTo);
		}
		if(StringUtils.isNotBlank(matchType)){
			if(matchType.equalsIgnoreCase(NULL)){
				sqlQuery = sqlQuery + " AND e.matchType IS NULL";
			}else if(!matchType.equals(MATCH_TYPE_ALL)){
				sqlQuery = sqlQuery + " AND e.matchType = :matchType";
				params.put(ATTR_MATCH_TYPE, matchType);
			}
		}
		
		List<NrStmtDetail> retList = new ArrayList<>();
		List<NrStmtDetailJpe> jpeList = this.dataService.findWithQuery(sqlQuery, NrStmtDetailJpe.class, params, null);
		if(jpeList != null){
			for(NrStmtDetailJpe jpe: jpeList){
				retList.add(jaxbSdoHelper.wrap(jpe, NrStmtDetail.class));
			}
		}
		
		return retList; 
	}
}