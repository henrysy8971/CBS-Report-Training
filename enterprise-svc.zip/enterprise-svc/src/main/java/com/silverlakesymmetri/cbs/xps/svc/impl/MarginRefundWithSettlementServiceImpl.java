package com.silverlakesymmetri.cbs.xps.svc.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.silverlakesymmetri.cbs.xps.svc.ext.BgtChargesServiceExt;
import org.apache.velocity.VelocityContext;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.mysema.query.types.EntityPath;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.exception.base.CbsServiceProcessException;
import com.silverlakesymmetri.cbs.commons.jpa.util.DateTimeHelper;
import com.silverlakesymmetri.cbs.commons.xmlapi.enums.CbsXmlApiOperation;
import com.silverlakesymmetri.cbs.mcl.bdo.sdo.Client;
import com.silverlakesymmetri.cbs.mcl.bdo.sdo.ClientContact;
import com.silverlakesymmetri.cbs.swf.bdo.sdo.SwfMessageGroup;
import com.silverlakesymmetri.cbs.xps.bdo.sdo.ChargeSettlement;
import com.silverlakesymmetri.cbs.xps.bdo.sdo.MarginMaster;
import com.silverlakesymmetri.cbs.xps.bdo.sdo.MarginSettlement;
import com.silverlakesymmetri.cbs.xps.bdo.sdo.MarginSettlementDetails;
import com.silverlakesymmetri.cbs.xps.bdo.sdo.MarginRefundWithSettlement;
import com.silverlakesymmetri.cbs.xps.bdo.sdo.MessageQOthers;
import com.silverlakesymmetri.cbs.xps.bdo.sdo.SettleMessagePreviewAddInfo;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.MarginRefundWithSettlementJpe;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.QMarginRefundWithSettlementJpe;
import com.silverlakesymmetri.cbs.xps.svc.AbstractXmlApiAdviceCapableBusinessService;
import com.silverlakesymmetri.cbs.xps.svc.ChargesUtilityService;
import com.silverlakesymmetri.cbs.xps.svc.MarginMasterService;
import com.silverlakesymmetri.cbs.xps.svc.MarginSettlementService;
import com.silverlakesymmetri.cbs.xps.svc.MarginUtilityService;
import com.silverlakesymmetri.cbs.xps.svc.MarginRefundWithSettlementService;
import com.silverlakesymmetri.cbs.xps.svc.mapper.MarginSettlementServiceMapper;
import com.silverlakesymmetri.cbs.xps.svc.mapper.MarginRefundWithSettlementServiceMapper;
import com.silverlakesymmetri.cbs.xps.xmlapi.XPSTRANCHARGESETTLEAPIType;
import com.silverlakesymmetri.cbs.xps.xmlapi.XPSTRANMARGINSETTLEAPIType;
import com.silverlakesymmetri.cbs.xps.xmlapi.XPSTRANMARGINREFUNDWITHSETTLEAPIType;

@Service
@Transactional
public class MarginRefundWithSettlementServiceImpl extends AbstractXmlApiAdviceCapableBusinessService<MarginRefundWithSettlement, MarginRefundWithSettlementJpe, Long, XPSTRANMARGINREFUNDWITHSETTLEAPIType, XPSTRANMARGINREFUNDWITHSETTLEAPIType> implements MarginRefundWithSettlementService {

    @Autowired
    private MarginRefundWithSettlementServiceMapper mapper;

    @Autowired
    private MarginSettlementServiceMapper settlementMapper;
    
    @Autowired
    private MarginUtilityService marginUtility;
	
	@Autowired
	protected MarginMasterService marginMasterService;
	
	@Autowired
	protected MarginSettlementService marginSettlementService;

	@Autowired
	protected DateTimeHelper dateTimeHelper;

	@Autowired
	private ChargesUtilityService chargesUtility;


    @Override
    public MarginRefundWithSettlement getByPk(String publicKey, MarginRefundWithSettlement reference) {
    	Long internalKey = Long.parseLong(publicKey);
    	MarginRefundWithSettlement bdo = jaxbSdoHelper.createSdoInstance(MarginRefundWithSettlement.class);
    	XPSTRANMARGINREFUNDWITHSETTLEAPIType request = new XPSTRANMARGINREFUNDWITHSETTLEAPIType();
    	request.setINTERNALKEY(internalKey);
    	request.setOPERATION(CbsXmlApiOperation.QUERY.toString());
    	XPSTRANMARGINREFUNDWITHSETTLEAPIType response = queryXmlApiRs(request);
    	MarginRefundWithSettlement result = null;
    	if(response.getINTERNALKEY() != null){
    		result = processXmlApiRs(bdo, response);
        	MarginMaster master = marginMasterService.getByPk(result.getMarginInternalKey().toString(), null);
        	result.setMarginStructRec(master);
        	result.getMarginRefundStructRec().setCcy(master.getCcy());
    		if(result.getSettlementStructRec() == null && response.getSETTLEMENT() != null){
            	MarginSettlement settlement = marginSettlementService.getByPk(publicKey, null);
            	result.setSettlementStructRec(settlement);
    		}
    	}
    	return result;
    }

    @Override
    public MarginRefundWithSettlement getAttachedMarginWithRefund(Map<String, Object> params) {
    	String domain = params.get("domain").toString();
    	String relEventType = params.get("relEventType").toString();
    	Long relInternalKey = Long.parseLong(params.get("relInternalKey").toString());
    	XPSTRANMARGINREFUNDWITHSETTLEAPIType request = new XPSTRANMARGINREFUNDWITHSETTLEAPIType();
    	request.setRELINTERNALKEY(relInternalKey);
    	request.setDOMAIN(domain);
    	request.setRELEVENTTYPE(relEventType);
    	request.setOPERATION(CbsXmlApiOperation.QUERY.toString());
    	XPSTRANMARGINREFUNDWITHSETTLEAPIType response = queryXmlApiRs(request);
    	MarginRefundWithSettlement result = null;
    	if(response.getINTERNALKEY() != null){
    		result = processXmlApiRs(jaxbSdoHelper.createSdoInstance(MarginRefundWithSettlement.class), response);
        	MarginMaster master = marginMasterService.getByPk(response.getMARGININTERNALKEY().toString(), null);
        	result.setMarginStructRec(master);
        	result.getMarginRefundStructRec().setCcy(master.getCcy());
    		if(result.getSettlementStructRec() == null && response.getSETTLEMENT() != null){
            	MarginSettlement settlement = marginSettlementService.getByPk(response.getSETTLEMENT().getINTERNALKEY().toString(), null);
            	result.setSettlementStructRec(settlement);
    		}
    	}
    	return result;
    }

	@Override
	public MarginRefundWithSettlement getAttachedMarginWithRefundWithRefNo(Map<String, Object> params) {
		String domain = (String) params.get("domain");
		String refNo = (String) params.get("refNo");
		String relEventType = (String) params.get("relEventType");
		Long relInternalKey = null;
		Long eventSeq = Long.parseLong((String) params.get("eventSeq"));
		MarginRefundWithSettlement result = null;
		if (domain.equalsIgnoreCase("BGT")) {
			BgtChargesServiceExt bgtChargesServiceExt = chargesUtility.getBgtChargeServiceExtensionPoint();
			if (bgtChargesServiceExt != null) {
				relInternalKey = bgtChargesServiceExt.getBgIssueEventRelInternalKey(relEventType, refNo, eventSeq);
				if (relInternalKey != null) {
					params.put("relInternalKey", relInternalKey);
					params.remove("refNo");
					result = getAttachedMarginWithRefund(params);
				}
			}
		}
		return result;
	}

	@Override
    public List<MarginRefundWithSettlement> find(FindCriteria findCriteria, CbsHeader cbsHeader) {
        return super.find(findCriteria, cbsHeader);
    }

    @Override
    public List<MarginRefundWithSettlement> query(int offset, int resultLimit, String groupBy, String order, Map<String, Object> filters) {
        return super.query(offset, resultLimit, groupBy, order, filters);
    }

    public MarginRefundWithSettlement preCreateValidation(MarginRefundWithSettlement dataObject) {
    	if(dataObject.getSettlementStructRec() == null){
            String msg = messageUtils.getMessage("CBS.B.XPS.MARGINSETTLEMENT.0002", new String[] {});
            CbsServiceProcessException exec = new CbsServiceProcessException("CBS.B.XPS.MARGINSETTLEMENT.0002", msg);
            throw exec;
    	} else if(dataObject.getSettlementStructRec().getMarginSettleDetailsList() != null){
    		if(dataObject.getSettlementStructRec().getMarginSettleDetailsList().size() > 1){
                String msg = messageUtils.getMessage("CBS.B.XPS.MARGINSETTLEMENT.0001", new String[] {});
                CbsServiceProcessException exec = new CbsServiceProcessException("CBS.B.XPS.MARGINSETTLEMENT.0001", msg);
                throw exec;
    		} else if(dataObject.getSettlementStructRec().getMarginSettleDetailsList().size() == 0){
                String msg = messageUtils.getMessage("CBS.B.XPS.MARGINSETTLEMENT.0001", new String[] {});
                CbsServiceProcessException exec = new CbsServiceProcessException("CBS.B.XPS.MARGINSETTLEMENT.0002", msg);
                throw exec;
    		}
    	}
    	return super.preCreateValidation(dataObject);
    }
    
    public MarginRefundWithSettlement getAttachedMarginRefundWithSettlement(Long attachedKey){
    	return null;
    }

    @Override
    public MarginRefundWithSettlement create(MarginRefundWithSettlement dataObject) {
        return super.create(dataObject);
    }

    @Override
    protected XPSTRANMARGINREFUNDWITHSETTLEAPIType transformBdoToXmlApiRqCreate(MarginRefundWithSettlement dataObject) {
        return transformBdoToXmlApiType(dataObject, CbsXmlApiOperation.INSERT);
    }

    @Override
    protected XPSTRANMARGINREFUNDWITHSETTLEAPIType transformBdoToXmlApiRqUpdate(MarginRefundWithSettlement dataObject) {
        return null;
    }

    @Override
    protected XPSTRANMARGINREFUNDWITHSETTLEAPIType transformBdoToXmlApiRqDelete(MarginRefundWithSettlement dataObject) {
        return null;
    }

    private XPSTRANMARGINREFUNDWITHSETTLEAPIType transformBdoToXmlApiType(MarginRefundWithSettlement dataObject, CbsXmlApiOperation oper) {
    	MarginRefundWithSettlementJpe jpe = jaxbSdoHelper.unwrap(dataObject);
    	XPSTRANMARGINREFUNDWITHSETTLEAPIType api = mapper.mapToApi(jpe, oper);
    	if(jpe.getSettlementStructRec() != null){
    		XPSTRANMARGINSETTLEAPIType settlement = settlementMapper.mapToApi(jpe.getSettlementStructRec(), oper);
    		super.setTechColsFromDataObject(dataObject.getSettlementStructRec(), settlement);
    		api.setSETTLEMENT(settlement);
    	}
    	super.setTechColsFromDataObject(dataObject, api);
        return api;
    }

    @Override
    protected Map<String, String> executeStoredProcedure(String xmlApiReq, String xmlHeaderIn) {
        String xmlApiReqProcess = xmlApiReq.replaceAll("XPS_TRAN_MARGIN_REFUND_WITH_SETTLE_API OPERATION=\"INSERT\"", "XPS_TRAN_MARGIN_REFUND_WITH_SETTLE_API OPERATION=\"PROCESS_AUTHORIZE\"");
        return super.executeStoredProcedure(xmlApiReqProcess, xmlHeaderIn);
    }

    @Override
    protected MarginRefundWithSettlement processXmlApiRs(MarginRefundWithSettlement dataObject, XPSTRANMARGINREFUNDWITHSETTLEAPIType xmlApiRs) {
    	MarginRefundWithSettlementJpe jpe = jaxbSdoHelper.unwrap(dataObject);
        jpe = mapper.mapToJpe(xmlApiRs, jpe);
        jpe.setInternalKey(xmlApiRs.getINTERNALKEY());
        return jaxbSdoHelper.wrap(jpe);
    }

    @Override
    protected List<MarginRefundWithSettlement> processXmlApiListRs(MarginRefundWithSettlement dataObject, XPSTRANMARGINREFUNDWITHSETTLEAPIType xmlApiRs) {
        return null;
    }

    @Override
    protected Class<XPSTRANMARGINREFUNDWITHSETTLEAPIType> getXmlApiResponseClass() {
        return XPSTRANMARGINREFUNDWITHSETTLEAPIType.class;
    }

    @Override
    protected Long getIdFromDataObjectInstance(MarginRefundWithSettlement dataObject) {
        return dataObject.getMarginStructRec().getInternalKey();
    }

    @Override
    protected EntityPath<MarginRefundWithSettlementJpe> getEntityPath() {
        return QMarginRefundWithSettlementJpe.marginRefundWithSettlementJpe;
    }

	@Override
	public String generateSwfMessage(Map<String, Object> params) {
		String swfMessage = null;
    	SwfMessageGroup msgGroup = jsonConversionMngr.convertToType(params.get("msgGroup"), SwfMessageGroup.class, null, null);
		if(params.get("module") != null){
			msgGroup.setModule(params.get("module").toString());
		} 
    	MarginRefundWithSettlement bdo = jsonConversionMngr.convertToType(params.get("transactionBdo"), MarginRefundWithSettlement.class, null, null);
    	String swiftMessageFromQueue = getGeneratedSwiftMessage(bdo.getInternalKey(), "MRF", msgGroup.getFormat(), msgGroup.getModule());
    	if(swiftMessageFromQueue != null){
    		return swiftMessageFromQueue;
    	}
    	XPSTRANMARGINREFUNDWITHSETTLEAPIType xmlApiReq = transformBdoToXmlApiType(bdo, CbsXmlApiOperation.QUERY);
    	SettleMessagePreviewAddInfo addtlInfo = jsonConversionMngr.convertToType(params.get("parentInfo"), SettleMessagePreviewAddInfo.class, null, null);
    	swfMessage = transformToSwfFormat(xmlApiReq, msgGroup, addtlInfo);
		return swfMessage;
	}

	@Override
	protected MessageQOthers fillContext(Map<String, Object> adviceParams, VelocityContext context){
		MarginRefundWithSettlement refundWithSettlement = jsonConversionMngr.convertToType(adviceParams.get("parentBdo"), MarginRefundWithSettlement.class, null, null);
		context.put("MarginMaster", refundWithSettlement.getMarginStructRec());
		context.put("MarginRefund", refundWithSettlement.getMarginRefundStructRec());

		MarginSettlementDetails details = jsonConversionMngr.convertToType(adviceParams.get("bdo"), MarginSettlementDetails.class, null, null);
		context.put("MarginSettlementDetails", details);
		adviceParams.remove("bdo");

		if(details.getCommonSettleDepositRec() != null){
			context.put("CommonSettleDeposit", details.getCommonSettleDepositRec());
			Client client = clientService.getByPk(details.getCommonSettleDepositRec().getClientNo(), null);
			if(client != null){
				context.put("Client", client);
				adviceParams.put("Client", client);
				ClientContact contact = getClientContact(client, "POSTAL", null);
				context.put("ClientContact", contact);
			}
		}

		if(details.getInternalKey() != null) {
			Map<String, Object> filters = new HashMap<String, Object>();
			filters.put("tranInternalKey", details.getInternalKey());
			filters.put("tranEventType", "MRF");
			List<MessageQOthers> messageQList = messageQOthersService.query(0, -1, null, null, filters);
			if(messageQList != null && messageQList.size() > 0){
				return messageQList.get(0);
			}
		}
		return null;
	}


}
