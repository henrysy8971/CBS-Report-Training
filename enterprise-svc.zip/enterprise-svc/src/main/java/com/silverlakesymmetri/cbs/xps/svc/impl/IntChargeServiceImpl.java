package com.silverlakesymmetri.cbs.xps.svc.impl;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Map;

import javax.inject.Inject;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;

import com.mysema.query.types.EntityPath;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.jpa.extension.JaxbSdoHelper;
import com.silverlakesymmetri.cbs.commons.jpa.service.CbsGenericDataService;
import com.silverlakesymmetri.cbs.commons.jpa.service.impl.BusinessDataObjectJpaQueryComponentImpl;
import com.silverlakesymmetri.cbs.commons.svc.AbstractBusinessService;
import com.silverlakesymmetri.cbs.commons.svc.BusinessObjectValidationCapable;
import com.silverlakesymmetri.cbs.commons.svc.ref.ReferenceNumberGeneratorService;
import com.silverlakesymmetri.cbs.commons.svc.util.InMemoryQueryExecutor;
import com.silverlakesymmetri.cbs.csd.svc.CcyConversionService;
import com.silverlakesymmetri.cbs.xps.bdo.sdo.IntCharge;
import com.silverlakesymmetri.cbs.xps.bdo.sdo.IntChargeRate;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.IntChargeJpe;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.QIntChargeJpe;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.util.XpsJpeConstants;
import com.silverlakesymmetri.cbs.xps.svc.IntChargeService;

@Service
@Transactional
public class IntChargeServiceImpl extends AbstractBusinessService<IntCharge, IntChargeJpe, String> implements IntChargeService, BusinessObjectValidationCapable<IntCharge> {

	@Inject
	protected JaxbSdoHelper jaxbSdoHelper;
	@Autowired
	protected CcyConversionService ccyConversionService;
	@Autowired
	private CbsGenericDataService dataService;

	@Autowired
	private ReferenceNumberGeneratorService referenceNumberGeneratorService;

	@Override
	protected String getIdFromDataObjectInstance(IntCharge dataObject) {
		return dataObject.getChargeRefNo();
	}

	@Override
	protected EntityPath<IntChargeJpe> getEntityPath() {
		return QIntChargeJpe.intChargeJpe;
	}

	@Override
	public IntCharge get(IntCharge objectInstanceIdentifier) {
		List<IntChargeJpe> jpeResult = dataService.findWithNamedQuery(XpsJpeConstants.INT_CHARGE_JPE_GET_ALL, IntChargeJpe.class);
		IntCharge sdo = null;
		for (IntChargeJpe jpe : jpeResult) {
			if (jpe.getChargeRefNo().equals(objectInstanceIdentifier.getChargeRefNo())){
				sdo = jaxbSdoHelper.wrap(jpe, IntCharge.class);
			}
		}
		return sdo;
	}

	@Override
	public List<IntCharge> query(int offset, int resultLimit, String groupBy, String order, Map<String, Object> filters) {
		List<IntCharge> sdoResult = getAll();
		FindCriteria fc = jaxbSdoHelper.wrap(BusinessDataObjectJpaQueryComponentImpl.buildFindCriteria(offset, resultLimit, groupBy, order, filters));
		return filterAndSortResult(fc, sdoResult);
	}

	@Override
	public IntCharge create(IntCharge dataObject) {
		Defaulting(dataObject);
		return super.create(dataObject);
	}

	@Override
	public IntCharge update(IntCharge dataObject) {
		Defaulting(dataObject);
		return super.update(dataObject);
	}

	@Override
	public boolean delete(IntCharge dataObject) {
		return super.delete(dataObject);
	}

	@Override
	public List<IntCharge> getAll() {
		List<IntCharge> sdoResult = new ArrayList<IntCharge>();

		List<IntChargeJpe> jpeResult = dataService.findWithNamedQuery(XpsJpeConstants.INT_CHARGE_JPE_GET_ALL, IntChargeJpe.class);

		for (IntChargeJpe jpe : jpeResult) {
			IntCharge sdo = jaxbSdoHelper.wrap(jpe, IntCharge.class);
			sdoResult.add(sdo);
		}

		return sdoResult;
	}

	private List<IntCharge> filterAndSortResult(FindCriteria findCriteria, List<IntCharge> list) {
		InMemoryQueryExecutor<IntCharge> inMemQry = new InMemoryQueryExecutor<>(list);
		return inMemQry.executeFilter(findCriteria);
	}

	@Override
	protected IntCharge preCreateValidation(IntCharge dataObject) {
		if(null != dataObject){
	    	performDefaulting(dataObject);
	    	if (StringUtils.isEmpty(dataObject.getChargeRefNo())) {
				referenceNumberGeneratorService.getNewRefNo(dataObject, "chargeRefNo");
			}
	        if (dataObject.isUsedYn() == null) {
	            dataObject.setUsedYn(false);
	        }
	        if (dataObject.isActiveYn() == null) {
	            dataObject.setActiveYn(false);
	        }

	        java.util.List<com.silverlakesymmetri.cbs.xps.bdo.sdo.IntChargeRate> chargeRateList;
			chargeRateList = dataObject.getIntChargeRateList();

			if (null != chargeRateList){
				for ( IntChargeRate child : chargeRateList){
					if (StringUtils.isEmpty(child.getChargeRefNo())) {
						child.setChargeRefNo(dataObject.getChargeRefNo());
					}
					if (StringUtils.isEmpty(child.getChargeRateRefNo())) {
						referenceNumberGeneratorService.getNewRefNo(child, "chargeRateRefNo");
					}
				}
				dataObject.setIntChargeRateList(chargeRateList);
			}
		}
		return dataObject;
	}

	@Override
	protected IntCharge preUpdateValidation(IntCharge dataObject) {
		performDefaulting(dataObject);
		java.util.List<com.silverlakesymmetri.cbs.xps.bdo.sdo.IntChargeRate> chargeRateList;
		chargeRateList = dataObject.getIntChargeRateList();

		if (null != chargeRateList){
			for ( IntChargeRate child : chargeRateList){
				if (StringUtils.isEmpty(child.getChargeRefNo())) {
					child.setChargeRefNo(dataObject.getChargeRefNo());
				}
				if (StringUtils.isEmpty(child.getChargeRateRefNo())) {
					referenceNumberGeneratorService.getNewRefNo(child, "chargeRateRefNo");
				}
			}
			dataObject.setIntChargeRateList(chargeRateList);
		}
		return dataObject;
	}

	private void performDefaulting(IntCharge intChargeJpe) {
		if (null != intChargeJpe) {
			if (null == intChargeJpe.getChargeType()) {intChargeJpe.setChargeType("I");}
			sortAndDefaultSeqNo(intChargeJpe);
		}
	}

	private void sortAndDefaultSeqNo(IntCharge intChargeJpe) {
		List<IntChargeRate> chargeRateList = intChargeJpe.getIntChargeRateList();
		if (chargeRateList!=null && chargeRateList.size() > 0) {

			List<IntChargeRate> chargeRateSortedByBalanceDays = new ArrayList<IntChargeRate>(chargeRateList);
			Collections.sort(chargeRateSortedByBalanceDays, new Comparator<IntChargeRate>() {
				@Override
				public int compare(IntChargeRate o1, IntChargeRate o2) {
					int iResult = 0;
					Double d1 = o1.getBalance();
					Double d2 = o2.getBalance();
					if (d1 != null) {
						iResult = d1.compareTo(d2);
					}

					return iResult;
				}
			});

			for (IntChargeRate removeTradeChargeRate : chargeRateList) {
				intChargeJpe.getIntChargeRateList().remove(removeTradeChargeRate);
			}

			int seqNo = 1;
			for (IntChargeRate addTradeChargeRate : chargeRateSortedByBalanceDays) {
				addTradeChargeRate.setSeqNo(seqNo);
				intChargeJpe.getIntChargeRateList().add(addTradeChargeRate);
            	seqNo++;
			}

		}
	}

	@Override
	public List<IntCharge> find(FindCriteria findCriteria, CbsHeader cbsHeader) {
		List<IntCharge> sdoResult = getAll();
		return filterAndSortResult(findCriteria, sdoResult);
	}

	@Override
	public IntCharge getByPk(String publicKey, IntCharge reference) {
		IntCharge result = super.getByPk(publicKey, reference);
		if (null != result && "I".equals(result.getChargeType())) {
			return result;
		} else {
			return null;

		}
	}

	@Override
	public Long count(FindCriteria findCriteria, CbsHeader cbsHeader) {
		List<IntCharge> sdoResult = getAll();
		return Long.valueOf((long)filterAndSortResult(findCriteria, sdoResult).size());
	}

	private void Defaulting(IntCharge dataObject){
		if (null != dataObject){
			//chargeType
			if (null == dataObject.getChargeType()){
				dataObject.setChargeType("I");
			}
			//userRateConstituents
			if (null == dataObject.getUseRateConstituents()){
				dataObject.setUseRateConstituents("N");
			}
			//recurring
			if (null == dataObject.getRecurring()){
				dataObject.setRecurring("N");
			}
			//interestAction
			if (null == dataObject.getInterestAction()){
				dataObject.setInterestAction("N");
			}
		}
	}

}
