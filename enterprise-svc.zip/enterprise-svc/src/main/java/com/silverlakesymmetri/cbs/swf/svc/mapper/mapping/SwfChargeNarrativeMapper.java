package com.silverlakesymmetri.cbs.swf.svc.mapper.mapping;

import org.mapstruct.InheritInverseConfiguration;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Mappings;

import com.silverlakesymmetri.cbs.swf.jpa.mapping.sdo.SwfChargeNarrativeJpe;
import com.silverlakesymmetri.cbs.swf.xmlapi.SWFCHARGENARRATIVETYPEType;

@Mapper()
public interface SwfChargeNarrativeMapper {
	@Mappings({
		@Mapping(source="index", target="INDEX"),
		@Mapping(source="code", target="CODE"),
		@Mapping(source="currency", target="CURRENCY"),
		@Mapping(source="amount", target="AMOUNT"),
		@Mapping(source="narrative", target="NARRATIVE"),
		@Mapping(source="settleEquivAmt", target="SETTLEEQUIVAMT")
	})
	SWFCHARGENARRATIVETYPEType mapToApi(SwfChargeNarrativeJpe jpe);
	
	@InheritInverseConfiguration(name = "mapToApi")
	SwfChargeNarrativeJpe mapToJpe(SWFCHARGENARRATIVETYPEType api);

}