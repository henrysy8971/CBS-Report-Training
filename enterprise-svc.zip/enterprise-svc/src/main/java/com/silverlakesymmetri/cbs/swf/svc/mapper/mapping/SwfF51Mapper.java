package com.silverlakesymmetri.cbs.swf.svc.mapper.mapping;

import org.apache.commons.lang3.StringUtils;
import org.mapstruct.DecoratedWith;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Mappings;

import com.silverlakesymmetri.cbs.swf.jpa.mapping.sdo.SwfFinEntityJpe;
import com.silverlakesymmetri.cbs.swf.svc.mapper.decorator.SwfF51MapperDecorator;
import com.silverlakesymmetri.cbs.swf.xmlapi.SWFF51TYPEType;

@Mapper(imports = StringUtils.class, uses = { SwiftMapperHelper.class, SwfAcctLineMapper.class })
@DecoratedWith(SwfF51MapperDecorator.class)
public interface SwfF51Mapper {
	@Mappings({
		@Mapping(source="opt", target="OPT", qualifiedByName = {"SwiftMapperHelper", "resolveFOption"}),
		@Mapping(source="swfAcctLineStructRec", target="ACCOUNT"),
		@Mapping(source="address", target="ADDRESS"),
		@Mapping(source="bic", target="BIC"),
		@Mapping(source="branchLocation", target="BRANCHLOCATION")
	})
	SWFF51TYPEType mapToApi(SwfFinEntityJpe jpe);
	
	@Mappings({
		@Mapping(target="opt", expression = "java(StringUtils.isNotBlank(api.getOPT())?api.getOPT():null)"),
		@Mapping(target="swfAcctLineStructRec", source="ACCOUNT"),
		@Mapping(target="address", expression = "java(StringUtils.isNotBlank(api.getADDRESS())?api.getADDRESS():null)"),
		@Mapping(target="bic", expression = "java(StringUtils.isNotBlank(api.getBIC())?api.getBIC():null)"),
		@Mapping(target="branchLocation", expression = "java(StringUtils.isNotBlank(api.getBRANCHLOCATION())?api.getBRANCHLOCATION():null)")
	})
	SwfFinEntityJpe mapToJpe(SWFF51TYPEType api);
}