package com.silverlakesymmetri.cbs.xps.svc;

import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation;
import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation.ServiceOperationType;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.svc.BusinessService;
import com.silverlakesymmetri.cbs.xps.bdo.sdo.InwTranMapOut;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.InwTranMapOutJpe;

import java.util.List;
import java.util.Map;

public interface InwTranMapOutService extends BusinessService<InwTranMapOut, InwTranMapOutJpe> {

	public static final String SVC_OP_NAME_INWTRANMAPOUTSERVICE_GET = "InwTranMapOutService.get";
    public static final String SVC_OP_NAME_INWTRANMAPOUTSERVICE_QUERY = "InwTranMapOutService.query";
    public static final String SVC_OP_NAME_INWTRANMAPOUTSERVICE_FIND = "InwTranMapOutService.find";
    public static final String SVC_OP_NAME_INWTRANMAPOUTSERVICE_CREATE = "InwTranMapOutService.create";
    public static final String SVC_OP_NAME_INWTRANMAPOUTSERVICE_UPDATE = "InwTranMapOutService.update";
    public static final String SVC_OP_NAME_INWTRANMAPOUTSERVICE_DELETE = "InwTranMapOutService.delete";
    
    @ServiceOperation(name = SVC_OP_NAME_INWTRANMAPOUTSERVICE_GET, type = ServiceOperationType.GET)
    public InwTranMapOut getByPk(String publicKey, InwTranMapOut reference);

    @ServiceOperation(name = SVC_OP_NAME_INWTRANMAPOUTSERVICE_QUERY)
    public List<InwTranMapOut> query(int offset, int resultLimit, String groupBy, String order, Map<String, Object> filters);
    
    @ServiceOperation(name = SVC_OP_NAME_INWTRANMAPOUTSERVICE_FIND)
    public List<InwTranMapOut> find(FindCriteria findCriteria, CbsHeader cbsHeader);
    
    @ServiceOperation(name = SVC_OP_NAME_INWTRANMAPOUTSERVICE_CREATE)
    public InwTranMapOut create(InwTranMapOut dataObject);

     @ServiceOperation(name = SVC_OP_NAME_INWTRANMAPOUTSERVICE_UPDATE)
    public InwTranMapOut update(InwTranMapOut dataObject);

    @ServiceOperation(name = SVC_OP_NAME_INWTRANMAPOUTSERVICE_DELETE)
    public boolean delete(InwTranMapOut dataObject);
}