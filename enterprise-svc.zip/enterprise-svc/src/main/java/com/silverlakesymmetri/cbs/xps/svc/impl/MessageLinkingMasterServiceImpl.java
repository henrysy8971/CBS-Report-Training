package com.silverlakesymmetri.cbs.xps.svc.impl;

import java.io.StringWriter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.transform.stream.StreamResult;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mysema.query.types.EntityPath;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.exception.CbsRuntimeException;
import com.silverlakesymmetri.cbs.commons.logging.CbsAppLogger;
import com.silverlakesymmetri.cbs.commons.logging.CbsAppLoggerFactory;
import com.silverlakesymmetri.cbs.commons.svc.AbstractXmlApiBusinessService;
import com.silverlakesymmetri.cbs.commons.xmlapi.enums.CbsXmlApiOperation;
import com.silverlakesymmetri.cbs.commons.xmlapi.rs.CUTAPIHEADEROUTCPLXType;
import com.silverlakesymmetri.cbs.xps.bdo.sdo.MessageLinkingMaster;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.MessageLinkingListJpe;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.MessageLinkingMasterJpe;
import com.silverlakesymmetri.cbs.xps.svc.MessageLinkingMasterService;
import com.silverlakesymmetri.cbs.xps.svc.mapper.MessageLinkingDetailServiceMapper;
import com.silverlakesymmetri.cbs.xps.svc.mapper.MessageLinkingMasterServiceMapper;
import com.silverlakesymmetri.cbs.xps.xmlapi.XPSMESSAGEREPOSWFAPIType;
import com.silverlakesymmetri.cbs.xps.xmlapi.XPSMESSAGEREPOSWFINAPIType;
import com.silverlakesymmetri.cbs.xps.xmlapi.XPSSWFLINKAPIType;
import com.silverlakesymmetri.cbs.xps.xmlapi.XPSSWFLINKDETAILLISTTYPEType;
import com.silverlakesymmetri.cbs.xps.xmlapi.XPSSWFLINKDETAILTYPEType;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.QMessageLinkingMasterJpe;

@Service
public class MessageLinkingMasterServiceImpl extends AbstractXmlApiBusinessService<MessageLinkingMaster, MessageLinkingMasterJpe, Long, XPSSWFLINKAPIType, XPSSWFLINKAPIType>  
	implements MessageLinkingMasterService {
	
	protected static final String SP_RES_XML_API = "p_Response";
    protected static final String SP_RES_HEADER_OUT = "p_Response_Header";
	
	private static CbsAppLogger logger = CbsAppLoggerFactory.getLogger(MessageLinkingMasterServiceImpl.class);
	
	@Autowired
	MessageLinkingMasterServiceMapper mapper;
	
	@Autowired
	MessageLinkingDetailServiceMapper dtlMapper;

	@Override
	protected Long getIdFromDataObjectInstance(MessageLinkingMaster dataObject) {
		MessageLinkingMasterJpe jpe = jaxbSdoHelper.unwrap(dataObject, MessageLinkingMasterJpe.class);
		return jpe.getInternalKey();
	}

	@Override
	protected EntityPath<MessageLinkingMasterJpe> getEntityPath() {
		return QMessageLinkingMasterJpe.messageLinkingMasterJpe;
	}
	
	@Override
	public MessageLinkingMaster getByPk(String publicKey, MessageLinkingMaster reference) {
		return super.getByPk(publicKey, reference);
	}
	
	@Override
	public List<MessageLinkingMaster> query(int offset, int resultLimit, String groupBy, String order,
			Map<String, Object> filters) {
		return super.query(offset, resultLimit, groupBy, order, filters);
	}
	
	@Override
	public List<MessageLinkingMaster> find(FindCriteria findCriteria, CbsHeader cbsHeader) {
		return super.find(findCriteria, cbsHeader);
	}
	
	@Override
	public MessageLinkingMaster create(MessageLinkingMaster dataObject) {
		return super.create(dataObject);
	}
	
	@Override
	public MessageLinkingMaster update(MessageLinkingMaster dataObject) {
		return super.update(dataObject);
	}
	
	@Override
	public boolean delete(MessageLinkingMaster dataObject) {
		return super.delete(dataObject);
	}
	
	private XPSSWFLINKAPIType transformBdoToXmlApiType(MessageLinkingMaster dataObject, CbsXmlApiOperation oper ) {
		MessageLinkingMasterJpe jpe = jaxbSdoHelper.unwrap(dataObject);
		XPSSWFLINKAPIType api = mapper.mapToApi(jpe, oper);
		if(jpe != null && jpe.getMessageLinkingListStructList() != null && !jpe.getMessageLinkingListStructList().isEmpty()) {
			XPSSWFLINKDETAILLISTTYPEType messages = new XPSSWFLINKDETAILLISTTYPEType();
			List<XPSSWFLINKDETAILTYPEType> list = new ArrayList<>();
			for(MessageLinkingListJpe dtlJpe : jpe.getMessageLinkingListStructList()) {
				XPSSWFLINKDETAILTYPEType dtl = dtlMapper.mapToApi(dtlJpe);
				list.add(dtl);
			}
			messages.getXPSSWFLINKDETAILTYPE().addAll(list);
			api.setLINKEDMESSAGES(messages);
		}
		super.setTechColsFromDataObject(dataObject, api);
		return api;
	}

	@Override
	protected XPSSWFLINKAPIType transformBdoToXmlApiRqCreate(MessageLinkingMaster dataObject) {
		return transformBdoToXmlApiType(dataObject, CbsXmlApiOperation.INSERT);
	}

	@Override
	protected XPSSWFLINKAPIType transformBdoToXmlApiRqUpdate(MessageLinkingMaster dataObject) {
		return transformBdoToXmlApiType(dataObject, CbsXmlApiOperation.UPDATE);
	}

	@Override
	protected XPSSWFLINKAPIType transformBdoToXmlApiRqDelete(MessageLinkingMaster dataObject) {
		return null;
	}
	
	@Override
    protected Map<String, String> executeStoredProcedure(String xmlApiReq, String xmlHeaderIn) {
        String xmlApiReqProcess = xmlApiReq.replaceAll("XPS_SWF_LINK_API OPERATION=+\"(INSERT|UPDATE|DELETE)\"", "XPS_SWF_LINK_API OPERATION=\"PROCESS_AUTHORIZE\"");
        return super.executeStoredProcedure(xmlApiReqProcess, xmlHeaderIn);
    }

	@Override
	protected MessageLinkingMaster processXmlApiRs(MessageLinkingMaster dataObject, XPSSWFLINKAPIType xmlApiRs) {
		MessageLinkingMasterJpe jpe = jaxbSdoHelper.unwrap(dataObject);
		jpe = mapper.mapToJpe(xmlApiRs, jpe);
		return jaxbSdoHelper.wrap(jpe);
	}

	@Override
	protected List<MessageLinkingMaster> processXmlApiListRs(MessageLinkingMaster dataObject,
			XPSSWFLINKAPIType xmlApiRs) {
		return Collections.emptyList();
	}

	@Override
	protected Class<XPSSWFLINKAPIType> getXmlApiResponseClass() {
		return XPSSWFLINKAPIType.class;
	}
	
	@Override
	public String getMessageDetails(Long internalKey, String direction) {
		String message = "";

		if(direction.equalsIgnoreCase("I")) {
			message = this.getIncomingMessageDetails(internalKey);
		}if(direction.equalsIgnoreCase("O")) {
			message = this.getOutgoingMessageDetails(internalKey);
		}

		return message;
	}
	
	private String getIncomingMessageDetails(Long internalKey) {
		String message = "";

		XPSMESSAGEREPOSWFINAPIType xmlApiReq = new XPSMESSAGEREPOSWFINAPIType();
		xmlApiReq.setOPERATION(CbsXmlApiOperation.QUERY.getOperation());
		xmlApiReq.setINTERNALKEY(internalKey);

		try {
			String xmlApiReqStr = transformMessageDetailRequest(xmlApiReq);
			message = messageDetailRequest(xmlApiReqStr);
		} catch (Exception e) {
			throw new RuntimeException(e);
		}

		return message;
	}
	
	private String transformMessageDetailRequest (XPSMESSAGEREPOSWFINAPIType xmlApiRq) throws JAXBException {
        JAXBContext jaxbContext = getJAXBContextFromPool(XPSMESSAGEREPOSWFINAPIType.class);
        Marshaller m = jaxbContext.createMarshaller();
        StringWriter writerIn = new StringWriter();
        StreamResult requestStream = new StreamResult(writerIn);
        m.marshal(xmlApiRq, requestStream);
        String xmlString = writerIn.toString();
        if (logger != null && logger.isDebugEnabled()) {
            logger.debug("XML_API_REQUEST>>>");
            logger.debug(xmlString);
        }

        return xmlString;
    }
	
	protected String messageDetailRequest(String xmlApiReq) {
        String message = "";
        try {
            String xmlHeaderIn = convertXmlApiRqToString(createHeader());
            Map<String, String> responseMap = executeStoredProcedure(xmlApiReq, xmlHeaderIn);
            processErrors(convertXmlStringToObject(responseMap.get(SP_RES_HEADER_OUT), CUTAPIHEADEROUTCPLXType.class), null, null);
            message = responseMap.get(SP_RES_XML_API);

            if (logger != null && logger.isDebugEnabled()) {
                logger.debug("XPS_MESSAGE_REPO_SWF_IN_APIType >>>");
                logger.debug(message);
            }
        } catch (CbsRuntimeException cre) {
            throw cre;
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
        return message;
    }
	
	private String getOutgoingMessageDetails(Long internalKey) {
		String message = "";

		XPSMESSAGEREPOSWFAPIType xmlApiReq = new XPSMESSAGEREPOSWFAPIType();
		xmlApiReq.setOPERATION(CbsXmlApiOperation.QUERY.getOperation());
		xmlApiReq.setRELINTERNALKEY(internalKey);

		try {
			String xmlApiReqStr = transformOutgoingMessageDetailRequest(xmlApiReq);
			message = messageDetailOutgoingRequest(xmlApiReqStr);
		} catch (Exception e) {
			throw new RuntimeException(e);
		}

		return message;
	}
	
	
	private String transformOutgoingMessageDetailRequest (XPSMESSAGEREPOSWFAPIType xmlApiRq) throws JAXBException {
        JAXBContext jaxbContext = getJAXBContextFromPool(XPSMESSAGEREPOSWFAPIType.class);
        Marshaller m = jaxbContext.createMarshaller();
        StringWriter writerIn = new StringWriter();
        StreamResult requestStream = new StreamResult(writerIn);
        m.marshal(xmlApiRq, requestStream);
        String xmlString = writerIn.toString();
        if (logger != null && logger.isDebugEnabled()) {
            logger.debug("XML_API_REQUEST>>>");
            logger.debug(xmlString);
        }

        return xmlString;
    }
	
	protected String messageDetailOutgoingRequest(String xmlApiReq) {
        String message = "";
        try {
            String xmlHeaderIn = convertXmlApiRqToString(createHeader());
            Map<String, String> responseMap = executeStoredProcedure(xmlApiReq, xmlHeaderIn);
            processErrors(convertXmlStringToObject(responseMap.get(SP_RES_HEADER_OUT), CUTAPIHEADEROUTCPLXType.class), null, null);
            message = responseMap.get(SP_RES_XML_API);

            if (logger != null && logger.isDebugEnabled()) {
                logger.debug("XPS_MESSAGE_REPO_SWF_APIType >>>");
                logger.debug(message);
            }
        } catch (CbsRuntimeException cre) {
            throw cre;
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
        return message;
    }
}
