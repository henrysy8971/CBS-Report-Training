package com.silverlakesymmetri.cbs.xps.svc.impl;

import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.mysema.query.types.EntityPath;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.svc.AbstractBusinessService;
import com.silverlakesymmetri.cbs.commons.svc.BusinessObjectValidationCapable;
import com.silverlakesymmetri.cbs.commons.svc.ref.ReferenceNumberGeneratorService;
import com.silverlakesymmetri.cbs.xps.bdo.sdo.InwPymtMap;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.InwPymtMapJpe;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.QInwPymtMapJpe;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.id.InwPymtMapPk;
import com.silverlakesymmetri.cbs.xps.svc.InwPymtMapService;

@Service
@Transactional
public class InwPymtMapServiceImpl extends AbstractBusinessService<InwPymtMap, InwPymtMapJpe, InwPymtMapPk>
		implements InwPymtMapService, BusinessObjectValidationCapable<InwPymtMap> {

	@Autowired
	private ReferenceNumberGeneratorService referenceNumberGeneratorService;

	@Override
	protected InwPymtMapPk getIdFromDataObjectInstance(InwPymtMap dataObject) {
		return new InwPymtMapPk(dataObject.getInwMapRefNo());
	}

	@Override
	protected EntityPath<InwPymtMapJpe> getEntityPath() {
		return QInwPymtMapJpe.inwPymtMapJpe;
	}

	@Override
	public InwPymtMap getByPk(String publicKey, InwPymtMap reference) {
		return super.getByPk(publicKey, reference);
	}

	@Override
	public List<InwPymtMap> query(int offset, int resultLimit, String groupBy, String order,
			Map<String, Object> filters) {
		return super.query(offset, resultLimit, groupBy, order, filters);
	}

	@Override
	public List<InwPymtMap> find(FindCriteria findCriteria, CbsHeader cbsHeader) {
		return super.find(findCriteria, cbsHeader);
	}

	@Override
	public InwPymtMap create(InwPymtMap dataObject) {
		return super.create(dataObject);
	}

	@Override
	public InwPymtMap update(InwPymtMap dataObject) {
		return super.update(dataObject);
	}

	@Override
	public boolean delete(InwPymtMap dataObject) {
		return super.delete(dataObject);
	}

	@Override
	protected InwPymtMap preCreateValidation(InwPymtMap dataObject) {
		if (StringUtils.isEmpty(dataObject.getInwMapRefNo())) {
			referenceNumberGeneratorService.getNewRefNo(dataObject, "inwMapRefNo");
		}
		return super.preCreateValidation(dataObject);
	}

}
