package com.silverlakesymmetri.cbs.xps.svc;

import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation;
import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation.ServiceOperationType;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.svc.BusinessService;
import com.silverlakesymmetri.cbs.xps.bdo.sdo.NrStmtHeader;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.NrStmtHeaderJpe;

import java.util.List;
import java.util.Map;

public interface ExternalAcctStatementService extends BusinessService<NrStmtHeader, NrStmtHeaderJpe> {
	public static final String XPS_OP_NAME_EXTERNALACCTSTATEMENTSERVICE_GET = "ExternalAcctStatementService.get";
    public static final String XPS_OP_NAME_EXTERNALACCTSTATEMENTSERVICE_QUERY = "ExternalAcctStatementService.query";
    public static final String XPS_OP_NAME_EXTERNALACCTSTATEMENTSERVICE_FIND = "ExternalAcctStatementService.find";
    public static final String XPS_OP_NAME_EXTERNALACCTSTATEMENTSERVICE_CREATE = "ExternalAcctStatementService.create";
    public static final String XPS_OP_NAME_EXTERNALACCTSTATEMENTSERVICE_UPDATE = "ExternalAcctStatementService.update";
    public static final String XPS_OP_NAME_EXTERNALACCTSTATEMENTSERVICE_DELETE = "ExternalAcctStatementService.delete";
    
    @ServiceOperation(name = XPS_OP_NAME_EXTERNALACCTSTATEMENTSERVICE_GET, type = ServiceOperationType.GET)
    public NrStmtHeader getByPk(String publicKey, NrStmtHeader reference);

    @ServiceOperation(name = XPS_OP_NAME_EXTERNALACCTSTATEMENTSERVICE_QUERY)
    public List<NrStmtHeader> query(int offset, int resultLimit, String groupBy, String order, Map<String, Object> filters);
    
    @ServiceOperation(name = XPS_OP_NAME_EXTERNALACCTSTATEMENTSERVICE_FIND)
    public List<NrStmtHeader> find(FindCriteria findCriteria, CbsHeader cbsHeader);
    
    @ServiceOperation(name = XPS_OP_NAME_EXTERNALACCTSTATEMENTSERVICE_CREATE)
    public NrStmtHeader create(NrStmtHeader dataObject);

     @ServiceOperation(name = XPS_OP_NAME_EXTERNALACCTSTATEMENTSERVICE_UPDATE)
    public NrStmtHeader update(NrStmtHeader dataObject);

    @ServiceOperation(name = XPS_OP_NAME_EXTERNALACCTSTATEMENTSERVICE_DELETE)
    public boolean delete(NrStmtHeader dataObject);
}