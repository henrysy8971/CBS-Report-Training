package com.silverlakesymmetri.cbs.gla.svc;

import java.util.List;
import java.util.Map;

import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation;
import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation.ServiceOperationType;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.svc.BusinessService;
import com.silverlakesymmetri.cbs.gla.bdo.sdo.GlAccount;
import com.silverlakesymmetri.cbs.gla.jpa.mapping.sdo.GlAccountJpe;

public interface GlAccountService extends BusinessService<GlAccount, GlAccountJpe> {

	public static final String SVC_OP_NAME_GLACCOUNTSERVICE_GET = "GlAccountService.get";
	public static final String SVC_OP_NAME_GLACCOUNTSERVICE_QUERY = "GlAccountService.query";
	public static final String SVC_OP_NAME_GLACCOUNTSERVICE_CREATE = "GlAccountService.create";
	public static final String SVC_OP_NAME_GLACCOUNTSERVICE_UPDATE = "GlAccountService.update";
	public static final String SVC_OP_NAME_GLACCOUNTSERVICE_DELETE = "GlAccountService.delete";
	public static final String SVC_OP_NAME_GLACCOUNTSERVICE_FIND = "GlAccountService.find";
	public static final String SVC_OP_NAME_GLACCOUNTSERVICE_GETAUTOINTACCTCREATIONGLCODES = "GlAccountService.getautointacctcreationglcodes";
    public static final String SVC_OP_NAME_GLACCOUNTSERVICE_FIND_GL_CODE_FOR_DWP = "GlAccountService.findGlCodeForDwp";
    public static final String SVC_OP_NAME_GLACCOUNTSERVICE_FIND_ACCT_STATUS = "GlAccountService.findAcctStatus";
    public static final String SVC_OP_NAME_GLACCOUNTSERVICE_LOV_FOR_CASHFLOWMAP = "GlAccountService.lovForSeqNoCashFlowMap";
    public static final String SVC_OP_NAME_GLACCOUNTSERVICE_FIND_SEQ_NO_FOR_BATCH = "GlAccountService.findSeqNoForBatch";
	public static final String SVC_OP_NAME_GLACCOUNTSERVICE_COUNT = "GlAccountService.count";
	@ServiceOperation(name = SVC_OP_NAME_GLACCOUNTSERVICE_GET, type = ServiceOperationType.GET)
	public GlAccount getByPk(String publicKey, GlAccount reference);

	@ServiceOperation(name = SVC_OP_NAME_GLACCOUNTSERVICE_CREATE)
	public GlAccount create(GlAccount dataObject);

	@ServiceOperation(name = SVC_OP_NAME_GLACCOUNTSERVICE_UPDATE)
	public GlAccount update(GlAccount dataObject);

	@ServiceOperation(name = SVC_OP_NAME_GLACCOUNTSERVICE_QUERY)
	public List<GlAccount> query(int offset, int resultLimit, String groupBy, String order, Map<String, Object> filters);

	@ServiceOperation(name = SVC_OP_NAME_GLACCOUNTSERVICE_DELETE)
	public boolean delete(GlAccount dataObject);

	@ServiceOperation(name = SVC_OP_NAME_GLACCOUNTSERVICE_FIND)
	public List<GlAccount> find(FindCriteria findCriteria, CbsHeader cbsHeader);

	@ServiceOperation(name = SVC_OP_NAME_GLACCOUNTSERVICE_GETAUTOINTACCTCREATIONGLCODES, type = ServiceOperationType.GET)
	public List<String> getautointacctcreationglcodes();

    @ServiceOperation(name = SVC_OP_NAME_GLACCOUNTSERVICE_FIND_GL_CODE_FOR_DWP, type = ServiceOperationType.READ, 
            passParamAsMap = true)
    public List<GlAccount> findGlCodeForDwp(Map<String, Object> queryParams);

    @ServiceOperation(name = SVC_OP_NAME_GLACCOUNTSERVICE_LOV_FOR_CASHFLOWMAP, type = ServiceOperationType.READ, 
            passParamAsMap = true)
    public List<GlAccount> lovForSeqNoCashFlowMap(Map<String, Object> queryParams);

    @ServiceOperation(name = SVC_OP_NAME_GLACCOUNTSERVICE_FIND_SEQ_NO_FOR_BATCH, type = ServiceOperationType.READ,
            passParamAsMap = true)
    public List<GlAccount> findSeqNoForBatch(Map<String, Object> queryParams);

	@ServiceOperation(name = SVC_OP_NAME_GLACCOUNTSERVICE_COUNT, type = ServiceOperationType.GET)
	public Long count(FindCriteria findCriteria, CbsHeader cbsHeader);

}
