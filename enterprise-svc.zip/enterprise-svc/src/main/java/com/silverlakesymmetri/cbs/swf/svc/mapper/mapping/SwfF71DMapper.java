package com.silverlakesymmetri.cbs.swf.svc.mapper.mapping;

import org.mapstruct.InheritInverseConfiguration;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Mappings;

import com.silverlakesymmetri.cbs.swf.jpa.mapping.sdo.SwfF71DJpe;
import com.silverlakesymmetri.cbs.swf.xmlapi.SWFF71DTYPEType;

@Mapper(uses = SwfChargeNarrativeMapper.class)
public interface SwfF71DMapper {
	@Mappings({
		@Mapping(source="opt", target="OPT"),
		@Mapping(source="swfChargeNarrativeList", target="DETAILS.SWFCHARGENARRATIVETYPE") 
	})
	SWFF71DTYPEType mapToApi(SwfF71DJpe jpe);
	
	@InheritInverseConfiguration(name = "mapToApi")
	SwfF71DJpe mapToJpe(SWFF71DTYPEType api);
}