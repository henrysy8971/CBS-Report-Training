package com.silverlakesymmetri.cbs.xps.svc.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.mysema.query.types.EntityPath;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.jpa.service.impl.BusinessDataObjectJpaQueryComponentImpl;
import com.silverlakesymmetri.cbs.commons.svc.AbstractBusinessService;
import com.silverlakesymmetri.cbs.commons.svc.util.InMemoryQueryExecutor;
import com.silverlakesymmetri.cbs.xps.bdo.sdo.Charges;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.ChargesJpe;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.QChargesJpe;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.util.XpsJpeConstants;
import com.silverlakesymmetri.cbs.xps.svc.ChargesService;

@Service
@Transactional
public class ChargesServiceImpl extends AbstractBusinessService<Charges, ChargesJpe, String> implements ChargesService {

    @Override
    public Charges getByPk(String publicKey, Charges reference) {
    	return super.getByPk(publicKey, reference);
    }

    @Override
    public List<Charges> find(FindCriteria findCriteria, CbsHeader cbsHeader) {
        return super.find(findCriteria, cbsHeader);
    }

    @Override
    protected String getIdFromDataObjectInstance(Charges dataObject) {
        return dataObject.getChargeRefNo();
    }

    @Override
    protected EntityPath<ChargesJpe> getEntityPath() {
        return QChargesJpe.chargesJpe;
    }
    
    private List<Charges> getChargeNoLovResult(int offset, int resultLimit, String groupBy, String order) {
    	List<Charges> chargeList = new ArrayList<Charges>();
    	List<ChargesJpe> chargeJpeList = dataService.findWithNamedQuery(XpsJpeConstants.FIND_CHARGE_BY_NULL_CLIENT_ID, ChargesJpe.class);
        if (chargeJpeList != null && chargeJpeList.size() > 0) {
        	for (ChargesJpe jpe : chargeJpeList) {
        		Charges bdo = jaxbSdoHelper.wrap(jpe, Charges.class);
        		chargeList.add(bdo);
			}
        	FindCriteria fc = jaxbSdoHelper.wrap(BusinessDataObjectJpaQueryComponentImpl
					.buildFindCriteria(offset, resultLimit, groupBy, order, null));
			InMemoryQueryExecutor<Charges> inMemQry = new InMemoryQueryExecutor<>(chargeList);
			return inMemQry.executeFilter(fc);
        } else {
        	return chargeList;
        }
    }

	@Override
	public List<Charges> query(int offset, int resultLimit, String groupBy, String order, Map<String, Object> filters) {
		List<Charges> chargeList = new ArrayList<Charges>();
		if (filters.get("chargeNoLov") != null) {
	        return getChargeNoLovResult(offset, resultLimit, groupBy, order);
		} else if (filters.get("chargeNoLovValidation") != null) {
			chargeList.clear();
			if (filters.get("chargeNo") == null) {
				return getChargeNoLovResult(offset, resultLimit, groupBy, order);
			} else {
				Map<String, Object> param = new HashMap<String, Object>();
		        param.put("chargeNo", filters.remove("chargeNo").toString());
				List<ChargesJpe> chargeJpeList = dataService.findWithNamedQuery(XpsJpeConstants.FIND_CHARGE_LOV_BY_CHARGE_NO, param, ChargesJpe.class);
		        if (chargeJpeList != null && chargeJpeList.size() > 0) {
		        	for (ChargesJpe jpe : chargeJpeList) {
		        		Charges bdo = jaxbSdoHelper.wrap(jpe, Charges.class);
		        		chargeList.add(bdo);
					}
		        	FindCriteria fc = jaxbSdoHelper.wrap(BusinessDataObjectJpaQueryComponentImpl
							.buildFindCriteria(offset, resultLimit, groupBy, order, null));
					InMemoryQueryExecutor<Charges> inMemQry = new InMemoryQueryExecutor<>(chargeList);
					return inMemQry.executeFilter(fc);
		        } else {
		        	return chargeList;
		        }
	        }
		}
		
		return super.query(offset, resultLimit, groupBy, order, filters);
	}

}
