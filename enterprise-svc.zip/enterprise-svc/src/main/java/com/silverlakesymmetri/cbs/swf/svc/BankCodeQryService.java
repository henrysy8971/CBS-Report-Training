package com.silverlakesymmetri.cbs.swf.svc;


import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation;
import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation.ServiceOperationType;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.svc.BusinessService;
import com.silverlakesymmetri.cbs.swf.bdo.sdo.BankCodeQry;
import com.silverlakesymmetri.cbs.swf.jpa.mapping.sdo.BankCodeQryJpe;

import java.util.List;
import java.util.Map;

public interface BankCodeQryService extends BusinessService<BankCodeQry, BankCodeQryJpe> {

    String SVC_OP_NAME_BANK_CODE_SERVICE_GET = "BankCodeQryService.get";
    String SVC_OP_NAME_BANK_CODE_SERVICE_QUERY = "BankCodeQryService.query";
    String SVC_OP_NAME_BANK_CODE_SERVICE_CREATE = "BankCodeQryService.create";
    String SVC_OP_NAME_BANK_CODE_SERVICE_UPDATE = "BankCodeQryService.update";
    String SVC_OP_NAME_BANK_CODE_SERVICE_DELETE = "BankCodeQryService.delete";
    String SVC_OP_NAME_BANK_CODE_SERVICE_FIND = "BankCodeQryService.find";
    String SVC_OP_NAME_BANK_CODE_SERVICE_COUNT = "BankCodeQryService.count";

    @ServiceOperation(name = SVC_OP_NAME_BANK_CODE_SERVICE_GET, type = ServiceOperationType.GET)
    BankCodeQry getByPk(String publicKey, BankCodeQry reference);

    @ServiceOperation(name = SVC_OP_NAME_BANK_CODE_SERVICE_CREATE)
    BankCodeQry create(BankCodeQry dataObject);

    @ServiceOperation(name = SVC_OP_NAME_BANK_CODE_SERVICE_UPDATE)
    BankCodeQry update(BankCodeQry dataObject);

    @ServiceOperation(name = SVC_OP_NAME_BANK_CODE_SERVICE_QUERY)
    List<BankCodeQry> query(int offset, int resultLimit, String groupBy, String order, Map<String, Object> filters);

    @ServiceOperation(name = SVC_OP_NAME_BANK_CODE_SERVICE_DELETE)
    boolean delete(BankCodeQry dataObject);

    @ServiceOperation(name = SVC_OP_NAME_BANK_CODE_SERVICE_FIND)
    List<BankCodeQry> find(FindCriteria findCriteria, CbsHeader cbsHeader);

    @ServiceOperation(name = SVC_OP_NAME_BANK_CODE_SERVICE_COUNT, type = ServiceOperationType.GET)
    public Long count(FindCriteria findCriteria, CbsHeader cbsHeader);

}
