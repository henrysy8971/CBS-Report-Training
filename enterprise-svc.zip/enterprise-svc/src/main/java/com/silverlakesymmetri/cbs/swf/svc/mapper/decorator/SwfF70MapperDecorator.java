package com.silverlakesymmetri.cbs.swf.svc.mapper.decorator;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

import com.silverlakesymmetri.cbs.swf.jpa.mapping.sdo.SwfF70Jpe;
import com.silverlakesymmetri.cbs.swf.svc.mapper.mapping.SwfF70Mapper;
import com.silverlakesymmetri.cbs.swf.xmlapi.SWFF70TYPEType;

public abstract class SwfF70MapperDecorator implements SwfF70Mapper {
	
	@Autowired
	@Qualifier("delegate")
	protected SwfF70Mapper delegate;

	@Override
	public SWFF70TYPEType mapToApi(SwfF70Jpe jpe){
		SWFF70TYPEType swfF70 = delegate.mapToApi(jpe);
		if(swfF70 != null){
			if(swfF70.getDETAILS() == null || swfF70.getDETAILS().getSWFSNDRRCVRNARRATIVETYPE() == null || swfF70.getDETAILS().getSWFSNDRRCVRNARRATIVETYPE().size() == 0){
				return null;
			}
		}
		return swfF70;
	}
	
	@Override
	public SwfF70Jpe mapToJpe(SWFF70TYPEType api){
		return delegate.mapToJpe(api);
	}
	
}
