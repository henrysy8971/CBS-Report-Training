package com.silverlakesymmetri.cbs.xps.svc.impl;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.mysema.query.types.EntityPath;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.svc.AbstractBusinessService;
import com.silverlakesymmetri.cbs.xps.bdo.sdo.MessageQSWIFT;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.MessageQSWIFTJpe;
import com.silverlakesymmetri.cbs.xps.svc.MessageQSWIFTService;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.QMessageQSWIFTJpe;

@Service
@Transactional
public class MessageQSWIFTServiceImpl extends AbstractBusinessService<MessageQSWIFT, MessageQSWIFTJpe, Long> implements MessageQSWIFTService{

	@Override
	protected Long getIdFromDataObjectInstance(MessageQSWIFT dataObject) {
		return dataObject.getInternalKey();
	}

	@Override
	protected EntityPath<MessageQSWIFTJpe> getEntityPath() {
		return QMessageQSWIFTJpe.messageQSWIFTJpe;
	}

	@Override
	public MessageQSWIFT get(MessageQSWIFT objectInstanceIdentifier) {
		return super.get(objectInstanceIdentifier);
	}

	@Override
	public List<MessageQSWIFT> query(int offset, int resultLimit, String groupBy, String order,
			Map<String, Object> filters) {
		return super.query(offset, resultLimit, groupBy, order, filters);
	}

	@Override
	public List<MessageQSWIFT> find(FindCriteria findCriteria, CbsHeader cbsHeader) {
		return super.find(findCriteria, cbsHeader);
	}

	@Override
	public MessageQSWIFT getByPk(String publicKey, MessageQSWIFT reference) {
		return super.getByPk(publicKey, reference);
	}

}
