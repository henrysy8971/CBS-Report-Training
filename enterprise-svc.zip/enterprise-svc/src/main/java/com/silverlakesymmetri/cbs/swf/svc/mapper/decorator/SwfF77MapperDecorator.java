package com.silverlakesymmetri.cbs.swf.svc.mapper.decorator;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

import com.silverlakesymmetri.cbs.swf.jpa.mapping.sdo.SwfF77Jpe;
import com.silverlakesymmetri.cbs.swf.svc.mapper.mapping.SwfF77Mapper;
import com.silverlakesymmetri.cbs.swf.xmlapi.SWFF77TYPEType;

public abstract class SwfF77MapperDecorator implements SwfF77Mapper {
	
	@Autowired
	@Qualifier("delegate")
	protected SwfF77Mapper delegate;

	@Override
	public SWFF77TYPEType mapToApi(SwfF77Jpe jpe){
		SWFF77TYPEType swfF77 = delegate.mapToApi(jpe);
		if(swfF77 != null){
			if(swfF77.getDETAILS() == null || swfF77.getDETAILS().getSWFF77NARRATIVETYPE() == null || swfF77.getDETAILS().getSWFF77NARRATIVETYPE().size() == 0){
				return null;
			}
		}
		return swfF77;
	}
	
	@Override
	public SwfF77Jpe mapToJpe(SWFF77TYPEType api){
		return delegate.mapToJpe(api);
	}
	
}
