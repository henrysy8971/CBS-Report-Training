package com.silverlakesymmetri.cbs.xps.svc.batch.reader;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import javax.annotation.PostConstruct;

import org.apache.commons.lang3.StringUtils;
import org.springframework.batch.item.ItemReader;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

import com.silverlakesymmetri.cbs.commons.jpa.service.CbsBatchGenericDataService;
import com.silverlakesymmetri.cbs.commons.logging.CbsAppLogger;
import com.silverlakesymmetri.cbs.commons.logging.CbsAppLoggerFactory;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.MessageQJpe;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.util.XpsJpeConstants;

public class MessageQueueListItemReader implements ItemReader<MessageQJpe> {

	private CbsAppLogger logger = CbsAppLoggerFactory.getLogger(MessageQueueListItemReader.class.getName());
	private static final String LIST_DELIMITER = "~";
	
	@Autowired(required = true)
	@Qualifier("cbsBatchGenericDataService")
	CbsBatchGenericDataService cbsBatchGenericDataService;

	List<MessageQJpe> itemList;
	String itemListStr;

	public String getItemListStr() {
		return itemListStr;
	}

	public void setItemListStr(String itemListStr) {
		this.itemListStr = itemListStr;
	}

	@Override
	public MessageQJpe read() {
		if (!itemList.isEmpty()) {
			return itemList.remove(0);
		}
		return null;
	}

	@PostConstruct
	private void initList() {
		this.itemList = new ArrayList<>();

		if (StringUtils.isBlank(itemListStr)) {
			logger.warn("Noting to process. itemListStr is blank");
		} else {
			String[] keysArray = itemListStr.split(LIST_DELIMITER);
			if (keysArray != null && keysArray.length > 0) {
				List<String> internalKeysStr = Arrays.asList(keysArray);
				List<Long> keyList = internalKeysStr.stream().map(Long::valueOf).collect(Collectors.toList());
				
				Map<String, Object> params = Collections.singletonMap("keys", keyList);
				List<MessageQJpe> jpeList = this.cbsBatchGenericDataService
						.findWithNamedQuery(XpsJpeConstants.MESSAGE_Q_JPE_FIND_BY_KEYS, params, MessageQJpe.class);

				if (jpeList == null || jpeList.isEmpty()) {
					logger.warn("jpeList is empty. Nothing to processs!");
				}

				this.itemList = jpeList;
			} else {
				logger.warn("Noting to process. keysArray is empty");
			}
		}
	}
}
