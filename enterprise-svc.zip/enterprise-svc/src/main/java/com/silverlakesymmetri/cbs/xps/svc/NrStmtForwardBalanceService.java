package com.silverlakesymmetri.cbs.xps.svc;

import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation;
import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation.ServiceOperationType;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.svc.BusinessService;
import com.silverlakesymmetri.cbs.xps.bdo.sdo.NrStmtForwardBalance;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.NrStmtForwardBalanceJpe;

import java.util.List;
import java.util.Map;

public interface NrStmtForwardBalanceService extends BusinessService<NrStmtForwardBalance, NrStmtForwardBalanceJpe> {
	public static final String XPS_OP_NAME_NRSTMTFWDBALSERVICE_GET = "NrStmtForwardBalanceService.get";
    public static final String XPS_OP_NAME_NRSTMTFWDBALSERVICE_QUERY = "NrStmtForwardBalanceService.query";
    public static final String XPS_OP_NAME_NRSTMTFWDBALSERVICE_FIND = "NrStmtForwardBalanceService.find";
    public static final String XPS_OP_NAME_NRSTMTFWDBALSERVICE_CREATE = "NrStmtForwardBalanceService.create";
    public static final String XPS_OP_NAME_NRSTMTFWDBALSERVICE_UPDATE = "NrStmtForwardBalanceService.update";
    public static final String XPS_OP_NAME_NRSTMTFWDBALSERVICE_DELETE = "NrStmtForwardBalanceService.delete";
    
    @ServiceOperation(name = XPS_OP_NAME_NRSTMTFWDBALSERVICE_GET, type = ServiceOperationType.GET)
    public NrStmtForwardBalance getByPk(String publicKey, NrStmtForwardBalance reference);

    @ServiceOperation(name = XPS_OP_NAME_NRSTMTFWDBALSERVICE_QUERY)
    public List<NrStmtForwardBalance> query(int offset, int resultLimit, String groupBy, String order, Map<String, Object> filters);
    
    @ServiceOperation(name = XPS_OP_NAME_NRSTMTFWDBALSERVICE_FIND)
    public List<NrStmtForwardBalance> find(FindCriteria findCriteria, CbsHeader cbsHeader);
    
    @ServiceOperation(name = XPS_OP_NAME_NRSTMTFWDBALSERVICE_CREATE)
    public NrStmtForwardBalance create(NrStmtForwardBalance dataObject);

     @ServiceOperation(name = XPS_OP_NAME_NRSTMTFWDBALSERVICE_UPDATE)
    public NrStmtForwardBalance update(NrStmtForwardBalance dataObject);

    @ServiceOperation(name = XPS_OP_NAME_NRSTMTFWDBALSERVICE_DELETE)
    public boolean delete(NrStmtForwardBalance dataObject);
}