package com.silverlakesymmetri.cbs.xps.svc;

import java.util.List;
import java.util.Map;

import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation;
import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation.ServiceOperationType;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.svc.BusinessService;
import com.silverlakesymmetri.cbs.xps.bdo.sdo.DocumentDomainReqt;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.DocumentDomainReqtJpe;

public interface DocumentDomainReqtService extends BusinessService<DocumentDomainReqt, DocumentDomainReqtJpe> {
	public static final String XPS_OP_NAME_DOCUMENTDOMAINREQTSERVICE_GET = "documentDomainReqtService.get";
    public static final String XPS_OP_NAME_DOCUMENTDOMAINREQTSERVICE_QUERY = "documentDomainReqtService.query";
    public static final String XPS_OP_NAME_DOCUMENTDOMAINREQTSERVICE_FIND = "documentDomainReqtService.find";
    public static final String XPS_OP_NAME_DOCUMENTDOMAINREQTSERVICE_CREATE = "documentDomainReqtService.create";
    public static final String XPS_OP_NAME_DOCUMENTDOMAINREQTSERVICE_UPDATE = "documentDomainReqtService.update";
    public static final String XPS_OP_NAME_DOCUMENTDOMAINREQTSERVICE_DELETE = "documentDomainReqtService.delete";
    
    @ServiceOperation(name = XPS_OP_NAME_DOCUMENTDOMAINREQTSERVICE_GET, type = ServiceOperationType.GET)
    public DocumentDomainReqt getByPk(String publicKey, DocumentDomainReqt reference);

    @ServiceOperation(name = XPS_OP_NAME_DOCUMENTDOMAINREQTSERVICE_QUERY)
    public List<DocumentDomainReqt> query(int offset, int resultLimit, String groupBy, String order, Map<String, Object> filters);
    
    @ServiceOperation(name = XPS_OP_NAME_DOCUMENTDOMAINREQTSERVICE_FIND)
    public List<DocumentDomainReqt> find(FindCriteria findCriteria, CbsHeader cbsHeader);
    
    @ServiceOperation(name = XPS_OP_NAME_DOCUMENTDOMAINREQTSERVICE_CREATE)
    public DocumentDomainReqt create(DocumentDomainReqt dataObject);

     @ServiceOperation(name = XPS_OP_NAME_DOCUMENTDOMAINREQTSERVICE_UPDATE)
    public DocumentDomainReqt update(DocumentDomainReqt dataObject);

    @ServiceOperation(name = XPS_OP_NAME_DOCUMENTDOMAINREQTSERVICE_DELETE)
    public boolean delete(DocumentDomainReqt dataObject);
}