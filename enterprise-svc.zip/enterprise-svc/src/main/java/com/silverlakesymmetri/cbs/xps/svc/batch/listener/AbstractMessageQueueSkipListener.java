package com.silverlakesymmetri.cbs.xps.svc.batch.listener;

import java.util.Date;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.springframework.batch.core.SkipListener;
import org.springframework.beans.factory.annotation.Autowired;

import com.silverlakesymmetri.cbs.commons.jpa.service.CbsBatchGenericDataService;
import com.silverlakesymmetri.cbs.commons.logging.CbsAppLogger;
import com.silverlakesymmetri.cbs.commons.logging.CbsAppLoggerFactory;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.MessageQJpe;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.MessageQStpJpe;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.util.XpsJpeConstants;

public abstract class AbstractMessageQueueSkipListener<I, O> implements SkipListener<I, O> {
	private static CbsAppLogger logger = CbsAppLoggerFactory.getLogger(AbstractMessageQueueSkipListener.class);

	@Autowired
	protected CbsBatchGenericDataService batchDataService;

	@Override
	public void onSkipInRead(Throwable t) {
		t.printStackTrace();
	}

	@Override
	public void onSkipInWrite(O item, Throwable t) {
		t.printStackTrace();
	}

	@Override
	public void onSkipInProcess(I item, Throwable t) {
		if (item instanceof MessageQJpe) {
			logger.error("Process failed for item: {} -> {}", ((MessageQJpe) item).getInternalKey(), t.getMessage());
		} else if (item instanceof MessageQStpJpe) {
			logger.error("Process failed for item: {} -> {}", ((MessageQStpJpe) item).getInternalKey(), t.getMessage());
		}
		t.printStackTrace();

		updateStatusToFailed(item, t);
	}

	protected void updateStatusToFailed(I item, Throwable t) {
		if (item instanceof MessageQJpe) {
			MessageQJpe jpe = (MessageQJpe) item;

			String errorDetails = ExceptionUtils.getStackTrace(t);
			errorDetails = StringUtils.substring(errorDetails, 0, 1000);

			jpe.setStatus(getFailedStatus());
			jpe.setDateSent(new Date());
			jpe.setErrorDetails(errorDetails);
			batchDataService.update(jpe);
		} else if (item instanceof MessageQStpJpe) {
			MessageQStpJpe jpe = (MessageQStpJpe) item;
			
			String errorDetails = ExceptionUtils.getStackTrace(t);
			errorDetails = StringUtils.substring(errorDetails, 0, 1000);
			
			jpe.setStatus(getFailedStatus());
			jpe.setDateSent(new Date());
			jpe.setErrorDetails(errorDetails);
			batchDataService.update(jpe);
		}
	};
	
	protected String getFailedStatus(){
		return XpsJpeConstants.MESSAG_Q_STATUS_FAILED;
	}
}
