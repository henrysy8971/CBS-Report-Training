package com.silverlakesymmetri.cbs.xps.svc;

import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation;
import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation.ServiceOperationType;
import com.silverlakesymmetri.cbs.commons.bdo.sdo.DmsFile;
import com.silverlakesymmetri.cbs.commons.svc.BusinessService;
import com.silverlakesymmetri.cbs.xps.bdo.sdo.AdvicePreview;
import com.silverlakesymmetri.cbs.xps.bdo.sdo.MessageControlQWrapper;
import com.silverlakesymmetri.cbs.xps.bdo.sdo.MessageQOthers;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.MessageControlQWrapperJpe;

public interface MessageControlQWrapperService extends BusinessService<MessageControlQWrapper, MessageControlQWrapperJpe> {
    public static final String XPS_OP_NAME_MESSAGECONTROLQWRAPPERSERVICE_UPDATESTATUS = "MessageControlQWrapperService.updatestatus";
    public static final String XPS_OP_NAME_MESSAGECONTROLQWRAPPERSERVICE_GET_PREVIEW = "MessageControlQWrapperService.getpreview";
    public static final String XPS_OP_NAME_MESSAGECONTROLQWRAPPERSERVICE_GET_FILE = "MessageControlQWrapperService.getfile";
    public static final String XPS_OP_NAME_MESSAGECONTROLQWRAPPERSERVICE_SEND_EMAIL = "MessageControlQWrapperService.sendemail";
    public static final String XPS_OP_NAME_MESSAGECONTROLQWRAPPERSERVICE_SPOOL_FILE = "MessageControlQWrapperService.spoolfile";
    public static final String XPS_OP_NAME_MESSAGECONTROLQWRAPPERSERVICE_GET_SWIFT_MESSAGE = "MessageControlQWrapperService.getswiftmessage";

    @ServiceOperation(name = XPS_OP_NAME_MESSAGECONTROLQWRAPPERSERVICE_UPDATESTATUS, type = ServiceOperationType.EXECUTE)
    public MessageControlQWrapper updateStatus(MessageControlQWrapper dataObject);
    
    @ServiceOperation(name = XPS_OP_NAME_MESSAGECONTROLQWRAPPERSERVICE_GET_PREVIEW, type = ServiceOperationType.EXECUTE)
    public AdvicePreview getPreview(MessageQOthers bdo);

    @ServiceOperation(name = XPS_OP_NAME_MESSAGECONTROLQWRAPPERSERVICE_GET_FILE, type = ServiceOperationType.GET)
    public DmsFile getFile(String jcrId);
    
    @ServiceOperation(name = XPS_OP_NAME_MESSAGECONTROLQWRAPPERSERVICE_SEND_EMAIL, type = ServiceOperationType.EXECUTE)
    public Boolean sendEmail(MessageQOthers bdo);
    
    @ServiceOperation(name = XPS_OP_NAME_MESSAGECONTROLQWRAPPERSERVICE_SPOOL_FILE, type = ServiceOperationType.EXECUTE)
    public Boolean spoolFile(MessageQOthers bdo);
    
    @ServiceOperation(name = XPS_OP_NAME_MESSAGECONTROLQWRAPPERSERVICE_GET_SWIFT_MESSAGE, type = ServiceOperationType.GET)
    public String getSwiftMessage(Long relInternalKey);
    
    public String getFormattedMessageForPreview(Long relInternalKey, String module, String format, String sender, String receiver);
    
}