package com.silverlakesymmetri.cbs.xps.svc.impl;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.mysema.query.types.EntityPath;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.exception.CbsRuntimeException;
import com.silverlakesymmetri.cbs.commons.exception.base.CbsServiceProcessException;
import com.silverlakesymmetri.cbs.commons.svc.AbstractBusinessService;
import com.silverlakesymmetri.cbs.commons.svc.BusinessObjectValidationCapable;
import com.silverlakesymmetri.cbs.xps.bdo.sdo.AdviceTemplate;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.AdviceTemplateJpe;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.QAdviceTemplateJpe;
import com.silverlakesymmetri.cbs.xps.svc.AdviceTemplateService;

@Service
@Transactional
public class AdviceTemplateServiceImpl extends AbstractBusinessService<AdviceTemplate, AdviceTemplateJpe, String> implements AdviceTemplateService, BusinessObjectValidationCapable<AdviceTemplate> {
	
	private final String SCRIPT_TAG = "&lt;script";
	
	@Override
	protected String getIdFromDataObjectInstance(AdviceTemplate dataObject) {
		return dataObject.getDocument();
	}

	@Override
	protected EntityPath<AdviceTemplateJpe> getEntityPath() {
		return QAdviceTemplateJpe.adviceTemplateJpe;
	}

	@Override
	public AdviceTemplate getByPk(String publicKey, AdviceTemplate reference) {
		AdviceTemplate bdo = super.getByPk(publicKey, reference);
		return bdo;
	}

	@Override
	public List<AdviceTemplate> query(int offset, int resultLimit, String groupBy, String order, Map<String, Object> filters) {
		return super.query(offset, resultLimit, groupBy, order, filters);
	}
	
	@Override
	public List<AdviceTemplate> find(FindCriteria fc, CbsHeader cbsHeader){
		return super.find(fc, cbsHeader);
	}
	
	@Override
	public AdviceTemplate preCreateValidation(AdviceTemplate dataObject) {
		if(dataObject.getBodyTemplate() != null && dataObject.getBodyTemplate().indexOf(SCRIPT_TAG) >= 0) {
            String msg = messageUtils.getMessage("CBS.B.XPS.ADVICETEMPLATESERVICE.0005", new String[] {});
            CbsServiceProcessException exec = new CbsServiceProcessException("CBS.B.XPS.ADVICETEMPLATESERVICE.0005", msg);
            throw exec;
		}
		return super.preCreateValidation(dataObject);
	}
	
	@Override
	public AdviceTemplate create(AdviceTemplate dataObject) {
		return super.create(dataObject);
	}

	@Override
	public AdviceTemplate update(AdviceTemplate dataObject) {
		return super.update(dataObject);
	}
	
	@Override
	public boolean delete(AdviceTemplate dataObject) {
		return super.delete(dataObject);
	}
}