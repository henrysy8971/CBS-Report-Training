package com.silverlakesymmetri.cbs.xps.svc;

import java.util.List;
import java.util.Map;

import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation;
import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation.ServiceOperationType;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.bdo.sdo.DmsFile;
import com.silverlakesymmetri.cbs.commons.svc.BusinessService;
import com.silverlakesymmetri.cbs.xps.bdo.sdo.AdvicePreview;
import com.silverlakesymmetri.cbs.xps.bdo.sdo.MarginSettlement;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.MarginSettlementJpe;

public interface MarginSettlementService extends BusinessService<MarginSettlement, MarginSettlementJpe> {
	public static final String XPS_MARGINSETTLEMENTSERVICE_GET = "MarginSettlementService.get";
    public static final String XPS_MARGINSETTLEMENTSERVICE_QUERY = "MarginSettlementService.query";
    public static final String XPS_MARGINSETTLEMENTSERVICE_FIND = "MarginSettlementService.find";
    public static final String XPS_MARGINSETTLEMENTSERVICE_CREATE = "MarginSettlementService.create";
    public static final String XPS_MARGINSETTLEMENTSERVICE_UPDATE = "MarginSettlementService.update";
    public static final String XPS_MARGINSETTLEMENTSERVICE_COUNT = "MarginSettlementService.count";
	public static final String XPS_MARGINSETTLEMENTSERVICE_SWFMSG = "MarginSettlementService.generateSwfMessage";
    public static final String XPS_MARGINSETTLEMENTSERVICE_EMAILPREVIEW = "MarginSettlementService.generateEmailPreview";
    public static final String XPS_MARGINSETTLEMENTSERVICE_GENADVICE = "MarginSettlementService.generateAdvice";

    @ServiceOperation(name = XPS_MARGINSETTLEMENTSERVICE_GET, type = ServiceOperationType.GET)
    public MarginSettlement getByPk(String publicKey, MarginSettlement reference);

    @ServiceOperation(name = XPS_MARGINSETTLEMENTSERVICE_QUERY)
    public List<MarginSettlement> query(int offset, int resultLimit, String groupBy, String order, Map<String, Object> filters);
    
    @ServiceOperation(name = XPS_MARGINSETTLEMENTSERVICE_FIND)
    public List<MarginSettlement> find(FindCriteria findCriteria, CbsHeader cbsHeader);
    
    @ServiceOperation(name = XPS_MARGINSETTLEMENTSERVICE_COUNT, type = ServiceOperationType.GET)
    public Long count(FindCriteria findCriteria, CbsHeader cbsHeader);

    @ServiceOperation(name = XPS_MARGINSETTLEMENTSERVICE_CREATE)
    public MarginSettlement create(MarginSettlement dataObject);

    @ServiceOperation(name = XPS_MARGINSETTLEMENTSERVICE_UPDATE)
    public MarginSettlement update(MarginSettlement dataObject);

    @ServiceOperation(name = XPS_MARGINSETTLEMENTSERVICE_SWFMSG, passParamAsMap = true)
    public String generateSwfMessage(Map<String, Object> params);
    
    @ServiceOperation(name = XPS_MARGINSETTLEMENTSERVICE_EMAILPREVIEW, passParamAsMap = true)
    public AdvicePreview generateEmailPreview(Map<String, Object> params);
    
    @ServiceOperation(name = XPS_MARGINSETTLEMENTSERVICE_GENADVICE, passParamAsMap = true)
    public DmsFile generateAdvice(Map<String, Object> params);
}