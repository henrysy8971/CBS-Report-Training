package com.silverlakesymmetri.cbs.xps.svc.impl;

import com.mysema.query.types.EntityPath;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.svc.AbstractBusinessService;
import com.silverlakesymmetri.cbs.commons.svc.BusinessObjectValidationCapable;
import com.silverlakesymmetri.cbs.xps.bdo.sdo.OfBranchBookMap;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.OfBranchBookMapJpe;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.QOfBranchBookMapJpe;
import com.silverlakesymmetri.cbs.xps.svc.OfBranchBookMapService;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Map;

@Service
@Transactional
public class OfBranchBookMapServiceImpl extends AbstractBusinessService<OfBranchBookMap, OfBranchBookMapJpe, String>
        implements OfBranchBookMapService, BusinessObjectValidationCapable<OfBranchBookMap> {

    @Override
    protected String getIdFromDataObjectInstance(OfBranchBookMap dataObject) {
        return dataObject.getBranch();
    }

    @Override
    protected EntityPath<OfBranchBookMapJpe> getEntityPath() {
        return QOfBranchBookMapJpe.ofBranchBookMapJpe;
    }

    @Override
    protected OfBranchBookMap preCreateValidation(OfBranchBookMap dataObject) {

        return super.preCreateValidation(dataObject);
    }

    @Override
    public OfBranchBookMap create(OfBranchBookMap dataObject) {

        return super.create(dataObject);
    }

    @Override
    public OfBranchBookMap get(OfBranchBookMap objectInstanceIdentifier) {
        return super.get(objectInstanceIdentifier);
    }

    @Override
    public List<OfBranchBookMap> query(int offset, int resultLimit, String groupBy, String order,
                                       Map<String, Object> filters) {
        return super.query(offset, resultLimit, groupBy, order, filters);
    }

    @Override
    public OfBranchBookMap update(OfBranchBookMap dataObject) {
        return super.update(dataObject);
    }

    @Override
    public boolean delete(OfBranchBookMap dataObject) {
        return super.delete(dataObject);
    }

    @Override
    public List<OfBranchBookMap> find(FindCriteria findCriteria, CbsHeader cbsHeader) {
        return super.find(findCriteria, cbsHeader);
    }

    @Override
    public OfBranchBookMap getByPk(String publicKey, OfBranchBookMap reference) {
        return super.getByPk(publicKey, reference);
    }

}
