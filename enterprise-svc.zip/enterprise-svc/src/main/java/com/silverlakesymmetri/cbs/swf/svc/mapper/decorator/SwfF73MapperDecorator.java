package com.silverlakesymmetri.cbs.swf.svc.mapper.decorator;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

import com.silverlakesymmetri.cbs.swf.jpa.mapping.sdo.SwfF73Jpe;
import com.silverlakesymmetri.cbs.swf.svc.mapper.mapping.SwfF73Mapper;
import com.silverlakesymmetri.cbs.swf.xmlapi.SWFF73TYPEType;

public abstract class SwfF73MapperDecorator implements SwfF73Mapper {
	
	@Autowired
	@Qualifier("delegate")
	protected SwfF73Mapper delegate;

	@Override
	public SWFF73TYPEType mapToApi(SwfF73Jpe jpe){
		SWFF73TYPEType swfF73 = delegate.mapToApi(jpe);
		if(swfF73 != null){
			if(swfF73.getDETAILS() == null || swfF73.getDETAILS().getSWFCHARGENARRATIVETYPE() == null || swfF73.getDETAILS().getSWFCHARGENARRATIVETYPE().size() == 0){
				return null;
			}
		}
		return swfF73;
	}
	
	@Override
	public SwfF73Jpe mapToJpe(SWFF73TYPEType api){
		return delegate.mapToJpe(api);
	}
	
}
