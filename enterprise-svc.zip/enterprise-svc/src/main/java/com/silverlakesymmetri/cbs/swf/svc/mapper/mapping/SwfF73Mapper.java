package com.silverlakesymmetri.cbs.swf.svc.mapper.mapping;

import org.mapstruct.DecoratedWith;
import org.mapstruct.InheritInverseConfiguration;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Mappings;

import com.silverlakesymmetri.cbs.swf.jpa.mapping.sdo.SwfF73Jpe;
import com.silverlakesymmetri.cbs.swf.svc.mapper.decorator.SwfF73MapperDecorator;
import com.silverlakesymmetri.cbs.swf.xmlapi.SWFF73TYPEType;

@Mapper(uses = SwfChargeNarrativeMapper.class)
@DecoratedWith(SwfF73MapperDecorator.class)
public interface SwfF73Mapper {
	@Mappings({
		@Mapping(source="opt", target="OPT"),
		@Mapping(source="swfChargeNarrativeList", target="DETAILS.SWFCHARGENARRATIVETYPE")
	})
	SWFF73TYPEType mapToApi(SwfF73Jpe jpe);
	
	@InheritInverseConfiguration(name = "mapToApi")
	SwfF73Jpe mapToJpe(SWFF73TYPEType api);
}