package com.silverlakesymmetri.cbs.xps.svc.mapper.decorator;

import org.mapstruct.Context;
import org.mapstruct.MappingTarget;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

import com.silverlakesymmetri.cbs.commons.xmlapi.enums.CbsXmlApiOperation;
import com.silverlakesymmetri.cbs.mcl.svc.ClientService;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.MarginWithSettlementJpe;
import com.silverlakesymmetri.cbs.xps.svc.mapper.MarginWithSettlementServiceMapper;
import com.silverlakesymmetri.cbs.xps.xmlapi.XPSTRANMARGINWITHSETTLEAPIType;

public abstract class MarginWithSettlementServiceDecorator implements MarginWithSettlementServiceMapper {
	
	@Autowired
	@Qualifier("delegate")
	protected MarginWithSettlementServiceMapper delegate;
	
	@Autowired
	protected ClientService clientService;

	@Override
	public XPSTRANMARGINWITHSETTLEAPIType mapToApi(MarginWithSettlementJpe jpe, @Context CbsXmlApiOperation oper){
		XPSTRANMARGINWITHSETTLEAPIType req = (XPSTRANMARGINWITHSETTLEAPIType) delegate.mapToApi(jpe, oper);
		return  req;
	}
	
	@Override
	public MarginWithSettlementJpe mapToJpe(XPSTRANMARGINWITHSETTLEAPIType api, @MappingTarget MarginWithSettlementJpe jpe){
		delegate.mapToJpe(api, jpe);
		return jpe;
	}

}


