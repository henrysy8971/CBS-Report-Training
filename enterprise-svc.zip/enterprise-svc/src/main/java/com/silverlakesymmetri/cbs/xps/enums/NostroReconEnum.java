package com.silverlakesymmetri.cbs.xps.enums;

public enum NostroReconEnum {
	FORCEMATCH, UNMATCH, SKIP, UNSKIP;

	public static NostroReconEnum parseString(String value) {
		NostroReconEnum result = null;
    for(NostroReconEnum enumValue : values()) {
        if(enumValue.toString().equals(value)) {
            result = enumValue;
            break;
        }
    }
    return result;
  }

	public static String enumToString(NostroReconEnum value) {
		return value.toString();
	}
}
