package com.silverlakesymmetri.cbs.xps.svc.mapper.decorator;

import org.mapstruct.Context;
import org.mapstruct.MappingTarget;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

import com.silverlakesymmetri.cbs.commons.xmlapi.enums.CbsXmlApiOperation;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.ChargeSettlementJpe;
import com.silverlakesymmetri.cbs.xps.svc.mapper.ChargeSettlementServiceMapper;
import com.silverlakesymmetri.cbs.xps.xmlapi.XPSTRANCHARGESETTLEAPIType;

public abstract class ChargeSettlementServiceDecorator implements ChargeSettlementServiceMapper {
	
	@Autowired
	@Qualifier("delegate")
	protected ChargeSettlementServiceMapper delegate;

	@Override
	public XPSTRANCHARGESETTLEAPIType mapToApi(ChargeSettlementJpe jpe, @Context CbsXmlApiOperation oper){
		return delegate.mapToApi(jpe, oper);
	}
	
	@Override
	public ChargeSettlementJpe mapToJpe(XPSTRANCHARGESETTLEAPIType api, @MappingTarget ChargeSettlementJpe jpe){
		delegate.mapToJpe(api, jpe);
		return jpe;
	}

}


