package com.silverlakesymmetri.cbs.swf.svc.mapper.mapping;

import org.mapstruct.InheritInverseConfiguration;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Mappings;

import com.silverlakesymmetri.cbs.swf.jpa.mapping.sdo.SwfMtn99Jpe;
import com.silverlakesymmetri.cbs.swf.xmlapi.SWFMTN99TYPEType;

@Mapper(uses={ SwfF21Mapper.class, SwfF79Mapper.class})
public interface SwfMtn99Mapper {
	@Mappings({
		@Mapping(source="relatedRef", target="RELATEDREFERENCE"),
		@Mapping(source="narrativeStructRec", target="NARRATIVE"),
	})
	SWFMTN99TYPEType mapToApi(SwfMtn99Jpe jpe);
	
	@InheritInverseConfiguration(name="mapToApi")
	SwfMtn99Jpe mapToJpe(SWFMTN99TYPEType api);
}
