package com.silverlakesymmetri.cbs.xps.svc.batch.tasklet;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.apache.commons.lang3.tuple.Pair;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;

import com.silverlakesymmetri.cbs.commons.jpa.service.CbsBatchGenericDataService;
import com.silverlakesymmetri.cbs.commons.jpa.service.CbsGenericDataService;
import com.silverlakesymmetri.cbs.commons.logging.CbsAppLogger;
import com.silverlakesymmetri.cbs.commons.logging.CbsAppLoggerFactory;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.MessageQJpe;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.util.XpsJpeConstants;

public class MessageQueueTasklet implements Tasklet {

	private CbsAppLogger logger = CbsAppLoggerFactory.getLogger(MessageQueueTasklet.class.getName());
	private static final String ACTION_UPDATE = "UPDATE";
	private static final String ACTION_CLEANUP = "CLEANUP";
	//private static final String KEY_SPOOL_DIRECTORY = "spoolDirectory";
	//private static final String KEY_FILE_NAME = "fileName";
	private static final String LIST_DELIMITER = "~";
	private static final String STATUS_FAILED = "F";
	private static final String STATUS_SENDING = "D";
	private static final String LAST_FAILED_KEY = "lastFailedKey";
	private static final String ATTR_INTERNAL_KEY_LIST = "internalKeyList";
	
	private String action;
	private CbsBatchGenericDataService batchDataService;
	//private String itemListStr;
	
	public String getAction() {
		return action;
	}
	public void setAction(String action) {
		this.action = action;
	}
	public CbsBatchGenericDataService getBatchDataService() {
		return batchDataService;
	}
	public void setBatchDataService(CbsBatchGenericDataService batchDataService) {
		this.batchDataService = batchDataService;
	}
	/*
	public String getItemListStr() {
		return itemListStr;
	}
	public void setItemListStr(String itemListStr) {
		this.itemListStr = itemListStr;
	}
	*/

	@Override
	public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) throws Exception {
		if (ACTION_UPDATE.equals(action)) {
			// doUpdate(chunkContext);
		} else if (ACTION_CLEANUP.equals(action)) {
			//doCleanup(chunkContext);
			
			List<Long> internalKeyList = getInternalKeyList(chunkContext);
			Pair<Long, Exception> failedPair = getLastFailedKeyPair(chunkContext);
			
			updateLastFailedKey(failedPair);
			doBulkUpdateFailed(internalKeyList, failedPair);
		}

		return RepeatStatus.FINISHED;
	}
	
	private void updateLastFailedKey(Pair<Long, Exception> failedKeyPair) {
		if (failedKeyPair != null) {
			List<Long> keyList = new ArrayList<>();
			keyList.add(failedKeyPair.getLeft());
			bulkUpdate(keyList, STATUS_FAILED, failedKeyPair.getRight());
		}
	}
	
	@SuppressWarnings("unchecked")
	private Pair<Long, Exception> getLastFailedKeyPair(ChunkContext ctx){
		Object pairObj = ctx.getStepContext().getJobExecutionContext().get(LAST_FAILED_KEY);

		if (pairObj == null) {
			logger.info("key {} not found in context", LAST_FAILED_KEY);
			return null;
		}

		Pair<Long, Exception> failedKeyPair = (Pair<Long, Exception>) pairObj;
		return failedKeyPair;
	}

	private List<Long> getInternalKeyList(ChunkContext ctx){
		Object strObj = ctx.getStepContext().getJobExecutionContext().get(ATTR_INTERNAL_KEY_LIST);
		
		if(strObj == null){
			logger.warn("key {} not found in context", ATTR_INTERNAL_KEY_LIST);
			return null;
		}

		String itemListStr = (String) strObj;		
		List<Long> itemList = new ArrayList<>();

		if (StringUtils.isBlank(itemListStr)) {
			logger.warn("Noting to process. itemListStr is blank");
		} else {
			String[] keysArray = itemListStr.split(LIST_DELIMITER);
			if (keysArray != null && keysArray.length > 0) {
				List<String> internalKeysStr = Arrays.asList(keysArray);
				itemList = internalKeysStr.stream().map(Long::valueOf).collect(Collectors.toList());
			} else {
				logger.warn("Noting to process. keysArray is empty");
			}
		}
	
		return itemList;
	}
	
	private void doBulkUpdateFailed(List<Long> keyList, Pair<Long, Exception> failedKeyPair) {
		if (keyList == null || keyList.isEmpty()) {
			logger.warn("itemListStr is empty. Noting to update!");
			return;
		} else {
			//List<Long> sendingList = findMessageQKeys(keyList, STATUS_SENDING);
			List<Long> sendingList = keyList;

			//exclude last failed pair
			if (failedKeyPair != null) {
				sendingList = sendingList.stream().filter(e -> Long.compare(e, failedKeyPair.getLeft()) != 0)
						.collect(Collectors.toList());
			}

			bulkUpdate(sendingList, STATUS_SENDING, STATUS_FAILED);
		}
	}
	
	/*private List<Long> findMessageQKeys(List<Long> keys, String status) {
		if (keys == null || keys.isEmpty()) {
			logger.warn("keys is empty. Nothing to update!");
			return null;
		}
		if (StringUtils.isBlank(status)) {
			logger.warn("status is empty. Cannot proceed with find!");
			return null;
		}

		Map<String, Object> params = new HashMap<>();
		params.put("status", status);
		params.put("keys", keys);

		String qString = "SELECT t.internalKey FROM MessageQJpe t WHERE t.status = :status AND t.internalKey in :keys";
		List<Long> keyList = this.batchDataService.findWithQuery(qString, Long.class, params, null);

		if (keyList == null || keyList.isEmpty()) {
			logger.warn("no records found with keys {}", keys.toString());
		}

		return keyList;
	}*/

	private void bulkUpdate(List<Long> keys, String status, Exception e) {
		//TODO: exception should be persisted as well when ERROR_MSG column becomes available
		
		if (keys == null || keys.isEmpty()) {
			logger.warn("keys is empty. Nothing to update!");
			return;
		}
		if(StringUtils.isBlank(status)){
			logger.warn("status is empty. Cannot proceed with update!");
			return;
		}
		
		String errorDetails = null;
		if(e!=null){
			errorDetails = ExceptionUtils.getStackTrace(e);
			errorDetails = StringUtils.substring(errorDetails, 0, 1000);
		}

		Map<String, Object> params = new HashMap<>();
		params.put("status", status);
		params.put("errorDetails", errorDetails);
		params.put("keys", keys);

		batchDataService.bulkUpdateWithNamedQuery(XpsJpeConstants.MESSAGE_Q_JPE_UPDATE_STATUS_ERROR, params,
				MessageQJpe.class);
	}
	
	private void bulkUpdate(List<Long> keys, String oldStatus, String newStatus) {
		if (keys == null || keys.isEmpty()) {
			logger.warn("keys is empty. Nothing to update!");
			return;
		}
		if(StringUtils.isBlank(oldStatus)){
			logger.warn("oldStatus is empty. Cannot proceed with update!");
			return;
		}
		if(StringUtils.isBlank(newStatus)){
			logger.warn("newStatus is empty. Cannot proceed with update!");
			return;
		}
		
		Map<String, Object> params = new HashMap<>();
		params.put("newStatus", newStatus);
		params.put("oldStatus", oldStatus);
		params.put("keys", keys);
		
		batchDataService.bulkUpdateWithNamedQuery(XpsJpeConstants.MESSAGE_Q_JPE_UPDATE_STATUS_W_OLD_STATUS, params,
				MessageQJpe.class);
	}

	/*
	private void doCleanup(ChunkContext chunkContext) throws Exception {
		Object directory = getValueFromJobParam(chunkContext, KEY_SPOOL_DIRECTORY);
		Object fileName = getValueFromJobParam(chunkContext, KEY_FILE_NAME);
		String fullFilePath = null;

		if (directory != null && fileName != null) {
			fullFilePath = (String) directory + (String) fileName;
		}

		if (StringUtils.isNotBlank(fullFilePath)) {
			doFileDeletion(fullFilePath);
		}
	}

	private boolean doFileDeletion(String fullFilePath) throws IOException {
		boolean result = true;
		try {
			result = Files.deleteIfExists(Paths.get(fullFilePath));
			if (result) {
				logger.info("File is deleted:" + fullFilePath);
			} else {
				logger.warn("Unable to delete the file: " + fullFilePath);
			}
		} catch (IOException e) {
			e.printStackTrace();
			throw (e);
		}

		return result;
	}

	private Object getValueFromJobParam(ChunkContext ctx, String key) {
		Object retValue = null;

		Map<String, Object> param1 = ctx.getStepContext().getJobParameters();
		retValue = param1.get(key);
		return retValue;
	}
	*/

}
