package com.silverlakesymmetri.cbs.xps.svc;

import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation;
import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation.ServiceOperationType;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.svc.BusinessService;
import com.silverlakesymmetri.cbs.xps.bdo.sdo.DepDepositSettleQry;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.DepDepositSettleQryJpe;

import java.util.List;
import java.util.Map;


public interface DepDepositSettleQryService extends BusinessService<DepDepositSettleQry, DepDepositSettleQryJpe> {

    public static final String SVC_OP_NAME_DEPDEPOSITSETTLEQRY_GET = "DepDepositSettleQryService.get";
    public static final String SVC_OP_NAME_DEPDEPOSITSETTLEQRY_QUERY = "DepDepositSettleQryService.query";
    public static final String SVC_OP_NAME_DEPDEPOSITSETTLEQRY_FIND = "DepDepositSettleQryService.find";

    @ServiceOperation(name = SVC_OP_NAME_DEPDEPOSITSETTLEQRY_GET, type = ServiceOperationType.GET)
    public DepDepositSettleQry getByPk(String publicKey, DepDepositSettleQry reference);
    
    @ServiceOperation(name = SVC_OP_NAME_DEPDEPOSITSETTLEQRY_QUERY)
    public List<DepDepositSettleQry> query(int offset, int resultLimit, String groupBy, String order, Map<String, Object> filters);

    @ServiceOperation(name = SVC_OP_NAME_DEPDEPOSITSETTLEQRY_FIND)
    public List<DepDepositSettleQry> find(FindCriteria findCriteria, CbsHeader cbsHeader);


}
