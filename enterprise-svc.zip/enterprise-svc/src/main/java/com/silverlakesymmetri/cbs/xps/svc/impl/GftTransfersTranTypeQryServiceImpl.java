package com.silverlakesymmetri.cbs.xps.svc.impl;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.mysema.query.types.EntityPath;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.svc.AbstractBusinessService;
import com.silverlakesymmetri.cbs.commons.svc.BusinessObjectValidationCapable;
import com.silverlakesymmetri.cbs.xps.bdo.sdo.GftTransfersTranTypeQry;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.GftTransfersTranTypeQryJpe;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.QGftTransfersTranTypeQryJpe;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.id.GftTransfersTranTypeQryPk;
import com.silverlakesymmetri.cbs.xps.svc.GftTransfersTranTypeQryService;

@Service
@Transactional
public class GftTransfersTranTypeQryServiceImpl extends AbstractBusinessService<GftTransfersTranTypeQry, GftTransfersTranTypeQryJpe, GftTransfersTranTypeQryPk> implements GftTransfersTranTypeQryService, BusinessObjectValidationCapable<GftTransfersTranTypeQry> {

	@Override
	protected GftTransfersTranTypeQryPk getIdFromDataObjectInstance(GftTransfersTranTypeQry dataObject) {
		return new GftTransfersTranTypeQryPk(dataObject.getTranType());
	}

	@Override
	protected EntityPath<GftTransfersTranTypeQryJpe> getEntityPath() {
		return QGftTransfersTranTypeQryJpe.gftTransfersTranTypeQryJpe;
	}

	public GftTransfersTranTypeQry getByPk(String publicKey, GftTransfersTranTypeQry reference) {
		return super.getByPk(publicKey, reference);
	}
	
	public List<GftTransfersTranTypeQry> query(int offset, int resultLimit, String groupBy, String order, Map<String, Object> filters) {
		return super.query(offset, resultLimit, groupBy, order, filters);
	}
	
	public List<GftTransfersTranTypeQry> find(FindCriteria findCriteria, CbsHeader cbsHeader) {
		return super.find(findCriteria, cbsHeader);
	}
}