package com.silverlakesymmetri.cbs.xps.svc.mapper.decorator;

import org.mapstruct.Context;
import org.mapstruct.MappingTarget;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

import com.silverlakesymmetri.cbs.commons.xmlapi.enums.CbsXmlApiOperation;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.QuickLoanJpe;
import com.silverlakesymmetri.cbs.xps.svc.mapper.QuickLoanServiceMapper;
import com.silverlakesymmetri.cbs.xps.xmlapi.XPSLNDQLOANAPIType;

public abstract class QuickLoanServiceDecorator implements QuickLoanServiceMapper {
	
	@Autowired
	@Qualifier("delegate")
	protected QuickLoanServiceMapper delegate;

	@Override
	public XPSLNDQLOANAPIType mapToApi(QuickLoanJpe jpe, @Context CbsXmlApiOperation oper){
		XPSLNDQLOANAPIType req = (XPSLNDQLOANAPIType) delegate.mapToApi(jpe, oper);
		return  req;
	}
	
	@Override
	public QuickLoanJpe mapToJpe(XPSLNDQLOANAPIType api, @MappingTarget QuickLoanJpe jpe){
		delegate.mapToJpe(api, jpe);
		return jpe;
	}

}


