package com.silverlakesymmetri.cbs.xps.svc.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;

import com.mysema.query.types.EntityPath;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.jpa.entity.FindCriteriaJpe;
import com.silverlakesymmetri.cbs.commons.jpa.entity.ViewCriteriaItemJpe;
import com.silverlakesymmetri.cbs.commons.jpa.entity.ViewCriteriaRowJpe;
import com.silverlakesymmetri.cbs.commons.svc.AbstractBusinessService;
import com.silverlakesymmetri.cbs.commons.svc.BusinessObjectValidationCapable;
import com.silverlakesymmetri.cbs.csd.bdo.sdo.Branch;
import com.silverlakesymmetri.cbs.csd.jpa.mapping.sdo.BranchJpe;
import com.silverlakesymmetri.cbs.xps.bdo.sdo.SettleNostroV;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.SettleNostroVJpe;
import com.silverlakesymmetri.cbs.xps.svc.SettleNostroVService;

import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.QSettleNostroVJpe;

@Service
public class SettleNostroVServiceImpl extends AbstractBusinessService<SettleNostroV, SettleNostroVJpe, Long>
        implements SettleNostroVService, BusinessObjectValidationCapable<SettleNostroV> {

    private static final String OP_NOT_EQUAL = "!=";
    private static final String OP_LIKE = "LIKE";
    private static final String ATTR_CCY = "ccy";

    @Override
    protected Long getIdFromDataObjectInstance(SettleNostroV dataObject) {
        SettleNostroVJpe jpe = jaxbSdoHelper.unwrap(dataObject);
        return jpe.getInternalKey();
    }

    @Override
    protected EntityPath<SettleNostroVJpe> getEntityPath() {
        return QSettleNostroVJpe.settleNostroVJpe;
    }

    @Override
    public List<SettleNostroV> query(int offset, int resultLimit, String groupBy, String order, Map<String, Object> filters) {
    	return super.query(offset, resultLimit, groupBy, order, filters);
    }

    @Override
    public List<SettleNostroV> find(FindCriteria fc, CbsHeader cbsHeader) {
    	return super.find(fc, cbsHeader);
    }

    @Override
    public SettleNostroV getByPk(String publicKey, SettleNostroV reference) {
        return super.getByPk(publicKey, reference);
    }

    @Override
    public Long count(FindCriteria findCriteria, CbsHeader cbsHeader) {
    	return dataService.getRowCount(this.getEntityPath());
    }

	@Override
	public List<Branch> findBranches(FindCriteria fc, CbsHeader cbsHeader) {
		
		String qString = "SELECT NEW com.silverlakesymmetri.cbs.csd.jpa.mapping.sdo.BranchJpe(b.branch, b.branchDesc) "
				+ "FROM BranchJpe b "
				+ "WHERE EXISTS ( "
					+ "SELECT 1 "
					+ "FROM SettleNostroVJpe v "
					+ "WHERE v.branch = b.branch "
					+ "AND v.ccy = :ccy "
				+ ") ";
		
		FindCriteriaJpe fcJpe = null;
		int limit = 10;
		int offset = 0;
		if(fc!= null){
			fcJpe = jaxbSdoHelper.unwrap(fc);
			limit = fcJpe.getFetchSize();
			offset = fcJpe.getFetchStart();
		}
		
		String ccyFilter = "v.ccy";
		if (fcJpe != null && fcJpe.getFilter() != null && fcJpe.getFilter().getGroup() != null
				&& !fcJpe.getFilter().getGroup().isEmpty()) {
			ViewCriteriaRowJpe row = fcJpe.getFilter().getGroup().get(0);
			for(ViewCriteriaItemJpe item: row.getItem()){
				if (StringUtils.isNotBlank(item.getAttribute()) && item.getValue() != null
						&& !item.getValue().isEmpty()) {
					if(ATTR_CCY.equals(item.getAttribute())){
						ccyFilter = "'" + item.getValue().get(0).toString() + "'";
						continue;
					}
					if(OP_NOT_EQUAL.equals(item.getOperator())){
						qString = qString + "AND b." + item.getAttribute() + " " + OP_NOT_EQUAL + " '"
								+ item.getValue().get(0).toString() + "' "; 
					}else{
						qString = qString + "AND b." + item.getAttribute() + " " + OP_LIKE + " '"
								+ item.getValue().get(0).toString() + "' ";
					}
				}
			}
		}
		
		qString = qString.replace(":ccy", ccyFilter);
		List<BranchJpe> findList = dataService.findWithQuery(qString, offset, (limit < 0 ? 10 : limit), BranchJpe.class);
		
		List<Branch> retList = new ArrayList<>();
		for(BranchJpe jpe: findList){
			retList.add(jaxbSdoHelper.wrap(jpe));
		}
		
		return retList;
	}
}
