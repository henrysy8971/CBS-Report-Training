package com.silverlakesymmetri.cbs.xps.svc.mapper.decorator;

import org.mapstruct.Context;
import org.mapstruct.MappingTarget;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

import com.silverlakesymmetri.cbs.commons.xmlapi.enums.CbsXmlApiOperation;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.MarginSettlementDetailsJpe;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.MarginSettlementJpe;
import com.silverlakesymmetri.cbs.xps.svc.mapper.MarginSettlementServiceMapper;
import com.silverlakesymmetri.cbs.xps.xmlapi.XPSTRANMARGINSETTLEAPIType;

public abstract class MarginSettlementServiceDecorator implements MarginSettlementServiceMapper {
	
	@Autowired
	@Qualifier("delegate")
	protected MarginSettlementServiceMapper delegate;

	@Override
	public XPSTRANMARGINSETTLEAPIType mapToApi(MarginSettlementJpe jpe, @Context CbsXmlApiOperation oper){
		XPSTRANMARGINSETTLEAPIType marginSettleApi =  delegate.mapToApi(jpe, oper);
		if(jpe.getMarginSettleDetailsList() != null && jpe.getMarginSettleDetailsList().size() > 0){
			Double totalMarginAmount = 0d;
			for(MarginSettlementDetailsJpe dtl : jpe.getMarginSettleDetailsList()) {
				totalMarginAmount = totalMarginAmount + dtl.getAmount().doubleValue();
			}
			marginSettleApi.setAMOUNT(totalMarginAmount);
		}
		return marginSettleApi;
	}
	
	@Override
	public MarginSettlementJpe mapToJpe(XPSTRANMARGINSETTLEAPIType api, @MappingTarget MarginSettlementJpe jpe){
		delegate.mapToJpe(api, jpe);
		return jpe;
	}

}


