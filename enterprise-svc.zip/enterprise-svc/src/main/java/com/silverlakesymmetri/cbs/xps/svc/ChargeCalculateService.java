package com.silverlakesymmetri.cbs.xps.svc;

import java.util.Map;

import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation;
import com.silverlakesymmetri.cbs.commons.svc.BusinessService;
import com.silverlakesymmetri.cbs.xps.bdo.sdo.ChargeDetails;
import com.silverlakesymmetri.cbs.xps.bdo.sdo.ChargeMaster;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.ChargeMasterJpe;

public interface ChargeCalculateService extends BusinessService<ChargeMaster, ChargeMasterJpe> {

	public static final String XPS_CHARGECALCULATESERVICE_CALCULATE = "ChargeMasterService.calculate";

	@ServiceOperation(name = XPS_CHARGECALCULATESERVICE_CALCULATE, passParamAsMap = true)
    public ChargeDetails calculate(Map<String, Object> params);
	
}