package com.silverlakesymmetri.cbs.xps.svc.impl;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.mysema.query.types.EntityPath;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.svc.AbstractBusinessService;
import com.silverlakesymmetri.cbs.commons.svc.BusinessObjectValidationCapable;
import com.silverlakesymmetri.cbs.xps.bdo.sdo.InwTranMapInt;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.InwTranMapIntJpe;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.QInwTranMapIntJpe;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.id.InwTranMapIntPk;
import com.silverlakesymmetri.cbs.xps.svc.InwTranMapIntService;

@Service
@Transactional
public class InwTranMapIntServiceImpl extends AbstractBusinessService<InwTranMapInt, InwTranMapIntJpe, InwTranMapIntPk> implements InwTranMapIntService, BusinessObjectValidationCapable<InwTranMapInt> {

	@Override
	protected InwTranMapIntPk getIdFromDataObjectInstance(InwTranMapInt dataObject) {
		return new InwTranMapIntPk(dataObject.getInternalKey());
	}

	@Override
	protected EntityPath<InwTranMapIntJpe> getEntityPath() {
		return QInwTranMapIntJpe.inwTranMapIntJpe;
	}

	@Override
	public InwTranMapInt getByPk(String publicKey, InwTranMapInt reference) {
		return super.getByPk(publicKey, reference);
	}
	
	@Override
	public List<InwTranMapInt> query(int offset, int resultLimit, String groupBy, String order, Map<String, Object> filters) {
		return super.query(offset, resultLimit, groupBy, order, filters);
	}
	
	@Override
	public List<InwTranMapInt> find(FindCriteria findCriteria, CbsHeader cbsHeader){
		return super.find(findCriteria, cbsHeader);
	}

	@Override
	public InwTranMapInt create(InwTranMapInt dataObject) {
		return super.create(dataObject);
	}
	
	@Override
	public InwTranMapInt update(InwTranMapInt dataObject) {
		return super.update(dataObject);
	}
	
	@Override
	public boolean delete(InwTranMapInt dataObject) {
		return super.delete(dataObject);
	}
}