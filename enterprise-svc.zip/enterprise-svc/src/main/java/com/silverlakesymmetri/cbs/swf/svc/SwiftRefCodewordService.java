package com.silverlakesymmetri.cbs.swf.svc;


import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation;
import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation.ServiceOperationType;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.svc.BusinessService;
import com.silverlakesymmetri.cbs.swf.bdo.sdo.SwiftRefCodeword;
import com.silverlakesymmetri.cbs.swf.jpa.mapping.sdo.SwiftRefCodewordJpe;

import java.util.List;
import java.util.Map;

public interface SwiftRefCodewordService extends BusinessService<SwiftRefCodeword, SwiftRefCodewordJpe> {

    String SVC_OP_NAME_SWF_REF_CODEWORD_SERVICE_GET = "SwiftRefCodewordService.get";
    String SVC_OP_NAME_SWF_REF_CODEWORD_SERVICE_QUERY = "SwiftRefCodewordService.query";
    String SVC_OP_NAME_SWF_REF_CODEWORD_SERVICE_FIND = "SwiftRefCodewordService.find";

    @ServiceOperation(name = SVC_OP_NAME_SWF_REF_CODEWORD_SERVICE_GET, type = ServiceOperationType.GET)
    SwiftRefCodeword getByPk(String publicKey, SwiftRefCodeword reference);

    @ServiceOperation(name = SVC_OP_NAME_SWF_REF_CODEWORD_SERVICE_QUERY)
    List<SwiftRefCodeword> query(int offset, int resultLimit, String groupBy, String order, Map<String, Object> filters);

    @ServiceOperation(name = SVC_OP_NAME_SWF_REF_CODEWORD_SERVICE_FIND)
    List<SwiftRefCodeword> find(FindCriteria findCriteria, CbsHeader cbsHeader);

}
