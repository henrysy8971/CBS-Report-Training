package com.silverlakesymmetri.cbs.xps.svc;

import java.util.Map;

import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation;
import com.silverlakesymmetri.cbs.commons.svc.BusinessService;
import com.silverlakesymmetri.cbs.xps.bdo.sdo.ChargeDetails;
import com.silverlakesymmetri.cbs.xps.bdo.sdo.ChargeMaster;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.ChargeMasterJpe;

public interface ChargePeriodicRecalculateService extends BusinessService<ChargeMaster, ChargeMasterJpe> {

	public static final String XPS_CHARGEPERIODICRECALCULATESERVICE_RECALCULATE = "ChargePeriodicRecalculateService.recalculate";

	@ServiceOperation(name = XPS_CHARGEPERIODICRECALCULATESERVICE_RECALCULATE, passParamAsMap = true)
    public ChargeDetails recalculate(Map<String, Object> params);
	
}