package com.silverlakesymmetri.cbs.xps.svc.impl;

import com.mysema.query.types.EntityPath;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.jpa.service.CbsEntityManagerAware;
import com.silverlakesymmetri.cbs.commons.svc.AbstractBusinessService;
import com.silverlakesymmetri.cbs.commons.svc.ref.ReferenceNumberGeneratorService;
import com.silverlakesymmetri.cbs.xps.bdo.sdo.NrStmtDetail;
import com.silverlakesymmetri.cbs.xps.bdo.sdo.NrStmtForwardBalance;
import com.silverlakesymmetri.cbs.xps.bdo.sdo.NrStmtHeader;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.NrStmtDetailJpe;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.NrStmtForwardBalanceJpe;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.NrStmtHeaderJpe;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.QNrStmtHeaderJpe;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.id.NrStmtHeaderPk;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.util.XpsJpeConstants;
import com.silverlakesymmetri.cbs.xps.svc.ExternalAcctStatementService;
import com.silverlakesymmetri.cbs.xps.svc.NrStmtDetailService;
import com.silverlakesymmetri.cbs.xps.svc.NrStmtForwardBalanceService;
import commonj.sdo.ChangeSummary;
import commonj.sdo.DataObject;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.*;
import java.util.stream.Collectors;

@Service
@Transactional
public class ExternalAcctStatementServiceImpl extends AbstractBusinessService<NrStmtHeader, NrStmtHeaderJpe, NrStmtHeaderPk> implements ExternalAcctStatementService {

	private static final String D = "D";
	private static final String C = "C";
	private static final int DEFAULT_MAX = 0;

	@Autowired
	NrStmtDetailService nrStmtDetailService;

	@Autowired
	NrStmtForwardBalanceService nrStmtForwardBalanceService;

	@Autowired
	private ReferenceNumberGeneratorService referenceNumberGeneratorService;

	@Override
	protected NrStmtHeaderPk getIdFromDataObjectInstance(NrStmtHeader dataObject) {
		return new NrStmtHeaderPk(dataObject.getInternalKey());
	}

	@Override
	protected EntityPath<NrStmtHeaderJpe> getEntityPath() {
		return QNrStmtHeaderJpe.nrStmtHeaderJpe;
	}

	@Override
	public NrStmtHeader getByPk(String publicKey, NrStmtHeader reference) {
		NrStmtHeader hdrObj =  super.getByPk(publicKey, reference);
		if(hdrObj != null) {
			// The hdrObj was detached to the entity manager to avoid changing the state of the object since we did a separate query for the child
			((CbsEntityManagerAware) dataService).getMyEntityManager().detach(unwrap(hdrObj));

			Map<String, Object> params = new HashMap<>();
			params.put("relInternalKey", hdrObj.getInternalKey());

			/** Separate child query was necessary since the @JoinColumn does not work properly if the parentKey name is different from the foreignKey name in the child table.
			 ** Either the getByPk or the insert operation will have an issue if you try to interchange the name and referenceColumnName in the @JoinColumn.
			 **/

			List<NrStmtDetailJpe> detailJpe = dataService.findWithNamedQuery(XpsJpeConstants.FIND_DETAIL_BY_REL_INT_KEY,params, NrStmtDetailJpe.class);
			if (detailJpe != null) {
				List<NrStmtDetail> nrStmtDetailList = detailJpe.stream()
						.map(nrStmtDetailJpe -> jaxbSdoHelper.wrap(nrStmtDetailJpe, NrStmtDetail.class))
						.collect(Collectors.toList());
				hdrObj.setNrStmtDetailList(nrStmtDetailList);
			}

			List<NrStmtForwardBalanceJpe> balanceJpe = dataService.findWithNamedQuery(XpsJpeConstants.FIND_BALANCE_BY_REL_INT_KEY,params, NrStmtForwardBalanceJpe.class);
			if (balanceJpe != null) {

				List<NrStmtForwardBalance> nrStmtBalList = balanceJpe.stream()
						.map(nrStmtBalJpe -> jaxbSdoHelper.wrap(nrStmtBalJpe, NrStmtForwardBalance.class))
						.collect(Collectors.toList());
				hdrObj.setNrStmtForwardBalList(nrStmtBalList);
			}

			calculateClosingBalance(hdrObj);
			setDrCrValues(hdrObj);
		}

		return hdrObj;
	}

	@Override
	public List<NrStmtHeader> query(int offset, int resultLimit, String groupBy, String order, Map<String, Object> filters) {
		List<NrStmtHeader> hdrList = super.query(offset, resultLimit, groupBy, order, filters);
		if(hdrList != null ) {
			List<NrStmtHeader> nrStmtHeaderList = hdrList.stream().map(hdrObj -> {
				setDrCrValues(hdrObj);
				return hdrObj;
			}).collect(Collectors.toList());
			return nrStmtHeaderList;
		}
		return hdrList;
	}
	
	@Override
	public List<NrStmtHeader> find(FindCriteria findCriteria, CbsHeader cbsHeader){
		List<NrStmtHeader> hdrList =  super.find(findCriteria, cbsHeader);
		if(hdrList != null) {
			List<NrStmtHeader> nrStmtHeaderList = hdrList.stream().map(hdrObj -> {
				setDrCrValues(hdrObj);
				return hdrObj;
			}).collect(Collectors.toList());

			return nrStmtHeaderList;
		}
		return hdrList;
	}

	@Override
	protected NrStmtHeader preCreateValidation(NrStmtHeader dataObject) {
		setRefNo(dataObject);
		setMsgNo(dataObject);
		return super.preCreateValidation(dataObject);
	}

	@Override
	public NrStmtHeader create(NrStmtHeader dataObject) {
		setBalancesAndDefaults(dataObject);
		return super.create(dataObject);
	}

	@Override
	protected NrStmtHeader preUpdateValidation(NrStmtHeader dataObject) {
		setMsgNo(dataObject);
		return super.preUpdateValidation(dataObject);
	}

	@Override
	public NrStmtHeader update(NrStmtHeader dataObject) {
		setBalancesAndDefaults(dataObject);
		delegateChildDeletion(dataObject);
		return super.update(dataObject);
	}

	@Override
	public boolean delete(NrStmtHeader dataObject) {
		return super.delete(dataObject);
	}

	private void setRefNo(NrStmtHeader dataObject) {
		if (StringUtils.isBlank(dataObject.getHdrStmtRefNo())) {
			referenceNumberGeneratorService.getNewRefNo(dataObject,"hdrStmtRefNo");
		}
	}

	private void calculateClosingBalance(NrStmtHeader hdrObj) {
		Double totalStmtAmt = Double.valueOf(0);
		if(hdrObj.getNrStmtDetailList() != null) {
			totalStmtAmt = hdrObj.getNrStmtDetailList().stream().map(nrStmtDetail -> nrStmtDetail.getAmount()).reduce(Double.valueOf(0), (subtotal, element) -> subtotal + element);
		}

		if(hdrObj.getOpeningBalance() != null) {
			Double calculatedBalance = totalStmtAmt + hdrObj.getOpeningBalance();
			hdrObj.setClosingCalculatedBalance(calculatedBalance);
			if(calculatedBalance < 0) {
				hdrObj.setDrCrCcb(D);
			} else {
				hdrObj.setDrCrCcb(C);
			}
		}
	}

	private void setDrCrValues(NrStmtHeader hdrObj) {
		if(hdrObj != null ) {
			if (hdrObj.getClosingAvailableBalance() != null && hdrObj.getClosingAvailableBalance() < 0) {
				hdrObj.setDrCrAb(D);
				hdrObj.setClosingAvailableBalance(Math.abs(hdrObj.getClosingAvailableBalance()));
			} else {
				hdrObj.setDrCrAb(C);
			}

			if (hdrObj.getOpeningBalance() != null && hdrObj.getOpeningBalance() < 0) {
				hdrObj.setDrCrOb(D);
				hdrObj.setOpeningBalance(Math.abs(hdrObj.getOpeningBalance()));
			} else {
				hdrObj.setDrCrOb(C);
			}

			if (hdrObj.getClosingBalance()!=null && hdrObj.getClosingBalance() < 0) {
				hdrObj.setDrCrCb(D);
				hdrObj.setClosingBalance(Math.abs(hdrObj.getClosingBalance()));
			} else {
				hdrObj.setDrCrCb(C);
			}

			if (hdrObj.getNrStmtDetailList() != null) {
				List<NrStmtDetail> nrStmtDetailList = hdrObj.getNrStmtDetailList().stream().map(nrStmtDetail -> {
					if (nrStmtDetail.getAmount() < 0) {
						nrStmtDetail.setDrCr(D);
						nrStmtDetail.setAmount(Math.abs(nrStmtDetail.getAmount()));
					} else {
						nrStmtDetail.setDrCr(C);
					}
					return nrStmtDetail;
				}).collect(Collectors.toList());
				hdrObj.setNrStmtDetailList(nrStmtDetailList);
			}

			if (hdrObj.getNrStmtForwardBalList() != null) {
				List<NrStmtForwardBalance> nrStmtForwardBalanceList = hdrObj.getNrStmtForwardBalList().stream().map(nrStmtForwardBal -> {
					if (nrStmtForwardBal.getForwardAvailableBal() != null && nrStmtForwardBal.getForwardAvailableBal() < 0) {
						nrStmtForwardBal.setDrCr(D);
						nrStmtForwardBal.setForwardAvailableBal(Math.abs(nrStmtForwardBal.getForwardAvailableBal()));
					} else {
						nrStmtForwardBal.setDrCr(C);
					}
					return nrStmtForwardBal;
				}).collect(Collectors.toList());
				hdrObj.setNrStmtForwardBalList(nrStmtForwardBalanceList);
			}
		}
	}

	private void setBalancesAndDefaults(NrStmtHeader dataObject) {
		if(dataObject != null){
			if(D.equals(dataObject.getDrCrAb())) {
				dataObject.setClosingAvailableBalance(negate(dataObject.getClosingAvailableBalance()));
			}

			if(D.equals(dataObject.getDrCrCb())) {
				dataObject.setClosingBalance(negate(dataObject.getClosingBalance()));
			}

			if(D.equals(dataObject.getDrCrOb())) {
				dataObject.setOpeningBalance(negate(dataObject.getOpeningBalance()));
			}

			if(dataObject.getNrStmtDetailList() != null) {
				List<NrStmtDetail> nrStmtDetailList = dataObject.getNrStmtDetailList().stream().map(nrStmtDetail -> {
					if (D.equals(nrStmtDetail.getDrCr())) {
						nrStmtDetail.setAmount(negate(nrStmtDetail.getAmount()));
					} else {
						nrStmtDetail.setAmount(Math.abs(nrStmtDetail.getAmount()));
					}
					return nrStmtDetail;
				}).collect(Collectors.toList());

				dataObject.setNrStmtDetailList(nrStmtDetailList);
			}

			if(dataObject.getNrStmtForwardBalList() != null) {
				List<NrStmtForwardBalance> nrStmtForwardBalanceList = dataObject.getNrStmtForwardBalList().stream().map(nrStmtForwardBalance -> {
					if (D.equals(nrStmtForwardBalance.getDrCr())) {
						nrStmtForwardBalance.setForwardAvailableBal(negate(nrStmtForwardBalance.getForwardAvailableBal()));
					}
					return nrStmtForwardBalance;
				}).collect(Collectors.toList());
				dataObject.setNrStmtForwardBalList(nrStmtForwardBalanceList);
			}
		}
	}




	private Double negate(Double num) {
		return Math.abs(num) * -1;
	}

	private void delegateChildDeletion(NrStmtHeader dataObject) {
		if(dataObject != null) {
			ChangeSummary cs = dataObject.getChangeSummary();
			if (cs != null && cs.getChangedDataObjects() != null && !cs.getChangedDataObjects().isEmpty()) {
				for (Object object : cs.getChangedDataObjects()) {
					if(cs.isDeleted((DataObject) object) && object instanceof NrStmtDetail) {
						nrStmtDetailService.delete((NrStmtDetail) object);
					} else if(cs.isDeleted((DataObject) object) && object instanceof NrStmtForwardBalance) {
						nrStmtForwardBalanceService.delete((NrStmtForwardBalance) object);
					}
				}
			}
		}
	}

	private void setMsgNo(NrStmtHeader dataObject) {
		if(dataObject.getNrStmtDetailList() != null && dataObject.getNrStmtDetailList().size() >0) {
			Integer maxSeqNo = dataObject.getNrStmtDetailList()
					.stream()
					.map(NrStmtDetail::getMsgNo)
					.filter(Objects::nonNull)
					.max(Comparator.comparing(Integer::valueOf))
					.orElse(DEFAULT_MAX);

			for(NrStmtDetail stmtDetail : dataObject.getNrStmtDetailList()) {
				if(stmtDetail.getMsgNo() == null) {
					maxSeqNo++;
					stmtDetail.setMsgNo(maxSeqNo);
				}
			}
		}
	}

}