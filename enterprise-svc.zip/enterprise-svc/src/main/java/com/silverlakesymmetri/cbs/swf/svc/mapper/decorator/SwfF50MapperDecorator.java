package com.silverlakesymmetri.cbs.swf.svc.mapper.decorator;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

import com.silverlakesymmetri.cbs.swf.jpa.mapping.sdo.SwfNonFinEntityJpe;
import com.silverlakesymmetri.cbs.swf.svc.mapper.mapping.SwfF50Mapper;
import com.silverlakesymmetri.cbs.swf.xmlapi.SWFF50TYPEType;

public abstract class SwfF50MapperDecorator implements SwfF50Mapper {
	
	@Autowired
	@Qualifier("delegate")
	protected SwfF50Mapper delegate;

	@Override
	public SWFF50TYPEType mapToApi(SwfNonFinEntityJpe jpe){
		SWFF50TYPEType swfF50 = delegate.mapToApi(jpe);
		if(swfF50 != null && swfF50.getACCOUNT() == null && swfF50.getADDRESS() == null && swfF50.getBIC() == null && 
				swfF50.getCUSTOMERID() == null && swfF50.getCUSTOMERDETAILS() == null){
			return null;
		}
		return swfF50;
	}
	
	@Override
	public SwfNonFinEntityJpe mapToJpe(SWFF50TYPEType api){
		return delegate.mapToJpe(api);
	}
	
}
