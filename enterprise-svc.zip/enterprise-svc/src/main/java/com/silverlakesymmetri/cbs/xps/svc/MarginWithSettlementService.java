package com.silverlakesymmetri.cbs.xps.svc;

import java.util.Map;

import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation;
import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation.ServiceOperationType;
import com.silverlakesymmetri.cbs.commons.bdo.sdo.DmsFile;
import com.silverlakesymmetri.cbs.commons.svc.BusinessService;
import com.silverlakesymmetri.cbs.xps.bdo.sdo.AdvicePreview;
import com.silverlakesymmetri.cbs.xps.bdo.sdo.MarginWithSettlement;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.MarginWithSettlementJpe;

public interface MarginWithSettlementService extends BusinessService<MarginWithSettlement, MarginWithSettlementJpe> {
	public static final String XPS_MARGINSETTLEMENTSERVICE_GET = "MarginWithSettlementService.get";
    public static final String XPS_MARGINSETTLEMENTSERVICE_CREATE = "MarginWithSettlementService.create";
    public static final String XPS_MARGINSETTLEMENTSERVICE_UPDATE = "MarginWithSettlementService.update";
    public static final String XPS_MARGINSETTLEMENTSERVICE_DELETE = "MarginWithSettlementService.delete";
    public static final String XPS_MARGINSETTLEMENTSERVICE_GETACTIVEMARGIN = "MarginWithSettlementService.getActiveMarginWithSettlement";
    public static final String XPS_MARGINSETTLEMENTSERVICE_GETATTACHEDMARGINWITHUTIL = "MarginWithSettlementService.getAttachedMarginWithUtilization";
	public static final String SVC_OP_NAME_MARGINSETTLEMENTSERVICE_SWFMSG = "MarginWithSettlementService.generateSwfMessage";
    public static final String SVC_OP_NAME_MARGINSETTLEMENTSERVICE_EMAILPREVIEW = "MarginWithSettlementService.generateEmailPreview";
    public static final String SVC_OP_NAME_MARGINSETTLEMENTSERVICE_GENADVICE = "MarginWithSettlementService.generateAdvice";
    
    @ServiceOperation(name = XPS_MARGINSETTLEMENTSERVICE_GET, type = ServiceOperationType.GET)
    public MarginWithSettlement getByPk(String publicKey, MarginWithSettlement reference);
    
    @ServiceOperation(name = XPS_MARGINSETTLEMENTSERVICE_CREATE)
    public MarginWithSettlement create(MarginWithSettlement dataObject);

    @ServiceOperation(name = XPS_MARGINSETTLEMENTSERVICE_UPDATE)
    public MarginWithSettlement update(MarginWithSettlement dataObject);

    @ServiceOperation(name = XPS_MARGINSETTLEMENTSERVICE_DELETE)
    public boolean delete(MarginWithSettlement dataObject);

    @ServiceOperation(name = XPS_MARGINSETTLEMENTSERVICE_GETACTIVEMARGIN, passParamAsMap = true)
    public MarginWithSettlement getActiveMarginWithSettlement(Map<String, Object> params);

    @ServiceOperation(name = SVC_OP_NAME_MARGINSETTLEMENTSERVICE_SWFMSG, passParamAsMap = true)
    public String generateSwfMessage(Map<String, Object> params);
    
    @ServiceOperation(name = SVC_OP_NAME_MARGINSETTLEMENTSERVICE_EMAILPREVIEW, passParamAsMap = true)
    public AdvicePreview generateEmailPreview(Map<String, Object> params);
    
    @ServiceOperation(name = SVC_OP_NAME_MARGINSETTLEMENTSERVICE_GENADVICE, passParamAsMap = true)
    public DmsFile generateAdvice(Map<String, Object> params);
    
    @ServiceOperation(name = XPS_MARGINSETTLEMENTSERVICE_GETATTACHEDMARGINWITHUTIL, passParamAsMap = true)
    public MarginWithSettlement getAttachedMarginWithUtilization(Map<String, Object> params);
    
    public MarginWithSettlement getAttachedMargin(Long attachedKey);
}