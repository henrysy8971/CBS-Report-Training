package com.silverlakesymmetri.cbs.xps.svc.mapper;

import org.mapstruct.Context;
import org.mapstruct.DecoratedWith;
import org.mapstruct.InheritInverseConfiguration;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingTarget;
import org.mapstruct.Mappings;

import com.silverlakesymmetri.cbs.commons.jpa.util.DateTimeHelper;
import com.silverlakesymmetri.cbs.commons.xmlapi.enums.CbsXmlApiOperation;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.ChargeDetailsJpe;
import com.silverlakesymmetri.cbs.xps.svc.mapper.decorator.ChargeDetailServiceDecorator;
import com.silverlakesymmetri.cbs.xps.xmlapi.XPSTRANCHARGEDETAILAPIType;

@Mapper(uses = { DateTimeHelper.class })
@DecoratedWith(ChargeDetailServiceDecorator.class)
public interface ChargeDetailServiceMapper {

	@Mappings({
		@Mapping(source="internalKey", target = "INTERNALKEY"),
		@Mapping(source="relInternalKey", target = "RELINTERNALKEY"),
		@Mapping(source="seqNo", target = "SEQNO"),
		@Mapping(source="chargeRefNo", target = "CHARGEREFNO"),
		@Mapping(source="payRec", target = "PAYREC"),
		@Mapping(source="exchangeType", target = "EXCHANGETYPE"),
		@Mapping(source="amount", target = "AMOUNT"),
		@Mapping(source="interestAction", target = "INTERESTACTION"),
		//@Mapping(source="", target = "WAIVED"),
		//@Mapping(source="", target = "PCTOFBANKRATE"),
		//@Mapping(source="", target = "SETUPCCY"),
		//@Mapping(source="", target = "SETUPAMT"),
		//@Mapping(source="", target = "CHANGED"),
		//@Mapping(source="", target = "EXCHRATE"),
		//@Mapping(source="", target = "EXCHQUOTE"),
		//@Mapping(source="", target = "CALCULATEDAMT"),
		//@Mapping(source="", target = "STARTDATE", qualifiedByName = {"DateTimeHelper", "convertDateToCbsXmlApiDate"}),
		//@Mapping(source="", target = "ENDDATE", qualifiedByName = {"DateTimeHelper", "convertDateToCbsXmlApiDate"}),
		//@Mapping(source="", target = "GRACEIND"),
		//@Mapping(source="", target = "GRACEDAYS"),
		//@Mapping(source="", target = "NOOFDAYS"),
		//@Mapping(source="", target = "AMENDSTARTDATE", qualifiedByName = {"DateTimeHelper", "convertDateToCbsXmlApiDate"}),
		//@Mapping(source="", target = "AMENDENDDATE", qualifiedByName = {"DateTimeHelper", "convertDateToCbsXmlApiDate"}),
		//@Mapping(source="", target = "AMENDBALANCEAMT"),
		//@Mapping(source="", target = "CALCULATIONTYPE"),
		//@Mapping(source="", target = "PERPERIODDAYS"),
		@Mapping(source="yearBasis", target = "YEARBASIS"),
		//@Mapping(source="", target = "RATELADDER"),
		//@Mapping(source="", target = "AMTTYPE"),
		@Mapping(source="npRelDetailSeqNo", target = "RELDETAILKEY"),
		//@Mapping(source="", target = "BASISCCY"),
		//@Mapping(source="", target = "BASISAMT"),
		//@Mapping(source="", target = "BASISCALCAMT"),
		//@Mapping(source="", target = "OVERALLMINAMT"),
		//@Mapping(source="", target = "OVERALLMAXAMT"),
		//@Mapping(source="", target = "PERANNUMMINAMT"),
		//@Mapping(source="", target = "PERANNUMMAXAMT"),
		@Mapping(source="setupCcyExchRate", target = "SETUPCCYEXCHRATE"),
		@Mapping(source="setupCcyExchQuote", target = "SETUPCCYEXCHQUOTE")
		//@Mapping(source="", target = "INTERESTACTIONFREQ"),
		//@Mapping(source="", target = "INTERESTACTIONFREQDAY"),
		//@Mapping(source="", target = "DAILYPOSTAMT"),
		//@Mapping(source="", target = "TOTALDAYS"),
		//@Mapping(source="", target = "TOTALPOSTEDAMT"),
		//@Mapping(source="", target = "LASTPOSTDATE", qualifiedByName = {"DateTimeHelper", "convertDateToCbsXmlApiDate"}),
		//@Mapping(source="", target = "NEXTPOSTDATE", qualifiedByName = {"DateTimeHelper", "convertDateToCbsXmlApiDate"}),
		//@Mapping(source="", target = "OVERDUEAMT"),
		//@Mapping(source="", target = "STARTPOSTDATE", qualifiedByName = {"DateTimeHelper", "convertDateToCbsXmlApiDate"}),
		//@Mapping(source="", target = "ENDPOSTDATE", qualifiedByName = {"DateTimeHelper", "convertDateToCbsXmlApiDate"}),
		//@Mapping(source="", target = "SLABS")
	})
	public XPSTRANCHARGEDETAILAPIType mapToApi(ChargeDetailsJpe jpe, @Context CbsXmlApiOperation oper);

	@InheritInverseConfiguration(name = "mapToApi")
	public ChargeDetailsJpe mapToJpe(XPSTRANCHARGEDETAILAPIType api, @MappingTarget ChargeDetailsJpe jpe);
}