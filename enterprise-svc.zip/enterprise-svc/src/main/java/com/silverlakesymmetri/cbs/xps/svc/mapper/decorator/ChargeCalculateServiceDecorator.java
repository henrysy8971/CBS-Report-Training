package com.silverlakesymmetri.cbs.xps.svc.mapper.decorator;

import java.util.ArrayList;

import org.mapstruct.Context;
import org.mapstruct.MappingTarget;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

import com.silverlakesymmetri.cbs.commons.xmlapi.enums.CbsXmlApiOperation;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.ChargeDetailsJpe;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.ChargeMasterJpe;
import com.silverlakesymmetri.cbs.xps.svc.mapper.ChargeCalculateServiceMapper;
import com.silverlakesymmetri.cbs.xps.svc.mapper.ChargeDetailServiceMapper;
import com.silverlakesymmetri.cbs.xps.xmlapi.XPSCHARGECALCULATEAPIType;
import com.silverlakesymmetri.cbs.xps.xmlapi.XPSTRANCHARGEDETAILAPIType;

public abstract class ChargeCalculateServiceDecorator implements ChargeCalculateServiceMapper {
	
	private static final String CHARGE_TYPE_FIXED = "F";
	private static final String CHARGE_TYPE_INTEREST = "I";
	private static final String CHARGE_TYPE_PERIODIC = "P";
	private static final String CHARGE_TYPE_RATED = "R";
	private static final String CHARGE_TYPE_TWOTIER = "T";
	
	@Autowired
	@Qualifier("delegate")
	protected ChargeCalculateServiceMapper delegate;

	@Autowired
	protected ChargeDetailServiceMapper detailMapper;

	@Override
	public XPSCHARGECALCULATEAPIType mapToApi(ChargeMasterJpe jpe, @Context CbsXmlApiOperation oper){
		XPSCHARGECALCULATEAPIType req = (XPSCHARGECALCULATEAPIType) delegate.mapToApi(jpe, oper);
		
		if(jpe.getChargeDetailsList() != null && jpe.getChargeDetailsList().size() > 0){
			//master's first detail is always the selected charge
			req.setCHARGEREFNO(jpe.getChargeDetailsList().get(0).getChargeRefNo());
			
			//master will have 2nd detail for related charge
			if(jpe.getChargeDetailsList().size() > 1){
				ChargeDetailsJpe detailsJpe = jpe.getChargeDetailsList().get(1);
				XPSTRANCHARGEDETAILAPIType detailApi = detailMapper.mapToApi(detailsJpe, oper);
				req.setRELATEDCHARGE(detailApi);
			}
		}
		//TODO: when is this set to N??
		req.setUSEEXISTINGEXCHRATE("Y");

		req.setCHARGE(new XPSTRANCHARGEDETAILAPIType());
		
		return  req;
	}
	
	@Override
	public ChargeMasterJpe mapToJpe(XPSCHARGECALCULATEAPIType api, @MappingTarget ChargeMasterJpe jpe){
		delegate.mapToJpe(api, jpe);
		
		jpe.setChargeDetailsList(new ArrayList<ChargeDetailsJpe>());
		ChargeDetailsJpe detailsJpe = new ChargeDetailsJpe();
		detailsJpe = detailMapper.mapToJpe(api.getCHARGE(), detailsJpe);
		jpe.getChargeDetailsList().add(detailsJpe);
		return jpe;
	}

}


