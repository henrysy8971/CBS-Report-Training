package com.silverlakesymmetri.cbs.swf.svc.mapper.decorator;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

import com.silverlakesymmetri.cbs.swf.jpa.mapping.sdo.SwfCustomerIdJpe;
import com.silverlakesymmetri.cbs.swf.svc.mapper.mapping.SwfCustomerIdMapper;
import com.silverlakesymmetri.cbs.swf.xmlapi.SWFCUSTOMERIDTYPEType;

public abstract class SwfCustomerIdMapperDecorator implements SwfCustomerIdMapper {
	
	@Autowired
	@Qualifier("delegate")
	protected SwfCustomerIdMapper delegate;

	@Override
	public SWFCUSTOMERIDTYPEType mapToApi(SwfCustomerIdJpe jpe){
		SWFCUSTOMERIDTYPEType customerId = delegate.mapToApi(jpe);
		if(customerId != null && customerId.getCODE() == null && customerId.getCOUNTRY() == null && customerId.getID() == null){
			return null;
		}
		return customerId;
	}
	
	@Override
	public SwfCustomerIdJpe mapToJpe(SWFCUSTOMERIDTYPEType api){
		return delegate.mapToJpe(api);
	}
	
}
