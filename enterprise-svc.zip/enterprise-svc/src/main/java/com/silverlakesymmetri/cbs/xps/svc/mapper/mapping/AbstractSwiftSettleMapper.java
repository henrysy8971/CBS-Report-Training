package com.silverlakesymmetri.cbs.xps.svc.mapper.mapping;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.silverlakesymmetri.cbs.swf.jpa.mapping.sdo.*;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.*;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

import com.silverlakesymmetri.cbs.commons.jpa.service.CbsGenericDataService;
import com.silverlakesymmetri.cbs.commons.logging.CbsAppLogger;
import com.silverlakesymmetri.cbs.commons.logging.CbsAppLoggerFactory;
import com.silverlakesymmetri.cbs.commons.xmlapi.enums.CbsXmlApiOperation;
import com.silverlakesymmetri.cbs.csd.jpa.mapping.sdo.SettleMethodJpe;
import com.silverlakesymmetri.cbs.gla.jpa.mapping.sdo.GlAccountJpe;
import com.silverlakesymmetri.cbs.gla.jpa.mapping.sdo.util.GlaJpeConstants;
import com.silverlakesymmetri.cbs.mcl.jpa.mapping.sdo.util.MclJpeConstants;
import com.silverlakesymmetri.cbs.swf.jpa.mapping.sdo.util.SwfJpeConstants;
import com.silverlakesymmetri.cbs.swf.svc.mapper.mapping.SwfF54Mapper;
import com.silverlakesymmetri.cbs.swf.svc.mapper.mapping.SwfF58Mapper;
import com.silverlakesymmetri.cbs.swf.svc.mapper.mapping.SwfF72Mapper;
import com.silverlakesymmetri.cbs.swf.xmlapi.SWFCOVERMESSAGETYPEType;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.util.XpsJpeConstants;
import com.silverlakesymmetri.cbs.xps.listener.CommonSettelementJpeInterface;
import com.silverlakesymmetri.cbs.xps.xmlapi.XPSSETTLEMESSAGETYPEType;
import com.silverlakesymmetri.cbs.xps.xmlapi.XPSSWFSETTLEAPIType;

public abstract class AbstractSwiftSettleMapper {
	private static final CbsAppLogger logger = CbsAppLoggerFactory.getLogger(AbstractSwiftSettleMapper.class);
	private static final String NOSTRO_ACCT_TYPE = "N";
	private static final String RETAIL_ACCT_TYPE = "R";
	private static final String INTERNAL_GL_ACCT_TYPE = "I";
	private static final String ROUTE_SWIFT = "SWIFT";
	private static final String PAY = "P";
	private static final String REC = "R";
	private static final List<String> SWIFT_FORMATS = Arrays.asList(new String []{SwfJpeConstants.SWFMT103, SwfJpeConstants.SWFMT202, SwfJpeConstants.SWFMT103202COV, SwfJpeConstants.SWFMT400});

	@Autowired(required = true)
	@Qualifier("cbsGenericDataService")
	protected CbsGenericDataService dataService;

	@Autowired
	SwfMt103ToXPSSWFSETTLEAPITypeMapper mt103Mapper;

	@Autowired
	SwfMt202ToXPSSWFSETTLEAPITypeMapper mt202Mapper;
	
	@Autowired
	SwfMt400ToXPSSWFSETTLEAPITypeMapper mt400Mapper;

	@Autowired
	SwfF54Mapper swfF54Mapper;

	@Autowired
	SwfF58Mapper swfF58Mapper;

	@Autowired
	SwfF72Mapper swfF72Mapper;

	@Autowired
	SettleMessageJpeToXPSSETTLEMESSAGETYPETypeMapper settleMessageMapper;

	public void mapToApi(CommonSettelementApiInterface api, CommonSettelementJpeInterface jpe, CbsXmlApiOperation oper){
		if (oper.compareTo(CbsXmlApiOperation.DELETE) == 0) { return; }
		
		String format = getSwiftFormat(jpe.getSettleMethod(), null);
		
		if (RETAIL_ACCT_TYPE.equals(jpe.getAcctType())) {
			mapRetailToApi(api, jpe);
		} else if (INTERNAL_GL_ACCT_TYPE.equals(jpe.getAcctType())) {
			mapInternalGlToApi(api, jpe);
		} else if (NOSTRO_ACCT_TYPE.equals(jpe.getAcctType())) {
			mapNostroToApi(api, jpe);
			
			if (format != null && SWIFT_FORMATS.contains(format)) {
				if (SwfJpeConstants.SWFMT103.equals(format) && jpe.getCommonSettleNostroMt103Rec() != null) {
					mapSWFMT103ToApi(api, jpe, oper);
				} else if (SwfJpeConstants.SWFMT202.equals(format) && jpe.getCommonSettleNostroMt202Rec() != null) {
					mapSWFMT202ToApi(api, jpe, oper);
				} else if (SwfJpeConstants.SWFMT103202COV.equals(format) && jpe.getCommonSettleNostroMt103Mt202CovRec() != null) {
					mapSWFMT103202COVToApi(api, jpe, oper);
				} else if (SwfJpeConstants.SWFMT400.equals(format) && jpe.getCommonSettleNostroMt400Rec() != null) {
					mapSWFMT400ToApi(api, jpe, oper);
				}
			}
		}
		
		if (jpe.getMessageStructRec() != null) {
			mapMessageToApi(api, jpe);
		}
	}
	
	public void mapRetailToApi(CommonSettelementApiInterface api, CommonSettelementJpeInterface jpe){
		if (jpe.getCommonSettleDepositRec() == null) {
//			jpe.setCommonSettleDepositRec(new CommonSettleDepositJpe());
			return;
		}
		
		if (jpe.getCommonSettleDepositRec().getAcctInternalKey() != null) {
			api.setACCTINTERNALKEY(jpe.getCommonSettleDepositRec().getAcctInternalKey());
		} else {
			api.setACCTINTERNALKEY(this.getRetailInternalKey(jpe.getCommonSettleDepositRec().getAcctNo()));
		}
		
		api.setREMARKS(jpe.getCommonSettleDepositRec().getRemarks());
	}
	
	public void mapInternalGlToApi(CommonSettelementApiInterface api, CommonSettelementJpeInterface jpe){
		if (jpe.getCommonSettleInternalGlRec() == null) {
//			jpe.setCommonSettleInternalGlRec(new CommonSettleInternalGlJpe());
			return;
		}

		api.setGLCODE(jpe.getCommonSettleInternalGlRec().getGlCode());
		api.setREMARKS(jpe.getCommonSettleInternalGlRec().getRemarks());
	}
	
	public void mapNostroToApi(CommonSettelementApiInterface api, CommonSettelementJpeInterface jpe){
		if (jpe.getCommonSettleNostroRec() == null) {
//			jpe.setCommonSettleNostroRec(new CommonSettleNostroJpe());
			return;
		}

		api.setACCTINTERNALKEY(this.getAcctInternalKey(jpe.getCommonSettleNostroRec().getAcctNo()));
		api.setREMARKS(jpe.getCommonSettleNostroRec().getRemarks());
	}
	
	public void mapSWFMT103ToApi(CommonSettelementApiInterface api, CommonSettelementJpeInterface jpe, CbsXmlApiOperation oper){
		if (jpe.getCommonSettleNostroMt103Rec().getCommonSettleNostroRec() != null) {
//			jpe.getCommonSettleNostroMt103Rec().setCommonSettleNostroRec(new CommonSettleNostroJpe());
			api.setACCTINTERNALKEY(this.getAcctInternalKey(jpe.getCommonSettleNostroMt103Rec().getCommonSettleNostroRec().getAcctNo()));
			api.setREMARKS(jpe.getCommonSettleNostroMt103Rec().getCommonSettleNostroRec().getRemarks());
		}

		api.setSWIFT(mt103Mapper.mapToApi(jpe.getCommonSettleNostroMt103Rec().getSwfMt103StructRec(), oper));
	}
	
	public void mapSWFMT202ToApi(CommonSettelementApiInterface api, CommonSettelementJpeInterface jpe, CbsXmlApiOperation oper){
		if (jpe.getCommonSettleNostroMt202Rec().getCommonSettleNostroRec() != null) {
//			jpe.getCommonSettleNostroMt202Rec().setCommonSettleNostroRec(new CommonSettleNostroJpe());
			api.setACCTINTERNALKEY(this.getAcctInternalKey(jpe.getCommonSettleNostroMt202Rec().getCommonSettleNostroRec().getAcctNo()));
			api.setREMARKS(jpe.getCommonSettleNostroMt202Rec().getCommonSettleNostroRec().getRemarks());
		}

		api.setSWIFT(mt202Mapper.mapToApi(jpe.getCommonSettleNostroMt202Rec().getSwfMt202StructRec(), oper));
	}

	public void mapSWFMT400ToApi(CommonSettelementApiInterface api, CommonSettelementJpeInterface jpe, CbsXmlApiOperation oper){
		if (jpe.getCommonSettleNostroMt400Rec().getCommonSettleNostroRec() != null) {
//			jpe.getCommonSettleNostroMt400Rec().setCommonSettleNostroRec(new CommonSettleNostroJpe());
			api.setACCTINTERNALKEY(this.getAcctInternalKey(jpe.getCommonSettleNostroMt400Rec().getCommonSettleNostroRec().getAcctNo()));
			api.setREMARKS(jpe.getCommonSettleNostroMt400Rec().getCommonSettleNostroRec().getRemarks());
		}

		api.setSWIFT(mt400Mapper.mapToApi(jpe.getCommonSettleNostroMt400Rec().getSwfMt400StructRec(), oper));
	}
	
	public void mapSWFMT103202COVToApi(CommonSettelementApiInterface api, CommonSettelementJpeInterface jpe, CbsXmlApiOperation oper){
		if (jpe.getCommonSettleNostroMt103Mt202CovRec().getCommonSettleNostroRec() != null) {
//			jpe.getCommonSettleNostroMt103Mt202CovRec().setCommonSettleNostroRec(new CommonSettleNostroJpe());
			api.setACCTINTERNALKEY(this.getAcctInternalKey(jpe.getCommonSettleNostroMt103Mt202CovRec().getCommonSettleNostroRec().getAcctNo()));
			api.setREMARKS(jpe.getCommonSettleNostroMt103Mt202CovRec().getCommonSettleNostroRec().getRemarks());
		}

		SWFCOVERMESSAGETYPEType covMsgApi = new SWFCOVERMESSAGETYPEType();
		covMsgApi.setRECEIVERSCORRESPONDENT(swfF54Mapper.mapToApi(jpe.getCommonSettleNostroMt103Mt202CovRec().getCovReceiversCorrespondentStructRec()));
		covMsgApi.setBENEFICIARYINSTITUTION(swfF58Mapper.mapToApi(jpe.getCommonSettleNostroMt103Mt202CovRec().getCovBeneficiaryInstitutionStructRec()));
		covMsgApi.setSENDERTORECEIVERINFO(swfF72Mapper.mapToApi(jpe.getCommonSettleNostroMt103Mt202CovRec().getCovSenderToReceiverInfoStructRec()));

		XPSSWFSETTLEAPIType swiftSettleApi = mt103Mapper.mapToApi(jpe.getCommonSettleNostroMt103Mt202CovRec().getSwfMt103StructRec(), oper);
		swiftSettleApi.setCOVERMESSAGEDETAILS(covMsgApi);
		api.setSWIFT(swiftSettleApi);
	}

	public void mapMessageToApi(CommonSettelementApiInterface api, CommonSettelementJpeInterface jpe){
		XPSSETTLEMESSAGETYPEType settleMessageApi = settleMessageMapper.mapToApi(jpe.getMessageStructRec());
		api.setMESSAGE(settleMessageApi);
	}

	public void mapToJpe(CommonSettelementJpeInterface jpe, CommonSettelementApiInterface api) {
		if (api == null) {
			logger.warn("api is null");
			return;
		}
		if (jpe == null) {
			logger.warn("jpe is null");
			return;
		}

		boolean nonSwift = true;
		String format = getSwiftFormat(jpe.getSettleMethod(), null);

		if (format != null && !format.isEmpty()) {
			nonSwift = !SWIFT_FORMATS.contains(format);
		}

		if (NOSTRO_ACCT_TYPE.equals(api.getACCTTYPE()) & nonSwift) {
			mapNostroToJpe(jpe, api);
		} else if (RETAIL_ACCT_TYPE.equals(api.getACCTTYPE())) {
			mapRetailToJpe(jpe, api);
		} else if (INTERNAL_GL_ACCT_TYPE.equals(api.getACCTTYPE())) {
			mapInternalGlToJpe(jpe, api);
		}
		
		if (NOSTRO_ACCT_TYPE.equals(api.getACCTTYPE())) {
			if (SwfJpeConstants.SWFMT103.equals(format)) {
				mapSWFMT103ToJpe(jpe, api);
			} else if (SwfJpeConstants.SWFMT202.equals(format)) {
				mapSWFMT202ToJpe(jpe, api);
			} else if (SwfJpeConstants.SWFMT103202COV.equals(format)) {
				mapSWFMT103202COVToJpe(jpe, api);
			} else if (SwfJpeConstants.SWFMT400.equals(format)) {
				mapSWFMT400ToJpe(jpe, api);
			}
		}
		
		if (api.getMESSAGE() != null) {
			mapMessageToJpe(jpe, api);
		}
	}

	public void mapNostroToJpe(CommonSettelementJpeInterface jpe, CommonSettelementApiInterface api){
		if (jpe.getCommonSettleNostroRec() == null) {
			jpe.setCommonSettleNostroRec(new CommonSettleNostroJpe());
		}

		if (api.getACCTINTERNALKEY() != null) {
			jpe.setCommonSettleNostroRec(mapToCommonSettleDepositRec(jpe.getCommonSettleNostroRec(), api.getACCTINTERNALKEY()));
		}

		if (StringUtils.isNotBlank(api.getREMARKS())) {
			jpe.getCommonSettleNostroRec().setRemarks(api.getREMARKS());
		}
	}
	
	public void mapRetailToJpe(CommonSettelementJpeInterface jpe, CommonSettelementApiInterface api){
		if (jpe.getCommonSettleDepositRec() == null) {
			jpe.setCommonSettleDepositRec(new CommonSettleDepositJpe());
		}

		if (api.getACCTINTERNALKEY() != null) {
			jpe.setCommonSettleDepositRec(
					mapToRetailAcct(jpe.getCommonSettleDepositRec(), api.getACCTINTERNALKEY()));
		}

		if (StringUtils.isNotBlank(api.getREMARKS())) {
			jpe.getCommonSettleDepositRec().setRemarks(api.getREMARKS());
		}
	}
	
	public void mapInternalGlToJpe(CommonSettelementJpeInterface jpe, CommonSettelementApiInterface api){
		if (jpe.getCommonSettleInternalGlRec() == null) {
			jpe.setCommonSettleInternalGlRec(new CommonSettleInternalGlJpe());
		}

		jpe.getCommonSettleInternalGlRec().setGlCode(api.getGLCODE());

		if (StringUtils.isNotBlank(api.getREMARKS())) {
			jpe.getCommonSettleInternalGlRec().setRemarks(api.getREMARKS());
		}
	}
	
	public void mapSWFMT103ToJpe(CommonSettelementJpeInterface jpe, CommonSettelementApiInterface api){
		SwfMt103Jpe swfMt103Jpe = mt103Mapper.mapToJpe(api.getSWIFT(), new SwfMt103Jpe());

		if (jpe.getCommonSettleNostroMt103Rec() == null) {
			jpe.setCommonSettleNostroMt103Rec(new CommonSettleNostroMt103Jpe());
		}

		jpe.getCommonSettleNostroMt103Rec().setSwfMt103StructRec(swfMt103Jpe);

		// set CommonSettleNostroRec
		if (jpe.getCommonSettleNostroMt103Rec().getCommonSettleNostroRec() == null) {
			jpe.getCommonSettleNostroMt103Rec().setCommonSettleNostroRec(new CommonSettleNostroJpe());
		}
		
		if (api.getACCTINTERNALKEY() != null) {
			jpe.getCommonSettleNostroMt103Rec().setCommonSettleNostroRec(mapToCommonSettleDepositRec(
					jpe.getCommonSettleNostroMt103Rec().getCommonSettleNostroRec(), api.getACCTINTERNALKEY()));
		}

		jpe.getCommonSettleNostroMt103Rec().getCommonSettleNostroRec().setRemarks(api.getREMARKS());
	}
	
	public void mapSWFMT202ToJpe(CommonSettelementJpeInterface jpe, CommonSettelementApiInterface api){
		SwfMt202Jpe swfMt202Jpe = mt202Mapper.mapToJpe(api.getSWIFT(), new SwfMt202Jpe());

		if (jpe.getCommonSettleNostroMt202Rec() == null) {
			jpe.setCommonSettleNostroMt202Rec(new CommonSettleNostroMt202Jpe());
		}

		jpe.getCommonSettleNostroMt202Rec().setSwfMt202StructRec(swfMt202Jpe);

		// set CommonSettleNostroRec
		if (jpe.getCommonSettleNostroMt202Rec().getCommonSettleNostroRec() == null) {
			jpe.getCommonSettleNostroMt202Rec().setCommonSettleNostroRec(new CommonSettleNostroJpe());
		}
		
		if (api.getACCTINTERNALKEY() != null) {
			jpe.getCommonSettleNostroMt202Rec().setCommonSettleNostroRec(mapToCommonSettleDepositRec(
					jpe.getCommonSettleNostroMt202Rec().getCommonSettleNostroRec(), api.getACCTINTERNALKEY()));
		}

		jpe.getCommonSettleNostroMt202Rec().getCommonSettleNostroRec().setRemarks(api.getREMARKS());
	}

	public void mapSWFMT400ToJpe(CommonSettelementJpeInterface jpe, CommonSettelementApiInterface api){
		SwfMt400Jpe swfMt400Jpe = mt400Mapper.mapToJpe(api.getSWIFT(), new SwfMt400Jpe());

		if (jpe.getCommonSettleNostroMt400Rec() == null) {
			jpe.setCommonSettleNostroMt400Rec(new CommonSettleNostroMt400Jpe());
		}

		jpe.getCommonSettleNostroMt400Rec().setSwfMt400StructRec(swfMt400Jpe);

		// set CommonSettleNostroRec
		if (jpe.getCommonSettleNostroMt400Rec().getCommonSettleNostroRec() == null) {
			jpe.getCommonSettleNostroMt400Rec().setCommonSettleNostroRec(new CommonSettleNostroJpe());
		}

		if (api.getACCTINTERNALKEY() != null) {
			jpe.getCommonSettleNostroMt400Rec().setCommonSettleNostroRec(mapToCommonSettleDepositRec(
					jpe.getCommonSettleNostroMt400Rec().getCommonSettleNostroRec(), api.getACCTINTERNALKEY()));
		}

		jpe.getCommonSettleNostroMt400Rec().getCommonSettleNostroRec().setRemarks(api.getREMARKS());
	}
	
	public void mapSWFMT103202COVToJpe(CommonSettelementJpeInterface jpe, CommonSettelementApiInterface api){
		if (jpe.getCommonSettleNostroMt103Mt202CovRec() == null) {
			jpe.setCommonSettleNostroMt103Mt202CovRec(new CommonSettleNostroMt103Mt202CovJpe());
		}

		SwfMt103Jpe swfMt103Jpe = mt103Mapper.mapToJpe(api.getSWIFT(), new SwfMt103Jpe());
		jpe.getCommonSettleNostroMt103Mt202CovRec().setSwfMt103StructRec(swfMt103Jpe);

		if(api.getSWIFT().getCOVERMESSAGEDETAILS() != null){					
			SwfFinEntityJpe swfF54Jpe = swfF54Mapper.mapToJpe(api.getSWIFT().getCOVERMESSAGEDETAILS().getRECEIVERSCORRESPONDENT());
			SwfFinEntityJpe swfF58Jpe = swfF58Mapper.mapToJpe(api.getSWIFT().getCOVERMESSAGEDETAILS().getBENEFICIARYINSTITUTION());
			SwfF72Jpe swfF72Jpe = swfF72Mapper.mapToJpe(api.getSWIFT().getCOVERMESSAGEDETAILS().getSENDERTORECEIVERINFO());
			jpe.getCommonSettleNostroMt103Mt202CovRec().setCovReceiversCorrespondentStructRec(swfF54Jpe);
			jpe.getCommonSettleNostroMt103Mt202CovRec().setCovBeneficiaryInstitutionStructRec(swfF58Jpe);
			jpe.getCommonSettleNostroMt103Mt202CovRec().setCovSenderToReceiverInfoStructRec(swfF72Jpe);
		}

		// set CommonSettleNostroRec
		if (jpe.getCommonSettleNostroMt103Mt202CovRec().getCommonSettleNostroRec() == null) {
			jpe.getCommonSettleNostroMt103Mt202CovRec().setCommonSettleNostroRec(new CommonSettleNostroJpe());
		}
		
		if (api.getACCTINTERNALKEY() != null) {
			jpe.getCommonSettleNostroMt103Mt202CovRec().setCommonSettleNostroRec(mapToCommonSettleDepositRec(
				jpe.getCommonSettleNostroMt103Mt202CovRec().getCommonSettleNostroRec(), api.getACCTINTERNALKEY()));
		}

		jpe.getCommonSettleNostroMt103Mt202CovRec().getCommonSettleNostroRec().setRemarks(api.getREMARKS());
	}

	public void mapMessageToJpe(CommonSettelementJpeInterface jpe, CommonSettelementApiInterface api){
		SettleMessageJpe settleMessageJpe = settleMessageMapper.mapToJpe(api.getMESSAGE(), new SettleMessageJpe());
		jpe.setMessageStructRec(settleMessageJpe);
	}
	
	protected String getSwiftFormat(String settleMethod, String payRec) {
		if (StringUtils.isBlank(settleMethod)) {
			return null;
		}

		String qlString = "select e from SettleMethodJpe e "
				+ "where e.routeDest = :routeDest "
				+ "and e.settleMethod = :settleMethod "
				+ "and e.payRec = '" + (REC.equals(payRec) ? REC : PAY) + "' "
				+ "and e.settleAcctType = 'N'";
		Map<String, Object> params = new HashMap<String, Object>();
		params.put("routeDest", ROUTE_SWIFT);
		params.put("settleMethod", settleMethod);

		List<SettleMethodJpe> smList = dataService.findWithQuery(qlString, SettleMethodJpe.class, params, null);
		String format = "";

		if (smList != null && !smList.isEmpty()) {
			format = smList.get(0).getFormat();
		}

		return format;
	}

	protected Long getRetailInternalKey(String acctNo) {
		if (StringUtils.isBlank(acctNo)) {
			return null;
		}
		Long acctInternalKey = null;

		Map<String, Object> params = new HashMap<String, Object>();
		params.put("acctNo", acctNo);

		List<Long> acctInternalKeys = dataService.findWithNamedQuery(XpsJpeConstants.SC_UNCOLL_QRY_JPE_FIND_BY_ACCT_NO,
				params, Long.class);
		if (!acctInternalKeys.isEmpty()) {
			acctInternalKey = acctInternalKeys.get(0);
		}

		return acctInternalKey;
	}

	protected Long getAcctInternalKey(String acctNo) {
		if (StringUtils.isBlank(acctNo)) {
			return null;
		}
		Long acctInternalKey = null;

		Map<String, Object> params = new HashMap<String, Object>();
		params.put("acctNo", acctNo);

		List<Long> acctInternalKeys = dataService
				.findWithNamedQuery(GlaJpeConstants.GLA_ACCOUNT_JPE_FIND_INTERNAL_KEY_BY_ACCT_NO, params, Long.class);
		if (!acctInternalKeys.isEmpty()) {
			acctInternalKey = acctInternalKeys.get(0);
		}

		return acctInternalKey;
	}

	protected GlAccountJpe getAcctByInternalKey(Long internalkey) {
		if (null == internalkey) {
			return null;
		}

		Map<String, Object> params = new HashMap<String, Object>();
		params.put("internalKey", internalkey);
		List<GlAccountJpe> glaList = dataService
				.findWithNamedQuery(GlaJpeConstants.GLA_ACCOUNT_JPE_FIND_BY_INTERNAL_KEY, params, GlAccountJpe.class);

		if (!glaList.isEmpty() && glaList.size() > 0) {
			return glaList.get(0);
		}
		return null;
	}

	protected CommonSettleNostroJpe mapToCommonSettleDepositRec(CommonSettleNostroJpe jpe, Long internalKey) {
		GlAccountJpe gla = getAcctByInternalKey(internalKey);
		
		if(jpe == null) {
			jpe = new CommonSettleNostroJpe();
		}
		if (gla != null) {
			jpe.setNosVosNo(gla.getNosVosNo());
			jpe.setAcctNo(gla.getAcctNo());
			jpe.setBranch(gla.getBranch());
			jpe.setCcy(gla.getCcy());
		}
		return jpe;
	}

	protected String getClientNo(Long clientId) {
		if (clientId == null) {
			return null;
		}

		String client = null;
		Map<String, Object> params = new HashMap<String, Object>();
		params.put("clientId", clientId);

		List<String> clientNo = dataService
				.findWithNamedQuery(MclJpeConstants.CLIENT_JPE_FIND_CLIENT_NO_USING_CLIENT_ID, params, String.class);

		if (!clientNo.isEmpty()) {
			client = clientNo.get(0);
		}
		return client;
	}

	protected DepAcctVJpe getAcctNo(Long internalKey) {
		if (internalKey == null) {
			return null;
		}

		Map<String, Object> params = new HashMap<String, Object>();
		params.put("internalKey", internalKey);
		List<DepAcctVJpe> depAcctList = dataService.findWithNamedQuery(XpsJpeConstants.DEP_ACCT_V_JPE_FIND_BY_INTERNAL_KEY, params, DepAcctVJpe.class);
		if (!depAcctList.isEmpty() && depAcctList.size() > 0) {
			return depAcctList.get(0);
		}
		return null;
	}

	protected CommonSettleDepositJpe mapToRetailAcct(CommonSettleDepositJpe jpe, Long internalKey) {
		DepAcctVJpe depAcct = getAcctNo(internalKey);

		if (depAcct != null) {
			jpe.setAcctNo(depAcct.getAcctNo());
			jpe.setClientId(depAcct.getClientId());
			jpe.setClientNo(getClientNo(depAcct.getClientId()));
		}
		return jpe;
	}

}
