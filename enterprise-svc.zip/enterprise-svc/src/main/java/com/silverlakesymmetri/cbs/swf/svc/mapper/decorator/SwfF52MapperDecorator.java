package com.silverlakesymmetri.cbs.swf.svc.mapper.decorator;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

import com.silverlakesymmetri.cbs.swf.jpa.mapping.sdo.SwfFinEntityJpe;
import com.silverlakesymmetri.cbs.swf.svc.mapper.mapping.SwfF52Mapper;
import com.silverlakesymmetri.cbs.swf.xmlapi.SWFF52TYPEType;

public abstract class SwfF52MapperDecorator implements SwfF52Mapper {
	
	@Autowired
	@Qualifier("delegate")
	protected SwfF52Mapper delegate;

	@Override
	public SWFF52TYPEType mapToApi(SwfFinEntityJpe jpe){
		SWFF52TYPEType swfF52 = delegate.mapToApi(jpe);
		if(swfF52 != null && swfF52.getACCOUNT() == null && swfF52.getADDRESS() == null && swfF52.getBIC() == null && swfF52.getBRANCHLOCATION() == null){
			return null;
		}
		return swfF52;
	}
	
	@Override
	public SwfFinEntityJpe mapToJpe(SWFF52TYPEType api){
		return delegate.mapToJpe(api);
	}
	
}
