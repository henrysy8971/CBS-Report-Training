package com.silverlakesymmetri.cbs.xps.svc;

import java.util.List;
import java.util.Map;

import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation;
import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation.ServiceOperationType;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.svc.BusinessService;
import com.silverlakesymmetri.cbs.xps.bdo.sdo.ChargeSettlementLandingQry;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.ChargeSettlementLandingQryJpe;

public interface ChargeSettlementLandingQryService extends BusinessService<ChargeSettlementLandingQry, ChargeSettlementLandingQryJpe> {
	public static final String XPS_CHARGESETTLEMENTQRYSERVICE_GET = "ChargeSettlementLandingQryService.get";
    public static final String XPS_CHARGESETTLEMENTQRYSERVICE_FIND = "ChargeSettlementLandingQryService.find";
    public static final String XPS_CHARGESETTLEMENTQRYSERVICE_QUERY = "ChargeSettlementLandingQryService.query";
    public static final String XPS_CHARGESETTLEMENTQRYSERVICE_COUNT = "ChargeSettlementLandingQryService.count";
    
    @ServiceOperation(name = XPS_CHARGESETTLEMENTQRYSERVICE_GET, type = ServiceOperationType.GET)
    public ChargeSettlementLandingQry getByPk(String publicKey, ChargeSettlementLandingQry reference);

    @ServiceOperation(name = XPS_CHARGESETTLEMENTQRYSERVICE_FIND)
    public List<ChargeSettlementLandingQry> find(FindCriteria findCriteria, CbsHeader cbsHeader);
    
    @ServiceOperation(name = XPS_CHARGESETTLEMENTQRYSERVICE_QUERY)
    public List<ChargeSettlementLandingQry> query(int offset, int resultLimit, String groupBy, String order, Map<String, Object> filters);

    @ServiceOperation(name = XPS_CHARGESETTLEMENTQRYSERVICE_COUNT, type = ServiceOperationType.GET)
    public Long count(FindCriteria findCriteria, CbsHeader cbsHeader);

}