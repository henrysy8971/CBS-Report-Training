package com.silverlakesymmetri.cbs.swf.svc.mapper.mapping;

import org.apache.commons.lang3.StringUtils;
import org.mapstruct.DecoratedWith;
import org.mapstruct.InheritInverseConfiguration;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Mappings;

import com.silverlakesymmetri.cbs.commons.jpa.util.DateTimeHelper;
import com.silverlakesymmetri.cbs.swf.jpa.mapping.sdo.SwfF25Jpe;
import com.silverlakesymmetri.cbs.swf.svc.mapper.decorator.SwfF25MapperDecorator;
import com.silverlakesymmetri.cbs.swf.xmlapi.SWFF25TYPEType;

@Mapper(imports=StringUtils.class, uses={DateTimeHelper.class})
@DecoratedWith(SwfF25MapperDecorator.class)
public interface SwfF25Mapper {
	@Mappings({
		@Mapping(source="opt", target="OPT"),
		@Mapping(source="accountNo", target="ACCOUNTNO"),
	})
	SWFF25TYPEType mapToApi(SwfF25Jpe jpe);
	
	@Mappings({
		@Mapping(target="opt", expression="java(StringUtils.isNotBlank(api.getOPT())?api.getOPT():null)"),
	})
	@InheritInverseConfiguration(name = "mapToApi")
	SwfF25Jpe mapToJpe(SWFF25TYPEType api);
}
