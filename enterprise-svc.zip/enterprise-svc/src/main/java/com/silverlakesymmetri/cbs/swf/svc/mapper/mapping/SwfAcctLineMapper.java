package com.silverlakesymmetri.cbs.swf.svc.mapper.mapping;

import org.apache.commons.lang3.StringUtils;
import org.mapstruct.DecoratedWith;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Mappings;

import com.silverlakesymmetri.cbs.swf.jpa.mapping.sdo.SwfAcctLineJpe;
import com.silverlakesymmetri.cbs.swf.svc.mapper.decorator.SwfAcctLineMapperDecorator;
import com.silverlakesymmetri.cbs.swf.xmlapi.SWFACCTLINETYPEType;

@Mapper(imports = StringUtils.class)
@DecoratedWith(SwfAcctLineMapperDecorator.class)
public interface SwfAcctLineMapper {
	@Mappings({
		@Mapping(source="acctIdentification", target="ACCTIDENTIFICATION"),
		@Mapping(source="clearingCodeSystem", target="CLEARINGSYSTEMCODE"),
		@Mapping(source="accountNo", target="ACCOUNTNO")
	})
	SWFACCTLINETYPEType mapToApi(SwfAcctLineJpe jpe);
	
	@Mappings({
		@Mapping(target="acctIdentification", expression="java(StringUtils.isNotBlank(api.getACCTIDENTIFICATION())?api.getACCTIDENTIFICATION():null)"),
		@Mapping(target="clearingCodeSystem", expression="java(StringUtils.isNotBlank(api.getCLEARINGSYSTEMCODE())?api.getCLEARINGSYSTEMCODE():null)"),
		@Mapping(target="accountNo", expression="java(StringUtils.isNotBlank(api.getACCOUNTNO())?api.getACCOUNTNO():null)")
	})
	SwfAcctLineJpe mapToJpe(SWFACCTLINETYPEType api);
}