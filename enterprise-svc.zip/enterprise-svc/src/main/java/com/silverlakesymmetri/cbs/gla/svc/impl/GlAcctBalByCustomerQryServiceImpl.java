package com.silverlakesymmetri.cbs.gla.svc.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import com.silverlakesymmetri.cbs.commons.jpa.extension.CbsOracle12Platform;
import org.springframework.stereotype.Service;

import com.mysema.query.types.EntityPath;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.svc.AbstractBusinessService;
import com.silverlakesymmetri.cbs.gla.bdo.sdo.GlAcctBalByCustomerQry;
import com.silverlakesymmetri.cbs.gla.bdo.sdo.GlAcctQry;
import com.silverlakesymmetri.cbs.gla.jpa.mapping.sdo.GlAcctBalByCustomerQryJpe;
import com.silverlakesymmetri.cbs.gla.jpa.mapping.sdo.GlAcctQryJpe;
import com.silverlakesymmetri.cbs.gla.jpa.mapping.sdo.QGlAcctBalByCustomerQryJpe;
import com.silverlakesymmetri.cbs.gla.jpa.mapping.sdo.util.GlaJpeConstants;
import com.silverlakesymmetri.cbs.gla.jpa.mapping.sdo.id.GlAcctBalByCustomerQryPk;
import com.silverlakesymmetri.cbs.gla.svc.GlAcctBalByCustomerQryService;

@Service
public class GlAcctBalByCustomerQryServiceImpl extends AbstractBusinessService<GlAcctBalByCustomerQry, GlAcctBalByCustomerQryJpe, GlAcctBalByCustomerQryPk> implements 
		GlAcctBalByCustomerQryService {

	@Override
	protected GlAcctBalByCustomerQryPk getIdFromDataObjectInstance(GlAcctBalByCustomerQry dataObject) {
		return new GlAcctBalByCustomerQryPk(dataObject.getClientNo(), dataObject.getBranch(), dataObject.getCcy(), dataObject.getGlCode(), dataObject.getSeqNo(), dataObject.getProfitCentre());
	}

	@Override
	protected EntityPath<GlAcctBalByCustomerQryJpe> getEntityPath() {
		return QGlAcctBalByCustomerQryJpe.glAcctBalByCustomerQryJpe;
	}
	
	@Override
	public GlAcctBalByCustomerQry getByPk(String publicKey, GlAcctBalByCustomerQry dataObject) {

		GlAcctBalByCustomerQry glAcctBalByCustomerQry = super.getByPk(publicKey, dataObject);

		if (glAcctBalByCustomerQry != null ) 
			glAcctBalByCustomerQry.setAcctList(getAcctList(glAcctBalByCustomerQry));

		return glAcctBalByCustomerQry;
	}

	private List<GlAcctQry> getAcctList(final GlAcctBalByCustomerQry dataObject) {
		List<GlAcctQry> bdoList = null;

		Map<String, Object> params = new HashMap<>();
		params.put("clientNo", dataObject.getClientNo());
		params.put("branch", dataObject.getBranch());
		params.put("ccy", dataObject.getCcy());
		params.put("glCode", dataObject.getGlCode());
		List<GlAcctQryJpe>  glAcctQryJpeList = dataService.findWithNamedQuery(
				GlaJpeConstants.GLA_ACCT_QRY_JPE_FIND_BY_CLIENT_NO_BRANCH_CCY_GL_CODE, params,GlAcctQryJpe.class);

		if (glAcctQryJpeList != null && !glAcctQryJpeList.isEmpty()) {
			bdoList = glAcctQryJpeList.stream()
									.map(glAcctQryJpe -> jaxbSdoHelper.wrap(glAcctQryJpe, GlAcctQry.class))
									.collect(Collectors.toList());
		}
		return bdoList;
	}
	
	@Override
	public List<GlAcctBalByCustomerQry> query(int offset, int resultLimit, String groupBy, String order,
			Map<String, Object> filters) {
		try {
			CbsOracle12Platform.setUseNewOraclePaging(true);
			return super.query(offset, resultLimit, groupBy, order, filters);
		} finally {
			CbsOracle12Platform.setUseNewOraclePaging(false);
		}
	}

	@Override
	public List<GlAcctBalByCustomerQry> find(FindCriteria findCriteria, CbsHeader cbsHeader) {
		try {
			CbsOracle12Platform.setUseNewOraclePaging(true);
			return super.find(findCriteria, cbsHeader);
		} finally {
			CbsOracle12Platform.setUseNewOraclePaging(false);
		}
	}
	
	@Override
	public GlAcctBalByCustomerQry get(GlAcctBalByCustomerQry objectInstanceIdentifier) {
		return super.get(objectInstanceIdentifier);
	}

}
