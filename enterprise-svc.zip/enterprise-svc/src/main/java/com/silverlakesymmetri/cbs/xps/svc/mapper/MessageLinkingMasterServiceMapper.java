package com.silverlakesymmetri.cbs.xps.svc.mapper;

import org.mapstruct.Context;
import org.mapstruct.InheritInverseConfiguration;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingTarget;
import org.mapstruct.Mappings;

import com.silverlakesymmetri.cbs.commons.xmlapi.enums.CbsXmlApiOperation;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.MessageLinkingMasterJpe;
import com.silverlakesymmetri.cbs.xps.xmlapi.XPSSWFLINKAPIType;

@Mapper
public interface MessageLinkingMasterServiceMapper {
	@Mappings({
		@Mapping(expression = "java(oper != null ? oper.getOperation() : null)", target="OPERATION"),
		@Mapping(source="direction", target = "DIRECTION"),
		@Mapping(source="internalKey", target = "INTERNALKEY"),
	})
	public XPSSWFLINKAPIType mapToApi(MessageLinkingMasterJpe jpe, @Context CbsXmlApiOperation oper);
	
	@InheritInverseConfiguration(name = "mapToApi")
	public MessageLinkingMasterJpe mapToJpe(XPSSWFLINKAPIType api, @MappingTarget MessageLinkingMasterJpe jpe);
}
