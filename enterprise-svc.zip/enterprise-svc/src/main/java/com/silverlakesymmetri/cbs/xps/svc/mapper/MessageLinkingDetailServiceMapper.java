package com.silverlakesymmetri.cbs.xps.svc.mapper;

import org.mapstruct.InheritInverseConfiguration;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingTarget;
import org.mapstruct.Mappings;

import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.MessageLinkingListJpe;
import com.silverlakesymmetri.cbs.xps.xmlapi.XPSSWFLINKDETAILTYPEType;

@Mapper
public interface MessageLinkingDetailServiceMapper {
	@Mappings({
		@Mapping(source="direction", target = "DIRECTION"),
		@Mapping(source="internalKey", target = "INTERNALKEY"),
	})
	public XPSSWFLINKDETAILTYPEType mapToApi(MessageLinkingListJpe jpe);
	
	@InheritInverseConfiguration(name = "mapToApi")
	public MessageLinkingListJpe mapToJpe(XPSSWFLINKDETAILTYPEType api, @MappingTarget MessageLinkingListJpe jpe);
}
