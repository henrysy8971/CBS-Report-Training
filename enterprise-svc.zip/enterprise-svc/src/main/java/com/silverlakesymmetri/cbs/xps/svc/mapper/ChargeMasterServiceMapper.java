package com.silverlakesymmetri.cbs.xps.svc.mapper;

import org.mapstruct.Context;
import org.mapstruct.DecoratedWith;
import org.mapstruct.InheritInverseConfiguration;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingTarget;
import org.mapstruct.Mappings;

import com.silverlakesymmetri.cbs.commons.jpa.util.DateTimeHelper;
import com.silverlakesymmetri.cbs.commons.xmlapi.enums.CbsXmlApiOperation;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.ChargeMasterJpe;
import com.silverlakesymmetri.cbs.xps.svc.mapper.decorator.ChargeMasterServiceDecorator;
import com.silverlakesymmetri.cbs.xps.svc.mapper.mapping.XpsMessageJpeToXPSMESSAGETYPETypeMapper;
import com.silverlakesymmetri.cbs.xps.xmlapi.XPSTRANCHARGEWITHSETTLEAPIType;

@Mapper(uses={ DateTimeHelper.class, XpsMessageJpeToXPSMESSAGETYPETypeMapper.class })
@DecoratedWith(ChargeMasterServiceDecorator.class)
public interface ChargeMasterServiceMapper {

	@Mappings({
		@Mapping(expression = "java(oper != null ? oper.getOperation() : null)", target="OPERATION"),
		@Mapping(source="domain", target = "DOMAIN"),
		@Mapping(source="internalKey", target = "INTERNALKEY"),
		@Mapping(source="tranKey", target = "TRANKEY"),
		@Mapping(source="seqNo", target = "SEQNO"),
		@Mapping(source="instrumentType", target = "INSTRUMENTTYPE"),
		@Mapping(source="payRec", target = "PAYREC"),
		@Mapping(source="tranDate", target = "TRANDATE", qualifiedByName = {"DateTimeHelper", "convertDateToCbsXmlApiDate"}),
		@Mapping(source="valueDate", target = "VALUEDATE", qualifiedByName = {"DateTimeHelper", "convertDateToCbsXmlApiDate"}),
		@Mapping(source="bookBranch", target = "BOOKBRANCH"),
		@Mapping(source="profitCentre", target = "PROFITCENTRE"),
		@Mapping(source="partyCharged", target = "PARTYCHARGED"),
		@Mapping(source="partyClientId", target = "PARTYCLIENTID"),
		@Mapping(source="partyContactRefNo", target = "PARTYCONTACTREFNO"),
		@Mapping(source="partyContactAddress", target = "PARTYCONTACTADDRESS"),
		@Mapping(source="tranStatus", target = "TRANSTATUS"),
		@Mapping(source="eventType", target = "EVENTTYPE"),
		@Mapping(source="eventSeq", target = "EVENTSEQ"),
		@Mapping(source="attached", target = "ATTACHED"),
		@Mapping(source="attachedKey", target = "ATTACHEDKEY"),
		@Mapping(source="remarks", target = "REMARKS"),
		@Mapping(source="ccy", target = "CCY"),
		@Mapping(source="amount", target = "AMOUNT"),
		@Mapping(source="baseSpotRate", target = "BASESPOTRATE"),
		@Mapping(source="baseFwdPoints", target = "BASEFWDPOINTS"),
		@Mapping(source="baseExchSpread", target = "BASEEXCHSPREAD"),
		@Mapping(source="baseClientSpread", target = "BASECLIENTSPREAD"),
		@Mapping(source="baseEffectRate", target = "BASEEFFECTRATE"),
		@Mapping(source="baseQuote", target = "BASEQUOTE"),
		@Mapping(source="baseEquiv", target = "BASEEQUIV"),
		@Mapping(source="localEffectRate", target = "LOCALEFFECTRATE"),
		@Mapping(source="localQuote", target = "LOCALQUOTE"),
		@Mapping(source="localEquiv", target = "LOCALEQUIV"),
		@Mapping(source="messageStructList", target = "MESSAGELIST.XPSMESSAGETYPE")
	})
	public XPSTRANCHARGEWITHSETTLEAPIType mapToApi(ChargeMasterJpe jpe, @Context CbsXmlApiOperation oper);

	@InheritInverseConfiguration(name = "mapToApi")
	@Mappings({
		@Mapping(source="TRANDATE", target="tranDate", qualifiedByName = {"DateTimeHelper", "convertCbsApiDateToString"}),
		@Mapping(source="VALUEDATE", target="valueDate", qualifiedByName = {"DateTimeHelper", "convertCbsApiDateToString"})
	})
	public ChargeMasterJpe mapToJpe(XPSTRANCHARGEWITHSETTLEAPIType api, @MappingTarget ChargeMasterJpe jpe);
}