package com.silverlakesymmetri.cbs.gla.svc.impl;

import com.mysema.query.types.EntityPath;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.exception.CbsRuntimeException;
import com.silverlakesymmetri.cbs.commons.logging.CbsAppLogger;
import com.silverlakesymmetri.cbs.commons.logging.CbsAppLoggerFactory;
import com.silverlakesymmetri.cbs.commons.svc.AbstractXmlApiBusinessService;
import com.silverlakesymmetri.cbs.commons.xmlapi.enums.CbsXmlApiOperation;
import com.silverlakesymmetri.cbs.commons.xmlapi.rs.CUTAPIHEADEROUTCPLXType;
import com.silverlakesymmetri.cbs.gla.bdo.sdo.GlAccountingEntriesInterBranchForex;
import com.silverlakesymmetri.cbs.gla.bdo.sdo.GlAccountingEntriesInterBranchForexImpl;
import com.silverlakesymmetri.cbs.gla.jpa.mapping.sdo.*;
import com.silverlakesymmetri.cbs.gla.svc.AcctngEntryInterBranchForexService;
import com.silverlakesymmetri.cbs.gla.svc.mapper.mapping.GlAcctgEntryDetailToGLAACCTGENTRYDTLTYPEMapper;
import com.silverlakesymmetri.cbs.gla.svc.mapper.mapping.GlAcctgEntryGroupToGLAACCTGENTRYGROUPTYPEMapper;
import com.silverlakesymmetri.cbs.gla.svc.mapper.mapping.GlAcctgEntryToGLAACCOUNTINGENTRYTYPEMapper;
import com.silverlakesymmetri.cbs.gla.xmlapi.GLAACCOUNTINGENTRYGROUPTYPEType;
import com.silverlakesymmetri.cbs.gla.xmlapi.GLAACCOUNTINGENTRYINTERBRANCHFOREXAPIType;
import com.silverlakesymmetri.cbs.gla.xmlapi.GLAACCOUNTINGENTRYLISTTYPEType;
import com.silverlakesymmetri.cbs.gla.xmlapi.GLAACCOUNTINGENTRYTYPEType;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;

@Service
public class AcctngEntryInterBranchForexServiceImpl extends
		AbstractXmlApiBusinessService<GlAccountingEntriesInterBranchForex, GlAccountingEntriesInterBranchForexJpe, String, GLAACCOUNTINGENTRYINTERBRANCHFOREXAPIType, GLAACCOUNTINGENTRYINTERBRANCHFOREXAPIType>
		implements AcctngEntryInterBranchForexService {

	private CbsAppLogger logger = CbsAppLoggerFactory.getLogger(AcctngEntryInterBranchForexServiceImpl.class);

	private static final String SP_RES_XML_API = "p_Response";
	private static final String SP_RES_HEADER_OUT = "p_Response_Header";

    @Autowired
    GlAcctgEntryToGLAACCOUNTINGENTRYTYPEMapper acctgEntryMapper;

    @Autowired
	GlAcctgEntryGroupToGLAACCTGENTRYGROUPTYPEMapper acctgEntryGrpMapper;

    @Autowired
	GlAcctgEntryDetailToGLAACCTGENTRYDTLTYPEMapper detailMapper;

	@Override
	protected String getIdFromDataObjectInstance(GlAccountingEntriesInterBranchForex dataObject) {
		return null;
	}

	@Override
	protected EntityPath<GlAccountingEntriesInterBranchForexJpe> getEntityPath() {
		return QGlAccountingEntriesInterBranchForexJpe.glAccountingEntriesInterBranchForexJpe;
	}

	@Override
	public GlAccountingEntriesInterBranchForex getByPk(String publicKey, GlAccountingEntriesInterBranchForex reference) {
		return reference;
	}

	private GLAACCOUNTINGENTRYINTERBRANCHFOREXAPIType transformBdoToXmlApiType(GlAccountingEntriesInterBranchForex bdo, String oper) {
		GlAccountingEntriesInterBranchForexJpe hdrJpe = jaxbSdoHelper.unwrap(bdo);

		GLAACCOUNTINGENTRYINTERBRANCHFOREXAPIType hdrApi = new GLAACCOUNTINGENTRYINTERBRANCHFOREXAPIType();

		GLAACCOUNTINGENTRYLISTTYPEType entryListApi = new GLAACCOUNTINGENTRYLISTTYPEType();

		transformAcctgEntriesToGLAACCOUNTINGENTRYLISTTYPEType(hdrJpe.getEntriesStructList(), entryListApi, hdrApi);
		hdrApi.setENTRIES(entryListApi);
		super.setTechColumns(hdrApi);
		hdrApi.setOPERATION(oper);

		return hdrApi;
	}

	private void transformAcctgEntriesToGLAACCOUNTINGENTRYLISTTYPEType(List<GlAccountingEntryJpe> entriesStructList,
																	   GLAACCOUNTINGENTRYLISTTYPEType entryListApi, GLAACCOUNTINGENTRYINTERBRANCHFOREXAPIType hdrApi) {
		if (entriesStructList != null ) {
			if(entriesStructList != null && entriesStructList.size() > 0) {
			    for(GlAccountingEntryJpe acctgEntryJpe: entriesStructList) {
                    entryListApi.getGLAACCOUNTINGENTRYTYPE().add(createGLAACCOUTINGENTRYAPIType(hdrApi, acctgEntryJpe));
                }

			}
		}
	}

	private GLAACCOUNTINGENTRYTYPEType createGLAACCOUTINGENTRYAPIType(GLAACCOUNTINGENTRYINTERBRANCHFOREXAPIType xmlApiObj, GlAccountingEntryJpe acctgEntryJpe) {

		GLAACCOUNTINGENTRYTYPEType acctgEntryApi = acctgEntryMapper.mapToApi(acctgEntryJpe);

		if(acctgEntryJpe != null && acctgEntryJpe.getCreditsStructList() != null && acctgEntryJpe.getCreditsStructList().size() > 0 ) {
			for(GlAccountingEntryGroupJpe creditJpe: acctgEntryJpe.getCreditsStructList()) {
				GLAACCOUNTINGENTRYGROUPTYPEType glACCTGENTRYGRPAPITYPE = createGlACCTGENTRYGRPAPITYPE(acctgEntryApi, creditJpe);
				createGlACCTGENTRYDETAILAPITYPE(glACCTGENTRYGRPAPITYPE, creditJpe);
				acctgEntryApi.getCREDITS().getGLAACCOUNTINGENTRYGROUPTYPE().add(glACCTGENTRYGRPAPITYPE);
			}

			for(GlAccountingEntryGroupJpe debitJpe: acctgEntryJpe.getDebitsStructList()) {
				GLAACCOUNTINGENTRYGROUPTYPEType glACCTGENTRYGRPAPITYPE = createGlACCTGENTRYGRPAPITYPE(acctgEntryApi, debitJpe);
				createGlACCTGENTRYDETAILAPITYPE(glACCTGENTRYGRPAPITYPE, debitJpe);
				acctgEntryApi.getDEBITS().getGLAACCOUNTINGENTRYGROUPTYPE().add(glACCTGENTRYGRPAPITYPE);
			}
		}

		return acctgEntryApi;
	}

	private void createGlACCTGENTRYDETAILAPITYPE(GLAACCOUNTINGENTRYGROUPTYPEType groupApiType, GlAccountingEntryGroupJpe detailJpe) {
		if(detailJpe != null && detailJpe.getDetailsStructList() != null && detailJpe.getDetailsStructList().size() > 0) {
			for(GlAccountingEntryDetailJpe jpe : detailJpe.getDetailsStructList()) {
				groupApiType.getDETAILS().getGLAACCOUNTINGENTRYDETAILTYPE().add(detailMapper.mapToApi(jpe));
			}
		}
	}

	private GLAACCOUNTINGENTRYGROUPTYPEType createGlACCTGENTRYGRPAPITYPE(GLAACCOUNTINGENTRYTYPEType acctgEntryApi, GlAccountingEntryGroupJpe groupJpe) {
		return acctgEntryGrpMapper.mapToApi(groupJpe);
	}


	@Override
	protected GlAccountingEntriesInterBranchForex processXmlApiRs(GlAccountingEntriesInterBranchForex dataObject, GLAACCOUNTINGENTRYINTERBRANCHFOREXAPIType xmlApiRs) {
		return dataObject;
	}

	@Override
	protected List<GlAccountingEntriesInterBranchForex> processXmlApiListRs(GlAccountingEntriesInterBranchForex dataObject, GLAACCOUNTINGENTRYINTERBRANCHFOREXAPIType xmlApiRs) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	protected Class<GLAACCOUNTINGENTRYINTERBRANCHFOREXAPIType> getXmlApiResponseClass() {
		return GLAACCOUNTINGENTRYINTERBRANCHFOREXAPIType.class;
	}


	@Override
	protected GLAACCOUNTINGENTRYINTERBRANCHFOREXAPIType transformBdoToXmlApiRqCreate(GlAccountingEntriesInterBranchForex dataObject) {
		return null;
	}

	@Override
	protected GLAACCOUNTINGENTRYINTERBRANCHFOREXAPIType transformBdoToXmlApiRqUpdate(GlAccountingEntriesInterBranchForex dataObject) {
		return null;
	}

	@Override
	protected GLAACCOUNTINGENTRYINTERBRANCHFOREXAPIType transformBdoToXmlApiRqDelete(GlAccountingEntriesInterBranchForex dataObject) {
		return null;
	}

	@Override
	public GlAccountingEntriesInterBranchForex processAuthorize(GlAccountingEntriesInterBranchForex acctgEntriesObj) {
		return executeStoredProcedureAuthorize(acctgEntriesObj, false);
	}

	private GlAccountingEntriesInterBranchForex executeStoredProcedureAuthorize(GlAccountingEntriesInterBranchForex acctgEntriesObj, boolean performValidate) {

		if(acctgEntriesObj != null) {
			try {
				String xmlApiReq = convertXmlApiRqToString(transformBdoToXmlApiType(acctgEntriesObj, "PROCESS_AUTHORIZE"));
				String xmlHeaderIn = convertXmlApiRqToString(createHeader());
				if (performValidate) {
					validate(acctgEntriesObj, xmlApiReq, xmlHeaderIn);
				}
				Map<String, String> responseMap = executeStoredProcedure(xmlApiReq, xmlHeaderIn);
				return handleXmlApiRs(acctgEntriesObj,
						convertXmlStringToObject(responseMap.get(SP_RES_XML_API), getXmlApiResponseClass()),
						convertXmlStringToObject(responseMap.get(SP_RES_HEADER_OUT), CUTAPIHEADEROUTCPLXType.class));
			} catch (CbsRuntimeException cre) {
				throw cre;
			} catch (Exception e) {
				throw new RuntimeException(e);
			}
		}

		return null;
	}
	
}
