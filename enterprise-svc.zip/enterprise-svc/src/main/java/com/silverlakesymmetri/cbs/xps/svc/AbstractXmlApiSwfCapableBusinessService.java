package com.silverlakesymmetri.cbs.xps.svc;

import java.io.BufferedReader;
import java.io.Serializable;
import java.io.StringWriter;
import java.sql.Clob;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.inject.Inject;
import javax.persistence.StoredProcedureQuery;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.transform.stream.StreamResult;

import org.springframework.beans.factory.annotation.Autowired;

import com.silverlakesymmetri.cbs.commons.bdo.CbsBusinessDataObject;
import com.silverlakesymmetri.cbs.commons.context.CbsSessionContext;
import com.silverlakesymmetri.cbs.commons.exception.CbsRuntimeException;
import com.silverlakesymmetri.cbs.commons.integration.translator.util.IntegrationHelper;
import com.silverlakesymmetri.cbs.commons.jpa.entity.CbsBusinessDataObjectJpe;
import com.silverlakesymmetri.cbs.commons.jpa.util.DateTimeHelper;
import com.silverlakesymmetri.cbs.commons.logging.CbsAppLogger;
import com.silverlakesymmetri.cbs.commons.logging.annotation.Logger;
import com.silverlakesymmetri.cbs.commons.restlet.JsonConvertionManager;
import com.silverlakesymmetri.cbs.commons.svc.AbstractXmlApiBusinessService;
import com.silverlakesymmetri.cbs.commons.xmlapi.rs.CUTAPIHEADEROUTCPLXType;
import com.silverlakesymmetri.cbs.mcl.bdo.sdo.Client;
import com.silverlakesymmetri.cbs.mcl.bdo.sdo.ClientContact;
import com.silverlakesymmetri.cbs.mcl.jpa.mapping.sdo.ClientJpe;
import com.silverlakesymmetri.cbs.mcl.svc.ClientService;
import com.silverlakesymmetri.cbs.swf.bdo.sdo.SwfMessageGroup;
import com.silverlakesymmetri.cbs.xps.bdo.sdo.SettleMessagePreviewAddInfo;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.MessageQJpe;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.util.XpsJpeConstants;
import com.silverlakesymmetri.cbs.xps.xmlapi.XPSMESSAGEADDITIONALINFOTYPEType;
import com.silverlakesymmetri.cbs.xps.xmlapi.XPSMESSAGETYPEType;
import com.silverlakesymmetri.cbs.xps.xmlapi.XPSSETTLEMESSAGETYPEType;
import com.silverlakesymmetri.cbs.xps.xmlapi.XPSSWFPREVIEWAPIType;

public abstract class AbstractXmlApiSwfCapableBusinessService<B extends CbsBusinessDataObject, E extends CbsBusinessDataObjectJpe, ID extends Serializable, XmlApiRq, XmlApiRs> 
	extends AbstractXmlApiBusinessService<B, E, ID, XmlApiRq, XmlApiRs> {
	
    @Logger
    CbsAppLogger logger;
    
    @Inject
    protected JsonConvertionManager jsonConversionMngr;

    @Autowired
    protected DateTimeHelper dateTimeHelper;

    @Autowired
    protected ClientService clientService;

    @Autowired
    private MessageControlQWrapperService messageControlService;

    protected static final String SP_REQ_XML_API = "p_Request";
	protected static final String SP_REQ_HEADER_IN = "p_Request_Header";
	protected static final String SP_RES_XML_API = "p_Response";
	protected static final String SP_RES_HEADER_OUT = "p_Response_Header";
	
	protected CbsSessionContext sessionCtx;

	public abstract String generateSwfMessage(Map<String, Object> params);
	
	protected B createAsyncPrepared(B bdo, CbsSessionContext sessionCtx) {
		if(sessionCtx != null) this.sessionCtx = sessionCtx; 
		return this.create(bdo);
	}
	
    protected CbsSessionContext getSessionContext() {
    	CbsSessionContext currentSessionCtx = cbsRuntimeContextManager.getContext(CbsSessionContext.class);
    	if(currentSessionCtx != null) {
    		return currentSessionCtx;
    	}
    	return this.sessionCtx;
    }

	
	protected String transformToSwfFormat(XmlApiRq xmlApiRq, SwfMessageGroup msgGroup){
		String message = "";
		try {
			String xmlApiReq = createSwfPreviewRequest(xmlApiRq, msgGroup);
			message = transformToSwfFormat(xmlApiReq);
		} catch (CbsRuntimeException cre) {
			throw cre;
		} catch (Exception e) {
			throw new RuntimeException(e);
		}
		return message;
	}
	
	protected String transformToSwfFormat(XpsSwfSettleXmlApi xmlApiRq, SwfMessageGroup msgGroup, SettleMessagePreviewAddInfo settleInfo){
		String message = "";
		try {
			String xmlApiReq = createSwfSettlePreviewRequest(xmlApiRq, msgGroup, settleInfo);
			message = transformToSwfFormat(xmlApiReq);
		} catch (Exception e) {
			throw new RuntimeException(e);
		}
		return message;
	}

	protected String transformToSwfFormat(String xmlApiReq){
		String message = "";
		try {
			String xmlHeaderIn = convertXmlApiRqToString(createHeader());
			Map<String, String> responseMap = executeStoredProcedure(xmlApiReq, xmlHeaderIn);
			processErrors(convertXmlStringToObject(responseMap.get(SP_RES_HEADER_OUT), CUTAPIHEADEROUTCPLXType.class), null, null);
			message = responseMap.get(SP_RES_XML_API);

			if (logger != null && logger.isDebugEnabled()) {
				logger.debug("SWF_OUT_MESSAGE_TYPEType >>>");
				logger.debug(message);
			}
		} catch (CbsRuntimeException cre) {
			throw cre;
		} catch (Exception e) {
			throw new RuntimeException(e);
		}
		return message;
	}

	private String createSwfPreviewRequest(XmlApiRq xmlApiRq, SwfMessageGroup msgGroup) throws JAXBException{
		String xmlApiReq = removeModifiedByAndModifiedDt(convertXmlApiRqToString(xmlApiRq));
		xmlApiReq = xmlApiReq.replaceAll("(?<=\\<\\?xml)(.*?)(?=\\?\\>)", "");
		xmlApiReq = xmlApiReq.replace("<?xml?>", "");
		
		XPSSWFPREVIEWAPIType previewRequest = new XPSSWFPREVIEWAPIType();
		previewRequest.setMODULEID(msgGroup.getModule());
		previewRequest.setMESSAGEDEFINITION(convertSwfMessageGroup(msgGroup));
		previewRequest.setTRANSACTIONDETAILS("");
		previewRequest.setOPERATION("QUERY");
		
		JAXBContext jaxbContext = getJAXBContextFromPool(XPSSWFPREVIEWAPIType.class);
		Marshaller m = jaxbContext.createMarshaller();
		StringWriter writerIn = new StringWriter();
		StreamResult requestStream = new StreamResult(writerIn);
		m.marshal(previewRequest, requestStream);
		String xmlString = writerIn.toString();
		xmlString = xmlString.replace("<TRANSACTION_DETAILS></TRANSACTION_DETAILS>","<TRANSACTION_DETAILS>"+xmlApiReq+"</TRANSACTION_DETAILS>");
		if (logger != null && logger.isDebugEnabled()) {
			logger.debug("XPS_SWF_PREVIEW_API Request >>>");
			logger.debug(xmlString);
		}
		return xmlString;
	}
	
	protected XPSMESSAGEADDITIONALINFOTYPEType parseForAddtlInfo(SettleMessagePreviewAddInfo settleInfo){
		if(settleInfo != null){
		    try {
				XPSMESSAGEADDITIONALINFOTYPEType addtlInfoType = new XPSMESSAGEADDITIONALINFOTYPEType();
				addtlInfoType.setREFERENCE(settleInfo.getReference());
				addtlInfoType.setRELREFERENCE(settleInfo.getRelReference());
				addtlInfoType.setCCY1(settleInfo.getCcy1());
				addtlInfoType.setAMOUNT1(settleInfo.getAmount1());
				addtlInfoType.setCCY2(settleInfo.getCcy2());
				addtlInfoType.setAMOUNT2(settleInfo.getAmount2());
				addtlInfoType.setCCY3(settleInfo.getCcy3());
				addtlInfoType.setAMOUNT3(settleInfo.getAmount3());
				addtlInfoType.setCCY4(settleInfo.getCcy4());
				addtlInfoType.setAMOUNT4(settleInfo.getAmount4());
				addtlInfoType.setEXCHRATE(settleInfo.getExchRate());
				addtlInfoType.setBRANCH(settleInfo.getBranch());
				addtlInfoType.setINSTRUMENTIND(settleInfo.getInstrumentInd());
				addtlInfoType.setPARENTREFERENCE(settleInfo.getParentReference());
				if(settleInfo.getValueDate() != null) addtlInfoType.setVALUEDATE(dateTimeHelper.convertToCbsXmlApiDate(settleInfo.getValueDate()));
				if(settleInfo.getClientNo() != null){
					ClientJpe clientJpe = clientService.getClientDetails(settleInfo.getClientNo());
					if(clientJpe != null){
						addtlInfoType.setCLIENTID(clientJpe.getClientId());
					}
				}
				return addtlInfoType;
			} catch (NumberFormatException e) {
				return null;
			}
		}
		return null;
	}

	private String createSwfSettlePreviewRequest(XpsSwfSettleXmlApi xmlApiRq, SwfMessageGroup msgGroup, SettleMessagePreviewAddInfo settleInfo) throws JAXBException{
		String xmlApiReq = removeModifiedByAndModifiedDt(convertXmlApiRqToString(xmlApiRq));
		xmlApiReq = xmlApiReq.replaceAll("(?<=\\<\\?xml)(.*?)(?=\\?\\>)", "");
		xmlApiReq = xmlApiReq.replace("<?xml?>", "");
		
		XPSSWFPREVIEWAPIType previewRequest = new XPSSWFPREVIEWAPIType();
		previewRequest.setMODULEID(msgGroup.getModule());
		previewRequest.setMESSAGEDEFINITION(convertSwfMessageGroup(msgGroup));
		previewRequest.setTRANSACTIONDETAILS("");
		previewRequest.setADDITIONALDETAILS(parseForAddtlInfo(settleInfo));
		previewRequest.setOPERATION("QUERY");
		
		JAXBContext jaxbContext = getJAXBContextFromPool(XPSSWFPREVIEWAPIType.class);
		Marshaller m = jaxbContext.createMarshaller();
		StringWriter writerIn = new StringWriter();
		StreamResult requestStream = new StreamResult(writerIn);
		m.marshal(previewRequest, requestStream);
		String xmlString = writerIn.toString();
		xmlString = xmlString.replace("<TRANSACTION_DETAILS></TRANSACTION_DETAILS>","<TRANSACTION_DETAILS>"+xmlApiReq+"</TRANSACTION_DETAILS>");
		if (logger != null && logger.isDebugEnabled()) {
			logger.debug("XPS_SWF_PREVIEW_API Request >>>");
			logger.debug(xmlString);
		}
		return xmlString;
	}

	protected Map<String, String> extractResponseFromSPQ(StoredProcedureQuery query) {
		long xmlApiExecTime = System.currentTimeMillis();
        try  {
        	String xmlHeaderOut = null;
            if (query.getOutputParameterValue(SP_RES_HEADER_OUT) != null) {
                xmlHeaderOut = convertClobToString((Clob) query.getOutputParameterValue(SP_RES_HEADER_OUT));
            }

            String xmlApiRes = null;
            if (query.getOutputParameterValue(SP_RES_XML_API) != null) {
                xmlApiRes = convertClobToPreservedString((Clob) query.getOutputParameterValue(SP_RES_XML_API));
            }

            if (logger != null && logger.isDebugEnabled()) {
                logger.debug(SP_RES_HEADER_OUT + " XML_API_RESPONSE>>> ");
                logger.debug(xmlHeaderOut);
                logger.debug(SP_RES_XML_API + " XML_API_RESPONSE>>> ");
                logger.debug(xmlApiRes);
            }

            Map<String, String> result = new HashMap<>();
            result.put(SP_RES_HEADER_OUT, xmlHeaderOut);
            result.put(SP_RES_XML_API, xmlApiRes);
    		return result;
		} finally {
    		xmlApiExecTime = System.currentTimeMillis() - xmlApiExecTime;
    		if (logger != null) {
    			logger.info("Thread ID - {}, extractResponseFromSPQ Timing - {} ms", Thread.currentThread().getId(), xmlApiExecTime);
    		}
    	}
	}
	
	private String convertClobToString(Clob clobData) {
		if (clobData == null) {
			return null;
		}
		final StringBuilder sb = new StringBuilder();
		String str;
		try {
			BufferedReader br = new BufferedReader(clobData.getCharacterStream());
			while ((str = br.readLine()) !=null) {
				sb.append(str);
			}
			br.close();
	    } catch (Exception e) {
	    	if (logger != null && logger.isDebugEnabled()) {
				logger.debug("Error reading XML Api response.");
				logger.debug(IntegrationHelper.getStackTraceAsString(e));
			}
	    	throw new CbsRuntimeException(e);
	    }
		
		return sb.toString();
	}
	
	private String convertClobToPreservedString(Clob clobData) {
		if (clobData == null) {
			return null;
		}
		final StringBuilder sb = new StringBuilder();
		String str;
		try {
			BufferedReader br = new BufferedReader(clobData.getCharacterStream());
			while ((str = br.readLine()) !=null) {
				sb.append(str);
				sb.append("\n");
			}
			br.close();
	    } catch (Exception e) {
	    	if (logger != null && logger.isDebugEnabled()) {
				logger.debug("Error reading XML Api response.");
				logger.debug(IntegrationHelper.getStackTraceAsString(e));
			}
	    	throw new CbsRuntimeException(e);
	    }
		
		return sb.toString();
	}

	protected XPSMESSAGETYPEType convertSwfMessageGroup(SwfMessageGroup msgGroup) {
		XPSMESSAGETYPEType xpsMessage = new XPSMESSAGETYPEType();
		xpsMessage.setFORMAT(msgGroup.getFormat());
		xpsMessage.setSENDERCONTACTTYPE(msgGroup.getSenderContactType());
		xpsMessage.setSENDERCONTACTSUBTYPE(msgGroup.getSenderContactSubType());
		xpsMessage.setRECEIVERCLIENTTYPE(msgGroup.getReceiverClientType());
		xpsMessage.setRECEIVERCONTACTTYPE(msgGroup.getReceiverContactType());
		xpsMessage.setRECEIVERCONTACTSUBTYPE(msgGroup.getReceiverContactSubType());
		
		return xpsMessage;		
	}


	protected XPSSETTLEMESSAGETYPEType convertSwfMessageToSettle(SwfMessageGroup msgGroup) {
		XPSSETTLEMESSAGETYPEType xpsMessage = new XPSSETTLEMESSAGETYPEType();
		xpsMessage.setFORMAT(msgGroup.getFormat());
		xpsMessage.setSENDERCONTACTTYPE(msgGroup.getSenderContactType());
		xpsMessage.setSENDERCONTACTSUBTYPE(msgGroup.getSenderContactSubType());
		xpsMessage.setRECEIVERCLIENTTYPE(msgGroup.getReceiverClientType());
		xpsMessage.setRECEIVERCONTACTTYPE(msgGroup.getReceiverContactType());
		xpsMessage.setRECEIVERCONTACTSUBTYPE(msgGroup.getReceiverContactSubType());
		
		return xpsMessage;		
	}
    
    
    protected ClientContact getClientContact(Client client, String contactType, String contactSubType){
    	return clientService.getClientContactFromType(client.getClientNo(), contactType, contactSubType);
    }
    
	protected String getGeneratedSwiftMessage(Long tranKey, String eventType, String format, String module) {
		Map<String, Object> params = new HashMap<>();
		params.put("tranInternalKey", tranKey);
		params.put("format", format);
		List<MessageQJpe> messageQEntries = null;
		if(eventType != null){
			params.put("tranEventType", eventType);
			messageQEntries = dataService.findWithNamedQuery(XpsJpeConstants.MESSAGE_Q_JPE_FIND_BY_TRAN_INTERNAL_KEY_EVENT_FORMAT, params, MessageQJpe.class);
		} else {
			messageQEntries = dataService.findWithNamedQuery(XpsJpeConstants.MESSAGE_Q_JPE_FIND_BY_TRAN_INTERNAL_KEY_FORMAT, params, MessageQJpe.class);
		}
		if(messageQEntries != null && messageQEntries.size() > 0){
			return messageControlService.getFormattedMessageForPreview(messageQEntries.get(0).getInternalKey(), module, 
					messageQEntries.get(0).getFormat(), messageQEntries.get(0).getSenderAddress(), messageQEntries.get(0).getDestAddress()); 
		}
		return null;
	}

	protected String getGeneratedSwiftMessage(String tranRefNo, String eventType, String format, String module) {
		Map<String, Object> params = new HashMap<>();
		params.put("tranRefNo", tranRefNo);
		params.put("format", format);
		List<MessageQJpe> messageQEntries = null;
		if(eventType != null){
			params.put("tranEventType", eventType);
			messageQEntries = dataService.findWithNamedQuery(XpsJpeConstants.MESSAGE_Q_JPE_FIND_BY_TRAN_REF_NO_EVENT_FORMAT, params, MessageQJpe.class);
		} else {
			messageQEntries = dataService.findWithNamedQuery(XpsJpeConstants.MESSAGE_Q_JPE_FIND_BY_TRAN_REF_NO_FORMAT, params, MessageQJpe.class);
		}
		if(messageQEntries != null && messageQEntries.size() > 0){
			return messageControlService.getFormattedMessageForPreview(messageQEntries.get(0).getInternalKey(), module, 
					messageQEntries.get(0).getFormat(), messageQEntries.get(0).getSenderAddress(), messageQEntries.get(0).getDestAddress()); 
		}
		return null;
	}
}
