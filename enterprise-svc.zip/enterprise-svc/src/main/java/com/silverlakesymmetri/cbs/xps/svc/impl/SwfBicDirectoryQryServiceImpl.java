package com.silverlakesymmetri.cbs.xps.svc.impl;

import com.mysema.query.types.EntityPath;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.svc.AbstractBusinessService;
import com.silverlakesymmetri.cbs.commons.svc.BusinessObjectValidationCapable;
import com.silverlakesymmetri.cbs.xps.bdo.sdo.SwfBicDirectoryQry;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.QSwfBicDirectoryQryJpe;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.SwfBicDirectoryQryJpe;
import com.silverlakesymmetri.cbs.xps.svc.SwfBicDirectoryQryService;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Map;

@Service
@Transactional
public class SwfBicDirectoryQryServiceImpl extends AbstractBusinessService<SwfBicDirectoryQry, SwfBicDirectoryQryJpe, String>
        implements SwfBicDirectoryQryService, BusinessObjectValidationCapable<SwfBicDirectoryQry> {

    @Override
    protected String getIdFromDataObjectInstance(SwfBicDirectoryQry dataObject) {
        return dataObject.getBic();
    }

    @Override
    protected EntityPath<SwfBicDirectoryQryJpe> getEntityPath() {
        return QSwfBicDirectoryQryJpe.swfBicDirectoryQryJpe;
    }

    @Override
    public List<SwfBicDirectoryQry> query(int offset, int resultLimit, String groupBy, String order,
                                          Map<String, Object> filters) {
        return super.query(offset, resultLimit, groupBy, order, filters);
    }

    @Override
    public List<SwfBicDirectoryQry> find(FindCriteria findCriteria, CbsHeader cbsHeader) {
        return super.find(findCriteria, cbsHeader);
    }
}
