package com.silverlakesymmetri.cbs.xps.svc.mapper.decorator;

import org.mapstruct.Context;
import org.mapstruct.MappingTarget;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

import com.silverlakesymmetri.cbs.commons.xmlapi.enums.CbsXmlApiOperation;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.MarginRefundWithSettlementJpe;
import com.silverlakesymmetri.cbs.xps.svc.mapper.MarginRefundWithSettlementServiceMapper;
import com.silverlakesymmetri.cbs.xps.xmlapi.XPSTRANMARGINREFUNDWITHSETTLEAPIType;

public abstract class MarginRefundWithSettlementServiceDecorator implements MarginRefundWithSettlementServiceMapper {
	
	@Autowired
	@Qualifier("delegate")
	protected MarginRefundWithSettlementServiceMapper delegate;

	@Override
	public XPSTRANMARGINREFUNDWITHSETTLEAPIType mapToApi(MarginRefundWithSettlementJpe jpe, @Context CbsXmlApiOperation oper){
		XPSTRANMARGINREFUNDWITHSETTLEAPIType req = (XPSTRANMARGINREFUNDWITHSETTLEAPIType) delegate.mapToApi(jpe, oper);
		return  req;
	}
	
	@Override
	public MarginRefundWithSettlementJpe mapToJpe(XPSTRANMARGINREFUNDWITHSETTLEAPIType api, @MappingTarget MarginRefundWithSettlementJpe jpe){
		delegate.mapToJpe(api, jpe);
		return jpe;
	}

}


