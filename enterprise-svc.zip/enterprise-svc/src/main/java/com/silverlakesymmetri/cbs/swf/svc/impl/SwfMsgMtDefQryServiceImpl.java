package com.silverlakesymmetri.cbs.swf.svc.impl;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Service;

import com.mysema.query.types.EntityPath;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.jpa.entity.FindCriteriaJpe;
import com.silverlakesymmetri.cbs.commons.svc.AbstractBusinessService;
import com.silverlakesymmetri.cbs.commons.svc.BusinessObjectValidationCapable;
import com.silverlakesymmetri.cbs.swf.bdo.sdo.SwfMsgMtDefQry;
import com.silverlakesymmetri.cbs.swf.jpa.mapping.sdo.SwfMsgMtDefQryJpe;
import com.silverlakesymmetri.cbs.swf.jpa.mapping.sdo.id.SwfMsgMtDefQryPk;
import com.silverlakesymmetri.cbs.swf.svc.SwfMsgMtDefQryService;
import com.silverlakesymmetri.cbs.swf.jpa.mapping.sdo.QSwfMsgMtDefQryJpe;

@Service
public class SwfMsgMtDefQryServiceImpl extends AbstractBusinessService<SwfMsgMtDefQry, SwfMsgMtDefQryJpe, SwfMsgMtDefQryPk> 
	implements SwfMsgMtDefQryService, BusinessObjectValidationCapable<SwfMsgMtDefQry>{

	@Override
	public Long count(FindCriteria findCriteria, CbsHeader cbsHeader) {
		if (findCriteria == null) {
            return dataService.getRowCount(this.getEntityPath());
        } else {
            FindCriteriaJpe fc = jaxbSdoHelper.unwrap(findCriteria);
            return dataService.getRowCount(SwfMsgMtDefQryJpe.class, fc);
        }
	}

	@Override
	protected SwfMsgMtDefQryPk getIdFromDataObjectInstance(SwfMsgMtDefQry dataObject) {
		SwfMsgMtDefQryPk key = new SwfMsgMtDefQryPk(dataObject.getMessageType());
		return key;
	}

	@Override
	protected EntityPath<SwfMsgMtDefQryJpe> getEntityPath() {
		return QSwfMsgMtDefQryJpe.swfMsgMtDefQryJpe;
	}
	
	@Override
    public SwfMsgMtDefQry get(SwfMsgMtDefQry objectInstanceIdentifier) {
        return super.get(objectInstanceIdentifier);
    }

    @Override
    public List<SwfMsgMtDefQry> query(int offset, int resultLimit, String groupBy, String order,
                                    Map<String, Object> filters) {
        return super.query(offset, resultLimit, groupBy, order, filters);
    }

    @Override
    public List<SwfMsgMtDefQry> find(FindCriteria findCriteria, CbsHeader cbsHeader) {
        return super.find(findCriteria, cbsHeader);
    }

    @Override
    public SwfMsgMtDefQry getByPk(String publicKey, SwfMsgMtDefQry reference) {
        return super.getByPk(publicKey, reference);
    }
	

}
