package com.silverlakesymmetri.cbs.gla.svc;

import java.util.List;
import java.util.Map;

import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation;
import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation.ServiceOperationType;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.svc.BusinessService;
import com.silverlakesymmetri.cbs.gla.bdo.sdo.GlChartAcctBalQry;
import com.silverlakesymmetri.cbs.gla.jpa.mapping.sdo.GlChartAcctBalQryJpe;

public interface GlChartAcctBalQryService extends BusinessService<GlChartAcctBalQry, GlChartAcctBalQryJpe> {

	public static final String SVC_OP_NAME_GLCHARTACCTBALQRYSERVICE_GET = "GlChartAcctBalQryService.get";
	public static final String SVC_OP_NAME_GLCHARTACCTBALQRYQRYSERVICE_FIND = "GlChartAcctBalQryService.find";
	public static final String SVC_OP_NAME_GLCHARTACCTBALQRYQRYSERVICE_QUERY = "GlChartAcctBalQryService.query";
	
	@ServiceOperation(name = SVC_OP_NAME_GLCHARTACCTBALQRYSERVICE_GET, type = ServiceOperationType.GET)
    public GlChartAcctBalQry getByPk(String publicKey, GlChartAcctBalQry reference);

    @ServiceOperation(name = SVC_OP_NAME_GLCHARTACCTBALQRYQRYSERVICE_FIND)
    public List<GlChartAcctBalQry> find(FindCriteria findCriteria, CbsHeader cbsHeader);
    
    @ServiceOperation(name = SVC_OP_NAME_GLCHARTACCTBALQRYQRYSERVICE_QUERY)
    public List<GlChartAcctBalQry> query(int offset, int resultLimit, String groupBy, String order, Map<String, Object> filters);
}
