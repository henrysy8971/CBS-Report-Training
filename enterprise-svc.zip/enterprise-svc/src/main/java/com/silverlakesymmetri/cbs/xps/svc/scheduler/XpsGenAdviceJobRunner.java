package com.silverlakesymmetri.cbs.xps.svc.scheduler;

import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.silverlakesymmetri.cbs.commons.exception.base.CbsRuntimeException;
import com.silverlakesymmetri.cbs.commons.logging.CbsAppLogger;
import com.silverlakesymmetri.cbs.commons.logging.CbsAppLoggerFactory;
import com.silverlakesymmetri.cbs.commons.svc.scheduler.BaseScheduledJobRunner;

@Component("xpsGenAdviceJobRunner")
@Transactional(propagation = Propagation.REQUIRES_NEW)
@Service
public class XpsGenAdviceJobRunner extends BaseScheduledJobRunner {
	private final CbsAppLogger logger = CbsAppLoggerFactory.getLogger(XpsGenAdviceJobRunner.class);
	private static final String ADVICE_GENERATION_JOB_NAME = "AnyModuleGenAdviceJob";

	@Override
	protected void executeInternal(JobExecutionContext context) throws JobExecutionException {
		super.executeInternal(context);
		//runJobs();
	}

	@Override
	protected void doJob() {
		// TODO: replace boolean runScheduledJobs and use a registry flag instead
		boolean runScheduledJobs = true;
		logger.info("Start running AnyModuleGenAdviceJob ...");
		if (runScheduledJobs) {
			//startTransaction();
			doAdviceGeneration();
		} else {
			logger.warn("Scheduled XPS jobs did not run!");
		}
	}

	private void doAdviceGeneration() {
		logger.info("Attempt to start job: {}", ADVICE_GENERATION_JOB_NAME);

		String params = super.getJobParams();
		try {
			jobMaintenanceService.startJobWithParam(ADVICE_GENERATION_JOB_NAME, params);
		} catch (CbsRuntimeException cbsEx) {
			if (JOB_WITH_FAILED_EXECUTION.equals(cbsEx.getErrorCode())) {
				try {
					jobMaintenanceService.startNewJobInstance(ADVICE_GENERATION_JOB_NAME);
				} catch (Exception restartEx) {
					logger.error("Start next instance of job failed: {}", ADVICE_GENERATION_JOB_NAME);
					restartEx.printStackTrace();
				}
			} else {
				logger.error("Job did not start: {}", ADVICE_GENERATION_JOB_NAME);
				cbsEx.printStackTrace();
			}
		} catch (ClassCastException ccex) {
			logger.warn("Cast exception encountered during start: {}", ccex.getMessage());
			ccex.printStackTrace();
		} catch (Exception e) {
			logger.error("Failed to start job: {}", ADVICE_GENERATION_JOB_NAME);
			e.printStackTrace();
		}
	}

}
