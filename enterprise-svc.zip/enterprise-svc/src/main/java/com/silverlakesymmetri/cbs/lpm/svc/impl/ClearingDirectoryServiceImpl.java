package com.silverlakesymmetri.cbs.lpm.svc.impl;

import com.mysema.query.types.EntityPath;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.context.CbsRuntimeContextManager;
import com.silverlakesymmetri.cbs.commons.logging.CbsAppLogger;
import com.silverlakesymmetri.cbs.commons.logging.annotation.Logger;
import com.silverlakesymmetri.cbs.commons.svc.AbstractBusinessService;
import com.silverlakesymmetri.cbs.commons.svc.CbsFileUploadCapable;
import com.silverlakesymmetri.cbs.commons.svc.util.FileUploadUtilImpl;
import com.silverlakesymmetri.cbs.lpm.bdo.sdo.ClearingDirectory;
import com.silverlakesymmetri.cbs.lpm.jpa.mapping.sdo.ClearingDirectoryJpe;
import com.silverlakesymmetri.cbs.lpm.jpa.mapping.sdo.QClearingDirectoryJpe;
import com.silverlakesymmetri.cbs.lpm.svc.ClearingDirectoryService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

@Service
@Transactional
public class ClearingDirectoryServiceImpl extends AbstractBusinessService<ClearingDirectory, ClearingDirectoryJpe, Long>
		implements ClearingDirectoryService, CbsFileUploadCapable<ClearingDirectory> {

	@Logger
	CbsAppLogger logger;

	@Autowired
	private FileUploadUtilImpl fileUploadUtility;

	@Autowired
	private CbsRuntimeContextManager cbsRuntimeContextManager;

	@Override
	protected Long getIdFromDataObjectInstance(ClearingDirectory bdo) {
		ClearingDirectoryJpe jpe = jaxbSdoHelper.unwrap(bdo);
		return jpe.getInternalKey();
	}

	@Override
	protected EntityPath<ClearingDirectoryJpe> getEntityPath() {
		 return QClearingDirectoryJpe.clearingDirectoryJpe;
	}

	@Override
	public List<ClearingDirectory> query(int offset, int resultLimit, String groupBy, String order,
												 Map<String, Object> filters) {
		return super.query(offset, resultLimit, groupBy, order, filters);
	}

	@Override
	public ClearingDirectory create(ClearingDirectory dataObject) {
		return super.create(dataObject);
	}

	@Override
	public ClearingDirectory update(ClearingDirectory dataObject) {
		return super.update(dataObject);
	}

	@Override
	public boolean delete(ClearingDirectory dataObject) {
		return super.delete(dataObject);
	}

	@Override
	public List<ClearingDirectory> find(FindCriteria findCriteria, CbsHeader cbsHeader) {
		return super.find(findCriteria, cbsHeader);
	}

	@Override
	public ClearingDirectory getByPk(String publicKey, ClearingDirectory reference) {
		return super.getByPk(publicKey, reference);
	}

	@Override
	public boolean bulkCreate(List<ClearingDirectory> bdoList) {
		validateBulkCreateList(bdoList);

		for (ClearingDirectory bdo: bdoList) {
			try {
				this.create(bdo);
			} catch (Exception e) {
				logger.error("Error encountered while processing jpe: {}", jaxbSdoHelper.unwrap(bdo), e);
				throw e;
			}
		}

		return true;
	}

	private void validateBulkCreateList(List<ClearingDirectory> bdoList) {
		// look for duplicate combination
		List<String> uniqueKeyString = new ArrayList<>();
		this.isDuplicatesOnList(uniqueKeyString, bdoList);
	}

	@Override
	public boolean isDuplicatesOnList(List<String> uniqueKeys, List<ClearingDirectory> list) {
		return false;
	}
}
