package com.silverlakesymmetri.cbs.xps.svc.impl;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import com.silverlakesymmetri.cbs.commons.jpa.extension.CbsOracle12Platform;
import com.silverlakesymmetri.cbs.commons.svc.CaseSensitivityOverrideCapable;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;

import com.mysema.query.types.EntityPath;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.helper.jpa.LinkTable;
import com.silverlakesymmetri.cbs.commons.helper.jpa.QueryCondition;
import com.silverlakesymmetri.cbs.commons.helper.jpa.QueryType;
import com.silverlakesymmetri.cbs.commons.jpa.entity.FindCriteriaJpe;
import com.silverlakesymmetri.cbs.commons.jpa.entity.ViewCriteriaItemJpe;
import com.silverlakesymmetri.cbs.commons.jpa.entity.ViewCriteriaRowJpe;
import com.silverlakesymmetri.cbs.commons.svc.AbstractBusinessService;
import com.silverlakesymmetri.cbs.commons.svc.BusinessObjectValidationCapable;
import com.silverlakesymmetri.cbs.mcl.bdo.sdo.Client;
import com.silverlakesymmetri.cbs.mcl.jpa.mapping.sdo.ClientJpe;
import com.silverlakesymmetri.cbs.xps.bdo.sdo.SettleDepAcctV;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.SettleDepAcctVJpe;
import com.silverlakesymmetri.cbs.xps.svc.SettleDepAcctVService;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.QSettleDepAcctVJpe;

@Service
public class SettleDepAcctVServiceImpl extends AbstractBusinessService<SettleDepAcctV, SettleDepAcctVJpe, Long>
        implements SettleDepAcctVService, BusinessObjectValidationCapable<SettleDepAcctV>, CaseSensitivityOverrideCapable {

    private static LinkedHashMap<String, LinkTable> constructorMap;
    private static QueryCondition queryCondition;
    private static final String OP_NOT_EQUAL = "!=";
    private static final String OP_LIKE = "LIKE";
    private static final String ATTR_CCY = "ccy";
    private static final String ATTR_DEPOSIT_TYPE = "depositType";

    static {
        constructorMap = new LinkedHashMap<String, LinkTable>();
        constructorMap.put("internalKey", new LinkTable(SettleDepAcctVJpe.class));
        constructorMap.put("clientId", new LinkTable(SettleDepAcctVJpe.class));
        constructorMap.put("clientNo", new LinkTable(ClientJpe.class));
        constructorMap.put("clientShort", new LinkTable(ClientJpe.class));
        constructorMap.put("clientName", new LinkTable(ClientJpe.class));
        constructorMap.put("acctNo", new LinkTable(SettleDepAcctVJpe.class));
        constructorMap.put("branch", new LinkTable(SettleDepAcctVJpe.class));
        constructorMap.put("ccy", new LinkTable(SettleDepAcctVJpe.class));
        constructorMap.put("acctDesc", new LinkTable(SettleDepAcctVJpe.class));
        constructorMap.put("depositType", new LinkTable(SettleDepAcctVJpe.class));
        
        queryCondition = new QueryCondition();
        queryCondition.where("clientId", QueryType.EQUALS, new LinkTable(ClientJpe.class, "clientId"));
    }

    @Override
    protected Long getIdFromDataObjectInstance(SettleDepAcctV dataObject) {
        SettleDepAcctVJpe jpe = jaxbSdoHelper.unwrap(dataObject);
        return jpe.getInternalKey();
    }

    @Override
    protected EntityPath<SettleDepAcctVJpe> getEntityPath() {
        return QSettleDepAcctVJpe.settleDepAcctVJpe;
    }

    @Override
    public List<SettleDepAcctV> query(int offset, int resultLimit, String groupBy, String order, Map<String, Object> filters) {
		try {
			CbsOracle12Platform.setUseNewOraclePaging(true);
			QueryCondition newCondition = convertFilters(queryCondition, filters, constructorMap);
			return super.query(newCondition, offset, resultLimit, groupBy, order, constructorMap);
		} finally {
			CbsOracle12Platform.setUseNewOraclePaging(false);
		}
    }

    @Override
    public List<SettleDepAcctV> find(FindCriteria findCriteria, CbsHeader cbsHeader) {
    	try {
			CbsOracle12Platform.setUseNewOraclePaging(true);
			return super.find(findCriteria, cbsHeader, constructorMap, queryCondition);
		} finally {
			CbsOracle12Platform.setUseNewOraclePaging(false);
		}
    }

    @Override
    public SettleDepAcctV getByPk(String publicKey, SettleDepAcctV reference) {
        return super.getByPk(publicKey, reference);
    }

    @Override
    public Long count(FindCriteria findCriteria, CbsHeader cbsHeader) {
        FindCriteriaJpe jpe = jaxbSdoHelper.unwrap(findCriteria, FindCriteriaJpe.class);
        return dataService.getRowCount(SettleDepAcctVJpe.class, jpe, constructorMap, queryCondition);
    }

	@Override
	public List<Client> findClients(FindCriteria fc, CbsHeader cbsHeader) {
		
		String qString = "SELECT NEW com.silverlakesymmetri.cbs.mcl.jpa.mapping.sdo.ClientJpe(c.clientNo, c.clientShort) "
				+ "FROM ClientJpe c "
				+ "WHERE EXISTS ( :settleV "
				+ ") and c.status <> 'C'";
		
		String settleV = "SELECT 1 "
				+ "FROM SettleDepAcctVJpe v "
				+ "WHERE v.clientId = c.clientId "
				+ "AND v.ccy = :ccy ";
			
		
		FindCriteriaJpe fcJpe = null;
		int limit = 10;
		int offset = 0;
		if(fc!=null){			
			fcJpe = jaxbSdoHelper.unwrap(fc);
			if(fcJpe.getFetchSize() > 0) {
				limit = fcJpe.getFetchSize();
			}
			offset = fcJpe.getFetchStart();
		}
		
		String ccyFilter = "v.ccy";
		if (fcJpe != null && fcJpe.getFilter() != null && fcJpe.getFilter().getGroup() != null
				&& !fcJpe.getFilter().getGroup().isEmpty()) {
			ViewCriteriaRowJpe row = fcJpe.getFilter().getGroup().get(0);
			for(ViewCriteriaItemJpe item: row.getItem()){
				if (StringUtils.isNotBlank(item.getAttribute()) && item.getValue() != null
						&& !item.getValue().isEmpty()) {
					if(ATTR_CCY.equals(item.getAttribute())){
						ccyFilter = "'" + item.getValue().get(0).toString() + "'";
						continue;
					}
					if(ATTR_DEPOSIT_TYPE.equals(item.getAttribute()) && OP_NOT_EQUAL.equals(item.getOperator()) ){
						settleV = settleV + "AND v." + item.getAttribute() + " " + OP_NOT_EQUAL + " '"
								+ item.getValue().get(0).toString() + "' "; 
						continue;
					}
					if(OP_NOT_EQUAL.equals(item.getOperator())){
						qString = qString + "AND c." + item.getAttribute() + " " + OP_NOT_EQUAL + " '"
								+ item.getValue().get(0).toString() + "' "; 
					}else{
						qString = qString + "AND c." + item.getAttribute() + " " + OP_LIKE + " '"
								+ item.getValue().get(0).toString() + "' ";
					}
				}
			}
		}

		qString = qString.replace(":settleV", settleV);
		qString = qString.replace(":ccy", ccyFilter);
		List<ClientJpe> findList = dataService.findWithQuery(qString, offset, limit, ClientJpe.class);
		
		List<Client> retList = new ArrayList<>();
		for(ClientJpe jpe: findList){
			retList.add(jaxbSdoHelper.wrap(jpe));
		}
		
		return retList;
	}

	@Override
	public String[] getOverrideFields() {
		return new String[] {"clientNo", "acctNo", "ccy"};
	}

	@Override
	public boolean isUpperCaseCompare() {
		return false;
	}
}
