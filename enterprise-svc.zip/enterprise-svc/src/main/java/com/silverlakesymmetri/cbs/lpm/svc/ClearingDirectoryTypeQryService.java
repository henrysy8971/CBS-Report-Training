package com.silverlakesymmetri.cbs.lpm.svc;


import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation;
import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation.ServiceOperationType;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.svc.BusinessService;
import com.silverlakesymmetri.cbs.lpm.bdo.sdo.ClearingDirectoryTypeQry;
import com.silverlakesymmetri.cbs.lpm.jpa.mapping.sdo.ClearingDirectoryTypeQryJpe;

import java.util.List;
import java.util.Map;

public interface ClearingDirectoryTypeQryService extends BusinessService<ClearingDirectoryTypeQry, ClearingDirectoryTypeQryJpe> {

    public static final String SVC_OP_NAME_CLEARING_DIRECTORY_TYPE_QRY_SERVICE_GET = "ClearingDirectoryTypeQryService.get";
    public static final String SVC_OP_NAME_CLEARING_DIRECTORY_TYPE_QRY_SERVICE_QUERY = "ClearingDirectoryTypeQryService.query";
    public static final String SVC_OP_NAME_CLEARING_DIRECTORY_TYPE_QRY_SERVICE_FIND = "ClearingDirectoryTypeQryService.find";

    @ServiceOperation(name = SVC_OP_NAME_CLEARING_DIRECTORY_TYPE_QRY_SERVICE_GET, type = ServiceOperationType.GET)
    public ClearingDirectoryTypeQry getByPk(String publicKey, ClearingDirectoryTypeQry reference);

    @ServiceOperation(name = SVC_OP_NAME_CLEARING_DIRECTORY_TYPE_QRY_SERVICE_QUERY)
    public List<ClearingDirectoryTypeQry> query(int offset, int resultLimit, String groupBy, String order, Map<String, Object> filters);

    @ServiceOperation(name = SVC_OP_NAME_CLEARING_DIRECTORY_TYPE_QRY_SERVICE_FIND)
    public List<ClearingDirectoryTypeQry> find(FindCriteria findCriteria, CbsHeader cbsHeader);

}
