package com.silverlakesymmetri.cbs.xps.svc.mapper.mapping;

import org.mapstruct.Context;
import org.mapstruct.InheritInverseConfiguration;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingTarget;
import org.mapstruct.Mappings;

import com.silverlakesymmetri.cbs.commons.xmlapi.enums.CbsXmlApiOperation;
import com.silverlakesymmetri.cbs.swf.jpa.mapping.sdo.SwfMt200Jpe;
import com.silverlakesymmetri.cbs.swf.svc.mapper.mapping.SwfF13Mapper;
import com.silverlakesymmetri.cbs.swf.svc.mapper.mapping.SwfF23Mapper;
import com.silverlakesymmetri.cbs.swf.svc.mapper.mapping.SwfF26Mapper;
import com.silverlakesymmetri.cbs.swf.svc.mapper.mapping.SwfF50Mapper;
import com.silverlakesymmetri.cbs.swf.svc.mapper.mapping.SwfF51Mapper;
import com.silverlakesymmetri.cbs.swf.svc.mapper.mapping.SwfF52Mapper;
import com.silverlakesymmetri.cbs.swf.svc.mapper.mapping.SwfF53Mapper;
import com.silverlakesymmetri.cbs.swf.svc.mapper.mapping.SwfF54Mapper;
import com.silverlakesymmetri.cbs.swf.svc.mapper.mapping.SwfF55Mapper;
import com.silverlakesymmetri.cbs.swf.svc.mapper.mapping.SwfF56Mapper;
import com.silverlakesymmetri.cbs.swf.svc.mapper.mapping.SwfF57Mapper;
import com.silverlakesymmetri.cbs.swf.svc.mapper.mapping.SwfF58Mapper;
import com.silverlakesymmetri.cbs.swf.svc.mapper.mapping.SwfF59Mapper;
import com.silverlakesymmetri.cbs.swf.svc.mapper.mapping.SwfF70Mapper;
import com.silverlakesymmetri.cbs.swf.svc.mapper.mapping.SwfF71Mapper;
import com.silverlakesymmetri.cbs.swf.svc.mapper.mapping.SwfF72Mapper;
import com.silverlakesymmetri.cbs.swf.svc.mapper.mapping.SwfF77Mapper;
import com.silverlakesymmetri.cbs.xps.xmlapi.XPSSWFSETTLEAPIType;

@Mapper(uses = {
		SwfF13Mapper.class,
		SwfF23Mapper.class,
		SwfF26Mapper.class,
		SwfF50Mapper.class,
		SwfF51Mapper.class,
		SwfF52Mapper.class,
		SwfF53Mapper.class,
		SwfF54Mapper.class,
		SwfF55Mapper.class,
		SwfF56Mapper.class,
		SwfF57Mapper.class,
		SwfF58Mapper.class,
		SwfF59Mapper.class,
		SwfF70Mapper.class,
		SwfF71Mapper.class,
		SwfF72Mapper.class,
		SwfF77Mapper.class,
		//SWFCOVERMESSAGETYPE
})
//@DecoratedWith(SettlePayToLNDDDSETTLEPAYAPITypeDecorator.class)
public interface SwfMt200ToXPSSWFSETTLEAPITypeMapper {
	@Mappings({
		//@Mapping(target ="TECHNICALINFO", ignore = true),
		@Mapping(target ="INTERNALKEY", ignore = true),
//	    @Mapping(source="timeIndicationStructList", target ="TIMEINDICATION.SWFF13TYPE"),
	    //@Mapping(source="transferAmountStructRec", target =""),
//	    @Mapping(source="orderingInstitutionStructRec", target ="ORDERINGINSTITUTION"),
	    @Mapping(source="sendersCorrespondentStructRec", target ="SENDERSCORRESPONDENT"),
//	    @Mapping(source="receiversCorrespondentStructRec", target ="RECEIVERSCORRESPONDENT"),
	    @Mapping(source="intermediaryInstitutionStructRec", target ="INTERMEDIARYINSTITUTION"),
	    @Mapping(source="acctWithInstitutionStructRec", target ="ACCTWITHINSTITUTION"),
//	    @Mapping(source="beneficiaryInstitutionStructRec", target ="BENEFICIARYINSTITUTION"),
	    @Mapping(source="senderToReceiverInfoStructRec", target ="SENDERTORECEIVERINFO"),
	    //
	    @Mapping(target ="BANKOPERATIONCODE", ignore=true),
	    @Mapping(target ="INSTRUCTIONCODE.SWFF23TYPE", ignore=true),
	    @Mapping(target ="TRANTYPECODE", ignore=true),
	    @Mapping(target ="ORDERINGCUSTOMER", ignore=true),
	    @Mapping(target ="SENDINGINSTITUTION", ignore=true),
	    @Mapping(target ="THIRDREIMBINSTITUTION", ignore=true),
	    @Mapping(target ="BENEFICIARYCUSTOMER", ignore=true),
	    @Mapping(target ="REMITTANCEINFO", ignore=true),
	    @Mapping(target ="DETAILSOFCHARGES", ignore=true),
	    @Mapping(target ="REGULATORYREPORTING", ignore=true),
		@Mapping(target ="RECEIVERCHARGES", ignore = true),
		@Mapping(target ="SENDERCHARGES", ignore = true),
		@Mapping(target ="COVERMESSAGEDETAILS", ignore = true),
	})
	XPSSWFSETTLEAPIType mapToApi(SwfMt200Jpe jpe, @Context CbsXmlApiOperation oper);
	
	@InheritInverseConfiguration(name="mapToApi")
	@Mappings({
		@Mapping(target ="transferAmountStructRec", ignore=true),
//	    @Mapping(target="timeIndicationStructList", source="TIMEINDICATION.SWFF13TYPE")
	})
	SwfMt200Jpe mapToJpe(XPSSWFSETTLEAPIType api, @MappingTarget SwfMt200Jpe jpe);
}
