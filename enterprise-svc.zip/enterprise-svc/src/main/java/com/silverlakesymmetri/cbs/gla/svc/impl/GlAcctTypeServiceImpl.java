package com.silverlakesymmetri.cbs.gla.svc.impl;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.mysema.query.types.EntityPath;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.svc.AbstractBusinessService;
import com.silverlakesymmetri.cbs.gla.bdo.sdo.GlAcctType;
import com.silverlakesymmetri.cbs.gla.jpa.mapping.sdo.GlAcctTypeJpe;
import com.silverlakesymmetri.cbs.gla.jpa.mapping.sdo.QGlAcctTypeJpe;
import com.silverlakesymmetri.cbs.gla.svc.GlAcctTypeService;

@Service
@Transactional
public class GlAcctTypeServiceImpl extends AbstractBusinessService<GlAcctType, GlAcctTypeJpe, String> implements GlAcctTypeService{

	@Override
	protected String getIdFromDataObjectInstance(GlAcctType dataObject) {
		return dataObject.getAcctType();
	}

	@Override
	protected EntityPath<GlAcctTypeJpe> getEntityPath() {
		return QGlAcctTypeJpe.glAcctTypeJpe;
	}

	@Override
	public GlAcctType create(GlAcctType dataObject) {

		return super.create(dataObject);
	}

	@Override
	protected GlAcctType preCreateValidation(GlAcctType dataObject) {
		performDefaulting(dataObject);
		return super.preCreateValidation(dataObject);
	}
	
	@Override
	protected GlAcctType preUpdateValidation(GlAcctType dataObject) {
		return super.preUpdateValidation(dataObject);
	}

	private void performDefaulting(GlAcctType goodsType) {
		if (null != goodsType) {
			if (null == goodsType.isUsedYn()) {
			    goodsType.setUsedYn(false);
			}

			if (null == goodsType.isActiveYn()) {
			    goodsType.setActiveYn(false);
			}
		}
	}
	
	@Override
	public GlAcctType get(GlAcctType objectInstanceIdentifier) {
		return super.get(objectInstanceIdentifier);
	}

	@Override
	public List<GlAcctType> query(int offset, int resultLimit, String groupBy, String order,
			Map<String, Object> filters) {
		return super.query(offset, resultLimit, groupBy, order, filters);
	}

	@Override
	public GlAcctType update(GlAcctType dataObject) {
		return super.update(dataObject);
	}

	@Override
	public boolean delete(GlAcctType dataObject) {
		return super.delete(dataObject);
	}

	@Override
	public List<GlAcctType> find(FindCriteria findCriteria, CbsHeader cbsHeader) {
		return super.find(findCriteria, cbsHeader);
	}

	@Override
	public GlAcctType getByPk(String publicKey, GlAcctType reference) {
		return super.getByPk(publicKey, reference);
	}

}
