package com.silverlakesymmetri.cbs.swf.svc.mapper.mapping;

import org.mapstruct.InheritInverseConfiguration;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Mappings;

import com.silverlakesymmetri.cbs.swf.jpa.mapping.sdo.SwfF74NarrativeJpe;
import com.silverlakesymmetri.cbs.swf.xmlapi.SWFF74NARRATIVETYPEType;

@Mapper()
public interface SwfF74NarrativeMapper {
	@Mappings({
		@Mapping(source="index", target="INDEX"),
		@Mapping(source="code", target="CODE"),
		@Mapping(source="narrative", target="NARRATIVE")
	})
	SWFF74NARRATIVETYPEType mapToApi(SwfF74NarrativeJpe jpe);
	
	@InheritInverseConfiguration(name = "mapToApi")
	SwfF74NarrativeJpe mapToJpe(SWFF74NARRATIVETYPEType api);

}