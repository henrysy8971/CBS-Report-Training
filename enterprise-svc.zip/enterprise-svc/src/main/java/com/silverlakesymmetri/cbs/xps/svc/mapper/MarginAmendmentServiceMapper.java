package com.silverlakesymmetri.cbs.xps.svc.mapper;

import org.mapstruct.Context;
import org.mapstruct.InheritInverseConfiguration;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingTarget;
import org.mapstruct.Mappings;

import com.silverlakesymmetri.cbs.commons.jpa.util.DateTimeHelper;
import com.silverlakesymmetri.cbs.commons.xmlapi.enums.CbsXmlApiOperation;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.MarginAmendmentJpe;
import com.silverlakesymmetri.cbs.xps.svc.mapper.mapping.XpsMessageJpeToXPSMESSAGETYPETypeMapper;
import com.silverlakesymmetri.cbs.xps.xmlapi.XPSTRANMARGINAMENDMENTAPIType;

@Mapper(uses={ DateTimeHelper.class, XpsMessageJpeToXPSMESSAGETYPETypeMapper.class })
public interface MarginAmendmentServiceMapper {
	@Mappings({
		@Mapping(expression = "java(oper != null ? oper.getOperation() : null)", target="OPERATION"),
		@Mapping(source="internalKey", target = "INTERNALKEY"),
		@Mapping(source="marginInternalKey", target = "MARGININTERNALKEY"),
		@Mapping(source="seqNo", target = "SEQNO"),
		@Mapping(source="valueDate", target = "VALUEDATE", qualifiedByName = {"DateTimeHelper", "convertDateToCbsXmlApiDate"}),
		@Mapping(source="tranStatus", target = "TRANSTATUS"),
		@Mapping(source="incrDecrInd", target = "INCRDECRIND"),
		@Mapping(source="tranEquivAmt", target = "TRANEQUIVAMT"),
		@Mapping(source="exchRate", target = "EXCHRATE"),
		@Mapping(source="exchQuote", target = "EXCHQUOTE"),
		@Mapping(source="amount", target = "AMOUNT"),
		@Mapping(source="baseRate", target = "BASERATE"),
		@Mapping(source="baseQuote", target = "BASEQUOTE"),
		@Mapping(source="baseEquiv", target = "BASEEQUIV"),
		@Mapping(source="localRate", target = "LOCALRATE"),
		@Mapping(source="localQuote", target = "LOCALQUOTE"),
		@Mapping(source="localEquiv", target = "LOCALEQUIV"),
		@Mapping(source="messageStructList", target = "MESSAGELIST.XPSMESSAGETYPE"),
		@Mapping(source="oldTranEquivAmt", target = "OLDAMOUNT"),
		@Mapping(source="oldAmount", target = "OLDTRANEQUIVAMT"),
	})
	public XPSTRANMARGINAMENDMENTAPIType mapToApi(MarginAmendmentJpe jpe, @Context CbsXmlApiOperation oper);
	
	@InheritInverseConfiguration(name = "mapToApi")
	@Mappings({
		@Mapping(source="VALUEDATE", target="valueDate", qualifiedByName = {"DateTimeHelper", "convertCbsApiDateToString"})
	})
	public MarginAmendmentJpe mapToJpe(XPSTRANMARGINAMENDMENTAPIType api, @MappingTarget MarginAmendmentJpe jpe);
}
