package com.silverlakesymmetri.cbs.swf.svc.mapper.decorator;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

import com.silverlakesymmetri.cbs.swf.jpa.mapping.sdo.SwfF13Jpe;
import com.silverlakesymmetri.cbs.swf.svc.mapper.mapping.SwfF13Mapper;
import com.silverlakesymmetri.cbs.swf.xmlapi.SWFF13TYPEType;

public abstract class SwfF13MapperDecorator extends SwfF13Mapper {
	
	@Autowired
	@Qualifier("delegate")
	protected SwfF13Mapper delegate;

	@Override
	public SWFF13TYPEType mapToApi(SwfF13Jpe jpe){
		SWFF13TYPEType swfF13 = delegate.mapToApi(jpe);
		if(swfF13 != null && swfF13.getCODE() == null && swfF13.getTIMEIND() == null){
			return null;
		}
		return swfF13;
	}
	
	@Override
	public SwfF13Jpe mapToJpe(SWFF13TYPEType api){
		return delegate.mapToJpe(api);
	}
	
}
