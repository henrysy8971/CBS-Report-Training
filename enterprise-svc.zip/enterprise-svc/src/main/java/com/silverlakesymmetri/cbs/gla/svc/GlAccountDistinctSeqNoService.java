package com.silverlakesymmetri.cbs.gla.svc;

import java.util.List;
import java.util.Map;

import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation;
import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation.ServiceOperationType;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.svc.BusinessService;
import com.silverlakesymmetri.cbs.gla.bdo.sdo.GlAccount;
import com.silverlakesymmetri.cbs.gla.jpa.mapping.sdo.GlAccountJpe;

public interface GlAccountDistinctSeqNoService extends BusinessService<GlAccount, GlAccountJpe>{
	public static final String SVC_OP_NAME_GLACCOUNTSERVICE_FIND = "GlAccountDistinctSeqNoService.find";
	public static final String SVC_OP_NAME_GLACCOUNTSERVICE_QUERY = "GlAccountDistinctSeqNoService.query";
	
	@ServiceOperation(name = SVC_OP_NAME_GLACCOUNTSERVICE_FIND)
	public List<GlAccount> find(FindCriteria findCriteria, CbsHeader cbsHeader);
	
	//@ServiceOperation(name = SVC_OP_NAME_GLACCOUNTSERVICE_QUERY)
	//public List<GlAccount> query(int offset, int resultLimit, String groupBy, String order, Map<String, Object> filters);

	@ServiceOperation(name = SVC_OP_NAME_GLACCOUNTSERVICE_QUERY)
	public List<GlAccount> query(int offset, int resultLimit, String groupBy, String order, Map<String, Object> filters);

}