package com.silverlakesymmetri.cbs.swf.svc.mapper.mapping;

import org.mapstruct.Named;
import org.springframework.stereotype.Component;

@Component
@Named("SwiftMapperHelper")
public class SwiftMapperHelper {
	private static final String F_OPTION = "F";
	private static final String F1_OPTION = "F1";
	private static final String F2_OPTION = "F2";
	
	@Named("resolveFOption")
	public String resolveFOption(String option) {
		if (F1_OPTION.equals(option)) { return F_OPTION; }
		if (F2_OPTION.equals(option)) { return F_OPTION; }
		
		return option;

	}
}
