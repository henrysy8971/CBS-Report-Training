package com.silverlakesymmetri.cbs.xps.svc.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.inject.Inject;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mysema.query.types.EntityPath;
import com.silverlakesymmetri.cbs.commons.restlet.JsonConvertionManager;
import com.silverlakesymmetri.cbs.commons.svc.AbstractXmlApiBusinessService;
import com.silverlakesymmetri.cbs.commons.xmlapi.enums.CbsXmlApiOperation;
import com.silverlakesymmetri.cbs.xps.bdo.sdo.ChargeDetails;
import com.silverlakesymmetri.cbs.xps.bdo.sdo.ChargeMaster;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.ChargeMasterJpe;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.QChargeMasterJpe;
import com.silverlakesymmetri.cbs.xps.svc.ChargeRecalculateSlabService;
import com.silverlakesymmetri.cbs.xps.svc.mapper.ChargeRecalculateSlabServiceMapper;
import com.silverlakesymmetri.cbs.xps.xmlapi.XPSCHARGERECALCULATESLABAPIType;

@Service
public class ChargeRecalculateSlabServiceImpl extends AbstractXmlApiBusinessService<ChargeMaster, ChargeMasterJpe, Long, XPSCHARGERECALCULATESLABAPIType, XPSCHARGERECALCULATESLABAPIType> implements ChargeRecalculateSlabService {

    @Autowired
    private ChargeRecalculateSlabServiceMapper mapper;
	
    @Inject
    protected JsonConvertionManager jsonConversionMngr;
    
    private Double slabIndex;

    public ChargeMaster preCreateValidation(ChargeMaster dataObject) {
    	return super.preCreateValidation(dataObject);
    }

    @Override
    public ChargeMaster create(ChargeMaster dataObject) {
        return super.create(dataObject);
    }

    @Override
    protected XPSCHARGERECALCULATESLABAPIType transformBdoToXmlApiRqCreate(ChargeMaster dataObject) {
        return transformBdoToXmlApiType(dataObject, CbsXmlApiOperation.INSERT);
    }

    @Override
    protected XPSCHARGERECALCULATESLABAPIType transformBdoToXmlApiRqUpdate(ChargeMaster dataObject) {
        return null;
    }

    @Override
    protected XPSCHARGERECALCULATESLABAPIType transformBdoToXmlApiRqDelete(ChargeMaster dataObject) {
        return null;
    }

    private XPSCHARGERECALCULATESLABAPIType transformBdoToXmlApiType(ChargeMaster dataObject, CbsXmlApiOperation oper) {
    	ChargeMasterJpe jpe = jaxbSdoHelper.unwrap(dataObject);
    	XPSCHARGERECALCULATESLABAPIType api = mapper.mapToApi(jpe, oper);
    	api.setSEQNO(slabIndex);
    	api.setOPERATION("PROCESS_GENERIC");
        return api;
    }

    @Override
    protected Map<String, String> executeStoredProcedure(String xmlApiReq, String xmlHeaderIn) {
		String processAuthorizeOperation = "XPS_CHARGE_RECALCULATE_SLAB_API OPERATION=\"PROCESS_GENERIC\"";
		String xmlApiReqProcess = xmlApiReq.replaceAll(
				"XPS_CHARGE_RECALCULATE_SLAB_API=\"(INSERT|UPDATE|DELETE|DO_PROCESS)\"", processAuthorizeOperation);
        return super.executeStoredProcedure(xmlApiReqProcess, xmlHeaderIn);
    }

    @Override
    protected ChargeMaster processXmlApiRs(ChargeMaster dataObject, XPSCHARGERECALCULATESLABAPIType xmlApiRs) {
    	ChargeMasterJpe jpe = jaxbSdoHelper.unwrap(dataObject);
        jpe = mapper.mapToJpe(xmlApiRs, jpe);
        return jaxbSdoHelper.wrap(jpe);
    }

    @Override
    protected List<ChargeMaster> processXmlApiListRs(ChargeMaster dataObject, XPSCHARGERECALCULATESLABAPIType xmlApiRs) {
        return null;
    }

    @Override
    protected Class<XPSCHARGERECALCULATESLABAPIType> getXmlApiResponseClass() {
        return XPSCHARGERECALCULATESLABAPIType.class;
    }

    @Override
    protected Long getIdFromDataObjectInstance(ChargeMaster dataObject) {
        return dataObject.getInternalKey();
    }

    @Override
    protected EntityPath<ChargeMasterJpe> getEntityPath() {
        return QChargeMasterJpe.chargeMasterJpe;
    }

	@Override
	public ChargeDetails recalculateSlab(Map<String, Object> params) {
		ChargeMaster master = jsonConversionMngr.convertToType(params.get("master"), ChargeMaster.class, null, null);
		ChargeDetails detail = jsonConversionMngr.convertToType(params.get("detail"), ChargeDetails.class, null, null);
		this.slabIndex = Double.parseDouble(params.get("slabIndex").toString());
		
		master.setChargeDetailsList(new ArrayList<ChargeDetails>());
		master.getChargeDetailsList().add(detail);
		
		ChargeMaster response = this.createDataObject(master);
		ChargeDetails result = null;
		if(response != null && response.getChargeDetailsList() != null && response.getChargeDetailsList().size() > 0){
			result = response.getChargeDetailsList().get(0);
		}
		
		return result;
	}
	
	@Override
	protected ChargeMaster preCreateObject(ChargeMaster dataObject) {
		return dataObject;
	}
    

}
