package com.silverlakesymmetri.cbs.xps.svc;

import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation;
import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation.ServiceOperationType;
import com.silverlakesymmetri.cbs.commons.svc.BusinessService;
import com.silverlakesymmetri.cbs.mcl.bdo.sdo.Client;
import com.silverlakesymmetri.cbs.mcl.jpa.mapping.sdo.ClientJpe;

public interface DepAcctClientIndService extends BusinessService<Client, ClientJpe> {
	
    public static final String SVC_OP_NAME_DEPACCTCLIENTSERVICE_UPDCLIENTACCT = "DepAcctClientIndService.updClientAcct";

    @ServiceOperation(name = SVC_OP_NAME_DEPACCTCLIENTSERVICE_UPDCLIENTACCT,  type = ServiceOperationType.EXECUTE)
    public Client updClientAcct(Client dataObject);

}
