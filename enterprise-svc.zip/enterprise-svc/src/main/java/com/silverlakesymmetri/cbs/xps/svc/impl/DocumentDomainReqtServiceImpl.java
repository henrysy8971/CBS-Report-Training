package com.silverlakesymmetri.cbs.xps.svc.impl;

import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.mysema.query.types.EntityPath;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.jpa.mapping.sdo.RefCodeHdrJpe;
import com.silverlakesymmetri.cbs.commons.jpa.mapping.sdo.util.JpeConstants;
import com.silverlakesymmetri.cbs.commons.svc.AbstractBusinessService;
import com.silverlakesymmetri.cbs.commons.svc.BusinessObjectValidationCapable;
import com.silverlakesymmetri.cbs.xps.bdo.sdo.DocumentDomainReqt;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.DocumentDomainReqtJpe;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.QDocumentDomainReqtJpe;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.id.DocumentDomainReqtPk;
import com.silverlakesymmetri.cbs.xps.svc.DocumentDomainReqtService;

@Service
@Transactional
public class DocumentDomainReqtServiceImpl
		extends AbstractBusinessService<DocumentDomainReqt, DocumentDomainReqtJpe, DocumentDomainReqtPk>
		implements DocumentDomainReqtService, BusinessObjectValidationCapable<DocumentDomainReqt> {

	@Override
	protected DocumentDomainReqtPk getIdFromDataObjectInstance(DocumentDomainReqt dataObject) {
		return new DocumentDomainReqtPk(dataObject.getModuleRefDomain(), dataObject.getRefDomain(),
				dataObject.getRefDomainKey(), dataObject.getDocumentType());
	}

	@Override
	protected EntityPath<DocumentDomainReqtJpe> getEntityPath() {
		return QDocumentDomainReqtJpe.documentDomainReqtJpe;
	}

	@Override
	public DocumentDomainReqt getByPk(String publicKey, DocumentDomainReqt reference) {
		DocumentDomainReqt bdo = super.getByPk(publicKey, reference);
		if (bdo != null) {
			bdo.setDocumentTypeDesc(getDocumentTypeDesc(bdo.getDocumentType()));
		}
		return bdo;
	}

	@Override
	public List<DocumentDomainReqt> query(int offset, int resultLimit, String groupBy, String order,
			Map<String, Object> filters) {
		List<DocumentDomainReqt> bdoList = super.query(offset, resultLimit, groupBy, order, filters);
		if (bdoList != null) {
			for (DocumentDomainReqt bdo : bdoList) {
				bdo.setDocumentTypeDesc(getDocumentTypeDesc(bdo.getDocumentType()));
			}
		}
		return bdoList != null ? bdoList : Collections.emptyList();
	}

	@Override
	public List<DocumentDomainReqt> find(FindCriteria findCriteria, CbsHeader cbsHeader) {
		List<DocumentDomainReqt> bdoList = super.find(findCriteria, cbsHeader);
		if (bdoList != null) {
			for (DocumentDomainReqt bdo : bdoList) {
				bdo.setDocumentTypeDesc(getDocumentTypeDesc(bdo.getDocumentType()));
			}
		}
		return bdoList != null ? bdoList : Collections.emptyList();
	}

	@Override
	public DocumentDomainReqt create(DocumentDomainReqt dataObject) {
		return super.create(dataObject);
	}

	@Override
	public DocumentDomainReqt update(DocumentDomainReqt dataObject) {
		return super.update(dataObject);
	}

	@Override
	public boolean delete(DocumentDomainReqt dataObject) {
		return super.delete(dataObject);
	}

	private String getDocumentTypeDesc(String documentType) {
		if (!StringUtils.isBlank(documentType)) {
			Map<String, Object> params = new HashMap<>();
			params.put("metaCode", "Document.documentType");
			params.put("rowKey", documentType);
			List<RefCodeHdrJpe> refCodeList = dataService
					.findWithNamedQuery(JpeConstants.REF_CODE_HDR_JPE_GET_DESCRIPTION, params, RefCodeHdrJpe.class);
			if (refCodeList != null && !refCodeList.isEmpty()) {
				return refCodeList.get(0).getValueDesc();
			}
		}
		return null;
	}

}
