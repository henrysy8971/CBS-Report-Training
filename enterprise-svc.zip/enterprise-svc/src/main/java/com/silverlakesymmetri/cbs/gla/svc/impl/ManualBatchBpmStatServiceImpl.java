package com.silverlakesymmetri.cbs.gla.svc.impl;

import com.mysema.query.types.EntityPath;
import com.silverlakesymmetri.cbs.commons.bdo.sdo.BpmWorkItem;
import com.silverlakesymmetri.cbs.commons.bpm.constants.BpmConstants;
import com.silverlakesymmetri.cbs.commons.bpm.svc.BpmService;
import com.silverlakesymmetri.cbs.commons.context.CbsSessionContext;
import com.silverlakesymmetri.cbs.commons.exception.base.CbsServiceProcessException;
import com.silverlakesymmetri.cbs.commons.exception.base.helper.ExceptionHelper;
import com.silverlakesymmetri.cbs.commons.jpa.extension.JaxbSdoHelper;
import com.silverlakesymmetri.cbs.commons.jpa.util.DateTimeHelper;
import com.silverlakesymmetri.cbs.commons.svc.AbstractBusinessService;
import com.silverlakesymmetri.cbs.commons.svc.context.CbsRuntimeContextManager;
import com.silverlakesymmetri.cbs.commons.util.MessageUtils;
import com.silverlakesymmetri.cbs.gla.bdo.sdo.ManualBatchBpmStat;
import com.silverlakesymmetri.cbs.gla.bdo.sdo.ManualBatchBpmStatNameCount;
import com.silverlakesymmetri.cbs.gla.jpa.mapping.sdo.ManualBatchHdrJpe;
import com.silverlakesymmetri.cbs.gla.svc.ManualBatchBpmStatService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Created by Emerson.Sanchez on 20/12/2022.
 */
@Service
public class ManualBatchBpmStatServiceImpl implements ManualBatchBpmStatService {
    private static final String MANUAL_BATCH_SERVICE = "manualBatchService.create";
    private static final String ROLE = "ROLE";
    private static final String VALUE_DATE_FROM = "valueDateFrom";
    private static final String VALUE_DATE_TO = "valueDateTo";
    private static final String BATCH_DATE_FROM = "batchDateFrom";
    private static final String BATCH_DATE_TO = "batchDateTo";
    private static final String MUST_BE_CURRENT_MONTH = "CBS.B.GLA.MUST.BE.CURRENT.MONTH";

    private JaxbSdoHelper jaxbSdoHelper;

    private CbsRuntimeContextManager cbsRuntimeContextManager;

    @Autowired
    private BpmService bpmService;

    @Autowired
    protected DateTimeHelper dateTimeHelper;

    @Autowired(required = true)
    protected MessageUtils messageUtils;


    @Autowired
    public void setJaxbSdoHelper(JaxbSdoHelper jaxbSdoHelper) {
        this.jaxbSdoHelper = jaxbSdoHelper;
    }

    @Autowired
    public void setCbsRuntimeContextManager(CbsRuntimeContextManager cbsRuntimeContextManager) {
        this.cbsRuntimeContextManager = cbsRuntimeContextManager;
    }

    @Override
    public ManualBatchBpmStat getUnapproved() {
        CbsSessionContext sessionCtx = cbsRuntimeContextManager.getContext(CbsSessionContext.class);
        List<BpmWorkItem> list = bpmService.getUnapprovedByServiceOperationAndBranch(MANUAL_BATCH_SERVICE,
                sessionCtx.getBranch());
        List<ManualBatchBpmStatNameCount> unapprovedPerMaker = new ArrayList<>();
        List<ManualBatchBpmStatNameCount> unapprovedPerAuthorizer = new ArrayList<>();
        Map<String, Integer> makerMap = new HashMap<>();
        Map<String, Integer> authorizerMap = new HashMap<>();
        int unassignedCount = 0;
        int totalUnapproved = 0;
        if(list != null) {
            totalUnapproved = list.size();
            for (BpmWorkItem bpmWorkItem : list) {
                /**
                 * Maker
                 */
                if (!makerMap.containsKey(bpmWorkItem.getCreatedBy())) {
                    makerMap.put(bpmWorkItem.getCreatedBy(), 1);
                } else {
                    Integer count = makerMap.get(bpmWorkItem.getCreatedBy());
                    makerMap.put(bpmWorkItem.getCreatedBy(), ++count);
                }
                /**
                 * Authorizer
                 */
                boolean assignedWorkItem = ROLE.equals(bpmWorkItem.getParticipantType()) &&
                        bpmWorkItem.getCurrentUser() != null;
                if (assignedWorkItem) {
                    if (!authorizerMap.containsKey(bpmWorkItem.getCurrentUser())) {
                        authorizerMap.put(bpmWorkItem.getCurrentUser(), 1);
                    } else {
                        Integer count = authorizerMap.get(bpmWorkItem.getCurrentUser());
                        authorizerMap.put(bpmWorkItem.getCurrentUser(), ++count);
                    }
                } else {
                    unassignedCount++;
                }
            }

            for (String maker : makerMap.keySet()) {
                ManualBatchBpmStatNameCount stat = jaxbSdoHelper.createSdoInstance(ManualBatchBpmStatNameCount.class);
                stat.setName(maker);
                stat.setCount(makerMap.get(maker));
                unapprovedPerMaker.add(stat);
            }

            for (String authorizer : authorizerMap.keySet()) {
                ManualBatchBpmStatNameCount stat = jaxbSdoHelper.createSdoInstance(ManualBatchBpmStatNameCount.class);
                stat.setName(authorizer);
                stat.setCount(authorizerMap.get(authorizer));
                unapprovedPerAuthorizer.add(stat);
            }
        }

        ManualBatchBpmStat result = jaxbSdoHelper.createSdoInstance(ManualBatchBpmStat.class);
        result.setTotalUnapproved(totalUnapproved);
        result.setTotalUnapprovedUnassigned(unassignedCount);
        result.setTotalUnapprovedPerMaker(unapprovedPerMaker);
        result.setTotalUnapprovedPerAuthorizer(unapprovedPerAuthorizer);
        return result;
    }

    @Override
    public ManualBatchBpmStat getApproved(Map<String, Object> params) {
        CbsSessionContext sessionCtx = cbsRuntimeContextManager.getContext(CbsSessionContext.class);
        List<BpmWorkItem> bpmItems = bpmService.getApprovedByServiceOperationAndBranch(MANUAL_BATCH_SERVICE,
                sessionCtx.getBranch());
        List<BpmWorkItem> filtered = filterApprovedList(bpmItems, params);
        List<ManualBatchBpmStatNameCount> approvedPerMaker = new ArrayList<>();
        List<ManualBatchBpmStatNameCount> approvedPerAuthorizer = new ArrayList<>();
        Map<String, Integer> makerMap = new HashMap<>();
        Map<String, Integer> authorizerMap = new HashMap<>();
        int totalApproved = 0;
        if(filtered != null) {
            totalApproved = filtered.size();
            for (BpmWorkItem bpmWorkItem : filtered) {
                /**
                 * Maker
                 */
                if (!makerMap.containsKey(bpmWorkItem.getCreatedBy())) {
                    makerMap.put(bpmWorkItem.getCreatedBy(), 1);
                } else {
                    Integer count = makerMap.get(bpmWorkItem.getCreatedBy());
                    makerMap.put(bpmWorkItem.getCreatedBy(), ++count);
                }
                /**
                 * Authorizer
                 */
                if (!authorizerMap.containsKey(bpmWorkItem.getCurrentUser())) {
                    authorizerMap.put(bpmWorkItem.getCurrentUser(), 1);
                } else {
                    Integer count = authorizerMap.get(bpmWorkItem.getCurrentUser());
                    authorizerMap.put(bpmWorkItem.getCurrentUser(), ++count);
                }
            }

            for (String maker : makerMap.keySet()) {
                ManualBatchBpmStatNameCount stat = jaxbSdoHelper.createSdoInstance(ManualBatchBpmStatNameCount.class);
                stat.setName(maker);
                stat.setCount(makerMap.get(maker));
                approvedPerMaker.add(stat);
            }

            for (String authorizer : authorizerMap.keySet()) {
                ManualBatchBpmStatNameCount stat = jaxbSdoHelper.createSdoInstance(ManualBatchBpmStatNameCount.class);
                stat.setName(authorizer);
                stat.setCount(authorizerMap.get(authorizer));
                approvedPerAuthorizer.add(stat);
            }
        }
        ManualBatchBpmStat result = jaxbSdoHelper.createSdoInstance(ManualBatchBpmStat.class);
        result.setTotalApproved(totalApproved);
        result.setTotalApprovedPerMaker(approvedPerMaker);
        result.setTotalApprovedPerAuthorizer(approvedPerAuthorizer);
        result.setBatchDateFrom((String) params.get(BATCH_DATE_FROM));
        result.setBatchDateTo((String) params.get(BATCH_DATE_TO));
        result.setValueDateFrom((String) params.get(VALUE_DATE_FROM));
        result.setValueDateTo((String) params.get(VALUE_DATE_TO));
        return result;
    }

    private List<BpmWorkItem> filterApprovedList(List<BpmWorkItem> bpmItems, Map<String, Object> params){
        List<BpmWorkItem> filtered = new ArrayList<>();
        if(bpmItems != null && bpmItems.isEmpty()) {
            return filtered;
        }
        String valueDateFromStr = (String) params.get(VALUE_DATE_FROM);
        String valueDateToStr = (String) params.get(VALUE_DATE_TO);
        String batchDateFromStr = (String) params.get(BATCH_DATE_FROM);
        String batchDateToStr = (String) params.get(BATCH_DATE_TO);
        Date valueDateFrom = valueDateFromStr != null ? dateTimeHelper.getDate(valueDateFromStr) : null;
        Date valueDateTo = valueDateToStr != null ? dateTimeHelper.getDate(valueDateToStr) : null;
        Date batchDateFrom = batchDateFromStr != null ? dateTimeHelper.getDate(batchDateFromStr) : null;
        Date batchDateTo = batchDateToStr != null ? dateTimeHelper.getDate(batchDateToStr) : null;

        //Validate Dates
        boolean validValueDateFrom = withinCurrentMonth(valueDateFrom);
        boolean validValueDateTo = withinCurrentMonth(valueDateTo);
        boolean validBatchDateFrom = withinCurrentMonth(batchDateFrom);
        boolean validBatchDateTo = withinCurrentMonth(batchDateTo);

        if(!validValueDateFrom){
            Collection<Throwable> exceptions = new ArrayList<>();
            String msg = messageUtils.getMessage(MUST_BE_CURRENT_MONTH, new String[] { "Value Date From" });
            CbsServiceProcessException exec = new CbsServiceProcessException(MUST_BE_CURRENT_MONTH, msg);
            exceptions.add(exec);
            ExceptionHelper.createAndThrowAggregateException(exceptions);
        }

        if(!validValueDateTo){
            Collection<Throwable> exceptions = new ArrayList<>();
            String msg = messageUtils.getMessage(MUST_BE_CURRENT_MONTH, new String[] { "Value Date To" });
            CbsServiceProcessException exec = new CbsServiceProcessException(MUST_BE_CURRENT_MONTH, msg);
            exceptions.add(exec);
            ExceptionHelper.createAndThrowAggregateException(exceptions);
        }

        if(!validBatchDateFrom){
            Collection<Throwable> exceptions = new ArrayList<>();
            String msg = messageUtils.getMessage(MUST_BE_CURRENT_MONTH, new String[] { "Batch Date From" });
            CbsServiceProcessException exec = new CbsServiceProcessException(MUST_BE_CURRENT_MONTH, msg);
            exceptions.add(exec);
            ExceptionHelper.createAndThrowAggregateException(exceptions);
        }

        if(!validBatchDateTo){
            Collection<Throwable> exceptions = new ArrayList<>();
            String msg = messageUtils.getMessage(MUST_BE_CURRENT_MONTH, new String[] { "Batch Date To" });
            CbsServiceProcessException exec = new CbsServiceProcessException(MUST_BE_CURRENT_MONTH, msg);
            exceptions.add(exec);
            ExceptionHelper.createAndThrowAggregateException(exceptions);
        }

        boolean addData = true;
        for (BpmWorkItem bpmWorkItem : bpmItems) {
            ConcurrentHashMap<String, Object> map = bpmService.getProcessDataMapFromDB(bpmWorkItem.getProcInstanceId());
            Object rawData = map.get(BpmConstants.REQUEST);
            if(rawData == null){
                continue;
            }
            ManualBatchHdrJpe jpe = (ManualBatchHdrJpe) rawData;
            boolean valueDateFromCriteriaMet = true;
            boolean valueDateToCriteriaMet = true;
            boolean batchDateFromCriteriaMet = true;
            boolean batchDateToCriteriaMet = true;
            boolean capturedByCriteriaMet = true;
            boolean batchNoCriteriaMet = true;
            if(valueDateFrom != null && jpe.getValueDate() != null && valueDateFrom.compareTo(jpe.getValueDate()) > 0) {
                valueDateFromCriteriaMet = false;
            } else if(valueDateFrom != null && jpe.getValueDate() == null){
                valueDateFromCriteriaMet = false;
            }
            if(valueDateTo != null && jpe.getValueDate() != null && valueDateTo.compareTo(jpe.getValueDate()) < 0) {
                valueDateToCriteriaMet = false;
            } else if(valueDateTo != null && jpe.getValueDate() == null){
                valueDateToCriteriaMet = false;
            }
            if(batchDateFrom != null && jpe.getBatchDate() != null && batchDateFrom.compareTo(jpe.getBatchDate()) > 0) {
                batchDateFromCriteriaMet = false;
            } else if(batchDateFrom != null && jpe.getBatchDate() == null){
                batchDateFromCriteriaMet = false;
            }
            if(batchDateTo != null && jpe.getBatchDate() != null &&  batchDateTo.compareTo(jpe.getBatchDate()) < 0) {
                batchDateToCriteriaMet = false;
            } else if(batchDateTo != null && jpe.getBatchDate() == null){
                batchDateToCriteriaMet = false;
            }

            addData = valueDateFromCriteriaMet && valueDateToCriteriaMet && batchDateFromCriteriaMet && batchDateToCriteriaMet
                    && capturedByCriteriaMet && batchNoCriteriaMet;
            if(addData) {
                filtered.add(bpmWorkItem);
            }
        }
        return filtered;
    }

    private boolean withinCurrentMonth(Date givenDate){
        Date runDate = dateTimeHelper.getRunDate();
        Calendar valueToCheck = Calendar.getInstance();
        Calendar current = Calendar.getInstance();

        valueToCheck.setTime(givenDate);
        current.setTime(runDate);

        if(valueToCheck.get(Calendar.YEAR) == current.get(Calendar.YEAR)) {
            if(valueToCheck.get(Calendar.MONTH) == current.get(Calendar.MONTH)) {
                return true;
            }
        }
        return false;
    }
}
