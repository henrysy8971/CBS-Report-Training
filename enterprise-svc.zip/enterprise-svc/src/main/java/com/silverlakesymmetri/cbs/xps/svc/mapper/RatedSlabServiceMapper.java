package com.silverlakesymmetri.cbs.xps.svc.mapper;

import org.mapstruct.Context;
import org.mapstruct.DecoratedWith;
import org.mapstruct.InheritInverseConfiguration;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingTarget;
import org.mapstruct.Mappings;

import com.silverlakesymmetri.cbs.commons.jpa.util.DateTimeHelper;
import com.silverlakesymmetri.cbs.commons.xmlapi.enums.CbsXmlApiOperation;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.RatedSlabJpe;
import com.silverlakesymmetri.cbs.xps.svc.mapper.decorator.RatedSlabServiceDecorator;
import com.silverlakesymmetri.cbs.xps.xmlapi.XPSCHARGESLABTYPEType;

@Mapper(uses = { DateTimeHelper.class })
@DecoratedWith(RatedSlabServiceDecorator.class)
public interface RatedSlabServiceMapper {


	@Mappings({
		@Mapping(source="balance", target = "BALANCE"),
		@Mapping(source="intBasis", target = "INTBASIS"),
		@Mapping(source="intBasisRate", target = "INTBASISRATE"),
		@Mapping(source="actualAmt", target = "AMOUNT"),
		@Mapping(source="spreadRate", target = "SPREADRATE"),
		@Mapping(source="actualRate", target = "RATE"),
		@Mapping(source="minAmt", target = "MINIMUMAMT"),
		@Mapping(source="maxAmt", target = "MAXIMUMAMT")
	})
	public XPSCHARGESLABTYPEType mapToApi(RatedSlabJpe jpe, @Context CbsXmlApiOperation oper);

	@InheritInverseConfiguration(name = "mapToApi")
	public RatedSlabJpe mapToJpe(XPSCHARGESLABTYPEType api, @MappingTarget RatedSlabJpe jpe);

	@InheritInverseConfiguration(name = "mapToApi")
	public RatedSlabJpe mapToJpe(XPSCHARGESLABTYPEType api);
}