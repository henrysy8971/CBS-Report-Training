package com.silverlakesymmetri.cbs.gla.svc;

import java.util.List;
import java.util.Map;

import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation;
import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation.ServiceOperationType;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.svc.BusinessService;
import com.silverlakesymmetri.cbs.gla.bdo.sdo.GlOverallPositionQry;
import com.silverlakesymmetri.cbs.gla.jpa.mapping.sdo.GlOverallPositionQryJpe;

public interface GlOverallPositionQryService extends BusinessService<GlOverallPositionQry, GlOverallPositionQryJpe> {

	public static final String SVC_OP_NAME_GLOVERALLPOSITIONQRYSERVICE_GET = "GlOverallPositionQryService.get";
	public static final String SVC_OP_NAME_GLOVERALLPOSITIONQRYSERVICE_FIND = "GlOverallPositionQryService.find";
	public static final String SVC_OP_NAME_GLOVERALLPOSITIONQRYSERVICE_QUERY = "GlOverallPositionQryService.query";
	
	@ServiceOperation(name = SVC_OP_NAME_GLOVERALLPOSITIONQRYSERVICE_GET, type = ServiceOperationType.GET)
    public GlOverallPositionQry getByPk(String publicKey, GlOverallPositionQry reference);

    @ServiceOperation(name = SVC_OP_NAME_GLOVERALLPOSITIONQRYSERVICE_FIND)
    public List<GlOverallPositionQry> find(FindCriteria findCriteria, CbsHeader cbsHeader);
    
    @ServiceOperation(name = SVC_OP_NAME_GLOVERALLPOSITIONQRYSERVICE_QUERY)
    public List<GlOverallPositionQry> query(int offset, int resultLimit, String groupBy, String order, Map<String, Object> filters);
}
