package com.silverlakesymmetri.cbs.xps.svc.mapper;

import org.mapstruct.AfterMapping;
import org.mapstruct.Context;
import org.mapstruct.InheritInverseConfiguration;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingTarget;
import org.mapstruct.Mappings;
import org.springframework.beans.factory.annotation.Autowired;

import com.silverlakesymmetri.cbs.commons.jpa.util.DateTimeHelper;
import com.silverlakesymmetri.cbs.commons.xmlapi.enums.CbsXmlApiOperation;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.MarginSettlementDetailsJpe;
import com.silverlakesymmetri.cbs.xps.svc.mapper.mapping.AbstractSwiftSettleMapper;
import com.silverlakesymmetri.cbs.xps.svc.mapper.mapping.SettleMessageJpeToXPSSETTLEMESSAGETYPETypeMapper;
import com.silverlakesymmetri.cbs.xps.svc.util.XmlApiMapperUtil;
import com.silverlakesymmetri.cbs.xps.xmlapi.XPSTRANMARGINSETTLEDETAILAPIType;

@Mapper(uses = { DateTimeHelper.class, SettleMessageJpeToXPSSETTLEMESSAGETYPETypeMapper.class })
public abstract class MarginSettlementDetailsServiceMapper extends AbstractSwiftSettleMapper {
	
	@Autowired
	private XmlApiMapperUtil xmlApiMapperUtil;

	@Mappings({
		@Mapping(target = "INTERNALKEY", source = "internalKey"),
		@Mapping(target = "AMOUNT", source = "amount"),
		@Mapping(target = "SETTLECCY", source = "settleCcy"),
		@Mapping(target = "ISEARMARK", source = "isEarmark"),
		@Mapping(target = "ACCTTYPE", source = "acctType"),
		@Mapping(target = "SETTLEMETHOD", source = "settleMethod"),
		@Mapping(target = "XPSSETTLEKEY", source = "xpsSettleKey"),
		@Mapping(target = "RELINTERNALKEY", source = "relInternalKey"),
		@Mapping(target = "ACCTRESTRAINTKEY", source = "acctRestraintKey"),
		@Mapping(target = "MESSAGE", source = "messageStructRec"),
		@Mapping(target = "SEQNO", source = "seqNo")
	})
	public abstract XPSTRANMARGINSETTLEDETAILAPIType mapToApi(MarginSettlementDetailsJpe jpe, @Context CbsXmlApiOperation oper);

	@InheritInverseConfiguration(name="mapToApi")
	public abstract MarginSettlementDetailsJpe mapToJpe(XPSTRANMARGINSETTLEDETAILAPIType api, @MappingTarget MarginSettlementDetailsJpe jpe);
	
	@InheritInverseConfiguration(name="mapToApi")
	public abstract MarginSettlementDetailsJpe mapToJpe(XPSTRANMARGINSETTLEDETAILAPIType api);

	@AfterMapping
	protected void afterMapToApi(@MappingTarget XPSTRANMARGINSETTLEDETAILAPIType api, MarginSettlementDetailsJpe jpe, @Context CbsXmlApiOperation oper){
		super.mapToApi(api, jpe, oper);
	}
	
	@AfterMapping
	protected void afterMapToJpe(@MappingTarget MarginSettlementDetailsJpe jpe, XPSTRANMARGINSETTLEDETAILAPIType api){
		super.mapToJpe(jpe, api);
		xmlApiMapperUtil.mapCUTTECHNICALINFOTypeToJpe(api, jpe);
	}
	
}
