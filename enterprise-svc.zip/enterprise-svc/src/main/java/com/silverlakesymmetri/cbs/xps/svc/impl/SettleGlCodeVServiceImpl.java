package com.silverlakesymmetri.cbs.xps.svc.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;

import com.mysema.query.types.EntityPath;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.jpa.entity.FindCriteriaJpe;
import com.silverlakesymmetri.cbs.commons.jpa.entity.ViewCriteriaItemJpe;
import com.silverlakesymmetri.cbs.commons.jpa.entity.ViewCriteriaRowJpe;
import com.silverlakesymmetri.cbs.commons.svc.AbstractBusinessService;
import com.silverlakesymmetri.cbs.commons.svc.BusinessObjectValidationCapable;
import com.silverlakesymmetri.cbs.commons.svc.util.InMemoryQueryExecutor;
import com.silverlakesymmetri.cbs.csd.jpa.mapping.sdo.BranchJpe;
import com.silverlakesymmetri.cbs.xps.bdo.sdo.SettleGlCodeV;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.SettleGlCodeVJpe;
import com.silverlakesymmetri.cbs.xps.svc.SettleGlCodeVService;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.QSettleGlCodeVJpe;

@Service
public class SettleGlCodeVServiceImpl extends AbstractBusinessService<SettleGlCodeV, SettleGlCodeVJpe, String>
        implements SettleGlCodeVService, BusinessObjectValidationCapable<SettleGlCodeV> {

	private static final String EXISTS_IN_GL_ACCOUNT = "existsInGlAccount";
	private static final String ATTR_BRANCH = "branch";
	private static final String ATTR_CCY = "ccy";
	private static final String ATTR_PROFIT_CENTRE = "profitCentre";
	private static final String ATTR_CLIENT_ID = "clientId";
	private static final String ATTR_GL_CODE = "glCode";
	private static final String ATTR_DESC = "description";
	private static final String ATTR_BSPL_TYPE = "bsplType";
	private static final String GL_ACCOUNT_ATTR_LIST="branch|ccy|profitCentre";

    @Override
    protected String getIdFromDataObjectInstance(SettleGlCodeV dataObject) {
        SettleGlCodeVJpe jpe = jaxbSdoHelper.unwrap(dataObject);
        return jpe.getGlCode();
    }

    @Override
    protected EntityPath<SettleGlCodeVJpe> getEntityPath() {
        return QSettleGlCodeVJpe.settleGlCodeVJpe;
    }

    @Override
    public List<SettleGlCodeV> query(int offset, int resultLimit, String groupBy, String order, Map<String, Object> filters) {
    	return super.query(offset, resultLimit, groupBy, order, filters);
    }

    @Override
    public List<SettleGlCodeV> find(FindCriteria fc, CbsHeader cbsHeader) {
    	FindCriteriaJpe fcJpe = jaxbSdoHelper.unwrap(fc);
    	
    	if(findExistsInGlAccount(fcJpe)){
    		Map<String,Object> fcMap = convertFcToMap(fcJpe);
    		
    		boolean hasLovFilter = fcMap!=null && !fcMap.isEmpty();
			hasLovFilter = hasLovFilter && (fcMap.containsKey(ATTR_GL_CODE) || fcMap.containsKey(ATTR_DESC)
					|| fcMap.containsKey(ATTR_BSPL_TYPE));
			
			String qString = "SELECT v "
					+ "FROM SettleGlCodeVJpe v "
					+ "WHERE EXISTS ("
						+ "SELECT 1 "
						+ "FROM GlAccountJpe g "
						+ "WHERE g.glCode = v.glCode "
						+ "AND g.acctStatus IN ('N','A') ";
					//+ ")";
			
			if(fcMap.containsKey(ATTR_BRANCH)){
				qString = qString + "AND g.branch = :branch ";
	    		String branchFilter = (String) fcMap.get(ATTR_BRANCH);
	    		if(StringUtils.isNotBlank(branchFilter)){
	    			BranchJpe branchJpe = getBranch(branchFilter);
					if (branchJpe != null && branchJpe.getClientIdInternal() != null) {
	    				qString = qString + "AND g.clientId = :clientId ";
	    				fcMap.put(ATTR_CLIENT_ID, branchJpe.getClientIdInternal());
	    			}
	    		}
			}
			if(fcMap.containsKey(ATTR_CCY)){
				qString = qString + "AND g.ccy = :ccy ";
			}
			if(fcMap.containsKey(ATTR_PROFIT_CENTRE)){
				qString = qString + "AND g.profitCentre = :profitCentre ";
			}
			
			qString = qString + ")";
			
			List<SettleGlCodeVJpe> findList = null;
			if(hasLovFilter){
				//these removed filters will be handled in inMemQry
				fcMap.remove(ATTR_GL_CODE);
				fcMap.remove(ATTR_DESC);
				fcMap.remove(ATTR_BSPL_TYPE);
				findList = dataService.findWithQuery(qString, SettleGlCodeVJpe.class, fcMap, null);				
			}else{
				findList = dataService.findWithQuery(qString, fcMap, fcJpe.getFetchStart(), fcJpe.getFetchSize(),
						SettleGlCodeVJpe.class);
			}
			
			List<SettleGlCodeV>retList = new ArrayList<>();
			for(SettleGlCodeVJpe jpe: findList){
				retList.add(jaxbSdoHelper.wrap(jpe));
			}
			
			if(!hasLovFilter){
				return retList;
			}

			FindCriteria inMemQryFc = removeGlAccountFilters(fcJpe);
	        InMemoryQueryExecutor<SettleGlCodeV> inMemQry = new InMemoryQueryExecutor<>(retList);
	        return inMemQry.executeFilter(inMemQryFc);
    	}else{
    		return super.find(fc, cbsHeader);
    	}
    }

    @Override
    public SettleGlCodeV getByPk(String publicKey, SettleGlCodeV reference) {
        return super.getByPk(publicKey, reference);
    }

    @Override
    public Long count(FindCriteria findCriteria, CbsHeader cbsHeader) {
    	return dataService.getRowCount(this.getEntityPath());
    }
    
    private FindCriteria removeGlAccountFilters(FindCriteriaJpe fcJpe){
    	if (fcJpe != null && fcJpe.getFilter() != null) {
    		if(fcJpe.getFilter().getGroup()!=null && !fcJpe.getFilter().getGroup().isEmpty()){
    			ViewCriteriaRowJpe row = fcJpe.getFilter().getGroup().get(0);
    			List<ViewCriteriaItemJpe> vciList = row.getItem();
    			List<ViewCriteriaItemJpe> filteredList = vciList.stream().filter(p -> !GL_ACCOUNT_ATTR_LIST.contains(p.getAttribute()))
						.collect(Collectors.toList());
    			row.setItem(filteredList);
    		}
    	}
    	return jaxbSdoHelper.wrap(fcJpe);
    }
    
    private Map<String,Object> convertFcToMap(FindCriteriaJpe fcJpe){
    	Map<String,Object> fcMap = new HashMap<>();
    	if (fcJpe != null && fcJpe.getFilter() != null) {
    		for(ViewCriteriaRowJpe row: fcJpe.getFilter().getGroup()){
    			for(ViewCriteriaItemJpe item: row.getItem()){
    				if(item.getValue()!=null && !item.getValue().isEmpty()){    					
    					fcMap.put(item.getAttribute(), item.getValue().get(0));
    				}
    			}
    		}
    	}
    	return fcMap;
    }
    
    private BranchJpe getBranch(String branch){
    	BranchJpe jpe = dataService.find(BranchJpe.class, branch);
    	return jpe;
    }
    
    private boolean findExistsInGlAccount(FindCriteriaJpe fcJpe){
    	boolean isExistsInGlAccount = false;
		int vciIndexToAdjust = -1;
		int vcrIndexToAdjust = -1; 

		if (fcJpe != null && fcJpe.getFilter() != null) {
			for (int r = 0; r < fcJpe.getFilter().getGroup().size(); r++) {
				ViewCriteriaRowJpe row = fcJpe.getFilter().getGroup().get(r);
				for (int c = 0; c < row.getItem().size(); c++) {
					ViewCriteriaItemJpe item = row.getItem().get(c);
					if (EXISTS_IN_GL_ACCOUNT.equals(item.getAttribute())) {
						isExistsInGlAccount = item.getValue() != null && item.getValue().get(0) != null;
						isExistsInGlAccount = isExistsInGlAccount
								&& Boolean.parseBoolean(item.getValue().get(0).toString());
						if (isExistsInGlAccount) {
    						vcrIndexToAdjust=r;
    						vciIndexToAdjust=c;
							break;
						}
					}
				}
				if (isExistsInGlAccount) {
					break;
				}
			}
		}
		
		if (isExistsInGlAccount && vcrIndexToAdjust >= 0 && vciIndexToAdjust >= 0) {
			fcJpe.getFilter().getGroup().get(vcrIndexToAdjust).getItem().remove(vciIndexToAdjust);
		}
		
		return isExistsInGlAccount;
    }

}
