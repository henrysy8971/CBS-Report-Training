package com.silverlakesymmetri.cbs.swf.svc.mapper.mapping;

import org.mapstruct.InheritInverseConfiguration;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Mappings;

import com.silverlakesymmetri.cbs.swf.jpa.mapping.sdo.SwfMtn95Jpe;
import com.silverlakesymmetri.cbs.swf.xmlapi.SWFMTN95TYPEType;

@Mapper(uses={
			  SwfF21Mapper.class,
			  SwfF75Mapper.class,
			  SwfF77TextMapper.class,
			  SwfF11Mapper.class,
			  SwfF79Mapper.class})
public interface SwfMtn95Mapper {
	@Mappings({
		@Mapping(source="relatedRef", target="RELATEDREFERENCE"),
		@Mapping(source="queriesStructRec", target="QUERIES"),
		@Mapping(source="narrativeStructRec", target="NARRATIVE"),
		@Mapping(source="origMessageDateStructRec", target="ORIGMESSAGEDATE"),
		@Mapping(source="origMessageNarrativeStructRec", target="ORIGMESSAGENARRATIVE"),
	})
	SWFMTN95TYPEType mapToApi(SwfMtn95Jpe jpe);
	
	@InheritInverseConfiguration(name="mapToApi")
	SwfMtn95Jpe mapToJpe(SWFMTN95TYPEType api);
}
