package com.silverlakesymmetri.cbs.xps.svc;

import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.svc.BusinessService;
import com.silverlakesymmetri.cbs.xps.bdo.sdo.InwAcctDefn;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.InwAcctDefnJpe;

import java.util.List;
import java.util.Map;

public interface InwAcctDefnService extends BusinessService<InwAcctDefn, InwAcctDefnJpe> {
    String XPS_OP_NAME_INWACCTDEFNSERVICE_GET = "inwAcctDefnService.get";
    String XPS_OP_NAME_INWACCTDEFNSERVICE_QUERY = "inwAcctDefnService.query";
    String XPS_OP_NAME_INWACCTDEFNSERVICE_FIND = "inwAcctDefnService.find";
    String XPS_OP_NAME_INWACCTDEFNSERVICE_CREATE = "inwAcctDefnService.create";
    String XPS_OP_NAME_INWACCTDEFNSERVICE_UPDATE = "inwAcctDefnService.update";
    String XPS_OP_NAME_INWACCTDEFNSERVICE_DELETE = "inwAcctDefnService.delete";

    @ServiceOperation(name = XPS_OP_NAME_INWACCTDEFNSERVICE_GET, type = ServiceOperation.ServiceOperationType.GET)
    InwAcctDefn getByPk(String publicKey, InwAcctDefn reference);

    @ServiceOperation(name = XPS_OP_NAME_INWACCTDEFNSERVICE_QUERY)
    List<InwAcctDefn> query(int offset, int resultLimit, String groupBy, String order,
                            Map<String, Object> filters);

    @ServiceOperation(name = XPS_OP_NAME_INWACCTDEFNSERVICE_FIND)
    List<InwAcctDefn> find(FindCriteria findCriteria, CbsHeader cbsHeader);

    @ServiceOperation(name = XPS_OP_NAME_INWACCTDEFNSERVICE_CREATE)
    InwAcctDefn create(InwAcctDefn dataObject);

    @ServiceOperation(name = XPS_OP_NAME_INWACCTDEFNSERVICE_UPDATE)
    InwAcctDefn update(InwAcctDefn dataObject);

    @ServiceOperation(name = XPS_OP_NAME_INWACCTDEFNSERVICE_DELETE)
    boolean delete(InwAcctDefn dataObject);
}
