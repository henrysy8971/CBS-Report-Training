package com.silverlakesymmetri.cbs.xps.svc.batch.reader;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.batch.core.StepExecution;

import com.silverlakesymmetri.cbs.commons.batch.reader.CbsPartitionedStepItemReader;
import com.silverlakesymmetri.cbs.commons.logging.CbsAppLogger;
import com.silverlakesymmetri.cbs.commons.logging.CbsAppLoggerFactory;

public abstract class AbstractMessageQueueGenAdviceReader<T> extends CbsPartitionedStepItemReader<T> {
	private static CbsAppLogger logger = CbsAppLoggerFactory.getLogger(AbstractMessageQueueGenAdviceReader.class);
			
	private String domain;
	public String getDomain() {
		return domain;
	}
	public void setDomain(String domain) {
		this.domain = domain;
	}

	@Override
	protected List<String> queryKeys(StepExecution stepExecution) {
		List<String> keyList = super.queryKeys(stepExecution);

		if (keyList != null && !keyList.isEmpty()) {
			Integer partitionKey = getPartitionKey();
			logger.debug("keyList size found for partition: {} is {}", partitionKey, keyList.size());
		} else {
			logger.warn("keyList is empty!");
		}

		return keyList;
	}

	@SuppressWarnings("unchecked")
	@Override
	protected List<T> getItemsBuffer(int startIdx) {
		if (getItemIndex() >= keys.size()) {
			return null;
		}

		// there should only be one item per partition
		String minMaxStr = keys.get(0);
		String[] minMaxKeys = minMaxStr.split("~");

		final Map<String, Object> hints = createQueryHints();
		final Map<String, Object> params = new HashMap<String, Object>();
		params.put("domain", this.domain);
		params.put("fromInternalKey", Long.valueOf(minMaxKeys[0]));
		params.put("toInternalKey", Long.valueOf(minMaxKeys[1]));

		final List<T> itemList = (List<T>) getBatchDataService()
				.findWithNamedQuery(getNamedQueryName(), params, getEntityClass(), isClearEntityManager(), hints);

		if (itemList == null || itemList.isEmpty()) {
			logger.warn("itemList is empty!");
		} else {
			logger.debug("itemList size is: {}", itemList.size());
		}

		return itemList;
	}

}
