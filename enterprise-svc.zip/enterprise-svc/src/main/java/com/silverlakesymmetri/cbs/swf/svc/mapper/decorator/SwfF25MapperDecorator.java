package com.silverlakesymmetri.cbs.swf.svc.mapper.decorator;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

import com.silverlakesymmetri.cbs.swf.jpa.mapping.sdo.SwfF25Jpe;
import com.silverlakesymmetri.cbs.swf.svc.mapper.mapping.SwfF25Mapper;
import com.silverlakesymmetri.cbs.swf.xmlapi.SWFF25TYPEType;

public abstract class SwfF25MapperDecorator implements SwfF25Mapper {
	
	@Autowired
	@Qualifier("delegate")
	protected SwfF25Mapper delegate;

	@Override
	public SWFF25TYPEType mapToApi(SwfF25Jpe jpe){
		SWFF25TYPEType swfF25 = delegate.mapToApi(jpe);
		if(swfF25 != null && swfF25.getACCOUNTNO() == null){
			return null;
		}
		return swfF25;
	}
	
	@Override
	public SwfF25Jpe mapToJpe(SWFF25TYPEType api){
		return delegate.mapToJpe(api);
	}
	
}
