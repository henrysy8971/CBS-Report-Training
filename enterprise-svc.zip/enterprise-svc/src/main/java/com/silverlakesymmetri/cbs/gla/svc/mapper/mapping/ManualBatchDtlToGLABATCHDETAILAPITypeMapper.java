package com.silverlakesymmetri.cbs.gla.svc.mapper.mapping;

import org.mapstruct.InheritInverseConfiguration;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Mappings;

import com.silverlakesymmetri.cbs.commons.jpa.util.DateTimeHelper;
import com.silverlakesymmetri.cbs.gla.jpa.mapping.sdo.ManualBatchDtlJpe;
import com.silverlakesymmetri.cbs.gla.xmlapi.GLABATCHDETAILAPIType;

@Mapper(uses={ DateTimeHelper.class})
public interface ManualBatchDtlToGLABATCHDETAILAPITypeMapper {
	
	@Mappings({
		@Mapping(source="itemNo", target="ITEMNO"),
		@Mapping(source="reference", target="REFERENCE"),
		@Mapping(source="narrative", target="NARRATIVE"),
		@Mapping(source="internalKey", target="INTERNALKEY"),
		@Mapping(source="branch", target="BRANCH"),
		@Mapping(source="clientId", target="CLIENTNO"),
		@Mapping(source="glCode", target="GLCODE"),
		@Mapping(source="profitCentre", target="PROFITCENTRE"),
		@Mapping(source="seqNo", target="SEQNO"),
		@Mapping(source="ccy", target="CCY"),
		@Mapping(source="relInternalKey", target="RELINTERNALKEY"),
		@Mapping(source="drAmount", target="DRAMOUNT"),
		@Mapping(source="crAmount", target="CRAMOUNT")
	})
	public GLABATCHDETAILAPIType mapToApi(ManualBatchDtlJpe jpe);

	@InheritInverseConfiguration(name = "mapToApi")
	public ManualBatchDtlJpe mapToJpe(GLABATCHDETAILAPIType api);
}
