package com.silverlakesymmetri.cbs.gla.svc.impl;

import com.mysema.query.types.EntityPath;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.svc.AbstractBusinessService;
import com.silverlakesymmetri.cbs.gla.bdo.sdo.GlPostingFieldsByGLKeysQry;
import com.silverlakesymmetri.cbs.gla.jpa.mapping.sdo.GlPostingFieldsByGLKeysQryJpe;
import com.silverlakesymmetri.cbs.gla.jpa.mapping.sdo.QGlPostingFieldsByGLKeysQryJpe;
import com.silverlakesymmetri.cbs.gla.jpa.mapping.sdo.id.GlPostingFieldsByGLKeysQryPk;
import com.silverlakesymmetri.cbs.gla.svc.GlAcctBalByGlKeysQryService;
import com.silverlakesymmetri.cbs.gla.svc.GlPostingFieldsByGlKeysQryService;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;

@Service
public class GlPostingFieldsByGlKeysQryServiceImpl extends AbstractBusinessService<GlPostingFieldsByGLKeysQry, GlPostingFieldsByGLKeysQryJpe, GlPostingFieldsByGLKeysQryPk> implements
		GlPostingFieldsByGlKeysQryService {

	private static final String D = "D";
	private static final String C = "C";
	private static final String VD = "VD";
	private static final String PD= "PD";


	@Override
	protected GlPostingFieldsByGLKeysQryPk getIdFromDataObjectInstance(GlPostingFieldsByGLKeysQry dataObject) {
		return new GlPostingFieldsByGLKeysQryPk(dataObject.getInternalKey());
	}

	@Override
	protected EntityPath<GlPostingFieldsByGLKeysQryJpe> getEntityPath() {
		return QGlPostingFieldsByGLKeysQryJpe.glPostingFieldsByGLKeysQryJpe;
	}
	
	@Override
	public GlPostingFieldsByGLKeysQry getByPk(String publicKey, GlPostingFieldsByGLKeysQry dataObject) {
		GlPostingFieldsByGLKeysQry bdo = super.getByPk(publicKey, dataObject);

		//For 3rd party else computation will be done in UI
		if(VD.equals(bdo.getDateType())) {
			bdo.setAvailBal((bdo.getActualBalAbs() + bdo.getCrInterestAccrued() + bdo.getCrInterestAdjust()) - (bdo.getWitholdingTaxAmount() + bdo.getDrInterestAccrued() + bdo.getDrInterestAdjust()));
		} else {
			bdo.setAvailBal((bdo.getLedgerBalAbs() + bdo.getCrInterestAccrued() + bdo.getCrInterestAdjust()) - (bdo.getWitholdingTaxAmount() + bdo.getDrInterestAccrued() + bdo.getDrInterestAdjust()));
		}

		setDrCrValues(bdo);
		return bdo;
	}

	private void setDrCrValues(GlPostingFieldsByGLKeysQry bdo) {
		if(bdo.getAvailBal() != null) {
			if (bdo.getAvailBal() < 0) {
				bdo.setAvailBalCrDR(C);
			} else {
				bdo.setAvailBalCrDR(D);
			}
		}

		if(bdo.getCurrentBal() != null) {
			if(bdo.getCurrentBal() < 0) {
				bdo.setCurrentBalDrCr(C);
			} else {
				bdo.setCurrentBalDrCr(D);
			}
		}
	}


	@Override
	public List<GlPostingFieldsByGLKeysQry> query(int offset, int resultLimit, String groupBy, String order,
			Map<String, Object> filters) {
		return super.query(offset, resultLimit, groupBy, order, filters);
	}

	@Override
	public List<GlPostingFieldsByGLKeysQry> find(FindCriteria findCriteria, CbsHeader cbsHeader) {
		return super.find(findCriteria, cbsHeader);
	}
	
	@Override
	public GlPostingFieldsByGLKeysQry get(GlPostingFieldsByGLKeysQry objectInstanceIdentifier) {
		return super.get(objectInstanceIdentifier);
	}

}
