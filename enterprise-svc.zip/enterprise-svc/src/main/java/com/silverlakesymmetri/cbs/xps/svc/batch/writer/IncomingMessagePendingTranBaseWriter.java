package com.silverlakesymmetri.cbs.xps.svc.batch.writer;

import com.silverlakesymmetri.cbs.commons.bdo.CbsBusinessDataObject;
import com.silverlakesymmetri.cbs.commons.bpm.svc.BpmServiceAdapter;
import com.silverlakesymmetri.cbs.commons.context.CbsRuntimeContextManager;
import com.silverlakesymmetri.cbs.commons.context.CbsSessionContext;
import com.silverlakesymmetri.cbs.commons.integration.CbsIntegrationConstants;
import com.silverlakesymmetri.cbs.commons.jpa.mapping.sdo.UserJpe;
import com.silverlakesymmetri.cbs.commons.jpa.mapping.sdo.UserOrganizationJpe;
import com.silverlakesymmetri.cbs.commons.jpa.mapping.sdo.UserProfilesJpe;
import com.silverlakesymmetri.cbs.commons.jpa.mapping.sdo.util.JpeConstants;
import com.silverlakesymmetri.cbs.commons.jpa.service.CbsBatchGenericDataService;
import com.silverlakesymmetri.cbs.commons.logging.CbsAppLogger;
import com.silverlakesymmetri.cbs.commons.logging.CbsAppLoggerFactory;
import com.silverlakesymmetri.cbs.xps.util.BpmTaskParamObject;
import org.apache.commons.lang3.StringUtils;
import org.springframework.batch.item.ItemWriter;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public abstract class IncomingMessagePendingTranBaseWriter implements ItemWriter<BpmTaskParamObject> {
	private final CbsAppLogger logger = CbsAppLoggerFactory.getLogger(IncomingMessagePendingTranBaseWriter.class.getName());

	protected static final String STATUS_PROCESSED = "P";
	protected static final String STATUS_FAILED = "F";

	@Autowired
	private CbsRuntimeContextManager ctxMngr;

	public CbsBatchGenericDataService batchDataService;
	String maker;

	public CbsBatchGenericDataService getBatchDataService() {
		return batchDataService;
	}

	public void setBatchDataService(CbsBatchGenericDataService batchDataService) {
		this.batchDataService = batchDataService;
	}

	public String getMaker() {
		return maker;
	}

	public void setMaker(String maker) {
		this.maker = maker;
	}

	@Autowired
	BpmServiceAdapter bpmServiceAdapter;

	@Override
	public void write(List<? extends BpmTaskParamObject> items) throws Exception {
		//preliminary check
		if (items == null || items.isEmpty()) {
			logger.warn("items is empty. Nothing to update!");
			return;
		}

		List<Long> internalKeyList = items.stream()
				.filter(e-> e.getInternalKey() != null)
				.map(BpmTaskParamObject::getInternalKey)
				.collect(Collectors.toList());

		if (internalKeyList.isEmpty()) {
			logger.warn("internalKeyList is empty. Nothing to update!");
			return;
		}
		
		boolean isSuccess = false;
		try {
			createBpmTask(items);
			isSuccess = true;
		} catch (Exception e) {
			logger.error("Failed to create BPM Task for keys: {}", internalKeyList);
			e.printStackTrace();

			// update to FAIL
			doBulkUpdate(STATUS_FAILED, internalKeyList);
		}

		if (isSuccess) {
			// update to PROCESSED
			doBulkUpdate(STATUS_PROCESSED, internalKeyList);
		}
	}

	protected void createBpmTask(List<? extends BpmTaskParamObject> items) throws Exception {
		String userBranch = StringUtils.isNotBlank(this.maker) ? getUserBranch(this.maker) : null;

		for (BpmTaskParamObject obj : items) {
			CbsBusinessDataObject bdo = bpmServiceAdapter.createWorkItem(
				obj.getBdo(),
				CbsIntegrationConstants.PROPERTY_CBS_HEADER_BACKGROUND_RUNNER_USER_CODE,
				obj.getServiceOperation(),
				obj.getScreenUrl(),
				obj.getActivityName(),
				obj.getReferenceNo(),
				userBranch
			);
			
			Long processInstanceId = null;
			Long activityInstanceId = null;
			if(bdo != null && bdo.getHeader() != null && bdo.getHeader().getBpmInfo() != null){
				processInstanceId = bdo.getHeader().getBpmInfo().getProcessInstanceId();
				activityInstanceId = bdo.getHeader().getBpmInfo().getActivityInstanceId();
			}
			logger.info("Process/Activity Instance ID is {}/{} for internalKey {}", processInstanceId, activityInstanceId, obj.getInternalKey());
		}
	}

	protected abstract void doBulkUpdate(String newStatus, List<Long> keys);

	protected String getUserBranch(String userCode) {
		CbsSessionContext sessionCtx = ctxMngr.getContext(CbsSessionContext.class);
		String branch = null;
		Map<String, Object> params = new HashMap<>();
		params.put("userCode", userCode);
		List<UserJpe> userQueryList = batchDataService.findWithNamedQuery(JpeConstants.USER_JPE__GET_USER_BY_USER_CODE, params, UserJpe.class);
		if(userQueryList != null && userQueryList.size() > 0) {
			UserJpe user = userQueryList.get(0);
			if(user.getUserProfilesList() != null && user.getUserProfilesList().size() > 0){
				for(UserProfilesJpe profile : user.getUserProfilesList()) {
					if(Boolean.TRUE.equals(profile.isDefaultYn())) {
						branch = profile.getProfileCode();
						break;
					}
				}
			} else if(user.getUserOrganizationList() != null) {
				for(UserOrganizationJpe org : user.getUserOrganizationList()) {
					if(org.getOrgCode().equals(sessionCtx.getOrgCode())) {
						branch = org.getBranch();
						break;
					}
				}
			}
		}
		return branch;
	}

}
