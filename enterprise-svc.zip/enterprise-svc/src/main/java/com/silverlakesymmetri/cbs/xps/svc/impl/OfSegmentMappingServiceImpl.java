package com.silverlakesymmetri.cbs.xps.svc.impl;

import com.mysema.query.types.EntityPath;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.svc.AbstractBusinessService;
import com.silverlakesymmetri.cbs.commons.svc.BusinessObjectValidationCapable;
import com.silverlakesymmetri.cbs.xps.bdo.sdo.OfSegmentMapping;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.OfSegmentMappingJpe;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.QOfSegmentMappingJpe;
import com.silverlakesymmetri.cbs.xps.svc.OfSegmentMappingService;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Map;

@Transactional
@Service
public class OfSegmentMappingServiceImpl extends AbstractBusinessService<OfSegmentMapping, OfSegmentMappingJpe, String>
        implements OfSegmentMappingService, BusinessObjectValidationCapable<OfSegmentMapping> {

    @Override
    protected String getIdFromDataObjectInstance(OfSegmentMapping dataObject) {
        return dataObject.getCbsColumn();
    }

    @Override
    protected EntityPath<OfSegmentMappingJpe> getEntityPath() {
        return QOfSegmentMappingJpe.ofSegmentMappingJpe;
    }
    
    @Override
    public OfSegmentMapping getByPk(String publicKey, OfSegmentMapping reference) {
        return super.getByPk(publicKey, reference);
    }

    @Override
    public OfSegmentMapping get(OfSegmentMapping objectInstanceIdentifier) {
        return super.get(objectInstanceIdentifier);
    }

    @Override
    public OfSegmentMapping create(OfSegmentMapping dataObject) {
        return super.create(dataObject);
    }

    @Override
    public OfSegmentMapping update(OfSegmentMapping dataObject) {
        return super.update(dataObject);
    }

    @Override
    public boolean delete(OfSegmentMapping dataObject) {
        return super.delete(dataObject);
    }

    @Override
    public List<OfSegmentMapping> query(int offset, int resultLimit, String groupBy, String order, Map<String, Object> filters) {
        return super.query(offset, resultLimit, groupBy, order, filters);
    }

    @Override
    public List<OfSegmentMapping> find(FindCriteria findCriteria, CbsHeader cbsHeader) {
        return super.find(findCriteria, cbsHeader);
    }
}
