package com.silverlakesymmetri.cbs.gla.svc;

import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation;
import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation.ServiceOperationType;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.svc.BusinessService;
import com.silverlakesymmetri.cbs.csd.bdo.sdo.Branch;
import com.silverlakesymmetri.cbs.csd.bdo.sdo.Currency;
import com.silverlakesymmetri.cbs.gla.bdo.sdo.CashFlowOverallQry;
import com.silverlakesymmetri.cbs.gla.jpa.mapping.sdo.CashFlowOverallQryJpe;

import java.util.List;
import java.util.Map;

public interface CashFlowOverallQryService extends BusinessService<CashFlowOverallQry, CashFlowOverallQryJpe>{

	public static final String SVC_OP_NAME_CASHFLOWOVERALLSERVICE_GET = "CashFlowOverallQryService.get";
	public static final String SVC_OP_NAME_CASHFLOWOVERALLSERVICE_FIND = "CashFlowOverallQryService.find";
	public static final String SVC_OP_NAME_CASHFLOWOVERALLSERVICE_QUERY = "CashFlowOverallQryService.query";
    public static final String SVC_OP_NAME_CASHFLOWOVERALLSERVICE_FIND_BRANCH = "CashFlowOverallQryService.findBranch";
    public static final String SVC_OP_NAME_CASHFLOWOVERALLSERVICE_FIND_CCY = "CashFlowOverallQryService.findCcy";
	
	@ServiceOperation(name = SVC_OP_NAME_CASHFLOWOVERALLSERVICE_GET, type = ServiceOperationType.GET)
    public CashFlowOverallQry getByPk(String publicKey, CashFlowOverallQry reference);

    @ServiceOperation(name = SVC_OP_NAME_CASHFLOWOVERALLSERVICE_FIND)
    public List<CashFlowOverallQry> find(FindCriteria findCriteria, CbsHeader cbsHeader);
    
    @ServiceOperation(name = SVC_OP_NAME_CASHFLOWOVERALLSERVICE_QUERY)
    public List<CashFlowOverallQry> query(int offset, int resultLimit, String groupBy, String order, Map<String, Object> filters);

    @ServiceOperation(name = SVC_OP_NAME_CASHFLOWOVERALLSERVICE_FIND_BRANCH ,
            type = ServiceOperation.ServiceOperationType.READ, passParamAsMap = true)
    public List<Branch> findBranches(Map<String, Object> queryParams);

    @ServiceOperation(name = SVC_OP_NAME_CASHFLOWOVERALLSERVICE_FIND_CCY ,
            type = ServiceOperation.ServiceOperationType.READ, passParamAsMap = true)
    public List<Currency> findCcy(Map<String, Object> queryParams);
}
