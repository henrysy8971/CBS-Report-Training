package com.silverlakesymmetri.cbs.gla.svc.impl;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import com.silverlakesymmetri.cbs.commons.context.impl.CbsRuntimeContextManagerImpl;
import com.silverlakesymmetri.cbs.csd.gla.bdo.sdo.ChartAccount;
import com.silverlakesymmetri.cbs.csd.gla.jpa.mapping.sdo.ChartAccountJpe;
import com.silverlakesymmetri.cbs.csd.jpa.mapping.sdo.util.CsdJpeConstants;
import com.silverlakesymmetri.cbs.csd.svc.CurrencyService;
import com.silverlakesymmetri.cbs.csd.svc.ProfitCentreService;
import com.silverlakesymmetri.cbs.gla.bdo.sdo.GlManualBatchGlCodeQry;
import com.silverlakesymmetri.cbs.gla.bdo.sdo.ManualBatchDtl;
import com.silverlakesymmetri.cbs.csd.bdo.sdo.Currency;
import com.silverlakesymmetri.cbs.csd.jpa.mapping.sdo.CurrencyJpe;
import com.silverlakesymmetri.cbs.gla.jpa.mapping.sdo.GlManualBatchGlCodeQryJpe;
import com.silverlakesymmetri.cbs.mcl.bdo.sdo.Client;
import com.silverlakesymmetri.cbs.mcl.jpa.mapping.sdo.ClientJpe;
import com.silverlakesymmetri.cbs.mcl.svc.ClientService;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mysema.query.types.EntityPath;
import com.silverlakesymmetri.cbs.commons.bdo.CbsBusinessDataObject;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.bpm.svc.BpmServiceAdapter;
import com.silverlakesymmetri.cbs.commons.context.CbsSessionContext;
import com.silverlakesymmetri.cbs.commons.exception.CbsRuntimeException;
import com.silverlakesymmetri.cbs.commons.exception.base.CbsServiceProcessException;
import com.silverlakesymmetri.cbs.commons.exception.base.helper.ExceptionHelper;
import com.silverlakesymmetri.cbs.commons.integration.CbsIntegrationConstants;
import com.silverlakesymmetri.cbs.commons.jpa.util.DateTimeHelper;
import com.silverlakesymmetri.cbs.commons.logging.CbsAppLogger;
import com.silverlakesymmetri.cbs.commons.logging.CbsAppLoggerFactory;
import com.silverlakesymmetri.cbs.commons.svc.AbstractXmlApiBusinessService;
import com.silverlakesymmetri.cbs.commons.xmlapi.enums.CbsXmlApiOperation;
import com.silverlakesymmetri.cbs.csd.bdo.sdo.ProfitCentre;
import com.silverlakesymmetri.cbs.csd.jpa.mapping.sdo.ProfitCentreJpe;
import com.silverlakesymmetri.cbs.csd.util.DateHelperDataHolder;
import com.silverlakesymmetri.cbs.csd.util.DateHelperUtil;
import com.silverlakesymmetri.cbs.gla.bdo.sdo.ManualBatchHdr;
import com.silverlakesymmetri.cbs.gla.jpa.mapping.sdo.ManualBatchDtlJpe;
import com.silverlakesymmetri.cbs.gla.jpa.mapping.sdo.ManualBatchHdrJpe;
import com.silverlakesymmetri.cbs.gla.jpa.mapping.sdo.id.ManualBatchHdrPk;
import com.silverlakesymmetri.cbs.gla.jpa.mapping.sdo.util.GlaJpeConstants;
import com.silverlakesymmetri.cbs.gla.svc.ManualBatchService;
import com.silverlakesymmetri.cbs.gla.svc.mapper.mapping.ManualBatchDtlToGLABATCHDETAILAPITypeMapper;
import com.silverlakesymmetri.cbs.gla.svc.mapper.mapping.ManualBatchHdrToGLABATCHHEADERAPITypeMapper;
import com.silverlakesymmetri.cbs.gla.xmlapi.GLABATCHDETAILAPIType;
import com.silverlakesymmetri.cbs.gla.xmlapi.GLABATCHDETAILCOLLType;
import com.silverlakesymmetri.cbs.gla.xmlapi.GLABATCHHEADERAPIType;
import com.silverlakesymmetri.cbs.gla.xmlapi.GLABATCHTRANSAPIType;
import com.silverlakesymmetri.cbs.mcl.jpa.mapping.sdo.util.MclJpeConstants;
import com.silverlakesymmetri.cbs.xps.util.BpmTaskParamObject;
import com.silverlakesymmetri.cbs.gla.jpa.mapping.sdo.QManualBatchHdrJpe;

import javax.inject.Inject;

@Service
public class ManualBatchServiceImpl extends
		AbstractXmlApiBusinessService<ManualBatchHdr, ManualBatchHdrJpe, ManualBatchHdrPk, GLABATCHTRANSAPIType, GLABATCHTRANSAPIType>
		implements ManualBatchService {

	private CbsAppLogger logger = CbsAppLoggerFactory.getLogger(ManualBatchServiceImpl.class);

	private static final String ERROR_BATCH_DATE_IS_HOLIDAY = "CBS.B.GLA.119092";
	private static final String BATCH_NO_SEQ = "GLA_BATCH_NO_S";
	private static final String BATCH_HEADER_SEQ = "GLA_BATCH_HEADER_INTERNAL_KEY_S";
	private static final String BATCH_DETAIL_SEQ = "GLA_BATCH_DETAIL_INTERNAL_KEY_S";
	private static final String ERROR_GL_CODE_INACTIVE = "CBS.B.GLA.119102";

	@Autowired
	private DateTimeHelper dateTimeHelper;

	@Autowired
	private DateHelperUtil dateHelperUtil;

	@Autowired
	ManualBatchHdrToGLABATCHHEADERAPITypeMapper batchHdrMapper;

	@Autowired
	ManualBatchDtlToGLABATCHDETAILAPITypeMapper batchDtlMapper;

	@Autowired
	BpmServiceAdapter bpmServiceAdapter;

	@Inject
	protected CbsRuntimeContextManagerImpl ctxMngrImpl;

	@Autowired
	CurrencyService ccyService;

	@Autowired
	ClientService clientService;

	@Autowired
	ProfitCentreService profitCentreService;



	@Override
	protected ManualBatchHdrPk getIdFromDataObjectInstance(ManualBatchHdr dataObject) {
		ManualBatchHdrJpe jpe = jaxbSdoHelper.unwrap(dataObject, ManualBatchHdrJpe.class);
		return new ManualBatchHdrPk(jpe.getInternalKey());
	}

	@Override
	protected EntityPath<ManualBatchHdrJpe> getEntityPath() {
		return QManualBatchHdrJpe.manualBatchHdrJpe;
	}

	@Override
	public ManualBatchHdr getByPk(String publicKey, ManualBatchHdr reference) {
		return super.getByPk(publicKey, reference);
	}

	@Override
	public List<ManualBatchHdr> find(FindCriteria findCriteria, CbsHeader cbsHeader) {
		return super.find(findCriteria, cbsHeader);
	}

	@Override
	public List<ManualBatchHdr> query(int offset, int resultLimit, String groupBy, String order,
			Map<String, Object> filters) {
		return super.query(offset, resultLimit, groupBy, order, filters);
	}

	@Override
	protected ManualBatchHdr preCreateValidation(ManualBatchHdr dataObject) {
		ManualBatchHdrJpe jpe = jaxbSdoHelper.unwrap(dataObject, ManualBatchHdrJpe.class);
		setDefaulting(jpe);
		dataObject = jaxbSdoHelper.wrap(jpe);
		validateDates(dataObject);
		return super.preCreateValidation(dataObject);
	}

	private void validateDates(ManualBatchHdr dataObject) {
		Collection<Throwable> exceptions = new ArrayList<>();

		// Batch date cannot be a holiday
		if (dataObject.getBatchDate() != null) {
			DateHelperDataHolder holder = dateHelperUtil.createGeneralDateDataHolder(dataObject.getType().getName(),
					"batchDate", dataObject);
			if (dateHelperUtil.checkHoliday(holder)) {
				String msg = messageUtils.getMessage(ERROR_BATCH_DATE_IS_HOLIDAY, new String[] { "Batch date" });
				CbsServiceProcessException exec = new CbsServiceProcessException(ERROR_BATCH_DATE_IS_HOLIDAY, msg);
				exceptions.add(exec);
			}
		}

		// Value date cannot be a holiday
		if (dataObject.getValueDate() != null) {
			DateHelperDataHolder holder = dateHelperUtil.createGeneralDateDataHolder(dataObject.getType().getName(),
					"valueDate", dataObject);
			if (dateHelperUtil.checkHoliday(holder)) {
				String msg = messageUtils.getMessage(ERROR_BATCH_DATE_IS_HOLIDAY, new String[] { "Value date" });
				CbsServiceProcessException exec = new CbsServiceProcessException(ERROR_BATCH_DATE_IS_HOLIDAY, msg);
				exceptions.add(exec);
			}
		}

		ExceptionHelper.createAndThrowAggregateException(exceptions);
	}

	private void setDefaulting(ManualBatchHdrJpe jpe) {

		if (jpe.getBranch() == null || jpe.getBranch().isEmpty()) {
			CbsSessionContext sessionCtx = cbsRuntimeContextManager.getContext(CbsSessionContext.class);
			String branch = getUserBranch(sessionCtx.getUserCode());
			jpe.setBranch(branch);
		}

		if (StringUtils.isBlank(jpe.getBatchNo())) {
			jpe.setBatchNo(String.valueOf(dataService.nextSequenceValue(BATCH_NO_SEQ)));
		}
		
		jpe.setInternalKey(dataService.nextSequenceValue(BATCH_HEADER_SEQ));

		if (jpe.getNoOfItems() == null) {
			jpe.setNoOfItems(0);
		}

		for (ManualBatchDtlJpe detail : jpe.getManualbatchDetailList()) {
			detail.setBatchNo(jpe.getBatchNo());
			detail.setRelInternalKey(jpe.getInternalKey());
			detail.setInternalKey(dataService.nextSequenceValue(BATCH_DETAIL_SEQ));
			detail.setClientId(getClientId(detail.getClientNo()));
		}
		Date runDate = dateTimeHelper.getRunDate();

		if (jpe.getBatchDate() == null) {
			jpe.setBatchDate(runDate);
		}
		if (jpe.getValueDate() == null) {
			jpe.setValueDate(runDate);
		}
		if (jpe.getTranDate() == null) {
			jpe.setTranDate(runDate);
		}
		if(jpe.getInterbranch() == null) {
			jpe.setInterbranch("N");
		}
	}

	@Override
	public ManualBatchHdr create(ManualBatchHdr dataObject) {
		return super.create(dataObject);
	}

	@Override
	public ManualBatchHdr update(ManualBatchHdr dataObject) {
		return super.update(dataObject);
	}

	@Override
	public boolean delete(ManualBatchHdr dataObject) {
		return super.delete(dataObject);
	}

	@Override
	protected GLABATCHTRANSAPIType transformBdoToXmlApiRqCreate(ManualBatchHdr bdo) {

		return transformBdoToXmlApiType(bdo, CbsXmlApiOperation.INSERT);
	}

	private GLABATCHTRANSAPIType transformBdoToXmlApiType(ManualBatchHdr bdo, CbsXmlApiOperation oper) {
		ManualBatchHdrJpe hdrJpe = jaxbSdoHelper.unwrap(bdo);
		GLABATCHHEADERAPIType hdrApi = batchHdrMapper.mapToApi(hdrJpe);
		GLABATCHTRANSAPIType batchTransApi = new GLABATCHTRANSAPIType();

		transformManualBatchDtlToGLABATCHDETAILAPIType(bdo, batchTransApi, hdrApi);

		batchTransApi.setBATCHNO(hdrApi.getBATCHNO());
		batchTransApi.setINTERNALKEY(hdrApi.getINTERNALKEY());
		batchTransApi.setBATCHHEADERREC(hdrApi);
		super.setTechColsFromDataObject(bdo, hdrApi);
		batchTransApi.setOPERATION(oper.getOperation());

		return batchTransApi;
	}

	private void transformManualBatchDtlToGLABATCHDETAILAPIType(ManualBatchHdr bdo,
			GLABATCHTRANSAPIType batchTransApi, GLABATCHHEADERAPIType hdrApi) {
		if (batchTransApi.getBATCHDETAILLIST() == null) {
			batchTransApi.setBATCHDETAILLIST(new GLABATCHDETAILCOLLType());
		}
		ManualBatchHdrJpe hdrJpe = jaxbSdoHelper.unwrap(bdo);
		List<ManualBatchDtlJpe> jpeList = hdrJpe.getManualbatchDetailList();
		
		if (jpeList != null && !jpeList.isEmpty()) {
			for (ManualBatchDtlJpe detailJpe : jpeList) {
				GLABATCHDETAILAPIType detailApi = batchDtlMapper.mapToApi(detailJpe);
				super.setTechColsFromDataObject(bdo, detailApi);
				batchTransApi.getBATCHDETAILLIST().getGLABATCHDETAILAPI().add(detailApi);
			}
		}
	}

	private void createGLABATCHDETAILAPIType(GLABATCHTRANSAPIType xmlApiObj, ManualBatchDtlJpe detailJpe) {
		GLABATCHDETAILAPIType detailApi = batchDtlMapper.mapToApi(detailJpe);
		super.setTechColumns(detailApi);
		xmlApiObj.getBATCHDETAILLIST().getGLABATCHDETAILAPI().add(detailApi);
	}

	private Long getClientId(String clientNo) {
		if (clientNo == null)
			return null;
		Map<String, Object> params = new HashMap<>();
		params.put("clientNo", clientNo);
		List<Long> list = dataService.findWithNamedQuery(MclJpeConstants.CLIENT_JPE_FIND_CLIENT_ID_USING_CLIENT_NO,
				params, Long.class);
		if (list != null && !list.isEmpty())
			return list.get(0);
		return null;
	}

	@Override
	protected GLABATCHTRANSAPIType transformBdoToXmlApiRqUpdate(ManualBatchHdr bdo) {
		return transformBdoToXmlApiType(bdo, CbsXmlApiOperation.UPDATE);
	}

	@Override
	protected GLABATCHTRANSAPIType transformBdoToXmlApiRqDelete(ManualBatchHdr bdo) {
		return transformBdoToXmlApiType(bdo, CbsXmlApiOperation.DELETE);
	}

	@Override
	protected ManualBatchHdr processXmlApiRs(ManualBatchHdr dataObject, GLABATCHTRANSAPIType xmlApiRs) {
		return dataObject;
	}

	@Override
	protected List<ManualBatchHdr> processXmlApiListRs(ManualBatchHdr dataObject, GLABATCHTRANSAPIType xmlApiRs) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	protected Class<GLABATCHTRANSAPIType> getXmlApiResponseClass() {
		return GLABATCHTRANSAPIType.class;
	}

	@Override
	public List<ProfitCentre> findProfitCentre(Map<String, Object> queryParams) {
		String detailBranch = (String) queryParams.get("branch");
		String detailCcy = (String) queryParams.get("ccy");
		String detailGlType = (String) queryParams.get("glType");
		String detailGlCode = (String) queryParams.get("glCode");
		String detailClientNo = (String) queryParams.get("clientNo");
		String detailSeqNo = (String) queryParams.get("seqNo");
		String profitCentre = (String) queryParams.get("profitCentre");
		String profitCentreDesc = (String) queryParams.get("profitCentreDesc");
		String autoIntAcctCreation = ctxMngrImpl.getBestAvailableContext().getRegistryEntry("GENERAL_LEDGER_REGISTRY", "autoIntAcctCreation");


		if(detailGlType == null) {
			Map<String, Object> glParams = new HashMap<>();
			glParams.put("glCode", detailGlCode);
			List<ChartAccountJpe> chartAccountJpeList = dataService.findWithNamedQuery(CsdJpeConstants.GLA_MANUAL_BATCH_DTL_GL_CODE_JPE_LOV_VALIDATION, glParams, ChartAccountJpe.class);
			if(chartAccountJpeList != null) {
				detailGlType = chartAccountJpeList.get(0).getGlType();
			}
		}

		int limit = queryParams.get("limit") != null ? Integer.parseInt((String) queryParams.get("limit")) : 10;
		int offset = queryParams.get("offset") != null ? Integer.parseInt((String) queryParams.get("offset")) : 0;

		if(autoIntAcctCreation != null && "Y".equalsIgnoreCase(autoIntAcctCreation) && "I".equalsIgnoreCase(detailGlType)) {

			Map<String, Object> params = new HashMap<>();
			if(profitCentre != null) {
				params.put("profitCentre", profitCentre);
			}

			if(profitCentreDesc != null) {
				params.put("profitCentreDesc", profitCentreDesc);
			}

			return profitCentreService.query(offset,limit,"profitCentre","profitCentre", params);

		} else {
			String query = GlaJpeConstants.BATCH_MAINTENANCE_PROFIT_CENTRE_LOV_QUERY_PREFIX;

			Long clientId = getClientId(detailClientNo);
			Integer seqNo = null;
			try {
				seqNo = Integer.parseInt(detailSeqNo);
			} catch (NumberFormatException nfe) {
			}

			List<ProfitCentre> result = new ArrayList<>();
			final Map<String, Object> parameters = new HashMap<>();
			parameters.put("detailGlType", detailGlType);
			parameters.put("detailBranch", detailBranch);
			parameters.put("detailCcy", detailCcy);
			parameters.put("detailGlCode", detailGlCode);
			parameters.put("detailSeqNo", seqNo);
			parameters.put("detailClientNo", clientId);

			if (profitCentre != null) {
				query = query + " AND p.profitCentre LIKE :profitCentre ";
				parameters.put("profitCentre", "%" + profitCentre + "%");
			}

			if (profitCentreDesc != null) {
				query = query + " AND p.profitCentreDesc LIKE :profitCentreDesc ";
				parameters.put("profitCentreDesc", "%" + profitCentreDesc + "%");
			}
			query = query + GlaJpeConstants.BATCH_MAINTENANCE_PROFIT_CENTRE_LOV_QUERY_SUFFIX + " ORDER BY p.profitCentre";

			List<ProfitCentreJpe> list = dataService.findWithQuery(query, parameters, offset, limit, ProfitCentreJpe.class);

			for (Object o : list) {
				Object[] values = (Object[]) o;
				ProfitCentre bdo = jaxbSdoHelper.createSdoInstance(ProfitCentre.class);
				bdo.setProfitCentre((String) values[0]);
				bdo.setProfitCentreDesc((String) values[1]);
				result.add(bdo);
			}
			return result;
		}
	}

	@Override
	public List<Currency> findCurrency(Map<String, Object> queryParams) {
		String detailBranch = (String) queryParams.get("branch");
		String detailCcy = (String) queryParams.get("ccy");
		String detailCcyDesc = (String) queryParams.get("ccyDesc");
		String autoIntAcctCreation = ctxMngrImpl.getBestAvailableContext().getRegistryEntry("GENERAL_LEDGER_REGISTRY", "autoIntAcctCreation");
		int limit = queryParams.get("limit") != null ? Integer.parseInt((String) queryParams.get("limit")) : 10;
		int offset = queryParams.get("offset") != null ? Integer.parseInt((String) queryParams.get("offset")) : 0;

		if(autoIntAcctCreation != null && "Y".equalsIgnoreCase(autoIntAcctCreation)) {

			Map<String, Object> params = new HashMap<>();
			if(detailCcy != null) {
				params.put("ccy", detailCcy);
			}

			if(detailCcyDesc != null){
				params.put("ccyDesc", detailCcyDesc);
			}
			return ccyService.query(offset,limit,"ccy","ccy", params);

		} else {
			String query = GlaJpeConstants.BATCH_MAINTENANCE_CURRENCY_LOV_QUERY_PREFIX;


			List<Currency> result = new ArrayList<>();
			final Map<String, Object> parameters = new HashMap<>();
			parameters.put("detailBranch", detailBranch);



			if (detailCcy != null) {
				query = query + " AND p.ccy LIKE :detailCcy ";
				parameters.put("detailCcy", "%" + detailCcy + "%");
			}

			if (detailCcyDesc != null) {
				query = query + " AND p.ccyDesc LIKE :detailCcyDesc ";
				parameters.put("detailCcyDesc", "%" + detailCcyDesc + "%");
			}
			query = query + GlaJpeConstants.BATCH_MAINTENANCE_CURRENCY_LOV_QUERY_SUFFIX + " ORDER BY p.ccy";

			List<CurrencyJpe> list = dataService.findWithQuery(query, parameters, offset, limit, CurrencyJpe.class);

			for (Object o : list) {
				Object[] values = (Object[]) o;
				Currency bdo = jaxbSdoHelper.createSdoInstance(Currency.class);
				bdo.setCcy((String) values[0]);
				bdo.setCcyDesc((String) values[1]);
				result.add(bdo);
			}
			return result;
		}


	}

	@Override
	public List<Client> findClient(Map<String, Object> queryParams) {
		String detailBranch = (String) queryParams.get("branch");
		String detailCcy = (String) queryParams.get("ccy");
		String detailGlCode = (String) queryParams.get("glCode");
		String detailClientNo = (String) queryParams.get("clientNo");
		String detailGlType = (String) queryParams.get("detailGlType");
		String detailClientName = (String) queryParams.get("clientName");
		String autoIntAcctCreation = ctxMngrImpl.getBestAvailableContext().getRegistryEntry("GENERAL_LEDGER_REGISTRY", "autoIntAcctCreation");

		int limit = queryParams.get("limit") != null ? Integer.parseInt((String) queryParams.get("limit")) : 10;
		int offset = queryParams.get("offset") != null ? Integer.parseInt((String) queryParams.get("offset")) : 0;

		if(detailGlType == null) {
			Map<String, Object> glParams = new HashMap<>();
			glParams.put("glCode", detailGlCode);
			List<ChartAccountJpe> chartAccountJpeList = dataService.findWithNamedQuery(CsdJpeConstants.GLA_MANUAL_BATCH_DTL_GL_CODE_JPE_LOV_VALIDATION, glParams, ChartAccountJpe.class);
			if(chartAccountJpeList != null) {
				detailGlType = chartAccountJpeList.get(0).getGlType();
			}
		}

		if(autoIntAcctCreation != null && "Y".equalsIgnoreCase(autoIntAcctCreation) && "I".equalsIgnoreCase(detailGlType)) {

			Map<String, Object> params = new HashMap<>();
			if(detailClientNo != null) {
				params.put("clientNo", detailClientNo);
			}

			if(detailClientName != null) {
				params.put("clientName", detailClientName);
			}

			params.put("isFromLOV", true);
			params.put("status", "A");
			return clientService.query(offset,limit,"clientNo","clientNo", params);

		} else {
			String query = GlaJpeConstants.BATCH_MAINTENANCE_CLIENT_LOV_QUERY_PREFIX;

			List<Client> result = new ArrayList<>();
			final Map<String, Object> parameters = new HashMap<>();
			parameters.put("detailBranch", detailBranch);
			parameters.put("detailCcy", detailCcy);
			parameters.put("detailGlCode", detailGlCode);
			parameters.put("detailGlType", detailGlType);

			if (detailClientNo != null) {
				query = query + " AND p.clientNo LIKE :detailClientNo ";
				parameters.put("detailClientNo", "%" + detailClientNo + "%");
			}

			if (detailClientName != null) {
				query = query + " AND p.clientName LIKE :detailClientName ";
				parameters.put("detailClientName", "%" + detailClientName + "%");
			}
			query = query + GlaJpeConstants.BATCH_MAINTENANCE_CLIENT_LOV_QUERY_SUFFIX + " ORDER BY p.clientNo";

			List<ClientJpe> list = dataService.findWithQuery(query, parameters, offset, limit, ClientJpe.class);

			for (Object o : list) {
				Object[] values = (Object[]) o;
				Client bdo = jaxbSdoHelper.createSdoInstance(Client.class);
				bdo.setClientNo((String) values[0]);
				bdo.setClientName((String) values[1]);
				result.add(bdo);
			}
			return result;
		}


	}


	@Override
	public ManualBatchHdr submitToBpm(ManualBatchHdr bdo) {
		BpmTaskParamObject bpmObj = new BpmTaskParamObject();
		bpmObj.setInternalKey(bdo.getInternalKey());
		bpmObj.setBdo(bdo);
		bpmObj.setServiceOperation(SVC_OP_NAME_MANUALBATCHSERVICE_CREATE);
		bpmObj.setScreenUrl("/workspace/gla/detail-screen/batch-maintenance-detail/new");
		bpmObj.setActivityName("Batch Maintenance Create");
		bpmObj.setReferenceNo(bdo.getInternalKey() == null ? "new" : bdo.getInternalKey().toString());

		CbsBusinessDataObject submittedBdo = null;
		try {
			submittedBdo = createBpmTask(bpmObj);
		} catch (Exception e) {
			logger.error("Error encountered while submitting ManualBatchHdr to BPM");
			e.printStackTrace();
			throw new CbsRuntimeException(e);
		}

		return (ManualBatchHdr) submittedBdo;
	}

	private CbsBusinessDataObject createBpmTask(BpmTaskParamObject obj) throws Exception {
		CbsBusinessDataObject bdo = bpmServiceAdapter.createWorkItem(obj.getBdo(),
				CbsIntegrationConstants.PROPERTY_CBS_HEADER_BACKGROUND_RUNNER_USER_CODE, obj.getServiceOperation(),
				obj.getScreenUrl(), obj.getActivityName(), obj.getReferenceNo());

		Long processInstanceId = null;
		if (bdo != null && bdo.getHeader() != null && bdo.getHeader().getBpmInfo() != null) {
			processInstanceId = bdo.getHeader().getBpmInfo().getProcessInstanceId();
		}

		logger.info("Process Instance ID is {} for internalKey {}", processInstanceId, obj.getInternalKey());
		return bdo;
	}

	@Override
	public List<GlManualBatchGlCodeQry> findForBatchMaintenance(Map<String, Object> queryParams) {
		List<GlManualBatchGlCodeQry> result = new ArrayList<GlManualBatchGlCodeQry>();

		String detailBranch = (String) queryParams.get("detailBranch");
		String detailCcy = (String) queryParams.get("detailCcy");
		String glCode = (String) queryParams.get("glCode");
		String glCodeDesc = (String) queryParams.get("glCodeDesc");
		String glType = (String) queryParams.get("glType");
		String glCodeType = (String) queryParams.get("glCodeType");
		String bsplType = (String) queryParams.get("bsplType");

		int limit = queryParams.get("limit") != null ? Integer.parseInt((String)queryParams.get("limit")) : 10;
		int offset = queryParams.get("offset") != null ? Integer.parseInt((String)queryParams.get("offset")) : 0;
		String nativeQuery = null;

		String autoIntAcctCreation = ctxMngrImpl.getBestAvailableContext().getRegistryEntry("GENERAL_LEDGER_REGISTRY", "autoIntAcctCreation");
		final Map<String, Object> parameters = new HashMap<>();
		long orgId = cbsRuntimeContextManager.getContext(CbsSessionContext.class).getOrgId();
		parameters.put("org_id", orgId);
		parameters.put("detailBranch", detailBranch);
		parameters.put("detailCcy", detailCcy);

		if("N".equalsIgnoreCase(autoIntAcctCreation)) {
			nativeQuery = CsdJpeConstants.BATCH_MAINTENANCE_CHART_ACCT_LOV_QUERY_2;
			if (glCode != null) {
				nativeQuery = nativeQuery + " AND kgm.gl_code LIKE ?glCode";
				parameters.put("glCode", "%" + glCode + "%");
			}

			if (glCodeDesc != null) {
				nativeQuery = nativeQuery + " AND kgm.gl_code_desc LIKE ?glCodeDesc";
				parameters.put("glCodeDesc", "%" + glCodeDesc + "%");
			}

			if(glType != null) {
				nativeQuery = nativeQuery + " AND kgm.gl_type LIKE ?glType";
				parameters.put("glType", "%" + glType + "%");
			}

			if(glCodeType != null) {
				nativeQuery = nativeQuery + " AND kgm.gl_code_type LIKE ?glCodeType";
				parameters.put("glCodeType", "%" + glCodeType + "%");
			}

			if(bsplType != null) {
				nativeQuery = nativeQuery + " AND kgm.BSPL_TYPE LIKE ?bsplType";
				parameters.put("bsplType", "%" + bsplType + "%");
			}

			nativeQuery = nativeQuery + " ORDER BY kgm.gl_code";


			List<ChartAccountJpe> list = dataService.findWithNativeQuery(nativeQuery, parameters, offset, limit, ChartAccountJpe.class);
			for (ChartAccountJpe jpe : list) {
				GlManualBatchGlCodeQryJpe qryJpe = new GlManualBatchGlCodeQryJpe();
				qryJpe.setGlCode(jpe.getGlCode());
				qryJpe.setGlCodeDesc(jpe.getGlCode());
				qryJpe.setGlType(jpe.getGlType());
				qryJpe.setGlCodeType(jpe.getGlCodeType());
				qryJpe.setBsplType(jpe.getBsplType());
				result.add(jaxbSdoHelper.wrap(qryJpe));
			}
		} else {
			StringBuilder queryString = new StringBuilder();

			queryString = queryString.append(GlaJpeConstants.GLA_MANUAL_BATCH_GL_CODE_LOV_QUERY);
			if (glCode != null) {
				queryString.append(" AND g.gl_code LIKE ?glCode");
				parameters.put("glCode", "%" + glCode + "%");
			}

			if (glCodeDesc != null) {
				queryString.append(" AND g.gl_Code_Desc LIKE ?glCodeDesc");
				parameters.put("glCodeDesc", "%" + glCodeDesc + "%");
			}

			if(glType != null) {
				queryString.append(" AND g.gl_Type LIKE ?glType");
				parameters.put("glType", "%" + glType + "%");
			}

			if(glCodeType != null) {
				queryString.append(" AND g.gl_code_type LIKE ?glCodeType");
				parameters.put("glCodeType", "%" + glCodeType + "%");
			}

			if(bsplType != null) {
				queryString.append(" AND g.bspl_Type LIKE ?bsplType");
				parameters.put("bsplType", "%" + bsplType + "%");
			}

			List<GlManualBatchGlCodeQryJpe> manualBatchGlCodeQryJpeList = dataService.findWithNativeQuery(queryString.toString(), parameters, offset, limit, GlManualBatchGlCodeQryJpe.class);

			if(manualBatchGlCodeQryJpeList != null) {
				for(GlManualBatchGlCodeQryJpe jpe : manualBatchGlCodeQryJpeList) {
					result.add(jaxbSdoHelper.wrap(jpe));
				}
			}
		}


		return result;
	}
}
