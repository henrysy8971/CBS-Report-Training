package com.silverlakesymmetri.cbs.gla.svc.mapper.mapping;

import com.silverlakesymmetri.cbs.commons.jpa.util.DateTimeHelper;
import com.silverlakesymmetri.cbs.gla.jpa.mapping.sdo.GlAccountingEntryDetailJpe;
import com.silverlakesymmetri.cbs.gla.xmlapi.GLAACCOUNTINGENTRYDETAILTYPEType;
import org.mapstruct.InheritInverseConfiguration;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Mappings;

@Mapper(uses={ DateTimeHelper.class})
public interface GlAcctgEntryDetailToGLAACCTGENTRYDTLTYPEMapper {
	
	@Mappings({
		@Mapping(source="tranKey", target="TRANKEY"),
		@Mapping(source="clientId", target="CLIENTID"),
		@Mapping(source="glCode", target="GLCODE"),
		@Mapping(source="seqNo", target="SEQNO"),
		@Mapping(source="profitCentre", target="PROFITCENTRE"),
		@Mapping(source="sourceType", target="SOURCETYPE"),
		@Mapping(source="tradeNo", target="TRADENO"),
		@Mapping(source="reference", target="REFERENCE"),
		@Mapping(source="narrative", target="NARRATIVE"),
		@Mapping(source="amount", target="AMOUNT"),
		@Mapping(source="reversal", target="REVERSAL"),
		@Mapping(source="baseEffectRate", target="BASEEFFECTRATE"),
		@Mapping(source="baseQuote", target="BASEQUOTE"),
		@Mapping(source="baseEquiv", target="BASEEQUIV"),
		@Mapping(source="localEffectRate", target="LOCALEFFECTRATE"),
		@Mapping(source="localQuote", target="LOCALQUOTE"),
		@Mapping(source="localEquiv", target="LOCALEQUIV")
	})
	public GLAACCOUNTINGENTRYDETAILTYPEType mapToApi(GlAccountingEntryDetailJpe jpe);

	@InheritInverseConfiguration(name = "mapToApi")
	public GlAccountingEntryDetailJpe mapToJpe(GLAACCOUNTINGENTRYDETAILTYPEType api);
}
