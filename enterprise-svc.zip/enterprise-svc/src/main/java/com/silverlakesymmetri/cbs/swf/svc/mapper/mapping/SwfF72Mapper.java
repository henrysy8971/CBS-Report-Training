package com.silverlakesymmetri.cbs.swf.svc.mapper.mapping;

import org.apache.commons.lang3.StringUtils;
import org.mapstruct.DecoratedWith;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Mappings;

import com.silverlakesymmetri.cbs.swf.jpa.mapping.sdo.SwfF72Jpe;
import com.silverlakesymmetri.cbs.swf.svc.mapper.decorator.SwfF72MapperDecorator;
import com.silverlakesymmetri.cbs.swf.xmlapi.SWFF72TYPEType;

@Mapper(imports=StringUtils.class, uses = SwfSndrRcvrNarrativeMapper.class)
@DecoratedWith(SwfF72MapperDecorator.class)
public interface SwfF72Mapper {
	@Mappings({
		@Mapping(source="opt", target="OPT"),
		@Mapping(source="swfSndrRcvrNarrativeList", target="DETAILS.SWFSNDRRCVRNARRATIVETYPE")
	})
	SWFF72TYPEType mapToApi(SwfF72Jpe jpe);
	
	@Mappings({
		@Mapping(target="opt", expression="java(StringUtils.isNotBlank(api.getOPT())?api.getOPT():null)"),
		@Mapping(target="swfSndrRcvrNarrativeList", source="DETAILS.SWFSNDRRCVRNARRATIVETYPE")
	})
	SwfF72Jpe mapToJpe(SWFF72TYPEType api);
}