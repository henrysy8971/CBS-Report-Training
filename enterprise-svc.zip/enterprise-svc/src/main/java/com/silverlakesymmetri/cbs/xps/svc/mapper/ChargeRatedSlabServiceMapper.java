package com.silverlakesymmetri.cbs.xps.svc.mapper;

import org.mapstruct.DecoratedWith;
import org.mapstruct.InheritConfiguration;
import org.mapstruct.InheritInverseConfiguration;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingTarget;
import org.mapstruct.Mappings;

import com.silverlakesymmetri.cbs.commons.jpa.util.DateTimeHelper;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.RatedSlabJpe;
import com.silverlakesymmetri.cbs.xps.svc.mapper.decorator.ChargeRatedSlabServiceDecorator;
import com.silverlakesymmetri.cbs.xps.xmlapi.XPSTRANCHARGEDETAILSLABTYPEType;

@Mapper(uses = { DateTimeHelper.class })
@DecoratedWith(ChargeRatedSlabServiceDecorator.class)
public interface ChargeRatedSlabServiceMapper {

	@Mappings({
		@Mapping(source="balance", target = "BALANCE"),
		@Mapping(source="intBasis", target = "INTBASIS"),
		@Mapping(source="intBasisRate", target = "INTBASISRATE"),
		@Mapping(source="spreadRate", target = "SPREADRATE"),
		@Mapping(source="actualRate", target = "ACTUALRATE"),
		@Mapping(source="minAmt", target = "MINAMT"),
		@Mapping(source="maxAmt", target = "MAXAMT"),
		@Mapping(source="actualAmt", target = "ACTUALAMT"),
		@Mapping(source="calculatedAmt", target = "CALCULATEDAMT"),
		@Mapping(source="tranRateAmt", target = "TRANRATEAMT"),
		@Mapping(source="tranRateBalance", target = "TRANRATEBALANCE"),
		@Mapping(source="seqNo", target = "SEQNO"),
	})
	public XPSTRANCHARGEDETAILSLABTYPEType mapToApi(RatedSlabJpe jpe, @MappingTarget XPSTRANCHARGEDETAILSLABTYPEType api);

	@Mappings({
		@Mapping(source="balance", target = "BALANCE"),
		@Mapping(source="intBasis", target = "INTBASIS"),
		@Mapping(source="intBasisRate", target = "INTBASISRATE"),
		@Mapping(source="spreadRate", target = "SPREADRATE"),
		@Mapping(source="actualRate", target = "ACTUALRATE"),
		@Mapping(source="minAmt", target = "MINAMT"),
		@Mapping(source="maxAmt", target = "MAXAMT"),
		@Mapping(source="actualAmt", target = "ACTUALAMT"),
		@Mapping(source="calculatedAmt", target = "CALCULATEDAMT"),
		@Mapping(source="tranRateAmt", target = "TRANRATEAMT"),
		@Mapping(source="tranRateBalance", target = "TRANRATEBALANCE"),
		@Mapping(source="seqNo", target = "SEQNO"),
	})
	public XPSTRANCHARGEDETAILSLABTYPEType mapToApi(RatedSlabJpe jpe);

	@Mappings({
		@Mapping(target="balance", source = "BALANCE"),
		@Mapping(target="intBasis", source = "INTBASIS"),
		@Mapping(target="intBasisRate", source = "INTBASISRATE"),
		@Mapping(target="spreadRate", source = "SPREADRATE"),
		@Mapping(target="actualRate", source = "ACTUALRATE"),
		@Mapping(target="minAmt", source = "MINAMT"),
		@Mapping(target="maxAmt", source = "MAXAMT"),
		@Mapping(target="actualAmt", source = "ACTUALAMT"),
		@Mapping(target="calculatedAmt", source = "CALCULATEDAMT"),
		@Mapping(target="tranRateAmt", source = "TRANRATEAMT"),
		@Mapping(target="tranRateBalance", source = "TRANRATEBALANCE"),
		@Mapping(target="seqNo", source = "SEQNO"),
		@Mapping(target="relDetailKey", source = "RELDETAILKEY")
	})
	public RatedSlabJpe mapToJpe(XPSTRANCHARGEDETAILSLABTYPEType api, @MappingTarget RatedSlabJpe jpe);

	@Mappings({
		@Mapping(target="balance", source = "BALANCE"),
		@Mapping(target="intBasis", source = "INTBASIS"),
		@Mapping(target="intBasisRate", source = "INTBASISRATE"),
		@Mapping(target="spreadRate", source = "SPREADRATE"),
		@Mapping(target="actualRate", source = "ACTUALRATE"),
		@Mapping(target="minAmt", source = "MINAMT"),
		@Mapping(target="maxAmt", source = "MAXAMT"),
		@Mapping(target="actualAmt", source = "ACTUALAMT"),
		@Mapping(target="calculatedAmt", source = "CALCULATEDAMT"),
		@Mapping(target="tranRateAmt", source = "TRANRATEAMT"),
		@Mapping(target="tranRateBalance", source = "TRANRATEBALANCE"),
		@Mapping(target="seqNo", source = "SEQNO"),
		@Mapping(target="relDetailKey", source = "RELDETAILKEY")
	})
	public RatedSlabJpe mapToJpe(XPSTRANCHARGEDETAILSLABTYPEType api);

}