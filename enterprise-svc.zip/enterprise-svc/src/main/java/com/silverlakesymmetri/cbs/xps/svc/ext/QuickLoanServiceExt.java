package com.silverlakesymmetri.cbs.xps.svc.ext;

import com.silverlakesymmetri.cbs.xps.bdo.sdo.QuickLoan;

public interface QuickLoanServiceExt {
	
	public static final String QUICK_LOAN = "QUICK_LOAN";
	public static final String QUICK_LOAN_UTILITY = "QuickLoanServiceExt.facilitate";
	
    public String generateLoanNo(QuickLoan loan);
    
    public QuickLoan getQuickLoanReference(String loanNo);
    
}
