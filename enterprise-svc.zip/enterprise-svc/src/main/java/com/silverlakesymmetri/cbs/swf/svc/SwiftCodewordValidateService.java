package com.silverlakesymmetri.cbs.swf.svc;


import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation;
import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation.ServiceOperationType;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.svc.BusinessService;
import com.silverlakesymmetri.cbs.swf.bdo.sdo.SwiftCodewordValidate;
import com.silverlakesymmetri.cbs.swf.jpa.mapping.sdo.SwiftCodewordValidateJpe;

import java.util.List;
import java.util.Map;

public interface SwiftCodewordValidateService extends BusinessService<SwiftCodewordValidate, SwiftCodewordValidateJpe> {

    String SVC_OP_NAME_SWF_CODEWORD_VALIDATE_SERVICE_GET = "SwiftCodewordValidateService.get";
    String SVC_OP_NAME_SWF_CODEWORD_VALIDATE_SERVICE_QUERY = "SwiftCodewordValidateService.query";
    String SVC_OP_NAME_SWF_CODEWORD_VALIDATE_SERVICE_CREATE = "SwiftCodewordValidateService.create";
    String SVC_OP_NAME_SWF_CODEWORD_VALIDATE_SERVICE_UPDATE = "SwiftCodewordValidateService.update";
    String SVC_OP_NAME_SWF_CODEWORD_VALIDATE_SERVICE_DELETE = "SwiftCodewordValidateService.delete";
    String SVC_OP_NAME_SWF_CODEWORD_VALIDATE_SERVICE_FIND = "SwiftCodewordValidateService.find";

    @ServiceOperation(name = SVC_OP_NAME_SWF_CODEWORD_VALIDATE_SERVICE_GET, type = ServiceOperationType.GET)
    SwiftCodewordValidate getByPk(String publicKey, SwiftCodewordValidate reference);

    @ServiceOperation(name = SVC_OP_NAME_SWF_CODEWORD_VALIDATE_SERVICE_CREATE)
    SwiftCodewordValidate create(SwiftCodewordValidate dataObject);

    @ServiceOperation(name = SVC_OP_NAME_SWF_CODEWORD_VALIDATE_SERVICE_UPDATE)
    SwiftCodewordValidate update(SwiftCodewordValidate dataObject);

    @ServiceOperation(name = SVC_OP_NAME_SWF_CODEWORD_VALIDATE_SERVICE_QUERY)
    List<SwiftCodewordValidate> query(int offset, int resultLimit, String groupBy, String order, Map<String, Object> filters);

    @ServiceOperation(name = SVC_OP_NAME_SWF_CODEWORD_VALIDATE_SERVICE_DELETE)
    boolean delete(SwiftCodewordValidate dataObject);

    @ServiceOperation(name = SVC_OP_NAME_SWF_CODEWORD_VALIDATE_SERVICE_FIND)
    List<SwiftCodewordValidate> find(FindCriteria findCriteria, CbsHeader cbsHeader);

}
