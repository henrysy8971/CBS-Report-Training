package com.silverlakesymmetri.cbs.xps.svc.mapper.decorator;

import java.util.ArrayList;
import java.util.List;

import org.mapstruct.Context;
import org.mapstruct.MappingTarget;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

import com.silverlakesymmetri.cbs.commons.xmlapi.enums.CbsXmlApiOperation;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.ChargeDetailsJpe;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.ChargeMasterJpe;
import com.silverlakesymmetri.cbs.xps.svc.mapper.ChargeDefaultsServiceMapper;
import com.silverlakesymmetri.cbs.xps.svc.mapper.ChargeDetailServiceMapper;
import com.silverlakesymmetri.cbs.xps.xmlapi.XPSCHARGEGETPRODDEFAULTDETAILSAPIType;
import com.silverlakesymmetri.cbs.xps.xmlapi.XPSTRANCHARGEDETAILAPIType;

public abstract class ChargeDefaultsServiceDecorator implements ChargeDefaultsServiceMapper {
	
	@Autowired
	@Qualifier("delegate")
	protected ChargeDefaultsServiceMapper delegate;

	@Autowired
	protected ChargeDetailServiceMapper detailMapper;

	@Override
	public XPSCHARGEGETPRODDEFAULTDETAILSAPIType mapToApi(ChargeMasterJpe jpe, @Context CbsXmlApiOperation oper){
		XPSCHARGEGETPRODDEFAULTDETAILSAPIType req = (XPSCHARGEGETPRODDEFAULTDETAILSAPIType) delegate.mapToApi(jpe, oper);
		return  req;
	}
	
	@Override
	public ChargeMasterJpe mapToJpe(XPSCHARGEGETPRODDEFAULTDETAILSAPIType api, @MappingTarget ChargeMasterJpe jpe){
		if (api == null) {
			return null;
		}

		delegate.mapToJpe(api, jpe);
		List<ChargeDetailsJpe> detailsList = new ArrayList<ChargeDetailsJpe>();
		if(api.getDEFAULTDETAILS() != null && api.getDEFAULTDETAILS().getXPSTRANCHARGEDETAILAPI().size() > 0){
			for(XPSTRANCHARGEDETAILAPIType detailApi : api.getDEFAULTDETAILS().getXPSTRANCHARGEDETAILAPI()){
				ChargeDetailsJpe detailsJpe = new ChargeDetailsJpe();
				detailsJpe = detailMapper.mapToJpe(detailApi, detailsJpe);
				detailsList.add(detailsJpe);
			}
		}
		jpe.setChargeDetailsList(detailsList);
		return jpe;
	}

}


