package com.silverlakesymmetri.cbs.xps.svc;

import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation;
import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation.ServiceOperationType;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.svc.BusinessService;
import com.silverlakesymmetri.cbs.xps.bdo.sdo.CommonOnlineAcctgEntriesQry;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.CommonOnlineAcctgEntriesQryJpe;

import java.util.List;
import java.util.Map;

public interface CommonOnlineAcctgEntriesQryService extends BusinessService<CommonOnlineAcctgEntriesQry, CommonOnlineAcctgEntriesQryJpe> {
	public static final String XPS_COMMONONLINEACCTGENTRIESQRYSERVICE_GET = "CommonOnlineAcctgEntriesQryService.get";
    public static final String XPS_COMMONONLINEACCTGENTRIESQRYSERVICE_FIND = "CommonOnlineAcctgEntriesQryService.find";
    public static final String XPS_COMMONONLINEACCTGENTRIESQRYSERVICE_QUERY = "CommonOnlineAcctgEntriesQryService.query";
    public static final String XPS_COMMONONLINEACCTGENTRIESQRYSERVICE_COUNT = "CommonOnlineAcctgEntriesQryService.count";
    
    @ServiceOperation(name = XPS_COMMONONLINEACCTGENTRIESQRYSERVICE_GET, type = ServiceOperationType.GET)
    public CommonOnlineAcctgEntriesQry getByPk(String publicKey, CommonOnlineAcctgEntriesQry reference);

    @ServiceOperation(name = XPS_COMMONONLINEACCTGENTRIESQRYSERVICE_FIND)
    public List<CommonOnlineAcctgEntriesQry> find(FindCriteria findCriteria, CbsHeader cbsHeader);
    
    @ServiceOperation(name = XPS_COMMONONLINEACCTGENTRIESQRYSERVICE_QUERY)
    public List<CommonOnlineAcctgEntriesQry> query(int offset, int resultLimit, String groupBy, String order, Map<String, Object> filters);

    @ServiceOperation(name = XPS_COMMONONLINEACCTGENTRIESQRYSERVICE_COUNT, type = ServiceOperationType.GET)
    public Long count(FindCriteria findCriteria, CbsHeader cbsHeader);

}