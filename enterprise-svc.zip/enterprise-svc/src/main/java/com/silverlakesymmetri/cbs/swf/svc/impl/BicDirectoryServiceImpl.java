package com.silverlakesymmetri.cbs.swf.svc.impl;

import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.mysema.query.types.EntityPath;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.svc.AbstractBusinessService;
import com.silverlakesymmetri.cbs.commons.svc.BusinessObjectValidationCapable;
import com.silverlakesymmetri.cbs.swf.bdo.sdo.BicDirectory;
import com.silverlakesymmetri.cbs.swf.jpa.mapping.sdo.BicDirectoryJpe;
import com.silverlakesymmetri.cbs.swf.svc.BicDirectoryService;
import com.silverlakesymmetri.cbs.swf.jpa.mapping.sdo.QBicDirectoryJpe;
import commonj.sdo.ChangeSummary;
import commonj.sdo.ChangeSummary.Setting;
import commonj.sdo.DataObject;

@Service
@Transactional
public class BicDirectoryServiceImpl extends AbstractBusinessService<BicDirectory, BicDirectoryJpe, String>
        implements BicDirectoryService, BusinessObjectValidationCapable<BicDirectory> {

    @Override
    protected String getIdFromDataObjectInstance(BicDirectory dataObject) {
        return dataObject.getBic();
    }

    @Override
    protected EntityPath<BicDirectoryJpe> getEntityPath() {
        return QBicDirectoryJpe.bicDirectoryJpe;
    }

    @Override
    protected BicDirectory preCreateValidation(BicDirectory dataObject) {

        setDefaults(dataObject);
        return super.preCreateValidation(dataObject);
    }

    private void setDefaults(BicDirectory dataObject) {
        setDefaultAuthKey(dataObject);
    }

    private void setDefaultAuthKey(BicDirectory dataObject) {
        if (dataObject.getAuthKey() == null) {
            dataObject.setAuthKey("N");
        }
    }

    @Override
    public BicDirectory create(BicDirectory dataObject) {

        return super.create(dataObject);
    }

    @Override
    public BicDirectory get(BicDirectory objectInstanceIdentifier) {
        return super.get(objectInstanceIdentifier);
    }

    @Override
    public List<BicDirectory> query(int offset, int resultLimit, String groupBy, String order,
                                    Map<String, Object> filters) {
        return super.query(offset, resultLimit, groupBy, order, filters);
    }

    @Override
    public BicDirectory update(BicDirectory bdo) {
    	setClientIdToNull(bdo);
        return super.update(bdo);
    }

    @Override
    public boolean delete(BicDirectory dataObject) {
        return super.delete(dataObject);
    }

    @Override
    public List<BicDirectory> find(FindCriteria findCriteria, CbsHeader cbsHeader) {
        return super.find(findCriteria, cbsHeader);
    }

    @Override
    public BicDirectory getByPk(String publicKey, BicDirectory reference) {
        return super.getByPk(publicKey, reference);
    }
    
    private void setClientIdToNull(BicDirectory bdo){
    	boolean setClientToNull = false;
    	ChangeSummary cs = bdo.getChangeSummary();
    	if (cs != null && cs.getChangedDataObjects() != null && !cs.getChangedDataObjects().isEmpty()) {
    		for (Object object : cs.getChangedDataObjects()) {
    			if(cs.isModified((DataObject) object)) {
    				if(object instanceof BicDirectory){
    					DataObject obj = (DataObject) object; 
    					Setting oldSett = cs.getOldValue(obj, obj.getInstanceProperty("clientNo"));
    					if(oldSett!=null && oldSett.getValue()!=null && StringUtils.isBlank(bdo.getClientNo())){
    						setClientToNull = true;
    						break;
    					}
    				}
    			}
    		}
    	}
    	
    	if(setClientToNull){
    		BicDirectoryJpe jpe = jaxbSdoHelper.unwrap(bdo);
    		jpe.setClientId(null);
    		jpe.setClientNo(null);
    	}
    }

}
