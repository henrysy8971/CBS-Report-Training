package com.silverlakesymmetri.cbs.lpm.svc;


import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation;
import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation.ServiceOperationType;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.svc.BusinessService;
import com.silverlakesymmetri.cbs.lpm.bdo.sdo.LocalClearingDirectoryQry;
import com.silverlakesymmetri.cbs.lpm.jpa.mapping.sdo.LocalClearingDirectoryQryJpe;

import java.util.List;
import java.util.Map;

public interface LocalClearingDirectoryQryService extends BusinessService<LocalClearingDirectoryQry, LocalClearingDirectoryQryJpe> {

    String SVC_OP_NAME_LOCAL_CLEARING_DIRECTORY_SERVICE_GET = "LocalClearingDirectoryQryService.get";
    String SVC_OP_NAME_LOCAL_CLEARING_DIRECTORY_SERVICE_QUERY = "LocalClearingDirectoryQryService.query";
    String SVC_OP_NAME_LOCAL_CLEARING_DIRECTORY_SERVICE_FIND = "LocalClearingDirectoryQryService.find";

    @ServiceOperation(name = SVC_OP_NAME_LOCAL_CLEARING_DIRECTORY_SERVICE_GET, type = ServiceOperationType.GET)
    LocalClearingDirectoryQry getByPk(String publicKey, LocalClearingDirectoryQry reference);

    @ServiceOperation(name = SVC_OP_NAME_LOCAL_CLEARING_DIRECTORY_SERVICE_QUERY)
    List<LocalClearingDirectoryQry> query(int offset, int resultLimit, String groupBy, String order, Map<String, Object> filters);

    @ServiceOperation(name = SVC_OP_NAME_LOCAL_CLEARING_DIRECTORY_SERVICE_FIND)
    List<LocalClearingDirectoryQry> find(FindCriteria findCriteria, CbsHeader cbsHeader);

}
