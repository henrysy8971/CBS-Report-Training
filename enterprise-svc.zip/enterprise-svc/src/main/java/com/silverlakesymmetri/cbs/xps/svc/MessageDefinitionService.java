package com.silverlakesymmetri.cbs.xps.svc;


import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation;
import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation.ServiceOperationType;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.svc.BusinessService;
import com.silverlakesymmetri.cbs.xps.bdo.sdo.MessageDefinition;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.MessageDefinitionJpe;

import java.util.List;
import java.util.Map;

public interface MessageDefinitionService extends BusinessService<MessageDefinition, MessageDefinitionJpe> {

    String SVC_OP_NAME_MESSAGE_DEFINITION_SERVICE_GET = "MessageDefinitionService.get";
    String SVC_OP_NAME_MESSAGE_DEFINITION_SERVICE_QUERY = "MessageDefinitionService.query";
    String SVC_OP_NAME_MESSAGE_DEFINITION_SERVICE_FIND = "MessageDefinitionService.find";
    String SVC_OP_NAME_MESSAGE_DEFINITION_SERVICE_COUNT = "MessageDefinitionService.count";
    String SVC_OP_NAME_MESSAGE_DEFINITION_SERVICE_UPDATE = "MessageDefinitionService.update";

    @ServiceOperation(name = SVC_OP_NAME_MESSAGE_DEFINITION_SERVICE_GET, type = ServiceOperationType.GET)
    MessageDefinition getByPk(String publicKey, MessageDefinition reference);

    @ServiceOperation(name = SVC_OP_NAME_MESSAGE_DEFINITION_SERVICE_QUERY)
    List<MessageDefinition> query(int offset, int resultLimit, String groupBy, String order, Map<String, Object> filters);

    @ServiceOperation(name = SVC_OP_NAME_MESSAGE_DEFINITION_SERVICE_FIND)
    List<MessageDefinition> find(FindCriteria findCriteria, CbsHeader cbsHeader);

    @ServiceOperation(name = SVC_OP_NAME_MESSAGE_DEFINITION_SERVICE_COUNT, type = ServiceOperationType.GET)
    public Long count(FindCriteria findCriteria, CbsHeader cbsHeader);

    @ServiceOperation(name = SVC_OP_NAME_MESSAGE_DEFINITION_SERVICE_UPDATE)
    public MessageDefinition update(MessageDefinition dataObject);

}
