package com.silverlakesymmetri.cbs.swf.svc.mapper.mapping;

import org.apache.commons.lang3.StringUtils;
import org.mapstruct.DecoratedWith;
import org.mapstruct.InheritInverseConfiguration;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Mappings;

import com.silverlakesymmetri.cbs.commons.jpa.util.DateTimeHelper;
import com.silverlakesymmetri.cbs.swf.jpa.mapping.sdo.SwfF33Jpe;
import com.silverlakesymmetri.cbs.swf.svc.mapper.decorator.SwfF33MapperDecorator;
import com.silverlakesymmetri.cbs.swf.xmlapi.SWFF33TYPEType;

@Mapper(imports=StringUtils.class, uses={DateTimeHelper.class})
@DecoratedWith(SwfF33MapperDecorator.class)
public interface SwfF33Mapper {
	@Mappings({
		@Mapping(source="opt", target="OPT"),
		@Mapping(source="valueDate", target="VALUEDATE", qualifiedByName = {"DateTimeHelper","convertDateToCbsXmlApiDate"}),
		@Mapping(source="currency", target="CURRENCY"),
		@Mapping(source="amount", target="AMOUNT"),
		
	})
	SWFF33TYPEType mapToApi(SwfF33Jpe jpe);
	
	@InheritInverseConfiguration(name = "mapToApi")
	@Mappings({
		@Mapping(target="opt", expression="java(StringUtils.isNotBlank(api.getOPT())?api.getOPT():null)"),
		@Mapping(target="valueDate", source="VALUEDATE", qualifiedByName = { "DateTimeHelper", "convertCbsApiDateToString" }),
		@Mapping(target="currency", expression="java(StringUtils.isNotBlank(api.getCURRENCY())?api.getCURRENCY():null)"),
		@Mapping(target="amount", source="AMOUNT"),
	})
	SwfF33Jpe mapToJpe(SWFF33TYPEType api);
}