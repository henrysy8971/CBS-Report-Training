package com.silverlakesymmetri.cbs.xps.svc.mapper;

import org.mapstruct.Context;
import org.mapstruct.DecoratedWith;
import org.mapstruct.InheritInverseConfiguration;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingTarget;
import org.mapstruct.Mappings;

import com.silverlakesymmetri.cbs.commons.jpa.util.DateTimeHelper;
import com.silverlakesymmetri.cbs.commons.xmlapi.enums.CbsXmlApiOperation;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.RecurringChargeMasterJpe;
import com.silverlakesymmetri.cbs.xps.svc.mapper.decorator.RecurringChargeMasterServiceDecorator;
import com.silverlakesymmetri.cbs.xps.svc.mapper.mapping.XpsMessageJpeToXPSMESSAGETYPETypeMapper;
import com.silverlakesymmetri.cbs.xps.xmlapi.XPSTRANCHARGESCHEDAPIType;

@Mapper(uses={ DateTimeHelper.class, 
			XpsMessageJpeToXPSMESSAGETYPETypeMapper.class, 
			ChargeSettlementDetailsServiceMapper.class})
@DecoratedWith(RecurringChargeMasterServiceDecorator.class)
public interface RecurringChargeMasterServiceMapper {
	@Mappings({
		@Mapping(expression = "java(oper != null ? oper.getOperation() : null)", target="OPERATION"),
		@Mapping(source="domain", target = "DOMAIN"),
		@Mapping(source="internalKey", target = "INTERNALKEY"),
		@Mapping(source="tranKey", target = "TRANKEY"),
		@Mapping(source="seqNo", target = "SEQNO"),
		@Mapping(source="instrumentType", target = "INSTRUMENTTYPE"),
		@Mapping(source="payRec", target = "PAYREC"),
		@Mapping(source="bookBranch", target = "BOOKBRANCH"),
		@Mapping(source="profitCentre", target = "PROFITCENTRE"),
		@Mapping(source="partyCharged", target = "PARTYCHARGED"),
		@Mapping(source="partyClientId", target = "PARTYCLIENTID"),
		@Mapping(source="partyContactRefNo", target = "PARTYCONTACTREFNO"),
		@Mapping(source="partyContactAddress", target = "PARTYCONTACTADDRESS"),
		@Mapping(source="tranStatus", target = "TRANSTATUS"),
		@Mapping(source="eventType", target = "EVENTTYPE"),
		@Mapping(source="eventSeq", target = "EVENTSEQ"),
		@Mapping(source="attached", target = "ATTACHED"),
		@Mapping(source="attachedKey", target = "ATTACHEDKEY"),
		@Mapping(source="remarks", target = "REMARKS"),
		@Mapping(source="ccy", target = "CCY"),
		@Mapping(source="amount", target = "AMOUNT"),
		@Mapping(source="endOnExpiry", target = "ENDONEXPIRY"),
		@Mapping(source="frequency", target = "FREQUENCY"),
		@Mapping(source="day", target = "DAY"),
		@Mapping(source="periodYearStartInd", target = "PERIODYEARSTARTIND"),
		@Mapping(source="endDate", target = "ENDDATE", qualifiedByName = {"DateTimeHelper", "convertDateToCbsXmlApiDate"}),
		@Mapping(source="firstDate", target = "FIRSTDATE", qualifiedByName = {"DateTimeHelper", "convertDateToCbsXmlApiDate"}),
		@Mapping(source="nextDate", target = "NEXTDATE", qualifiedByName = {"DateTimeHelper", "convertDateToCbsXmlApiDate"}),
		@Mapping(source="previousDate", target = "PREVIOUSDATE", qualifiedByName = {"DateTimeHelper", "convertDateToCbsXmlApiDate"}),
		@Mapping(source="messageStructList", target = "MESSAGELIST.XPSMESSAGETYPE"),
		@Mapping(source="settleMessageStructList", target = "SETTLEMESSAGELIST.XPSMESSAGETYPE"),
		@Mapping(source="chargeSettleDetailsList", target = "SETTLEMENTDETAILS.XPSTRANCHARGESETTLEDETAILAPI")
	})
	public XPSTRANCHARGESCHEDAPIType mapToApi(RecurringChargeMasterJpe jpe, @Context CbsXmlApiOperation oper);

	@InheritInverseConfiguration(name = "mapToApi")
	@Mappings({
		@Mapping(source="FIRSTDATE", target="firstDate", qualifiedByName = {"DateTimeHelper", "convertCbsApiDateToString"}),
		@Mapping(source="ENDDATE", target="endDate", qualifiedByName = {"DateTimeHelper", "convertCbsApiDateToString"}),
		@Mapping(source="NEXTDATE", target="nextDate", qualifiedByName = {"DateTimeHelper", "convertCbsApiDateToString"}),
		@Mapping(source="PREVIOUSDATE", target="previousDate", qualifiedByName = {"DateTimeHelper", "convertCbsApiDateToString"})
	})
	public RecurringChargeMasterJpe mapToJpe(XPSTRANCHARGESCHEDAPIType api, @MappingTarget RecurringChargeMasterJpe jpe);
	
	@InheritInverseConfiguration(name = "mapToApi")
	@Mappings({
		@Mapping(source="FIRSTDATE", target="firstDate", qualifiedByName = {"DateTimeHelper", "convertCbsApiDateToString"}),
		@Mapping(source="ENDDATE", target="endDate", qualifiedByName = {"DateTimeHelper", "convertCbsApiDateToString"}),
		@Mapping(source="NEXTDATE", target="nextDate", qualifiedByName = {"DateTimeHelper", "convertCbsApiDateToString"}),
		@Mapping(source="PREVIOUSDATE", target="previousDate", qualifiedByName = {"DateTimeHelper", "convertCbsApiDateToString"})
	})
	public RecurringChargeMasterJpe mapToJpe(XPSTRANCHARGESCHEDAPIType api);
}
