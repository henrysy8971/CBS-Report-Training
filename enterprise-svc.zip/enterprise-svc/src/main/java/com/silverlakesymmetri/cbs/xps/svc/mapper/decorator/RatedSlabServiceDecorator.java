package com.silverlakesymmetri.cbs.xps.svc.mapper.decorator;

import org.mapstruct.Context;
import org.mapstruct.MappingTarget;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

import com.silverlakesymmetri.cbs.commons.xmlapi.enums.CbsXmlApiOperation;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.RatedSlabJpe;
import com.silverlakesymmetri.cbs.xps.svc.mapper.RatedSlabServiceMapper;
import com.silverlakesymmetri.cbs.xps.xmlapi.XPSCHARGESLABTYPEType;

public abstract class RatedSlabServiceDecorator implements RatedSlabServiceMapper {
	
	@Autowired
	@Qualifier("delegate")
	protected RatedSlabServiceMapper delegate;

	@Override
	public XPSCHARGESLABTYPEType mapToApi(RatedSlabJpe jpe, @Context CbsXmlApiOperation oper){
		XPSCHARGESLABTYPEType req = (XPSCHARGESLABTYPEType) delegate.mapToApi(jpe, oper);
		return  req;
	}
	
	@Override
	public RatedSlabJpe mapToJpe(XPSCHARGESLABTYPEType api, @MappingTarget RatedSlabJpe jpe){
		delegate.mapToJpe(api, jpe);
		return jpe;
	}

}


