package com.silverlakesymmetri.cbs.gla.svc;

public interface NostroCashFlowService {

}
