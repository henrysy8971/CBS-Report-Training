package com.silverlakesymmetri.cbs.gla.svc.impl;

import com.mysema.query.types.EntityPath;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.svc.AbstractBusinessService;
import com.silverlakesymmetri.cbs.gla.bdo.sdo.GlManualBatchGlCodeQry;
import com.silverlakesymmetri.cbs.gla.jpa.mapping.sdo.GlManualBatchGlCodeQryJpe;
import com.silverlakesymmetri.cbs.gla.jpa.mapping.sdo.QGlManualBatchGlCodeQryJpe;
import com.silverlakesymmetri.cbs.gla.jpa.mapping.sdo.id.GlManualBatchGlCodeQryPk;
import com.silverlakesymmetri.cbs.gla.svc.GlAcctBalByGlKeysQryService;
import com.silverlakesymmetri.cbs.gla.svc.GlManualBatchGlCodeQryService;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;

@Service
public class GlManualBatchGlCodeQryServiceImpl extends AbstractBusinessService<GlManualBatchGlCodeQry, GlManualBatchGlCodeQryJpe, GlManualBatchGlCodeQryPk> implements
		GlManualBatchGlCodeQryService {
	

	@Override
	protected GlManualBatchGlCodeQryPk getIdFromDataObjectInstance(GlManualBatchGlCodeQry dataObject) {
		return new GlManualBatchGlCodeQryPk(dataObject.getGlCode());
	}

	@Override
	protected EntityPath<GlManualBatchGlCodeQryJpe> getEntityPath() {
		return QGlManualBatchGlCodeQryJpe.glManualBatchGlCodeQryJpe;
	}
	
	@Override
	public GlManualBatchGlCodeQry getByPk(String publicKey, GlManualBatchGlCodeQry dataObject) {
		return super.getByPk(publicKey, dataObject);
	}

	@Override
	public List<GlManualBatchGlCodeQry> query(int offset, int resultLimit, String groupBy, String order,
			Map<String, Object> filters) {
		return super.query(offset, resultLimit, groupBy, order, filters);
	}

	@Override
	public List<GlManualBatchGlCodeQry> find(FindCriteria findCriteria, CbsHeader cbsHeader) {
		return super.find(findCriteria, cbsHeader);
	}
	
	@Override
	public GlManualBatchGlCodeQry get(GlManualBatchGlCodeQry objectInstanceIdentifier) {
		return super.get(objectInstanceIdentifier);
	}

}
