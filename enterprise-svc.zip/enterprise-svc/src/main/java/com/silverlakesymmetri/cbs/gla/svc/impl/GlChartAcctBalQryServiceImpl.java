package com.silverlakesymmetri.cbs.gla.svc.impl;

import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import com.mysema.query.types.EntityPath;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.svc.AbstractBusinessService;
import com.silverlakesymmetri.cbs.commons.jpa.service.CbsEntityManagerAware;
import com.silverlakesymmetri.cbs.gla.bdo.sdo.GlChartAcctBalQry;
import com.silverlakesymmetri.cbs.gla.jpa.mapping.sdo.GlChartAcctBalQryJpe;
import com.silverlakesymmetri.cbs.gla.jpa.mapping.sdo.QGlChartAcctBalQryJpe;
import com.silverlakesymmetri.cbs.gla.jpa.mapping.sdo.id.GlChartAcctBalQryPk;
import com.silverlakesymmetri.cbs.gla.jpa.mapping.sdo.util.GlaJpeConstants;
import com.silverlakesymmetri.cbs.gla.svc.GlChartAcctBalQryService;

@Service
public class GlChartAcctBalQryServiceImpl extends AbstractBusinessService<GlChartAcctBalQry, GlChartAcctBalQryJpe, GlChartAcctBalQryPk> implements GlChartAcctBalQryService {

	private static final String CREDIT = "CR";
	private static final String DEBIT = "DR";
	private static final String CONTROL = "C";

	@Override
	protected GlChartAcctBalQryPk getIdFromDataObjectInstance(GlChartAcctBalQry dataObject) {
		return new GlChartAcctBalQryPk(dataObject.getGlCode());
	}

	@Override
	protected EntityPath<GlChartAcctBalQryJpe> getEntityPath() {
		return QGlChartAcctBalQryJpe.glChartAcctBalQryJpe;
	}
	
	@Override
	public GlChartAcctBalQry getByPk(String publicKey, GlChartAcctBalQry dataObject) {
        // same implentation as ExternalAccountStatementServiceImpl
		GlChartAcctBalQry glChartAcctBalQry = super.getByPk(publicKey, dataObject);

        if (glChartAcctBalQry != null) {
            ((CbsEntityManagerAware) dataService).getMyEntityManager().detach(unwrap(glChartAcctBalQry));

            Map<String, Object> params = new HashMap<>();
            List<GlChartAcctBalQryJpe> glChartAcctBalQryJpeList = null;

            if (glChartAcctBalQry != null) {
                if (CONTROL.equals(glChartAcctBalQry.getGlCodeType())) {
                    params.put("glCodeControl", glChartAcctBalQry.getGlCode());
                    glChartAcctBalQryJpeList = dataService.findWithNamedQuery(
                            GlaJpeConstants.GLA_CHART_ACCT_BAL_QRY_JPE_FIND_BY_GL_CODE_CONTROL, params,
                            GlChartAcctBalQryJpe.class);
                } else {
                    params.put("glCode", glChartAcctBalQry.getGlCode());
                    glChartAcctBalQryJpeList = dataService.findWithNamedQuery(
                            GlaJpeConstants.GLA_CHART_ACCT_BAL_QRY_JPE_FIND_BY_GL_CODE, params,
                            GlChartAcctBalQryJpe.class);
                }
                if (glChartAcctBalQryJpeList != null && glChartAcctBalQryJpeList.size() > 0) {
                    List<GlChartAcctBalQry> glChartAcctBalQryList = glChartAcctBalQryJpeList.stream()
                            .map(jpe -> jaxbSdoHelper.wrap(jpe, GlChartAcctBalQry.class)).collect(Collectors.toList());
                    glChartAcctBalQry.setGlChartAcctBalList(glChartAcctBalQryList);
                }
                calculateActualTotal(glChartAcctBalQry);
                calculateLedgerTotal(glChartAcctBalQry);
            }
        }    
		return glChartAcctBalQry;
	}

	
	@Override
	public List<GlChartAcctBalQry> query(int offset, int resultLimit, String groupBy, String order,
			Map<String, Object> filters) {
		return super.query(offset, resultLimit, groupBy, order, filters);
	}

	@Override
	public List<GlChartAcctBalQry> find(FindCriteria findCriteria, CbsHeader cbsHeader) {
		return super.find(findCriteria, cbsHeader);
	}
	
	@Override
	public GlChartAcctBalQry get(GlChartAcctBalQry objectInstanceIdentifier) {
		return super.get(objectInstanceIdentifier);
	}

	private void calculateActualTotal(GlChartAcctBalQry bdo) {
		Double totalActualAmt = Double.valueOf(0);
		
		if (bdo.getGlChartAcctBalList() != null ) {
			totalActualAmt = bdo.getGlChartAcctBalList()
				.stream()
				.map(glChartAcctBal -> 
							( CREDIT.equals(glChartAcctBal.getActualDrCr()) ? -glChartAcctBal.getActualBalAbs() : glChartAcctBal.getActualBalAbs()))
				.reduce(Double.valueOf(0), (subtotal, element) -> subtotal + element);

			bdo.setTotActualBal(Math.abs(totalActualAmt));
			if (!totalActualAmt.equals(Double.valueOf(0))) {
				bdo.setTotalActualDrCr((totalActualAmt > 0 ? DEBIT : CREDIT));
			}
		}
	
	}

	private void calculateLedgerTotal(GlChartAcctBalQry bdo) {
		Double totalLedgerAmt = Double.valueOf(0);

		if (bdo.getGlChartAcctBalList() != null) {
			totalLedgerAmt = bdo.getGlChartAcctBalList().stream()
					.map(glChartAcctBal -> (CREDIT.equals(glChartAcctBal.getLedgerDrCr())  ? -glChartAcctBal.getLedgerBalAbs()
							: glChartAcctBal.getLedgerBalAbs()))
					.reduce(Double.valueOf(0), (subtotal, element) -> subtotal + element);

			bdo.setTotLedgerBal(Math.abs(totalLedgerAmt));
			if (!totalLedgerAmt.equals(Double.valueOf(0))) {
				bdo.setTotalLedgerDrCr((totalLedgerAmt > 0 ? DEBIT : CREDIT));
			}
		}

	}

}
