package com.silverlakesymmetri.cbs.xps.svc;

import java.util.List;
import java.util.Map;

import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation;
import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation.ServiceOperationType;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.svc.BusinessService;
import com.silverlakesymmetri.cbs.xps.bdo.sdo.BdsBranchEodStatus;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.BdsBranchEodStatusJpe;

public interface BdsBranchEodStatusService extends BusinessService<BdsBranchEodStatus, BdsBranchEodStatusJpe> {

    public static final String SVC_OP_NAME_BDSBRANCHEODSTATUSSERVICE_GET = "bdsBranchEodStatusService.get";
    public static final String SVC_OP_NAME_BDSBRANCHEODSTATUSSERVICE_QUERY = "bdsBranchEodStatusService.query";
    public static final String SVC_OP_NAME_BDSBRANCHEODSTATUSSERVICE_FIND = "bdsBranchEodStatusService.find";
    public static final String SVC_OP_NAME_BDSBRANCHEODSTATUSSERVICE_UPDATE = "bdsBranchEodStatusService.update";

    @ServiceOperation(name = SVC_OP_NAME_BDSBRANCHEODSTATUSSERVICE_GET, type = ServiceOperationType.GET)
    public BdsBranchEodStatus getByPk(String publicKey, BdsBranchEodStatus reference);

    @ServiceOperation(name = SVC_OP_NAME_BDSBRANCHEODSTATUSSERVICE_QUERY)
    public List<BdsBranchEodStatus> query(int offset, int resultLimit, String groupBy, String order, Map<String, Object> filters);

    @ServiceOperation(name = SVC_OP_NAME_BDSBRANCHEODSTATUSSERVICE_FIND)
    public List<BdsBranchEodStatus> find(FindCriteria findCriteria, CbsHeader cbsHeader);

    @ServiceOperation(name = SVC_OP_NAME_BDSBRANCHEODSTATUSSERVICE_UPDATE)
    public BdsBranchEodStatus update(BdsBranchEodStatus dataObject);
}
