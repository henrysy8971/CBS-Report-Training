package com.silverlakesymmetri.cbs.xps.svc.impl;

import com.mysema.query.types.EntityPath;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.svc.AbstractBusinessService;
import com.silverlakesymmetri.cbs.commons.svc.BusinessObjectValidationCapable;
import com.silverlakesymmetri.cbs.xps.bdo.sdo.InwTranMapOut;
import com.silverlakesymmetri.cbs.xps.bdo.sdo.InwTranMapOutCcy;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.InwTranMapOutJpe;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.QInwTranMapOutJpe;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.id.InwTranMapOutPk;
import com.silverlakesymmetri.cbs.xps.svc.InwTranMapOutService;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

@Service
@Transactional
public class InwTranMapOutServiceImpl extends AbstractBusinessService<InwTranMapOut, InwTranMapOutJpe, InwTranMapOutPk> 
		implements InwTranMapOutService, BusinessObjectValidationCapable<InwTranMapOut> {

	@Override
	protected InwTranMapOutPk getIdFromDataObjectInstance(InwTranMapOut dataObject) {
		return new InwTranMapOutPk(dataObject.getInternalKey());
	}

	@Override
	protected EntityPath<InwTranMapOutJpe> getEntityPath() {
		return QInwTranMapOutJpe.inwTranMapOutJpe;
	}

	@Override
	public InwTranMapOut getByPk(String publicKey, InwTranMapOut reference) {
		return super.getByPk(publicKey, reference);
	}
	
	@Override
	public List<InwTranMapOut> query(int offset, int resultLimit, String groupBy, String order, Map<String, Object> filters) {
		return super.query(offset, resultLimit, groupBy, order, filters);
	}
	
	@Override
	public List<InwTranMapOut> find(FindCriteria findCriteria, CbsHeader cbsHeader){
		return super.find(findCriteria, cbsHeader);
	}

	@Override
	protected InwTranMapOut preUpdateValidation(InwTranMapOut dataObject) {
		return super.preUpdateValidation(setDefaults(dataObject));
	}

	@Override
	protected InwTranMapOut preCreateValidation(InwTranMapOut dataObject) {
		return super.preCreateValidation(setDefaults(dataObject));
	}

	@Override
	public InwTranMapOut create(InwTranMapOut dataObject) {
		return super.create(setDefaults(dataObject));
	}
	
	@Override
	public InwTranMapOut update(InwTranMapOut dataObject) {
		return super.update(dataObject);
	}
	
	@Override
	public boolean delete(InwTranMapOut dataObject) {
		return super.delete(dataObject);
	}

	private InwTranMapOut setDefaults(InwTranMapOut inwTranMapOut) {
		if (StringUtils.isBlank(inwTranMapOut.getLimitEur())) {
			inwTranMapOut.setLimitEur("N");
		}

		if (StringUtils.isBlank(inwTranMapOut.getPmtRealization())) {
			inwTranMapOut.setPmtRealization("S");
		}

		if (StringUtils.isBlank(inwTranMapOut.getUrgencyLevel())) {
			inwTranMapOut.setUrgencyLevel("0");
		}

		if (StringUtils.isBlank(inwTranMapOut.getDetailsOfChrgOur())) {
			inwTranMapOut.setDetailsOfChrgOur("N");
		}

		if (StringUtils.isBlank(inwTranMapOut.getDetailsOfChrgBen())) {
			inwTranMapOut.setDetailsOfChrgBen("N");
		}

		if (StringUtils.isBlank(inwTranMapOut.getDetailsOfChrgSha())) {
			inwTranMapOut.setDetailsOfChrgSha("Y");
		}

		if (StringUtils.isBlank(inwTranMapOut.getInsertTransfer())) {
			inwTranMapOut.setInsertTransfer("N");
		}

		if (StringUtils.isBlank(inwTranMapOut.getCcyInd())) {
			inwTranMapOut.setInwTranMapOutCcyList(new ArrayList<InwTranMapOutCcy>());
		}

		return inwTranMapOut;
	}
}
