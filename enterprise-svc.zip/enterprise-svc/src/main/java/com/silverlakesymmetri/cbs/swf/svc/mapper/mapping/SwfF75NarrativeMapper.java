package com.silverlakesymmetri.cbs.swf.svc.mapper.mapping;

import org.mapstruct.InheritInverseConfiguration;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Mappings;

import com.silverlakesymmetri.cbs.swf.jpa.mapping.sdo.SwfF75NarrativeJpe;
import com.silverlakesymmetri.cbs.swf.xmlapi.SWFF75NARRATIVETYPEType;

@Mapper
public interface SwfF75NarrativeMapper {
	
	@Mappings({
		@Mapping(target="INDEX", source="index"),
		@Mapping(target="QUERYNO", source="queryNo"),
		@Mapping(target="SUPPLEMENT1", source="supplement1"),
		@Mapping(target="SUPPLEMENT2", source="supplement2")
	})
	SWFF75NARRATIVETYPEType mapToApi(SwfF75NarrativeJpe jpe);
	
	@InheritInverseConfiguration(name = "mapToApi")
	SwfF75NarrativeJpe mapToJpe(SWFF75NARRATIVETYPEType api);

}