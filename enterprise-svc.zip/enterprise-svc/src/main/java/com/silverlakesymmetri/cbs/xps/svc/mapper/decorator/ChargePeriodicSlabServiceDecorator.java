package com.silverlakesymmetri.cbs.xps.svc.mapper.decorator;

import java.util.ArrayList;

import org.mapstruct.MappingTarget;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.PeriodicSlabJpe;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.SlabRateJpe;
import com.silverlakesymmetri.cbs.xps.svc.mapper.ChargePeriodicSlabServiceMapper;
import com.silverlakesymmetri.cbs.xps.xmlapi.XPSTRANCHARGEDETAILSLABRATELISTTYPEType;
import com.silverlakesymmetri.cbs.xps.xmlapi.XPSTRANCHARGEDETAILSLABRATETYPEType;
import com.silverlakesymmetri.cbs.xps.xmlapi.XPSTRANCHARGEDETAILSLABTYPEType;

public abstract class ChargePeriodicSlabServiceDecorator implements ChargePeriodicSlabServiceMapper {
	
	@Autowired
	@Qualifier("delegate")
	protected ChargePeriodicSlabServiceMapper delegate;

	@Override
	public XPSTRANCHARGEDETAILSLABTYPEType mapToApi(PeriodicSlabJpe jpe, @MappingTarget XPSTRANCHARGEDETAILSLABTYPEType api){
		delegate.mapToApi(jpe, api);
		return commonMapToApi(jpe, api);
	}

	@Override
	public XPSTRANCHARGEDETAILSLABTYPEType mapToApi(PeriodicSlabJpe jpe){
		XPSTRANCHARGEDETAILSLABTYPEType api = delegate.mapToApi(jpe);
		return commonMapToApi(jpe, api);
	}
	
	@Override
	public PeriodicSlabJpe mapToJpe(XPSTRANCHARGEDETAILSLABTYPEType api, @MappingTarget PeriodicSlabJpe jpe){
		delegate.mapToJpe(api, jpe);
		return commonMapToJpe(api, jpe);
	}
	
	@Override
	public PeriodicSlabJpe mapToJpe(XPSTRANCHARGEDETAILSLABTYPEType api){
		PeriodicSlabJpe jpe = delegate.mapToJpe(api);
		return commonMapToJpe(api, jpe);
	}
	
	private XPSTRANCHARGEDETAILSLABTYPEType commonMapToApi(PeriodicSlabJpe jpe, XPSTRANCHARGEDETAILSLABTYPEType api){
		if(api.getRATES() == null) api.setRATES(new XPSTRANCHARGEDETAILSLABRATELISTTYPEType());
		for(int i = 0; i < 12; i++){
			Double setupRate = getSetupRate(i+1, jpe);
			XPSTRANCHARGEDETAILSLABRATETYPEType slabRate = new XPSTRANCHARGEDETAILSLABRATETYPEType();
			slabRate.setPERIODNO(new Double(i + 1));
			slabRate.setSETUPRATE(setupRate);
			switch(i){
			case 0: slabRate.setRATE(jpe.getRate01()); break;
			case 1: slabRate.setRATE(jpe.getRate02()); break;
			case 2: slabRate.setRATE(jpe.getRate03()); break;
			case 3: slabRate.setRATE(jpe.getRate04()); break;
			case 4: slabRate.setRATE(jpe.getRate05()); break;
			case 5: slabRate.setRATE(jpe.getRate06()); break;
			case 6: slabRate.setRATE(jpe.getRate07()); break;
			case 7: slabRate.setRATE(jpe.getRate08()); break;
			case 8: slabRate.setRATE(jpe.getRate09()); break;
			case 9: slabRate.setRATE(jpe.getRate10()); break;
			case 10: slabRate.setRATE(jpe.getRate11()); break;
			case 11: slabRate.setRATE(jpe.getRate12()); break;
			}
			api.getRATES().getXPSTRANCHARGEDETAILSLABRATETYPE().add(slabRate);
		}
		return api;
	}
	
	private Double getSetupRate(int periodNo, PeriodicSlabJpe jpe){
		if(jpe.getRates() != null && jpe.getRates().size() > 0){
			for(SlabRateJpe slabRate : jpe.getRates()){
				if(slabRate.getPeriodNo().intValue() == periodNo){
					return slabRate.getSetupRate();
				}
			}
		}
		return null;
	}
	
	private PeriodicSlabJpe commonMapToJpe(XPSTRANCHARGEDETAILSLABTYPEType api, PeriodicSlabJpe jpe){
		if(api.getRATES() != null){
			jpe.setRates(new ArrayList<SlabRateJpe>());
			for(int i = 0; i < api.getRATES().getXPSTRANCHARGEDETAILSLABRATETYPE().size(); i++){
				XPSTRANCHARGEDETAILSLABRATETYPEType slabRate = api.getRATES().getXPSTRANCHARGEDETAILSLABRATETYPE().get(i);
				switch(i){
				case 0: jpe.setRate01(slabRate.getRATE()); break;
				case 1: jpe.setRate02(slabRate.getRATE()); break;
				case 2: jpe.setRate03(slabRate.getRATE()); break;
				case 3: jpe.setRate04(slabRate.getRATE()); break;
				case 4: jpe.setRate05(slabRate.getRATE()); break;
				case 5: jpe.setRate06(slabRate.getRATE()); break;
				case 6: jpe.setRate07(slabRate.getRATE()); break;
				case 7: jpe.setRate08(slabRate.getRATE()); break;
				case 8: jpe.setRate09(slabRate.getRATE()); break;
				case 9: jpe.setRate10(slabRate.getRATE()); break;
				case 10: jpe.setRate11(slabRate.getRATE()); break;
				case 11: jpe.setRate12(slabRate.getRATE()); break;
				}
				SlabRateJpe slabRateJpe = new SlabRateJpe();
				slabRateJpe.setPeriodNo(new Double(i+1));
				slabRateJpe.setRate(slabRate.getRATE());
				slabRateJpe.setSetupRate(slabRate.getSETUPRATE());
				jpe.getRates().add(slabRateJpe);
			}
		}
		return jpe;
	}

}


