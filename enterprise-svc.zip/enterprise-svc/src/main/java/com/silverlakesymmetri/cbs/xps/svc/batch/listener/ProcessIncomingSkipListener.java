package com.silverlakesymmetri.cbs.xps.svc.batch.listener;

import com.silverlakesymmetri.cbs.commons.logging.CbsAppLogger;
import com.silverlakesymmetri.cbs.commons.logging.CbsAppLoggerFactory;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.IncomingMessageSwfJpe;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.MessageMasterJpe;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.util.XpsJpeConstants;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

public class ProcessIncomingSkipListener extends IncomingMessageBaseSkipListener<IncomingMessageSwfJpe> {

	private static CbsAppLogger logger = CbsAppLoggerFactory.getLogger(ProcessIncomingSkipListener.class);

	@Override
	protected void doBulkUpdate(String newStatus, Object internalKey) {
		if (logger.isDebugEnabled()) {
			logger.debug("Following keys {} will be updated to {}", internalKey, newStatus);
		}

		Map<String, Object> params = new HashMap<>();
		params.put("status", newStatus);
		params.put("keys", Arrays.asList((Long) internalKey));
		batchDataService.bulkUpdateWithNamedQuery(XpsJpeConstants.MESSAGE_MASTER_JPE_UPDATE_STATUS_ERROR, params,
				MessageMasterJpe.class);
	}

	@Override
	protected Object getUniqueId(IncomingMessageSwfJpe item) {
		return item.getInternalKey();
	}
}
