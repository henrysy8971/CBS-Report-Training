package com.silverlakesymmetri.cbs.xps.svc;

import java.util.List;
import java.util.Map;

import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation;
import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation.ServiceOperationType;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.svc.BusinessService;
import com.silverlakesymmetri.cbs.xps.bdo.sdo.PeriodicCharge;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.PeriodicChargeJpe;

public interface PeriodicChargeService extends BusinessService<PeriodicCharge, PeriodicChargeJpe> {
	public static final String SVC_OP_NAME_PERIODICCHARGESERVICE_GET = "PeriodicChargeService.get";
    public static final String SVC_OP_NAME_PERIODICCHARGESERVICE_QUERY = "PeriodicChargeService.query";
    public static final String SVC_OP_NAME_PERIODICCHARGESERVICE_CREATE = "PeriodicChargeService.create";
    public static final String SVC_OP_NAME_PERIODICCHARGESERVICE_UPDATE = "PeriodicChargeService.update";
    public static final String SVC_OP_NAME_PERIODICCHARGESERVICE_DELETE = "PeriodicChargeService.delete";
    public static final String SVC_OP_NAME_PERIODICCHARGESERVICE_FIND = "PeriodicChargeService.find";
    public static final String SVC_OP_NAME_PERIODICCHARGESERVICE_COUNT = "PeriodicChargeService.count";

    @ServiceOperation(name=SVC_OP_NAME_PERIODICCHARGESERVICE_GET, type = ServiceOperationType.GET)
    public PeriodicCharge getByPk(String publicKey, PeriodicCharge reference);
	
    @ServiceOperation(name = SVC_OP_NAME_PERIODICCHARGESERVICE_QUERY)
    public List<PeriodicCharge> query(int offset, int resultLimit, String groupBy, String order, Map<String, Object> filters);
 
    @ServiceOperation(name = SVC_OP_NAME_PERIODICCHARGESERVICE_CREATE)
    public PeriodicCharge create(PeriodicCharge dataObject);
     
    @ServiceOperation(name = SVC_OP_NAME_PERIODICCHARGESERVICE_UPDATE)
    public PeriodicCharge update(PeriodicCharge dataObject);
	
    @ServiceOperation(name = SVC_OP_NAME_PERIODICCHARGESERVICE_DELETE)
    public boolean delete(PeriodicCharge dataObject);
	
    @ServiceOperation(name = SVC_OP_NAME_PERIODICCHARGESERVICE_FIND)
    public List<PeriodicCharge> find(FindCriteria findCriteria, CbsHeader cbsHeader);

    @ServiceOperation(name = SVC_OP_NAME_PERIODICCHARGESERVICE_COUNT, type = ServiceOperationType.GET)
    public Long count(FindCriteria findCriteria, CbsHeader cbsHeader);
}
