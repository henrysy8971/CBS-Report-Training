package com.silverlakesymmetri.cbs.xps.svc.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.mysema.query.types.EntityPath;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.svc.AbstractBusinessService;
import com.silverlakesymmetri.cbs.xps.bdo.sdo.MarginAmendment;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.MarginAmendmentJpe;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.QMarginAmendmentJpe;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.util.XpsJpeConstants;
import com.silverlakesymmetri.cbs.xps.svc.MarginAmendmentService;

@Service
@Transactional
public class MarginAmendmentServiceImpl extends AbstractBusinessService<MarginAmendment, MarginAmendmentJpe, Long> 
	implements MarginAmendmentService {
	
	@Override
	protected Long getIdFromDataObjectInstance(MarginAmendment dataObject) {
		return dataObject.getInternalKey();
	}

	@Override
	protected EntityPath<MarginAmendmentJpe> getEntityPath() {
		return QMarginAmendmentJpe.marginAmendmentJpe;
	}
	
	@Override
	public MarginAmendment getByPk(String publicKey, MarginAmendment reference) {
		Map<String, Object> params = new HashMap<String, Object>();
    	params.put("internalKey", new Long(publicKey));
    	List<MarginAmendmentJpe> result = dataService.findWithNamedQuery(XpsJpeConstants.FIND_MARGIN_AMENDMENT_BY_INTERNAL_KEY, params, MarginAmendmentJpe.class);
    	if(result != null && result.size() > 0){
    		MarginAmendmentJpe jpe = result.get(0);
    		return jaxbSdoHelper.wrap(jpe, MarginAmendment.class);
    	}
    	return null;
	}

	@Override
	public Long count(FindCriteria findCriteria, CbsHeader cbsHeader) {
		List<MarginAmendment> list = find(findCriteria, cbsHeader);
		return list != null ? new Integer(list.size()).longValue() : 0L;
	}
	
	 @Override
	 public List<MarginAmendment> query(int offset, int resultLimit, String groupBy, String order, Map<String, Object> filters) {
		 return super.query(offset, resultLimit, groupBy, order, filters);
	 }
	
	 @Override
	 public List<MarginAmendment> find(FindCriteria findCriteria, CbsHeader cbsHeader) {
		 return super.find(findCriteria, cbsHeader);
	 }

	@Override
    public MarginAmendment create(MarginAmendment dataObject){
    	return null;
    }

    @Override
    public MarginAmendment update(MarginAmendment dataObject){
    	return null;
    }

    @Override
    public boolean delete(MarginAmendment dataObject){
    	return true;
    }

	

}
