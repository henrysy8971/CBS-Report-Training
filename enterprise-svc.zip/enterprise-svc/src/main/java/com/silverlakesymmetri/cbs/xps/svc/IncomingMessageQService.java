package com.silverlakesymmetri.cbs.xps.svc;

import java.util.List;

import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation;
import com.silverlakesymmetri.cbs.commons.svc.BusinessService;
import com.silverlakesymmetri.cbs.xps.bdo.sdo.IncomingMessageQ;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.IncomingMessageQJpe;

public interface IncomingMessageQService extends BusinessService<IncomingMessageQ, IncomingMessageQJpe> {
    public static final String SVC_OP_NAME_INCOMINGMESSAGEQSERVICE_GET = "IncomingMessageQService.get";
    public static final String SVC_OP_NAME_INCOMINGMESSAGEQSERVICE_UPDATE = "IncomingMessageQService.updateIncomingMessage";
    public static final String SVC_OP_NAME_INCOMINGMESSAGEQSERVICE_PROCESS_FILE = "IncomingMessageQService.processFile";

    @ServiceOperation(name = SVC_OP_NAME_INCOMINGMESSAGEQSERVICE_GET, type = ServiceOperation.ServiceOperationType.GET)
    public IncomingMessageQ getByPk(String publicKey, IncomingMessageQ reference);

    @ServiceOperation(name = SVC_OP_NAME_INCOMINGMESSAGEQSERVICE_UPDATE, type = ServiceOperation.ServiceOperationType.EXECUTE)
    public IncomingMessageQ updateIncomingMessage(IncomingMessageQ dataObject);
    
    /**
     * Invokes the SPRING BATCH JOB <em>ProcessIncoming.SwiftMessageJob</em> that will process the messages</br>
     * (In this case, the records within the incoming message file will be processed and submitted to BPM as tasks)
     * @param internalKeyList - the list of internal keys (XPS_MESSAGE_MASTER_SWF_V.INTERNAL_KEY) to be processed
     * @return true if the spring batch job has been invoked successfully, false otherwise
     */
    @ServiceOperation(name = SVC_OP_NAME_INCOMINGMESSAGEQSERVICE_PROCESS_FILE, type = ServiceOperation.ServiceOperationType.EXECUTE)
    public boolean processFile(List<Long> internalKeyList);
}
