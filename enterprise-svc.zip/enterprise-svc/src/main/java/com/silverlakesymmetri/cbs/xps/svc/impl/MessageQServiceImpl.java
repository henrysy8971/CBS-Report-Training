package com.silverlakesymmetri.cbs.xps.svc.impl;

import java.util.Date;
import java.util.List;
import java.util.Map;

import org.apache.velocity.VelocityContext;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.mysema.query.types.EntityPath;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.bdo.sdo.DmsFile;
import com.silverlakesymmetri.cbs.commons.context.CbsSessionContext;
import com.silverlakesymmetri.cbs.commons.dms.DocumentManagementService;
import com.silverlakesymmetri.cbs.commons.xmlapi.enums.CbsXmlApiOperation;
import com.silverlakesymmetri.cbs.xps.bdo.sdo.AdvicePreview;
import com.silverlakesymmetri.cbs.xps.bdo.sdo.MessageQ;
import com.silverlakesymmetri.cbs.xps.bdo.sdo.MessageQOthers;
import com.silverlakesymmetri.cbs.xps.enums.XpsGlobalConstants;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.MessageQJpe;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.QMessageQJpe;
import com.silverlakesymmetri.cbs.xps.svc.AbstractXmlApiAdviceCapableBusinessService;
import com.silverlakesymmetri.cbs.xps.svc.MessageQService;
import com.silverlakesymmetri.cbs.xps.svc.mapper.MessageQServiceMapper;
import com.silverlakesymmetri.cbs.xps.xmlapi.XPSMESSAGEQCUSTOMADVICEAPIType;

@Service
@Transactional
public class MessageQServiceImpl extends AbstractXmlApiAdviceCapableBusinessService<MessageQ, MessageQJpe, Long, XPSMESSAGEQCUSTOMADVICEAPIType, XPSMESSAGEQCUSTOMADVICEAPIType> implements MessageQService{
	
	@Autowired
	private MessageQServiceMapper mapper;
	
	@Autowired
	private DocumentManagementService dmsService;

	@Override
	protected Long getIdFromDataObjectInstance(MessageQ dataObject) {
		return dataObject.getInternalKey();
	}

	@Override
	protected EntityPath<MessageQJpe> getEntityPath() {
		return QMessageQJpe.messageQJpe;
	}

	@Override
	public MessageQ get(MessageQ objectInstanceIdentifier) {
		return super.get(objectInstanceIdentifier);
	}

	@Override
	public List<MessageQ> query(int offset, int resultLimit, String groupBy, String order,
			Map<String, Object> filters) {
		return super.query(offset, resultLimit, groupBy, order, filters);
	}

	@Override
	public List<MessageQ> find(FindCriteria findCriteria, CbsHeader cbsHeader) {
		return super.find(findCriteria, cbsHeader);
	}

	@Override
	public MessageQ getByPk(String publicKey, MessageQ reference) {
		return super.getByPk(publicKey, reference);
	}

	@Override
	public MessageQ create(MessageQ dataObject) {
		return super.create(dataObject);
	}

	@Override
	public MessageQ update(MessageQ dataObject) {
		return super.update(dataObject);
	}

	@Override
	public boolean delete(MessageQ dataObject) {
		return super.delete(dataObject);
	}

	@Override
	protected MessageQOthers fillContext(Map<String, Object> adviceParams, VelocityContext context) {
		return null;
	}

	@Override
	public String generateSwfMessage(Map<String, Object> params) {
		return null;
	}

	@Override
	protected XPSMESSAGEQCUSTOMADVICEAPIType transformBdoToXmlApiRqCreate(MessageQ dataObject) {
		return transformBdoToXmlApi(dataObject, CbsXmlApiOperation.INSERT);
	}

	@Override
	protected XPSMESSAGEQCUSTOMADVICEAPIType transformBdoToXmlApiRqUpdate(MessageQ dataObject) {
		return transformBdoToXmlApi(dataObject, CbsXmlApiOperation.UPDATE);
	}

	@Override
	protected XPSMESSAGEQCUSTOMADVICEAPIType transformBdoToXmlApiRqDelete(MessageQ dataObject) {
		return transformBdoToXmlApi(dataObject, CbsXmlApiOperation.DELETE);
	}
	
	private XPSMESSAGEQCUSTOMADVICEAPIType transformBdoToXmlApi(MessageQ dataObject, CbsXmlApiOperation operation) {
		MessageQJpe jpe = jaxbSdoHelper.unwrap(dataObject);

		//if (operation == CbsXmlApiOperation.INSERT) {
		//	jpe.setTranKey(dataService.nextSequenceValue("XPS_INTERNAL_KEY_S"));
		//}

		XPSMESSAGEQCUSTOMADVICEAPIType api = mapper.mapToApi(jpe, operation);
		api.setOPERATION(operation.getOperation());
		if (api != null) {
			super.setTechColsFromDataObject(dataObject, api);
			if(api.getTRANDATE() == null){
				api.setTRANDATE(dateTimeHelper.convertToCbsXmlApiDate(dateTimeHelper.getRunDate()));
			}
		}
		return api;
	}
	
	@Override
	protected MessageQ processXmlApiRs(MessageQ dataObject, XPSMESSAGEQCUSTOMADVICEAPIType xmlApiRs) {
		return dataObject;
	}

	@Override
	protected List<MessageQ> processXmlApiListRs(MessageQ dataObject, XPSMESSAGEQCUSTOMADVICEAPIType xmlApiRs) {
		return null;
	}

	@Override
	protected Class<XPSMESSAGEQCUSTOMADVICEAPIType> getXmlApiResponseClass() {
		return XPSMESSAGEQCUSTOMADVICEAPIType.class;
	}

	@Override
	public MessageQ createAsyncPrepared(MessageQ dataObject, CbsSessionContext sessionCtx) {
		return super.createAsyncPrepared(dataObject, sessionCtx);
	}

	@Override
	public MessageQ createMessageQueueEntry(AdvicePreview advice, DmsFile file, String domain, Long tranInternalKey, String refNo, String eventType, String tranDate, String route, String branch, String sourceType, Long seqNo, String destination, String errorMsg) {
		return createMessageQueueEntry(advice, file, domain, tranInternalKey, refNo, eventType, tranDate, route, branch, sourceType, seqNo, destination, null, errorMsg);
	}

	@Override
	public MessageQ createMessageQueueEntry(AdvicePreview advice, DmsFile file, String domain, Long tranInternalKey, String refNo, String eventType, String tranDate, String route, String branch, String sourceType, Long seqNo, String destination, String sender, String errorMsg) {
		MessageQ messageQueue = jaxbSdoHelper.createSdoInstance(MessageQ.class);
	    messageQueue.setDomain(domain);
	    messageQueue.setBranch(branch);
	    messageQueue.setTranInternalKey(tranInternalKey);
	    messageQueue.setTranDate(tranDate);
	    messageQueue.setSourceType(sourceType);
	    messageQueue.setTranRefNo(refNo);
	    messageQueue.setTranEventType(eventType);
	    messageQueue.setRoute(route);
	    messageQueue.setSeqNo(seqNo);
	    messageQueue.setSenderAddress(sender);
	    messageQueue.setErrorDetails(errorMsg);
	    if(XpsGlobalConstants.EMAIL_ROUTE.equals(route) && advice != null){
		    messageQueue.setDetails(advice.getSubject()+":::::"+advice.getMsgBody());
		    messageQueue.setDestAddress(advice.getRecipients());
		    messageQueue.setFormat(advice.getDocument());
		    if(advice.getAttachments() != null && advice.getAttachments().size() > 0){
		    	StringBuilder builder = new StringBuilder();
		    	for(DmsFile dmsFile : advice.getAttachments()){
		    		String jcrId = dmsService.createDocument(XpsGlobalConstants.MESSAGE_QUEUE_JCR_PATH, dmsFile);
		    		if(builder.length() > 0) builder.append(",");
		    		builder.append(jcrId);
		    	}
		    	messageQueue.setJcrId(builder.toString());
		    }
	    } else if(file != null) {
		    messageQueue.setDestAddress(destination);
		    messageQueue.setFormat(file.getDmsFileId());
    		String jcrId = dmsService.createDocument(XpsGlobalConstants.MESSAGE_QUEUE_JCR_PATH, file);
    		messageQueue.setJcrId(jcrId);
	    }
	    messageQueue.setDateGenerated(dateTimeHelper.getSDODateTime(new Date()));
	    return this.create(messageQueue);
	}

	//TODO: remove the other 2 above and use these instead
	@Override
	public MessageQ createMessageQueueEntry(AdvicePreview advice, DmsFile file, String domain, Long tranInternalKey, String refNo, String eventType, 
			String tranDate, String route, String branch, String sourceType, Long seqNo, String destination, String errorMsg, CbsSessionContext sessionCtx) {
		return createMessageQueueEntry(advice, file, domain, tranInternalKey, refNo, eventType, tranDate, route, branch, sourceType, seqNo, destination, null, errorMsg, sessionCtx);
	}

	@Override
	public MessageQ createMessageQueueEntry(AdvicePreview advice, DmsFile file, String domain, Long tranInternalKey, String refNo, String eventType, 
			String tranDate, String route, String branch, String sourceType, Long seqNo, String destination, String sender, String errorMsg, CbsSessionContext sessionCtx) {
		MessageQ messageQueue = jaxbSdoHelper.createSdoInstance(MessageQ.class);
	    messageQueue.setDomain(domain);
	    messageQueue.setBranch(branch);
	    messageQueue.setTranInternalKey(tranInternalKey);
	    messageQueue.setTranDate(tranDate);
	    messageQueue.setSourceType(sourceType);
	    messageQueue.setTranRefNo(refNo);
	    messageQueue.setTranEventType(eventType);
	    messageQueue.setRoute(route);
	    messageQueue.setSeqNo(seqNo);
	    messageQueue.setSenderAddress(sender);
	    messageQueue.setErrorDetails(errorMsg);
	    if(XpsGlobalConstants.EMAIL_ROUTE.equals(route) && advice != null){
		    messageQueue.setDetails(advice.getSubject()+":::::"+advice.getMsgBody());
		    messageQueue.setDestAddress(advice.getRecipients());
		    messageQueue.setFormat(advice.getDocument());
		    if(advice.getAttachments() != null && advice.getAttachments().size() > 0){
		    	StringBuilder builder = new StringBuilder();
		    	for(DmsFile dmsFile : advice.getAttachments()){
		    		String jcrId = dmsService.createDocument(XpsGlobalConstants.MESSAGE_QUEUE_JCR_PATH, dmsFile);
		    		if(builder.length() > 0) builder.append(",");
		    		builder.append(jcrId);
		    	}
		    	messageQueue.setJcrId(builder.toString());
		    }
	    } else if(file != null) {
		    messageQueue.setDestAddress(destination);
		    messageQueue.setFormat(file.getDmsFileId());
    		String jcrId = dmsService.createDocument(XpsGlobalConstants.MESSAGE_QUEUE_JCR_PATH, file);
    		messageQueue.setJcrId(jcrId);
	    }
	    messageQueue.setDateGenerated(dateTimeHelper.getSDODateTime(new Date()));
	    return this.createAsyncPrepared(messageQueue, sessionCtx);
	}

	@Override
	public MessageQJpe updateMessageQueueEntry(AdvicePreview advice, DmsFile file, MessageQJpe messageQueue) {
	    if(XpsGlobalConstants.EMAIL_ROUTE.equals(messageQueue.getRoute()) && advice != null){
		    messageQueue.setDetails(advice.getSubject()+":::::"+advice.getMsgBody());
		    if(advice.getAttachments() != null && advice.getAttachments().size() > 0){
		    	StringBuilder builder = new StringBuilder();
		    	for(DmsFile dmsFile : advice.getAttachments()){
		    		String jcrId = dmsService.createDocument(XpsGlobalConstants.MESSAGE_QUEUE_JCR_PATH, dmsFile);
		    		if(builder.length() > 0) builder.append(",");
		    		builder.append(jcrId);
		    	}
		    	messageQueue.setJcrId(builder.toString());
		    }
	    } else if(file != null) {
		    messageQueue.setFormat(file.getDmsFileId());
    		String jcrId = dmsService.createDocument(XpsGlobalConstants.MESSAGE_QUEUE_JCR_PATH, file);
    		messageQueue.setJcrId(jcrId);
	    }
	    messageQueue.setStatus("N");
	    
	    return messageQueue;
	}

}
