package com.silverlakesymmetri.cbs.xps.svc.impl;

import com.mysema.query.types.EntityPath;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.svc.AbstractBusinessService;
import com.silverlakesymmetri.cbs.commons.svc.BusinessObjectValidationCapable;
import com.silverlakesymmetri.cbs.commons.svc.ref.ReferenceNumberGeneratorService;
import com.silverlakesymmetri.cbs.xps.bdo.sdo.CashFlowMap;
import com.silverlakesymmetri.cbs.xps.bdo.sdo.DocumentInventoryHdr;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.CashFlowMapJpe;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.QCashFlowMapJpe;
import com.silverlakesymmetri.cbs.xps.svc.CashFlowMapService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;

@Service
public class CashFlowMapServiceImpl extends AbstractBusinessService<CashFlowMap, CashFlowMapJpe, String>
        implements CashFlowMapService, BusinessObjectValidationCapable<CashFlowMap> {

    @Autowired
    private ReferenceNumberGeneratorService referenceNumberGeneratorService;

    @Override
    protected String getIdFromDataObjectInstance(CashFlowMap dataObject) {
        return null;
    }

    @Override
    protected EntityPath<CashFlowMapJpe> getEntityPath() {
        return QCashFlowMapJpe.cashFlowMapJpe;
    }

    @Override
    public CashFlowMap getByPk(String publicKey, CashFlowMap reference) {
        return super.getByPk(publicKey, reference);
    }

    @Override
    public CashFlowMap create(CashFlowMap dataObject) {
        return super.create(dataObject);
    }

    @Override
    public CashFlowMap update(CashFlowMap dataObject) {
        return super.update(dataObject);
    }

    @Override
    public List<CashFlowMap> query(int offset, int resultLimit, String groupBy, String order,
                                   Map<String, Object> filters) {
        return super.query(offset, resultLimit, groupBy, order, filters);
    }

    @Override
    public boolean delete(CashFlowMap dataObject) {
        return super.delete(dataObject);
    }

    @Override
    public List<CashFlowMap> find(FindCriteria findCriteria, CbsHeader cbsHeader) {
        return super.find(findCriteria, cbsHeader);
    }

    @Override
    protected CashFlowMap preCreateValidation(CashFlowMap dataObject) {
        if (dataObject.getCashFlowMapRefNo() == null || dataObject.getCashFlowMapRefNo().isEmpty()) {
            referenceNumberGeneratorService.getNewRefNo(dataObject, "cashFlowMapRefNo");
        }
        return super.preCreateValidation(dataObject);
    }
}
