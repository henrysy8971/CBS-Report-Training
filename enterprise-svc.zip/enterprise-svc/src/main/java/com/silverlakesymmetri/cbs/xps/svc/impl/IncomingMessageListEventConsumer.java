package com.silverlakesymmetri.cbs.xps.svc.impl;

import java.util.List;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.silverlakesymmetri.cbs.commons.bdo.CbsBusinessDataObject;
import com.silverlakesymmetri.cbs.commons.event.CbsEvent;
import com.silverlakesymmetri.cbs.commons.event.CbsEventData;
import com.silverlakesymmetri.cbs.commons.event.impl.BpmAwareEventConsumer;
import com.silverlakesymmetri.cbs.commons.jpa.service.CbsGenericDataService;
import com.silverlakesymmetri.cbs.commons.logging.CbsAppLogger;
import com.silverlakesymmetri.cbs.commons.logging.CbsAppLoggerFactory;
import com.silverlakesymmetri.cbs.xps.bdo.sdo.IncomingMessageQ;
import com.silverlakesymmetri.cbs.xps.bdo.sdo.IncomingMessageSwf;
import com.silverlakesymmetri.cbs.xps.svc.IncomingMessageQService;

@Service("incomingMessageListEventConsumer")
public class IncomingMessageListEventConsumer extends BpmAwareEventConsumer {
	private static CbsAppLogger logger = CbsAppLoggerFactory.getLogger(IncomingMessageListEventConsumer.class);

	@Autowired(required = true)
	@Qualifier("cbsGenericDataService")
	protected CbsGenericDataService dataService;
	@Autowired
	IncomingMessageQService incomingMessageQService;

	@Override
	protected boolean handleEvent(CbsEvent anEvent) {
		logger.info("Handling of event started");

		// preliminary checks
		if (anEvent == null || anEvent.getCbsEventData() == null) {
			logger.error("Event data is empty! Nothing to process!");
			return true;
		}

		CbsEventData<?> evtData = anEvent.getCbsEventData();

		if (evtData.getDataType() != CbsEventData.Type.BDO) {
			logger.error("Event data is NOT of type {}! Cannot proceed!", CbsEventData.Type.BDO);
			return true;
		}

		IncomingMessageQ bdo = null;

		try {
			CbsBusinessDataObject cbsBdo = (CbsBusinessDataObject) evtData.getEventData();
			bdo = (IncomingMessageQ) cbsBdo;
		} catch (Exception e) {
			logger.error("Could not resolve Business Data Object from event data!");
			e.printStackTrace();
			return true;
		}

		if (bdo == null) {
			logger.error("Business Data Object is empty! Cannot Proceed!");
			return true;
		}

		if (bdo.getIncomingMessageSwfStructList() == null || bdo.getIncomingMessageSwfStructList().isEmpty()) {
			logger.warn("List is empty! Nothing to process!");
			return true;
		}

		IncomingMessageSwf foundForProcessing = bdo.getIncomingMessageSwfStructList().stream().filter(e -> {
			return StringUtils.equals("N", e.getIgnore()) || StringUtils.isEmpty(e.getIgnore());
		}).findFirst().orElse(null);

		if (foundForProcessing == null) {
			logger.info("All records in the list are ignored. Nothing to process.");
			return true;
		}
		
		// filter out the ignore
		List<Long> internalKeyList = bdo.getIncomingMessageSwfStructList().stream()
			.filter(e -> { return StringUtils.equals("N", e.getIgnore()) || StringUtils.isEmpty(e.getIgnore()); })
			.map(IncomingMessageSwf::getInternalKey).collect(Collectors.toList());

		if (internalKeyList == null || internalKeyList.isEmpty()) {
			logger.warn("internalKeyList is empty! Nothing to Process!");
			return true;
		}

		// run job
		try {
			//doJob(bdo);
			incomingMessageQService.processFile(internalKeyList);
		} catch (Exception e) {
			logger.error("Error encountered when trying to execute IncomingMessageQService.processFile");
			e.printStackTrace();
			anEvent.setProcessingException(e);
		}

		return true;
	}

}
