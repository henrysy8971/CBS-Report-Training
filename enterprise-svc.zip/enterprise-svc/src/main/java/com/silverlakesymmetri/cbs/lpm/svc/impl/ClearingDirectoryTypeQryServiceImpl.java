package com.silverlakesymmetri.cbs.lpm.svc.impl;

import com.mysema.query.types.EntityPath;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.svc.AbstractBusinessService;
import com.silverlakesymmetri.cbs.lpm.bdo.sdo.ClearingDirectory;
import com.silverlakesymmetri.cbs.lpm.bdo.sdo.ClearingDirectoryTypeQry;
import com.silverlakesymmetri.cbs.lpm.jpa.mapping.sdo.ClearingDirectoryJpe;
import com.silverlakesymmetri.cbs.lpm.jpa.mapping.sdo.ClearingDirectoryTypeQryJpe;
import com.silverlakesymmetri.cbs.lpm.jpa.mapping.sdo.QClearingDirectoryTypeQryJpe;
import com.silverlakesymmetri.cbs.lpm.jpa.mapping.sdo.id.ClearingDirectoryTypeQryPk;
import com.silverlakesymmetri.cbs.lpm.svc.ClearingDirectoryTypeQryService;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Map;

@Service
@Transactional
public class ClearingDirectoryTypeQryServiceImpl extends AbstractBusinessService<ClearingDirectoryTypeQry, ClearingDirectoryTypeQryJpe, String>
		implements ClearingDirectoryTypeQryService {

	@Override
	protected String getIdFromDataObjectInstance(ClearingDirectoryTypeQry bdo) {
		ClearingDirectoryTypeQryJpe jpe = jaxbSdoHelper.unwrap(bdo);
		return jpe.getCode();
	}

	@Override
	protected EntityPath<ClearingDirectoryTypeQryJpe> getEntityPath() {
		 return QClearingDirectoryTypeQryJpe.clearingDirectoryTypeQryJpe;
	}

	@Override
	public List<ClearingDirectoryTypeQry> query(int offset, int resultLimit, String groupBy, String order,
												 Map<String, Object> filters) {
		return super.query(offset, resultLimit, groupBy, order, filters);
	}

	@Override
	public List<ClearingDirectoryTypeQry> find(FindCriteria findCriteria, CbsHeader cbsHeader) {
		return super.find(findCriteria, cbsHeader);
	}

	@Override
	public ClearingDirectoryTypeQry getByPk(String publicKey, ClearingDirectoryTypeQry reference) {
		return super.getByPk(publicKey, reference);
	}

}
