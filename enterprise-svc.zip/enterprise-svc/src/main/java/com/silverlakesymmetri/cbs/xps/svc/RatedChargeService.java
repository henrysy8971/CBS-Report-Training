package com.silverlakesymmetri.cbs.xps.svc;

import java.util.List;
import java.util.Map;

import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation;
import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation.ServiceOperationType;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.svc.BusinessService;
import com.silverlakesymmetri.cbs.xps.bdo.sdo.RatedCharge;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.RatedChargeJpe;

public interface RatedChargeService extends BusinessService<RatedCharge, RatedChargeJpe> {
	public static final String SVC_OP_NAME_RATEDCHARGESERVICE_GET= "RatedChargeService.get";
    public static final String SVC_OP_NAME_RATEDCHARGESERVICE_QUERY= "RatedChargeService.query";
    public static final String SVC_OP_NAME_RATEDCHARGESERVICE_CREATE= "RatedChargeService.create";
    public static final String SVC_OP_NAME_RATEDCHARGESERVICE_UPDATE= "RatedChargeService.update";
    public static final String SVC_OP_NAME_RATEDCHARGESERVICE_DELETE= "RatedChargeService.delete";
    public static final String SVC_OP_NAME_RATEDCHARGESERVICE_FIND= "RatedChargeService.find";
    public static final String SVC_OP_NAME_RATEDCHARGESERVICE_COUNT = "RatedChargeService.count";

    @ServiceOperation(name=SVC_OP_NAME_RATEDCHARGESERVICE_GET, type = ServiceOperationType.GET)
    public RatedCharge getByPk(String publicKey, RatedCharge reference);
	
    @ServiceOperation(name = SVC_OP_NAME_RATEDCHARGESERVICE_QUERY)
    public List<RatedCharge> query(int offset, int resultLimit, String groupBy, String order, Map<String, Object> filters);
 
    @ServiceOperation(name = SVC_OP_NAME_RATEDCHARGESERVICE_CREATE)
    public RatedCharge create(RatedCharge dataObject);
     
    @ServiceOperation(name = SVC_OP_NAME_RATEDCHARGESERVICE_UPDATE)
    public RatedCharge update(RatedCharge dataObject);
	
    @ServiceOperation(name = SVC_OP_NAME_RATEDCHARGESERVICE_DELETE)
    public boolean delete(RatedCharge dataObject);
	
    @ServiceOperation(name = SVC_OP_NAME_RATEDCHARGESERVICE_FIND)
    public List<RatedCharge> find(FindCriteria findCriteria, CbsHeader cbsHeader);

    @ServiceOperation(name = SVC_OP_NAME_RATEDCHARGESERVICE_COUNT, type = ServiceOperationType.GET)
    public Long count(FindCriteria findCriteria, CbsHeader cbsHeader);

    /**
     * Two Tier Chargess.
     * 
     * @return Two Tier charges.
     */
    List<RatedCharge> getAll();
}
