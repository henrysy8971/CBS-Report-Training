package com.silverlakesymmetri.cbs.xps.svc;

import java.util.List;
import java.util.Map;

import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation;
import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation.ServiceOperationType;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.svc.BusinessService;
import com.silverlakesymmetri.cbs.xps.bdo.sdo.MessageLinkingList;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.MessageLinkingListJpe;

public interface MessageLinkingDetailService extends BusinessService<MessageLinkingList, MessageLinkingListJpe> {
	public static final String XPS_OP_NAME_MESSAGELINKINGMASTERSERVICE_GET = "MessageLinkingDetailService.get";
    public static final String XPS_OP_NAME_MESSAGELINKINGMASTERSERVICE_QUERY = "MessageLinkingDetailService.query";
    public static final String XPS_OP_NAME_MESSAGELINKINGMASTERSERVICE_FIND = "MessageLinkingDetailService.find";
    
    @ServiceOperation(name = XPS_OP_NAME_MESSAGELINKINGMASTERSERVICE_GET, type = ServiceOperationType.GET)
    public MessageLinkingList getByPk(String publicKey, MessageLinkingList reference);

    @ServiceOperation(name = XPS_OP_NAME_MESSAGELINKINGMASTERSERVICE_QUERY)
    public List<MessageLinkingList> query(int offset, int resultLimit, String groupBy, String order, Map<String, Object> filters);
    
    @ServiceOperation(name = XPS_OP_NAME_MESSAGELINKINGMASTERSERVICE_FIND)
    public List<MessageLinkingList> find(FindCriteria findCriteria, CbsHeader cbsHeader);
    
}
