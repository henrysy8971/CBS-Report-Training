package com.silverlakesymmetri.cbs.xps.svc;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Map;

import javax.inject.Inject;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;

import com.mysema.query.types.EntityPath;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.jpa.entity.ConjunctionEnumJpe;
import com.silverlakesymmetri.cbs.commons.jpa.entity.FindCriteriaJpe;
import com.silverlakesymmetri.cbs.commons.jpa.entity.ViewCriteriaItemJpe;
import com.silverlakesymmetri.cbs.commons.jpa.entity.ViewCriteriaJpe;
import com.silverlakesymmetri.cbs.commons.jpa.entity.ViewCriteriaRowJpe;
import com.silverlakesymmetri.cbs.commons.jpa.extension.JaxbSdoHelper;
import com.silverlakesymmetri.cbs.commons.jpa.service.CbsGenericDataService;
import com.silverlakesymmetri.cbs.commons.jpa.service.impl.BusinessDataObjectJpaQueryComponentImpl;
import com.silverlakesymmetri.cbs.commons.svc.AbstractBusinessService;
import com.silverlakesymmetri.cbs.commons.svc.BusinessObjectValidationCapable;
import com.silverlakesymmetri.cbs.commons.svc.ref.ReferenceNumberGeneratorService;
import com.silverlakesymmetri.cbs.commons.svc.util.InMemoryQueryExecutor;
import com.silverlakesymmetri.cbs.csd.svc.CcyConversionService;
import com.silverlakesymmetri.cbs.xps.bdo.sdo.ChargeMatrix;
import com.silverlakesymmetri.cbs.xps.bdo.sdo.PeriodicCharge;
import com.silverlakesymmetri.cbs.xps.bdo.sdo.PeriodicChargeRate;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.ChargeMatrixJpe;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.QPeriodicChargeJpe;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.PeriodicChargeJpe;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.PeriodicChargeRateJpe;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.util.XpsJpeConstants;

@Service
@Transactional
public class PeriodicChargeServiceImpl extends AbstractBusinessService<PeriodicCharge, PeriodicChargeJpe, String> 
	implements PeriodicChargeService, BusinessObjectValidationCapable<PeriodicCharge> {
	
	@Inject
    protected JaxbSdoHelper jaxbSdoHelper;
    @Autowired
    protected CcyConversionService ccyConversionService;
    @Autowired
    private CbsGenericDataService dataService;
    Map<String, Object> filters;
    @Autowired
    private ReferenceNumberGeneratorService referenceNumberGeneratorService;
	
    @Override
    protected String getIdFromDataObjectInstance(PeriodicCharge dataObject) {
        return dataObject.getChargeRefNo();
    }

    @Override
    protected EntityPath<PeriodicChargeJpe> getEntityPath() {
        return QPeriodicChargeJpe.periodicChargeJpe;
    }

    @Override
    public PeriodicCharge get(PeriodicCharge objectInstanceIdentifier) {
       
        List<PeriodicChargeJpe> jpeResult = dataService.findWithNamedQuery(XpsJpeConstants.PERIODIC_CHARGE_JPE_GET_ALL, PeriodicChargeJpe.class);
        PeriodicCharge sdo = null;
        for (PeriodicChargeJpe jpe : jpeResult) {
        	if (jpe.getChargeRefNo().equals(objectInstanceIdentifier.getChargeRefNo())){
        	    populateChargeRates(jpe);
        		sdo = jaxbSdoHelper.wrap(jpe, PeriodicCharge.class);
        	}
        }
        
        return sdo;
    }
    
    @Override
    public List<PeriodicCharge> query(int offset, int resultLimit, String groupBy, String order, Map<String, Object> filters) {
        List<PeriodicCharge> sdoResult = getAll(filters);
        FindCriteria fc = jaxbSdoHelper.wrap(BusinessDataObjectJpaQueryComponentImpl.buildFindCriteria(offset, resultLimit, groupBy, order, filters));
        return filterAndSortResult(fc, sdoResult);
    }
	
    @Override
    public PeriodicCharge create(PeriodicCharge dataObject) {
    	Defaulting(dataObject);
    	return super.create(dataObject);
    }
    
    @Override
    public PeriodicCharge update(PeriodicCharge dataObject) {
    	Defaulting(dataObject);
    	return super.update(dataObject);
    }
    
    @Override
    public boolean delete(PeriodicCharge dataObject) {
		return super.delete(dataObject);
    }
    

    public List<PeriodicCharge> getAll( Map<String, Object> filters) {
        List<PeriodicCharge> sdoResult = new ArrayList<PeriodicCharge>();
              
        List<PeriodicChargeJpe> jpeResult = dataService.findWithNamedQuery(XpsJpeConstants.PERIODIC_CHARGE_JPE_GET_ALL, filters, PeriodicChargeJpe.class);
        
        for (PeriodicChargeJpe jpe : jpeResult) {
            populateChargeRates(jpe);
    		PeriodicCharge sdo = jaxbSdoHelper.wrap(jpe, PeriodicCharge.class);
    		sdoResult.add(sdo);
        }
        
        return sdoResult;
    }

    private void populateChargeRates(PeriodicChargeJpe jpe) {
        if (jpe.getPeriodicChargeRateList()!=null && jpe.getPeriodicChargeRateList().size() > 0) {
            for (PeriodicChargeRateJpe chargeRateJpe : jpe.getPeriodicChargeRateList()) {
                if (chargeRateJpe.getChargeMatrixList()!=null && chargeRateJpe.getChargeMatrixList().size() > 0) {
                    for (ChargeMatrixJpe matrixJpe : chargeRateJpe.getChargeMatrixList()) {
                        if (matrixJpe.getPeriodSeq().compareTo(1d)==0) {
                            chargeRateJpe.setChargeRate1(matrixJpe.getChargeRate());
                        }
                        if (matrixJpe.getPeriodSeq().compareTo(2d)==0) {
                            chargeRateJpe.setChargeRate2(matrixJpe.getChargeRate());
                        }
                        if (matrixJpe.getPeriodSeq().compareTo(3d)==0) {
                            chargeRateJpe.setChargeRate3(matrixJpe.getChargeRate());
                        }
                        if (matrixJpe.getPeriodSeq().compareTo(4d)==0) {
                            chargeRateJpe.setChargeRate4(matrixJpe.getChargeRate());
                        }
                        if (matrixJpe.getPeriodSeq().compareTo(5d)==0) {
                            chargeRateJpe.setChargeRate5(matrixJpe.getChargeRate());
                        }
                        if (matrixJpe.getPeriodSeq().compareTo(6d)==0) {
                            chargeRateJpe.setChargeRate6(matrixJpe.getChargeRate());
                        }
                        if (matrixJpe.getPeriodSeq().compareTo(7d)==0) {
                            chargeRateJpe.setChargeRate7(matrixJpe.getChargeRate());
                        }
                        if (matrixJpe.getPeriodSeq().compareTo(8d)==0) {
                            chargeRateJpe.setChargeRate8(matrixJpe.getChargeRate());
                        }
                        if (matrixJpe.getPeriodSeq().compareTo(9d)==0) {
                            chargeRateJpe.setChargeRate9(matrixJpe.getChargeRate());
                        }
                        if (matrixJpe.getPeriodSeq().compareTo(10d)==0) {
                            chargeRateJpe.setChargeRate10(matrixJpe.getChargeRate());
                        }
                        if (matrixJpe.getPeriodSeq().compareTo(11d)==0) {
                            chargeRateJpe.setChargeRate11(matrixJpe.getChargeRate());
                        }
                        if (matrixJpe.getPeriodSeq().compareTo(12d)==0) {
                            chargeRateJpe.setChargeRate12(matrixJpe.getChargeRate());
                        }
                    }
                }
            }
        }
    }

    private List<PeriodicCharge> filterAndSortResult(FindCriteria findCriteria, List<PeriodicCharge> list) {
        InMemoryQueryExecutor<PeriodicCharge> inMemQry = new InMemoryQueryExecutor<>(list);
        return inMemQry.executeFilter(findCriteria);
    }

    @Override
    protected PeriodicCharge preCreateValidation(PeriodicCharge dataObject) {
    	if(null != dataObject){
    	    defaultPeriodicChargeRate(dataObject);
	    	performDefaulting(dataObject);
	    	if (StringUtils.isEmpty(dataObject.getChargeRefNo())) {
				referenceNumberGeneratorService.getNewRefNo(dataObject, "chargeRefNo");
			}
	        if (dataObject.isUsedYn() == null) {
	            dataObject.setUsedYn(false);
	        }
	        if (dataObject.isActiveYn() == null) {
	            dataObject.setActiveYn(false);
	        }

	        java.util.List<PeriodicChargeRate> chargeRateList;
			chargeRateList = dataObject.getPeriodicChargeRateList();
			
			if (null != chargeRateList){
				for ( PeriodicChargeRate childRate : chargeRateList){
					if (StringUtils.isEmpty(childRate.getChargeRateRefNo())) {
						referenceNumberGeneratorService.getNewRefNo(childRate, "chargeRateRefNo");
					}				
					if (StringUtils.isEmpty(childRate.getChargeRefNo())) {
						childRate.setChargeRefNo(dataObject.getChargeRefNo());
					}				
			        java.util.List<ChargeMatrix> chargeMatrixList;
			        chargeMatrixList = childRate.getChargeMatrixList();
					
					if (null != chargeMatrixList){
						for ( ChargeMatrix childMatrix : chargeMatrixList){
							if (StringUtils.isEmpty(childMatrix.getChargeMatrixRefNo())) {
								referenceNumberGeneratorService.getNewRefNo(childMatrix, "chargeMatrixRefNo");
							}				
							if (StringUtils.isEmpty(childMatrix.getChargeRateRefNo())) {
								childMatrix.setChargeRateRefNo(childRate.getChargeRateRefNo());
							}				
							if (StringUtils.isEmpty(childMatrix.getChargeRefNo())) {
								childMatrix.setChargeRefNo(dataObject.getChargeRefNo());
							}				
						}
						childRate.setChargeMatrixList(chargeMatrixList);
					}
				}
				dataObject.setPeriodicChargeRateList(chargeRateList);
			}
		}
        return dataObject;
    }

    @Override
    protected PeriodicCharge preUpdateValidation(PeriodicCharge dataObject) {
        defaultPeriodicChargeRate(dataObject);
    	performDefaulting(dataObject);
		java.util.List<PeriodicChargeRate> chargeRateList;
		chargeRateList = dataObject.getPeriodicChargeRateList();
		
		if (null != chargeRateList){
			for ( PeriodicChargeRate childRate : chargeRateList){
				if (StringUtils.isEmpty(childRate.getChargeRefNo())) {
					childRate.setChargeRefNo(dataObject.getChargeRefNo());
				}				
				if (StringUtils.isEmpty(childRate.getChargeRateRefNo())) {
					referenceNumberGeneratorService.getNewRefNo(childRate, "chargeRateRefNo");
				}		
		        java.util.List<ChargeMatrix> chargeMatrixList;
		        chargeMatrixList = childRate.getChargeMatrixList();
				
				if (null != chargeMatrixList){
					for ( ChargeMatrix childMatrix : chargeMatrixList){
						if (StringUtils.isEmpty(childMatrix.getChargeMatrixRefNo())) {
							referenceNumberGeneratorService.getNewRefNo(childMatrix, "chargeMatrixRefNo");
						}				
						if (StringUtils.isEmpty(childMatrix.getChargeRateRefNo())) {
							childMatrix.setChargeRateRefNo(childRate.getChargeRateRefNo());
						}				
						if (StringUtils.isEmpty(childMatrix.getChargeRefNo())) {
							childMatrix.setChargeRefNo(dataObject.getChargeRefNo());
						}				
					}
					childRate.setChargeMatrixList(chargeMatrixList);
				}
			}
			dataObject.setPeriodicChargeRateList(chargeRateList);
		}
        return dataObject;
    }
    
    private void performDefaulting(PeriodicCharge periodicChargeJpe) {
        if (null != periodicChargeJpe) {
			if (null == periodicChargeJpe.getChargeType()) {periodicChargeJpe.setChargeType("P");}
        }

        sortAndDefaultSeqNo(periodicChargeJpe);

    }

	private void sortAndDefaultSeqNo(PeriodicCharge periodicChargeJpe) {
        List<PeriodicChargeRate> chargeRateList = periodicChargeJpe.getPeriodicChargeRateList();
		if (chargeRateList!=null && chargeRateList.size() > 0) {
        	
            List<PeriodicChargeRate> periodicChargeRateSortedByBalanceDays = new ArrayList<PeriodicChargeRate>(chargeRateList);
            Collections.sort(periodicChargeRateSortedByBalanceDays, new Comparator<PeriodicChargeRate>() {
                @Override
                public int compare(PeriodicChargeRate o1, PeriodicChargeRate o2) {
                    int iResult = 0;
                    Double d1 = o1.getBalance();
                    Double d2 = o2.getBalance();
                    if (d1 != null) {
                        iResult = d1.compareTo(d2);
                    }

                    return iResult;
                }
            });

            for (PeriodicChargeRate removePeriodicChargeRate : chargeRateList) {
            	periodicChargeJpe.getPeriodicChargeRateList().remove(removePeriodicChargeRate);
            }
            
            int seqNo = 1;
            for (PeriodicChargeRate addPeriodicChargeRate : periodicChargeRateSortedByBalanceDays) {
            	addPeriodicChargeRate.setSeqNo(seqNo);
            	periodicChargeJpe.getPeriodicChargeRateList().add(addPeriodicChargeRate);
            	seqNo++;
            }

        }
	}
   
    @Override
    public List<PeriodicCharge> find(FindCriteria findCriteria, CbsHeader cbsHeader) {
        List<PeriodicCharge> periodicChargeList = super.find(findCriteria, cbsHeader);
        List<PeriodicCharge> bdoList = new ArrayList <PeriodicCharge> ();
        
        if (periodicChargeList.size() > 0 ) {
            for (PeriodicCharge periodicCharge : periodicChargeList) {
                if (periodicCharge.getChargeType()!= null && "P".equals(periodicCharge.getChargeType())) {
                    bdoList.add(periodicCharge);
                }
            }
        }
        return bdoList;
    }
    
    @Override
    public Long count(FindCriteria findCriteria, CbsHeader cbsHeader) {
        FindCriteriaJpe fcJpe = customFC(findCriteria);
        return dataService.getRowCount(PeriodicChargeJpe.class, fcJpe);
    }
    
    @Override
    public PeriodicCharge getByPk(String publicKey, PeriodicCharge reference) {
        PeriodicCharge result = super.getByPk(publicKey, reference);
    	if (null != result && "P".equals(result.getChargeType())) {
    	    PeriodicChargeJpe jpe = jaxbSdoHelper.unwrap(result, PeriodicChargeJpe.class);
    	    populateChargeRates(jpe);
    	    result = jaxbSdoHelper.wrap(jpe, PeriodicCharge.class);
    		return result;
    	} else {
    		return null;
    			
    	}
    }
    private void Defaulting(PeriodicCharge dataObject){
    	if (null != dataObject){
    		//chargeType
    		if (null == dataObject.getChargeType()){
    			dataObject.setChargeType("P");
    		}
    		//userRateConstituents
    		if (null == dataObject.getUseRateConstituents()){
    			dataObject.setUseRateConstituents("N");
    		}
    		//recurring
    		if (null == dataObject.getRecurring()){
    			dataObject.setRecurring("N");
    		}
    		//interestAction
    		if (null == dataObject.getInterestAction()){
    			dataObject.setInterestAction("N");
    		} 
     	}
    }
    
    private void defaultPeriodicChargeRate(PeriodicCharge dataObject){
        if (null != dataObject){

            List <PeriodicChargeRate> periodicChargeRateList = dataObject.getPeriodicChargeRateList();

            if (periodicChargeRateList!=null && periodicChargeRateList.size()>0) {
                
                for (PeriodicChargeRate periodicChargeRate : periodicChargeRateList) {
                    ChargeMatrixJpe chargeMatrixJpe1 = new ChargeMatrixJpe();
                    ChargeMatrixJpe chargeMatrixJpe2 = new ChargeMatrixJpe();
                    ChargeMatrixJpe chargeMatrixJpe3 = new ChargeMatrixJpe();
                    ChargeMatrixJpe chargeMatrixJpe4 = new ChargeMatrixJpe();
                    ChargeMatrixJpe chargeMatrixJpe5 = new ChargeMatrixJpe();
                    ChargeMatrixJpe chargeMatrixJpe6 = new ChargeMatrixJpe();
                    ChargeMatrixJpe chargeMatrixJpe7 = new ChargeMatrixJpe();
                    ChargeMatrixJpe chargeMatrixJpe8 = new ChargeMatrixJpe();
                    ChargeMatrixJpe chargeMatrixJpe9 = new ChargeMatrixJpe();
                    ChargeMatrixJpe chargeMatrixJpe10 = new ChargeMatrixJpe();
                    ChargeMatrixJpe chargeMatrixJpe11 = new ChargeMatrixJpe();
                    ChargeMatrixJpe chargeMatrixJpe12 = new ChargeMatrixJpe();     
                    ChargeMatrix chargeMatrix1 = jaxbSdoHelper.wrap(chargeMatrixJpe1, ChargeMatrix.class);
                    ChargeMatrix chargeMatrix2 = jaxbSdoHelper.wrap(chargeMatrixJpe2, ChargeMatrix.class);
                    ChargeMatrix chargeMatrix3 = jaxbSdoHelper.wrap(chargeMatrixJpe3, ChargeMatrix.class);
                    ChargeMatrix chargeMatrix4 = jaxbSdoHelper.wrap(chargeMatrixJpe4, ChargeMatrix.class);
                    ChargeMatrix chargeMatrix5 = jaxbSdoHelper.wrap(chargeMatrixJpe5, ChargeMatrix.class);
                    ChargeMatrix chargeMatrix6 = jaxbSdoHelper.wrap(chargeMatrixJpe6, ChargeMatrix.class);
                    ChargeMatrix chargeMatrix7 = jaxbSdoHelper.wrap(chargeMatrixJpe7, ChargeMatrix.class);
                    ChargeMatrix chargeMatrix8 = jaxbSdoHelper.wrap(chargeMatrixJpe8, ChargeMatrix.class);
                    ChargeMatrix chargeMatrix9 = jaxbSdoHelper.wrap(chargeMatrixJpe9, ChargeMatrix.class);
                    ChargeMatrix chargeMatrix10 = jaxbSdoHelper.wrap(chargeMatrixJpe10, ChargeMatrix.class);
                    ChargeMatrix chargeMatrix11 = jaxbSdoHelper.wrap(chargeMatrixJpe11, ChargeMatrix.class);
                    ChargeMatrix chargeMatrix12 = jaxbSdoHelper.wrap(chargeMatrixJpe12, ChargeMatrix.class);
                                               	
                    List <ChargeMatrix>  chargeMatrixList = periodicChargeRate.getChargeMatrixList();
                    if (chargeMatrixList!=null && chargeMatrixList.size()>0) {
                        for (ChargeMatrix chargeMatrix : chargeMatrixList) {
                            if (chargeMatrix.getPeriodSeq().compareTo(1D)==0) {
                                chargeMatrix.setChargeRate(periodicChargeRate.getChargeRate1());
                                chargeMatrix1 = chargeMatrix;
                            } else if (chargeMatrix.getPeriodSeq().compareTo(2D)==0) {
                                chargeMatrix.setChargeRate(periodicChargeRate.getChargeRate2());
                                chargeMatrix2 = chargeMatrix;
                            } else if (chargeMatrix.getPeriodSeq().compareTo(3D)==0) {
                                chargeMatrix.setChargeRate(periodicChargeRate.getChargeRate3());
                                chargeMatrix3 = chargeMatrix;
                            } else if (chargeMatrix.getPeriodSeq().compareTo(4D)==0) {
                                chargeMatrix.setChargeRate(periodicChargeRate.getChargeRate4());
                                chargeMatrix4 = chargeMatrix;
                            } else if (chargeMatrix.getPeriodSeq().compareTo(5D)==0) {
                                chargeMatrix.setChargeRate(periodicChargeRate.getChargeRate5());
                                chargeMatrix5 = chargeMatrix;
                            } else if (chargeMatrix.getPeriodSeq().compareTo(6D)==0) {
                                chargeMatrix.setChargeRate(periodicChargeRate.getChargeRate6());
                                chargeMatrix6 = chargeMatrix;
                            } else if (chargeMatrix.getPeriodSeq().compareTo(7D)==0) {
                                chargeMatrix.setChargeRate(periodicChargeRate.getChargeRate7());
                                chargeMatrix7 = chargeMatrix;
                            } else if (chargeMatrix.getPeriodSeq().compareTo(8D)==0) {
                                chargeMatrix.setChargeRate(periodicChargeRate.getChargeRate8());
                                chargeMatrix8 = chargeMatrix;
                            } else if (chargeMatrix.getPeriodSeq().compareTo(9D)==0) {
                                chargeMatrix.setChargeRate(periodicChargeRate.getChargeRate9());
                                chargeMatrix9 = chargeMatrix;
                            } else if (chargeMatrix.getPeriodSeq().compareTo(10D)==0) {
                                chargeMatrix.setChargeRate(periodicChargeRate.getChargeRate10());
                                chargeMatrix10 = chargeMatrix;
                            } else if (chargeMatrix.getPeriodSeq().compareTo(11D)==0) {
                                chargeMatrix.setChargeRate(periodicChargeRate.getChargeRate11());
                                chargeMatrix11 = chargeMatrix;
                            } else if (chargeMatrix.getPeriodSeq().compareTo(12D)==0) {
                                chargeMatrix.setChargeRate(periodicChargeRate.getChargeRate12());
                                chargeMatrix12 = chargeMatrix;
                            }                            
                        }
                        // remove nullified 
                        if (periodicChargeRate.getChargeRate1()==null && chargeMatrix1.getPeriodSeq()!=null) {
                            periodicChargeRate.getChargeMatrixList().remove(chargeMatrix1);
                        }
                        if (periodicChargeRate.getChargeRate2()==null && chargeMatrix2.getPeriodSeq()!=null) {
                            periodicChargeRate.getChargeMatrixList().remove(chargeMatrix2);
                        } 
                        if (periodicChargeRate.getChargeRate3()==null && chargeMatrix3.getPeriodSeq()!=null) {
                            periodicChargeRate.getChargeMatrixList().remove(chargeMatrix3);
                        }
                        if (periodicChargeRate.getChargeRate4()==null && chargeMatrix4.getPeriodSeq()!=null) {
                            periodicChargeRate.getChargeMatrixList().remove(chargeMatrix4);
                        }
                        if (periodicChargeRate.getChargeRate5()==null && chargeMatrix5.getPeriodSeq()!=null) {
                            periodicChargeRate.getChargeMatrixList().remove(chargeMatrix5);
                        }
                        if (periodicChargeRate.getChargeRate6()==null && chargeMatrix6.getPeriodSeq()!=null) {
                            periodicChargeRate.getChargeMatrixList().remove(chargeMatrix6);
                        }
                        if (periodicChargeRate.getChargeRate7()==null && chargeMatrix7.getPeriodSeq()!=null) {
                            periodicChargeRate.getChargeMatrixList().remove(chargeMatrix7);
                        }
                        if (periodicChargeRate.getChargeRate8()==null && chargeMatrix8.getPeriodSeq()!=null) {
                            periodicChargeRate.getChargeMatrixList().remove(chargeMatrix8);
                        }
                        if (periodicChargeRate.getChargeRate9()==null && chargeMatrix9.getPeriodSeq()!=null) {
                            periodicChargeRate.getChargeMatrixList().remove(chargeMatrix9);
                        }
                        if (periodicChargeRate.getChargeRate10()==null && chargeMatrix10.getPeriodSeq()!=null) {
                            periodicChargeRate.getChargeMatrixList().remove(chargeMatrix10);
                        }
                        if (periodicChargeRate.getChargeRate11()==null && chargeMatrix11.getPeriodSeq()!=null) {
                            periodicChargeRate.getChargeMatrixList().remove(chargeMatrix11);
                        }
                        if (periodicChargeRate.getChargeRate12()==null && chargeMatrix12.getPeriodSeq()!=null) {
                            periodicChargeRate.getChargeMatrixList().remove(chargeMatrix12);
                        }                        
                    }
                    if (periodicChargeRate.getChargeRate1()!=null && (chargeMatrix1.getPeriodSeq()==null || chargeMatrix1.getPeriodSeq().equals(0d))) {
                        chargeMatrix1.setPeriodSeq(1D);
                        chargeMatrix1.setChargeRate(periodicChargeRate.getChargeRate1());
                        periodicChargeRate.getChargeMatrixList().add(chargeMatrix1);
                    }
                    if (periodicChargeRate.getChargeRate2()!=null && (chargeMatrix2.getPeriodSeq()==null || chargeMatrix2.getPeriodSeq().equals(0d))) {
                        chargeMatrix2.setPeriodSeq(2D);
                        chargeMatrix2.setChargeRate(periodicChargeRate.getChargeRate2());
                        periodicChargeRate.getChargeMatrixList().add(chargeMatrix2);
                    } 
                    if (periodicChargeRate.getChargeRate3()!=null && (chargeMatrix3.getPeriodSeq()==null || chargeMatrix3.getPeriodSeq().equals(0d))) {
                        chargeMatrix3.setPeriodSeq(3D);
                        chargeMatrix3.setChargeRate(periodicChargeRate.getChargeRate3());
                        periodicChargeRate.getChargeMatrixList().add(chargeMatrix3);
                    }
                    if (periodicChargeRate.getChargeRate4()!=null && (chargeMatrix4.getPeriodSeq()==null || chargeMatrix4.getPeriodSeq().equals(0d))) {
                        chargeMatrix4.setPeriodSeq(4D);
                        chargeMatrix4.setChargeRate(periodicChargeRate.getChargeRate4());
                        periodicChargeRate.getChargeMatrixList().add(chargeMatrix4);
                    }
                    if (periodicChargeRate.getChargeRate5()!=null && (chargeMatrix5.getPeriodSeq()==null || chargeMatrix5.getPeriodSeq().equals(0d))) {
                        chargeMatrix5.setPeriodSeq(5D);
                        chargeMatrix5.setChargeRate(periodicChargeRate.getChargeRate5());
                        periodicChargeRate.getChargeMatrixList().add(chargeMatrix5);
                    }
                    if (periodicChargeRate.getChargeRate6()!=null && (chargeMatrix6.getPeriodSeq()==null || chargeMatrix6.getPeriodSeq().equals(0d))) {
                        chargeMatrix6.setPeriodSeq(6D);
                        chargeMatrix6.setChargeRate(periodicChargeRate.getChargeRate6());
                        periodicChargeRate.getChargeMatrixList().add(chargeMatrix6);
                    }
                    if (periodicChargeRate.getChargeRate7()!=null && (chargeMatrix7.getPeriodSeq()==null || chargeMatrix7.getPeriodSeq().equals(0d))) {
                        chargeMatrix7.setPeriodSeq(7D);
                        chargeMatrix7.setChargeRate(periodicChargeRate.getChargeRate7());
                        periodicChargeRate.getChargeMatrixList().add(chargeMatrix7);
                    }
                    if (periodicChargeRate.getChargeRate8()!=null && (chargeMatrix8.getPeriodSeq()==null || chargeMatrix8.getPeriodSeq().equals(0d))) {
                        chargeMatrix8.setPeriodSeq(8D);
                        chargeMatrix8.setChargeRate(periodicChargeRate.getChargeRate8());
                        periodicChargeRate.getChargeMatrixList().add(chargeMatrix8);
                    }
                    if (periodicChargeRate.getChargeRate9()!=null && (chargeMatrix9.getPeriodSeq()==null || chargeMatrix9.getPeriodSeq().equals(0d))) {
                        chargeMatrix9.setPeriodSeq(9D);
                        chargeMatrix9.setChargeRate(periodicChargeRate.getChargeRate9());
                        periodicChargeRate.getChargeMatrixList().add(chargeMatrix9);
                    }
                    if (periodicChargeRate.getChargeRate10()!=null && (chargeMatrix10.getPeriodSeq()==null || chargeMatrix10.getPeriodSeq().equals(0d))) {
                        chargeMatrix10.setPeriodSeq(10D);
                        chargeMatrix10.setChargeRate(periodicChargeRate.getChargeRate10());
                        periodicChargeRate.getChargeMatrixList().add(chargeMatrix10);
                    }
                    if (periodicChargeRate.getChargeRate11()!=null && (chargeMatrix11.getPeriodSeq()==null || chargeMatrix11.getPeriodSeq().equals(0d))) {
                        chargeMatrix11.setPeriodSeq(11D);
                        chargeMatrix11.setChargeRate(periodicChargeRate.getChargeRate11());
                        periodicChargeRate.getChargeMatrixList().add(chargeMatrix11);
                    }
                    if (periodicChargeRate.getChargeRate12()!=null && (chargeMatrix12.getPeriodSeq()==null || chargeMatrix12.getPeriodSeq().equals(0d))) {
                        chargeMatrix12.setPeriodSeq(12D);
                        chargeMatrix12.setChargeRate(periodicChargeRate.getChargeRate12());
                        periodicChargeRate.getChargeMatrixList().add(chargeMatrix12);
                    }

                    
                    
                }
            }

        }
    }
    
    private FindCriteriaJpe customFC(FindCriteria findCriteria) {
        FindCriteriaJpe fc = null;
        if (findCriteria == null) {
            fc = new FindCriteriaJpe();
            ViewCriteriaJpe rootViewCriteria = new ViewCriteriaJpe();
            fc.setFilter(rootViewCriteria);
        } else {
            fc = jaxbSdoHelper.unwrap(findCriteria, true);
        }
        if (fc != null) {
            if (fc.getFilter() == null) {
                fc.setFilter(new ViewCriteriaJpe());
                fc.getFilter().setConjunction(ConjunctionEnumJpe.AND);
            }
            
            List<Object> receiptTypeList = new ArrayList<Object>();
            receiptTypeList.addAll(Arrays.asList("P"));
            
            ViewCriteriaItemJpe vci = new ViewCriteriaItemJpe();
            vci.setAttribute("chargeType");
            vci.setOperator("IN");
            vci.setValue(receiptTypeList);
            vci.setConjunction(ConjunctionEnumJpe.AND);
            vci.setUpperCaseCompareYn(true);
            
            List<ViewCriteriaRowJpe> rowList = fc.getFilter().getGroup();
            if (rowList.isEmpty()) {
                ViewCriteriaRowJpe vcrJpe = new ViewCriteriaRowJpe();
                vcrJpe.getItem().add(vci);
                rowList.add(vcrJpe);
            } else {
                rowList.get(0).getItem().add(vci);
            }
        }
        return fc;
    }
}
