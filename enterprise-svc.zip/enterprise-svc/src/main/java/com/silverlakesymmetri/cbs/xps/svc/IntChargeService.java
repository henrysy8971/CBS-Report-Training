package com.silverlakesymmetri.cbs.xps.svc;

import java.util.List;
import java.util.Map;

import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation;
import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation.ServiceOperationType;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.svc.BusinessService;
import com.silverlakesymmetri.cbs.xps.bdo.sdo.IntCharge;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.IntChargeJpe;

public interface IntChargeService extends BusinessService<IntCharge, IntChargeJpe> {

	public static final String SVC_OP_NAME_INTCHARGESERVICE_GET = "IntChargeService.get";
	public static final String SVC_OP_NAME_INTCHARGESERVICE_QUERY = "IntChargeService.query";
	public static final String SVC_OP_NAME_INTCHARGESERVICE_CREATE = "IntChargeService.create";
	public static final String SVC_OP_NAME_INTCHARGESERVICE_UPDATE = "IntChargeService.update";
	public static final String SVC_OP_NAME_INTCHARGESERVICE_DELETE = "IntChargeService.delete";
	public static final String SVC_OP_NAME_INTCHARGESERVICE_FIND = "IntChargeService.find";
	public static final String SVC_OP_NAME_INTCHARGESERVICE_COUNT = "IntChargeService.count";

	@ServiceOperation(name = SVC_OP_NAME_INTCHARGESERVICE_GET, type = ServiceOperationType.GET)
	public IntCharge getByPk(String publicKey, IntCharge reference);

	@ServiceOperation(name = SVC_OP_NAME_INTCHARGESERVICE_QUERY)
	public List<IntCharge> query(int offset, int resultLimit, String groupBy, String order,
			Map<String, Object> filters);

	@ServiceOperation(name = SVC_OP_NAME_INTCHARGESERVICE_CREATE)
	public IntCharge create(IntCharge dataObject);

	@ServiceOperation(name = SVC_OP_NAME_INTCHARGESERVICE_UPDATE)
	public IntCharge update(IntCharge dataObject);

	@ServiceOperation(name = SVC_OP_NAME_INTCHARGESERVICE_DELETE)
	public boolean delete(IntCharge dataObject);

	@ServiceOperation(name = SVC_OP_NAME_INTCHARGESERVICE_FIND)
	public List<IntCharge> find(FindCriteria findCriteria, CbsHeader cbsHeader);

	@ServiceOperation(name = SVC_OP_NAME_INTCHARGESERVICE_COUNT, type = ServiceOperationType.GET)
	public Long count(FindCriteria findCriteria, CbsHeader cbsHeader);

	/**
	 * Two Tier Chargess.
	 *
	 * @return Two Tier charges.
	 */
	List<IntCharge> getAll();
}
