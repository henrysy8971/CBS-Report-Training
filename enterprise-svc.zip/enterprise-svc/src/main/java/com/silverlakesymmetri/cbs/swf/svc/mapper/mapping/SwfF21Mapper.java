package com.silverlakesymmetri.cbs.swf.svc.mapper.mapping;

import org.apache.commons.lang3.StringUtils;
import org.mapstruct.InheritInverseConfiguration;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Mappings;

import com.silverlakesymmetri.cbs.swf.jpa.mapping.sdo.SwfF21Jpe;
import com.silverlakesymmetri.cbs.swf.xmlapi.SWFF21TYPEType;

@Mapper(imports=StringUtils.class)
public interface SwfF21Mapper {
	
	@Mappings({
		@Mapping(source="opt", target="OPT"),
		@Mapping(source="reference", target="REFERENCE"),
	})
	SWFF21TYPEType mapToApi(SwfF21Jpe jpe);
	
	@InheritInverseConfiguration(name="mapToApi")
	@Mappings({
		@Mapping(target="opt", expression="java(StringUtils.isNotBlank(api.getOPT())?api.getOPT():null)"),
	})
	SwfF21Jpe mapToJpe(SWFF21TYPEType api);

}