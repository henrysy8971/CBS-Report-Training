package com.silverlakesymmetri.cbs.xps.svc.mapper;

import org.mapstruct.AfterMapping;
import org.mapstruct.Context;
import org.mapstruct.InheritInverseConfiguration;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingTarget;
import org.mapstruct.Mappings;

import com.silverlakesymmetri.cbs.commons.jpa.util.DateTimeHelper;
import com.silverlakesymmetri.cbs.commons.xmlapi.enums.CbsXmlApiOperation;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.ChargeSettlementDetailsJpe;
import com.silverlakesymmetri.cbs.xps.svc.mapper.mapping.AbstractSwiftSettleMapper;
import com.silverlakesymmetri.cbs.xps.svc.mapper.mapping.SettleMessageJpeToXPSSETTLEMESSAGETYPETypeMapper;
import com.silverlakesymmetri.cbs.xps.xmlapi.XPSTRANCHARGESETTLEDETAILAPIType;

@Mapper(uses = { DateTimeHelper.class, SettleMessageJpeToXPSSETTLEMESSAGETYPETypeMapper.class })
public abstract class ChargeSettlementDetailsServiceMapper extends AbstractSwiftSettleMapper {

	@Mappings({
		@Mapping(target = "AMOUNT", source = "amount"),
		@Mapping(target = "SETTLECCY", source = "settleCcy"),
		@Mapping(target = "BASERATE", source = "baseRate"),
		@Mapping(target = "BASEQUOTE", source = "baseQuote"),
		@Mapping(target = "SETTLEBASERATE", source = "settleBaseRate"),
		@Mapping(target = "SETTLEBASEQUOTE", source = "settleBaseQuote"),
		@Mapping(target = "EXCHQUOTE", source = "exchQuote"),
		@Mapping(target = "EXCHSPOTRATE", source = "exchSpotRate"),
		@Mapping(target = "EXCHFWDPOINTS", source = "exchFwdPoints"),
		@Mapping(target = "EXCHSPREAD", source = "exchSpread"),
		@Mapping(target = "EXCHCLIENTSPREAD", source = "exchClientSpread"),
		@Mapping(target = "EXCHRATE", source = "exchRate"),
		@Mapping(target = "SETTLEAMT", source = "settleAmt"),
		@Mapping(target = "ACCTTYPE", source = "acctType"),
		@Mapping(target = "SETTLEMETHOD", source = "settleMethod"),
		@Mapping(target = "XPSSETTLEKEY", source = "xpsSettleKey"),
		@Mapping(target = "INTERNALKEY", source = "internalKey"),
		@Mapping(target = "RELINTERNALKEY", source = "relInternalKey"),
		@Mapping(target = "ACCTRESTRAINTKEY", source = "acctRestraintKey"),
		@Mapping(target = "MESSAGE", source = "messageStructRec"),
		@Mapping(target = "SEQNO", source = "seqNo")
	})
	public abstract XPSTRANCHARGESETTLEDETAILAPIType mapToApi(ChargeSettlementDetailsJpe jpe, @Context CbsXmlApiOperation oper);

	@InheritInverseConfiguration(name="mapToApi")
	public abstract ChargeSettlementDetailsJpe mapToJpe(XPSTRANCHARGESETTLEDETAILAPIType api, @MappingTarget ChargeSettlementDetailsJpe jpe);
	
	@InheritInverseConfiguration(name="mapToApi")
	public abstract ChargeSettlementDetailsJpe mapToJpe(XPSTRANCHARGESETTLEDETAILAPIType api);

	@AfterMapping
	protected void afterMapToApi(@MappingTarget XPSTRANCHARGESETTLEDETAILAPIType api, ChargeSettlementDetailsJpe jpe, @Context CbsXmlApiOperation oper){
		super.mapToApi(api, jpe, oper);
	}
	
	@AfterMapping
	protected void afterMapToJpe(@MappingTarget ChargeSettlementDetailsJpe jpe, XPSTRANCHARGESETTLEDETAILAPIType api){
		super.mapToJpe(jpe, api);
	}
	
}
