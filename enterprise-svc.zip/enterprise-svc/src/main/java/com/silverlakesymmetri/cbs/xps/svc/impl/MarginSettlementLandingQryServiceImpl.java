package com.silverlakesymmetri.cbs.xps.svc.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.mysema.query.types.EntityPath;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.bdo.ViewCriteriaItem;
import com.silverlakesymmetri.cbs.commons.bdo.ViewCriteriaRow;
import com.silverlakesymmetri.cbs.commons.jpa.entity.ConjunctionEnumJpe;
import com.silverlakesymmetri.cbs.commons.jpa.entity.ViewCriteriaItemJpe;
import com.silverlakesymmetri.cbs.commons.svc.AbstractBusinessService;
import com.silverlakesymmetri.cbs.xps.bdo.sdo.MarginSettlementLandingQry;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.MarginSettlementLandingQryJpe;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.QMarginSettlementLandingQryJpe;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.id.MarginSettlementLandingQryPk;
import com.silverlakesymmetri.cbs.xps.svc.ChargesUtilityService;
import com.silverlakesymmetri.cbs.xps.svc.MarginSettlementLandingQryService;

@Service
@Transactional
public class MarginSettlementLandingQryServiceImpl extends AbstractBusinessService<MarginSettlementLandingQry, MarginSettlementLandingQryJpe, MarginSettlementLandingQryPk> implements MarginSettlementLandingQryService {

	@Autowired
	private ChargesUtilityService chargesUtility;

	@Override
	protected MarginSettlementLandingQryPk getIdFromDataObjectInstance(MarginSettlementLandingQry dataObject) {
		MarginSettlementLandingQryJpe jpe = jaxbSdoHelper.unwrap(dataObject);
		return new MarginSettlementLandingQryPk(jpe.getInternalKey());
	}

	@Override
	protected EntityPath<MarginSettlementLandingQryJpe> getEntityPath() {
		return QMarginSettlementLandingQryJpe.marginSettlementLandingQryJpe;
	}

	@Override
	public MarginSettlementLandingQry getByPk(String publicKey, MarginSettlementLandingQry reference) {
		MarginSettlementLandingQry bdo = super.getByPk(publicKey, reference);
		return bdo;
	}

	@Override
	public List<MarginSettlementLandingQry> query(int offset, int resultLimit, String groupBy, String order, Map<String, Object> filters) {
    	if(filters.containsKey("refNo") && filters.containsKey("instrumentType")){
    		String type = filters.get("domainType") != null ? filters.get("domainType").toString() : null;
			Long tranKey = chargesUtility.getTranKey(filters.get("refNo").toString(), type, filters.get("instrumentType").toString());
			filters.put("tranKey", tranKey);
			filters.remove("refNo");
			filters.remove("domainType");
    	}
		return super.query(offset, resultLimit, groupBy, order, filters);
	}
	
	@Override
	public List<MarginSettlementLandingQry> find(FindCriteria findCriteria, CbsHeader cbsHeader){
    	if(findCriteria.getFilter() != null && findCriteria.getFilter().getGroup() != null && findCriteria.getFilter().getGroup().size() > 0){
    		for(ViewCriteriaRow criteriaRow : findCriteria.getFilter().getGroup()){
    			if(criteriaRow.getItem() != null && criteriaRow.getItem().size() > 0){
    				String refNo = null;
    				String instrumentType = null;
    				String type = null;
    				List<ViewCriteriaItemJpe> otherFilters = new ArrayList<ViewCriteriaItemJpe>();
    				for(ViewCriteriaItem item : criteriaRow.getItem()){
    					ViewCriteriaItemJpe vci = jaxbSdoHelper.unwrap(item, ViewCriteriaItemJpe.class);
    					if(item.getAttribute().equals("refNo")){
    						refNo = vci.getValue().get(0).toString();
    					} else if(item.getAttribute().equals("instrumentType")){
    						instrumentType = vci.getValue().get(0).toString();
    					} else if(item.getAttribute().equals("domainType")){
    						if(item.getValue() != null && item.getValue().size() > 0){
        						type = vci.getValue().get(0) != null ? vci.getValue().get(0).toString() : null;
    						}
    					} else {
    						otherFilters.add(vci);
    					}
    				}
    				if(refNo != null && instrumentType != null){
    					Long tranKey = chargesUtility.getTranKey(refNo, type, instrumentType);
    					List<ViewCriteriaItem> modifiedItems = new ArrayList<ViewCriteriaItem>();
    					//modifiedItems.add(instrumentTypeVci);
    					ViewCriteriaItemJpe vci = new ViewCriteriaItemJpe();	
    					List<Object> values = new ArrayList<Object>();
    					values.add(tranKey);
    					vci.setAttribute("tranKey");
    					vci.setOperator("=");
    					vci.setValue(values);
    					vci.setConjunction(ConjunctionEnumJpe.AND);
    					vci.setUpperCaseCompareYn(true);
    					modifiedItems.add(jaxbSdoHelper.wrap(vci));
    					for(ViewCriteriaItemJpe otherVci : otherFilters){
    						modifiedItems.add(jaxbSdoHelper.wrap(otherVci));
    					}
    					criteriaRow.setItem(modifiedItems);
    				}
    			}
    		}
    	}
		return super.find(findCriteria, cbsHeader);
	}

    @Override
    public Long count(FindCriteria findCriteria, CbsHeader cbsHeader) {
    	List<MarginSettlementLandingQry> list = find(findCriteria, cbsHeader);
    	return list != null ? new Integer(list.size()).longValue() : 0L;
    }

}