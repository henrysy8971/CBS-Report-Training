package com.silverlakesymmetri.cbs.gla.svc.impl;

import com.mysema.query.types.EntityPath;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.svc.AbstractBusinessService;
import com.silverlakesymmetri.cbs.gla.bdo.sdo.GlAcctBalBySubledgerQry;
import com.silverlakesymmetri.cbs.gla.jpa.mapping.sdo.GlAcctBalBySubledgerQryJpe;
import com.silverlakesymmetri.cbs.gla.jpa.mapping.sdo.QGlAcctBalBySubledgerQryJpe;
import com.silverlakesymmetri.cbs.gla.jpa.mapping.sdo.id.GlAcctBalBySubledgerQryPk;
import com.silverlakesymmetri.cbs.gla.svc.GlAcctBalBySubLedgerQryService;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;

@Service
public class GlAcctBalBySubLedgerQryServiceImpl extends AbstractBusinessService<GlAcctBalBySubledgerQry, GlAcctBalBySubledgerQryJpe, GlAcctBalBySubledgerQryPk> implements
		GlAcctBalBySubLedgerQryService {

	@Override
	protected GlAcctBalBySubledgerQryPk getIdFromDataObjectInstance(GlAcctBalBySubledgerQry dataObject) {
		return new GlAcctBalBySubledgerQryPk(dataObject.getGlCode(), dataObject.getBranch(), dataObject.getCcy());
	}

	@Override
	protected EntityPath<GlAcctBalBySubledgerQryJpe> getEntityPath() {
		return QGlAcctBalBySubledgerQryJpe.glAcctBalBySubledgerQryJpe;
	}
	
	@Override
	public GlAcctBalBySubledgerQry getByPk(String publicKey, GlAcctBalBySubledgerQry dataObject) {
		return super.getByPk(publicKey, dataObject);
	}


	@Override
	public List<GlAcctBalBySubledgerQry> query(int offset, int resultLimit, String groupBy, String order,
			Map<String, Object> filters) {
		return super.query(offset, resultLimit, groupBy, order, filters);
	}

	@Override
	public List<GlAcctBalBySubledgerQry> find(FindCriteria findCriteria, CbsHeader cbsHeader) {
		return super.find(findCriteria, cbsHeader);
	}
	
	@Override
	public GlAcctBalBySubledgerQry get(GlAcctBalBySubledgerQry objectInstanceIdentifier) {
		return super.get(objectInstanceIdentifier);
	}

}
