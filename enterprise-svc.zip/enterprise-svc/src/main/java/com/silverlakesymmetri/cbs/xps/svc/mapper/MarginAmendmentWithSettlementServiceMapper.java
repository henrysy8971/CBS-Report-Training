package com.silverlakesymmetri.cbs.xps.svc.mapper;

import org.mapstruct.Context;
import org.mapstruct.InheritInverseConfiguration;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingTarget;
import org.mapstruct.Mappings;

import com.silverlakesymmetri.cbs.commons.jpa.util.DateTimeHelper;
import com.silverlakesymmetri.cbs.commons.xmlapi.enums.CbsXmlApiOperation;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.MarginAmendmentWithSettlementJpe;
import com.silverlakesymmetri.cbs.xps.svc.mapper.mapping.XpsMessageJpeToXPSMESSAGETYPETypeMapper;
import com.silverlakesymmetri.cbs.xps.xmlapi.XPSTRANMARGINAMENDMENTWITHSETTLEAPIType;

@Mapper(uses={ DateTimeHelper.class, 
			   MarginSettlementServiceMapper.class,
			   XpsMessageJpeToXPSMESSAGETYPETypeMapper.class})
public interface MarginAmendmentWithSettlementServiceMapper {
	@Mappings({
//		@Mapping(expression = "java(oper != null ? oper.getOperation() : null)", target="OPERATION"),
		@Mapping(source="internalKey", target = "INTERNALKEY"),
		@Mapping(source="acctRestraintKey", target = "ACCTRESTRAINTKEY"),
		@Mapping(source="marginAmendmentStructRec.marginInternalKey", target = "MARGININTERNALKEY"),
		@Mapping(source="marginAmendmentStructRec.seqNo", target = "SEQNO"),
		@Mapping(source="marginAmendmentStructRec.valueDate", target = "VALUEDATE", qualifiedByName = {"DateTimeHelper", "convertDateToCbsXmlApiDate"}),
		@Mapping(source="marginAmendmentStructRec.tranStatus", target = "TRANSTATUS"),
		@Mapping(source="marginAmendmentStructRec.incrDecrInd", target = "INCRDECRIND"),
		@Mapping(source="marginAmendmentStructRec.tranEquivAmt", target = "TRANEQUIVAMT"),
		@Mapping(source="marginAmendmentStructRec.exchRate", target = "EXCHRATE"),
		@Mapping(source="marginAmendmentStructRec.exchQuote", target = "EXCHQUOTE"),
		@Mapping(source="marginAmendmentStructRec.amount", target = "AMOUNT"),
		@Mapping(source="marginAmendmentStructRec.baseRate", target = "BASERATE"),
		@Mapping(source="marginAmendmentStructRec.baseQuote", target = "BASEQUOTE"),
		@Mapping(source="marginAmendmentStructRec.baseEquiv", target = "BASEEQUIV"),
		@Mapping(source="marginAmendmentStructRec.localRate", target = "LOCALRATE"),
		@Mapping(source="marginAmendmentStructRec.localQuote", target = "LOCALQUOTE"),
		@Mapping(source="marginAmendmentStructRec.localEquiv", target = "LOCALEQUIV"),
		@Mapping(source="marginAmendmentStructRec.messageStructList", target = "MESSAGELIST.XPSMESSAGETYPE"),
		@Mapping(source="marginAmendmentStructRec.oldTranEquivAmt", target = "OLDAMOUNT"),
		@Mapping(source="marginAmendmentStructRec.oldAmount", target = "OLDTRANEQUIVAMT"),
		@Mapping(source="settlementStructRec", target = "SETTLEMENT")
	})
	public XPSTRANMARGINAMENDMENTWITHSETTLEAPIType mapToApi(MarginAmendmentWithSettlementJpe jpe, @Context CbsXmlApiOperation oper);
	
	@InheritInverseConfiguration(name = "mapToApi")
	@Mappings({
		@Mapping(source="VALUEDATE", target="marginAmendmentStructRec.valueDate", qualifiedByName = {"DateTimeHelper", "convertCbsApiDateToString"})
	})
	public MarginAmendmentWithSettlementJpe mapToJpe(XPSTRANMARGINAMENDMENTWITHSETTLEAPIType api, @MappingTarget MarginAmendmentWithSettlementJpe jpe);
	
	@InheritInverseConfiguration(name = "mapToApi")
	@Mappings({
		@Mapping(source="VALUEDATE", target="marginAmendmentStructRec.valueDate", qualifiedByName = {"DateTimeHelper", "convertCbsApiDateToString"})
	})
	public MarginAmendmentWithSettlementJpe mapToJpe(XPSTRANMARGINAMENDMENTWITHSETTLEAPIType api);
}
