package com.silverlakesymmetri.cbs.swf.svc.mapper.mapping;

import org.mapstruct.InheritInverseConfiguration;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Mappings;

import com.silverlakesymmetri.cbs.swf.jpa.mapping.sdo.SwfF77TextJpe;
import com.silverlakesymmetri.cbs.swf.xmlapi.SWFF77TEXTTYPEType;

@Mapper()
public interface SwfF77TextMapper {
	@Mappings({
		@Mapping(source="opt", target="OPT"),
		@Mapping(source="narrative", target="NARRATIVE")
	})
	SWFF77TEXTTYPEType mapToApi(SwfF77TextJpe jpe);
	
	@InheritInverseConfiguration(name = "mapToApi")
	SwfF77TextJpe mapToJpe(SWFF77TEXTTYPEType api);
	
}
