package com.silverlakesymmetri.cbs.swf.svc.mapper.mapping;

import org.apache.commons.lang3.StringUtils;
import org.mapstruct.DecoratedWith;
import org.mapstruct.InheritInverseConfiguration;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Mappings;

import com.silverlakesymmetri.cbs.commons.jpa.util.DateTimeHelper;
import com.silverlakesymmetri.cbs.swf.jpa.mapping.sdo.SwfF32Jpe;
import com.silverlakesymmetri.cbs.swf.svc.mapper.decorator.SwfF32MapperDecorator;
import com.silverlakesymmetri.cbs.swf.xmlapi.SWFF32TYPEType;

@Mapper(imports=StringUtils.class, uses={DateTimeHelper.class})
@DecoratedWith(SwfF32MapperDecorator.class)
public interface SwfF32Mapper {
	@Mappings({
		@Mapping(source="opt", target="OPT"),
		@Mapping(source="valueDate", target="VALUEDATE", qualifiedByName = {"DateTimeHelper","convertDateToCbsXmlApiDate"}),
		@Mapping(source="currency", target="CURRENCY"),
		@Mapping(source="amount", target="AMOUNT"),
		@Mapping(source="periodType", target="PERIODTYPE"),
		@Mapping(source="periodNo", target="PERIODNO"),
		@Mapping(source="code", target="CODE"),
		
	})
	SWFF32TYPEType mapToApi(SwfF32Jpe jpe);
	
	@Mappings({
		@Mapping(target="opt", expression="java(StringUtils.isNotBlank(api.getOPT())?api.getOPT():null)"),
		@Mapping(target="valueDate", source="VALUEDATE", qualifiedByName = {"DateTimeHelper","convertCbsApiDateToString"}),		
	})
	@InheritInverseConfiguration(name = "mapToApi")
	SwfF32Jpe mapToJpe(SWFF32TYPEType api);
}

