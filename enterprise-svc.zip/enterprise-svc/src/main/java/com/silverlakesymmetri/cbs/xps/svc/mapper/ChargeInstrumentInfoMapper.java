package com.silverlakesymmetri.cbs.xps.svc.mapper;

import org.mapstruct.Context;
import org.mapstruct.DecoratedWith;
import org.mapstruct.InheritInverseConfiguration;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingTarget;
import org.mapstruct.Mappings;

import com.silverlakesymmetri.cbs.commons.jpa.util.DateTimeHelper;
import com.silverlakesymmetri.cbs.commons.xmlapi.enums.CbsXmlApiOperation;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.ChargeDetailsJpe;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.ChargeInstrumentInfoJpe;
import com.silverlakesymmetri.cbs.xps.svc.mapper.decorator.ChargeInstrumentInfoDecorator;
import com.silverlakesymmetri.cbs.xps.xmlapi.XPSCHARGEINSTRUMENTTYPEType;

@Mapper(uses = { DateTimeHelper.class })
@DecoratedWith(ChargeInstrumentInfoDecorator.class)
public interface ChargeInstrumentInfoMapper {

	@Mappings({
		@Mapping(source="tranKey", target = "TRANKEY"),
		@Mapping(source="refNo", target = "REFNO"),
		@Mapping(source="relatedRefNo", target = "RELATEDREFNO"),
		@Mapping(source="impExpType", target = "IMPEXPTYPE"),
		@Mapping(source="instrumentType", target = "INSTRUMENTTYPE"),
		@Mapping(source="sightUsance", target = "SIGHTUSANCE"),
		@Mapping(source="prodType", target = "PRODTYPE"),
		@Mapping(source="prodSubType", target = "PRODSUBTYPE"),
		@Mapping(source="bookBranch", target = "BOOKBRANCH"),
		@Mapping(source="ccy", target = "CCY"),
		@Mapping(source="amount", target = "AMOUNT"),
		@Mapping(source="customerClientId", target = "CUSTOMERCLIENTID"),
		@Mapping(source="customerContactRefNo", target = "CUSTOMERCONTACTREFNO"),
		@Mapping(source="customerContactAddress", target = "CUSTOMERCONTACTADDRESS"),
		@Mapping(source="agentClientId", target = "AGENTCLIENTID"),
		@Mapping(source="agentContactRefNo", target = "AGENTCONTACTREFNO"),
		@Mapping(source="agentContactAddress", target = "AGENTCONTACTADDRESS"),
		@Mapping(source="toleranceAdd", target = "TOLERANCEADD"),
		@Mapping(source="toleranceSub", target = "TOLERANCESUB"),
		@Mapping(source="relatedKey", target = "RELATEDKEY"),
		@Mapping(source="relatedCcy", target = "RELATEDCCY"),
		@Mapping(source="relatedAmount", target = "RELATEDAMOUNT"),
		@Mapping(source="supplierCreditIntAmt", target = "SUPPLIERCREDITINTAMT"),
		@Mapping(source="sightAmt", target = "SIGHTAMT"),
		@Mapping(source="usanceAmt", target = "USANCEAMT"),
		@Mapping(source="drawnAmt", target = "DRAWNAMT"),
		@Mapping(source="paidAmt", target = "PAIDAMT"),
		@Mapping(source="receivedAmt", target = "RECEIVEDAMT"),
		@Mapping(source="baseCcy", target = "BASECCY"),
		@Mapping(source="baseRate", target = "BASERATE"),
		@Mapping(source="baseQuote", target = "BASEQUOTE"),
		@Mapping(source="baseEquiv", target = "BASEEQUIV"),
		@Mapping(source="localCcy", target = "LOCALCCY"),
		@Mapping(source="localRate", target = "LOCALRATE"),
		@Mapping(source="localQuote", target = "LOCALQUOTE"),
		@Mapping(source="localEquiv", target = "LOCALEQUIV"),
		@Mapping(source="fobValue", target = "FOBVALUE"),
		@Mapping(source="cfValue", target = "CFVALUE"),
		@Mapping(source="eventAmt", target = "EVENTAMT"),
		@Mapping(source="issueDate", target = "ISSUEDATE", qualifiedByName = {"DateTimeHelper", "convertDateToCbsXmlApiDate"}),
		@Mapping(source="expiryDate", target = "EXPIRYDATE", qualifiedByName = {"DateTimeHelper", "convertDateToCbsXmlApiDate"}),
		@Mapping(source="collectedCommDate", target = "COLLECTEDCOMMDATE", qualifiedByName = {"DateTimeHelper", "convertDateToCbsXmlApiDate"}),
		@Mapping(source="ccyRateType", target = "CCYRATETYPE")
	})
	public XPSCHARGEINSTRUMENTTYPEType mapToApi(ChargeInstrumentInfoJpe jpe, @Context CbsXmlApiOperation oper);

	@InheritInverseConfiguration(name = "mapToApi")
	@Mappings({
		@Mapping(source="ISSUEDATE", target="issueDate", qualifiedByName = {"DateTimeHelper", "convertCbsApiDateToString"}),
		@Mapping(source="EXPIRYDATE", target="expiryDate", qualifiedByName = {"DateTimeHelper", "convertCbsApiDateToString"}),
		@Mapping(source="COLLECTEDCOMMDATE", target="collectedCommDate", qualifiedByName = {"DateTimeHelper", "convertCbsApiDateToString"})
	})
	public ChargeInstrumentInfoJpe mapToJpe(XPSCHARGEINSTRUMENTTYPEType api, @MappingTarget ChargeInstrumentInfoJpe jpe);
}