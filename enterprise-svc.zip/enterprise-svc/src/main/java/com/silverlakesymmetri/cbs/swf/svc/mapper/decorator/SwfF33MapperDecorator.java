package com.silverlakesymmetri.cbs.swf.svc.mapper.decorator;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

import com.silverlakesymmetri.cbs.swf.jpa.mapping.sdo.SwfF33Jpe;
import com.silverlakesymmetri.cbs.swf.svc.mapper.mapping.SwfF33Mapper;
import com.silverlakesymmetri.cbs.swf.xmlapi.SWFF33TYPEType;

public abstract class SwfF33MapperDecorator implements SwfF33Mapper {
	
	@Autowired
	@Qualifier("delegate")
	protected SwfF33Mapper delegate;

	@Override
	public SWFF33TYPEType mapToApi(SwfF33Jpe jpe){
		SWFF33TYPEType swfF33 = delegate.mapToApi(jpe);
		if(swfF33 != null && swfF33.getAMOUNT() == null && swfF33.getCURRENCY() == null && swfF33.getVALUEDATE() == null){
			return null;
		}
		return swfF33;
	}
	
	@Override
	public SwfF33Jpe mapToJpe(SWFF33TYPEType api){
		return delegate.mapToJpe(api);
	}
	
}
