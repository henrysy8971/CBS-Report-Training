package com.silverlakesymmetri.cbs.xps.svc.mapper.decorator;

import java.util.ArrayList;

import org.mapstruct.Context;
import org.mapstruct.MappingTarget;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

import com.silverlakesymmetri.cbs.commons.xmlapi.enums.CbsXmlApiOperation;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.ChargeDetailsJpe;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.ChargeMasterJpe;
import com.silverlakesymmetri.cbs.xps.svc.mapper.ChargeDetailServiceMapper;
import com.silverlakesymmetri.cbs.xps.svc.mapper.ChargeRecalculateServiceMapper;
import com.silverlakesymmetri.cbs.xps.xmlapi.XPSCHARGERECALCULATEAPIType;
import com.silverlakesymmetri.cbs.xps.xmlapi.XPSTRANCHARGEDETAILAPIType;

public abstract class ChargeRecalculateServiceDecorator implements ChargeRecalculateServiceMapper {
		
	@Autowired
	@Qualifier("delegate")
	protected ChargeRecalculateServiceMapper delegate;

	@Autowired
	protected ChargeDetailServiceMapper detailMapper;

	@Override
	public XPSCHARGERECALCULATEAPIType mapToApi(ChargeMasterJpe jpe, @Context CbsXmlApiOperation oper){
		XPSCHARGERECALCULATEAPIType req = (XPSCHARGERECALCULATEAPIType) delegate.mapToApi(jpe, oper);
		
		if(jpe.getChargeDetailsList() != null && jpe.getChargeDetailsList().size() > 0){
			//master's first detail is always the selected charge
			ChargeDetailsJpe detailsJpe = jpe.getChargeDetailsList().get(0);
			XPSTRANCHARGEDETAILAPIType detailApi = detailMapper.mapToApi(detailsJpe, oper);
			req.setCHARGE(detailApi);
			
			//master will have 2nd detail for related charge
			if(jpe.getChargeDetailsList().size() > 1){
				ChargeDetailsJpe relatedDetailsJpe = jpe.getChargeDetailsList().get(1);
				XPSTRANCHARGEDETAILAPIType relatedDetailApi = detailMapper.mapToApi(relatedDetailsJpe, oper);
				req.setRELATEDCHARGE(relatedDetailApi);
			}
		}
		//TODO: when is this set to N??
		req.setUSEEXISTINGEXCHRATE("Y");
		
		return  req;
	}
	
	@Override
	public ChargeMasterJpe mapToJpe(XPSCHARGERECALCULATEAPIType api, @MappingTarget ChargeMasterJpe jpe){
		delegate.mapToJpe(api, jpe);
		
		jpe.setChargeDetailsList(new ArrayList<ChargeDetailsJpe>());
		ChargeDetailsJpe detailsJpe = new ChargeDetailsJpe();
		detailsJpe = detailMapper.mapToJpe(api.getCHARGE(), detailsJpe);
		jpe.getChargeDetailsList().add(detailsJpe);
		return jpe;
	}

}


