package com.silverlakesymmetri.cbs.swf.svc.mapper.decorator;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

import com.silverlakesymmetri.cbs.swf.jpa.mapping.sdo.SwfFinEntityJpe;
import com.silverlakesymmetri.cbs.swf.svc.mapper.mapping.SwfF51Mapper;
import com.silverlakesymmetri.cbs.swf.xmlapi.SWFF51TYPEType;

public abstract class SwfF51MapperDecorator implements SwfF51Mapper {
	
	@Autowired
	@Qualifier("delegate")
	protected SwfF51Mapper delegate;

	@Override
	public SWFF51TYPEType mapToApi(SwfFinEntityJpe jpe){
		SWFF51TYPEType swfF51 = delegate.mapToApi(jpe);
		if(swfF51 != null && swfF51.getACCOUNT() == null && swfF51.getADDRESS() == null && swfF51.getBIC() == null && swfF51.getBRANCHLOCATION() == null){
			return null;
		}
		return swfF51;
	}
	
	@Override
	public SwfFinEntityJpe mapToJpe(SWFF51TYPEType api){
		return delegate.mapToJpe(api);
	}
	
}
