package com.silverlakesymmetri.cbs.gla.svc;

import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation;
import com.silverlakesymmetri.cbs.commons.svc.BusinessService;
import com.silverlakesymmetri.cbs.gla.bdo.sdo.GlAcctMovementQry;
import com.silverlakesymmetri.cbs.gla.jpa.mapping.sdo.GlAcctMovementQryJpe;

import java.util.List;
import java.util.Map;

public interface GlAcctMovementQryService extends BusinessService<GlAcctMovementQry, GlAcctMovementQryJpe> {

    public static final String SVC_OP_NAME_GLACCTMOVEMENTQRYSERVICE_GET = "GlAcctMovementQryService.get";
    public static final String SVC_OP_NAME_GLACCTMOVEMENTQRYSERVICE_GET_GL_ACCT_MOVEMENT = "GlAcctMovementQryService.glAccountMovement";

    @ServiceOperation(name = SVC_OP_NAME_GLACCTMOVEMENTQRYSERVICE_GET, type = ServiceOperation.ServiceOperationType.GET)
    public GlAcctMovementQry getByPk(String publicKey, GlAcctMovementQry reference);

    @ServiceOperation(name = SVC_OP_NAME_GLACCTMOVEMENTQRYSERVICE_GET_GL_ACCT_MOVEMENT, type = ServiceOperation.ServiceOperationType.GET, passParamAsMap = true)
    public GlAcctMovementQry glAccountMovement(Map<String, Object> filters);

}
