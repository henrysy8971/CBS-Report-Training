package com.silverlakesymmetri.cbs.swf.svc.mapper.decorator;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

import com.silverlakesymmetri.cbs.swf.jpa.mapping.sdo.SwfF11Jpe;
import com.silverlakesymmetri.cbs.swf.svc.mapper.mapping.SwfF11Mapper;
import com.silverlakesymmetri.cbs.swf.xmlapi.SWFF11TYPEType;

public abstract class SwfF11MapperDecorator implements SwfF11Mapper {
	
	@Autowired
	@Qualifier("delegate")
	protected SwfF11Mapper delegate;

	@Override
	public SWFF11TYPEType mapToApi(SwfF11Jpe jpe){
		SWFF11TYPEType swfF11 = delegate.mapToApi(jpe);
		if(swfF11 != null && swfF11.getMTNUMBER() == null && swfF11.getCURRENCY() == null && swfF11.getISN() == null && 
				swfF11.getQUALIFIER() == null && swfF11.getSENDDATE() == null && swfF11.getSESSIONNO() == null){
			return null;
		}
		return swfF11;
	}
	
	@Override
	public SwfF11Jpe mapToJpe(SWFF11TYPEType api){
		return delegate.mapToJpe(api);
	}
	
}
