package com.silverlakesymmetri.cbs.xps.svc.mapper.decorator;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.inject.Inject;

import org.mapstruct.Context;
import org.mapstruct.MappingTarget;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

import com.silverlakesymmetri.cbs.commons.jpa.extension.JaxbSdoHelper;
import com.silverlakesymmetri.cbs.commons.jpa.service.CbsGenericDataService;
import com.silverlakesymmetri.cbs.commons.jpa.util.BdoHelper;
import com.silverlakesymmetri.cbs.commons.xmlapi.enums.CbsXmlApiOperation;
import com.silverlakesymmetri.cbs.mcl.jpa.mapping.sdo.ClientJpe;
import com.silverlakesymmetri.cbs.mcl.jpa.mapping.sdo.util.MclJpeConstants;
import com.silverlakesymmetri.cbs.mcl.svc.ClientService;
import com.silverlakesymmetri.cbs.xps.bdo.sdo.ChargeDetails;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.ChargeDetailsJpe;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.ChargeMasterJpe;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.RecurringChargeMasterJpe;
import com.silverlakesymmetri.cbs.xps.listener.ChargeNoResolver;
import com.silverlakesymmetri.cbs.xps.svc.mapper.ChargeDetailServiceMapper;
import com.silverlakesymmetri.cbs.xps.svc.mapper.ChargeFixedServiceMapper;
import com.silverlakesymmetri.cbs.xps.svc.mapper.ChargeInterestServiceMapper;
import com.silverlakesymmetri.cbs.xps.svc.mapper.ChargeRatedServiceMapper;
import com.silverlakesymmetri.cbs.xps.svc.mapper.RecurringChargeMasterServiceMapper;
import com.silverlakesymmetri.cbs.xps.xmlapi.XPSTRANCHARGEDETAILAPIType;
import com.silverlakesymmetri.cbs.xps.xmlapi.XPSTRANCHARGEDETAILLISTTYPEType;
import com.silverlakesymmetri.cbs.xps.xmlapi.XPSTRANCHARGESCHEDAPIType;

public abstract class RecurringChargeMasterServiceDecorator implements RecurringChargeMasterServiceMapper {
	private static final String CHARGE_TYPE_FIXED = "F";
	private static final String CHARGE_TYPE_INTEREST = "I";
	private static final String CHARGE_TYPE_PERIODIC = "P";
	private static final String CHARGE_TYPE_RATED = "R";
	private static final String CHARGE_TYPE_TWOTIER = "T";
	
	@Autowired
	@Qualifier("delegate")
	protected RecurringChargeMasterServiceMapper delegate;
	
	@Autowired
	protected ChargeDetailServiceMapper detailMapper;

	@Autowired
	protected ChargeFixedServiceMapper fixedMapper;
	
	@Autowired
	protected ChargeRatedServiceMapper ratedMapper;
	
	@Autowired
	protected ChargeInterestServiceMapper interestMapper;
	
	@Autowired
	protected ClientService clientService;

    @Autowired(required = true)
    @Qualifier("cbsGenericDataService")
    protected CbsGenericDataService dataService;

    @Inject
    private BdoHelper bdoHelper;

	@Inject
	private JaxbSdoHelper jaxbSdoHelper;
	
	@Override
	public XPSTRANCHARGESCHEDAPIType mapToApi(RecurringChargeMasterJpe jpe, @Context CbsXmlApiOperation oper) {
		XPSTRANCHARGESCHEDAPIType req = (XPSTRANCHARGESCHEDAPIType) delegate.mapToApi(jpe, oper);
		
		ClientJpe client = clientService.getClientDetails(jpe.getPartyClientNo());
    	if(client != null){
    		req.setPARTYCLIENTID(client.getClientId());
    	}
    	if(jpe.getChargeDetailsList() != null && jpe.getChargeDetailsList().size() > 0){
			for(ChargeDetailsJpe detailsJpe : jpe.getChargeDetailsList()){
				XPSTRANCHARGEDETAILAPIType detailApi = detailMapper.mapToApi(detailsJpe, oper);
				if(req.getDETAILS() == null){
					req.setDETAILS(new XPSTRANCHARGEDETAILLISTTYPEType());
				}
				if(CHARGE_TYPE_FIXED.equals(detailsJpe.getChargeType())){
					detailApi = fixedMapper.mapToApi(detailsJpe.getChargeFixedStructRec(), detailApi);
				} else if(CHARGE_TYPE_RATED.equals(detailsJpe.getChargeType())){
					detailApi = ratedMapper.mapToApi(detailsJpe.getChargeRatedStructRec(), detailApi);
				} else if(CHARGE_TYPE_INTEREST.equals(detailsJpe.getChargeType())){
					detailApi = interestMapper.mapToApi(detailsJpe.getChargeInterestStructRec(), detailApi);
				}
				//TODO: this is not for Fixed Charges but is not nullable, set to N by default
				detailApi.setWAIVED("N");
				req.getDETAILS().getXPSTRANCHARGEDETAILAPI().add(detailApi);
			}
		}
		return  req;
	}

	@Override
	public RecurringChargeMasterJpe mapToJpe(XPSTRANCHARGESCHEDAPIType api, @MappingTarget RecurringChargeMasterJpe jpe) {
		delegate.mapToJpe(api, jpe);
		
		if(api.getDETAILS() != null && api.getDETAILS().getXPSTRANCHARGEDETAILAPI().size() > 0){
			for(XPSTRANCHARGEDETAILAPIType detailApi : api.getDETAILS().getXPSTRANCHARGEDETAILAPI()){
				ChargeDetailsJpe detailsJpe = new ChargeDetailsJpe();
				detailMapper.mapToJpe(detailApi, detailsJpe);
				if(CHARGE_TYPE_FIXED.equals(detailsJpe.getChargeType())){
					detailsJpe.setChargeFixedStructRec(fixedMapper.mapToJpe(detailApi, detailsJpe.getChargeFixedStructRec()));
				} else if(CHARGE_TYPE_RATED.equals(detailsJpe.getChargeType())){
					detailsJpe.setChargeRatedStructRec(ratedMapper.mapToJpe(detailApi, detailsJpe.getChargeRatedStructRec()));
				} else if(CHARGE_TYPE_INTEREST.equals(detailsJpe.getChargeType())){
					detailsJpe.setChargeInterestStructRec(interestMapper.mapToJpe(detailApi, detailsJpe.getChargeInterestStructRec()));
				}
				if(jpe.getChargeDetailsList() == null){
					jpe.setChargeDetailsList(new ArrayList<ChargeDetailsJpe>());
				}
				ChargeDetails bdo = jaxbSdoHelper.wrap(detailsJpe);
				bdoHelper.callEntityListenerMethod(bdo, new Class<?>[] { ChargeNoResolver.class }, "postBuild");	
				jpe.getChargeDetailsList().add(jaxbSdoHelper.unwrap(bdo));
			}
		}
		
		if(api.getPARTYCLIENTID() != null){
			Map<String, Object> parameters = new HashMap<String, Object>();
			parameters.put("clientId", api.getPARTYCLIENTID());
			List<ClientJpe> clientList = dataService.findWithNamedQuery(MclJpeConstants.CLIENT_JPE_GET_CLIENT_FROM_ID, parameters, ClientJpe.class);
			if(clientList != null && clientList.size() > 0){
				ClientJpe client = clientList.get(0);
				jpe.setPartyClientNo(client.getClientNo());
			}
	    	
		}
		return jpe;
	}
	
	@Override
	public RecurringChargeMasterJpe mapToJpe(XPSTRANCHARGESCHEDAPIType api) {
		RecurringChargeMasterJpe jpe = new RecurringChargeMasterJpe();
		return mapToJpe(api, jpe);
	}
	
}
