package com.silverlakesymmetri.cbs.xps.svc;

import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.svc.BusinessService;
import com.silverlakesymmetri.cbs.xps.bdo.sdo.IncomingMessageSwf;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.IncomingMessageSwfJpe;

import java.util.List;
import java.util.Map;

public interface IncomingMessageSwfService extends BusinessService<IncomingMessageSwf, IncomingMessageSwfJpe> {
    public static final String SVC_OP_NAME_INCOMINGMESSAGESWIFTSERVICE_GET = "IncomingMessageSwfService.get";
    public static final String SVC_OP_NAME_INCOMINGMESSAGESWIFTSERVICE_QUERY = "IncomingMessageSwfService.query";
    public static final String SVC_OP_NAME_INCOMINGMESSAGESWIFTSERVICE_FIND = "IncomingMessageSwfService.find";
    public static final String SVC_OP_NAME_INCOMINGMESSAGESWIFTSERVICE_MSG = "IncomingMessageSwfService.getMessageDetails";

    @ServiceOperation(name = SVC_OP_NAME_INCOMINGMESSAGESWIFTSERVICE_GET, type = ServiceOperation.ServiceOperationType.GET)
    public IncomingMessageSwf getByPk(String publicKey, IncomingMessageSwf reference);

    @ServiceOperation(name = SVC_OP_NAME_INCOMINGMESSAGESWIFTSERVICE_QUERY)
    public List<IncomingMessageSwf> query(int offset, int resultLimit, String groupBy, String order, Map<String, Object> filters);

    @ServiceOperation(name = SVC_OP_NAME_INCOMINGMESSAGESWIFTSERVICE_FIND)
    public List<IncomingMessageSwf> find(FindCriteria findCriteria, CbsHeader cbsHeader);

    @ServiceOperation(name = SVC_OP_NAME_INCOMINGMESSAGESWIFTSERVICE_MSG, type = ServiceOperation.ServiceOperationType.GET)
    public String getMessageDetails(Long internalKey);

}
