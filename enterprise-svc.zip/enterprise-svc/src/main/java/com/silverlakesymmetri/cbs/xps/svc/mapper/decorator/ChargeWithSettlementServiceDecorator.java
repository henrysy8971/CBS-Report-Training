package com.silverlakesymmetri.cbs.xps.svc.mapper.decorator;

import org.mapstruct.Context;
import org.mapstruct.MappingTarget;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

import com.silverlakesymmetri.cbs.commons.exception.base.CbsServiceProcessException;
import com.silverlakesymmetri.cbs.commons.util.MessageUtils;
import com.silverlakesymmetri.cbs.commons.xmlapi.enums.CbsXmlApiOperation;
import com.silverlakesymmetri.cbs.xps.bdo.sdo.ChargeMaster;
import com.silverlakesymmetri.cbs.xps.bdo.sdo.ChargeSettlement;
import com.silverlakesymmetri.cbs.xps.bdo.sdo.ChargeSettlementDetails;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.ChargeMasterJpe;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.ChargeSettlementDetailsJpe;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.ChargeSettlementJpe;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.ChargeWithSettlementJpe;
import com.silverlakesymmetri.cbs.xps.svc.mapper.ChargeMasterServiceMapper;
import com.silverlakesymmetri.cbs.xps.svc.mapper.ChargeSettlementServiceMapper;
import com.silverlakesymmetri.cbs.xps.svc.mapper.ChargeWithSettlementServiceMapper;
import com.silverlakesymmetri.cbs.xps.xmlapi.XPSTRANCHARGEWITHSETTLEAPIType;

public abstract class ChargeWithSettlementServiceDecorator implements ChargeWithSettlementServiceMapper {
	
	@Autowired
	@Qualifier("delegate")
	protected ChargeWithSettlementServiceMapper delegate;

	@Autowired
	protected ChargeSettlementServiceMapper settlementMapper;
	
	@Autowired
	protected ChargeMasterServiceMapper chargeMapper;;

    @Autowired
    protected MessageUtils messageUtils;

	@Override
	public XPSTRANCHARGEWITHSETTLEAPIType mapToApi(ChargeWithSettlementJpe jpe, @Context CbsXmlApiOperation oper){
		ChargeMasterJpe master = jpe.getChargeStructRec();
		ChargeSettlementJpe settlement = jpe.getSettlementStructRec();
    	if(settlement != null && settlement.getChargeSettleDetailsList() != null && settlement.getChargeSettleDetailsList().size() > 0 && master != null){
    		Double totalSettlementAmount = new Double(0);
    		for(ChargeSettlementDetailsJpe detail : settlement.getChargeSettleDetailsList()){
				if(detail.getAmount() != null){
					totalSettlementAmount = totalSettlementAmount.doubleValue() + detail.getAmount().doubleValue();
				}
    		}
    		if(totalSettlementAmount.compareTo(master.getAmount()) != 0){
	            String msg = messageUtils.getMessage("CBS.B.XPS.CHARGEWITHSETTLEMENT.0001", new String[] {});
	            CbsServiceProcessException exec = new CbsServiceProcessException("CBS.B.XPS.CHARGEWITHSETTLEMENT.0001", msg);
	            throw exec;
			}
    	}
		
		XPSTRANCHARGEWITHSETTLEAPIType req = (XPSTRANCHARGEWITHSETTLEAPIType) delegate.mapToApi(jpe, oper);
		req = chargeMapper.mapToApi(jpe.getChargeStructRec(), oper);
		if(!jpe.getSettlementStructRec().getChargeSettleDetailsList().isEmpty()) {
			req.setSETTLEMENT(settlementMapper.mapToApi(jpe.getSettlementStructRec(), oper));
		}
		return  req;
	}
	
	@Override
	public ChargeWithSettlementJpe mapToJpe(XPSTRANCHARGEWITHSETTLEAPIType api, @MappingTarget ChargeWithSettlementJpe jpe){
		chargeMapper.mapToJpe(api, jpe.getChargeStructRec());
		settlementMapper.mapToJpe(api.getSETTLEMENT(), jpe.getSettlementStructRec());
		return jpe;
	}
	
	@Override
	public ChargeWithSettlementJpe mapToJpe(XPSTRANCHARGEWITHSETTLEAPIType api){
		ChargeWithSettlementJpe jpe = new ChargeWithSettlementJpe();
		ChargeMasterJpe chargeJpe = new ChargeMasterJpe();
		ChargeSettlementJpe settlementJpe = new ChargeSettlementJpe();
		jpe.setChargeStructRec(chargeJpe);
		jpe.setSettlementStructRec(settlementJpe);
		return mapToJpe(api, jpe);
	}

}


