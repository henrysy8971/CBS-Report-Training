package com.silverlakesymmetri.cbs.xps.svc.batch.listener;

import org.apache.commons.lang3.tuple.Pair;
import org.springframework.batch.core.ItemProcessListener;

import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.MessageQJpe;

public class MessageQueueSendProcessorListener extends AbstractMessageQueueProcessorListener<MessageQJpe, MessageQJpe>
		implements ItemProcessListener<MessageQJpe, MessageQJpe> {

	@Override
	public void onProcessError(MessageQJpe item, Exception e) {
		super.onProcessError(item, e);
		this.stepExecution.getExecutionContext().put(LAST_FAILED_KEY,
				Pair.of(((MessageQJpe) item).getInternalKey(), e));
	}

}
