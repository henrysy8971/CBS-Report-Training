package com.silverlakesymmetri.cbs.swf.svc.mapper.mapping;

import org.apache.commons.lang3.StringUtils;
import org.mapstruct.DecoratedWith;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Mappings;

import com.silverlakesymmetri.cbs.swf.jpa.mapping.sdo.SwfF70Jpe;
import com.silverlakesymmetri.cbs.swf.svc.mapper.decorator.SwfF70MapperDecorator;
import com.silverlakesymmetri.cbs.swf.xmlapi.SWFF70TYPEType;

@Mapper(imports=StringUtils.class, uses = SwfSndrRcvrNarrativeMapper.class)
@DecoratedWith(SwfF70MapperDecorator.class)
public interface SwfF70Mapper {
	@Mappings({
		@Mapping(source="opt", target="OPT"),
		@Mapping(source="swfSndrRcvrNarrativeList", target="DETAILS.SWFSNDRRCVRNARRATIVETYPE")
	})
	SWFF70TYPEType mapToApi(SwfF70Jpe jpe);
	
	@Mappings({
		@Mapping(target="opt", expression="java(StringUtils.isNotBlank(api.getOPT())?api.getOPT():null)"),
		@Mapping(target="swfSndrRcvrNarrativeList", source="DETAILS.SWFSNDRRCVRNARRATIVETYPE")
	})
	SwfF70Jpe mapToJpe(SWFF70TYPEType api);

}