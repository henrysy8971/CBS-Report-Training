package com.silverlakesymmetri.cbs.swf.svc.mapper.mapping;

import java.util.Date;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.lang3.StringUtils;
import org.mapstruct.DecoratedWith;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Mappings;
import org.mapstruct.Named;
import org.springframework.beans.factory.annotation.Autowired;

import com.silverlakesymmetri.cbs.commons.jpa.util.DateTimeHelper;
import com.silverlakesymmetri.cbs.swf.jpa.mapping.sdo.SwfF13Jpe;
import com.silverlakesymmetri.cbs.swf.svc.mapper.decorator.SwfF13MapperDecorator;
import com.silverlakesymmetri.cbs.swf.xmlapi.SWFF13TYPEType;

@Mapper(imports = StringUtils.class)
@DecoratedWith(SwfF13MapperDecorator.class)
public abstract class SwfF13Mapper {
	private static final String WHITESPACE = " ";
	private static final Pattern TIMEZONE_PATTERN = Pattern.compile("\\s[\\+-]\\d\\d:\\d\\d$");
	private static final Pattern LEADING_ZERO_PATTERN = Pattern.compile("(?<=[+-])0");
	
	@Autowired
	DateTimeHelper dateTimeHelper;
	
	@Mappings({
		@Mapping(source="opt", target="OPT"),
		@Mapping(source="code", target="CODE"),
		//@Mapping(source="timeInd", target="TIMEIND", qualifiedByName = {"DateTimeHelper","convertDateToCbsXmlApiDate"})
		@Mapping(source="jpe", target="TIMEIND", qualifiedByName = {"convertStringToCbsXmlApiDateTimezone"})
	})
	public abstract SWFF13TYPEType mapToApi(SwfF13Jpe jpe);
	
	@Mappings({
		@Mapping(target="opt", expression="java(StringUtils.isNotBlank(api.getOPT())?api.getOPT():null)"),
		@Mapping(target="code", expression="java(StringUtils.isNotBlank(api.getCODE())?api.getCODE():null)"),
		//@Mapping(target="timeInd", source="TIMEIND", qualifiedByName = { "DateTimeHelper", "convertCbsApiDateToString" })
		@Mapping(target="timeInd", source="api", qualifiedByName = { "getDateFromXmlApiString" }),
		@Mapping(target="timezone", source="api", qualifiedByName = { "getTimezoneFromXmlApiString" })
	})
	public abstract SwfF13Jpe mapToJpe(SWFF13TYPEType api);
	
	@Named("convertStringToCbsXmlApiDateTimezone")
	protected String convertStringToCbsXmlApiDateTimezone(SwfF13Jpe jpe){
		//*********************************************************************************//
		// required format to pass to API: MM.DD.YYYY HH24:MI:SS TZR
		// example data to pass is 06.22.2020 15:46:36 +03:30
		//
		// convertToCbsXmlApiDate would yield this format: 06.19.2020 10:04:00
		// therefore just append the time zone at the end
		//*********************************************************************************//
		
		if(jpe.getTimeInd() == null) { return null; }
		
		String apiDate = dateTimeHelper.convertToCbsXmlApiDate(jpe.getTimeInd());
		
		if(StringUtils.isNotBlank(jpe.getTimezone())){
			apiDate = apiDate.concat(WHITESPACE).concat(jpe.getTimezone());
		}
		
		return apiDate;
	}

	@Named("getDateFromXmlApiString")
	protected Date getDateFromXmlApiString(SWFF13TYPEType api){
		if(StringUtils.isBlank(api.getTIMEIND())) { return null; }
		String apiDate = TIMEZONE_PATTERN.matcher(api.getTIMEIND()).replaceAll(StringUtils.EMPTY);
		return dateTimeHelper.convertFromCbsXmlApiDate(apiDate);
	}
	
	@Named("getTimezoneFromXmlApiString")
	protected String getTimezoneFromXmlApiString(SWFF13TYPEType api){
		if(StringUtils.isBlank(api.getTIMEIND())) { return null; }
		
		Matcher m = TIMEZONE_PATTERN.matcher(api.getTIMEIND());
		if (m.find()){
			String matchFound = m.group(); 
			matchFound = matchFound.trim();
			matchFound = LEADING_ZERO_PATTERN.matcher(matchFound).replaceFirst(StringUtils.EMPTY);
		    return matchFound;
		}
		
		return null;
	}

}