package com.silverlakesymmetri.cbs.gla.svc;

import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation;
import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation.ServiceOperationType;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.svc.BusinessService;
import com.silverlakesymmetri.cbs.gla.bdo.sdo.GlPostingFieldsByGLKeysQry;
import com.silverlakesymmetri.cbs.gla.jpa.mapping.sdo.GlPostingFieldsByGLKeysQryJpe;

import java.util.List;
import java.util.Map;

public interface GlPostingFieldsByGlKeysQryService extends BusinessService<GlPostingFieldsByGLKeysQry, GlPostingFieldsByGLKeysQryJpe> {

	public static final String SVC_OP_NAME_GLPOSTINGFIELDSBYGLKEYSSERVICE_GET = "GlPostingFieldsByGLKeysQryService.get";
	public static final String SVC_OP_NAME_GLPOSTINGFIELDSBYGLKEYSSERVICE_FIND = "GlPostingFieldsByGLKeysQryService.find";
	public static final String SVC_OP_NAME_GLPOSTINGFIELDSBYGLKEYSSERVICE_QUERY = "GlPostingFieldsByGLKeysQryService.query";
	
	@ServiceOperation(name = SVC_OP_NAME_GLPOSTINGFIELDSBYGLKEYSSERVICE_GET, type = ServiceOperationType.GET)
    public GlPostingFieldsByGLKeysQry getByPk(String publicKey, GlPostingFieldsByGLKeysQry reference);

    @ServiceOperation(name = SVC_OP_NAME_GLPOSTINGFIELDSBYGLKEYSSERVICE_FIND)
    public List<GlPostingFieldsByGLKeysQry> find(FindCriteria findCriteria, CbsHeader cbsHeader);
    
    @ServiceOperation(name = SVC_OP_NAME_GLPOSTINGFIELDSBYGLKEYSSERVICE_QUERY)
    public List<GlPostingFieldsByGLKeysQry> query(int offset, int resultLimit, String groupBy, String order, Map<String, Object> filters);
}
