package com.silverlakesymmetri.cbs.xps.svc.batch.incrementer;

import org.springframework.batch.core.JobParameters;

public class MessageQueueJobIncrementer extends JobIncrementerBase {

	@Override
	public JobParameters getNext(JobParameters parameters) {
		return super.getNext(parameters);
	}

	/*
	private JobParameters addDiscriminator(JobParameters parameters) {
		Map<String, JobParameter> newParams = new HashMap<>(parameters.getParameters());

		Long runId = 1L;
		JobParameter discriminatorParam = newParams.get(DISCRIMINATOR_KEY);
		if(discriminatorParam != null){
			runId = (Long) discriminatorParam.getValue();
		}
		runId = runId + 1;
		
		newParams.put(DISCRIMINATOR_KEY, new JobParameter(runId, true));
		return new JobParameters(newParams);
	}

    private JobParameters replaceSessionAndTransactionId(JobParameters parameters) {
        Map<String, JobParameter> newParams = new HashMap<>(parameters.getParameters());
        //
        String sessionId = null;
        String transactionId = null;
        String svcOpName = null;
        //
        newParams.remove(CBS_TRANSACTION_ID_KEY);
        newParams.remove(CBS_SESSION_ID_KEY);
        newParams.remove(SERVICE_OPERATION_NAME);
        //
        CbsTransactionContext txnContext = _ctxMngr.getContext(CbsTransactionContext.class);
        CbsSessionContext sessionContext = null;
        if (txnContext != null) {
            transactionId = Long.toString(txnContext.getTransactionId());
            sessionContext = (CbsSessionContext) txnContext;
            svcOpName = txnContext.getCurrentServiceOperation();
        } else {
            // Should not happen but never say never!
            sessionContext = _ctxMngr.getContext(CbsSessionContext.class);
        }
        if (sessionContext != null) {
            sessionId = sessionContext.getSessionId();
        }
        if(StringUtils.isNotBlank(sessionId)) {
            newParams.put(CBS_SESSION_ID_KEY, new JobParameter(sessionId, false));
        }
        if(StringUtils.isNotBlank(transactionId)) {
            newParams.put(CBS_TRANSACTION_ID_KEY, new JobParameter(transactionId, false));
        }
        if(StringUtils.isNotBlank(svcOpName)) {
            newParams.put(SERVICE_OPERATION_NAME, new JobParameter(svcOpName, false));
        }

        return new JobParameters(newParams);
    }

    */
}
