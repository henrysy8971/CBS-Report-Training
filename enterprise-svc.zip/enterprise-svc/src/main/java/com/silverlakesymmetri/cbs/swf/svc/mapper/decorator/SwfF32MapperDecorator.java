package com.silverlakesymmetri.cbs.swf.svc.mapper.decorator;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

import com.silverlakesymmetri.cbs.swf.jpa.mapping.sdo.SwfF32Jpe;
import com.silverlakesymmetri.cbs.swf.svc.mapper.mapping.SwfF32Mapper;
import com.silverlakesymmetri.cbs.swf.xmlapi.SWFF32TYPEType;

public abstract class SwfF32MapperDecorator implements SwfF32Mapper {
	
	@Autowired
	@Qualifier("delegate")
	protected SwfF32Mapper delegate;

	@Override
	public SWFF32TYPEType mapToApi(SwfF32Jpe jpe){
		SWFF32TYPEType swfF32 = delegate.mapToApi(jpe);
		if(swfF32 != null && swfF32.getAMOUNT() == null && swfF32.getCODE() == null && swfF32.getCURRENCY() == null && 
				swfF32.getPERIODNO() == null && swfF32.getPERIODTYPE() == null && swfF32.getVALUEDATE() == null){
			return null;
		}
		return swfF32;
	}
	
	@Override
	public SwfF32Jpe mapToJpe(SWFF32TYPEType api){
		return delegate.mapToJpe(api);
	}
	
}
