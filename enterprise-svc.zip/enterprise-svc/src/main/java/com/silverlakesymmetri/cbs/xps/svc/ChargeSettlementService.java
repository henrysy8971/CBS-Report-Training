package com.silverlakesymmetri.cbs.xps.svc;

import java.util.List;
import java.util.Map;

import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation;
import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation.ServiceOperationType;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.bdo.sdo.DmsFile;
import com.silverlakesymmetri.cbs.commons.svc.BusinessService;
import com.silverlakesymmetri.cbs.xps.bdo.sdo.AdvicePreview;
import com.silverlakesymmetri.cbs.xps.bdo.sdo.ChargeSettlement;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.ChargeSettlementJpe;

public interface ChargeSettlementService extends BusinessService<ChargeSettlement, ChargeSettlementJpe> {
	public static final String XPS_CHARGESETTLEMENTSERVICE_GET = "ChargeSettlementService.get";
    public static final String XPS_CHARGESETTLEMENTSERVICE_QUERY = "ChargeSettlementService.query";
    public static final String XPS_CHARGESETTLEMENTSERVICE_FIND = "ChargeSettlementService.find";
    public static final String XPS_CHARGESETTLEMENTSERVICE_CREATE = "ChargeSettlementService.create";
    public static final String XPS_CHARGESETTLEMENTSERVICE_UPDATE = "ChargeSettlementService.update";
    public static final String XPS_CHARGESETTLEMENTSERVICE_COUNT = "ChargeSettlementService.count";
	public static final String XPS_CHARGESETTLEMENTSERVICE_SWFMSG = "ChargeSettlementService.generateSwfMessage";
    public static final String XPS_CHARGESETTLEMENTSERVICE_EMAILPREVIEW = "ChargeSettlementService.generateEmailPreview";
    public static final String XPS_CHARGESETTLEMENTSERVICE_GENADVICE = "ChargeSettlementService.generateAdvice";

    @ServiceOperation(name = XPS_CHARGESETTLEMENTSERVICE_GET, type = ServiceOperationType.GET)
    public ChargeSettlement getByPk(String publicKey, ChargeSettlement reference);

    @ServiceOperation(name = XPS_CHARGESETTLEMENTSERVICE_QUERY)
    public List<ChargeSettlement> query(int offset, int resultLimit, String groupBy, String order, Map<String, Object> filters);
    
    @ServiceOperation(name = XPS_CHARGESETTLEMENTSERVICE_FIND)
    public List<ChargeSettlement> find(FindCriteria findCriteria, CbsHeader cbsHeader);
    
    @ServiceOperation(name = XPS_CHARGESETTLEMENTSERVICE_COUNT, type = ServiceOperationType.GET)
    public Long count(FindCriteria findCriteria, CbsHeader cbsHeader);

    @ServiceOperation(name = XPS_CHARGESETTLEMENTSERVICE_CREATE)
    public ChargeSettlement create(ChargeSettlement dataObject);

    @ServiceOperation(name = XPS_CHARGESETTLEMENTSERVICE_UPDATE)
    public ChargeSettlement update(ChargeSettlement dataObject);

    @ServiceOperation(name = XPS_CHARGESETTLEMENTSERVICE_SWFMSG, passParamAsMap = true)
    public String generateSwfMessage(Map<String, Object> params);
    
    @ServiceOperation(name = XPS_CHARGESETTLEMENTSERVICE_EMAILPREVIEW, passParamAsMap = true)
    public AdvicePreview generateEmailPreview(Map<String, Object> params);
    
    @ServiceOperation(name = XPS_CHARGESETTLEMENTSERVICE_GENADVICE, passParamAsMap = true)
    public DmsFile generateAdvice(Map<String, Object> params);
}