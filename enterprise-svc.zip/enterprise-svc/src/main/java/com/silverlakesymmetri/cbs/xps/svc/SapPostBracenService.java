package com.silverlakesymmetri.cbs.xps.svc;

import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.svc.BusinessService;
import com.silverlakesymmetri.cbs.xps.bdo.sdo.SapPostBracen;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.SapPostBracenJpe;

import java.util.List;
import java.util.Map;

/**
 *  Copyright Silverlake 2019
 *
 *  Service is used to Read, Create, Update, Delete Sap Post Bracen data.
 *
 * @author      Sean Mendoza
 * @since       2019-08-28
 */
public interface SapPostBracenService extends BusinessService<SapPostBracen, SapPostBracenJpe> {

    public static final String SVC_OP_SAPPOSTBRACENSERVICE_GET = "SapPostBracenService.get";
    public static final String SVC_OP_SAPPOSTBRACENSERVICE_QUERY = "SapPostBracenService.query";
    public static final String SVC_OP_SAPPOSTBRACENSERVICE_CREATE = "SapPostBracenService.create";
    public static final String SVC_OP_SAPPOSTBRACENSERVICE_UPDATE = "SapPostBracenService.update";
    public static final String SVC_OP_SAPPOSTBRACENSERVICE_DELETE = "SapPostBracenService.delete";
    public static final String SVC_OP_SAPPOSTBRACENSERVICE_FIND = "SapPostBracenService.find";
    public static final String SVC_OP_SAPPOSTBRACENSERVICE_FIND_WORK_UNIT = "SapPostBracenService.findWorkUnit";

    @ServiceOperation(name = SVC_OP_SAPPOSTBRACENSERVICE_GET, type = ServiceOperation.ServiceOperationType.GET)
    public SapPostBracen getByPk(String publicKey, SapPostBracen reference);

    @ServiceOperation(name = SVC_OP_SAPPOSTBRACENSERVICE_CREATE)
    public SapPostBracen create(SapPostBracen dataObject);

    @ServiceOperation(name = SVC_OP_SAPPOSTBRACENSERVICE_UPDATE)
    public SapPostBracen update(SapPostBracen dataObject);

    @ServiceOperation(name = SVC_OP_SAPPOSTBRACENSERVICE_DELETE)
    public boolean delete(SapPostBracen dataObject);

    @ServiceOperation(name = SVC_OP_SAPPOSTBRACENSERVICE_QUERY)
    public List<SapPostBracen> query(int offset, int resultLimit, String groupBy, String order, Map<String, Object> filters);

    @ServiceOperation(name = SVC_OP_SAPPOSTBRACENSERVICE_FIND)
    public List<SapPostBracen> find(FindCriteria findCriteria, CbsHeader cbsHeader);

    @ServiceOperation(name = SVC_OP_SAPPOSTBRACENSERVICE_FIND_WORK_UNIT ,
            type = ServiceOperation.ServiceOperationType.READ, passParamAsMap = true)
    public List<SapPostBracen> findWorkUnit(Map<String, Object> queryParams);

}
