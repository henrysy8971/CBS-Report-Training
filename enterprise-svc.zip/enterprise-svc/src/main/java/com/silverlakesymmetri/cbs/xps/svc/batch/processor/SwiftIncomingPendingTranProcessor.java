package com.silverlakesymmetri.cbs.xps.svc.batch.processor;

import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.IncomingMessageSwfJpe;

public class SwiftIncomingPendingTranProcessor extends IncomingMessagePendingTranBaseProcessor<IncomingMessageSwfJpe> {

	@Override
	protected Object getUniqueId(IncomingMessageSwfJpe item) {
		return item.getInternalKey();
	}

	@Override
	protected String getXmlTranDetails(IncomingMessageSwfJpe item) {
		return item.getTransactionDetails();
	}

	@Override
	protected String getTranRefNo(IncomingMessageSwfJpe item) {
		return item.getTranRefNo();
	}
}
