package com.silverlakesymmetri.cbs.swf.svc.impl;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.mysema.query.types.EntityPath;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.svc.AbstractXmlApiBusinessService;
import com.silverlakesymmetri.cbs.commons.xmlapi.enums.CbsXmlApiOperation;
import com.silverlakesymmetri.cbs.swf.bdo.sdo.SwfNonFinEntity;
import com.silverlakesymmetri.cbs.swf.jpa.mapping.sdo.SwfNonFinEntityJpe;
import com.silverlakesymmetri.cbs.swf.svc.SwiftNonFinEntityService;
import com.silverlakesymmetri.cbs.swf.svc.mapper.mapping.SwfF50Mapper;
import com.silverlakesymmetri.cbs.swf.xmlapi.SWFF50TYPEType;

@Service
@Transactional
public class SwiftNonFinEntityServiceImpl extends AbstractXmlApiBusinessService<SwfNonFinEntity, SwfNonFinEntityJpe, Long, SWFF50TYPEType, SWFF50TYPEType> implements SwiftNonFinEntityService {

	@Autowired
	private SwfF50Mapper mapper;

	@Override
	public boolean validateSwfNonFinEntity(SwfNonFinEntity dataObject) {
		SWFF50TYPEType swfF50 = mapper.mapToApi(jaxbSdoHelper.unwrap(dataObject));
		swfF50.setOPERATION("VALIDATE");
		queryDataObject(swfF50);
		return true;
	}
	
	@Override
    public SwfNonFinEntity getByPk(String publicKey, SwfNonFinEntity reference) {
    	return null;
    }

    @Override
    public List<SwfNonFinEntity> find(FindCriteria findCriteria, CbsHeader cbsHeader) {
        return null;
    }

    @Override
    public List<SwfNonFinEntity> query(int offset, int resultLimit, String groupBy, String order, Map<String, Object> filters) {
        return null;
    }

    @Override
    public SwfNonFinEntity preCreateValidation(SwfNonFinEntity dataObject) {
    	return null;
    }

    @Override
    public SwfNonFinEntity create(SwfNonFinEntity dataObject) {
        return null;
    }

    @Override
    public SwfNonFinEntity preUpdateValidation(SwfNonFinEntity dataObject) {
    	return null;
    }

    @Override
    public SwfNonFinEntity update(SwfNonFinEntity dataObject) {
        return null;
    }

    @Override
    protected SWFF50TYPEType transformBdoToXmlApiRqCreate(SwfNonFinEntity dataObject) {
        return transformBdoToXmlApiType(dataObject, CbsXmlApiOperation.INSERT);
    }

    @Override
    protected SWFF50TYPEType transformBdoToXmlApiRqUpdate(SwfNonFinEntity dataObject) {
        return transformBdoToXmlApiType(dataObject, CbsXmlApiOperation.INSERT);
    }

    @Override
    protected SWFF50TYPEType transformBdoToXmlApiRqDelete(SwfNonFinEntity dataObject) {
        return null;
    }

    private SWFF50TYPEType transformBdoToXmlApiType(SwfNonFinEntity dataObject, CbsXmlApiOperation oper) {
        return null;
    }

    @Override
    protected Map<String, String> executeStoredProcedure(String xmlApiReq, String xmlHeaderIn) {
        String xmlApiReqProcess = xmlApiReq.replaceAll("SWF_F50_TYPE OPERATION=\"INSERT\"", "SWF_F50_TYPE OPERATION=\"VALIDATE\"");
        return super.executeStoredProcedure(xmlApiReqProcess, xmlHeaderIn);
    }

    @Override
    protected SwfNonFinEntity processXmlApiRs(SwfNonFinEntity dataObject, SWFF50TYPEType xmlApiRs) {
        return null;
    }

    @Override
    protected List<SwfNonFinEntity> processXmlApiListRs(SwfNonFinEntity dataObject, SWFF50TYPEType xmlApiRs) {
        return null;
    }

    @Override
    protected Class<SWFF50TYPEType> getXmlApiResponseClass() {
        return SWFF50TYPEType.class;
    }

    @Override
    protected Long getIdFromDataObjectInstance(SwfNonFinEntity dataObject) {
        return null;
    }

    @Override
    protected EntityPath<SwfNonFinEntityJpe> getEntityPath() {
        return null;
    }


}
