package com.silverlakesymmetri.cbs.xps.svc.mapper.mapping;

import org.mapstruct.Context;
import org.mapstruct.InheritInverseConfiguration;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingTarget;
import org.mapstruct.Mappings;

import com.silverlakesymmetri.cbs.commons.xmlapi.enums.CbsXmlApiOperation;
import com.silverlakesymmetri.cbs.swf.jpa.mapping.sdo.SwfMt103Jpe;
import com.silverlakesymmetri.cbs.swf.svc.mapper.mapping.SwfF13Mapper;
import com.silverlakesymmetri.cbs.swf.svc.mapper.mapping.SwfF23Mapper;
import com.silverlakesymmetri.cbs.swf.svc.mapper.mapping.SwfF26Mapper;
import com.silverlakesymmetri.cbs.swf.svc.mapper.mapping.SwfF50Mapper;
import com.silverlakesymmetri.cbs.swf.svc.mapper.mapping.SwfF51Mapper;
import com.silverlakesymmetri.cbs.swf.svc.mapper.mapping.SwfF52Mapper;
import com.silverlakesymmetri.cbs.swf.svc.mapper.mapping.SwfF53Mapper;
import com.silverlakesymmetri.cbs.swf.svc.mapper.mapping.SwfF54Mapper;
import com.silverlakesymmetri.cbs.swf.svc.mapper.mapping.SwfF55Mapper;
import com.silverlakesymmetri.cbs.swf.svc.mapper.mapping.SwfF56Mapper;
import com.silverlakesymmetri.cbs.swf.svc.mapper.mapping.SwfF57Mapper;
import com.silverlakesymmetri.cbs.swf.svc.mapper.mapping.SwfF58Mapper;
import com.silverlakesymmetri.cbs.swf.svc.mapper.mapping.SwfF59Mapper;
import com.silverlakesymmetri.cbs.swf.svc.mapper.mapping.SwfF70Mapper;
import com.silverlakesymmetri.cbs.swf.svc.mapper.mapping.SwfF71Mapper;
import com.silverlakesymmetri.cbs.swf.svc.mapper.mapping.SwfF72Mapper;
import com.silverlakesymmetri.cbs.swf.svc.mapper.mapping.SwfF77Mapper;
import com.silverlakesymmetri.cbs.xps.xmlapi.XPSSWFSETTLEAPIType;

@Mapper(uses = {
		SwfF13Mapper.class,
		SwfF23Mapper.class,
		SwfF26Mapper.class,
		SwfF50Mapper.class,
		SwfF51Mapper.class,
		SwfF52Mapper.class,
		SwfF53Mapper.class,
		SwfF54Mapper.class,
		SwfF55Mapper.class,
		SwfF56Mapper.class,
		SwfF57Mapper.class,
		SwfF58Mapper.class,
		SwfF59Mapper.class,
		SwfF70Mapper.class,
		SwfF71Mapper.class,
		SwfF72Mapper.class,
		SwfF77Mapper.class,
		//SWFCOVERMESSAGETYPE
})
//@DecoratedWith(SettlePayToLNDDDSETTLEPAYAPITypeDecorator.class)
public interface SwfMt103ToXPSSWFSETTLEAPITypeMapper {
	@Mappings({
		//@Mapping(target ="TECHNICALINFO", ignore = true),
		@Mapping(target ="INTERNALKEY", ignore = true),
	    @Mapping(source="timeIndicationStructList", target ="TIMEINDICATION.SWFF13TYPE"),
	    @Mapping(source="bankOperationCodeStrucRec", target ="BANKOPERATIONCODE"),
	    @Mapping(source="instructionCodeStructList", target ="INSTRUCTIONCODE.SWFF23TYPE"),
	    @Mapping(source="tranTypeCodeStructRec", target ="TRANTYPECODE"),
	    //@Mapping(source="settledAmountStructRec", target =""),
	    //@Mapping(source="instructedAmountStructRec", target =""),
	    //@Mapping(source="instructedExchRateStructRec", target =""),
	    @Mapping(source="orderingCustomerStructRec", target ="ORDERINGCUSTOMER"),
	    @Mapping(source="sendingInstitutionStructRec", target ="SENDINGINSTITUTION"),
	    @Mapping(source="orderingInstitutionStructRec", target ="ORDERINGINSTITUTION"),
	    @Mapping(source="sendersCorrespondentStructRec", target ="SENDERSCORRESPONDENT"),
	    @Mapping(source="receiversCorrespondentStructRec", target ="RECEIVERSCORRESPONDENT"),
	    @Mapping(source="thirdReimbInstitutionStructRec", target ="THIRDREIMBINSTITUTION"),
	    @Mapping(source="intermediaryInstitutionStructRec", target ="INTERMEDIARYINSTITUTION"),
	    @Mapping(source="acctWithInstitutionStructRec", target ="ACCTWITHINSTITUTION"),
	    @Mapping(target ="BENEFICIARYINSTITUTION", ignore = true),
	    @Mapping(source="beneficicaryCustomerStructRec", target ="BENEFICIARYCUSTOMER"),
	    @Mapping(source="remittanceInfoStructRec", target ="REMITTANCEINFO"),
	    @Mapping(source="detailsOfChargesStructRec", target ="DETAILSOFCHARGES"),
	    @Mapping(source="receiversChargesStructRec", target ="RECEIVERCHARGES"),
	    @Mapping(source="sendersChargesStructList", target ="SENDERCHARGES.SWFF71TYPE"),
	    @Mapping(source="senderToReceiverInfoStructRec", target ="SENDERTORECEIVERINFO"),
	    @Mapping(source="regulatoryReportingStructRec", target ="REGULATORYREPORTING"),
		@Mapping(target ="COVERMESSAGEDETAILS", ignore = true),
	})
	XPSSWFSETTLEAPIType mapToApi(SwfMt103Jpe jpe, @Context CbsXmlApiOperation oper);
	
	@InheritInverseConfiguration(name="mapToApi")
	@Mappings({
	    @Mapping(target="settledAmountStructRec", ignore =true),
	    @Mapping(target="instructedAmountStructRec", ignore =true),
	    @Mapping(target="instructedExchRateStructRec", ignore =true),
	    @Mapping(target="timeIndicationStructList", source="TIMEINDICATION.SWFF13TYPE"),
	    @Mapping(target="instructionCodeStructList", source="INSTRUCTIONCODE.SWFF23TYPE"),
	    @Mapping(target="sendersChargesStructList", source="SENDERCHARGES.SWFF71TYPE")
	})
	SwfMt103Jpe mapToJpe(XPSSWFSETTLEAPIType api, @MappingTarget SwfMt103Jpe jpe);
}
