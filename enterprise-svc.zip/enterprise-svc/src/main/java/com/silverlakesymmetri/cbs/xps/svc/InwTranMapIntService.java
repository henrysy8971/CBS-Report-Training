package com.silverlakesymmetri.cbs.xps.svc;

import java.util.List;
import java.util.Map;

import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation;
import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation.ServiceOperationType;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.svc.BusinessService;
import com.silverlakesymmetri.cbs.xps.bdo.sdo.InwTranMapInt;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.InwTranMapIntJpe;

public interface InwTranMapIntService extends BusinessService<InwTranMapInt, InwTranMapIntJpe> {

	public static final String XPS_OP_NAME_INWTRANMAPINTSERVICE_GET = "inwTranMapIntService.get";
    public static final String XPS_OP_NAME_INWTRANMAPINTSERVICE_QUERY = "inwTranMapIntService.query";
    public static final String XPS_OP_NAME_INWTRANMAPINTSERVICE_FIND = "inwTranMapIntService.find";
    public static final String XPS_OP_NAME_INWTRANMAPINTSERVICE_CREATE = "inwTranMapIntService.create";
    public static final String XPS_OP_NAME_INWTRANMAPINTSERVICE_UPDATE = "inwTranMapIntService.update";
    public static final String XPS_OP_NAME_INWTRANMAPINTSERVICE_DELETE = "inwTranMapIntService.delete";
    
    @ServiceOperation(name = XPS_OP_NAME_INWTRANMAPINTSERVICE_GET, type = ServiceOperationType.GET)
    public InwTranMapInt getByPk(String publicKey, InwTranMapInt reference);

    @ServiceOperation(name = XPS_OP_NAME_INWTRANMAPINTSERVICE_QUERY)
    public List<InwTranMapInt> query(int offset, int resultLimit, String groupBy, String order, Map<String, Object> filters);
    
    @ServiceOperation(name = XPS_OP_NAME_INWTRANMAPINTSERVICE_FIND)
    public List<InwTranMapInt> find(FindCriteria findCriteria, CbsHeader cbsHeader);
    
    @ServiceOperation(name = XPS_OP_NAME_INWTRANMAPINTSERVICE_CREATE)
    public InwTranMapInt create(InwTranMapInt dataObject);

     @ServiceOperation(name = XPS_OP_NAME_INWTRANMAPINTSERVICE_UPDATE)
    public InwTranMapInt update(InwTranMapInt dataObject);

    @ServiceOperation(name = XPS_OP_NAME_INWTRANMAPINTSERVICE_DELETE)
    public boolean delete(InwTranMapInt dataObject);
}