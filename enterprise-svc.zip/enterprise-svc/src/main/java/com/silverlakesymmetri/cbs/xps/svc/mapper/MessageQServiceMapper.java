package com.silverlakesymmetri.cbs.xps.svc.mapper;

import org.mapstruct.Context;
import org.mapstruct.DecoratedWith;
import org.mapstruct.InheritInverseConfiguration;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingTarget;
import org.mapstruct.Mappings;

import com.silverlakesymmetri.cbs.commons.jpa.util.DateTimeHelper;
import com.silverlakesymmetri.cbs.commons.xmlapi.enums.CbsXmlApiOperation;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.MessageQJpe;
import com.silverlakesymmetri.cbs.xps.svc.mapper.decorator.MessageQServiceDecorator;
import com.silverlakesymmetri.cbs.xps.xmlapi.XPSMESSAGEQCUSTOMADVICEAPIType;

@Mapper(uses = { DateTimeHelper.class })
@DecoratedWith(MessageQServiceDecorator.class)
public interface MessageQServiceMapper {
   
	@Mappings({
		@Mapping(source="internalKey", target = "INTERNALKEY"),
		@Mapping(source="seqNo", target = "SEQNO"),
		@Mapping(source="domain", target = "DOMAIN"),
		@Mapping(source="branch", target = "BRANCH"),
		@Mapping(source="tranRefNo", target = "TRANREFNO"),
		@Mapping(source="tranInternalKey", target = "TRANINTERNALKEY"),
		@Mapping(source="tranEventType", target = "TRANEVENTTYPE"),
		@Mapping(source="tranDate", target = "TRANDATE", qualifiedByName = {"DateTimeHelper", "convertDateToCbsXmlApiDate"}),
		@Mapping(source="sourceType", target = "SOURCETYPE"),
		@Mapping(source="route", target = "ROUTE"),
		@Mapping(source="senderAddress", target = "SENDERADDRESS"),
		@Mapping(source="destAddress", target = "DESTADDRESS"),
		@Mapping(source="format", target = "FORMAT"),
		@Mapping(source="status", target = "STATUS"),
		@Mapping(source="dateGenerated", target = "DATEGENERATED", qualifiedByName = {"DateTimeHelper", "convertDateToCbsXmlApiDate"}),
		@Mapping(source="dateSent", target = "DATESENT", qualifiedByName = {"DateTimeHelper", "convertDateToCbsXmlApiDate"}),
		@Mapping(source="mainInternalKey", target = "MAININTERNALKEY"),
		@Mapping(source="details", target = "DETAILS"),
		@Mapping(source="jcrId", target = "JCRID")
	})
	public XPSMESSAGEQCUSTOMADVICEAPIType mapToApi(MessageQJpe jpe, @Context CbsXmlApiOperation oper);

	@InheritInverseConfiguration(name = "mapToApi")
	@Mappings({
		@Mapping(source="TRANDATE", target="tranDate", qualifiedByName = {"DateTimeHelper", "convertCbsApiDateToString"}),
		@Mapping(source="DATEGENERATED", target="dateGenerated", qualifiedByName = {"DateTimeHelper", "convertCbsApiDateToString"}),
		@Mapping(source="DATESENT", target="dateSent", qualifiedByName = {"DateTimeHelper", "convertCbsApiDateToString"})
	})
	public MessageQJpe mapToJpe(XPSMESSAGEQCUSTOMADVICEAPIType api, @MappingTarget MessageQJpe jpe);
}