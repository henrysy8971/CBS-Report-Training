package com.silverlakesymmetri.cbs.gla.svc;

import java.util.List;
import java.util.Map;

import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation;
import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation.ServiceOperationType;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.svc.BusinessService;
import com.silverlakesymmetri.cbs.gla.bdo.sdo.CashFlowDtlQry;
import com.silverlakesymmetri.cbs.gla.bdo.sdo.CashFlowOverallQry;
import com.silverlakesymmetri.cbs.gla.jpa.mapping.sdo.CashFlowDtlQryJpe;

public interface CashFlowDtlsService extends BusinessService<CashFlowDtlQry, CashFlowDtlQryJpe> {

	public static final String SVC_OP_NAME_CASHFLOWSTLSSERVICE_GET = "CashFlowDtlsService.get";
	public static final String SVC_OP_NAME_CASHFLOWSTLSSERVICE_FIND = "CashFlowDtlsService.find";
	public static final String SVC_OP_NAME_CASHFLOWSTLSSERVICE_QUERY = "CashFlowDtlsService.query";
	public static final String SVC_OP_NAME_CASHFLOWSTLSERVICE_FIND_NOSTRO_CASHFLOW = "CashFlowDtlsService.findNostroCashFlow";
	
	@ServiceOperation(name = SVC_OP_NAME_CASHFLOWSTLSSERVICE_GET, type = ServiceOperationType.GET)
    public CashFlowDtlQry getByPk(String publicKey, CashFlowDtlQry reference);

    @ServiceOperation(name = SVC_OP_NAME_CASHFLOWSTLSSERVICE_FIND)
    public List<CashFlowDtlQry> find(FindCriteria findCriteria, CbsHeader cbsHeader);
    
    @ServiceOperation(name = SVC_OP_NAME_CASHFLOWSTLSSERVICE_QUERY)
    public List<CashFlowDtlQry> query(int offset, int resultLimit, String groupBy, String order, Map<String, Object> filters);
    
    @ServiceOperation(name = SVC_OP_NAME_CASHFLOWSTLSERVICE_FIND_NOSTRO_CASHFLOW ,
            type = ServiceOperation.ServiceOperationType.READ, passParamAsMap = true)
    public List<CashFlowDtlQry> findNostroCashFlow(Map<String, Object> queryParams);
}
