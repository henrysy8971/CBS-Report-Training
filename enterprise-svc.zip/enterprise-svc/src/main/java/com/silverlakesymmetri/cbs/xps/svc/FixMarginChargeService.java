package com.silverlakesymmetri.cbs.xps.svc;

import java.util.List;
import java.util.Map;

import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation;
import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation.ServiceOperationType;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.svc.BusinessService;
import com.silverlakesymmetri.cbs.xps.bdo.sdo.FixMarginCharge;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.FixMarginChargeJpe;

public interface FixMarginChargeService extends BusinessService<FixMarginCharge, FixMarginChargeJpe> {

	public static final String SVC_OP_NAME_FIXMARGINCHARGESERVICE_GET = "FixMarginChargeService.get";
	public static final String SVC_OP_NAME_FIXMARGINCHARGESERVICE_QUERY = "FixMarginChargeService.query";
	public static final String SVC_OP_NAME_FIXMARGINCHARGESERVICE_CREATE = "FixMarginChargeService.create";
	public static final String SVC_OP_NAME_FIXMARGINCHARGESERVICE_UPDATE = "FixMarginChargeService.update";
	public static final String SVC_OP_NAME_FIXMARGINCHARGESERVICE_DELETE = "FixMarginChargeService.delete";
	public static final String SVC_OP_NAME_FIXMARGINCHARGESERVICE_FIND = "FixMarginChargeService.find";
	public static final String SVC_OP_NAME_FIXMARGINCHARGESERVICE_COUNT = "FixMarginChargeService.count";

	@ServiceOperation(name = SVC_OP_NAME_FIXMARGINCHARGESERVICE_GET, type = ServiceOperationType.GET)
	public FixMarginCharge getByPk(String publicKey, FixMarginCharge reference);

	@ServiceOperation(name = SVC_OP_NAME_FIXMARGINCHARGESERVICE_QUERY)
	public List<FixMarginCharge> query(int offset, int resultLimit, String groupBy, String order,
			Map<String, Object> filters);

	@ServiceOperation(name = SVC_OP_NAME_FIXMARGINCHARGESERVICE_CREATE)
	public FixMarginCharge create(FixMarginCharge dataObject);

	@ServiceOperation(name = SVC_OP_NAME_FIXMARGINCHARGESERVICE_UPDATE)
	public FixMarginCharge update(FixMarginCharge dataObject);

	@ServiceOperation(name = SVC_OP_NAME_FIXMARGINCHARGESERVICE_DELETE)
	public boolean delete(FixMarginCharge dataObject);

	@ServiceOperation(name = SVC_OP_NAME_FIXMARGINCHARGESERVICE_FIND)
	public List<FixMarginCharge> find(FindCriteria findCriteria, CbsHeader cbsHeader);

	@ServiceOperation(name = SVC_OP_NAME_FIXMARGINCHARGESERVICE_COUNT, type = ServiceOperationType.GET)
	public Long count(FindCriteria findCriteria, CbsHeader cbsHeader);

	/**
	 * Two Tier Chargess.
	 *
	 * @return Two Tier charges.
	 */
	List<FixMarginCharge> getAll();
}
