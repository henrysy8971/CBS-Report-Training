package com.silverlakesymmetri.cbs.xps.svc.mapper.decorator;

import java.util.ArrayList;

import org.mapstruct.Context;
import org.mapstruct.MappingTarget;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

import com.silverlakesymmetri.cbs.commons.xmlapi.enums.CbsXmlApiOperation;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.ChargeDetailsJpe;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.ChargeMasterJpe;
import com.silverlakesymmetri.cbs.xps.svc.mapper.ChargeDetailServiceMapper;
import com.silverlakesymmetri.cbs.xps.svc.mapper.ChargeFixedServiceMapper;
import com.silverlakesymmetri.cbs.xps.svc.mapper.ChargeInterestServiceMapper;
import com.silverlakesymmetri.cbs.xps.svc.mapper.ChargeRatedServiceMapper;
import com.silverlakesymmetri.cbs.xps.svc.mapper.ChargeRecalculateSlabServiceMapper;
import com.silverlakesymmetri.cbs.xps.svc.mapper.ChargeServiceMapper;
import com.silverlakesymmetri.cbs.xps.xmlapi.XPSCHARGERECALCULATESLABAPIType;
import com.silverlakesymmetri.cbs.xps.xmlapi.XPSTRANCHARGEDETAILAPIType;

public abstract class ChargeRecalculateSlabServiceDecorator implements ChargeRecalculateSlabServiceMapper {
	
	private static final String CHARGE_TYPE_FIXED = "F";
	private static final String CHARGE_TYPE_INTEREST = "I";
	private static final String CHARGE_TYPE_PERIODIC = "P";
	private static final String CHARGE_TYPE_RATED = "R";
	private static final String CHARGE_TYPE_TWOTIER = "T";

	@Autowired
	@Qualifier("delegate")
	protected ChargeRecalculateSlabServiceMapper delegate;

	@Autowired
	protected ChargeDetailServiceMapper detailMapper;
	
	@Autowired
	protected ChargeServiceMapper chargeMapper;
	
	@Autowired
	protected ChargeFixedServiceMapper fixedMapper;
	
	@Autowired
	protected ChargeRatedServiceMapper ratedMapper;
	
	@Autowired
	protected ChargeInterestServiceMapper interestMapper;

	@Override
	public XPSCHARGERECALCULATESLABAPIType mapToApi(ChargeMasterJpe jpe, @Context CbsXmlApiOperation oper){
		XPSCHARGERECALCULATESLABAPIType req = (XPSCHARGERECALCULATESLABAPIType) delegate.mapToApi(jpe, oper);
		
		if(jpe.getChargeDetailsList() != null && jpe.getChargeDetailsList().size() > 0){
			//master's first detail is always the selected charge
			ChargeDetailsJpe detailsJpe = jpe.getChargeDetailsList().get(0);
			XPSTRANCHARGEDETAILAPIType detailApi = detailMapper.mapToApi(detailsJpe, oper);
			if(CHARGE_TYPE_FIXED.equals(detailsJpe.getChargeType())){
				detailApi = fixedMapper.mapToApi(detailsJpe.getChargeFixedStructRec(), detailApi);
			} else if(CHARGE_TYPE_RATED.equals(detailsJpe.getChargeType())){
				detailApi = ratedMapper.mapToApi(detailsJpe.getChargeRatedStructRec(), detailApi);
			} else if(CHARGE_TYPE_INTEREST.equals(detailsJpe.getChargeType())){
				detailApi = interestMapper.mapToApi(detailsJpe.getChargeInterestStructRec(), detailApi);
			}

			req.setCHARGE(detailApi);
		}
		
		return  req;
	}
	
	@Override
	public ChargeMasterJpe mapToJpe(XPSCHARGERECALCULATESLABAPIType api, @MappingTarget ChargeMasterJpe jpe){
		delegate.mapToJpe(api, jpe);
		
		jpe.setChargeDetailsList(new ArrayList<ChargeDetailsJpe>());
		ChargeDetailsJpe detailsJpe = new ChargeDetailsJpe();
		detailsJpe = detailMapper.mapToJpe(api.getCHARGE(), detailsJpe);
		if(CHARGE_TYPE_FIXED.equals(detailsJpe.getChargeType())){
			detailsJpe.setChargeFixedStructRec(fixedMapper.mapToJpe(api.getCHARGE(), detailsJpe.getChargeFixedStructRec()));
		} else if(CHARGE_TYPE_RATED.equals(detailsJpe.getChargeType())){
			detailsJpe.setChargeRatedStructRec(ratedMapper.mapToJpe(api.getCHARGE(), detailsJpe.getChargeRatedStructRec()));
		} else if(CHARGE_TYPE_INTEREST.equals(detailsJpe.getChargeType())){
			detailsJpe.setChargeInterestStructRec(interestMapper.mapToJpe(api.getCHARGE(), detailsJpe.getChargeInterestStructRec()));
		}
		jpe.getChargeDetailsList().add(detailsJpe);
		return jpe;
	}

}


