package com.silverlakesymmetri.cbs.swf.svc.mapper.mapping;

import org.apache.commons.lang3.StringUtils;
import org.mapstruct.DecoratedWith;
import org.mapstruct.InheritInverseConfiguration;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Mappings;

import com.silverlakesymmetri.cbs.swf.jpa.mapping.sdo.SwfF71Jpe;
import com.silverlakesymmetri.cbs.swf.svc.mapper.decorator.SwfF71MapperDecorator;
import com.silverlakesymmetri.cbs.swf.xmlapi.SWFF71TYPEType;

@Mapper(imports=StringUtils.class)
@DecoratedWith(SwfF71MapperDecorator.class)
public interface SwfF71Mapper {
	@Mappings({
		@Mapping(source="opt", target="OPT"),
		@Mapping(source="code", target="CODE"),
		@Mapping(source="currency", target="CURRENCY"),
		@Mapping(source="amount", target="AMOUNT"),
		@Mapping(source="settleEquivAmt", target="SETTLEEQUIVAMT")
	})
	SWFF71TYPEType mapToApi(SwfF71Jpe jpe);
	
	@InheritInverseConfiguration(name = "mapToApi")
	@Mappings({
		@Mapping(target="opt", expression="java(StringUtils.isNotBlank(api.getOPT())?api.getOPT():null)"),
		@Mapping(target="code", expression="java(StringUtils.isNotBlank(api.getCODE())?api.getCODE():null)"),
		@Mapping(target="currency", expression="java(StringUtils.isNotBlank(api.getCURRENCY())?api.getCURRENCY():null)")
	})
	SwfF71Jpe mapToJpe(SWFF71TYPEType api);
}