package com.silverlakesymmetri.cbs.swf.svc.mapper.decorator;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

import com.silverlakesymmetri.cbs.swf.jpa.mapping.sdo.SwfFinEntityJpe;
import com.silverlakesymmetri.cbs.swf.svc.mapper.mapping.SwfF53Mapper;
import com.silverlakesymmetri.cbs.swf.xmlapi.SWFF53TYPEType;

public abstract class SwfF53MapperDecorator implements SwfF53Mapper {
	
	@Autowired
	@Qualifier("delegate")
	protected SwfF53Mapper delegate;

	@Override
	public SWFF53TYPEType mapToApi(SwfFinEntityJpe jpe){
		SWFF53TYPEType swfF53 = delegate.mapToApi(jpe);
		if(swfF53 != null && swfF53.getACCOUNT() == null && swfF53.getADDRESS() == null && swfF53.getBIC() == null && swfF53.getBRANCHLOCATION() == null){
			return null;
		}
		return swfF53;
	}
	
	@Override
	public SwfFinEntityJpe mapToJpe(SWFF53TYPEType api){
		return delegate.mapToJpe(api);
	}
	
}
