package com.silverlakesymmetri.cbs.xps.svc.impl;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.mysema.query.types.EntityPath;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.svc.AbstractBusinessService;
import com.silverlakesymmetri.cbs.commons.svc.BusinessObjectValidationCapable;
import com.silverlakesymmetri.cbs.xps.bdo.sdo.ExtGlPostingSetup;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.ExtGlPostingSetupJpe;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.QExtGlPostingSetupJpe;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.id.ExtGlPostingSetupPk;
import com.silverlakesymmetri.cbs.xps.svc.ExtGlPostingSetupService;

@Service
@Transactional
public class ExtGlPostingSetupServiceImpl
		extends AbstractBusinessService<ExtGlPostingSetup, ExtGlPostingSetupJpe, ExtGlPostingSetupPk>
		implements ExtGlPostingSetupService, BusinessObjectValidationCapable<ExtGlPostingSetup> {

	@Override
	protected ExtGlPostingSetupPk getIdFromDataObjectInstance(ExtGlPostingSetup dataObject) {
		return new ExtGlPostingSetupPk(dataObject.getGlPostingType());
	}

	@Override
	protected EntityPath<ExtGlPostingSetupJpe> getEntityPath() {
		return QExtGlPostingSetupJpe.extGlPostingSetupJpe;
	}

	@Override
	public ExtGlPostingSetup create(ExtGlPostingSetup dataObject) {
		return super.create(dataObject);
	}

	@Override
	public ExtGlPostingSetup update(ExtGlPostingSetup dataObject) {
		return super.update(dataObject);
	}

	@Override
	public List<ExtGlPostingSetup> query(int offset, int resultLimit, String groupBy, String order,
			Map<String, Object> filters) {
		return super.query(offset, resultLimit, groupBy, order, filters);
	}

	@Override
	public boolean delete(ExtGlPostingSetup dataObject) {
		return super.delete(dataObject);
	}

	@Override
	public List<ExtGlPostingSetup> find(FindCriteria findCriteria, CbsHeader cbsHeader) {
		return super.find(findCriteria, cbsHeader);
	}

}
