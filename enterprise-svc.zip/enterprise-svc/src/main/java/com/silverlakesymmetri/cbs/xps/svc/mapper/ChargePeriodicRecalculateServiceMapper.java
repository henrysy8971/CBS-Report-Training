package com.silverlakesymmetri.cbs.xps.svc.mapper;

import org.mapstruct.Context;
import org.mapstruct.DecoratedWith;
import org.mapstruct.InheritInverseConfiguration;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingTarget;
import org.mapstruct.Mappings;

import com.silverlakesymmetri.cbs.commons.jpa.util.DateTimeHelper;
import com.silverlakesymmetri.cbs.commons.xmlapi.enums.CbsXmlApiOperation;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.ChargeMasterJpe;
import com.silverlakesymmetri.cbs.xps.svc.mapper.decorator.ChargePeriodicRecalculateServiceDecorator;
import com.silverlakesymmetri.cbs.xps.xmlapi.XPSCHARGEPERIODICRECALCULATEAPIType;

@Mapper(uses = { DateTimeHelper.class, ChargeEventInfoMapper.class, ChargeInstrumentInfoMapper.class })
@DecoratedWith(ChargePeriodicRecalculateServiceDecorator.class)
public interface ChargePeriodicRecalculateServiceMapper {

	@Mappings({
		@Mapping(source="domain", target = "DOMAIN"),
		@Mapping(source="chargeInstrumentInfoStructRec", target = "INSTRUMENT"),
		@Mapping(source="chargeEventInfoStructRec", target = "EVENT"),
		@Mapping(source="valueDate", target = "VALUEDATE", qualifiedByName = {"DateTimeHelper", "convertDateToCbsXmlApiDate"}),
		@Mapping(source="tranDate", target = "RUNDATE", qualifiedByName = {"DateTimeHelper", "convertDateToCbsXmlApiDate"}),
		@Mapping(source="ccy", target = "MASTERCCY"),
	})
	public XPSCHARGEPERIODICRECALCULATEAPIType mapToApi(ChargeMasterJpe jpe, @Context CbsXmlApiOperation oper);

	@InheritInverseConfiguration(name = "mapToApi")
	@Mappings({
		@Mapping(source="VALUEDATE", target="valueDate", qualifiedByName = {"DateTimeHelper", "convertCbsApiDateToString"}),
		@Mapping(source="RUNDATE", target="tranDate", qualifiedByName = {"DateTimeHelper", "convertCbsApiDateToString"})
	})
	public ChargeMasterJpe mapToJpe(XPSCHARGEPERIODICRECALCULATEAPIType api, @MappingTarget ChargeMasterJpe jpe);
}