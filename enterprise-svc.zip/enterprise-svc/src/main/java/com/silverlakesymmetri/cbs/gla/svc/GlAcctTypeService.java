package com.silverlakesymmetri.cbs.gla.svc;


import java.util.List;
import java.util.Map;

import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation;
import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation.ServiceOperationType;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.svc.BusinessService;
import com.silverlakesymmetri.cbs.gla.bdo.sdo.GlAcctType;
import com.silverlakesymmetri.cbs.gla.jpa.mapping.sdo.GlAcctTypeJpe;

public interface GlAcctTypeService extends BusinessService<GlAcctType, GlAcctTypeJpe> {

	public static final String SVC_OP_NAME_GLACCTTYPESERVICE_GET = "GlAcctTypeService.get";
	public static final String SVC_OP_NAME_GLACCTTYPESERVICE_QUERY = "GlAcctTypeService.query";
	public static final String SVC_OP_NAME_GLACCTTYPESERVICE_CREATE = "GlAcctTypeService.create";
	public static final String SVC_OP_NAME_GLACCTTYPESERVICE_UPDATE = "GlAcctTypeService.update";
	public static final String SVC_OP_NAME_GLACCTTYPESERVICE_DELETE = "GlAcctTypeService.delete";
	public static final String SVC_OP_NAME_GLACCTTYPESERVICE_FIND = "GlAcctTypeService.find";

	@ServiceOperation(name = SVC_OP_NAME_GLACCTTYPESERVICE_GET, type = ServiceOperationType.GET)
	public GlAcctType getByPk(String publicKey, GlAcctType reference);

	@ServiceOperation(name = SVC_OP_NAME_GLACCTTYPESERVICE_CREATE)
	public GlAcctType create(GlAcctType dataObject);

	@ServiceOperation(name = SVC_OP_NAME_GLACCTTYPESERVICE_UPDATE)
	public GlAcctType update(GlAcctType dataObject);

	@ServiceOperation(name = SVC_OP_NAME_GLACCTTYPESERVICE_QUERY)
	public List<GlAcctType> query(int offset, int resultLimit, String groupBy, String order, Map<String, Object> filters);

	@ServiceOperation(name = SVC_OP_NAME_GLACCTTYPESERVICE_DELETE)
	public boolean delete(GlAcctType dataObject);

	@ServiceOperation(name = SVC_OP_NAME_GLACCTTYPESERVICE_FIND)
	public List<GlAcctType> find(FindCriteria findCriteria, CbsHeader cbsHeader);

}
