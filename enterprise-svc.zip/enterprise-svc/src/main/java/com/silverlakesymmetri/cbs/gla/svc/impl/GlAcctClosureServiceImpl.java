package com.silverlakesymmetri.cbs.gla.svc.impl;

import com.mysema.query.types.EntityPath;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.jpa.entity.FindCriteriaJpe;
import com.silverlakesymmetri.cbs.commons.jpa.entity.ViewCriteriaItemJpe;
import com.silverlakesymmetri.cbs.commons.jpa.entity.ViewCriteriaJpe;
import com.silverlakesymmetri.cbs.commons.jpa.entity.ViewCriteriaRowJpe;
import com.silverlakesymmetri.cbs.commons.svc.AbstractXmlApiBusinessService;
import com.silverlakesymmetri.cbs.commons.svc.BusinessObjectValidationCapable;
import com.silverlakesymmetri.cbs.commons.xmlapi.enums.CbsXmlApiOperation;
import com.silverlakesymmetri.cbs.csd.bdo.sdo.Branch;
import com.silverlakesymmetri.cbs.csd.bdo.sdo.Currency;
import com.silverlakesymmetri.cbs.csd.bdo.sdo.ProfitCentre;
import com.silverlakesymmetri.cbs.csd.gla.bdo.sdo.ChartAccount;
import com.silverlakesymmetri.cbs.gla.bdo.sdo.GlAcctClosure;
import com.silverlakesymmetri.cbs.gla.jpa.mapping.sdo.GlAcctClosureJpe;
import com.silverlakesymmetri.cbs.gla.jpa.mapping.sdo.QGlAcctClosureJpe;
import com.silverlakesymmetri.cbs.gla.jpa.mapping.sdo.id.GlAcctClosurePk;
import com.silverlakesymmetri.cbs.gla.jpa.mapping.sdo.util.GlaJpeConstants;
import com.silverlakesymmetri.cbs.gla.svc.GlAcctClosureService;
import com.silverlakesymmetri.cbs.gla.svc.mapper.mapping.GlAcctClosureToGLAACCTCLOSUREAPITypeMapper;
import com.silverlakesymmetri.cbs.gla.xmlapi.GLAACCTCLOSUREAPIType;
import com.silverlakesymmetri.cbs.mcl.bdo.sdo.Client;
import com.silverlakesymmetri.cbs.mcl.jpa.mapping.sdo.util.MclJpeConstants;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by Emerson.Sanchez on 26/7/2019.
 */
@Service
@Transactional
public class GlAcctClosureServiceImpl extends AbstractXmlApiBusinessService<GlAcctClosure, GlAcctClosureJpe, GlAcctClosurePk,
        GLAACCTCLOSUREAPIType, GLAACCTCLOSUREAPIType> implements GlAcctClosureService,
        BusinessObjectValidationCapable<GlAcctClosure> {

    @Autowired
    private GlAcctClosureToGLAACCTCLOSUREAPITypeMapper mapper;

    @Override
    protected GLAACCTCLOSUREAPIType transformBdoToXmlApiRqCreate(GlAcctClosure dataObject) {
        return transformBDOToAPIType(dataObject, CbsXmlApiOperation.INSERT);
    }

    @Override
    protected GLAACCTCLOSUREAPIType transformBdoToXmlApiRqUpdate(GlAcctClosure dataObject) {
        return transformBDOToAPIType(dataObject, CbsXmlApiOperation.UPDATE);
    }

    @Override
    protected GLAACCTCLOSUREAPIType transformBdoToXmlApiRqDelete(GlAcctClosure dataObject) {
        return transformBDOToAPIType(dataObject, CbsXmlApiOperation.DELETE);
    }

    private GLAACCTCLOSUREAPIType transformBDOToAPIType(GlAcctClosure bdo, CbsXmlApiOperation operation) {
        Long clientId = getClientId(bdo.getClientNo());
        GlAcctClosureJpe jpe = jaxbSdoHelper.unwrap(bdo, GlAcctClosureJpe.class);
        GLAACCTCLOSUREAPIType apiType = mapper.jpeToApiType(jpe);
        super.setTechColsFromDataObject(bdo, apiType);
        apiType.setOPERATION(operation.getOperation());
        apiType.setCLIENTNO(clientId);
        apiType.setCONFIRMIND(bdo.isConfirmFlag() ? "Y" : "N");
        apiType.setSWEEPIND(bdo.isSweepFlag() ? "Y" : "N");
        apiType.setCAPIND(bdo.isCapFlag() ? "Y" : "N");
        return apiType;
    }

    @Override
    public GlAcctClosure getByPk(String publicKey, GlAcctClosure reference){
        /*if(publicKey != null || publicKey.equals("null")) {
            return jaxbSdoHelper.createSdoInstance(GlAcctClosure.class, GlAcctClosureJpe.class);
        }*/
        return super.getByPk(publicKey, reference);
    }

    @Override
    protected GlAcctClosure processXmlApiRs(GlAcctClosure dataObject, GLAACCTCLOSUREAPIType glaacctclosureapiType) {
        return dataObject;
    }

    @Override
    protected List<GlAcctClosure> processXmlApiListRs(GlAcctClosure dataObject, GLAACCTCLOSUREAPIType glaacctclosureapiType) {
        return null;
    }

    @Override
    protected Class<GLAACCTCLOSUREAPIType> getXmlApiResponseClass() {
        return GLAACCTCLOSUREAPIType.class;
    }

    @Override
    protected GlAcctClosurePk getIdFromDataObjectInstance(GlAcctClosure dataObject) {
        return null;
    }

    @Override
    protected EntityPath<GlAcctClosureJpe> getEntityPath() {
        return QGlAcctClosureJpe.glAcctClosureJpe;
    }


    private Long getClientId(String clientNo) {
        Map<String, Object> params = new HashMap<>();
        params.put("clientNo", clientNo);
        return dataService.getWithNamedQuery(MclJpeConstants.CLIENT_JPE_FIND_ID_FROM_REF_NO, params, Long.class);
    }

    @Override
    public List<Branch> findBranches(Map<String, Object> queryParams) {
        String branch = (String) queryParams.get("branch");
        String branchDesc = (String) queryParams.get("branchDesc");
        int limit = queryParams.get("limit") != null ? Integer.parseInt((String)queryParams.get("limit")) : 10;
        int offset = queryParams.get("offset") != null ? Integer.parseInt((String)queryParams.get("offset")) : 0;
        String query = GlaJpeConstants.GLA_ACCT_CLOSE_BRANCH_LOV_QUERY;

        List<Branch> result = new ArrayList<Branch>();
        final Map<String, Object> parameters = new HashMap<>();

        if(branch != null){
            query = query + " AND UPPER(gac.branch) like :branch";
            parameters.put("branch", "%" + branch.toUpperCase() + "%");
        }

        if(branchDesc != null){
            query = query + " AND UPPER(kbh.branchDesc) like :branchDesc";
            parameters.put("branchDesc", "%" + branchDesc.toUpperCase() + "%");
        }

        query = query + " ORDER BY gac.branch";
        List<Branch> branches = dataService.findWithQuery(query, parameters, offset, limit, Branch.class);

        for (Object o : branches) {
            Object[] values = (Object[]) o;
            Branch branchBdo = jaxbSdoHelper.createSdoInstance(Branch.class);
            branchBdo.setBranch((String) values[0]);
            branchBdo.setBranchDesc((String) values[1]);
            result.add(branchBdo);
        }
        return result;
    }

    @Override
    public List<Currency> findCcy(Map<String, Object> queryParams) {
        String ccy = (String) queryParams.get("ccy");
        String ccyDesc = (String) queryParams.get("ccyDesc");
        int limit = queryParams.get("limit") != null ? Integer.parseInt((String)queryParams.get("limit")) : 10;
        int offset = queryParams.get("offset") != null ? Integer.parseInt((String)queryParams.get("offset")) : 0;
        String query = GlaJpeConstants.GLA_ACCT_CLOSE_CURRENCY_LOV_QUERY;

        List<Currency> result = new ArrayList<Currency>();
        final Map<String, Object> parameters = new HashMap<>();

        if(ccy != null){
            query = query + " AND UPPER(gac.ccy) like :ccy";
            parameters.put("ccy", "%" + ccy.toUpperCase() + "%");
        }

        if(ccyDesc != null){
            query = query + " AND UPPER(kcu.ccyDesc) like :ccyDesc";
            parameters.put("ccyDesc", "%" + ccyDesc.toUpperCase() + "%");
        }

        query = query + " ORDER BY gac.ccy";
        List<Currency> list = dataService.findWithQuery(query, parameters, offset, limit, Currency.class);

        for (Object o : list) {
            Object[] values = (Object[]) o;
            Currency bdo = jaxbSdoHelper.createSdoInstance(Currency.class);
            bdo.setCcy((String) values[0]);
            bdo.setCcyDesc((String) values[1]);
            result.add(bdo);
        }
        return result;
    }

    @Override
    public List<Client> findClientNo(Map<String, Object> queryParams) {
        String clientNo = (String) queryParams.get("clientNo");
        String clientDesc = (String) queryParams.get("clientDesc");
        int limit = queryParams.get("limit") != null ? Integer.parseInt((String)queryParams.get("limit")) : 10;
        int offset = queryParams.get("offset") != null ? Integer.parseInt((String)queryParams.get("offset")) : 0;
        String query = GlaJpeConstants.GLA_ACCT_CLOSE_CLIENT_NO_LOV_QUERY;

        List<Client> result = new ArrayList<Client>();
        final Map<String, Object> parameters = new HashMap<>();

        if(clientNo != null){
            query = query + " AND UPPER(kcl.clientNo) like :clientNo";
            parameters.put("clientNo", "%" + clientNo.toUpperCase() + "%");
        }

        if(clientDesc != null){
            query = query + " AND UPPER(kcl.clientShort) like :clientShort";
            parameters.put("clientShort", "%" + clientDesc.toUpperCase() + "%");
        }

        query = query + " ORDER BY kcl.clientNo";
        List<Client> list = dataService.findWithQuery(query, parameters, offset, limit, Client.class);

        for (Object o : list) {
            Object[] values = (Object[]) o;
            Client bdo = jaxbSdoHelper.createSdoInstance(Client.class);
            bdo.setClientNo((String) values[0]);
            bdo.setClientShort((String) values[1]);
            result.add(bdo);
        }
        return result;
    }

    @Override
    public List<GlAcctClosure> findNosVosNo(Map<String, Object> queryParams) {
        String nosVosNo = (String) queryParams.get("nosVosNo");
        int limit = queryParams.get("limit") != null ? Integer.parseInt((String)queryParams.get("limit")) : 10;
        int offset = queryParams.get("offset") != null ? Integer.parseInt((String)queryParams.get("offset")) : 0;
        String query = GlaJpeConstants.GLA_ACCT_CLOSE_NOS_VOS_NO_LOV_QUERY;

        List<GlAcctClosure> result = new ArrayList<GlAcctClosure>();
        final Map<String, Object> parameters = new HashMap<>();

        if(nosVosNo != null){
            query = query + " AND g.nosVosNo = :nosVosNo";
            parameters.put("nosVosNo", Integer.valueOf(nosVosNo));
        }

        query = query + " ORDER BY g.nosVosNo";
        List<GlAcctClosure> list = dataService.findWithQuery(query, parameters, offset, limit, GlAcctClosure.class);

        for (Object o : list) {
            Integer value = (Integer) o;
            GlAcctClosure bdo = jaxbSdoHelper.createSdoInstance(GlAcctClosure.class);
            bdo.setNosVosNo(value);
            result.add(bdo);
        }
        return result;
    }

    @Override
    public List<ChartAccount> findGlCodes(Map<String, Object> queryParams) {
        String glCode = (String) queryParams.get("glCode");
        String glCodeDesc = (String) queryParams.get("glCodeDesc");
        int limit = queryParams.get("limit") != null ? Integer.parseInt((String)queryParams.get("limit")) : 10;
        int offset = queryParams.get("offset") != null ? Integer.parseInt((String)queryParams.get("offset")) : 0;
        String query = GlaJpeConstants.GLA_ACCT_CLOSE_GL_CODE_LOV;

        List<ChartAccount> result = new ArrayList<ChartAccount>();
        final Map<String, Object> parameters = new HashMap<>();

        if(glCode != null) {
            query = GlaJpeConstants.GLA_ACCT_CLOSE_GL_CODE_FILTER_LOV;
            parameters.put("glCode", "%" + glCode.toUpperCase() + "%");
        }

        if(glCodeDesc != null) {
            query = GlaJpeConstants.GLA_ACCT_CLOSE_GL_CODE_DESC_FILTER_LOV;
            parameters.put("glCodeDesc", "%" + glCodeDesc.toUpperCase() + "%");
            if(glCode != null) {
                query = GlaJpeConstants.GLA_ACCT_CLOSE_GL_CODE_AND_DESC_FILTER_LOV;
            }
        }

        List<ChartAccount> list = dataService.findWithNamedQuery(query, parameters, offset, limit, ChartAccount.class);

        for (Object o : list) {
            Object[] values = (Object[]) o;
            ChartAccount bdo = jaxbSdoHelper.createSdoInstance(ChartAccount.class);
            bdo.setGlCode((String) values[0]);
            bdo.setGlCodeDesc((String) values[1]);
            result.add(bdo);
        }
        return result;
    }

    @Override
    public List<GlAcctClosure> findSeqNo(Map<String, Object> queryParams) {
        String seqNo = (String) queryParams.get("seqNo");
        int limit = queryParams.get("limit") != null ? Integer.parseInt((String)queryParams.get("limit")) : 10;
        int offset = queryParams.get("offset") != null ? Integer.parseInt((String)queryParams.get("offset")) : 0;
        String query = GlaJpeConstants.GLA_ACCT_CLOSE_SEQ_NO_LOV_QUERY;

        List<GlAcctClosure> result = new ArrayList<GlAcctClosure>();
        final Map<String, Object> parameters = new HashMap<>();

        if(seqNo != null){
            query = query + " AND g.seqNo = :seqNo";
            parameters.put("seqNo", Integer.valueOf(seqNo));
        }

        query = query + " ORDER BY g.seqNo";
        List<GlAcctClosure> list = dataService.findWithQuery(query, parameters, offset, limit, GlAcctClosure.class);

        for (Object o : list) {
            Integer value = (Integer) o;
            GlAcctClosure bdo = jaxbSdoHelper.createSdoInstance(GlAcctClosure.class);
            bdo.setSeqNo(value);
            result.add(bdo);
        }
        return result;
    }

    @Override
    public List<ProfitCentre> findProfitCentre(Map<String, Object> queryParams) {
        String profitCentre = (String) queryParams.get("profitCentre");
        String profitCentreDesc = (String) queryParams.get("profitCentreDesc");
        int limit = queryParams.get("limit") != null ? Integer.parseInt((String)queryParams.get("limit")) : 10;
        int offset = queryParams.get("offset") != null ? Integer.parseInt((String)queryParams.get("offset")) : 0;
        String query = GlaJpeConstants.GLA_ACCT_CLOSE_PROFIT_CENTRE_LOV_QUERY;

        List<ProfitCentre> result = new ArrayList<ProfitCentre>();
        final Map<String, Object> parameters = new HashMap<>();

        if(profitCentre != null){
            query = query + " AND UPPER(gac.profitCentre) like :profitCentre";
            parameters.put("profitCentre", "%" + profitCentre.toUpperCase() + "%");
        }

        if(profitCentreDesc != null){
            query = query + " AND UPPER(kpc.profitCentreDesc) like :profitCentreDesc";
            parameters.put("profitCentreDesc", "%" + profitCentreDesc.toUpperCase() + "%");
        }

        query = query + " ORDER BY gac.profitCentre";
        List<ProfitCentre> list = dataService.findWithQuery(query, parameters, offset, limit, ProfitCentre.class);

        for (Object o : list) {
            Object[] values = (Object[]) o;
            ProfitCentre bdo = jaxbSdoHelper.createSdoInstance(ProfitCentre.class);
            bdo.setProfitCentre((String) values[0]);
            bdo.setProfitCentreDesc((String) values[1]);
            result.add(bdo);
        }
        return result;
    }

    @Override
    public Long count(FindCriteria findCriteria, CbsHeader cbsHeader) {
        FindCriteriaJpe jpe = jaxbSdoHelper.unwrap(findCriteria, FindCriteriaJpe.class);
        return dataService.getRowCount(GlAcctClosureJpe.class, jpe);
    }

    @Override
    public List<GlAcctClosure> query(int offset, int resultLimit, String groupBy, String order,
                                     Map<String, Object> filters) {
        return super.query(offset, resultLimit, groupBy, order, filters);
    }

    @Override
    public List<GlAcctClosure> find(FindCriteria findCriteria, CbsHeader cbsHeader) {
        return super.find(findCriteria, cbsHeader);
    }

    @Override
    public GlAcctClosure update(GlAcctClosure dataObject) {
        return super.update(dataObject);
    }
}
