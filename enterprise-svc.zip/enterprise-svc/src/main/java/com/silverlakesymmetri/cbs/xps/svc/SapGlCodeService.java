package com.silverlakesymmetri.cbs.xps.svc;


import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation;
import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation.ServiceOperationType;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.svc.BusinessService;
import com.silverlakesymmetri.cbs.xps.bdo.sdo.SapGlCode;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.SapGlCodeJpe;

import java.util.List;
import java.util.Map;

public interface SapGlCodeService extends BusinessService<SapGlCode, SapGlCodeJpe> {

    String SVC_OP_NAME_SAPGLCODESERVICE_GET = "SapGlCodeService.get";
    String SVC_OP_NAME_SAPGLCODESERVICE_QUERY = "SapGlCodeService.query";
    String SVC_OP_NAME_SAPGLCODESERVICE_CREATE = "SapGlCodeService.create";
    String SVC_OP_NAME_SAPGLCODESERVICE_UPDATE = "SapGlCodeService.update";
    String SVC_OP_NAME_SAPGLCODESERVICE_DELETE = "SapGlCodeService.delete";
    String SVC_OP_NAME_SAPGLCODESERVICE_FIND = "SapGlCodeService.find";

    @ServiceOperation(name = SVC_OP_NAME_SAPGLCODESERVICE_GET, type = ServiceOperationType.GET)
    SapGlCode getByPk(String publicKey, SapGlCode reference);

    @ServiceOperation(name = SVC_OP_NAME_SAPGLCODESERVICE_CREATE)
    SapGlCode create(SapGlCode dataObject);

    @ServiceOperation(name = SVC_OP_NAME_SAPGLCODESERVICE_UPDATE)
    SapGlCode update(SapGlCode dataObject);

    @ServiceOperation(name = SVC_OP_NAME_SAPGLCODESERVICE_QUERY)
    List<SapGlCode> query(int offset, int resultLimit, String groupBy, String order, Map<String, Object> filters);

    @ServiceOperation(name = SVC_OP_NAME_SAPGLCODESERVICE_DELETE)
    boolean delete(SapGlCode dataObject);

    @ServiceOperation(name = SVC_OP_NAME_SAPGLCODESERVICE_FIND)
    List<SapGlCode> find(FindCriteria findCriteria, CbsHeader cbsHeader);

}
