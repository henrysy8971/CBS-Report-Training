package com.silverlakesymmetri.cbs.xps.svc.mapper.mapping;

import org.mapstruct.Context;
import org.mapstruct.InheritInverseConfiguration;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingTarget;
import org.mapstruct.Mappings;

import com.silverlakesymmetri.cbs.commons.xmlapi.enums.CbsXmlApiOperation;
import com.silverlakesymmetri.cbs.swf.jpa.mapping.sdo.SwfMt400Jpe;
import com.silverlakesymmetri.cbs.swf.svc.mapper.mapping.SwfF52Mapper;
import com.silverlakesymmetri.cbs.swf.svc.mapper.mapping.SwfF53Mapper;
import com.silverlakesymmetri.cbs.swf.svc.mapper.mapping.SwfF54Mapper;
import com.silverlakesymmetri.cbs.swf.svc.mapper.mapping.SwfF57Mapper;
import com.silverlakesymmetri.cbs.swf.svc.mapper.mapping.SwfF58Mapper;
import com.silverlakesymmetri.cbs.swf.svc.mapper.mapping.SwfF59Mapper;
import com.silverlakesymmetri.cbs.swf.svc.mapper.mapping.SwfF71NarrativeMapper;
import com.silverlakesymmetri.cbs.swf.svc.mapper.mapping.SwfF72Mapper;
import com.silverlakesymmetri.cbs.swf.svc.mapper.mapping.SwfF73Mapper;
import com.silverlakesymmetri.cbs.xps.xmlapi.XPSSWFSETTLEAPIType;

@Mapper(uses = {
		SwfF52Mapper.class,
		SwfF53Mapper.class,
		SwfF54Mapper.class,
		SwfF57Mapper.class,
		SwfF58Mapper.class,
		SwfF59Mapper.class,
		SwfF71NarrativeMapper.class,
		SwfF72Mapper.class,
		SwfF73Mapper.class
})
public interface SwfMt400ToXPSSWFSETTLEAPITypeMapper {
	@Mappings({
		@Mapping(target ="INTERNALKEY", ignore = true),
		@Mapping(target ="COVERMESSAGEDETAILS", ignore = true),
	    @Mapping(source="orderingInstitutionStructRec", target ="ORDERINGINSTITUTION"),
	    @Mapping(source="sendersCorrespondentStructRec", target ="SENDERSCORRESPONDENT"),
	    @Mapping(source="receiversCorrespondentStructRec", target ="RECEIVERSCORRESPONDENT"),
	    @Mapping(source="acctWithInstitutionStructRec", target ="ACCTWITHINSTITUTION"),
	    @Mapping(source="beneficiaryBankStructRec", target ="BENEFICIARYINSTITUTION"),
	    @Mapping(source="detailsOfChargesStructRec", target ="DETAILSOFCHARGESNARRATIVE"),
	    @Mapping(source="senderToReceiverInfoStructRec", target ="SENDERTORECEIVERINFO"),
	    @Mapping(source="detailsOfAmountsAddedStructRec", target ="DETAILSOFAMOUNTSADDED")
	})
	XPSSWFSETTLEAPIType mapToApi(SwfMt400Jpe jpe, @Context CbsXmlApiOperation oper);
	
	@InheritInverseConfiguration(name="mapToApi")
	SwfMt400Jpe mapToJpe(XPSSWFSETTLEAPIType api, @MappingTarget SwfMt400Jpe jpe);
}
