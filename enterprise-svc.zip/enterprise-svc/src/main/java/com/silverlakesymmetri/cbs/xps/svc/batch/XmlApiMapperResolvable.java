package com.silverlakesymmetri.cbs.xps.svc.batch;

public interface XmlApiMapperResolvable<E, A> {

	E mapToJpe(A api);
	
}
