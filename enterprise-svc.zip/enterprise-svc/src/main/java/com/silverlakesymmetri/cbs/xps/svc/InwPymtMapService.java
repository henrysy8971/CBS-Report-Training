package com.silverlakesymmetri.cbs.xps.svc;

import java.util.List;
import java.util.Map;

import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation;
import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation.ServiceOperationType;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.svc.BusinessService;
import com.silverlakesymmetri.cbs.xps.bdo.sdo.InwPymtMap;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.InwPymtMapJpe;

public interface InwPymtMapService extends BusinessService<InwPymtMap, InwPymtMapJpe> {

	public static final String XPS_OP_NAME_INWPYMTMAPSERVICE_GET = "inwPymtMapService.get";
	public static final String XPS_OP_NAME_INWPYMTMAPSERVICE_QUERY = "inwPymtMapService.query";
	public static final String XPS_OP_NAME_INWPYMTMAPSERVICE_FIND = "inwPymtMapService.find";
	public static final String XPS_OP_NAME_INWPYMTMAPSERVICE_CREATE = "inwPymtMapService.create";
	public static final String XPS_OP_NAME_INWPYMTMAPSERVICE_UPDATE = "inwPymtMapService.update";
	public static final String XPS_OP_NAME_INWPYMTMAPSERVICE_DELETE = "inwPymtMapService.delete";

	@ServiceOperation(name = XPS_OP_NAME_INWPYMTMAPSERVICE_GET, type = ServiceOperationType.GET)
	public InwPymtMap getByPk(String publicKey, InwPymtMap reference);

	@ServiceOperation(name = XPS_OP_NAME_INWPYMTMAPSERVICE_QUERY)
	public List<InwPymtMap> query(int offset, int resultLimit, String groupBy, String order,
			Map<String, Object> filters);

	@ServiceOperation(name = XPS_OP_NAME_INWPYMTMAPSERVICE_FIND)
	public List<InwPymtMap> find(FindCriteria findCriteria, CbsHeader cbsHeader);

	@ServiceOperation(name = XPS_OP_NAME_INWPYMTMAPSERVICE_CREATE)
	public InwPymtMap create(InwPymtMap dataObject);

	@ServiceOperation(name = XPS_OP_NAME_INWPYMTMAPSERVICE_UPDATE)
	public InwPymtMap update(InwPymtMap dataObject);

	@ServiceOperation(name = XPS_OP_NAME_INWPYMTMAPSERVICE_DELETE)
	public boolean delete(InwPymtMap dataObject);

}
