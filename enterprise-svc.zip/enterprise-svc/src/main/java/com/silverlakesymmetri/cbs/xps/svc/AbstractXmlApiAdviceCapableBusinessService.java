package com.silverlakesymmetri.cbs.xps.svc;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.mail.MessagingException;

import org.apache.velocity.VelocityContext;
import org.springframework.beans.factory.annotation.Autowired;

import com.silverlakesymmetri.cbs.commons.bdo.CbsBusinessDataObject;
import com.silverlakesymmetri.cbs.commons.bdo.sdo.DmsFile;
import com.silverlakesymmetri.cbs.commons.dms.DocumentManagementService;
import com.silverlakesymmetri.cbs.commons.exception.base.CbsServiceProcessException;
import com.silverlakesymmetri.cbs.commons.jpa.entity.CbsBusinessDataObjectJpe;
import com.silverlakesymmetri.cbs.commons.jpa.mapping.sdo.enums.CommunicationChannelEnum;
import com.silverlakesymmetri.cbs.commons.notification.CbsMessageNotificationService;
import com.silverlakesymmetri.cbs.csd.bdo.sdo.SettleMethod;
import com.silverlakesymmetri.cbs.csd.svc.SettleMethodService;
import com.silverlakesymmetri.cbs.mcl.bdo.sdo.Client;
import com.silverlakesymmetri.cbs.pim.svc.MessageKeyService;
import com.silverlakesymmetri.cbs.xps.bdo.sdo.AdvicePreview;
import com.silverlakesymmetri.cbs.xps.bdo.sdo.MessageQOthers;
import com.silverlakesymmetri.cbs.xps.svc.util.CbsDocumentTemplateBuilder;

public abstract class AbstractXmlApiAdviceCapableBusinessService<B extends CbsBusinessDataObject, E extends CbsBusinessDataObjectJpe, ID extends Serializable, XmlApiRq, XmlApiRs>
		extends AbstractXmlApiSwfCapableBusinessService<B, E, ID, XmlApiRq, XmlApiRs> {
	
	@Autowired
	protected SettleMethodService settleMethodService;

	@Autowired
	protected MessageKeyService messageKeyService;
	
	@Autowired
	protected CbsDocumentTemplateBuilder documentTemplateBuilder;

	@Autowired
	protected MessageQOthersService messageQOthersService;
	
	@Autowired 
	protected MessageControlQWrapperService msgQControlWrapperService;

	@Autowired
	protected DocumentManagementService documentmanagementService;

	@Autowired
	protected CbsMessageNotificationService msgNotificationService;
	
	protected abstract MessageQOthers fillContext(Map<String, Object> adviceParams, VelocityContext context);

	public AdvicePreview generateEmailPreview(Map<String, Object> adviceParams) {
		VelocityContext context = new VelocityContext();
		
		String adviceType = "";
		String locale = null;
		String publicKey = null;
		boolean isPreview = true;

		if(adviceParams.get("settleMethod") != null){
			SettleMethod settleMethod = settleMethodService.getByPk(adviceParams.get("settleMethod").toString(), null);
			if(settleMethod == null || !"EMAIL".equals(settleMethod.getRouteDest()) || 
					(settleMethod.getDestClientType() != null && settleMethod.getDestClientType().equals("N"))){
				return null;
			}
			adviceType = settleMethod.getFormat();
		} else {
			return null;
		}
		
		if(adviceParams.get("locale") != null){
			locale = adviceParams.get("locale").toString();
		} 
		if(adviceParams.get("publicKey") != null){
			publicKey = adviceParams.get("publicKey").toString();
		} 
		if(adviceParams.get("isPreview") != null){
			isPreview = Boolean.parseBoolean(adviceParams.get("isPreview").toString());
		}
		
		for (Map.Entry<String, Object> entry : adviceParams.entrySet()){
			if(!entry.getKey().equals("settleMethod") && !entry.getKey().equals("locale") && !entry.getKey().equals("isPreview")){
				context.put(entry.getKey(), entry.getValue());
			}
		}
		MessageQOthers adviceSnapShot = fillContext(adviceParams, context);
		if(adviceSnapShot != null){
			return msgQControlWrapperService.getPreview(adviceSnapShot);
		}
		//this is required in adviceParams
		Client client = (Client) adviceParams.get("Client");
		
		//call template builder
		//TODO: determine if document is islamic in nature
		Map<String, String> messageContext = documentTemplateBuilder.convertTemplateToMessage(adviceType + "Email", context, locale, false);
		DmsFile attachment = documentTemplateBuilder.convertTemplateToDocument(adviceType, context, locale, false, publicKey);
		List<DmsFile> attachments = new ArrayList<DmsFile>();
		attachments.add(attachment);
		
		String mailAddress = "";
		try {
			mailAddress = clientService.getClientElectronicMailAddress(client.getClientNo());
		} catch (CbsServiceProcessException spe) {
			if(!isPreview) throw spe;
			mailAddress = "No defined email address";
		}
		
		//create preview
		AdvicePreview mailPreview = jaxbSdoHelper.createSdoInstance(AdvicePreview.class);
		mailPreview.setRecipients(mailAddress);
		mailPreview.setMsgBody(messageContext.get("message"));
		mailPreview.setSubject(messageContext.get("subject"));
		mailPreview.setAttachments(attachments);
		mailPreview.setDocument(adviceType);

		if(isPreview){
			return mailPreview;
		}

		try {
			msgNotificationService.sendNotificationMessage(CommunicationChannelEnum.MAIL, mailAddress, messageContext.get("subject"), messageContext.get("message"), null, attachments);
		} catch (MessagingException e) {
			msgNotificationService.logFailedNotification(adviceType+"-"+publicKey, CommunicationChannelEnum.MAIL, mailAddress, messageContext.get("subject"), messageContext.get("message"), attachments);
			return null;
		}
		return mailPreview;
	}


	public DmsFile generateAdvice(Map<String, Object> adviceParams) {
		VelocityContext context = new VelocityContext();
		
		String adviceType = "";
		if(adviceParams.get("settleMethod") != null){
			SettleMethod settleMethod = settleMethodService.getByPk(adviceParams.get("settleMethod").toString(), null);
			if(settleMethod.getDestClientType() != null && settleMethod.getDestClientType().equals("N")){
				return null;
			}
			adviceType = settleMethod.getFormat();
		} else {
			return null;
		}
		
		MessageQOthers adviceSnapShot = fillContext(adviceParams, context);
		if(adviceSnapShot != null){
			return documentmanagementService.getDocument(adviceSnapShot.getJcrId(), "messagequeue/documents");
		}

		String locale = null;
		if(adviceParams.get("locale") != null){
			locale = adviceParams.get("locale").toString();
		}
		String publicKey = null;
		if(adviceParams.get("publicKey") != null){
			publicKey = adviceParams.get("publicKey").toString();
		}

		//call template builder
		//TODO: determine if document is islamic in nature
		return documentTemplateBuilder.convertTemplateToDocument(adviceType, context, locale, false, publicKey);
	}

}
