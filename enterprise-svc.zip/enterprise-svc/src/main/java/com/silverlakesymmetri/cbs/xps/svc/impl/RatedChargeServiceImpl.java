package com.silverlakesymmetri.cbs.xps.svc.impl;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Map;

import javax.inject.Inject;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;

import com.mysema.query.types.EntityPath;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.jpa.extension.JaxbSdoHelper;
import com.silverlakesymmetri.cbs.commons.jpa.service.CbsGenericDataService;
import com.silverlakesymmetri.cbs.commons.jpa.service.impl.BusinessDataObjectJpaQueryComponentImpl;
import com.silverlakesymmetri.cbs.commons.svc.AbstractBusinessService;
import com.silverlakesymmetri.cbs.commons.svc.BusinessObjectValidationCapable;
import com.silverlakesymmetri.cbs.commons.svc.ref.ReferenceNumberGeneratorService;
import com.silverlakesymmetri.cbs.commons.svc.util.InMemoryQueryExecutor;
import com.silverlakesymmetri.cbs.csd.svc.CcyConversionService;
import com.silverlakesymmetri.cbs.xps.bdo.sdo.RatedCharge;
import com.silverlakesymmetri.cbs.xps.bdo.sdo.RatedChargeRate;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.RatedChargeJpe;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.util.XpsJpeConstants;
import com.silverlakesymmetri.cbs.xps.svc.RatedChargeService;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.QRatedChargeJpe;

@Service
@Transactional
public class RatedChargeServiceImpl extends AbstractBusinessService<RatedCharge, RatedChargeJpe, String> 
	implements RatedChargeService, BusinessObjectValidationCapable<RatedCharge>{
	
	@Inject
    protected JaxbSdoHelper jaxbSdoHelper;
    @Autowired
    protected CcyConversionService ccyConversionService;
    @Autowired
    private CbsGenericDataService dataService;

    @Autowired
    private ReferenceNumberGeneratorService referenceNumberGeneratorService;
	
	
	@Override
	protected String getIdFromDataObjectInstance(RatedCharge dataObject) {
		return dataObject.getChargeRefNo();
	}

	@Override
	protected EntityPath<RatedChargeJpe> getEntityPath() {
		return QRatedChargeJpe.ratedChargeJpe;
	}
	
	@Override
    public RatedCharge get(RatedCharge objectInstanceIdentifier) {
       
        List<RatedChargeJpe> jpeResult = dataService.findWithNamedQuery(XpsJpeConstants.RATED_CHARGE_JPE_GET_ALL, RatedChargeJpe.class);
        RatedCharge sdo = null;
        for (RatedChargeJpe jpe : jpeResult) {
        	if (jpe.getChargeRefNo().equals(objectInstanceIdentifier.getChargeRefNo())){
        		sdo = jaxbSdoHelper.wrap(jpe, RatedCharge.class);
        	}
        }
        
        return sdo;
    }
	
	@Override
    public List<RatedCharge> query(int offset, int resultLimit, String groupBy, String order, Map<String, Object> filters) {
        List<RatedCharge> sdoResult = getAll();
        FindCriteria fc = jaxbSdoHelper.wrap(BusinessDataObjectJpaQueryComponentImpl.buildFindCriteria(offset, resultLimit, groupBy, order, filters));
        return filterAndSortResult(fc, sdoResult);
    }
	
    @Override
    public RatedCharge create(RatedCharge dataObject) {
    	Defaulting(dataObject);
    	return super.create(dataObject);
    }
    
    @Override
    public RatedCharge update(RatedCharge dataObject) {
    	Defaulting(dataObject);
    	return super.update(dataObject);
    }
    
    @Override
    public boolean delete(RatedCharge dataObject) {
		return super.delete(dataObject);
    }
	

	@Override
	public List<RatedCharge> getAll() {
		List<RatedCharge> sdoResult = new ArrayList<RatedCharge>();
        
        List<RatedChargeJpe> jpeResult = dataService.findWithNamedQuery(XpsJpeConstants.RATED_CHARGE_JPE_GET_ALL, RatedChargeJpe.class);
        
        for (RatedChargeJpe jpe : jpeResult) {
        	if (("R".equals(jpe.getChargeType())) && (("D".equals(jpe.getRateLadder())) || ("E".equals(jpe.getRateLadder()))  || ("F".equals(jpe.getRateLadder())) || ("S".equals(jpe.getRateLadder())) || ("T".equals(jpe.getRateLadder())))) {
        		RatedCharge sdo = jaxbSdoHelper.wrap(jpe, RatedCharge.class);
        		sdoResult.add(sdo);
            }
        }
        
        return sdoResult;
	}
	
	private List<RatedCharge> filterAndSortResult(FindCriteria findCriteria, List<RatedCharge> list) {
        InMemoryQueryExecutor<RatedCharge> inMemQry = new InMemoryQueryExecutor<>(list);
        return inMemQry.executeFilter(findCriteria);
    }
	
	@Override
    protected RatedCharge preCreateValidation(RatedCharge dataObject) {
    	if(null != dataObject){
	    	performDefaulting(dataObject);
	    	if (StringUtils.isEmpty(dataObject.getChargeRefNo())) {
				referenceNumberGeneratorService.getNewRefNo(dataObject, "chargeRefNo");
			}
	        if (dataObject.isUsedYn() == null) {
	            dataObject.setUsedYn(false);
	        }
	        if (dataObject.isActiveYn() == null) {
	            dataObject.setActiveYn(false);
	        }

	        java.util.List<RatedChargeRate> chargeRateList;
			chargeRateList = dataObject.getRatedChargeRateList();
			
			if (null != chargeRateList){
				for ( RatedChargeRate child : chargeRateList){
					if (StringUtils.isEmpty(child.getChargeRefNo())) {
						child.setChargeRefNo(dataObject.getChargeRefNo());
					}				
					if (StringUtils.isEmpty(child.getChargeRateRefNo())) {
						referenceNumberGeneratorService.getNewRefNo(child, "chargeRateRefNo");
					}				
				}
				dataObject.setRatedChargeRateList(chargeRateList);
			}
		}
        return dataObject;
    }
	
	@Override
    protected RatedCharge preUpdateValidation(RatedCharge dataObject) {
    	performDefaulting(dataObject);
		java.util.List<RatedChargeRate> chargeRateList;
		chargeRateList = dataObject.getRatedChargeRateList();
		
		if (null != chargeRateList){
			for ( RatedChargeRate child : chargeRateList){
				if (StringUtils.isEmpty(child.getChargeRefNo())) {
					child.setChargeRefNo(dataObject.getChargeRefNo());
				}				
				if (StringUtils.isEmpty(child.getChargeRateRefNo())) {
					referenceNumberGeneratorService.getNewRefNo(child, "chargeRateRefNo");
				}				
			}
			dataObject.setRatedChargeRateList(chargeRateList);
		}
        return dataObject;
    }
	
	private void performDefaulting(RatedCharge ratedCharge) {
        if (null != ratedCharge) {
			if (null == ratedCharge.getChargeType()) {ratedCharge.setChargeType("R");}
			sortAndDefaultSeqNo(ratedCharge);
        }
    }
	
	private void sortAndDefaultSeqNo(RatedCharge ratedCharge) {
        List<RatedChargeRate> chargeRateList = ratedCharge.getRatedChargeRateList();
		if (chargeRateList!=null && chargeRateList.size() > 0) {
        	
            List<RatedChargeRate> chargeRateSortedByBalanceDays = new ArrayList<RatedChargeRate>(chargeRateList);
            Collections.sort(chargeRateSortedByBalanceDays, new Comparator<RatedChargeRate>() {
                @Override
                public int compare(RatedChargeRate o1, RatedChargeRate o2) {
                    int iResult = 0;
                    Double d1 = o1.getBalance();
                    Double d2 = o2.getBalance();
                    if (d1 != null) {
                        iResult = d1.compareTo(d2);
                    }

                    return iResult;
                }
            });

            for (RatedChargeRate removeTradeChargeRate : chargeRateList) {
            	ratedCharge.getRatedChargeRateList().remove(removeTradeChargeRate);
            }
            
            int seqNo = 1;
            for (RatedChargeRate addTradeChargeRate : chargeRateSortedByBalanceDays) {
            	addTradeChargeRate.setSeqNo(seqNo);
            	ratedCharge.getRatedChargeRateList().add(addTradeChargeRate);
            	seqNo++;
            }

        }
	}   
	
	
	 @Override
	 public List<RatedCharge> find(FindCriteria findCriteria, CbsHeader cbsHeader) {
		 List<RatedCharge> sdoResult = getAll();
	     return filterAndSortResult(findCriteria, sdoResult);
	 }

	 @Override
	 public RatedCharge getByPk(String publicKey, RatedCharge reference) {
		 RatedCharge result = super.getByPk(publicKey, reference);
		 if (null != result && ("R".equals(result.getChargeType())) && (("D".equals(result.getRateLadder())) || ("E".equals(result.getRateLadder()))  || ("F".equals(result.getRateLadder())) || ("S".equals(result.getRateLadder())) || ("T".equals(result.getRateLadder())))) {
			 return result;
		 } else {
			 return null;    			
		 }
	 }

	
	@Override
	public Long count(FindCriteria findCriteria, CbsHeader cbsHeader) {
		List<RatedCharge> sdoResult = getAll();
        return Long.valueOf((long)filterAndSortResult(findCriteria, sdoResult).size());
	}
	
	private void Defaulting(RatedCharge dataObject){
    	if (null != dataObject){
    		//chargeType
    		if (null == dataObject.getChargeType()){
    			dataObject.setChargeType("R");
    		}
    		//userRateConstituents
    		if (null == dataObject.getUseRateConstituents()){
    			dataObject.setUseRateConstituents("N");
    		}
    		//recurring
    		if (null == dataObject.getRecurring()){
    			dataObject.setRecurring("N");
    		}
    		//interestAction
    		if (null == dataObject.getInterestAction()){
    			dataObject.setInterestAction("N");
    		} 
     	}
    }


}
