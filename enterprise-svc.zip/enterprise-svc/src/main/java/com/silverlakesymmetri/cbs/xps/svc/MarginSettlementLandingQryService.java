package com.silverlakesymmetri.cbs.xps.svc;

import java.util.List;
import java.util.Map;

import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation;
import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation.ServiceOperationType;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.svc.BusinessService;
import com.silverlakesymmetri.cbs.xps.bdo.sdo.MarginSettlementLandingQry;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.MarginSettlementLandingQryJpe;

public interface MarginSettlementLandingQryService extends BusinessService<MarginSettlementLandingQry, MarginSettlementLandingQryJpe> {
	public static final String XPS_MARGINSETTLEMENTLANDINGQRYSERVICE_GET = "MarginSettlementLandingQryService.get";
    public static final String XPS_MARGINSETTLEMENTLANDINGQRYSERVICE_QUERY = "MarginSettlementLandingQryService.query";
    public static final String XPS_MARGINSETTLEMENTLANDINGQRYSERVICE_FIND = "MarginSettlementLandingQryService.find";
    public static final String XPS_MARGINSETTLEMENTLANDINGQRYSERVICE_COUNT = "MarginSettlementLandingQryService.count";

    @ServiceOperation(name = XPS_MARGINSETTLEMENTLANDINGQRYSERVICE_GET, type = ServiceOperationType.GET)
    public MarginSettlementLandingQry getByPk(String publicKey, MarginSettlementLandingQry reference);

    @ServiceOperation(name = XPS_MARGINSETTLEMENTLANDINGQRYSERVICE_QUERY)
    public List<MarginSettlementLandingQry> query(int offset, int resultLimit, String groupBy, String order, Map<String, Object> filters);
    
    @ServiceOperation(name = XPS_MARGINSETTLEMENTLANDINGQRYSERVICE_FIND)
    public List<MarginSettlementLandingQry> find(FindCriteria findCriteria, CbsHeader cbsHeader);
    
    @ServiceOperation(name = XPS_MARGINSETTLEMENTLANDINGQRYSERVICE_COUNT, type = ServiceOperationType.GET)
    public Long count(FindCriteria findCriteria, CbsHeader cbsHeader);
}