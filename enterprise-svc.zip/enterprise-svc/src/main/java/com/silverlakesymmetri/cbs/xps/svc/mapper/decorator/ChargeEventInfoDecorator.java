package com.silverlakesymmetri.cbs.xps.svc.mapper.decorator;

import org.mapstruct.Context;
import org.mapstruct.MappingTarget;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

import com.silverlakesymmetri.cbs.commons.xmlapi.enums.CbsXmlApiOperation;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.ChargeEventInfoJpe;
import com.silverlakesymmetri.cbs.xps.svc.mapper.ChargeEventInfoMapper;
import com.silverlakesymmetri.cbs.xps.xmlapi.XPSCHARGEEVENTTYPEType;

public abstract class ChargeEventInfoDecorator implements ChargeEventInfoMapper {
	
	@Autowired
	@Qualifier("delegate")
	protected ChargeEventInfoMapper delegate;

	@Override
	public XPSCHARGEEVENTTYPEType mapToApi(ChargeEventInfoJpe jpe, @Context CbsXmlApiOperation oper){
		XPSCHARGEEVENTTYPEType req = (XPSCHARGEEVENTTYPEType) delegate.mapToApi(jpe, oper);
		return  req;
	}
	
	@Override
	public ChargeEventInfoJpe mapToJpe(XPSCHARGEEVENTTYPEType api, @MappingTarget ChargeEventInfoJpe jpe){
		delegate.mapToJpe(api, jpe);
		return jpe;
	}

}


