package com.silverlakesymmetri.cbs.xps.svc;

import java.util.List;
import java.util.Map;

import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation;
import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation.ServiceOperationType;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.svc.BusinessService;
import com.silverlakesymmetri.cbs.xps.bdo.sdo.Charges;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.ChargesJpe;

public interface ChargesService extends BusinessService<Charges, ChargesJpe> {
	public static final String XPS_CHARGESSERVICE_GET = "ChargesService.get";
    public static final String XPS_CHARGESSERVICE_FIND = "ChargesService.find";
    public static final String XPS_CHARGESSERVICE_QUERY = "ChargesService.query";
    
    @ServiceOperation(name = XPS_CHARGESSERVICE_GET, type = ServiceOperationType.GET)
    public Charges getByPk(String publicKey, Charges reference);

    @ServiceOperation(name = XPS_CHARGESSERVICE_FIND)
    public List<Charges> find(FindCriteria findCriteria, CbsHeader cbsHeader);
    
    @ServiceOperation(name = XPS_CHARGESSERVICE_QUERY)
    public List<Charges> query(int offset, int resultLimit, String groupBy, String order, Map<String, Object> filters);
    
}