package com.silverlakesymmetri.cbs.xps.svc.batch;

import java.io.StringReader;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;

import org.springframework.beans.BeansException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.stereotype.Component;

import com.silverlakesymmetri.cbs.commons.exception.CbsRuntimeException;
import com.silverlakesymmetri.cbs.commons.jpa.extension.JaxbSdoHelper;
import com.silverlakesymmetri.cbs.commons.logging.CbsAppLogger;
import com.silverlakesymmetri.cbs.commons.logging.CbsAppLoggerFactory;

import commonj.sdo.DataObject;

@Component
public class XmlApiBpmTaskResolver implements ApplicationContextAware {
	private static CbsAppLogger logger = CbsAppLoggerFactory.getLogger(XmlApiBpmTaskResolver.class);

	public static String API_CLASS_KEY = "apiClass";
	public static String BDO_CLASS_KEY = "bdoClass";
	public static String MAPPER_BEAN_NAME_KEY = "mapperBeanName";
	public static String SERVICE_NAME_KEY = "serviceName";
	public static String SCREEN_URL_KEY = "screenUrl";
	public static String ACTIVITY_NAME_KEY = "activityName";

	private static ApplicationContext appCtx;
	@SuppressWarnings("rawtypes")
	private static Map<String, XmlApiMapperResolvable> beanMap;
	private static boolean isInitialized = false;

	private static Map<String, Map<String, String>> apiDetailsMap;
	
	private static Pattern API_NAME_PATTERN = Pattern.compile("<(?:\\w)+_API"); //pattern to find the API name from an XML string

	private static final Map<Class<?>, JAXBContext> jaxbContextPool = new HashMap<>();

    @Autowired
    protected JaxbSdoHelper jaxbSdoHelper;

	@Override
	public void setApplicationContext(ApplicationContext applicationContext) throws BeansException {
		appCtx = applicationContext;
	}
	
	@SuppressWarnings({ "rawtypes", "unchecked" })
	public DataObject mapToBdo(String xmlString) {
		init();
		
		Object apiObj = null;
		try {
			 apiObj = convertToApiType(xmlString);			
		} catch (Exception e) {
			logger.error("Cannot retrieve API object!");
			throw new CbsRuntimeException(e);
		}
		
		String apiName = getApiName(xmlString);		
		XmlApiMapperResolvable mapper = getMapper(apiName);
		Object jpe = mapper.mapToJpe(apiObj);

		Class bdoClass = null;
		try {
			bdoClass = getBdoTypeClass(apiName);
		} catch (Exception e) {
			logger.error("Cannot retrieve BDO class!");
			throw new CbsRuntimeException(e);
		}
		
		DataObject bdo = jaxbSdoHelper.wrap(jpe, bdoClass);
		return bdo;
	}

	public String getApiName(String xmlApi) {
		String apiName = null;
        Matcher matcher = API_NAME_PATTERN.matcher(xmlApi);
        if(matcher.find()){
        	apiName = matcher.group(0);
            apiName = apiName.replace("<","");
            apiName = apiName.trim();
        } else {
        	logger.warn("Could not find api name in XML string!");
        	return null;
        }

		return apiName;
	}

	public Map<String, String> getApiDetails(String apiName) {
		init();
		
		if (apiDetailsMap.get(apiName) == null) {
			logger.warn("Api details not found for api name: {}", apiName);
			return null;
		}
		
		return apiDetailsMap.get(apiName);
	}

	/**
	 * Prepares the class before use.<br>
	 * Note:<br>
	 * Synchronized method approach is not used as it causes slow performance as
	 * multiple threads cannot access it simultaneously. Instead, <b>Double
	 * check locking</b> is used. The synchronized block which initializes the
	 * static fields is synchronized so that minimum number of threads have to
	 * wait and that is only for the first time
	 */
	private void init() {
		if (!isInitialized) {
			synchronized (this) {
				if (!isInitialized) {
					beanMap = new ConcurrentHashMap<>();
					initApiDetailsMap();
					isInitialized = true;
				}
			}
		}
	}

	//TODO: it could be better to transfer all this data in svc-context.xml or store them in a mapping table
	private void initApiDetailsMap() {
		apiDetailsMap = new ConcurrentHashMap<>();

		addDetails("TFN_LC_EXP_API", BDO_CLASS_KEY, "com.silverlakesymmetri.cbs.tfn.bdo.sdo.ExportLc");
		addDetails("TFN_LC_EXP_API", API_CLASS_KEY, "com.silverlakesymmetri.cbs.tfn.xmlapi.TFNLCEXPAPIType");
		addDetails("TFN_LC_EXP_API", MAPPER_BEAN_NAME_KEY, "exportLcToTFNLCEXPAPITypeMapperImpl");
		addDetails("TFN_LC_EXP_API", SERVICE_NAME_KEY, "ExportLcService.create");
		addDetails("TFN_LC_EXP_API", SCREEN_URL_KEY, "/trade-workspace/new/trade/detail-screen/export-lc-detail;domain=EXPORTLC");
		addDetails("TFN_LC_EXP_API", ACTIVITY_NAME_KEY, "Export LC Create");

		addDetails("TFN_LC_IMP_API", BDO_CLASS_KEY, "com.silverlakesymmetri.cbs.tfn.bdo.sdo.ImportLc");
		addDetails("TFN_LC_IMP_API", API_CLASS_KEY, "com.silverlakesymmetri.cbs.tfn.xmlapi.TFNLCIMPAPIType");
		addDetails("TFN_LC_IMP_API", MAPPER_BEAN_NAME_KEY, "importLcJpeToTFNLCIMPAPITypeMapperImpl");
		addDetails("TFN_LC_IMP_API", SERVICE_NAME_KEY, "ImportLcService.create");
		addDetails("TFN_LC_IMP_API", SCREEN_URL_KEY, "/trade-workspace/new/trade/detail-screen/import-lc-detail;domain=IMPORTLC");
		addDetails("TFN_LC_IMP_API", ACTIVITY_NAME_KEY, "Import LC Create");
		
		addDetails("GFT_TRANSFERS_INCOMING_API", BDO_CLASS_KEY, "com.silverlakesymmetri.cbs.gft.bdo.sdo.IncomingTransfers");
		addDetails("GFT_TRANSFERS_INCOMING_API", API_CLASS_KEY, "com.silverlakesymmetri.cbs.gft.xmlapi.GFTTRANSFERSINCOMINGAPIType");
		addDetails("GFT_TRANSFERS_INCOMING_API", MAPPER_BEAN_NAME_KEY, "incomingTransfersServiceMapperImpl");
		addDetails("GFT_TRANSFERS_INCOMING_API", SERVICE_NAME_KEY, "IncomingTransfersService.create");
		addDetails("GFT_TRANSFERS_INCOMING_API", SCREEN_URL_KEY, "/workspace/gft/detail-screen/incoming-transfers-detail/new");
		addDetails("GFT_TRANSFERS_INCOMING_API", ACTIVITY_NAME_KEY, "Incoming Transfers Create");

		addDetails("GFT_TRANSFERS_OUTGOING_API", BDO_CLASS_KEY, "com.silverlakesymmetri.cbs.gft.bdo.sdo.OutgoingTransfers");
		addDetails("GFT_TRANSFERS_OUTGOING_API", API_CLASS_KEY, "com.silverlakesymmetri.cbs.gft.xmlapi.GFTTRANSFERSOUTGOINGAPIType");
		addDetails("GFT_TRANSFERS_OUTGOING_API", MAPPER_BEAN_NAME_KEY, "outgoingTransfersServiceMapperImpl");
		addDetails("GFT_TRANSFERS_OUTGOING_API", SERVICE_NAME_KEY, "OutgoingTransfersService.create");
		addDetails("GFT_TRANSFERS_OUTGOING_API", SCREEN_URL_KEY, "/workspace/gft/detail-screen/outgoing-transfers-detail/new");
		addDetails("GFT_TRANSFERS_OUTGOING_API", ACTIVITY_NAME_KEY, "Outgoing Transfers Create");
	}

	private void addDetails(String apiName, String property, String value) {
		if (apiDetailsMap.get(apiName) == null) {
			apiDetailsMap.put(apiName, new ConcurrentHashMap<>());
		}

		Map<String, String> subDetails = apiDetailsMap.get(apiName);
		subDetails.put(property, value);
	}

	@SuppressWarnings("rawtypes")
	private XmlApiMapperResolvable getBean(String beanName) {
		XmlApiMapperResolvable bean = null;

		bean = beanMap.get(beanName);
		if (bean != null) {
			return bean;
		}

		if (bean == null) {
			// get an instance
			synchronized (this) {
				if (null == beanMap.get(beanName)) {
					bean = appCtx.getBean(beanName, XmlApiMapperResolvable.class);
					if (bean != null) {
						beanMap.put(beanName, bean);
					} else {
						logger.warn("Cannot get bean type {} with name {}", XmlApiMapperResolvable.class.getName(),
								beanName);
					}
				}
			}

		}

		return bean;
	}

	private String getBdoType(String apiName) {
		if (apiDetailsMap.get(apiName) == null) {
			logger.warn("Api details not found for api name: {}", apiName);
			return null;
		}

		return apiDetailsMap.get(apiName).get(BDO_CLASS_KEY);
	}
	
	private String getApiType(String apiName) {
		if (apiDetailsMap.get(apiName) == null) {
			logger.warn("Api details not found for api name: {}", apiName);
			return null;
		}
		
		return apiDetailsMap.get(apiName).get(API_CLASS_KEY);
	}

	@SuppressWarnings("rawtypes")
	private XmlApiMapperResolvable getMapper(String apiName) {
		if (apiDetailsMap.get(apiName) == null) {
			logger.warn("Api details not found for api name: {}", apiName);
			return null;
		}

		String beanName = apiDetailsMap.get(apiName).get(MAPPER_BEAN_NAME_KEY);
		return this.getBean(beanName);
	}

	@SuppressWarnings("rawtypes")
	private Class getBdoTypeClass(String apiName) throws Exception {
		String className = getBdoType(apiName);
		if (className == null) {
			logger.warn("BDO className not found for api name: {}", apiName);
		}

		Class bdoClass = null;
		try {
			bdoClass = Class.forName(className);
			return bdoClass;
		} catch (Exception e) {
			logger.warn("Cannot instantiate class for className: {}", className);
		}

		return null;
	}
	
	@SuppressWarnings("rawtypes")
	private Class getApiTypeClass(String apiName) throws Exception {
		String className = getApiType(apiName);
		if (className == null) {
			logger.warn("API className not found for api name: {}", apiName);
		}
		
		Class apiClass = null;
		try {
			apiClass = Class.forName(className);
			return apiClass;
		} catch (Exception e) {
			logger.warn("Cannot instantiate class for className: {}", className);
		}
		
		return null;
	}

	@SuppressWarnings("rawtypes")
	private Object convertToApiType(String xmlString) throws Exception {
		String apiName = getApiName(xmlString);

		Class apiClass = null;
		try {
			apiClass = getApiTypeClass(apiName);
		} catch (Exception e) {
			throw new CbsRuntimeException(e);
		}

		JAXBContext jaxbContext = getJAXBContextFromPool(apiClass);
		Unmarshaller unmarshaller = jaxbContext.createUnmarshaller();
		StringReader reader = new StringReader(xmlString);
		Object apiObj = unmarshaller.unmarshal(reader);

		return apiClass.cast(apiObj);
	}

	private JAXBContext getJAXBContextFromPool(Class<?> responseClass) throws JAXBException {
		JAXBContext jCtx = jaxbContextPool.get(responseClass);
		if (jCtx == null) {
			synchronized (jaxbContextPool) {
				jCtx = jaxbContextPool.get(responseClass);
				if (jCtx == null) {
					jCtx = JAXBContext.newInstance(responseClass);
					jaxbContextPool.put(responseClass, jCtx);
				}
			}
		}
		return jCtx;
	}
}
