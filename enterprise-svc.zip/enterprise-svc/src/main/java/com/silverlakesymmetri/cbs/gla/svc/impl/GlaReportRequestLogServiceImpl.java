package com.silverlakesymmetri.cbs.gla.svc.impl;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.ResourceBundle;
import java.util.concurrent.ConcurrentHashMap;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.mysema.query.types.EntityPath;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.bdo.sdo.BpmWorkItem;
import com.silverlakesymmetri.cbs.commons.bdo.sdo.ReportRequestLog;
import com.silverlakesymmetri.cbs.commons.bpm.constants.BpmConstants;
import com.silverlakesymmetri.cbs.commons.bpm.svc.BpmService;
import com.silverlakesymmetri.cbs.commons.constants.ReportConstants;
import com.silverlakesymmetri.cbs.commons.jpa.mapping.sdo.QReportRequestLogJpe;
import com.silverlakesymmetri.cbs.commons.jpa.mapping.sdo.RegistryJpe;
import com.silverlakesymmetri.cbs.commons.jpa.mapping.sdo.ReportRequestLogJpe;
import com.silverlakesymmetri.cbs.commons.jpa.mapping.sdo.id.ReportRequestLogPk;
import com.silverlakesymmetri.cbs.commons.svc.AbstractReportRequestLogService;
import com.silverlakesymmetri.cbs.csd.gla.jpa.mapping.sdo.ChartAccountJpe;
import com.silverlakesymmetri.cbs.csd.jpa.mapping.sdo.util.CsdJpeConstants;
import com.silverlakesymmetri.cbs.gla.jpa.mapping.sdo.ManualBatchDtlJpe;
import com.silverlakesymmetri.cbs.gla.jpa.mapping.sdo.ManualBatchHdrJpe;
import com.silverlakesymmetri.cbs.gla.svc.GlaReportRequestLogService;

import net.sf.jasperreports.engine.data.JRBeanCollectionDataSource;

@Service
@Transactional
public class GlaReportRequestLogServiceImpl extends AbstractReportRequestLogService<ReportRequestLog, ReportRequestLogJpe, ReportRequestLogPk> implements GlaReportRequestLogService {
    private static final String MANUAL_BATCH_VOUCHER_REPORT_ID = "glara11b";
    private static final String MANUAL_BATCH_SERVICE_OPERATION = "manualBatchService.create";
    private static final String VALUE_DATE_FROM = "VALUE_DATE_FROM";
    private static final String VALUE_DATE_TO = "VALUE_DATE_TO";
    private static final String BATCH_DATE_FROM = "BATCH_DATE_FROM";
    private static final String BATCH_DATE_TO = "BATCH_DATE_TO";
    private static final String CAPTURED_BY = "CAPTURED_BY";
    private static final String BATCH_NO = "BATCH_NO";

    @Autowired
    private BpmService bpmService;

	@Override
	protected ReportRequestLogPk getIdFromDataObjectInstance(ReportRequestLog dataObject) {
		ReportRequestLogPk id = new ReportRequestLogPk(dataObject.getReportId(), dataObject.getRequestedBy(), dateHelper.getDate(dataObject.getRequestDate()));
		return id;
	}

	@Override
	protected EntityPath<ReportRequestLogJpe> getEntityPath() {
		return QReportRequestLogJpe.reportRequestLogJpe;
	}

	@Override
    public ReportRequestLog getByPk(String publicKey, ReportRequestLog reference) {
    	return super.getByPk(publicKey, reference);
    }

	@Override
    public ReportRequestLog create(ReportRequestLog dataObject) {
		return super.create(dataObject);
    }

	@Override
    public ReportRequestLog update(ReportRequestLog dataObject) {
		return super.update(dataObject);
    }

	@Override
    public boolean delete(ReportRequestLog dataObject) {
		return super.delete(dataObject);
    }

	@Override
    public List<ReportRequestLog> query(int offset, int resultLimit, String groupBy, String order, Map<String, Object> filters){
		return super.query(offset, resultLimit, groupBy, order, filters);
    }

	@Override
    public List<ReportRequestLog> find(FindCriteria findCriteria, CbsHeader cbsHeader){
		return super.find(findCriteria, cbsHeader);
    }

	@Override
    public InputStream getReportStream(String screenPath) {
    	return getClass().getClassLoader().getResourceAsStream(screenPath);
    }
	
	@Override
	public void addModuleRelatedParameters(Map<String, Object> reportParams) {
		Map<String, RegistryJpe> registries = registryService.getMapByMetaCodeModuleCode("CSD", "CORE_REGISTRY");
		if(registries != null && registries.size() > 0) {
			RegistryJpe reg = registries.get("localCcy");
			if(reg != null) {
				reportParams.put(ReportConstants.LOCAL_CCY, reg.getValue());
			}
			reg = registries.get("ccyBase");
			if(reg != null) {
				reportParams.put(ReportConstants.BASE_CCY, reg.getValue());
			}
		}

        Locale locale = (Locale) reportParams.get(ReportConstants.REPORT_LOCALE);
        ResourceBundle bundle = ResourceBundle.getBundle(ReportConstants.GLA_RESOURCE_BUNDLE_LOCATION, locale);
		if(Boolean.TRUE.equals(reportParams.get("isIslamicUserSession")) && sessionCtx.isIslamicConfigOn()){
			bundle = ResourceBundle.getBundle(ReportConstants.GLA_ISL_RESOURCE_BUNDLE_LOCATION, locale);
		}
        reportParams.put(ReportConstants.REPORT_RESOURCE_BUNDLE, bundle);

        String reportId = (String) reportParams.get(ReportConstants.REPORT_ID);
        if(MANUAL_BATCH_VOUCHER_REPORT_ID.equals(reportId)){
            handleManualBatchVoucher(reportParams);
        }
	}

    private void handleManualBatchVoucher(Map<String, Object> reportParams) {
        Date valueDateFrom = (Date) reportParams.get(VALUE_DATE_FROM);
        Date valueDateTo = (Date) reportParams.get(VALUE_DATE_TO);
        Date batchDateFrom = (Date) reportParams.get(BATCH_DATE_FROM);
        Date batchDateTo = (Date) reportParams.get(BATCH_DATE_TO);
        List<String> capturedBy = (List<String>) reportParams.get(CAPTURED_BY);
        String batchNo = (String) reportParams.get(BATCH_NO);
        List<String> batchNoList = null;
        if(batchNo != null){
            String[] batchNoArray = batchNo.split(",");
            batchNoList = Arrays.asList(batchNoArray);
            reportParams.put(BATCH_NO, batchNoList);
        }
        Map<String, String> glCodeMap = new HashMap<>();
		glCodeMap.clear();
        List<ChartAccountJpe> list = dataService.findWithNamedQuery(CsdJpeConstants.CHART_ACCOUNT_JPE_LOV, ChartAccountJpe.class);
        if (list != null) {
        	for (Object o : list) {
        		Object[] objArr = (Object[]) o;
        		try { glCodeMap.put((String)objArr[0], (String)objArr[1]); } catch (Exception e) {}
        	}
        }

        List<BpmWorkItem> bpmItems = bpmService.getUnapprovedByServiceOperation(MANUAL_BATCH_SERVICE_OPERATION);
        List<ManualBatchHdrJpe> data = new ArrayList<>();
        boolean addData = true;
        for (BpmWorkItem bpmWorkItem : bpmItems) {
            ConcurrentHashMap<String, Object> map = bpmService.getProcessDataMapFromDB(bpmWorkItem.getProcInstanceId());
            Object rawData = map.get(BpmConstants.REQUEST);
            if(rawData == null){
                continue;
            }
            ManualBatchHdrJpe jpe = (ManualBatchHdrJpe) rawData;
            boolean valueDateFromCriteriaMet = true;
            boolean valueDateToCriteriaMet = true;
            boolean batchDateFromCriteriaMet = true;
            boolean batchDateToCriteriaMet = true;
            boolean capturedByCriteriaMet = true;
            boolean batchNoCriteriaMet = true;
            if(valueDateFrom != null && jpe.getValueDate() != null && valueDateFrom.compareTo(jpe.getValueDate()) > 0) {
                valueDateFromCriteriaMet = false;
            } else if(valueDateFrom != null && jpe.getValueDate() == null){
                valueDateFromCriteriaMet = false;
            }
            if(valueDateTo != null && jpe.getValueDate() != null && valueDateTo.compareTo(jpe.getValueDate()) < 0) {
                valueDateToCriteriaMet = false;
            } else if(valueDateTo != null && jpe.getValueDate() == null){
                valueDateToCriteriaMet = false;
            }
            if(batchDateFrom != null && jpe.getBatchDate() != null && batchDateFrom.compareTo(jpe.getBatchDate()) > 0) {
                batchDateFromCriteriaMet = false;
            } else if(batchDateFrom != null && jpe.getBatchDate() == null){
                batchDateFromCriteriaMet = false;
            }
            if(batchDateTo != null && jpe.getBatchDate() != null &&  batchDateTo.compareTo(jpe.getBatchDate()) < 0) {
                batchDateToCriteriaMet = false;
            } else if(batchDateTo != null && jpe.getBatchDate() == null){
                batchDateToCriteriaMet = false;
            }
            if(capturedBy != null && !capturedBy.isEmpty() && !capturedBy.contains(bpmWorkItem.getCurrentUser())){
                capturedByCriteriaMet = false;
            }
            if(batchNoList != null && !batchNoList.contains(jpe.getBatchNo())){
                batchNoCriteriaMet = false;
            }

            addData = valueDateFromCriteriaMet && valueDateToCriteriaMet && batchDateFromCriteriaMet && batchDateToCriteriaMet
                    && capturedByCriteriaMet && batchNoCriteriaMet;
            if(addData) {
                if (jpe.getManualbatchDetailList() != null) {
                	for (ManualBatchDtlJpe manualBatchDtl : jpe.getManualbatchDetailList()) {
                		try { manualBatchDtl.setGlCodeDesc(glCodeMap.get(manualBatchDtl.getGlCode())); } catch (Exception e) {}
                	}
                }
                data.add(jpe);
            }
        }
        for(ManualBatchHdrJpe jpe: data) {
        	Collections.sort(jpe.getManualbatchDetailList(), Comparator.comparing(ManualBatchDtlJpe::getItemNo).thenComparing(ManualBatchDtlJpe::getBranch).thenComparing(ManualBatchDtlJpe::getCcy));
        }
        JRBeanCollectionDataSource dataSource = new JRBeanCollectionDataSource(data);
        reportParams.put(ReportConstants.JASPER_DATA_SOURCE, dataSource);
    }

	@Override
	public String getModuleCode() {
		return "GLA";
	}

	@Override
	public ReportRequestLog start(Map<String, Object> params) {
		return super.start(params);
	}

	@Override
	public ReportRequestLog createRequest(Map<String, Object> params) {
		return super.generate(params);
	}

}
