package com.silverlakesymmetri.cbs.xps.svc.impl;

import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import javax.mail.MessagingException;
import javax.persistence.PersistenceException;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.apache.commons.lang3.tuple.Pair;
import org.springframework.beans.BeansException;
import org.springframework.beans.factory.NoUniqueBeanDefinitionException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.mysema.query.types.EntityPath;
import com.silverlakesymmetri.cbs.commons.bdo.sdo.DmsFile;
import com.silverlakesymmetri.cbs.commons.context.CbsSessionContext;
import com.silverlakesymmetri.cbs.commons.dms.DocumentManagementService;
import com.silverlakesymmetri.cbs.commons.exception.CbsRuntimeException;
import com.silverlakesymmetri.cbs.commons.exception.base.CbsServiceException;
import com.silverlakesymmetri.cbs.commons.jpa.mapping.sdo.RegistryJpe;
import com.silverlakesymmetri.cbs.commons.jpa.mapping.sdo.enums.CommunicationChannelEnum;
import com.silverlakesymmetri.cbs.commons.jpa.mapping.sdo.id.RegistryPk;
import com.silverlakesymmetri.cbs.commons.logging.CbsAppLogger;
import com.silverlakesymmetri.cbs.commons.logging.CbsAppLoggerFactory;
import com.silverlakesymmetri.cbs.commons.notification.CbsMessageNotificationService;
import com.silverlakesymmetri.cbs.commons.svc.AbstractXmlApiBusinessService;
import com.silverlakesymmetri.cbs.commons.svc.BusinessObjectValidationCapable;
import com.silverlakesymmetri.cbs.commons.svc.CbsUiMessenger;
import com.silverlakesymmetri.cbs.commons.svc.html5ui.impl.EventSourceDetail;
import com.silverlakesymmetri.cbs.commons.svc.util.CbsAsychronousTask;
import com.silverlakesymmetri.cbs.commons.svc.util.CbsAsychronousTaskSupport;
import com.silverlakesymmetri.cbs.commons.xmlapi.enums.CbsXmlApiOperation;
import com.silverlakesymmetri.cbs.xps.bdo.sdo.AdvicePreview;
import com.silverlakesymmetri.cbs.xps.bdo.sdo.MessageControlQWrapper;
import com.silverlakesymmetri.cbs.xps.bdo.sdo.MessageQ;
import com.silverlakesymmetri.cbs.xps.bdo.sdo.MessageQOthers;
import com.silverlakesymmetri.cbs.xps.enums.XpsGlobalConstants;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.MessageControlQWrapperJpe;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.MessageQJpe;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.MessageRepoJpe;
import com.silverlakesymmetri.cbs.xps.svc.MessageControlQWrapperService;
import com.silverlakesymmetri.cbs.xps.svc.util.MessageQueueUtil;
import com.silverlakesymmetri.cbs.xps.xmlapi.XPSMESSAGEQKEYLISTTYPEType;
import com.silverlakesymmetri.cbs.xps.xmlapi.XPSMESSAGEQSTATUSUPDATEAPIType;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.QMessageControlQWrapperJpe;

@Service
@Transactional
public class MessageControlQWrapperServiceImpl extends
		AbstractXmlApiBusinessService<MessageControlQWrapper, MessageControlQWrapperJpe, String, XPSMESSAGEQSTATUSUPDATEAPIType, XPSMESSAGEQSTATUSUPDATEAPIType>
		implements ApplicationContextAware, MessageControlQWrapperService, BusinessObjectValidationCapable<MessageControlQWrapper> {

	private CbsAppLogger logger = CbsAppLoggerFactory.getLogger(MessageControlQWrapperServiceImpl.class.getName());
	private static final String ATTR_SPOOL_DIR = "spoolDirectory";	
	private static final String STATUS_SENT = "S";
	private static final String STATUS_FAIL = "F";
	private static final String USER_EVENT = "user-event";
	private static final String CROSS_MODULE_REGISTRY = "CROSS_MODULE_REGISTRY";
	
    private ApplicationContext applicationContext;
    private CbsUiMessenger cbsUiMessenger;

	@Autowired
	DocumentManagementService dmsService;
	
	@Autowired
	CbsMessageNotificationService msgNotificationService;
	
    @Autowired
    CbsAsychronousTaskSupport _asynchTaskSupport;
    
    @Autowired
    MessageQueueUtil messageQueueUtil;
    
	@Override
	public void setApplicationContext(ApplicationContext applicationContext) throws BeansException {
		this.applicationContext = applicationContext;
	}

	@SuppressWarnings("unchecked")
	@Override
	public MessageControlQWrapper updateStatus(MessageControlQWrapper dataObject) {
		MessageControlQWrapper bdo = this.update(dataObject); 		
		return bdo;
	}

	@Override
	protected XPSMESSAGEQSTATUSUPDATEAPIType transformBdoToXmlApiRqCreate(MessageControlQWrapper dataObject) {
		throw new CbsServiceException("Create operation is not allowed in this service!");
	}

	@Override
	protected XPSMESSAGEQSTATUSUPDATEAPIType transformBdoToXmlApiRqUpdate(MessageControlQWrapper bdo) {
		MessageControlQWrapperJpe jpe = this.jaxbSdoHelper.unwrap(bdo, MessageControlQWrapperJpe.class);
		
		if(jpe.getInternalKeyList().isEmpty()) {
			logger.warn("List is empty. Nothing to update!");
		}
		
		List<Double> keyList = jpe.getInternalKeyList().stream().map(Double::valueOf).collect(Collectors.toList());
		
		XPSMESSAGEQKEYLISTTYPEType listType = new XPSMESSAGEQKEYLISTTYPEType();
		listType.getNUMBER().addAll(keyList);
		
		XPSMESSAGEQSTATUSUPDATEAPIType api = new XPSMESSAGEQSTATUSUPDATEAPIType();
		api.setSTATUS(bdo.getStatus());
		api.setINTERNALKEYS(listType);
		api.setOPERATION(CbsXmlApiOperation.UPDATE.getOperation());
		
		return api;
	}

	@Override
	protected XPSMESSAGEQSTATUSUPDATEAPIType transformBdoToXmlApiRqDelete(MessageControlQWrapper dataObject) {
		throw new CbsServiceException("Delete operation is not allowed in this service!");
	}

	@Override
	protected MessageControlQWrapper processXmlApiRs(MessageControlQWrapper dataObject,
			XPSMESSAGEQSTATUSUPDATEAPIType xmlApiRs) {
		return dataObject;
	}

	@Override
	protected List<MessageControlQWrapper> processXmlApiListRs(MessageControlQWrapper dataObject,
			XPSMESSAGEQSTATUSUPDATEAPIType xmlApiRs) {
		return null;
	}

	@Override
	protected Class<XPSMESSAGEQSTATUSUPDATEAPIType> getXmlApiResponseClass() {
		return XPSMESSAGEQSTATUSUPDATEAPIType.class;
	}

	@Override
	protected String getIdFromDataObjectInstance(MessageControlQWrapper dataObject) {
		return dataObject.getStatus();
	}

	@Override
	protected EntityPath<MessageControlQWrapperJpe> getEntityPath() {
		return QMessageControlQWrapperJpe.messageControlQWrapperJpe;
	}

	@Override
	public AdvicePreview getPreview(MessageQOthers bdo) {
		if (bdo == null) {
			logger.warn("bdo is null. Exit method.");
			return null;
		}
		
		if(StringUtils.isBlank(bdo.getDestAddress())){
			logger.warn("Address is blank!");
			//return null;
		}
		
		//retrieve subject & message body
		Pair<String, String> subjectBody = messageQueueUtil.getSubjectAndBody(bdo.getInternalKey());
		if(subjectBody == null){
			throw new CbsServiceException("Advice content cannot be found.");
		}
		
		String subject = subjectBody.getLeft();
		String msgBody = subjectBody.getRight();
		
		//retrieve file using jcrId
		List<DmsFile> attachmentList = new ArrayList<>();
		DmsFile dmsFile = getFile(bdo.getJcrId());
		if (dmsFile != null) {
			attachmentList.add(dmsFile);
		}

		AdvicePreview mailPreview = jaxbSdoHelper.createSdoInstance(AdvicePreview.class);
		mailPreview.setRecipients(bdo.getDestAddress());
		mailPreview.setMsgBody(msgBody);
		mailPreview.setSubject(subject);
		mailPreview.setAttachments(attachmentList);

		return mailPreview;
	}

	@Override
	public DmsFile getFile(String jcrId) {
		return messageQueueUtil.getFile(jcrId);
	}

	@Override
	public Boolean sendEmail(MessageQOthers bdo) {
		if (bdo == null) {
			logger.warn("bdo is null. Exit method.");
			return false;
		}
		if (bdo.getInternalKey() == null) {
			logger.warn("internalKey is null. Exit method.");
			return false;
		}

		//(new MessageQueueAsyncServiceImpl()).sendEmailAsync(bdo);
		this.doSendEmail(bdo);
		return true;
	}

	@Override
	public Boolean spoolFile(MessageQOthers bdo) {
		if (bdo == null) {
			logger.warn("bdo is null. Exit method.");
			return false;
		}
		if(StringUtils.isBlank(bdo.getJcrId())){
			logger.warn("jrcId is empty. Exit Method!");
			return false;
		}
		
		//String dir = messageQueueUtil.getXpsSpoolDir();
		//(new MessageQueueAsyncServiceImpl()).spoolFileAsync(bdo, dir);
		this.doSpoolFile(bdo, null);
		return true;
	}

	@Override
	public String getSwiftMessage(Long relInternalKey) {
		String qString = "select e from MessageRepoJpe e where e.relInternalKey = :relInternalKey";
		Map<String, Object> params = Collections.singletonMap("relInternalKey", relInternalKey);
		List<MessageRepoJpe> jpeList = dataService.findWithQuery(qString, MessageRepoJpe.class, params, null);

		if (jpeList != null && !jpeList.isEmpty()) {
			MessageRepoJpe jpe = jpeList.get(0);
			String retVal = jpe.getDetailsXmlChar(); 
			return retVal;
		} else {
			logger.warn("MessageRepoJpe not found for: {}", relInternalKey);
		}

		return null;
	}
	
	@Override
	public String getFormattedMessageForPreview(Long relInternalKey, String module, String format, String sender, String receiver){
		String qString = "select e from MessageRepoJpe e where e.relInternalKey = :relInternalKey";
		Map<String, Object> params = Collections.singletonMap("relInternalKey", relInternalKey);
		List<MessageRepoJpe> jpeList = dataService.findWithQuery(qString, MessageRepoJpe.class, params, null);

		if (jpeList != null && !jpeList.isEmpty()) {
			MessageRepoJpe jpe = jpeList.get(0);
			String retVal = jpe.getDetailsXmlChar(); 
			retVal = retVal.replaceAll("<SWF_OUT_MESSAGE_TYPE>", "");
			retVal = retVal.replaceAll("</SWF_OUT_MESSAGE_TYPE>", "");
			retVal = retVal.replaceAll("<SWF_OUT_MAIN_MESSAGE_TYPE>", "");
			retVal = retVal.replaceAll("</SWF_OUT_MAIN_MESSAGE_TYPE>", "");
			
			StringBuilder formattedSwift = new StringBuilder("<XPS_SWF_PREVIEW_API>");
		    formattedSwift.append("<MODULE_ID>" + module + "</MODULE_ID>");
		    formattedSwift.append("<MESSAGE_DEFINITION>");
		    formattedSwift.append("<FORMAT>" + format + "</FORMAT>");
		    formattedSwift.append("</MESSAGE_DEFINITION>");
		    formattedSwift.append("<MESSAGES>");
		    if(retVal.indexOf("<SENDER/>") > 0){
		    	retVal = retVal.replaceAll("<SENDER/>", "");
		    	formattedSwift.append("<SENDER>" + sender + "</SENDER>");
		    }
		    if(retVal.indexOf("<RECEIVER/>") > 0){
		    	retVal = retVal.replaceAll("<RECEIVER/>", "");
		    	formattedSwift.append("<RECEIVER>" + receiver + "</RECEIVER>");
		    }
		    formattedSwift.append(retVal);
		    formattedSwift.append("</MESSAGES>");
		    formattedSwift.append("</XPS_SWF_PREVIEW_API>");
			return formattedSwift.toString();
		} else {
			logger.warn("MessageRepoJpe not found for: {}", relInternalKey);
		}

		return null;
	}

    private CbsUiMessenger getCbsUiMessenger() {
        if (cbsUiMessenger == null) {
            try {
                cbsUiMessenger = applicationContext.getBean(CbsUiMessenger.class);
            } catch (NoUniqueBeanDefinitionException nubde) {
                Map<String, CbsUiMessenger> svcMap = applicationContext.getBeansOfType(CbsUiMessenger.class);
                if (svcMap != null && !svcMap.isEmpty()) {
                    cbsUiMessenger = svcMap.values().iterator().next();
                }
            } catch (BeansException e) {
                // do nothing
            }
        }
        return cbsUiMessenger;
    }
	
	private void sendPushNotificationMsg(String msg){
		EventSourceDetail eventSourceDetail = new EventSourceDetail();
		eventSourceDetail.setEventData(msg);
		eventSourceDetail.setEventName(USER_EVENT);
		
		CbsSessionContext sessionCtx = cbsRuntimeContextManager.getContext(CbsSessionContext.class);
		getCbsUiMessenger().sendToUserChannel(sessionCtx.getUserCode(), CbsUiMessenger.DEFAULT_CHANNEL, eventSourceDetail);		
	}

	/*private class MessageQueueAsyncServiceImpl{
		public void spoolFileAsync(MessageQOthers bdo, String dir){
			_asynchTaskSupport.executeNoWait(new CbsAsychronousTask<Boolean>() {
                @Override
                public Boolean run() {
                    try {
                    	boolean retVal = false;
                        retVal = doSpoolFile(bdo, dir);
                        return retVal;
                    } catch (Exception e) {
                    	e.printStackTrace();
                        throw new CbsRuntimeException(e);
                    }
                }
                @Override
                public String getTaskName() {
                    return "MessageQueueAsync.spoolFileAsync()";
                }
            });
		}
		public void sendEmailAsync(MessageQOthers bdo){
			_asynchTaskSupport.executeNoWait(new CbsAsychronousTask<Boolean>() {
				@Override
				public Boolean run() {
					try {
						boolean retVal = false;
						retVal = doSendEmail(bdo);
						return retVal;
					} catch (Exception e) {
						e.printStackTrace();
						throw new CbsRuntimeException(e);
					}
				}
				@Override
				public String getTaskName() {
					return "MessageQueueAsync.sendEmailAsync()";
				}
			});
		}
	}*/
	
	private Boolean doSpoolFile(MessageQOthers bdo, String dir){
		MessageQJpe qJpe = this.dataService.find(MessageQJpe.class, bdo.getInternalKey());
		
		boolean spoolSuccess = false;
		Exception spoolEx = null;
		try {
			messageQueueUtil.spoolFile(qJpe, dir);
			spoolSuccess = true;
		} catch (Exception e) {
			logger.error("Error encountered when spooling for internalKey: {}", qJpe.getInternalKey());
			spoolEx = e;
			spoolSuccess = false;
		}
		
		String pushMsg = null;
		try {
			if(spoolSuccess){
				qJpe.setStatus(STATUS_SENT);
				qJpe.setDateSent(dateTimeHelper.getRunDateWithTime());
				qJpe.setErrorDetails(null);
			}else{
				String errorDetails = ExceptionUtils.getStackTrace(spoolEx);
				errorDetails = StringUtils.substring(errorDetails, 0, 1000); 
				qJpe.setStatus(STATUS_FAIL);
				qJpe.setDateSent(null);
				qJpe.setErrorDetails(errorDetails);
			}
			
			//*************************************************************************************//
			//** MessageQService does not accept updates                                          *//
			//** ORA-06550: line 1, column 410:PLS-00302: component 'DO_UPDATE' must be declared  *//
			//** Use direct update of entity instead.                                             *//
			//*************************************************************************************//
			this.dataService.update(qJpe);
		} catch (Exception e) {
			e.printStackTrace();
			pushMsg = "Failed to update MessageQ with internalKey: " + qJpe.getInternalKey();
			sendPushNotificationMsg(pushMsg);
			return false;
		}
		
		try {
			if(!spoolSuccess){				
				pushMsg = "File creation failed for " + bdo.getInternalKey();
				sendPushNotificationMsg(pushMsg);
				return false;
			}else{
				pushMsg = "File successfully created for " + bdo.getInternalKey();
				sendPushNotificationMsg(pushMsg);				
				return true;
			}
		} catch (Exception e) {
			logger.error("Error encountered while trying to send push notification!");
			e.printStackTrace();
		}
		
		return false;
	}
	
	private Boolean doSendEmail(MessageQOthers bdo) {
		MessageQJpe qJpe = this.dataService.find(MessageQJpe.class, bdo.getInternalKey());
		
		boolean sendingSuccess = false;
		Exception emailEx = null;
		try {
			this.messageQueueUtil.sendEmail(qJpe);
			sendingSuccess = true;
		} catch (Exception e) {
			logger.error("Error encountered while sending email!");
			sendingSuccess = false;
			emailEx = e;
		}

		String pushMsg = null;
		try {
			if(sendingSuccess){
				qJpe.setStatus(STATUS_SENT);
				qJpe.setDateSent(dateTimeHelper.getRunDateWithTime());
				qJpe.setErrorDetails(null);
			} else {
				String errorDetails = ExceptionUtils.getStackTrace(emailEx);
				errorDetails = StringUtils.substring(errorDetails, 0, 1000);
				qJpe.setStatus(STATUS_FAIL);
				qJpe.setDateSent(null);
				qJpe.setErrorDetails(errorDetails);
			}
			
			//*************************************************************************************//
			//** MessageQService does not accept updates                                          *//
			//** ORA-06550: line 1, column 410:PLS-00302: component 'DO_UPDATE' must be declared  *//
			//** Use direct update of entity instead.                                             *//
			//*************************************************************************************//
			this.dataService.update(qJpe); 
		} catch (Exception e) {
			e.printStackTrace();
			pushMsg = "Failed to update MessageQ with internalKey: " + qJpe.getInternalKey();
			sendPushNotificationMsg(pushMsg);
			return false;
		}

		try {
			if(!sendingSuccess){
				pushMsg = "Failed to send email to " + bdo.getDestAddress();
				sendPushNotificationMsg(pushMsg);
				return false;
			} else {
				pushMsg = "Email successfully sent to "+ bdo.getDestAddress();
				sendPushNotificationMsg(pushMsg);
				return true;
			}
		} catch (Exception e) {
			logger.error("Error encountered while trying to send push notification!");
			e.printStackTrace();
		}

		return false;
	}
		
	@Override
	protected void updateVirtualAttributes(MessageControlQWrapperJpe originalJpe, MessageControlQWrapperJpe updatedJpe) {
		try {
			super.updateVirtualAttributes(originalJpe, updatedJpe);			
		} catch (PersistenceException pe) {
			// swallow NPE for virtual attributes
			//javax.persistence.PersistenceException: java.lang.NullPointerException&#xd;
			//at org.eclipse.persistence.internal.jpa.EntityManagerFactoryDelegate.getIdentifier(EntityManagerFactoryDelegate.java:730)&#xd;
			//at com.silverlakesymmetri.cbs.commons.jpa.service.CbsJpaBaseService.getIdentifier(CbsJpaBaseService.java:158)&#xd;
			//at com.silverlakesymmetri.cbs.commons.jpa.service.CbsJpaDataService.getIdentifier(CbsJpaDataService.java:34)&#xd;
			//at com.silverlakesymmetri.cbs.commons.jpa.service.CbsEntityMetaDataServiceImpl.getIdentifier(CbsEntityMetaDataServiceImpl.java:21)&#xd;
			//at com.silverlakesymmetri.cbs.commons.jpa.util.BdoHelperJpaImpl.createPublicKey(BdoHelperJpaImpl.java:131)&#xd;
			//at com.silverlakesymmetri.cbs.commons.svc.util.BdoHelperImpl.createPublicKey(BdoHelperImpl.java:85)&#xd;
			//at com.silverlakesymmetri.cbs.commons.jpa.util.BdoHelperJpaImpl.getBdoPublicKey(BdoHelperJpaImpl.java:189)&#xd;
			//at com.silverlakesymmetri.cbs.commons.jpa.metadata.VirtualAttributeManager$VirtualAttributeBdoVisitor.visitBdoInstance(VirtualAttributeManager.java:1092)&#xd;
			//at com.silverlakesymmetri.cbs.commons.jpa.util.visitor.AbstractBdoVisitor.visitInternal(AbstractBdoVisitor.java:175)&#xd;
			//at com.silverlakesymmetri.cbs.commons.jpa.util.visitor.AbstractBdoVisitor.visit(AbstractBdoVisitor.java:118)&#xd;
			//at com.silverlakesymmetri.cbs.commons.jpa.metadata.VirtualAttributeManager.processVirtualAttributes(VirtualAttributeManager.java:386)&#xd;
			//at com.silverlakesymmetri.cbs.commons.jpa.service.CbsGenericDataServiceImpl.updateVirtualAttributes(CbsGenericDataServiceImpl.java:114)&#xd;
			//at com.silverlakesymmetri.cbs.commons.jpa.service.CbsXmlApiDataServiceImpl.updateVirtualAttributes(CbsXmlApiDataServiceImpl.java:19)&#xd;
			//at com.silverlakesymmetri.cbs.commons.svc.AbstractXmlApiBusinessService.updateVirtualAttributes(AbstractXmlApiBusinessService.java:228)&#xd;
			
			pe.printStackTrace();
			if ("java.lang.NullPointerException".equals(pe.getMessage())) {
				logger.warn("error in updateVirtualAttributes:" + pe.getMessage());
			} else {
				throw pe;
			}
		}
	}

}