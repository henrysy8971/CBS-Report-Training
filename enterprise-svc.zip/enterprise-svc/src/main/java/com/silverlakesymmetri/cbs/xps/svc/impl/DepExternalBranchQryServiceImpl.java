package com.silverlakesymmetri.cbs.xps.svc.impl;

import com.mysema.query.types.EntityPath;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.svc.AbstractBusinessService;
import com.silverlakesymmetri.cbs.xps.bdo.sdo.DepExternalBranchQry;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.DepExternalBranchQryJpe;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.QDepExternalBranchQryJpe;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.id.DepExternalBranchQryPk;
import com.silverlakesymmetri.cbs.xps.svc.DepExternalBranchQryService;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Map;

@Service
@Transactional
public class DepExternalBranchQryServiceImpl extends AbstractBusinessService<DepExternalBranchQry, DepExternalBranchQryJpe, DepExternalBranchQryPk>
        implements DepExternalBranchQryService {

    @Override
    protected DepExternalBranchQryPk getIdFromDataObjectInstance(DepExternalBranchQry dataObject) {
        return new DepExternalBranchQryPk(dataObject.getBranchCode(), dataObject.getBankCode());
    }

    @Override
    protected EntityPath<DepExternalBranchQryJpe> getEntityPath() {
        return QDepExternalBranchQryJpe.depExternalBranchQryJpe;
    }

    @Override
    public List<DepExternalBranchQry> query(int offset, int resultLimit, String groupBy, String order, Map<String, Object> filters) {
        return super.query(offset, resultLimit, groupBy, order, filters);
    }

    @Override
    public List<DepExternalBranchQry> find(FindCriteria findCriteria, CbsHeader cbsHeader) {
        return super.find(findCriteria, cbsHeader);
    }

    @Override
    public DepExternalBranchQry getByPk(String publicKey, DepExternalBranchQry reference) {
        return super.getByPk(publicKey, reference);
    }
}
