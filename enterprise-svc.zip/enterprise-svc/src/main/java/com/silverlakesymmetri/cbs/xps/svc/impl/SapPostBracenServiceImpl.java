package com.silverlakesymmetri.cbs.xps.svc.impl;

import com.mysema.query.types.EntityPath;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.svc.AbstractBusinessService;
import com.silverlakesymmetri.cbs.commons.svc.BusinessObjectValidationCapable;
import com.silverlakesymmetri.cbs.xps.bdo.sdo.SapPostBracen;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.QSapPostBracenJpe;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.SapPostBracenJpe;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.util.XpsJpeConstants;
import com.silverlakesymmetri.cbs.xps.svc.SapPostBracenService;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class SapPostBracenServiceImpl extends AbstractBusinessService<SapPostBracen, SapPostBracenJpe, String>
        implements SapPostBracenService, BusinessObjectValidationCapable<SapPostBracen> {

    @Override
    public String getIdFromDataObjectInstance(SapPostBracen dataObject) {
        return dataObject.getSapPostBracenRefNo();
    }

    @Override
    public EntityPath<SapPostBracenJpe> getEntityPath() {
        return QSapPostBracenJpe.sapPostBracenJpe;
    }

    @Override
    public SapPostBracen getByPk(String publicKey, SapPostBracen reference) {
        return super.getByPk(publicKey, reference);
    }

    @Override
    public SapPostBracen create(SapPostBracen dataObject) {
        return super.create(dataObject);
    }

    @Override
    public SapPostBracen update(SapPostBracen dataObject) {
        return super.update(dataObject);
    }

    @Override
    public boolean delete(SapPostBracen dataObject) {
    	return super.delete(dataObject);
    }

    @Override
    public List<SapPostBracen> query(int offset, int resultLimit, String groupBy, String order,
                                 Map<String, Object> filters) {
        return super.query(offset, resultLimit, groupBy, order, filters);
    }

    @Override
    public List<SapPostBracen> find(FindCriteria findCriteria, CbsHeader cbsHeader) {
        return super.find(findCriteria, cbsHeader);
    }

    @Override
    public List<SapPostBracen> findWorkUnit(Map<String, Object> queryParams) {
        String sapProfitCentre = (String) queryParams.get("sapProfitCentre");
        int limit = queryParams.get("limit") != null ? Integer.parseInt((String)queryParams.get("limit")) : 10;
        int offset = queryParams.get("offset") != null ? Integer.parseInt((String)queryParams.get("offset")) : 0;

        String query = XpsJpeConstants.SAP_WORK_UNIT_MAP_WORK_UNIT_LOV_QUERY;

        List<SapPostBracen> result = new ArrayList<SapPostBracen>();
        final Map<String, Object> parameters = new HashMap<>();

        if(sapProfitCentre != null){
            query = query + " WHERE UPPER(s.sapProfitCentre) like :sapProfitCentre";
            parameters.put("sapProfitCentre", "%" + sapProfitCentre.toUpperCase() + "%");
        }

        query = query + " ORDER BY s.sapProfitCentre";

        List<SapPostBracen> list = dataService.findWithQuery(query, parameters, offset, limit, SapPostBracen.class);
        for (Object o : list) {
            Object[] values = (Object[]) o;
            SapPostBracen bdo = jaxbSdoHelper.createSdoInstance(SapPostBracen.class);
            bdo.setSapProfitCentre((String) values[0]);
            result.add(bdo);
        }
        return result;
    }


}
