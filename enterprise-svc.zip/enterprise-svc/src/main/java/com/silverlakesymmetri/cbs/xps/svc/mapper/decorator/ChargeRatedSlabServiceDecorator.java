package com.silverlakesymmetri.cbs.xps.svc.mapper.decorator;

import org.mapstruct.MappingTarget;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.RatedSlabJpe;
import com.silverlakesymmetri.cbs.xps.svc.mapper.ChargeRatedSlabServiceMapper;
import com.silverlakesymmetri.cbs.xps.xmlapi.XPSTRANCHARGEDETAILSLABTYPEType;

public abstract class ChargeRatedSlabServiceDecorator implements ChargeRatedSlabServiceMapper {
	
	@Autowired
	@Qualifier("delegate")
	protected ChargeRatedSlabServiceMapper delegate;

	@Override
	public XPSTRANCHARGEDETAILSLABTYPEType mapToApi(RatedSlabJpe jpe, @MappingTarget XPSTRANCHARGEDETAILSLABTYPEType api){
		delegate.mapToApi(jpe, api);
		return api;
	}
	
	@Override
	public RatedSlabJpe mapToJpe(XPSTRANCHARGEDETAILSLABTYPEType api, @MappingTarget RatedSlabJpe jpe){
		delegate.mapToJpe(api, jpe);
		return jpe;
	}

}


