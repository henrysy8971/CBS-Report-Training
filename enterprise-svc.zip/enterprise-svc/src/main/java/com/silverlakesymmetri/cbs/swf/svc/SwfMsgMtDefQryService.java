package com.silverlakesymmetri.cbs.swf.svc;

import java.util.List;
import java.util.Map;

import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation;
import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation.ServiceOperationType;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.svc.BusinessService;
import com.silverlakesymmetri.cbs.swf.bdo.sdo.SwfMsgMtDefQry;
import com.silverlakesymmetri.cbs.swf.jpa.mapping.sdo.SwfMsgMtDefQryJpe;

public interface SwfMsgMtDefQryService extends BusinessService<SwfMsgMtDefQry, SwfMsgMtDefQryJpe> {
	String SVC_OP_NAME_SWF_MSG_MT_DEF_QRY_SERVICE_GET = "SwfMsgMtDefQryService.get";
	String SVC_OP_NAME_SWF_MSG_MT_DEF_QRY_SERVICE_QUERY = "SwfMsgMtDefQryService.query";
	String SVC_OP_NAME_SWF_MSG_MT_DEF_QRY_SERVICE_FIND = "SwfMsgMtDefQryService.find";
	String SVC_OP_NAME_SWF_MSG_MT_DEF_QRY_SERVICE_COUNT = "SwfMsgMtDefQryService.count";
	
	 @ServiceOperation(name = SVC_OP_NAME_SWF_MSG_MT_DEF_QRY_SERVICE_GET, type = ServiceOperationType.GET)
	 SwfMsgMtDefQry getByPk(String publicKey, SwfMsgMtDefQry reference);

	    @ServiceOperation(name = SVC_OP_NAME_SWF_MSG_MT_DEF_QRY_SERVICE_QUERY)
	    List<SwfMsgMtDefQry> query(int offset, int resultLimit, String groupBy, String order, Map<String, Object> filters);

	    @ServiceOperation(name = SVC_OP_NAME_SWF_MSG_MT_DEF_QRY_SERVICE_FIND)
	    List<SwfMsgMtDefQry> find(FindCriteria findCriteria, CbsHeader cbsHeader);

	    @ServiceOperation(name = SVC_OP_NAME_SWF_MSG_MT_DEF_QRY_SERVICE_COUNT, type = ServiceOperationType.GET)
	    public Long count(FindCriteria findCriteria, CbsHeader cbsHeader);
}
