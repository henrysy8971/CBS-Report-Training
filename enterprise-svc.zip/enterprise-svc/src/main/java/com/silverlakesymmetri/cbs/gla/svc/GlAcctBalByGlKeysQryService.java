package com.silverlakesymmetri.cbs.gla.svc;

import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation;
import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation.ServiceOperationType;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.svc.BusinessService;
import com.silverlakesymmetri.cbs.gla.bdo.sdo.GlAcctBalGLKeysQry;
import com.silverlakesymmetri.cbs.gla.jpa.mapping.sdo.GlAcctBalGLKeysQryJpe;

import java.util.List;
import java.util.Map;

public interface GlAcctBalByGlKeysQryService extends BusinessService<GlAcctBalGLKeysQry, GlAcctBalGLKeysQryJpe> {

	public static final String SVC_OP_NAME_GLACCTBALBYGLKEYSSERVICE_GET = "GlAcctBalGLKeysQryService.get";
	public static final String SVC_OP_NAME_GLACCTBALBYGLKEYSSERVICE_FIND = "GlAcctBalGLKeysQryService.find";
	public static final String SVC_OP_NAME_GLACCTBALBYGLKEYSSERVICE_QUERY = "GlAcctBalGLKeysQryService.query";
	
	@ServiceOperation(name = SVC_OP_NAME_GLACCTBALBYGLKEYSSERVICE_GET, type = ServiceOperationType.GET)
    public GlAcctBalGLKeysQry getByPk(String publicKey, GlAcctBalGLKeysQry reference);

    @ServiceOperation(name = SVC_OP_NAME_GLACCTBALBYGLKEYSSERVICE_FIND)
    public List<GlAcctBalGLKeysQry> find(FindCriteria findCriteria, CbsHeader cbsHeader);
    
    @ServiceOperation(name = SVC_OP_NAME_GLACCTBALBYGLKEYSSERVICE_QUERY)
    public List<GlAcctBalGLKeysQry> query(int offset, int resultLimit, String groupBy, String order, Map<String, Object> filters);
}
