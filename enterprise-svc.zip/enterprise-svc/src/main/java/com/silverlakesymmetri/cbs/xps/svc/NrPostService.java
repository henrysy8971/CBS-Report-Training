package com.silverlakesymmetri.cbs.xps.svc;

import java.util.List;
import java.util.Map;

import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation;
import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation.ServiceOperationType;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.svc.BusinessService;
import com.silverlakesymmetri.cbs.xps.bdo.sdo.NrPost;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.NrPostJpe;

public interface NrPostService extends BusinessService<NrPost, NrPostJpe> {
	public static final String XPS_OP_NAME_NRPOSTSERVICE_GET = "NrPostService.get";
    public static final String XPS_OP_NAME_NRPOSTSERVICE_QUERY = "NrPostService.query";
    public static final String XPS_OP_NAME_NRPOSTSERVICE_FIND = "NrPostService.find";
    public static final String XPS_OP_NAME_NRPOSTSERVICE_CREATE = "NrPostService.create";
    public static final String XPS_OP_NAME_NRPOSTSERVICE_UPDATE = "NrPostService.update";
    public static final String XPS_OP_NAME_NRPOSTSERVICE_DELETE = "NrPostService.delete";
    
    @ServiceOperation(name = XPS_OP_NAME_NRPOSTSERVICE_GET, type = ServiceOperationType.GET)
    public NrPost getByPk(String publicKey, NrPost reference);

    @ServiceOperation(name = XPS_OP_NAME_NRPOSTSERVICE_QUERY)
    public List<NrPost> query(int offset, int resultLimit, String groupBy, String order, Map<String, Object> filters);
    
    @ServiceOperation(name = XPS_OP_NAME_NRPOSTSERVICE_FIND)
    public List<NrPost> find(FindCriteria findCriteria, CbsHeader cbsHeader);
    
    @ServiceOperation(name = XPS_OP_NAME_NRPOSTSERVICE_CREATE)
    public NrPost create(NrPost dataObject);

     @ServiceOperation(name = XPS_OP_NAME_NRPOSTSERVICE_UPDATE)
    public NrPost update(NrPost dataObject);

    @ServiceOperation(name = XPS_OP_NAME_NRPOSTSERVICE_DELETE)
    public boolean delete(NrPost dataObject);
}