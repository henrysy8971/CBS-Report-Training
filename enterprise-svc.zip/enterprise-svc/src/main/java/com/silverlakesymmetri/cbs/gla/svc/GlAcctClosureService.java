package com.silverlakesymmetri.cbs.gla.svc;

import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.svc.BusinessService;
import com.silverlakesymmetri.cbs.csd.bdo.sdo.Branch;
import com.silverlakesymmetri.cbs.csd.bdo.sdo.Currency;
import com.silverlakesymmetri.cbs.csd.bdo.sdo.ProfitCentre;
import com.silverlakesymmetri.cbs.csd.gla.bdo.sdo.ChartAccount;
import com.silverlakesymmetri.cbs.gla.bdo.sdo.GlAcctClosure;
import com.silverlakesymmetri.cbs.gla.jpa.mapping.sdo.GlAcctClosureJpe;
import com.silverlakesymmetri.cbs.mcl.bdo.sdo.Client;

import java.util.List;
import java.util.Map;

/**
 * Created by Emerson.Sanchez on 26/7/2019.
 */
public interface GlAcctClosureService extends BusinessService<GlAcctClosure, GlAcctClosureJpe> {

    public static final String SVC_OP_NAME_GL_ACCT_CLOSURE_SERVICE_GET = "GlAcctClosureService.get";
    public static final String SVC_OP_NAME_GL_ACCT_CLOSURE_SERVICE_CREATE = "GlAcctClosureService.create";
    public static final String SVC_OP_NAME_GL_ACCT_CLOSURE_SERVICE_BRANCH_LOV = "GlAcctClosureService.findBranches";
    public static final String SVC_OP_NAME_GL_ACCT_CLOSURE_SERVICE_CCY_LOV = "GlAcctClosureService.findCcy";
    public static final String SVC_OP_NAME_GL_ACCT_CLOSURE_SERVICE_CLIENT_NO_LOV = "GlAcctClosureService.findClientNo";
    public static final String SVC_OP_NAME_GL_ACCT_CLOSURE_SERVICE_NOS_VOS_NO_LOV = "GlAcctClosureService.findNosVosNo";
    public static final String SVC_OP_NAME_GL_ACCT_CLOSURE_SERVICE_GL_CODE_LOV = "GlAcctClosureService.findGlCodes";
    public static final String SVC_OP_NAME_GL_ACCT_CLOSURE_SERVICE_SEQ_NO_LOV = "GlAcctClosureService.findSeqNo";
    public static final String SVC_OP_NAME_GL_ACCT_CLOSURE_SERVICE_PROFIT_CENTRE_LOV = "GlAcctClosureService.findProfitCentre";
    public static final String SVC_OP_NAME_GL_ACCT_CLOSURE_SERVICE_QUERY = "GlAcctClosureService.query";
    public static final String SVC_OP_NAME_GL_ACCT_CLOSURE_SERVICE_FIND = "GlAcctClosureService.find";
    public static final String SVC_OP_NAME_GL_ACCT_CLOSURE_SERVICE_COUNT = "GlAcctClosureService.count";
    public static final String SVC_OP_NAME_GL_ACCT_CLOSURE_SERVICE_UPDATE = "GlAcctClosureService.update";

    @ServiceOperation(name = SVC_OP_NAME_GL_ACCT_CLOSURE_SERVICE_GET, type = ServiceOperation.ServiceOperationType.GET)
    public GlAcctClosure getByPk(String publicKey, GlAcctClosure reference);

    @ServiceOperation(name = SVC_OP_NAME_GL_ACCT_CLOSURE_SERVICE_CREATE)
    public GlAcctClosure create(GlAcctClosure dataObject);

    @ServiceOperation(name = SVC_OP_NAME_GL_ACCT_CLOSURE_SERVICE_BRANCH_LOV ,
            type = ServiceOperation.ServiceOperationType.READ, passParamAsMap = true)
    public List<Branch> findBranches(Map<String, Object> queryParams);

    @ServiceOperation(name = SVC_OP_NAME_GL_ACCT_CLOSURE_SERVICE_CCY_LOV ,
            type = ServiceOperation.ServiceOperationType.READ, passParamAsMap = true)
    public List<Currency> findCcy(Map<String, Object> queryParams);

    @ServiceOperation(name = SVC_OP_NAME_GL_ACCT_CLOSURE_SERVICE_CLIENT_NO_LOV ,
            type = ServiceOperation.ServiceOperationType.READ, passParamAsMap = true)
    public List<Client> findClientNo(Map<String, Object> queryParams);

    @ServiceOperation(name = SVC_OP_NAME_GL_ACCT_CLOSURE_SERVICE_NOS_VOS_NO_LOV ,
            type = ServiceOperation.ServiceOperationType.READ, passParamAsMap = true)
    public List<GlAcctClosure> findNosVosNo(Map<String, Object> queryParams);

    @ServiceOperation(name = SVC_OP_NAME_GL_ACCT_CLOSURE_SERVICE_GL_CODE_LOV ,
            type = ServiceOperation.ServiceOperationType.READ, passParamAsMap = true)
    public List<ChartAccount> findGlCodes(Map<String, Object> queryParams);

    @ServiceOperation(name = SVC_OP_NAME_GL_ACCT_CLOSURE_SERVICE_SEQ_NO_LOV ,
            type = ServiceOperation.ServiceOperationType.READ, passParamAsMap = true)
    public List<GlAcctClosure> findSeqNo(Map<String, Object> queryParams);

    @ServiceOperation(name = SVC_OP_NAME_GL_ACCT_CLOSURE_SERVICE_PROFIT_CENTRE_LOV ,
            type = ServiceOperation.ServiceOperationType.READ, passParamAsMap = true)
    public List<ProfitCentre> findProfitCentre(Map<String, Object> queryParams);

    @ServiceOperation(name = SVC_OP_NAME_GL_ACCT_CLOSURE_SERVICE_QUERY)
    public List<GlAcctClosure> query(int offset, int resultLimit, String groupBy, String order,
                                     Map<String, Object> filters);

    @ServiceOperation(name = SVC_OP_NAME_GL_ACCT_CLOSURE_SERVICE_FIND)
    public List<GlAcctClosure> find(FindCriteria findCriteria, CbsHeader cbsHeader);

    @ServiceOperation(name = SVC_OP_NAME_GL_ACCT_CLOSURE_SERVICE_COUNT, type = ServiceOperation.ServiceOperationType.GET)
    public Long count(FindCriteria findCriteria, CbsHeader cbsHeader);

    @ServiceOperation(name = SVC_OP_NAME_GL_ACCT_CLOSURE_SERVICE_UPDATE)
    public GlAcctClosure update(GlAcctClosure dataObject);

}
