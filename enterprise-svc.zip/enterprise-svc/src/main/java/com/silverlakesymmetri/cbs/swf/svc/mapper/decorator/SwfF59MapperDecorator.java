package com.silverlakesymmetri.cbs.swf.svc.mapper.decorator;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

import com.silverlakesymmetri.cbs.swf.jpa.mapping.sdo.SwfNonFinEntityJpe;
import com.silverlakesymmetri.cbs.swf.svc.mapper.mapping.SwfF59Mapper;
import com.silverlakesymmetri.cbs.swf.xmlapi.SWFF59TYPEType;

public abstract class SwfF59MapperDecorator implements SwfF59Mapper {
	
	@Autowired
	@Qualifier("delegate")
	protected SwfF59Mapper delegate;

	@Override
	public SWFF59TYPEType mapToApi(SwfNonFinEntityJpe jpe){
		SWFF59TYPEType swfF59 = delegate.mapToApi(jpe);
		if(swfF59 != null && swfF59.getACCOUNT() == null && swfF59.getADDRESS() == null && swfF59.getBIC() == null && 
				swfF59.getCUSTOMERID() == null && swfF59.getCUSTOMERDETAILS() == null){
			return null;
		}
		return swfF59;
	}
	
	@Override
	public SwfNonFinEntityJpe mapToJpe(SWFF59TYPEType api){
		return delegate.mapToJpe(api);
	}
	
}
