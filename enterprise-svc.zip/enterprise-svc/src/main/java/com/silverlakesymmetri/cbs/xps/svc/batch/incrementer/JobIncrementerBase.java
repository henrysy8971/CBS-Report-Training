package com.silverlakesymmetri.cbs.xps.svc.batch.incrementer;

import java.util.HashMap;
import java.util.Map;

import javax.inject.Inject;

import org.apache.commons.lang3.StringUtils;
import org.springframework.batch.core.JobParameter;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.JobParametersIncrementer;

import com.silverlakesymmetri.cbs.commons.batch.svc.util.BatchConstants;
import com.silverlakesymmetri.cbs.commons.context.CbsRuntimeContextManager;
import com.silverlakesymmetri.cbs.commons.context.CbsSessionContext;
import com.silverlakesymmetri.cbs.commons.context.CbsTransactionContext;

public abstract class JobIncrementerBase implements JobParametersIncrementer, BatchConstants {
	protected static final String DISCRIMINATOR_KEY = "run.id";
	protected static final String INTERNALKEYLIST_KEY = "internalKeyList";
	
	String itemListStr;
	public String getItemListStr() {
		return itemListStr;
	}
	public void setItemListStr(String itemListStr) {
		this.itemListStr = itemListStr;
	}

	@Inject
	private CbsRuntimeContextManager _ctxMngr;
	
	@Override
	public JobParameters getNext(JobParameters parameters) {
		parameters = replaceSessionAndTransactionId(parameters);
		parameters = addDiscriminator(parameters);
		parameters = replaceItemListParam(parameters);

		return parameters;
	}
	
	protected JobParameters replaceItemListParam(JobParameters parameters) {
		Map<String, JobParameter> newParams = new HashMap<>(parameters.getParameters());

		if (StringUtils.isBlank(itemListStr)) {
			return new JobParameters(newParams);
		}

		JobParameter internalKeyListParam = newParams.get(INTERNALKEYLIST_KEY);
		String internalKeyListParamValue = null;

		if (internalKeyListParam != null) {
			internalKeyListParamValue = internalKeyListParam.getValue() == null ? null
					: internalKeyListParam.getValue().toString();
		}

		if (!StringUtils.equals(internalKeyListParamValue, itemListStr)) {
			newParams.put(INTERNALKEYLIST_KEY, new JobParameter(itemListStr));
		}

		return new JobParameters(newParams);
	}

	protected JobParameters addDiscriminator(JobParameters parameters) {
		Map<String, JobParameter> newParams = new HashMap<>(parameters.getParameters());

		Long runId = 1L;
		JobParameter discriminatorParam = newParams.get(DISCRIMINATOR_KEY);
		if(discriminatorParam != null){
			runId = (Long) discriminatorParam.getValue();
		}
		runId = runId + 1;
		
		newParams.put(DISCRIMINATOR_KEY, new JobParameter(runId, true));
		return new JobParameters(newParams);
	}

    protected JobParameters replaceSessionAndTransactionId(JobParameters parameters) {
        Map<String, JobParameter> newParams = new HashMap<>(parameters.getParameters());
        //
        String sessionId = null;
        String transactionId = null;
        String svcOpName = null;
        //
        newParams.remove(CBS_TRANSACTION_ID_KEY);
        newParams.remove(CBS_SESSION_ID_KEY);
        newParams.remove(SERVICE_OPERATION_NAME);
        //
        CbsTransactionContext txnContext = _ctxMngr.getContext(CbsTransactionContext.class);
        CbsSessionContext sessionContext = null;
        if (txnContext != null) {
            transactionId = Long.toString(txnContext.getTransactionId());
            sessionContext = (CbsSessionContext) txnContext;
            svcOpName = txnContext.getCurrentServiceOperation();
        } else {
            // Should not happen but never say never!
            sessionContext = _ctxMngr.getContext(CbsSessionContext.class);
        }
        if (sessionContext != null) {
            sessionId = sessionContext.getSessionId();
        }
        if(StringUtils.isNotBlank(sessionId)) {
            newParams.put(CBS_SESSION_ID_KEY, new JobParameter(sessionId, false));
        }
        if(StringUtils.isNotBlank(transactionId)) {
            newParams.put(CBS_TRANSACTION_ID_KEY, new JobParameter(transactionId, false));
        }
        if(StringUtils.isNotBlank(svcOpName)) {
            newParams.put(SERVICE_OPERATION_NAME, new JobParameter(svcOpName, false));
        }

        return new JobParameters(newParams);
    }

}
