package com.silverlakesymmetri.cbs.xps.svc.impl;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.velocity.VelocityContext;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.mysema.query.types.EntityPath;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.bdo.sdo.DmsFile;
import com.silverlakesymmetri.cbs.commons.exception.base.CbsServiceProcessException;
import com.silverlakesymmetri.cbs.commons.jpa.entity.CbsBusinessDataObjectJpe;
import com.silverlakesymmetri.cbs.commons.jpa.mapping.sdo.RegistryJpe;
import com.silverlakesymmetri.cbs.commons.jpa.repository.RegistryRepository;
import com.silverlakesymmetri.cbs.commons.jpa.util.DateTimeHelper;
import com.silverlakesymmetri.cbs.commons.svc.ext.ServiceExtensionProcessor;
import com.silverlakesymmetri.cbs.commons.xmlapi.enums.CbsXmlApiOperation;
import com.silverlakesymmetri.cbs.csd.bdo.sdo.SettleMethod;
import com.silverlakesymmetri.cbs.mcl.bdo.sdo.Client;
import com.silverlakesymmetri.cbs.mcl.bdo.sdo.ClientContact;
import com.silverlakesymmetri.cbs.pim.bdo.sdo.MessageKey;
import com.silverlakesymmetri.cbs.swf.bdo.sdo.SwfMessageGroup;
import com.silverlakesymmetri.cbs.xps.bdo.sdo.AdvicePreview;
import com.silverlakesymmetri.cbs.xps.bdo.sdo.ChargeDetails;
import com.silverlakesymmetri.cbs.xps.bdo.sdo.ChargeMaster;
import com.silverlakesymmetri.cbs.xps.bdo.sdo.ChargeSettlement;
import com.silverlakesymmetri.cbs.xps.bdo.sdo.ChargeSettlementDetails;
import com.silverlakesymmetri.cbs.xps.bdo.sdo.ChargeWithSettlement;
import com.silverlakesymmetri.cbs.xps.bdo.sdo.MessageQOthers;
import com.silverlakesymmetri.cbs.xps.bdo.sdo.PeriodicSlab;
import com.silverlakesymmetri.cbs.xps.bdo.sdo.SettleMessagePreviewAddInfo;
import com.silverlakesymmetri.cbs.xps.enums.XpsGlobalConstants;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.ChargeDetailsJpe;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.ChargeSettlementJpe;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.ChargeWithSettlementJpe;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.QChargeWithSettlementJpe;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.util.ChargeMgrHelper;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.util.CommonAcctRestraintHolder;
import com.silverlakesymmetri.cbs.xps.svc.AbstractXmlApiAdviceCapableBusinessService;
import com.silverlakesymmetri.cbs.xps.svc.ChargeMasterService;
import com.silverlakesymmetri.cbs.xps.svc.ChargeSettlementService;
import com.silverlakesymmetri.cbs.xps.svc.ChargeWithSettlementService;
import com.silverlakesymmetri.cbs.xps.svc.ChargesUtilityService;
import com.silverlakesymmetri.cbs.xps.svc.MessageQService;
import com.silverlakesymmetri.cbs.xps.svc.mapper.ChargeMasterServiceMapper;
import com.silverlakesymmetri.cbs.xps.svc.mapper.ChargeSettlementServiceMapper;
import com.silverlakesymmetri.cbs.xps.svc.util.CommonAcctRestraintUtil;
import com.silverlakesymmetri.cbs.xps.xmlapi.XPSTRANCHARGEDETAILAPIType;
import com.silverlakesymmetri.cbs.xps.xmlapi.XPSTRANCHARGESETTLEAPIType;
import com.silverlakesymmetri.cbs.xps.xmlapi.XPSTRANCHARGEWITHSETTLEAPIType;

@Service
@Transactional
public class ChargeWithSettlementServiceImpl extends AbstractXmlApiAdviceCapableBusinessService<ChargeWithSettlement, ChargeWithSettlementJpe, Long, XPSTRANCHARGEWITHSETTLEAPIType, XPSTRANCHARGEWITHSETTLEAPIType> implements ChargeWithSettlementService, ServiceExtensionProcessor<ChargeWithSettlement> {

    @Autowired
    private ChargeMasterServiceMapper mapper;

    @Autowired
    private ChargeSettlementServiceMapper settlementMapper;
    
    @Autowired
    private ChargesUtilityService chargeUtility;
	
	@Autowired
	protected ChargeMasterService chargeMasterService;
	
	@Autowired
	protected ChargeSettlementService chargeSettlementService;

	@Autowired
	protected MessageQService messageQueueService;

	@Autowired
	protected DateTimeHelper dateTimeHelper;

	@Autowired
	private CommonAcctRestraintUtil commonAcctRestraintUtil;
	
	@Autowired
	private RegistryRepository registryRepository;

	private static final String CHARGE_TYPE_FIXED = "F";
	private static final String CHARGE_TYPE_INTEREST = "I";
	private static final String CHARGE_TYPE_PERIODIC = "P";
	private static final String CHARGE_TYPE_RATED = "R";
	private static final String CHARGE_TYPE_TWOTIER = "T";

	protected static final String BGT = "BGT";
	protected static final String BANK_GUARANTEE_REGISTRY = "BANK_GUARANTEE_REGISTRY";
	protected static final String TFN = "TFN";
	protected static final String TRADE_FINANCE_REGISTRY = "TRADE_FINANCE_REGISTRY";
	protected static final String FH_RESTRAINT_TYPE = "fhRestraintType";
	protected static final String CHARGE_API = "XPS_TRAN_CHARGE_WITH_SETTLE_API";

    @Override
    public ChargeWithSettlement getByPk(String publicKey, ChargeWithSettlement reference) {
    	ChargeWithSettlement bdo = jaxbSdoHelper.createSdoInstance(ChargeWithSettlement.class);
    	ChargeMaster chargeMaster = chargeMasterService.getByPk(publicKey, null);
    	bdo.setChargeStructRec(chargeMaster);
    	ChargeSettlement chargeSettlement = chargeSettlementService.getByPk(publicKey, null);
    	bdo.setSettlementStructRec(chargeSettlement);
    	return bdo;
    }

    @Override
    public List<ChargeWithSettlement> find(FindCriteria findCriteria, CbsHeader cbsHeader) {
        return super.find(findCriteria, cbsHeader);
    }

    @Override
    public List<ChargeWithSettlement> query(int offset, int resultLimit, String groupBy, String order, Map<String, Object> filters) {
        return super.query(offset, resultLimit, groupBy, order, filters);
    }

    @Override
    public ChargeWithSettlement preCreateValidation(ChargeWithSettlement dataObject) {
    	Long tranKey = chargeUtility.getTranKey(dataObject.getChargeStructRec().getRefNo(), dataObject.getChargeStructRec().getDomainType(), dataObject.getChargeStructRec().getInstrumentType());
    	Long internalKey = chargeUtility.getInternalKey(CHARGE_API);
    	dataObject.getChargeStructRec().setTranKey(tranKey);
    	if(dataObject.getChargeStructRec().getInternalKey() == null){
        	dataObject.getChargeStructRec().setInternalKey(internalKey);
    	}
    	if(dataObject.getInternalKey() == null){
        	dataObject.setInternalKey(internalKey);
    	}
    	
    	if(dataObject.getChargeStructRec().getChargeDetailsList() != null){
    		for(ChargeDetails details : dataObject.getChargeStructRec().getChargeDetailsList()){
    			if(CHARGE_TYPE_RATED.equals(details.getChargeType()) || CHARGE_TYPE_PERIODIC.equals(details.getChargeType()) || CHARGE_TYPE_TWOTIER.equals(details.getChargeType())){
    				ChargeDetailsJpe jpe = jaxbSdoHelper.unwrap(details);
    				Date startDate = null;
    				Date endDate = null;
    				Date amendStartDate = null;
    				Date amendEndDate = null;
    				if(CHARGE_TYPE_RATED.equals(details.getChargeType()) && details.getChargeRatedStructRec() != null){
        				startDate = jpe.getChargeRatedStructRec().getStartDate();
        				endDate = jpe.getChargeRatedStructRec().getEndDate();
        				amendStartDate = jpe.getChargeRatedStructRec().getAmendStartDate();
        				amendEndDate = jpe.getChargeRatedStructRec().getAmendEndDate();
    				} else if(CHARGE_TYPE_PERIODIC.equals(details.getChargeType()) && details.getChargePeriodicStructRec() != null){
        				startDate = jpe.getChargePeriodicStructRec().getStartDate();
        				endDate = jpe.getChargePeriodicStructRec().getEndDate();
        				amendStartDate = jpe.getChargePeriodicStructRec().getAmendStartDate();
        				amendEndDate = jpe.getChargePeriodicStructRec().getAmendEndDate();
    				} else if(CHARGE_TYPE_TWOTIER.equals(details.getChargeType()) && details.getChargeTwoTierStructRec() != null){
        				startDate = jpe.getChargeTwoTierStructRec().getStartDate();
        				endDate = jpe.getChargeTwoTierStructRec().getEndDate();
        				amendStartDate = jpe.getChargeTwoTierStructRec().getAmendStartDate();
        				amendEndDate = jpe.getChargeTwoTierStructRec().getAmendEndDate();
    				}
    				if(startDate != null && endDate != null){
    					if(dateTimeHelper.isBefore(endDate, startDate)){
    			            String msg = messageUtils.getMessage("CBS.B.XPS.CHARGEWITHSETTLEMENTSERVICE.0001", new String[] {});
    			            CbsServiceProcessException exec = new CbsServiceProcessException("CBS.B.XPS.CHARGEWITHSETTLEMENTSERVICE.0001", msg);
    			            throw exec;
    					}
    				}
    				if(amendStartDate != null && amendEndDate != null){
    					if(dateTimeHelper.isBefore(amendEndDate, amendStartDate)){
    			            String msg = messageUtils.getMessage("CBS.B.XPS.CHARGEWITHSETTLEMENTSERVICE.0002", new String[] {});
    			            CbsServiceProcessException exec = new CbsServiceProcessException("CBS.B.XPS.CHARGEWITHSETTLEMENTSERVICE.0002", msg);
    			            throw exec;
    					}
    				}
    				if(startDate != null && amendStartDate != null){
    					if(dateTimeHelper.isBefore(amendStartDate, startDate)){
    			            String msg = messageUtils.getMessage("CBS.B.XPS.CHARGEWITHSETTLEMENTSERVICE.0003", new String[] {});
    			            CbsServiceProcessException exec = new CbsServiceProcessException("CBS.B.XPS.CHARGEWITHSETTLEMENTSERVICE.0003", msg);
    			            throw exec;
    					}
    				}
    			}
    			if(CHARGE_TYPE_PERIODIC.equals(details.getChargeType()) && details.getChargePeriodicStructRec() != null){
    				if(details.getChargePeriodicStructRec().getPeriodicSlabList() != null && details.getChargePeriodicStructRec().getPeriodicSlabList().size() > 0){
    					for(PeriodicSlab periodicSlab : details.getChargePeriodicStructRec().getPeriodicSlabList()){
    						boolean skippedRateExists = false;
    						if(periodicSlab.getRate12() != null && periodicSlab.getRate11() == null){
    							skippedRateExists = true;
    						}
    						if(periodicSlab.getRate11() != null && periodicSlab.getRate10() == null){
    							skippedRateExists = true;
    						}
    						if(periodicSlab.getRate10() != null && periodicSlab.getRate09() == null){
    							skippedRateExists = true;
    						}
    						if(periodicSlab.getRate09() != null && periodicSlab.getRate08() == null){
    							skippedRateExists = true;
    						}
    						if(periodicSlab.getRate08() != null && periodicSlab.getRate07() == null){
    							skippedRateExists = true;
    						}
    						if(periodicSlab.getRate07() != null && periodicSlab.getRate06() == null){
    							skippedRateExists = true;
    						}
    						if(periodicSlab.getRate06() != null && periodicSlab.getRate05() == null){
    							skippedRateExists = true;
    						}
    						if(periodicSlab.getRate05() != null && periodicSlab.getRate04() == null){
    							skippedRateExists = true;
    						}
    						if(periodicSlab.getRate04() != null && periodicSlab.getRate03() == null){
    							skippedRateExists = true;
    						}
    						if(periodicSlab.getRate03() != null && periodicSlab.getRate02() == null){
    							skippedRateExists = true;
    						}
    						if(periodicSlab.getRate02() != null && periodicSlab.getRate01() == null){
    							skippedRateExists = true;
    						}
    						if(skippedRateExists){
        			            String msg = messageUtils.getMessage("CBS.B.XPS.CHARGEWITHSETTLEMENTSERVICE.0004", new String[] {});
        			            CbsServiceProcessException exec = new CbsServiceProcessException("CBS.B.XPS.CHARGEWITHSETTLEMENTSERVICE.0004", msg);
        			            throw exec;
    						}
    					}
    				}
    			}
    		}
    	}
    	validateSettlementAmount(dataObject);
    	
    	return super.preCreateValidation(dataObject);
    }
    
    @Override
    public ChargeWithSettlement preUpdateValidation(ChargeWithSettlement dataObject) {
    	validateSettlementAmount(dataObject);
    	return super.preUpdateValidation(dataObject);
    }
    
    private void validateSettlementAmount(ChargeWithSettlement dataObject){
		ChargeMaster master = dataObject.getChargeStructRec();
		ChargeSettlement settlement = dataObject.getSettlementStructRec();
    	if(settlement != null && settlement.getChargeSettleDetailsList() != null && master != null){
    		Double totalSettlementAmount = new Double(0);
    		for(ChargeSettlementDetails detail : settlement.getChargeSettleDetailsList()){
				if(detail.getAmount() != null){
					totalSettlementAmount = totalSettlementAmount.doubleValue() + detail.getAmount().doubleValue();
				}
    		}
    		if(totalSettlementAmount.compareTo(master.getAmount()) != 0){
	            String msg = messageUtils.getMessage("CBS.B.XPS.CHARGEWITHSETTLEMENT.0001", new String[] {});
	            CbsServiceProcessException exec = new CbsServiceProcessException("CBS.B.XPS.CHARGEWITHSETTLEMENT.0001", msg);
	            throw exec;
			}
    	}

    }

    @Override
    public ChargeWithSettlement create(ChargeWithSettlement dataObject) {
    	ChargeWithSettlement bdo = super.create(dataObject);
        generateMessageQueue(bdo);
        return bdo;
    }

    @Override
    protected XPSTRANCHARGEWITHSETTLEAPIType transformBdoToXmlApiRqCreate(ChargeWithSettlement dataObject) {
        return transformBdoToXmlApiType(dataObject, CbsXmlApiOperation.INSERT);
    }

    @Override
    protected XPSTRANCHARGEWITHSETTLEAPIType transformBdoToXmlApiRqUpdate(ChargeWithSettlement dataObject) {
        return null;
    }

    @Override
    protected XPSTRANCHARGEWITHSETTLEAPIType transformBdoToXmlApiRqDelete(ChargeWithSettlement dataObject) {
        return null;
    }

    private XPSTRANCHARGEWITHSETTLEAPIType transformBdoToXmlApiType(ChargeWithSettlement dataObject, CbsXmlApiOperation oper) {
    	ChargeWithSettlementJpe jpe = jaxbSdoHelper.unwrap(dataObject);
    	XPSTRANCHARGEWITHSETTLEAPIType api = mapper.mapToApi(jpe.getChargeStructRec(), oper);
    	if(jpe.getSettlementStructRec() != null){
    		XPSTRANCHARGESETTLEAPIType settlement = settlementMapper.mapToApi(jpe.getSettlementStructRec(), oper);
    		super.setTechColsFromDataObject(dataObject.getSettlementStructRec(), settlement);
    		/*if(settlement.getDETAILS().getXPSTRANCHARGESETTLEDETAILAPI() != null){
    	    	for(XPSTRANCHARGESETTLEDETAILAPIType detailApi : settlement.getDETAILS().getXPSTRANCHARGESETTLEDETAILAPI()){
    	    		for(ChargeSettlementDetails detailBdo : dataObject.getSettlementStructRec().getChargeSettleDetailsList()){
    	    			if(detailBdo.getSeqNo().longValue() == detailApi.getSEQNO().longValue()){
    	    				super.setTechColsFromDataObject(detailBdo, detailApi);
    	    			}
    	    		}
    	    	}
    		}*/
    		api.setSETTLEMENT(settlement);
    		api.setSETTLEDATE(settlement.getSETTLEDATE());
    		api.setSETTLEMESSAGELIST(settlement.getMESSAGELIST());
    	}
    	super.setTechColsFromDataObject(dataObject, api);
    	for(XPSTRANCHARGEDETAILAPIType detailApi : api.getDETAILS().getXPSTRANCHARGEDETAILAPI()){
    		for(ChargeDetails detailBdo : dataObject.getChargeStructRec().getChargeDetailsList()){
    			if(detailBdo.getSeqNo().longValue() == detailApi.getSEQNO().longValue()){
    				super.setTechColsFromDataObject(detailBdo, detailApi);
    			}
    		}
    	}
        return api;
    }

    @Override
    protected Map<String, String> executeStoredProcedure(String xmlApiReq, String xmlHeaderIn) {
        String xmlApiReqProcess = xmlApiReq.replaceAll("XPS_TRAN_CHARGE_WITH_SETTLE_API OPERATION=\"INSERT\"", "XPS_TRAN_CHARGE_WITH_SETTLE_API OPERATION=\"PROCESS_AUTHORIZE\"");
        return super.executeStoredProcedure(xmlApiReqProcess, xmlHeaderIn);
    }

    @Override
    protected ChargeWithSettlement processXmlApiRs(ChargeWithSettlement dataObject, XPSTRANCHARGEWITHSETTLEAPIType xmlApiRs) {
    	ChargeWithSettlementJpe jpe = jaxbSdoHelper.unwrap(dataObject);
        jpe.setChargeStructRec(mapper.mapToJpe(xmlApiRs, jpe.getChargeStructRec()));
        jpe.setInternalKey(xmlApiRs.getINTERNALKEY());
        if(xmlApiRs.getSETTLEMENT() != null && xmlApiRs.getSETTLEMENT().getINTERNALKEY() != null){
        	ChargeSettlementJpe settlement = settlementMapper.mapToJpe(xmlApiRs.getSETTLEMENT());
        	if(settlement != null){
        		jpe.setSettlementStructRec(settlement);
        	}
        }
        return jaxbSdoHelper.wrap(jpe);
    }

    @Override
    protected List<ChargeWithSettlement> processXmlApiListRs(ChargeWithSettlement dataObject, XPSTRANCHARGEWITHSETTLEAPIType xmlApiRs) {
        return null;
    }

    @Override
    protected Class<XPSTRANCHARGEWITHSETTLEAPIType> getXmlApiResponseClass() {
        return XPSTRANCHARGEWITHSETTLEAPIType.class;
    }

    @Override
    protected Long getIdFromDataObjectInstance(ChargeWithSettlement dataObject) {
        return dataObject.getChargeStructRec().getInternalKey();
    }

    @Override
    protected EntityPath<ChargeWithSettlementJpe> getEntityPath() {
        return QChargeWithSettlementJpe.chargeWithSettlementJpe;
    }

	@Override
	public String generateSwfMessage(Map<String, Object> params) {
		String swfMessage = null;
    	SwfMessageGroup msgGroup = jsonConversionMngr.convertToType(params.get("msgGroup"), SwfMessageGroup.class, null, null);
		if(params.get("module") != null){
			msgGroup.setModule(params.get("module").toString());
		} 
    	ChargeWithSettlement bdo = jsonConversionMngr.convertToType(params.get("transactionBdo"), ChargeWithSettlement.class, null, null);
    	String swiftMessageFromQueue = getGeneratedSwiftMessage(bdo.getInternalKey(), "ZEN", msgGroup.getFormat(), msgGroup.getModule());
    	if(swiftMessageFromQueue != null){
    		return swiftMessageFromQueue;
    	}
    	XPSTRANCHARGEWITHSETTLEAPIType xmlApiReq = transformBdoToXmlApiType(bdo, CbsXmlApiOperation.QUERY);
    	SettleMessagePreviewAddInfo addtlInfo = jsonConversionMngr.convertToType(params.get("parentInfo"), SettleMessagePreviewAddInfo.class, null, null);
    	swfMessage = transformToSwfFormat(xmlApiReq, msgGroup, addtlInfo);
		return swfMessage;
	}

	@Override
	protected MessageQOthers fillContext(Map<String, Object> adviceParams, VelocityContext context){
		boolean isJsonParams = adviceParams.get("isJsonParams") == null ? false : Boolean.valueOf(adviceParams.get("isJsonParams").toString());

		ChargeMaster master = null;
		if(isJsonParams){
			master = jsonConversionMngr.convertToType(adviceParams.get("ChargeMaster"), ChargeMaster.class, null, null);
		} else {
			master = (ChargeMaster) adviceParams.get("ChargeMaster");
		}
		context.put("ChargeMaster", master);
		adviceParams.remove("ChargeMaster");

		ChargeSettlementDetails details = null;
		if(isJsonParams){
			details = jsonConversionMngr.convertToType(adviceParams.get("bdo"), ChargeSettlementDetails.class, null, null);
		} else {
			details = (ChargeSettlementDetails) adviceParams.get("bdo");
		}
		context.put("ChargeSettlementDetails", details);
		adviceParams.remove("bdo");

		if(details.getCommonSettleDepositRec() != null){
			context.put("CommonSettleDeposit", details.getCommonSettleDepositRec());
			Client client = clientService.getByPk(details.getCommonSettleDepositRec().getClientNo(), null);
			if(client != null){
				context.put("Client", client);
				adviceParams.put("Client", client);
				ClientContact contact = getClientContact(client, "POSTAL", null);
				context.put("ClientContact", contact);
			}
		}

		if(details.getInternalKey() != null) {
			Map<String, Object> filters = new HashMap<String, Object>();
			filters.put("tranInternalKey", details.getInternalKey());
			filters.put("tranEventType", "ZST");
			List<MessageQOthers> messageQList = messageQOthersService.query(0, -1, null, null, filters);
			if(messageQList != null && messageQList.size() > 0){
				return messageQList.get(0);
			}
		}
		return null;
	}
	
	private void generateMessageQueue(ChargeWithSettlement bdo) {
		if(bdo.getSettlementStructRec() != null && bdo.getSettlementStructRec().getChargeSettleDetailsList() != null 
				&& bdo.getSettlementStructRec().getChargeSettleDetailsList().size() > 0) {
			Long seqNo = 1L;
			for(ChargeSettlementDetails details : bdo.getSettlementStructRec().getChargeSettleDetailsList()){
				String destinationAddress = null;
				SettleMethod settleMethod = settleMethodService.getByPk(details.getSettleMethod()+"~"+bdo.getChargeStructRec().getPayRec(), null);
				if(settleMethod != null && settleMethod.getDestClientType() != null && !settleMethod.getDestClientType().equals("N")){
					if(settleMethod.getRouteDest() != null && !settleMethod.getRouteDest().equals(XpsGlobalConstants.SWIFT_ROUTE)) {
						MessageKey messageKey = transformSettleMethodToMessageKey(settleMethod);
						if(settleMethod.getRouteDest().equals(XpsGlobalConstants.EMAIL_ROUTE)){
							AdvicePreview advice = null;
							Map<String, Object> params = new HashMap<String, Object>();
							params.put("bdo", details);
							params.put("ChargeMaster", bdo.getChargeStructRec());
							params.put("module", bdo.getChargeStructRec().getDomain());
							params.put("payRec", bdo.getChargeStructRec().getPayRec());
							params.put("settleMethod", settleMethod.getPublicKey());
							params.put("viaChargeSettlement", true);
							params.put("viaSettleMethod", true);
							params.put("isPreview", true);
							params.put("isJsonParams", false);
							try {
								advice = generateEmailPreview(params);
								//destinationAddress = msgQueueUtil.getDestinationAddress(null, qParams.get("refNo").toString(), messageKey, qParams.get("instrumentType").toString(), qParams.get("instrumentSubType").toString(), qParams);
							} catch (CbsServiceProcessException e) {
								continue;
							}
							//how to get tranKey???
							messageQueueService.createMessageQueueEntry(advice, null, bdo.getChargeStructRec().getDomain(), details.getInternalKey(), bdo.getChargeStructRec().getRefNo(), "ZST", 
									bdo.getSettlementStructRec().getSettleDate(), settleMethod.getRouteDest(), bdo.getChargeStructRec().getBookBranch(), null, seqNo, advice.getRecipients(), null);
						} else {
							Map<String, Object> params = new HashMap<String, Object>();
							params.put("bdo", details);
							params.put("ChargeMaster", bdo.getChargeStructRec());
							params.put("module", bdo.getChargeStructRec().getDomain());
							params.put("payRec", bdo.getChargeStructRec().getPayRec());
							params.put("settleMethod", settleMethod.getPublicKey());
							params.put("viaChargeSettlement", true);
							params.put("viaSettleMethod", true);
							params.put("isPreview", true);
							params.put("isJsonParams", false);
							DmsFile document = null;
							try {
								document = generateAdvice(params);
								destinationAddress = chargeUtility.getDestinationAddress(bdo.getChargeStructRec().getDomain(), null, bdo.getChargeStructRec().getRefNo(), messageKey, bdo.getChargeStructRec().getInstrumentType(), bdo.getChargeStructRec().getDomainType(), new HashMap<String, Object>());
							} catch (CbsServiceProcessException e) {
								continue;
							}
							messageQueueService.createMessageQueueEntry(null, document, bdo.getChargeStructRec().getDomain(), details.getInternalKey(), bdo.getChargeStructRec().getRefNo(), "ZST", 
									bdo.getSettlementStructRec().getSettleDate(), settleMethod.getRouteDest(), bdo.getChargeStructRec().getBookBranch(), null, seqNo, destinationAddress, null);
						}
					}
				}
			}
		}
	}

	private MessageKey transformSettleMethodToMessageKey(SettleMethod settleMethod){
		MessageKey msgKey = jaxbSdoHelper.createSdoInstance(MessageKey.class);
		msgKey.setReceiverClientType(settleMethod.getDestClientType());
		msgKey.setReceiverContactType(settleMethod.getRouteDest());
		msgKey.setReceiverContactSubType(settleMethod.getDestContactType());
		msgKey.setSenderContactType(settleMethod.getRouteSender());
		msgKey.setSenderContactSubType(settleMethod.getSendersContactType());
		msgKey.setFormat(settleMethod.getFormat());
		return msgKey;
	}

	@Override
	public Object extensionPreProcess(ChargeWithSettlement bdo) {

		if (bdo == null) {
			return null;
		}

		List<ChargeWithSettlement> chargeList = new ArrayList<>();
		chargeList.add(bdo);

		List<CommonAcctRestraintHolder> list = commonAcctRestraintUtil.collectDataForAcctRestraint(
				bdo.getChargeStructRec().getRefNo(), chargeList, getRegistry(bdo.getChargeStructRec().getDomain()), bdo.getChargeStructRec().getDomain());

		if (list != null && list.isEmpty()) return null;
		return list;
	}

	@Override
	public ChargeWithSettlement extensionPostProcess(Object listData, ChargeWithSettlement bdo) {
		if(listData == null) {
			return bdo;
		}
		List<CommonAcctRestraintHolder> list = (List<CommonAcctRestraintHolder>) listData;
		commonAcctRestraintUtil.updateAcctRestraintKey(bdo, list);
		return bdo;
	}

	@Override
	public void rejectPostProcessing(CbsBusinessDataObjectJpe dataObjectJpe) {
		ChargeWithSettlementJpe jpe = (ChargeWithSettlementJpe) dataObjectJpe;
		commonAcctRestraintUtil.performRestraintDelete(jpe, "ChargeWithSettlementService.create", "ChargeWithSettlement");
	}

	private String getRegistry(String domain){
		String registry = null;
		if(domain == null) {
			return null;
		}

		RegistryJpe jpe = registryRepository.find(metaCode(domain), FH_RESTRAINT_TYPE);
		if (jpe != null) {
			registry = jpe.getValueS();
		}

		return registry;
	}

	private String metaCode(String domain) {
		String metaCode = null;
		if (domain.matches(TFN)) {
			metaCode = TRADE_FINANCE_REGISTRY;
		} else if (domain.matches(BGT)) {
			metaCode = BANK_GUARANTEE_REGISTRY;
		}
		return metaCode;
	}

}
