package com.silverlakesymmetri.cbs.xps.svc.mapper.decorator;

import org.mapstruct.MappingTarget;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.ChargeFixedJpe;
import com.silverlakesymmetri.cbs.xps.svc.mapper.ChargeFixedServiceMapper;
import com.silverlakesymmetri.cbs.xps.xmlapi.XPSTRANCHARGEDETAILAPIType;

public abstract class ChargeFixedServiceDecorator implements ChargeFixedServiceMapper {
	
	@Autowired
	@Qualifier("delegate")
	protected ChargeFixedServiceMapper delegate;

	@Override
	public XPSTRANCHARGEDETAILAPIType mapToApi(ChargeFixedJpe jpe, @MappingTarget XPSTRANCHARGEDETAILAPIType api){
		delegate.mapToApi(jpe, api);
		return api;
	}
	
	@Override
	public ChargeFixedJpe mapToJpe(XPSTRANCHARGEDETAILAPIType api, @MappingTarget ChargeFixedJpe jpe){
		delegate.mapToJpe(api, jpe);
		return jpe;
	}

}


