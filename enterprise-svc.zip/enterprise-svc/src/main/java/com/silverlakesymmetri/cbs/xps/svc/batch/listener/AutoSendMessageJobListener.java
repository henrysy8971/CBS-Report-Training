package com.silverlakesymmetri.cbs.xps.svc.batch.listener;

import org.apache.commons.lang3.StringUtils;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobExecutionListener;
import org.springframework.beans.factory.annotation.Autowired;

import com.silverlakesymmetri.cbs.commons.batch.listener.CbsJobExecutionListener;
import com.silverlakesymmetri.cbs.commons.exception.base.CbsServiceException;
import com.silverlakesymmetri.cbs.commons.jpa.mapping.sdo.FileFormatOutJpe;
import com.silverlakesymmetri.cbs.commons.jpa.mapping.sdo.RegistryJpe;
import com.silverlakesymmetri.cbs.commons.jpa.mapping.sdo.id.FileFormatOutPk;
import com.silverlakesymmetri.cbs.commons.jpa.mapping.sdo.id.RegistryPk;
import com.silverlakesymmetri.cbs.commons.jpa.service.CbsBatchGenericDataService;
import com.silverlakesymmetri.cbs.commons.logging.CbsAppLogger;
import com.silverlakesymmetri.cbs.commons.logging.CbsAppLoggerFactory;
import com.silverlakesymmetri.cbs.xps.enums.XpsGlobalConstants;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.util.XpsStorHelper;
import com.silverlakesymmetri.cbs.xps.svc.batch.processor.MessageQueueListItemProcessor;

public class AutoSendMessageJobListener extends CbsJobExecutionListener implements JobExecutionListener {

	private static final String FILE_SEPARATOR = System.getProperty("file.separator");
	private static CbsAppLogger logger = CbsAppLoggerFactory.getLogger(AutoSendMessageJobListener.class);

	@Autowired
	protected CbsBatchGenericDataService batchDataService;
	@Autowired
	protected XpsStorHelper xpsStorHelper;

	@Override
	public void beforeJob(JobExecution exec) {
		super.beforeJob(exec);

		// add MessageQueueListItemProcessor field values for binding
		exec.getExecutionContext().put(MessageQueueListItemProcessor.SWIFT_SPOOL_DIRECTORY_ATTR,
				getSwiftSpoolDirectory());
		exec.getExecutionContext().put(MessageQueueListItemProcessor.SWIFT_MESSAGE_SEPARATOR_ATTR,
				getSwiftMessageSeparator());
	}

	@Override
	public void afterJob(JobExecution exec) {
		super.afterJob(exec);
	}

	private String getSwiftMessageSeparator() {
		String retVal = null;
		FileFormatOutJpe jpe = batchDataService.find(FileFormatOutJpe.class,
				new FileFormatOutPk(XpsGlobalConstants.SWIFT_FORMAT));
		if (jpe == null) {
			logger.warn("FileFormatOutJpe not found for format: {}", XpsGlobalConstants.SWIFT_FORMAT);
		} else {
			retVal = jpe.getSeparatorPattern();
		}

		if (StringUtils.isBlank(retVal)) {
			retVal = XpsGlobalConstants.DEFAULT_SWIFT_MSG_SEPARATOR;
		}

		return retVal;
	}

	private String getSwiftSpoolDirectory() {
		String dir = xpsStorHelper.getFileDir(XpsGlobalConstants.SWIFT_FORMAT, "SPOOL");
		if (StringUtils.isBlank(dir)) {
			dir = getXpsSpoolDir();
		}
		
		if (StringUtils.isBlank(dir)) {
			logger.warn("No SWIFT spool directory was retrieved!");
			return null;
		}
		
		if(FILE_SEPARATOR.equals("\\")){
			dir = dir.replaceAll("\\\\", "\\\\\\\\");
		}

		return dir;
	}

	private String getXpsSpoolDir() {
		RegistryPk pk = new RegistryPk("REGISTRY", "CROSS_MODULE_REGISTRY", "spoolDirectory", "spoolDirectory");
		RegistryJpe regJpe = batchDataService.find(RegistryJpe.class, pk);
		String dir = regJpe == null ? null : regJpe.getValueS();

		if (StringUtils.isBlank(dir)) {
			throw new CbsServiceException("Registry setup missing for CROSS_MODULE_REGISTRY~spoolDirectory");
		}

		return dir;
	}

}
