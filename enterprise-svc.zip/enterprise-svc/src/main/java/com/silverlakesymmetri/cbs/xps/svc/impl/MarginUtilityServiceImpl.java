package com.silverlakesymmetri.cbs.xps.svc.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.inject.Inject;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.silverlakesymmetri.cbs.commons.jpa.extension.JaxbSdoHelper;
import com.silverlakesymmetri.cbs.commons.jpa.service.CbsGenericDataService;
import com.silverlakesymmetri.cbs.commons.jpa.util.DateTimeHelper;
import com.silverlakesymmetri.cbs.commons.restlet.JsonConvertionManager;
import com.silverlakesymmetri.cbs.csd.util.CurrencyHelper;
import com.silverlakesymmetri.cbs.mcl.jpa.mapping.sdo.ClientJpe;
import com.silverlakesymmetri.cbs.mcl.jpa.mapping.sdo.util.MclJpeConstants;
import com.silverlakesymmetri.cbs.xps.bdo.sdo.MarginInstrumentInfo;
import com.silverlakesymmetri.cbs.xps.bdo.sdo.MarginUtilizationInfo;
import com.silverlakesymmetri.cbs.xps.bdo.sdo.MsgGrpDefQry;
import com.silverlakesymmetri.cbs.xps.bdo.sdo.MsgGrpTypeQry;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.MarginInstrumentInfoJpe;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.MarginUtilizationInfoJpe;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.MsgGrpDefQryJpe;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.MsgGrpTypeQryJpe;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.util.MarginMgrHelper;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.util.MarginMsgHelper;
import com.silverlakesymmetri.cbs.xps.svc.ChargesUtilityService;
import com.silverlakesymmetri.cbs.xps.svc.MarginUtilityService;

@Service
public class MarginUtilityServiceImpl implements MarginUtilityService {
	
	@Autowired
    protected JaxbSdoHelper jaxbSdoHelper;
	
	@Autowired
	private MarginMgrHelper marginMgrHelper;

	@Autowired
	private MarginMsgHelper marginMsgHelper;

	@Autowired(required = true)
    @Qualifier("cbsGenericDataService")
    protected CbsGenericDataService dataService;
	
    @Inject
    protected JsonConvertionManager jsonConversionMngr;

    @Autowired
    protected DateTimeHelper dateTimeHelper;
	
	@Autowired
	protected CurrencyHelper ccyHelper;
	
	@Autowired
	private ChargesUtilityService chargesUtility;


	@Override
	public MarginInstrumentInfo getMarginInstrumentInfo(Map<String, Object> params) {
		String domain = (String) params.get("domain");
		String instrumentType = (String) params.get("instrumentType");
		String refNo = (String) params.get("refNo");
		String type = (String) params.get("type");

		Long tranKey = null;
		if(refNo != null) {
			tranKey = chargesUtility.getTranKey(refNo, type, instrumentType);
		}
		MarginInstrumentInfoJpe jpe = marginMgrHelper.getMarginInstrumentInfo(domain, instrumentType, tranKey, type);
		if(jpe != null){
			Map<String, Object> parameters = new HashMap<String, Object>();
			if(jpe.getAgentClientId() != null){
				parameters.put("clientId", jpe.getAgentClientId());
				List<ClientJpe> clientList = dataService.findWithNamedQuery(MclJpeConstants.CLIENT_JPE_GET_CLIENT_FROM_ID, parameters, ClientJpe.class);
				if(clientList != null && clientList.size() > 0){
					jpe.setAgentClientNo(clientList.get(0).getClientNo());
				}
			}
			if(jpe.getCustomerClientId() != null){
				parameters.put("clientId", jpe.getCustomerClientId());
				List<ClientJpe> clientList = dataService.findWithNamedQuery(MclJpeConstants.CLIENT_JPE_GET_CLIENT_FROM_ID, parameters, ClientJpe.class);
				if(clientList != null && clientList.size() > 0){
					jpe.setCustomerClientNo(clientList.get(0).getClientNo());
				}
			}
			MarginInstrumentInfo bdo = jaxbSdoHelper.wrap(jpe, MarginInstrumentInfo.class);
			return bdo;
		}
		return null;
	}

	@Override
	public List<MsgGrpDefQry> getMsgGrpDefQryList(String domain, String msgGrp, String eventType, String prodType) {
    	List<MsgGrpDefQryJpe> jpel = marginMsgHelper.getMsgGrpDefList(domain, msgGrp, eventType, prodType);
    	
    	if (jpel != null && !jpel.isEmpty()){
    		List<MsgGrpDefQry> result  = new ArrayList<MsgGrpDefQry>();
    		for (MsgGrpDefQryJpe jpe : jpel){	
    			MsgGrpDefQry bdo = jaxbSdoHelper.createSdoInstance(MsgGrpDefQry.class);    			
    			bdo.setSenderContactType(jpe.getSenderContactType());
    			bdo.setSenderContactSubType(jpe.getSenderContactSubType());
    			bdo.setReceiverClientType(jpe.getReceiverClientType());
    			bdo.setReceiverContactType(jpe.getReceiverContactType());
    			bdo.setReceiverContactSubType(jpe.getReceiverContactSubType());
    			bdo.setFormat(jpe.getFormat());
    			bdo.setAdviceDays(jpe.getAdviceDays());
    			result.add(bdo);
    		}	
    		return result;
    	}
    	
    	return null;
	}

	@Override
	public List<MsgGrpTypeQry> getMsgGrpTypeQryList(String domain, String eventType, String prodType) {
    	List<MsgGrpTypeQryJpe> jpel = marginMsgHelper.getMsgGrpTypeList(domain, eventType, prodType);
    	
    	if (jpel != null && !jpel.isEmpty()){
    		List<MsgGrpTypeQry> result  = new ArrayList<MsgGrpTypeQry>();
    		for (MsgGrpTypeQryJpe jpe : jpel){	
    			MsgGrpTypeQry bdo = jaxbSdoHelper.createSdoInstance(MsgGrpTypeQry.class);
    			bdo.setMsgGrp(jpe.getMsgGrp());
    			bdo.setDescription(jpe.getDescription());
    			result.add(bdo);
    		}	
    		return result;
    	}

		return null;
	}
	
	public MarginUtilizationInfo getMarginUtilizationInfo(Long internalKey) {
		MarginUtilizationInfoJpe jpe = marginMgrHelper.getUtilizationInfo(internalKey);
		if(jpe != null){
			MarginUtilizationInfo bdo = jaxbSdoHelper.wrap(jpe, MarginUtilizationInfo.class);
			return bdo;
		}
		return null;
	}

}
