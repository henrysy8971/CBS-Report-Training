package com.silverlakesymmetri.cbs.swf.svc.impl;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.mysema.query.types.EntityPath;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.exception.CbsRuntimeException;
import com.silverlakesymmetri.cbs.commons.jpa.entity.FindCriteriaJpe;
import com.silverlakesymmetri.cbs.commons.svc.AbstractBusinessService;
import com.silverlakesymmetri.cbs.swf.bdo.sdo.BankCodeQry;
import com.silverlakesymmetri.cbs.swf.jpa.mapping.sdo.BankCodeQryJpe;
import com.silverlakesymmetri.cbs.swf.jpa.mapping.sdo.SwfMsgFormatQryJpe;
import com.silverlakesymmetri.cbs.swf.jpa.mapping.sdo.id.BankCodeQryPk;
import com.silverlakesymmetri.cbs.swf.svc.BankCodeQryService;
import com.silverlakesymmetri.cbs.swf.jpa.mapping.sdo.QBankCodeQryJpe;

@Service
@Transactional
public class BankCodeQryServiceImpl
		extends AbstractBusinessService<BankCodeQry, BankCodeQryJpe, BankCodeQryPk>
		implements BankCodeQryService {

	@Override
	public Long count(FindCriteria findCriteria, CbsHeader cbsHeader) {
        if (findCriteria == null) {
            return dataService.getRowCount(this.getEntityPath());
        } else {
            FindCriteriaJpe fc = jaxbSdoHelper.unwrap(findCriteria);
            return dataService.getRowCount(SwfMsgFormatQryJpe.class, fc);
        }
	}

	@Override
	protected BankCodeQryPk getIdFromDataObjectInstance(BankCodeQry bdo) {
		BankCodeQryPk pk = new BankCodeQryPk(bdo.getRecordKey());
		return pk;
	}

	@Override
	protected EntityPath<BankCodeQryJpe> getEntityPath() {
		 return QBankCodeQryJpe.bankCodeQryJpe;
	}

	@Override
	public BankCodeQry create(BankCodeQry dataObject) {
		throw new CbsRuntimeException("Create operation is not supported by this service");
	}

	@Override
	public BankCodeQry update(BankCodeQry dataObject) {
		throw new CbsRuntimeException("Update operation is not supported by this service");
	}

	@Override
	public boolean delete(BankCodeQry dataObject) {
		throw new CbsRuntimeException("Delete operation is not supported by this service");
	}

	@Override
	public List<BankCodeQry> query(int offset, int resultLimit, String groupBy, String order,
			Map<String, Object> filters) {
		return super.query(offset, resultLimit, groupBy, order, filters);
	}

	@Override
	public List<BankCodeQry> find(FindCriteria findCriteria, CbsHeader cbsHeader) {
		return super.find(findCriteria, cbsHeader);
	}

	@Override
	public BankCodeQry getByPk(String publicKey, BankCodeQry reference) {
		return super.getByPk(publicKey, reference);
	}

}
