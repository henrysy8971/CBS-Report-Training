package com.silverlakesymmetri.cbs.xps.svc.mapper;

import org.mapstruct.Context;
import org.mapstruct.DecoratedWith;
import org.mapstruct.InheritInverseConfiguration;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingTarget;
import org.mapstruct.Mappings;

import com.silverlakesymmetri.cbs.commons.jpa.util.DateTimeHelper;
import com.silverlakesymmetri.cbs.commons.xmlapi.enums.CbsXmlApiOperation;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.ChargeWithSettlementJpe;
import com.silverlakesymmetri.cbs.xps.svc.mapper.decorator.ChargeWithSettlementServiceDecorator;
import com.silverlakesymmetri.cbs.xps.xmlapi.XPSTRANCHARGEWITHSETTLEAPIType;

@Mapper(uses={ DateTimeHelper.class })
@DecoratedWith(ChargeWithSettlementServiceDecorator.class)
public interface ChargeWithSettlementServiceMapper {

	@Mappings({
		@Mapping(expression = "java(oper != null ? oper.getOperation() : null)", target="OPERATION")
	})
	public XPSTRANCHARGEWITHSETTLEAPIType mapToApi(ChargeWithSettlementJpe jpe, @Context CbsXmlApiOperation oper);

	@InheritInverseConfiguration(name = "mapToApi")
	public ChargeWithSettlementJpe mapToJpe(XPSTRANCHARGEWITHSETTLEAPIType api, @MappingTarget ChargeWithSettlementJpe jpe);

	@InheritInverseConfiguration(name = "mapToApi")
	public ChargeWithSettlementJpe mapToJpe(XPSTRANCHARGEWITHSETTLEAPIType api);
}