package com.silverlakesymmetri.cbs.xps.svc.mapper.decorator;

import org.mapstruct.Context;
import org.mapstruct.MappingTarget;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

import com.silverlakesymmetri.cbs.commons.xmlapi.enums.CbsXmlApiOperation;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.ChargesJpe;
import com.silverlakesymmetri.cbs.xps.svc.mapper.ChargeServiceMapper;
import com.silverlakesymmetri.cbs.xps.xmlapi.XPSCHARGETYPEType;

public abstract class ChargeServiceDecorator implements ChargeServiceMapper {
	
	@Autowired
	@Qualifier("delegate")
	protected ChargeServiceMapper delegate;

	@Override
	public XPSCHARGETYPEType mapToApi(ChargesJpe jpe, @Context CbsXmlApiOperation oper){
		XPSCHARGETYPEType req = (XPSCHARGETYPEType) delegate.mapToApi(jpe, oper);
		return  req;
	}
	
	@Override
	public ChargesJpe mapToJpe(XPSCHARGETYPEType api, @MappingTarget ChargesJpe jpe){
		delegate.mapToJpe(api, jpe);
		return jpe;
	}

}


