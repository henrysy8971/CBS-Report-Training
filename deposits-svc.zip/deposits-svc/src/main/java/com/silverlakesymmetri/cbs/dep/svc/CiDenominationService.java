package com.silverlakesymmetri.cbs.dep.svc;

import java.util.List;
import java.util.Map;

import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation;
import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation.ServiceOperationType;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.svc.BusinessService;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.CiDenomination;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.CiDenominationJpe;


public interface CiDenominationService extends BusinessService<CiDenomination, CiDenominationJpe> {

    public static final String SVC_OP_NAME_CIDENOMINATION_GET = "CiDenominationService.get";
    public static final String SVC_OP_NAME_CIDENOMINATION_CREATE = "CiDenominationService.create";
    public static final String SVC_OP_NAME_CIDENOMINATION_UPDATE = "CiDenominationService.update";
    public static final String SVC_OP_NAME_CIDENOMINATION_DELETE = "CiDenominationService.delete";
    public static final String SVC_OP_NAME_CIDENOMINATION_QUERY = "CiDenominationService.query";
    public static final String SVC_OP_NAME_CIDENOMINATION_FIND = "CiDenominationService.find";

    @ServiceOperation(name = SVC_OP_NAME_CIDENOMINATION_GET, type = ServiceOperationType.GET)
    public CiDenomination getByPk(String publicKey, CiDenomination reference);
    
    @ServiceOperation(name = SVC_OP_NAME_CIDENOMINATION_CREATE)
    public CiDenomination create(CiDenomination objectInstanceIdentifier);
    
    @ServiceOperation(name = SVC_OP_NAME_CIDENOMINATION_UPDATE)
    public CiDenomination update(CiDenomination objectInstanceIdentifier);
    
    @ServiceOperation(name = SVC_OP_NAME_CIDENOMINATION_DELETE)
    public boolean delete(CiDenomination objectInstanceIdentifier);
    
    @ServiceOperation(name = SVC_OP_NAME_CIDENOMINATION_QUERY)
    public List<CiDenomination> query(int offset, int resultLimit, String groupBy, String order, Map<String, Object> filters);

    @ServiceOperation(name = SVC_OP_NAME_CIDENOMINATION_FIND)
    public List<CiDenomination> find(FindCriteria findCriteria, CbsHeader cbsHeader);


}
