package com.silverlakesymmetri.cbs.dep.svc.impl;

import com.mysema.query.types.EntityPath;
import com.mysema.query.types.Predicate;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.svc.AbstractBusinessService;
import com.silverlakesymmetri.cbs.commons.svc.BusinessObjectValidationCapable;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.FinTranMsgsQry;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.FinTranMsgsQryJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.FinTranRestraintsQryJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.QFinTranMsgsQryJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.QFinTranRestraintsQryJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.TranDefJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.util.DepJpeConstants;
import com.silverlakesymmetri.cbs.dep.svc.FinTranMsgsQryService;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class FinTranMsgsQryServiceImpl extends AbstractBusinessService<FinTranMsgsQry, FinTranMsgsQryJpe, String>
        implements FinTranMsgsQryService, BusinessObjectValidationCapable<FinTranMsgsQry> {

    private static final String TRAN_DEF_CRDRMAINTIND_DEBIT = "D";
    private static final String TRAN_DEF_CRDRMAINTIND_CREDIT = "C";
    private static final String TRAN_DEF_CASHTRAN_N = "N";
    private static final String TRAN_DEF_CASHTRAN_Y = "Y";
    private static final String TRAN_RESTRAINT_INFO = "IN";
    private static final String TRAN_RESTRAINT_ACCOUNT_STOPPED = "AS";
    private static final String TRAN_RESTRAINT_FUNDS_HELD = "FH";
    private static final String TRAN_RESTRAINT_STOPPED_WITHDRAWAL = "SW";
    private static final String TRAN_RESTRAINT_CASH_TRANS_ONLY = "CO";
    private static final String TRAN_RESTRAINT_STOPPED_DEPOSIT = "SD";

    @Override
    protected String getIdFromDataObjectInstance(FinTranMsgsQry dataObject) {
        return "";
    }

    @Override
    protected EntityPath<FinTranMsgsQryJpe> getEntityPath() {
        return QFinTranMsgsQryJpe.finTranMsgsQryJpe;
    }

    @Override
    public FinTranMsgsQry getByPk(String publicKey, FinTranMsgsQry reference) {
        FinTranMsgsQry sdo = jaxbSdoHelper.createSdoInstance(FinTranMsgsQry.class);
        return sdo;
    }

    @Override
    public List<FinTranMsgsQry> query(int offset, int resultLimit, String groupBy, String order, Map<String, Object> filters) {
        List<FinTranMsgsQry> result = new ArrayList<>();
        return result;
    }

    @Override
    public List<FinTranMsgsQry> find(FindCriteria findCriteria, CbsHeader cbsHeader) {
        return super.find(findCriteria, cbsHeader);
    }

    @Override
    public FinTranMsgsQry findFinTranRestraintsQry(FinTranMsgsQry reference) {
        Map<String, Object> acctNoParams = new HashMap<String, Object>();
        Map<String, Object> tranDefParams = new HashMap<String, Object>();
        acctNoParams.put("acctNo", reference.getAcctNo());
        tranDefParams.put("tranType", reference.getTranType());
        Long internalKey = dataService.getWithNamedQuery(DepJpeConstants.ACCT_JPE_FIND_INTERNAL_KEY_BY_ACCT_NO, acctNoParams,
                Long.class);
        TranDefJpe tranDef = dataService.getWithNamedQuery(DepJpeConstants.TRAN_DEF_JPE_BY_TRAN_TYPE, tranDefParams, TranDefJpe.class);

        List<FinTranRestraintsQryJpe> finTranRestraintsQryList = new ArrayList<>();
        List<String> restraintClass = new ArrayList<>();
        FinTranMsgsQryJpe finTranMsgsQryJpe = jaxbSdoHelper.unwrap(reference);

        if(tranDef != null) {
            if (TRAN_DEF_CRDRMAINTIND_DEBIT.equalsIgnoreCase(tranDef.getCrDrMaintInd())) {
                if (TRAN_DEF_CASHTRAN_Y.equalsIgnoreCase(tranDef.getCashTran())) {
                    restraintClass.add(TRAN_RESTRAINT_INFO);
                    restraintClass.add(TRAN_RESTRAINT_ACCOUNT_STOPPED);
                    restraintClass.add(TRAN_RESTRAINT_FUNDS_HELD);
                    restraintClass.add(TRAN_RESTRAINT_STOPPED_WITHDRAWAL);
                    Predicate p = QFinTranRestraintsQryJpe.finTranRestraintsQryJpe.internalKey.eq(internalKey).and(QFinTranRestraintsQryJpe.finTranRestraintsQryJpe.restraintClass.in(restraintClass));
                    finTranRestraintsQryList = dataService.query(QFinTranRestraintsQryJpe.finTranRestraintsQryJpe, p);
                } else if (TRAN_DEF_CASHTRAN_N.equalsIgnoreCase(tranDef.getCashTran())) {
                    restraintClass.add(TRAN_RESTRAINT_INFO);
                    restraintClass.add(TRAN_RESTRAINT_ACCOUNT_STOPPED);
                    restraintClass.add(TRAN_RESTRAINT_FUNDS_HELD);
                    restraintClass.add(TRAN_RESTRAINT_STOPPED_WITHDRAWAL);
                    restraintClass.add(TRAN_RESTRAINT_CASH_TRANS_ONLY);
                    Predicate p = QFinTranRestraintsQryJpe.finTranRestraintsQryJpe.internalKey.eq(internalKey).and(QFinTranRestraintsQryJpe.finTranRestraintsQryJpe.restraintClass.in(restraintClass));
                    finTranRestraintsQryList = dataService.query(QFinTranRestraintsQryJpe.finTranRestraintsQryJpe, p);
                }
            } else if (TRAN_DEF_CRDRMAINTIND_CREDIT.equalsIgnoreCase(tranDef.getCrDrMaintInd())) {
                if (TRAN_DEF_CASHTRAN_Y.equalsIgnoreCase(tranDef.getCashTran())) {
                    restraintClass.add(TRAN_RESTRAINT_INFO);
                    restraintClass.add(TRAN_RESTRAINT_ACCOUNT_STOPPED);
                    restraintClass.add(TRAN_RESTRAINT_STOPPED_DEPOSIT);
                    Predicate p = QFinTranRestraintsQryJpe.finTranRestraintsQryJpe.internalKey.eq(internalKey).and(QFinTranRestraintsQryJpe.finTranRestraintsQryJpe.restraintClass.in(restraintClass));
                    finTranRestraintsQryList = dataService.query(QFinTranRestraintsQryJpe.finTranRestraintsQryJpe, p);
                } else if (TRAN_DEF_CASHTRAN_N.equalsIgnoreCase(tranDef.getCashTran())) {
                    restraintClass.add(TRAN_RESTRAINT_INFO);
                    restraintClass.add(TRAN_RESTRAINT_ACCOUNT_STOPPED);
                    restraintClass.add(TRAN_RESTRAINT_STOPPED_DEPOSIT);
                    restraintClass.add(TRAN_RESTRAINT_CASH_TRANS_ONLY);
                    Predicate p = QFinTranRestraintsQryJpe.finTranRestraintsQryJpe.internalKey.eq(internalKey).and(QFinTranRestraintsQryJpe.finTranRestraintsQryJpe.restraintClass.in(restraintClass));
                    finTranRestraintsQryList = dataService.query(QFinTranRestraintsQryJpe.finTranRestraintsQryJpe, p);
                }
            }
        }
        finTranMsgsQryJpe.setFinTranRestraintsQryList(finTranRestraintsQryList);
        return jaxbSdoHelper.wrap(finTranMsgsQryJpe);
    }
}
