package com.silverlakesymmetri.cbs.dep.svc;

import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.svc.BusinessService;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.CiAdministration;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.CiAdministrationJpe;

import java.util.List;
import java.util.Map;

/**
 * Created by Emerson.Sanchez on 22/3/2019.
 */
public interface ChequeAdministrationService extends BusinessService<CiAdministration, CiAdministrationJpe> {

    public static final String SVC_OP_NAME_CIADMINISTRATIONSERVICE_GET = "ChequeAdministrationService.get";
    public static final String SVC_OP_NAME_CIADMINISTRATIONSERVICE_QUERY = "ChequeAdministrationService.query";
    public static final String SVC_OP_NAME_CIADMINISTRATIONSERVICE_CREATE = "ChequeAdministrationService.create";
    public static final String SVC_OP_NAME_CIADMINISTRATIONSERVICE_UPDATE = "ChequeAdministrationService.update";
    public static final String SVC_OP_NAME_CIADMINISTRATIONSERVICE_DELETE = "ChequeAdministrationService.delete";
    public static final String SVC_OP_NAME_CIADMINISTRATIONSERVICE_FIND = "ChequeAdministrationService.find";
    public static final String SVC_OP_NAME_CIADMINISTRATIONSERVICE_COUNT = "ChequeAdministrationService.count";

    @ServiceOperation(name = SVC_OP_NAME_CIADMINISTRATIONSERVICE_GET, type = ServiceOperation.ServiceOperationType.GET)
    public CiAdministration getByPk(String publicKey, CiAdministration reference);

    @ServiceOperation(name = SVC_OP_NAME_CIADMINISTRATIONSERVICE_CREATE)
    public CiAdministration create(CiAdministration dataObject);

    @ServiceOperation(name = SVC_OP_NAME_CIADMINISTRATIONSERVICE_UPDATE)
    public CiAdministration update(CiAdministration dataObject);

    @ServiceOperation(name = SVC_OP_NAME_CIADMINISTRATIONSERVICE_QUERY)
    public List<CiAdministration> query(int offset, int resultLimit, String groupBy, String order,
                                        Map<String, Object> filters);

    @ServiceOperation(name = SVC_OP_NAME_CIADMINISTRATIONSERVICE_DELETE)
    public boolean delete(CiAdministration dataObject);

    @ServiceOperation(name = SVC_OP_NAME_CIADMINISTRATIONSERVICE_FIND)
    public List<CiAdministration> find(FindCriteria findCriteria, CbsHeader cbsHeader);

    @ServiceOperation(name = SVC_OP_NAME_CIADMINISTRATIONSERVICE_COUNT, type = ServiceOperation.ServiceOperationType.GET)
    public Long count(FindCriteria findCriteria, CbsHeader cbsHeader);
}
