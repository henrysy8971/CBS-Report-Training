package com.silverlakesymmetri.cbs.dep.svc.mapper.mapping;

import com.silverlakesymmetri.cbs.commons.jpa.util.DateTimeHelper;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.AcctInterestProjectionJpe;
import com.silverlakesymmetri.cbs.dep.xmlapi.DEPINTPROJECTIONAPIType;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Mappings;

@Mapper(uses = {DateTimeHelper.class})
public interface AcctInterestProjectionToDEPINTPROJECTIONAPITypeMapper {

    @Mappings({
            @Mapping(source = "internalKey", target = "INTERNALKEY"),
            @Mapping(source = "intEndDate", target = "INTENDDATE", qualifiedByName = {"DateTimeHelper","convertDateToCbsXmlApiDate"}),
            @Mapping(source = "crIntProj", target = "CRINTPROJ"),
            @Mapping(source = "crIntAdjProj", target = "CRINTADJPROJ"),
            @Mapping(source = "drIntProj", target = "DRINTPROJ"),
            @Mapping(source = "drIntAdjProj", target = "DRINTADJPROJ")
    })
    public DEPINTPROJECTIONAPIType mapAcctInterestProjectionToDEPINTPROJECTIONAPITypeMapper(AcctInterestProjectionJpe jpe);

}
