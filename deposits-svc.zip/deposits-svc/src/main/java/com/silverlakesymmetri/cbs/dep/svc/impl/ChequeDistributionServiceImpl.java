package com.silverlakesymmetri.cbs.dep.svc.impl;

import com.mysema.query.types.EntityPath;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.jpa.listener.Auditor;
import com.silverlakesymmetri.cbs.commons.jpa.util.BdoHelperJpaImpl;
import com.silverlakesymmetri.cbs.commons.svc.AbstractXmlApiBusinessService;
import com.silverlakesymmetri.cbs.commons.util.AbstractBdoPublicKeyResolverImpl;
import com.silverlakesymmetri.cbs.commons.xmlapi.enums.CbsXmlApiOperation;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.CiRdBunchDist;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.CiRdBunchCaptureJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.CiRdBunchDistJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.QCiRdBunchDistJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.id.CiRdBunchDistPk;
import com.silverlakesymmetri.cbs.dep.svc.ChequeDistributionService;
import com.silverlakesymmetri.cbs.dep.svc.mapper.ChequeDistributionServiceMapper;
import com.silverlakesymmetri.cbs.dep.xmlapi.DEPCIRDAPIType;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;
import java.util.Optional;

@Service
public class ChequeDistributionServiceImpl extends 
									AbstractXmlApiBusinessService<CiRdBunchDist, CiRdBunchDistJpe, CiRdBunchDistPk,  DEPCIRDAPIType, DEPCIRDAPIType>  
									implements ChequeDistributionService{
	
	@Autowired
	ChequeDistributionServiceMapper mapper;
	
	@Override
	protected DEPCIRDAPIType transformBdoToXmlApiRqUpdate(CiRdBunchDist dataObject) {
		// TODO Auto-generated method stub
		return transformCiRdRegToDEPCIRDAPIType( dataObject, CbsXmlApiOperation.UPDATE);
	}

	@Override
	protected CiRdBunchDist processXmlApiRs(CiRdBunchDist dataObject, DEPCIRDAPIType xmlApiRs) {
		// TODO Auto-generated method stub
//		CiRdBunchDist jpe = jaxbSdoHelper.unwrap(dataObject);
//		jpe = mapper.mapToJpe(xmlApiRs, jpe);
//		return jaxbSdoHelper.wrap(jpe);
		return dataObject;
	}

	@Override
	protected Class<DEPCIRDAPIType> getXmlApiResponseClass() {
		// TODO Auto-generated method stub
		return DEPCIRDAPIType.class;
	}

	@Override
	protected CiRdBunchDistPk getIdFromDataObjectInstance(CiRdBunchDist dataObject) {
		// TODO Auto-generated method stub
		CiRdBunchDistJpe jpe = jaxbSdoHelper.unwrap(dataObject);
		return new CiRdBunchDistPk(jpe.getChequeRdKey(), jpe.getDenomination(), jpe.getCcy(), jpe.getStartNo(), jpe.getEndNo());
	}

	@Override
	protected EntityPath<CiRdBunchDistJpe> getEntityPath() {
		// TODO Auto-generated method stub
		return QCiRdBunchDistJpe.ciRdBunchDistJpe;
	}

	@Override
	public CiRdBunchDist getByPk(String publicKey, CiRdBunchDist reference) {
		// TODO Auto-generated method stub
		return super.getByPk(publicKey, reference);
	}

	@Override
	public CiRdBunchDist update(CiRdBunchDist header) {
		// TODO Auto-generated method stub
		header = super.update(header);

		if (header.getCiRdBunchCaptureList() == null || header.getCiRdBunchCaptureList().isEmpty()){
			return header;
		}

		//why? after a successful distribution replace the first item in list to header
		//so the when UI would auto-getByPk it will be successful
		CiRdBunchDistJpe jpe = unwrap(header);
		CiRdBunchCaptureJpe rbc = jpe.getCiRdBunchCaptureList().stream().findFirst().get();

		CiRdBunchDistJpe rbd = new CiRdBunchDistJpe();
		rbd.setChequeRdKey(rbc.getChequeRdKey());
		rbd.setDenomination(rbc.getDenomination());
		rbd.setCcy(rbc.getCcy());
		rbd.setChequeType(rbc.getChequeType());
		rbd.setBranch(rbc.getNewBranch());
		rbd.setStartNo(rbc.getStartNo());
		rbd.setEndNo(rbc.getEndNo());
		AbstractBdoPublicKeyResolverImpl bdoPublicKeyResolver = (BdoHelperJpaImpl) getBdoHelper();
		rbd.setPublicKey(bdoPublicKeyResolver.createPublicKey(rbd));
		return wrap(rbd);
	}

	@Override
	public List<CiRdBunchDist> query(int offset, int resultLimit, String groupBy, String order,
			Map<String, Object> filters) {
		// TODO Auto-generated method stub
		return super.query(offset, resultLimit, groupBy, order, filters);
	}

	@Override
	public List<CiRdBunchDist> find(FindCriteria findCriteria, CbsHeader cbsHeader) {
		// TODO Auto-generated method stub
		return super.find(findCriteria, cbsHeader);
	}
		
	private DEPCIRDAPIType transformCiRdRegToDEPCIRDAPIType(CiRdBunchDist dataObject, CbsXmlApiOperation oper){
				
		CiRdBunchDistJpe jpe = jaxbSdoHelper.unwrap(dataObject);
		DEPCIRDAPIType api =  mapper.mapToApi(jpe, oper);
		super.setTechColsFromDataObject(dataObject, api);
				
		return api;
	}
	
	@Autowired
	private Auditor auditor;
		
	protected CiRdBunchDist preUpdateObject(CiRdBunchDist dataObject) {
		
		CiRdBunchDistJpe jpe = unwrap(dataObject);
		auditor.preUpdateCallback(jpe);
		return wrap(jpe);
	}

	@Override
	protected DEPCIRDAPIType transformBdoToXmlApiRqCreate(CiRdBunchDist dataObject) {
		// TODO Auto-generated method stub
		return null;
	}
	
	@Override
	protected DEPCIRDAPIType transformBdoToXmlApiRqDelete(CiRdBunchDist dataObject) {
		// TODO Auto-generated method stub
		return null;
	}
	
	@Override
	protected List<CiRdBunchDist> processXmlApiListRs(CiRdBunchDist dataObject, DEPCIRDAPIType xmlApiRs) {
		// TODO Auto-generated method stub
		return null;
	}
	
}
