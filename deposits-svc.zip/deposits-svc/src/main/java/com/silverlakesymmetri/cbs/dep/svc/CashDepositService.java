package com.silverlakesymmetri.cbs.dep.svc;

import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation;
import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation.ServiceOperationType;
import com.silverlakesymmetri.cbs.commons.svc.BusinessService;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.DepositTransaction;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.DepositTransactionJpe;

public interface CashDepositService extends BusinessService<DepositTransaction, DepositTransactionJpe> {


    public static final String SVC_OP_NAME_CASHDEPOSITSERVICE_POSTTRANSACTION = "CashDepositService.postTransaction";
    public static final String SVC_OP_NAME_CASHDEPOSITSERVICE_GET = "CashDepositService.get";

    @ServiceOperation(name = SVC_OP_NAME_CASHDEPOSITSERVICE_POSTTRANSACTION,  type = ServiceOperationType.CREATE)
    public DepositTransaction postTransaction(DepositTransaction dataObject);
    
	@ServiceOperation(name = SVC_OP_NAME_CASHDEPOSITSERVICE_GET, type = ServiceOperationType.GET)
    public DepositTransaction getByPk(String publicKey, DepositTransaction reference);

}
