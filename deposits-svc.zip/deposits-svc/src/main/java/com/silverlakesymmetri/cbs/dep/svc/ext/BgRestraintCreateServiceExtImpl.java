package com.silverlakesymmetri.cbs.dep.svc.ext;

import com.silverlakesymmetri.cbs.commons.logging.CbsAppLogger;
import com.silverlakesymmetri.cbs.commons.logging.CbsAppLoggerFactory;
import com.silverlakesymmetri.cbs.xps.svc.util.ReleaseAcctRestraintCapable;
import org.springframework.stereotype.Service;

@Service
public class BgRestraintCreateServiceExtImpl extends AbstractBgtAcctRestraintServiceExtImpl implements ReleaseAcctRestraintCapable {

	private static CbsAppLogger logger = CbsAppLoggerFactory.getLogger(BgRestraintCreateServiceExtImpl.class.getName());
	

	@Override
	public String[] getExtendedBdoNames() {
		return new String[] {
			"BgAdviseAmend",
			"BgIssueAmend",
			"BgAdviseBca",
			"BgAdviseBcc",
			"BgAdviseCancel",
			"BgIssueCancel",
			"BgIssueBca",
			"BgIssueBcc",
			"BgAdviseExpiry",
			"BgIssueExpiry",
			"BgAdviseClaim",
			"BgIssueClaim",
            "BgIssue",
			"BgAdvise",
            "BgIssueReactivate",
            "BgAdviseReactivate",
            "BgAdviseReceipt",
            "BgIssueReceipt"
		};
	}

    @Override
	public String[] getExtendedServiceNames() {
		return new String[] {
			"BgAdviseAmendService.create",
			"BgIssueAmendService.create",
			"BgAdviseBcaService.update",
			"BgAdviseBccService.update",
			"BgAdviseCancelService.create",
			"BgIssueCancelService.create",
			"BgIssueBcaService.create",
			"BgIssueBccService.create",
			"BgAdviseExpiryService.create",
			"BgIssueExpiryService.create",
			"BgAdviseClaimService.create",
			"BgIssueClaimService.create",
            "BgIssueService.create",
			"BgAdviseService.create",
            "BgIssueReactivateService.create",
            "BgAdviseReactivateService.create",
            "BgAdviseReceiptService.create",
            "BgIssueReceiptService.create"
		};
	}

    protected CbsAppLogger getLogger() {
    	return logger;
    }
}
