package com.silverlakesymmetri.cbs.dep.svc.impl;

import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.mysema.query.types.EntityPath;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.svc.AbstractBusinessService;
import com.silverlakesymmetri.cbs.commons.svc.BusinessObjectValidationCapable;
import com.silverlakesymmetri.cbs.commons.svc.ref.ReferenceNumberGeneratorService;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.AtmTranMap;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.AtmTranMapJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.QAtmTranMapJpe;
import com.silverlakesymmetri.cbs.dep.svc.AtmTranMapService;


@Service
@Transactional
public class AtmTranMapServiceImpl extends AbstractBusinessService<AtmTranMap, AtmTranMapJpe, String> implements AtmTranMapService, BusinessObjectValidationCapable<AtmTranMap>{

	@Autowired
    private ReferenceNumberGeneratorService referenceNumberGeneratorService;

	@Override
	protected EntityPath<AtmTranMapJpe> getEntityPath() {
		return QAtmTranMapJpe.atmTranMapJpe;
	}

	@Override
	protected String getIdFromDataObjectInstance(AtmTranMap dataObject) {
		return dataObject.getAtmTranMapRefNo();
	}
	
	@Override
	public AtmTranMap get(AtmTranMap objectInstanceIdentifier) {
		return super.get(objectInstanceIdentifier);
	}
	
	@Override
	public List<AtmTranMap> query(int offset, int resultLimit, String groupBy, String order, Map<String, Object> filters){
		return super.query(offset, resultLimit, groupBy, order, filters);
	}
	
	@Override
	public AtmTranMap create(AtmTranMap dataObject) {
		return super.create(dataObject);
	}
	
	@Override
	public AtmTranMap update(AtmTranMap dataObject) {
		return super.update(dataObject);
	}
	
	@Override
	public boolean delete(AtmTranMap dataObject) {
		return super.delete(dataObject);
	}
	
	@Override
	public List<AtmTranMap> find(FindCriteria findCriteria, CbsHeader cbsHeader){
		return super.find(findCriteria, cbsHeader);
	}
	
	@Override
	public AtmTranMap getByPk(String publicKey, AtmTranMap reference) {
		return super.getByPk(publicKey, reference);
	}
	
	@Override
	protected AtmTranMap preCreateValidation(AtmTranMap dataObject) {
		if (StringUtils.isBlank(dataObject.getAtmTranMapRefNo())) {
			referenceNumberGeneratorService.getNewRefNo(dataObject, "atmTranMapRefNo");
		}
		return super.preCreateValidation(dataObject);
	}

}
