package com.silverlakesymmetri.cbs.dep.svc;

import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation;
import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation.ServiceOperationType;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.bdo.sdo.DmsFile;
import com.silverlakesymmetri.cbs.commons.svc.BusinessService;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.Acct;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.AcctJpe;
import com.silverlakesymmetri.cbs.xps.bdo.sdo.AdvicePreview;

import java.util.List;
import java.util.Map;

public interface AcctService extends BusinessService<Acct, AcctJpe> {
	public static final String SVC_OP_NAME_ACCTSERVICE_GET= "AcctService.get";
	public static final String SVC_OP_NAME_ACCTSERVICE_QUERY= "AcctService.query";
	public static final String SVC_OP_NAME_ACCTSERVICE_CREATE= "AcctService.create";
	public static final String SVC_OP_NAME_ACCTSERVICE_UPDATE= "AcctService.update";
	public static final String SVC_OP_NAME_ACCTSERVICE_DELETE= "AcctService.delete";
	public static final String SVC_OP_NAME_ACCTSERVICE_FIND= "AcctService.find";
	public static final String SVC_OP_NAME_ACCTSERVICE_COUNT = "AcctService.count";
	public static final String SVC_OP_NAME_ACCTSERVICE_GENERATEDOC = "AcctService.generateLetterOfThanks";
    public static final String SVC_OP_NAME_ACCTSERVICE_FIND_DISTINCT_FROM_ACCT_NO = "AcctService.findDistinctFromAcctNo";
    public static final String SVC_OP_NAME_ACCTSERVICE_FIND_DISTINCT_TO_ACCT_NO = "AcctService.findDistinctToAcctNo";
    public static final String SVC_OP_NAME_ACCTSERVICE_FIND_OWN_ACCT_AND_JOINT_ACCT = "AcctService.findOwnAcctAndJointAcct";
    public static final String SVC_OP_NAME_ACCTSERVICE_FIND_CASA_ACCT_BY_ACCTNO_ACCTDESC_OR_CLIENTNO = "AcctService.findCasaAcctByAcctNoAcctDescOrClientNo";
	public static final String SVC_OP_NAME_ACCTSERVICE_SEND_INTIMATIONLETTER = "AcctService.sendIntimationLetter";

	@ServiceOperation(name = SVC_OP_NAME_ACCTSERVICE_CREATE)
    public Acct create(Acct dataObject);

    @ServiceOperation(name = SVC_OP_NAME_ACCTSERVICE_UPDATE)
    public Acct update(Acct dataObject);

    @ServiceOperation(name = SVC_OP_NAME_ACCTSERVICE_DELETE)
    public boolean delete(Acct dataObject);

    @ServiceOperation(name = SVC_OP_NAME_ACCTSERVICE_QUERY)
    public List<Acct> query(int offset, int resultLimit, String groupBy, String order, Map<String, Object> filters);

    @ServiceOperation(name = SVC_OP_NAME_ACCTSERVICE_FIND)
    public List<Acct> find(FindCriteria findCriteria, CbsHeader cbsHeader);

    @ServiceOperation(name = SVC_OP_NAME_ACCTSERVICE_GET, type = ServiceOperationType.GET)
    public Acct getByPk(String publicKey, Acct reference);

	@ServiceOperation(name = SVC_OP_NAME_ACCTSERVICE_COUNT, type = ServiceOperationType.GET)
	public Long count(FindCriteria findCriteria, CbsHeader cbsHeader);

    @ServiceOperation(name = SVC_OP_NAME_ACCTSERVICE_FIND_DISTINCT_FROM_ACCT_NO, type = ServiceOperationType.READ, passParamAsMap = true)
    public List<Acct> findDistinctFromAcctNo(Map<String, Object> queryParams);

    @ServiceOperation(name = SVC_OP_NAME_ACCTSERVICE_FIND_DISTINCT_TO_ACCT_NO, type = ServiceOperationType.READ,
            passParamAsMap = true)
    public List<Acct> findDistinctToAcctNo(Map<String, Object> queryParams);
    
    @ServiceOperation(name = SVC_OP_NAME_ACCTSERVICE_FIND_OWN_ACCT_AND_JOINT_ACCT, type = ServiceOperationType.READ,
            passParamAsMap = true)
    public List<Acct> findOwnAcctAndJointAcct(Map<String, Object> queryParams);
    
    @ServiceOperation(name = SVC_OP_NAME_ACCTSERVICE_FIND_CASA_ACCT_BY_ACCTNO_ACCTDESC_OR_CLIENTNO, type = ServiceOperationType.READ,
            passParamAsMap = true)
    public List<Acct> findCasaAcctByAcctNoAcctDescOrClientNo(Map<String, Object> queryParams);

    @ServiceOperation(name = SVC_OP_NAME_ACCTSERVICE_GENERATEDOC)
    public DmsFile generateLetterOfThanks(String acctNo, String locale);
    
    @ServiceOperation(name = SVC_OP_NAME_ACCTSERVICE_SEND_INTIMATIONLETTER)
    public AdvicePreview sendIntimationLetter(String acctNo, String locale, boolean isPreview);

}
