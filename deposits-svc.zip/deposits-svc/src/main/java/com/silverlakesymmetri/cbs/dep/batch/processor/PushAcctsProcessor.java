package com.silverlakesymmetri.cbs.dep.batch.processor;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.beans.factory.annotation.Autowired;
import com.silverlakesymmetri.cbs.commons.jpa.service.CbsBatchGenericDataService;
import com.silverlakesymmetri.cbs.pdm.jpa.mapping.sdo.ContractTypeJpe;
import com.silverlakesymmetri.cbs.pdm.bdo.sdo.DummyBdo;
import com.silverlakesymmetri.cbs.pdm.svc.PoolService;

public class PushAcctsProcessor implements ItemProcessor<ContractTypeJpe, ContractTypeJpe> {

    @Autowired
    private PoolService poolService;

    /*  Future to download tagging to respective module
    @Autowired
    private PoolAssetLiabTagService poolServiceTag;
     */
    @Autowired
    private CbsBatchGenericDataService batchDataService;

    @Override
    public ContractTypeJpe process(ContractTypeJpe contractTypes) {

        int limit = 999999999;
        int offset = 0;
        System.out.println("Loading Contract Type Dep " + contractTypes.getContractType());

        if (contractTypes.getContractType().equals("MUD")) {
            String query = "SELECT  a.acctNo, a.acctDesc, a.depositType, a.acctType, c.crIntType, d.depTermType, a.acctOpenDate, a.acctStatus, d.depTermPeriod FROM AcctJpe a "
                + " LEFT OUTER JOIN AcctTypeJpe b ON (a.acctType = b.acctType) "
                + " LEFT OUTER JOIN IntDetailJpe c ON (a.internalKey = c.internalKey) "
                + " LEFT JOIN a.tdaRec d ON (a.internalKey = d.internalKey)"
                + "WHERE b.contractType=:contractType and a.acctStatus<>'C'";
            final Map<String, Object> parameters = new HashMap<>();
            parameters.put("contractType", contractTypes.getContractType());
            List<DummyBdo> data = batchDataService.findWithQuery(query, parameters, offset, limit, DummyBdo.class);
            poolService.loadLiab(data, "S");
            
            /* Following query to be used
            select internal_key,
                   round(sum(calc_bal * days))*sum(days)/(i.next_profit_gen_date-i.last_profit_gen_date+1) avg_bal,
                   sum(days) total_days
             into v_internal_key, v_pool_avg_bal, v_total_days      
              from (select INTERNAL_KEY,
                           TRAN_DATE,
                           calc_bal,
                           nvl(LAG(tran_date) OVER(ORDER BY tran_date), tran_date) last_tran_date,
                           decode(nvl(LAG(tran_date) OVER(ORDER BY tran_date), tran_date),
                                  tran_date,
                                  1,
                                  TRAN_DATE -
                                  nvl(LAG(tran_date) OVER(ORDER BY tran_date), tran_date)) days
                      from RB_ACCT_BAL
                     where internal_key = x.acct_key
                       and tran_date between greatest(i.last_profit_gen_date,x.attach_date) and least(nvl(x.detach_date,v_run_date),v_run_date)
                     order by internal_key, tran_date) */
            query = "SELECT  a.acctNo, b.acctType, c.intAvgDailyBal FROM PoolAssetLiabTagJpe a "
                + " INNER JOIN AcctJpe b ON (a.acctNo = b.acctNo) "
                + " INNER JOIN AcctStatsJpe c ON (b.internalKey = c.internalKey) "
                + "WHERE a.itemType=:itemType";
            parameters.clear();
            parameters.put("itemType", "L");
            List<DummyBdo> bal = batchDataService.findWithQuery(query, parameters, offset, limit, DummyBdo.class);
            poolService.loadLiab(bal, "B");
        }
        return contractTypes;
    }

}
