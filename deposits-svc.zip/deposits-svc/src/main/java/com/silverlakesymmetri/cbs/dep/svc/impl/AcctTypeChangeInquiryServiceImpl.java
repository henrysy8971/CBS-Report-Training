package com.silverlakesymmetri.cbs.dep.svc.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.mysema.query.types.EntityPath;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.svc.AbstractBusinessService;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.AcctTypeChangeInquiry;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.AcctTypeChangeInquiryJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.QAcctTypeChangeInquiryJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.id.AcctTypeChangeInquiryPk;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.util.DepJpeConstants;
import com.silverlakesymmetri.cbs.dep.svc.AcctTypeChangeInquiryService;

@Service
@Transactional
public class AcctTypeChangeInquiryServiceImpl
		extends AbstractBusinessService<AcctTypeChangeInquiry, AcctTypeChangeInquiryJpe, AcctTypeChangeInquiryPk>
		implements AcctTypeChangeInquiryService {

	@Override
	protected EntityPath<AcctTypeChangeInquiryJpe> getEntityPath() {
		return QAcctTypeChangeInquiryJpe.acctTypeChangeInquiryJpe;
	}

	@Override
	protected AcctTypeChangeInquiryPk getIdFromDataObjectInstance(AcctTypeChangeInquiry dataObject) {
		Map<String, Object> params = new HashMap<String, Object>();
		params.put("acctNo", dataObject.getAcctNo());
		Long internalKey = dataService.getWithNamedQuery(DepJpeConstants.ACCT_JPE_FIND_INTERNAL_KEY_BY_ACCT_NO, params,
				Long.class);
		return new AcctTypeChangeInquiryPk(internalKey, dataObject.getSeqNo());
	}

	@Override
	public AcctTypeChangeInquiry getByPk(String publicKey, AcctTypeChangeInquiry reference) {
		return super.getByPk(publicKey, reference);
	}

	@Override
	public List<AcctTypeChangeInquiry> query(int offset, int resultLimit, String groupBy, String order,
			Map<String, Object> filters) {
		return super.query(offset, resultLimit, groupBy, order, filters);
	}

	@Override
	public List<AcctTypeChangeInquiry> find(FindCriteria findCriteria, CbsHeader cbsHeader) {
		return super.find(findCriteria, cbsHeader);
	}

}
