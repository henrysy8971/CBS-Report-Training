package com.silverlakesymmetri.cbs.dep.svc;

import java.util.List;
import java.util.Map;

import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.svc.BusinessService;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.RestraintType;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.RestraintTypeJpe;

public interface LovAcctRestraintService extends BusinessService<RestraintType, RestraintTypeJpe> {
	
	public static final String SVC_OP_NAME_LOVACCTRESTRAINTSERVICE_QUERY = "LovAcctRestraintService.query";
	public static final String SVC_OP_NAME_LOVACCTRESTRAINTSERVICE_FIND = "LovAcctRestraintService.find";
	
	@ServiceOperation(name = SVC_OP_NAME_LOVACCTRESTRAINTSERVICE_QUERY)
	public List<RestraintType> query(int offset, int resultLimit, String groupBy, String order, Map<String, Object> filters);
	
	@ServiceOperation(name = SVC_OP_NAME_LOVACCTRESTRAINTSERVICE_FIND)
	public List<RestraintType> find(FindCriteria findCriteria, CbsHeader cbsHeader);
}
