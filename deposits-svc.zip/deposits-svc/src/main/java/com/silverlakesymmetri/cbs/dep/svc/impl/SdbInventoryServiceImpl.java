package com.silverlakesymmetri.cbs.dep.svc.impl;

import java.util.Arrays;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.mysema.query.types.EntityPath;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.enums.ChangeOperation;
import com.silverlakesymmetri.cbs.commons.logging.CbsAppLogger;
import com.silverlakesymmetri.cbs.commons.logging.annotation.Logger;
import com.silverlakesymmetri.cbs.commons.svc.AbstractBusinessService;
import com.silverlakesymmetri.cbs.commons.svc.CbsFileUploadCapable;
import com.silverlakesymmetri.cbs.commons.svc.util.FileUploadUtilImpl;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.SdbInventory;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.QSdbInventoryJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.SdbInventoryJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.id.SdbInventoryPk;
import com.silverlakesymmetri.cbs.dep.svc.SdbInventoryService;

@Service
@Transactional
public class SdbInventoryServiceImpl extends AbstractBusinessService<SdbInventory, SdbInventoryJpe, SdbInventoryPk>
		implements SdbInventoryService, CbsFileUploadCapable<SdbInventory> {

	@Logger
	CbsAppLogger logger;

	@SuppressWarnings("rawtypes")
	@Autowired
	private FileUploadUtilImpl fileUploadUtility;

	@Override
	protected SdbInventoryPk getIdFromDataObjectInstance(SdbInventory dataObject) {
		SdbInventoryPk pk = new SdbInventoryPk(dataObject.getBranch(), dataObject.getBoxNo());
		return pk;
	}

	@Override
	protected EntityPath<SdbInventoryJpe> getEntityPath() {
		return QSdbInventoryJpe.sdbInventoryJpe;
	}

	@Override
	public SdbInventory create(SdbInventory dataObject) {
		return super.create(dataObject);
	}

	@Override
	public SdbInventory get(SdbInventory objectInstanceIdentifier) {
		return super.get(objectInstanceIdentifier);
	}

	@Override
	public List<SdbInventory> query(int offset, int resultLimit, String groupBy, String order,
			Map<String, Object> filters) {
		return super.query(offset, resultLimit, groupBy, order, filters);
	}

	@Override
	public SdbInventory update(SdbInventory dataObject) {
		return super.update(dataObject);
	}

	@Override
	public List<SdbInventory> find(FindCriteria findCriteria, CbsHeader cbsHeader) {
		return super.find(findCriteria, cbsHeader);
	}

	@Override
	public SdbInventory getByPk(String publicKey, SdbInventory reference) {
		return super.getByPk(publicKey, reference);
	}

	@Override
	public boolean bulkCreate(List<SdbInventory> bdoList) {
		validateBulkCreateList(bdoList);

		for (SdbInventory bdo : bdoList) {
			try {
				if (StringUtils.isAllBlank(bdo.getSdbStatus())) {
					bdo.setSdbStatus("V");
				}
				if (StringUtils.isAllBlank(bdo.getStartDt())) {
					bdo.setStartDt(dateTimeHelper.getSDODateTime(dateTimeHelper.getRunDate()));
				}
				bdo.setActiveYn(false);
				fileUploadUtility.validateConstraints(bdo, ChangeOperation.Create);
				this.create(bdo);
			} catch (Exception e) {
				logger.error("Error encountered while processing jpe: {}", jaxbSdoHelper.unwrap(bdo), e);
				throw e;
			}
		}

		return true;
	}

	private void validateBulkCreateList(List<SdbInventory> bdoList) {
		isDuplicatesOnList(Arrays.asList("branch", "boxNo"), bdoList);
	}

	@SuppressWarnings("unchecked")
	@Override
	public boolean isDuplicatesOnList(List<String> uniqueKeys, List<SdbInventory> bdoList) {
		return fileUploadUtility.isDuplicatesOnList(uniqueKeys, bdoList);
	}

}
