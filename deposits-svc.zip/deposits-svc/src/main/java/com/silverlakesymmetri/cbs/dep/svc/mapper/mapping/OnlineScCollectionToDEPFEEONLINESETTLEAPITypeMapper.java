package com.silverlakesymmetri.cbs.dep.svc.mapper.mapping;

import org.mapstruct.MapperConfig;
import org.mapstruct.Mapping;
import org.mapstruct.Mappings;

import com.silverlakesymmetri.cbs.commons.jpa.util.DateTimeHelper;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.OnlineScCollectionJpe;
import com.silverlakesymmetri.cbs.dep.xmlapi.DEPFEEONLINESETTLEAPIType;

@MapperConfig(uses={ DateTimeHelper.class})
public interface OnlineScCollectionToDEPFEEONLINESETTLEAPITypeMapper {
	

	@Mappings({
		@Mapping(target ="INTERNALKEY", source="internalKey"), 
	 })
	public DEPFEEONLINESETTLEAPIType mapOnlineScCollectionToDEPFEEONLINESETTLEAPIType(OnlineScCollectionJpe jpe);
	
}



