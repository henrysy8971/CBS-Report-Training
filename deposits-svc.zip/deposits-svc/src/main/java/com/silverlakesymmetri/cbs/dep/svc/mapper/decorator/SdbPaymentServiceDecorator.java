package com.silverlakesymmetri.cbs.dep.svc.mapper.decorator;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

import com.silverlakesymmetri.cbs.commons.xmlapi.enums.CbsXmlApiOperation;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.SdbAcctHdrJpe;
import com.silverlakesymmetri.cbs.dep.svc.mapper.SdbPaymentServiceMapper;
import com.silverlakesymmetri.cbs.dep.xmlapi.DEPSDBPAYMENTAPIType;

public abstract class SdbPaymentServiceDecorator extends SdbFeeServiceDecorator implements SdbPaymentServiceMapper {
	
	@Autowired
	@Qualifier("delegate")
	protected  SdbPaymentServiceMapper delegate;
	
	@Override
	public DEPSDBPAYMENTAPIType mapToApi(SdbAcctHdrJpe jpe, CbsXmlApiOperation oper, Map otherInfo) {
		DEPSDBPAYMENTAPIType req = (DEPSDBPAYMENTAPIType)delegate.mapToApi(jpe, oper, otherInfo);
		mapSdbFeeToApi(jpe, req);
		
		return  req;
	}

	@Override
	public SdbAcctHdrJpe mapToJpe(DEPSDBPAYMENTAPIType api, SdbAcctHdrJpe jpe) {
		if (jpe == null){
			jpe = new SdbAcctHdrJpe();
		}
		
		if (api == null){
			return jpe;
		}
		
		delegate.mapToJpe(api, jpe);
		mapSdbFeeToJpe(api, jpe);
		
		return jpe;
	}

}
