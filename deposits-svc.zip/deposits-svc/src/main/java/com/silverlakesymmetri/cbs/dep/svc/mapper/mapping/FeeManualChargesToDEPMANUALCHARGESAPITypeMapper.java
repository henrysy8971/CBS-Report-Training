package com.silverlakesymmetri.cbs.dep.svc.mapper.mapping;

import org.mapstruct.MapperConfig;
import org.mapstruct.Mapping;
import org.mapstruct.Mappings;

import com.silverlakesymmetri.cbs.commons.jpa.util.DateTimeHelper;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.FeeManualChargesJpe;
import com.silverlakesymmetri.cbs.dep.xmlapi.DEPMANUALCHARGESAPIType;

@MapperConfig(uses = { DateTimeHelper.class })
public interface FeeManualChargesToDEPMANUALCHARGESAPITypeMapper {
	@Mappings({
		@Mapping(source = "reference", target = "REFERENCE" ),
		@Mapping(source = "acctNo", target = "ACCTNO"),
		@Mapping(source = "referenceNo", target = "REFERENCENO"),
		@Mapping(source = "scType", target = "SCTYPE"),
		@Mapping(source = "scRateType", target = "SCRATETYPE"),
		@Mapping(source = "calcBalType", target = "CALCBALTYPE"),
		@Mapping(source = "calcBalCcy", target = "CALCBALCCY"),
		@Mapping(source = "calcBal", target = "CALCBAL"),
		@Mapping(source = "effectDate", target = "EFFECTDATE", qualifiedByName = { "DateTimeHelper", "convertDateToCbsXmlApiDate" }),
		@Mapping(source = "scCcy", target = "SCCCY"),
		@Mapping(source = "crossRate", target = "CROSSRATE"),
		@Mapping(source = "scAmt", target = "SCAMT"),
		@Mapping(source = "scTaxAmt", target = "SCTAXAMT"),
		@Mapping(source = "reasonType", target = "REASONTYPE"),
		@Mapping(source = "reasonDesc", target = "REASONDESC"),
		@Mapping(source = "scSeqNo", target = "SCSEQNO"),
		@Mapping(source = "moduleID", target = "MODULEID"),
		@Mapping(source = "subType", target = "SUBTYPE"),
		@Mapping(source = "branch", target = "BRANCH"),
		@Mapping(source = "crossId", target = "CROSSID"),
		@Mapping(source = "scAmtUpdated", target = "SCAMTUPDATED"),
		@Mapping(source = "scAmtStandard", target = "SCAMTSTANDARD"),
		@Mapping(source = "scTaxAmtStandard", target = "SCTAXAMTSTANDARD"),
		@Mapping(source = "scTaxAmtUpdated", target = "SCTAXAMTUPDATED"),
		@Mapping(source = "status", target = "STATUS"),
		@Mapping(source = "purpose", target = "PURPOSE"),
		@Mapping(source = "scManualSeqNo", target = "SCMANUALSEQNO"),
		@Mapping(source = "updInd", target = "TUPDALLOWED"),
	})
	public DEPMANUALCHARGESAPIType mapFeeManualChargesToDEPMANUALCHARGESAPIType(FeeManualChargesJpe jpe);
}
