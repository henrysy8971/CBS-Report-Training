package com.silverlakesymmetri.cbs.dep.svc.mapper.decorator;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

import com.silverlakesymmetri.cbs.commons.xmlapi.enums.CbsXmlApiOperation;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.FeeManualChargesJpe;
import com.silverlakesymmetri.cbs.dep.svc.mapper.FeeManualChargesServiceMapper;
import com.silverlakesymmetri.cbs.dep.xmlapi.DEPMANUALCHARGESAPIType;

public abstract class FeeManualChargesServiceDecorator implements FeeManualChargesServiceMapper {

	@Autowired
	@Qualifier("delegate")
	protected FeeManualChargesServiceMapper delegate;

	@SuppressWarnings("rawtypes")
	@Override
	public DEPMANUALCHARGESAPIType mapToApi(FeeManualChargesJpe jpe, CbsXmlApiOperation oper, Map otherInfo) {
		DEPMANUALCHARGESAPIType req = (DEPMANUALCHARGESAPIType) delegate.mapToApi(jpe, oper, otherInfo);
		return req;
	}

	@Override
	public FeeManualChargesJpe mapToJpe(DEPMANUALCHARGESAPIType api, FeeManualChargesJpe jpe) {
		if (jpe == null) {
			jpe = new FeeManualChargesJpe();
		}
		if (api == null) {
			return jpe;
		}
		jpe = delegate.mapToJpe(api, jpe);
		return jpe;
	}

}
