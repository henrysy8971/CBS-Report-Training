package com.silverlakesymmetri.cbs.dep.svc.ext;

import com.silverlakesymmetri.cbs.commons.logging.CbsAppLogger;
import com.silverlakesymmetri.cbs.commons.logging.CbsAppLoggerFactory;
import com.silverlakesymmetri.cbs.xps.svc.util.ReleaseAcctRestraintCapable;
import org.springframework.stereotype.Service;

@Service
public class ExportLCTransferRestraintCreateServiceExtImpl extends AbstractTfnAcctRestraintServiceExtImpl implements ReleaseAcctRestraintCapable {

	private static CbsAppLogger logger = CbsAppLoggerFactory.getLogger(ExportLCTransferRestraintCreateServiceExtImpl.class.getName());
	
    @Override
    public String[] getExtendedBdoNames() {
        return new String[] { "ExportLCTransfer" };
    }

    @Override
    public String[] getExtendedServiceNames() {
        return new String[] {"ExportLCTransferService.create"};
    }

    protected CbsAppLogger getLogger() {
    	return logger;
    }
}
