package com.silverlakesymmetri.cbs.dep.svc.mapper.decorator;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.inject.Inject;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

import com.silverlakesymmetri.cbs.commons.jpa.extension.JaxbSdoHelper;
import com.silverlakesymmetri.cbs.commons.xmlapi.enums.CbsXmlApiOperation;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.BalHistCtrlInq;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.BalHistInq;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.BalStatsInq;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.AcctBranchTransferJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.AcctJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.BalHistCtrlInqJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.BalHistInqJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.BalStatsInqJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.util.DepJpeConstants;
import com.silverlakesymmetri.cbs.dep.svc.mapper.BalHistCtrlInqServiceMapper;
import com.silverlakesymmetri.cbs.dep.xmlapi.DEPACCTBALHISTQRYAPIType;
import com.silverlakesymmetri.cbs.dep.xmlapi.DEPACCTBALHISTQRYTType;

public abstract class BalHistCtrlInqServiceDecorator implements BalHistCtrlInqServiceMapper {

	@Inject
    protected JaxbSdoHelper jaxbSdoHelper;
	
	@Autowired
	@Qualifier("delegate")
	protected  BalHistCtrlInqServiceMapper delegate;
	
	@Override
	public DEPACCTBALHISTQRYAPIType mapToApi(BalHistCtrlInqJpe jpe, CbsXmlApiOperation oper, Map otherInfo) {
		DEPACCTBALHISTQRYAPIType apiType = (DEPACCTBALHISTQRYAPIType)delegate.mapToApi(jpe, oper, otherInfo); 
		return apiType;
	}

	@Override
	public BalHistCtrlInqJpe mapToJpe(DEPACCTBALHISTQRYAPIType api, BalHistCtrlInqJpe jpe) {
		if (jpe == null){
			jpe = new BalHistCtrlInqJpe();
		}
		
		if (api == null){
			return jpe;
		}
		
		delegate.mapToJpe(api, jpe);
		
		if (api != null) {
			
			List<DEPACCTBALHISTQRYTType> balHistList = new ArrayList<>();
        	balHistList.addAll(api.getBALHISTLIST().getDEPACCTBALHISTQRYT());
        	for (DEPACCTBALHISTQRYTType balHist: balHistList) {
            	BalHistInq bdo = jaxbSdoHelper.createSdoInstance(BalHistInq.class);
            	BalHistInqJpe balHistRecJpe = jaxbSdoHelper.unwrap(bdo);
            	
            	balHistRecJpe.setDay((int) balHist.getDAYNO());
            	balHistRecJpe.setLedgerBal(balHist.getLEDGERBAL());
            	balHistRecJpe.setActualBal(balHist.getACTUALBAL());
	        	jpe.getBalHistInqList().add(balHistRecJpe);
        	}
			
        	BalStatsInq statsBdo = jaxbSdoHelper.createSdoInstance(BalStatsInq.class);
        	BalStatsInqJpe balStatsInqJpe = jaxbSdoHelper.unwrap(statsBdo);
        	balStatsInqJpe.setLowBal(api.getLOWBALANCE());
        	balStatsInqJpe.setAvgBal(api.getAVGBALANCE());
        	balStatsInqJpe.setHighBal(api.getHIGHBALANCE());
        	
        	jpe.getBalStatsInqList().add(balStatsInqJpe);
        }
		
		return jpe;
	}
	
}
