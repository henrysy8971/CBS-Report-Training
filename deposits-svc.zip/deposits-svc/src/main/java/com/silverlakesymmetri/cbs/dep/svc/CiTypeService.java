package com.silverlakesymmetri.cbs.dep.svc;

import java.util.List;
import java.util.Map;

import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation;
import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation.ServiceOperationType;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.svc.BusinessService;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.CiType;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.CiTypeJpe;


public interface CiTypeService extends BusinessService<CiType, CiTypeJpe> {

    public static final String SVC_OP_NAME_CIDENOMGROUP_GET = "CiTypeService.get";
    public static final String SVC_OP_NAME_CIDENOMGROUP_CREATE = "CiTypeService.create";
    public static final String SVC_OP_NAME_CIDENOMGROUP_UPDATE = "CiTypeService.update";
    public static final String SVC_OP_NAME_CIDENOMGROUP_DELETE = "CiTypeService.delete";
    public static final String SVC_OP_NAME_CIDENOMGROUP_QUERY = "CiTypeService.query";
    public static final String SVC_OP_NAME_CIDENOMGROUP_FIND = "CiTypeService.find";

    @ServiceOperation(name = SVC_OP_NAME_CIDENOMGROUP_GET, type = ServiceOperationType.GET)
    public CiType getByPk(String publicKey, CiType reference);
    
    @ServiceOperation(name = SVC_OP_NAME_CIDENOMGROUP_CREATE)
    public CiType create(CiType objectInstanceIdentifier);
    
    @ServiceOperation(name = SVC_OP_NAME_CIDENOMGROUP_UPDATE)
    public CiType update(CiType objectInstanceIdentifier);
    
    @ServiceOperation(name = SVC_OP_NAME_CIDENOMGROUP_DELETE)
    public boolean delete(CiType objectInstanceIdentifier);
    
    @ServiceOperation(name = SVC_OP_NAME_CIDENOMGROUP_QUERY)
    public List<CiType> query(int offset, int resultLimit, String groupBy, String order, Map<String, Object> filters);

    @ServiceOperation(name = SVC_OP_NAME_CIDENOMGROUP_FIND)
    public List<CiType> find(FindCriteria findCriteria, CbsHeader cbsHeader);


}
