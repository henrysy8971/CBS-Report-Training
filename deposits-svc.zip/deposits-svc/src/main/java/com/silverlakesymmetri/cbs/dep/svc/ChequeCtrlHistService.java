package com.silverlakesymmetri.cbs.dep.svc;

import java.util.List;
import java.util.Map;

import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation;
import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation.ServiceOperationType;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.svc.BusinessService;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.ChequeCtrlHist;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.ChequeCtrlHistJpe;

public interface ChequeCtrlHistService extends BusinessService<ChequeCtrlHist, ChequeCtrlHistJpe>{

	public static final String SVC_OP_NAME_CHEQUECTRLHISTSERVICE_GET= "ChequeCtrlHistService.get";
	public static final String SVC_OP_NAME_CHEQUECTRLHISTSERVICE_QUERY= "ChequeCtrlHistService.query";
	public static final String SVC_OP_NAME_CHEQUECTRLHISTSERVICE_FIND= "ChequeCtrlHistService.find";

    @ServiceOperation(name = SVC_OP_NAME_CHEQUECTRLHISTSERVICE_QUERY)
    public List<ChequeCtrlHist> query(int offset, int resultLimit, String groupBy, String order, Map<String, Object> filters);

    @ServiceOperation(name = SVC_OP_NAME_CHEQUECTRLHISTSERVICE_FIND)
    public List<ChequeCtrlHist> find(FindCriteria findCriteria, CbsHeader cbsHeader);

    @ServiceOperation(name = SVC_OP_NAME_CHEQUECTRLHISTSERVICE_GET, type = ServiceOperationType.GET)
    public ChequeCtrlHist getByPk(String publicKey, ChequeCtrlHist reference);
	
}
