package com.silverlakesymmetri.cbs.dep.svc.mapper.decorator;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.Date;
import java.util.Map;

import javax.inject.Inject;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

import com.silverlakesymmetri.cbs.commons.context.CbsRuntimeContextManager;
import com.silverlakesymmetri.cbs.commons.context.CbsSessionContext;
import com.silverlakesymmetri.cbs.commons.jpa.util.DateTimeHelper;
import com.silverlakesymmetri.cbs.commons.xmlapi.enums.CbsXmlApiOperation;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.FxBuySellJpe;
import com.silverlakesymmetri.cbs.dep.svc.mapper.FxBuySellServiceMapper;
import com.silverlakesymmetri.cbs.dep.xmlapi.DEPFXBUYSELLAPIType;

public abstract class FxBuySellServiceDecorator implements FxBuySellServiceMapper{
	
	@Autowired
	@Qualifier("delegate")
	protected FxBuySellServiceMapper delegate;
	
    @Autowired
    private DateTimeHelper dateTimeHelper;

	@Inject
	protected CbsRuntimeContextManager _ctxMngr;

	@Override
	public DEPFXBUYSELLAPIType mapToApi(FxBuySellJpe jpe, CbsXmlApiOperation oper, Map otherInfo){
		CbsSessionContext sessionCtx = _ctxMngr.getContext(CbsSessionContext.class);
		Date runDate = dateTimeHelper.getRunDate();
		LocalDate localDate = runDate.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
		LocalDateTime localDateTime = LocalDateTime.of(localDate.getYear(),localDate.getMonthValue(),localDate.getDayOfMonth(), 0, 0, 0);
        Date runDateNoTime = Date.from(localDateTime.atZone(ZoneId.systemDefault()).toInstant());
		jpe.setEffectDate(runDateNoTime);
		jpe.setOfficerId(sessionCtx.getUserCode());
		if(jpe.getAcctNo() != null){
			jpe.setClientName(jpe.getClientShort());
			jpe.setGlobalIdType(jpe.getAcctGlobalIdType());
			jpe.setGlobal(jpe.getAcctGlobalId());
		}
		DEPFXBUYSELLAPIType req = (DEPFXBUYSELLAPIType) delegate.mapToApi(jpe, oper, otherInfo);
		if(jpe.getFeeAmt() != null && jpe.getFeeAmt().doubleValue() > 0){
			req.setFEEIND("Y");
		} else {
			req.setFEEIND("N");
		}
		return  req;
	}
	
	@Override
	public FxBuySellJpe mapToJpe(DEPFXBUYSELLAPIType api, FxBuySellJpe jpe){
		Double seqNo = api.getFXMISCTRANSEQNO();
		jpe.setMiscSeqNo(seqNo.longValue());
		jpe.setMiscTranSeqNo((long) api.getFXMISCTRANSEQNO());
		jpe.setCommTranSeqNo((long) api.getFXCOMMTRANSEQNO());
		jpe.setTranSeqNo((long) api.getFXTRANSEQNO());
		return jpe;
	}
}


