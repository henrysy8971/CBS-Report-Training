package com.silverlakesymmetri.cbs.dep.svc.impl;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.mysema.query.types.EntityPath;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.svc.AbstractBusinessService;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.IntDetail;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.IntDetailJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.QIntDetailJpe;
import com.silverlakesymmetri.cbs.dep.svc.IntDetailService;


@Service
@Transactional
public class IntDetailServiceImpl extends AbstractBusinessService<IntDetail, IntDetailJpe, Long> implements IntDetailService {

    @Override
    protected Long getIdFromDataObjectInstance(IntDetail dataObject) {
    	IntDetailJpe jpe = jaxbSdoHelper.unwrap(dataObject, IntDetailJpe.class);
        return jpe.getInternalKey();
    }

    @Override
    protected EntityPath<IntDetailJpe> getEntityPath() {
        return QIntDetailJpe.intDetailJpe;
    }
    
    @Override
    public IntDetail get(IntDetail objectInstanceIdentifier) {
        return super.get(objectInstanceIdentifier);
    }

    @Override
    public List<IntDetail> query(int offset, int resultLimit, String groupBy, String order, Map<String, Object> filters) {
        return super.query(offset, resultLimit, groupBy, order, filters);
    }

    @Override
    public List<IntDetail> find(FindCriteria findCriteria, CbsHeader cbsHeader) {
        return super.find(findCriteria, cbsHeader);
    }

    @Override
    public IntDetail getByPk(String publicKey, IntDetail reference) {
        return super.getByPk(publicKey, reference);
    }
}
