package com.silverlakesymmetri.cbs.dep.svc.impl;

public class DepTestGerrit {
	
	public void main(String[] args){
		System.out.println("Test commit to Gerrit 101!");
	}

}
