package com.silverlakesymmetri.cbs.dep.svc.mapper.decorator;

import java.util.Map;

import org.mapstruct.Context;
import org.mapstruct.MappingTarget;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

import com.silverlakesymmetri.cbs.commons.xmlapi.enums.CbsXmlApiOperation;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.SiHeaderJpe;
import com.silverlakesymmetri.cbs.dep.svc.mapper.SiHeaderMapper;
import com.silverlakesymmetri.cbs.dep.xmlapi.DEPSIHEADERAPIType;

public abstract class SiHeaderDecorator extends FeeServiceDecorator implements SiHeaderMapper{
	
	@Autowired
	@Qualifier("delegate")
	protected  SiHeaderMapper delegate;
	
	
	@Override
	public DEPSIHEADERAPIType mapToApi(SiHeaderJpe jpe, @Context CbsXmlApiOperation oper, @Context Map otherInfo){
		
		DEPSIHEADERAPIType req = (DEPSIHEADERAPIType)delegate.mapToApi(jpe, oper, otherInfo);
		mapFeeToApi(jpe, req);
//		if (otherInfo.containsKey(BRANCH)){
//			req.setBRANCH((String) otherInfo.get(BRANCH));
//		}

		return  req;
	}
	
	@Override
	public SiHeaderJpe mapToJpe(DEPSIHEADERAPIType api, @MappingTarget SiHeaderJpe jpe){
		
		delegate.mapToJpe(api, jpe);
		mapFeeToJpe(api, jpe);
//		jpe.setSeqNo(api.getTXNSEQNO());
		return jpe;
	}
}


