package com.silverlakesymmetri.cbs.dep.svc.impl;

import java.util.HashMap;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.jpa.extension.JaxbSdoHelper;
import com.silverlakesymmetri.cbs.commons.jpa.service.CbsGenericDataService;
import com.silverlakesymmetri.cbs.commons.restlet.OdataUriFilterConverter;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.OdRepositoryDtl;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.OdRepositoryHeader;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.util.DepJpeConstants;
import com.silverlakesymmetri.cbs.dep.svc.OdRepositoryDtlService;
import com.silverlakesymmetri.cbs.dep.svc.OdRepositoryHeaderService;
import com.silverlakesymmetri.cbs.dep.util.OdRepositoryDtlTotalsHolder;

@Service
@Transactional
public class OdRepositoryHeaderServiceImpl implements OdRepositoryHeaderService {

	@Autowired
	private JaxbSdoHelper jaxbSdoHelper;

	@Autowired
	private CbsGenericDataService dataService;

	@Autowired
	private OdRepositoryDtlService odRepositoryDtlService;

	@Autowired
	private OdataUriFilterConverter odataUriFilterConverter;

	@Override
	public OdRepositoryHeader queryTotals(String fc, String acctNo, int limit, int offset) {

		double totalDueAmtDtl = 0;
		double totalPaidAmtDtl = 0;
		double totalWriteOffAmtDtl = 0;
		double totalScAmt = 0;
		double totalScPaidAmt = 0;
		double totalTaxAmt = 0;
		double totalTaxPaidAmt = 0;
		double totalBalanceDue = 0;

		if (StringUtils.isNotBlank(fc)) {

			String findCriteriaStr;
			if (StringUtils.isNotBlank(acctNo)) {
				findCriteriaStr = fc.trim() + " and acctNo eq '" + acctNo.trim() + "'";
			} else {
				findCriteriaStr = fc.trim();
			}
			FindCriteria crit = odataUriFilterConverter.convertUriQuery(findCriteriaStr);
			crit.setFetchStart(0);
			crit.setFetchSize(0);
			List<OdRepositoryDtl> list = odRepositoryDtlService.find(crit, null);
			if (list != null) {
				for (OdRepositoryDtl item : list) {
					totalDueAmtDtl += item.getDueAmt() == null ? 0 : item.getDueAmt().doubleValue();
					totalPaidAmtDtl += item.getPaidAmt() == null ? 0 : item.getPaidAmt().doubleValue();
					totalWriteOffAmtDtl += item.getWriteoffAmt() == null ? 0 : item.getWriteoffAmt().doubleValue();
					totalScAmt += item.getScAmt() == null ? 0 : item.getScAmt().doubleValue();
					totalScPaidAmt += item.getScPaidAmt() == null ? 0 : item.getScPaidAmt().doubleValue();
					totalTaxAmt += item.getTaxAmt() == null ? 0 : item.getTaxAmt().doubleValue();
					totalTaxPaidAmt += item.getTaxPaidAmt() == null ? 0 : item.getTaxPaidAmt().doubleValue();
				}
			}

		} else if (StringUtils.isNotBlank(acctNo)) {

			HashMap<String, Object> params = new HashMap<String, Object>();

			params.put("acctNo", acctNo);
			Long internalKey = dataService.getWithNamedQuery(DepJpeConstants.ACCT_JPE_FIND_INTERNAL_KEY_BY_ACCT_NO,
					params, Long.class);

			params.clear();
			params.put("internalKey", internalKey);
			OdRepositoryDtlTotalsHolder holder = dataService.getWithNamedQuery(
					DepJpeConstants.ODREPOSITORYDTL_JPE_GET_TOTALS_BY_INTERNAL_KEY, params,
					OdRepositoryDtlTotalsHolder.class);

			if (holder != null) {
				totalDueAmtDtl = holder.getTotalDueAmtDtl() == null ? 0 : holder.getTotalDueAmtDtl().doubleValue();
				totalPaidAmtDtl = holder.getTotalPaidAmtDtl() == null ? 0 : holder.getTotalPaidAmtDtl().doubleValue();
				totalWriteOffAmtDtl = holder.getTotalWriteOffAmtDtl() == null ? 0
						: holder.getTotalWriteOffAmtDtl().doubleValue();
				totalScAmt = holder.getTotalScAmt() == null ? 0 : holder.getTotalScAmt().doubleValue();
				totalScPaidAmt = holder.getTotalScPaidAmt() == null ? 0 : holder.getTotalScPaidAmt().doubleValue();
				totalTaxAmt = holder.getTotalTaxAmt() == null ? 0 : holder.getTotalTaxAmt().doubleValue();
				totalTaxPaidAmt = holder.getTotalTaxPaidAmt() == null ? 0 : holder.getTotalTaxPaidAmt().doubleValue();
			}

		}

		OdRepositoryHeader result = jaxbSdoHelper.createSdoInstance(OdRepositoryHeader.class);
		totalBalanceDue = totalDueAmtDtl + totalScAmt + totalTaxAmt - totalPaidAmtDtl - totalWriteOffAmtDtl
				- totalScPaidAmt - totalTaxPaidAmt;
		result.setTotalDueAmtDtl(totalDueAmtDtl);
		result.setTotalPaidAmtDtl(totalPaidAmtDtl);
		result.setTotalWriteOffAmtDtl(totalWriteOffAmtDtl);
		result.setTotalBalanceDue(totalBalanceDue);
		return result;

	}

}
