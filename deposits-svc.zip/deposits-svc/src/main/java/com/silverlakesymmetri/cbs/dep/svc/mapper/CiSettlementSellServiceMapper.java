package com.silverlakesymmetri.cbs.dep.svc.mapper;

import java.util.Map;

import org.mapstruct.Context;
import org.mapstruct.DecoratedWith;
import org.mapstruct.InheritConfiguration;
import org.mapstruct.InheritInverseConfiguration;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingTarget;
import org.mapstruct.Mappings;

import com.silverlakesymmetri.cbs.commons.jpa.util.DateTimeHelper;
import com.silverlakesymmetri.cbs.commons.xmlapi.enums.CbsXmlApiOperation;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.CiSettlementJpe;
import com.silverlakesymmetri.cbs.dep.svc.mapper.decorator.CiSettlementSellServiceDecorator;
import com.silverlakesymmetri.cbs.dep.svc.mapper.mapping.CiSettlementToDEPCIPROCESSSETTLESELLAPITypeMapper;
import com.silverlakesymmetri.cbs.dep.xmlapi.DEPCIPROCESSSETTLESELLAPIType;

@Mapper(config=CiSettlementToDEPCIPROCESSSETTLESELLAPITypeMapper.class, uses={ DateTimeHelper.class})
@DecoratedWith(CiSettlementSellServiceDecorator.class)
public interface CiSettlementSellServiceMapper{
	
	@Mappings({
		 @Mapping(expression = "java(oper != null ? oper.getOperation() : null)", target="OPERATION")
	 })
	@InheritConfiguration
	public DEPCIPROCESSSETTLESELLAPIType mapToApi(CiSettlementJpe jpe, @Context CbsXmlApiOperation oper, @Context Map otherInfo);
	
	
	@InheritInverseConfiguration(name = "mapCiSettlementToDEPCIPROCESSSETTLESELLAPIType")
//	@Mapping(source = "EFFECTDATE", target="trfDate", qualifiedByName = {"DateTimeHelper","convertCbsApiDateToString"})
	public CiSettlementJpe mapToJpe(DEPCIPROCESSSETTLESELLAPIType api, @MappingTarget CiSettlementJpe jpe);
	
}
