package com.silverlakesymmetri.cbs.dep.svc.impl;

import com.mysema.query.types.EntityPath;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.jpa.util.BdoHelperJpaImpl;
import com.silverlakesymmetri.cbs.commons.svc.AbstractBusinessService;
import com.silverlakesymmetri.cbs.commons.util.AbstractBdoPublicKeyResolverImpl;
import com.silverlakesymmetri.cbs.core.util.CbsNumberUtils;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.TdMaintenance;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.QTdMaintenanceJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.TdMaintAcctQryJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.TdMaintenanceJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.id.TdMaintenancePk;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.util.DepJpeConstants;
import com.silverlakesymmetri.cbs.dep.svc.TdMaintenanceService;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
@Transactional
public class TdMaintenanceServiceImpl extends AbstractBusinessService<TdMaintenance, TdMaintenanceJpe, TdMaintenancePk> implements TdMaintenanceService {

	@Override
	protected EntityPath<TdMaintenanceJpe> getEntityPath() {
		return QTdMaintenanceJpe.tdMaintenanceJpe;
	}

	@Override
	protected TdMaintenancePk getIdFromDataObjectInstance(TdMaintenance dataObject) {
		Long internalKey = 0L;
		TdMaintenancePk pk = new TdMaintenancePk(internalKey);
		return pk;
	}

	private TdMaintAcctQryJpe getTdMaintAcctQry(String acctNo, String certNo){

		Map<String, Object> parameters = new HashMap<String, Object>();
		parameters.put("acctNo", acctNo);
		String crit = DepJpeConstants.FIND_TDMAINTACCTQRYJPE_BY_ACCT_NO;

		if (StringUtils.isNotBlank(certNo)){
			parameters.put("certificateNo", certNo);
			crit = DepJpeConstants.FIND_TDMAINTACCTQRYJPE_BY_ACCT_NO_CERT_NO;
		}
		List<TdMaintAcctQryJpe> tda = dataService.findWithNamedQuery(crit, parameters, TdMaintAcctQryJpe.class);

		if (tda == null || tda.isEmpty()){
			return null;
		}
		return tda.get(0);
	}

	@Override
	public TdMaintenance getByPk(String publicKey, TdMaintenance reference) {

		AbstractBdoPublicKeyResolverImpl bdoPublicKeyResolver = (BdoHelperJpaImpl) getBdoHelper();
		String[] keys = bdoPublicKeyResolver.splitPublicKeyParts(publicKey);

		TdMaintAcctQryJpe tdmaq = getTdMaintAcctQry(keys[0],  keys.length > 1 ? keys[1]: null);
		if (tdmaq == null){
			return null;
		}

		Map<String, Object> parameters = new HashMap<String, Object>();
		parameters = new HashMap<String, Object>();
		parameters.put("internalKey", tdmaq.getInternalKey());
		List<TdMaintenanceJpe> list = dataService.findWithNamedQuery(DepJpeConstants.TDMAINTENANCEJPE_BY_INTERNAL_KEY, parameters, TdMaintenanceJpe.class);

		if (list == null || list.isEmpty()){
			return null;
		}
		TdMaintenanceJpe jpe = list.get(0);
		jpe.setNewEffectRate ( CbsNumberUtils.zeroIfNull(jpe.getNewAcctLevelRate()) +  CbsNumberUtils.zeroIfNull(jpe.getNewSpreadRate()));
		return wrap(jpe);
	}

	@Override
	protected TdMaintenance preCreateValidation(TdMaintenance dataObject) {

		TdMaintenanceJpe jpe = unwrap(dataObject);
		if (StringUtils.isBlank(jpe.getCrIntType())){
			return  dataObject;
		}
		TdMaintAcctQryJpe tdmaq = getTdMaintAcctQry(jpe.getAcctNo(), jpe.getCertificateNo());
		if (tdmaq == null){
			return dataObject;
		}
		jpe.setCrIntType(tdmaq.getCrIntType());

		return super.preCreateValidation(wrap(jpe));
	}

	@Override
	public TdMaintenance create(TdMaintenance dataObject) {
		return super.create(dataObject);
	}

	@Override
	public TdMaintenance update(TdMaintenance dataObject) {
		return super.update(dataObject);
	}

	@Override
	public List<TdMaintenance> query(int offset, int resultLimit, String groupBy, String order,
			Map<String, Object> filters) {
		return super.query(offset, resultLimit, groupBy, order, filters);
	}

	@Override
	public boolean delete(TdMaintenance dataObject) {
		return super.delete(dataObject);
	}

	@Override
	public List<TdMaintenance> find(FindCriteria findCriteria, CbsHeader cbsHeader) {
		return super.find(findCriteria, cbsHeader);
	}

}
