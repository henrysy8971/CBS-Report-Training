package com.silverlakesymmetri.cbs.dep.svc.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mysema.query.types.EntityPath;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.jpa.listener.Auditor;
import com.silverlakesymmetri.cbs.commons.svc.AbstractXmlApiBusinessService;
import com.silverlakesymmetri.cbs.commons.xmlapi.enums.CbsXmlApiOperation;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.CiRdBunchReg;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.CiRdReg;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.CiRdRegJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.QCiRdRegJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.id.CiRdRegPk;
import com.silverlakesymmetri.cbs.dep.svc.ChequeRegistrationService;
import com.silverlakesymmetri.cbs.dep.svc.mapper.ChequeRegistrationServiceMapper;
import com.silverlakesymmetri.cbs.dep.xmlapi.DEPCIRDAPIType;

@Service
public class ChequeRegistrationServiceImpl
		extends AbstractXmlApiBusinessService<CiRdReg, CiRdRegJpe, CiRdRegPk, DEPCIRDAPIType, DEPCIRDAPIType>
		implements ChequeRegistrationService {

	private static final String DEP_CI_RD_KEY = "DEP_CI_RD_KEY_S";

	@Autowired
	ChequeRegistrationServiceMapper mapper;

	@Override
	protected DEPCIRDAPIType transformBdoToXmlApiRqCreate(CiRdReg dataObject) {
		return transformCiRdRegToDEPCIRDAPIType(dataObject, CbsXmlApiOperation.INSERT);
	}

	@Override
	protected DEPCIRDAPIType transformBdoToXmlApiRqUpdate(CiRdReg dataObject) {
		return transformCiRdRegToDEPCIRDAPIType(dataObject, CbsXmlApiOperation.UPDATE);
	}

	@Override
	protected DEPCIRDAPIType transformBdoToXmlApiRqDelete(CiRdReg dataObject) {
		return transformCiRdRegToDEPCIRDAPIType(dataObject, CbsXmlApiOperation.DELETE);
	}

	@Override
	protected CiRdReg processXmlApiRs(CiRdReg dataObject, DEPCIRDAPIType xmlApiRs) {
		CiRdRegJpe jpe = jaxbSdoHelper.unwrap(dataObject);
		jpe = mapper.mapToJpe(xmlApiRs, jpe);
		return jaxbSdoHelper.wrap(jpe);
	}

	@Override
	protected List<CiRdReg> processXmlApiListRs(CiRdReg dataObject, DEPCIRDAPIType xmlApiRs) {
		return null;
	}

	@Override
	protected Class<DEPCIRDAPIType> getXmlApiResponseClass() {
		return DEPCIRDAPIType.class;
	}

	@Override
	protected CiRdRegPk getIdFromDataObjectInstance(CiRdReg dataObject) {
		CiRdRegJpe jpe = jaxbSdoHelper.unwrap(dataObject);
		return new CiRdRegPk(jpe.getChequeRdKey());
	}

	@Override
	protected EntityPath<CiRdRegJpe> getEntityPath() {
		return QCiRdRegJpe.ciRdRegJpe;
	}

	@Override
	public CiRdReg getByPk(String publicKey, CiRdReg reference) {
		CiRdReg data = super.getByPk(publicKey, reference);

		if (data == null || data.getCiRdBunchRegList() == null || data.getCiRdBunchRegList().isEmpty()) {
			return data;
		}

		for (CiRdBunchReg item : data.getCiRdBunchRegList()) {
			if (item.getDenomination() > 0 && item.getQuantity() > 0)
				item.setAmount(item.getDenomination() * item.getQuantity());
		}

		return data;
	}

	@Override
	public CiRdReg create(CiRdReg header) {
		return super.create(header);
	}

	@Override
	public CiRdReg update(CiRdReg header) {
		// why? only delete of children are allowed / header is not allowed to
		// be updated
		super.delete(header);
		return header;
	}

	@Override
	public boolean delete(CiRdReg header) {
		return super.delete(header);
	}

	@Override
	public List<CiRdReg> query(int offset, int resultLimit, String groupBy, String order, Map<String, Object> filters) {
		return super.query(offset, resultLimit, groupBy, order, filters);
	}

	@Override
	public List<CiRdReg> find(FindCriteria findCriteria, CbsHeader cbsHeader) {
		return super.find(findCriteria, cbsHeader);
	}

	private DEPCIRDAPIType transformCiRdRegToDEPCIRDAPIType(CiRdReg dataObject, CbsXmlApiOperation oper) {

		Map map = new HashMap();
		// CbsSessionContext sessionCtx =
		// _ctxMngr.getContext(CbsSessionContext.class);
		// map.put(mapper.BRANCH,
		// super.getUserBranch(sessionCtx.getUserCode()));

		CiRdRegJpe jpe = jaxbSdoHelper.unwrap(dataObject);
		DEPCIRDAPIType api = mapper.mapToApi(jpe, oper, map);
		super.setTechColsFromDataObject(dataObject, api);

		return api;
	}

	@Autowired
	private Auditor auditor;

	protected CiRdReg preCreateObject(CiRdReg dataObject) {
		CiRdRegJpe jpe = unwrap(dataObject);
		auditor.prePersistCallback(jpe);
		return wrap(jpe);
	}

	protected CiRdReg preUpdateObject(CiRdReg dataObject) {
		CiRdRegJpe jpe = unwrap(dataObject);
		auditor.preUpdateCallback(jpe);
		return wrap(jpe);
	}

//	protected SiHeader preDeleteObject(SiHeader dataObject) {
//		SiHeaderJpe jpe = unwrap(dataObject);
//		removeVirtualAttributes(jpe);
//		auditor.auditDeleteOperation(jpe);
//		return dataObject;
//	}

	@Override
	protected CiRdReg preCreateValidation(CiRdReg dataObject) {

		if (dataObject != null) {

			if (dataObject.getChequeRdKey() == null) {
				Long seqNo = dataService.nextSequenceValue(DEP_CI_RD_KEY).longValue();
				dataObject.setChequeRdKey(seqNo);
			}

			if (dataObject.getRegDate() == null) {
				dataObject.setRegDate(dateTimeHelper.getSDODateTime(dateTimeHelper.getRunDate()));
			}

			double amount = 0;

			if (dataObject.getCiRdBunchRegList() != null && !dataObject.getCiRdBunchRegList().isEmpty()) {
				int len = dataObject.getCiRdBunchRegList().size();
				for (int i = 0; i <= len -1; i++) {
					dataObject.getCiRdBunchRegList().get(i).setChequeRdKey(dataObject.getChequeRdKey());
					amount += dataObject.getCiRdBunchRegList().get(i).getAmount().doubleValue();
				}
			}
	
			dataObject.setAmount(amount);

			if (StringUtils.isEmpty(dataObject.getOfficerId()) && !StringUtils.isEmpty(dataObject.getCreatedBy())) {
				dataObject.setOfficerId(dataObject.getCreatedBy());
			}

			return super.preCreateValidation(dataObject);

		}

		return null;

	}

}
