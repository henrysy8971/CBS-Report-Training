package com.silverlakesymmetri.cbs.dep.svc;

import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation;
import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation.ServiceOperationType;

/**
 * 
 * @author xtian
 *
 */
public interface DepositsValidatorService {

	public static final String SVC_OP_NAME_DEPOSITSVALIDATORSERVICE_IS_ACCT_TYPE_TRANSFER_ALLOWED_BY_ACCT_TYPES = "DepositsValidatorService.isAcctTypeTransferAllowedByAcctTypes";
	public static final String SVC_OP_NAME_DEPOSITSVALIDATORSERVICE_IS_ACCT_TYPE_TRANSFER_ALLOWED_BY_ACCT_NOS = "DepositsValidatorService.isAcctTypeTransferAllowedByAcctNos";
	public static final String SVC_OP_NAME_DEPOSITSVALIDATORSERVICE_IS_FINANCIAL_TRANSFER_ALLOWED_BY_ACCT_TYPES = "DepositsValidatorService.isFinancialTransferAllowedByAcctTypes";
	public static final String SVC_OP_NAME_DEPOSITSVALIDATORSERVICE_IS_FINANCIAL_TRANSFER_ALLOWED_BY_ACCT_NOS = "DepositsValidatorService.isFinancialTransferAllowedByAcctNos";
	

	@ServiceOperation(name = SVC_OP_NAME_DEPOSITSVALIDATORSERVICE_IS_ACCT_TYPE_TRANSFER_ALLOWED_BY_ACCT_TYPES, type = ServiceOperationType.GET)
    public String isAcctTypeTransferAllowedByAcctTypes(String fromAcctType, String toAcctType);
	
	@ServiceOperation(name = SVC_OP_NAME_DEPOSITSVALIDATORSERVICE_IS_ACCT_TYPE_TRANSFER_ALLOWED_BY_ACCT_NOS, type = ServiceOperationType.GET)
    public String isAcctTypeTransferAllowedByAcctNos(String fromAcctNo, String toAcctNo);
		
	@ServiceOperation(name = SVC_OP_NAME_DEPOSITSVALIDATORSERVICE_IS_FINANCIAL_TRANSFER_ALLOWED_BY_ACCT_TYPES, type = ServiceOperationType.GET)
    public String isFinancialTransferAllowedByAcctTypes(String fromAcctType, String toAcctType);
	
	@ServiceOperation(name = SVC_OP_NAME_DEPOSITSVALIDATORSERVICE_IS_FINANCIAL_TRANSFER_ALLOWED_BY_ACCT_NOS, type = ServiceOperationType.GET)
    public String isFinancialTransferAllowedByAcctNos(String fromAcctNo, String toAcctNo);
	
}
