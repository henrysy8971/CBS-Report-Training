package com.silverlakesymmetri.cbs.dep.svc;

import java.util.List;
import java.util.Map;

import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation;
import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation.ServiceOperationType;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.svc.BusinessService;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.FloatMatrix;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.FloatMatrixJpe;

public interface FloatMatrixService extends BusinessService<FloatMatrix, FloatMatrixJpe> {
	public static final String SVC_OP_NAME_FLOATMATRIX_GET = "FloatMatrixService.get";
    public static final String SVC_OP_NAME_FLOATMATRIX_QUERY = "FloatMatrixService.query";
    public static final String SVC_OP_NAME_FLOATMATRIX_CREATE = "FloatMatrixService.create";
    public static final String SVC_OP_NAME_FLOATMATRIX_UPDATE = "FloatMatrixService.update";
    public static final String SVC_OP_NAME_FLOATMATRIX_DELETE = "FloatMatrixService.delete";
    public static final String SVC_OP_NAME_FLOATMATRIX_FIND = "FloatMatrixService.find";
    public static final String SVC_OP_NAME_FLOATMATRIX_BULK_CREATE = "FloatMatrixService.bulkCreate";
    
    @ServiceOperation(name = SVC_OP_NAME_FLOATMATRIX_GET, type = ServiceOperationType.GET)
    public FloatMatrix getByPk(String publicKey, FloatMatrix reference);

    @ServiceOperation(name = SVC_OP_NAME_FLOATMATRIX_CREATE)
    public FloatMatrix create(FloatMatrix dataObject);

    @ServiceOperation(name = SVC_OP_NAME_FLOATMATRIX_UPDATE)
    public FloatMatrix update(FloatMatrix dataObject);

    @ServiceOperation(name = SVC_OP_NAME_FLOATMATRIX_QUERY)
    public List<FloatMatrix> query(int offset, int resultLimit, String groupBy, String order, Map<String, Object> filters);

    @ServiceOperation(name = SVC_OP_NAME_FLOATMATRIX_DELETE)
    public boolean delete(FloatMatrix dataObject);

    @ServiceOperation(name = SVC_OP_NAME_FLOATMATRIX_FIND)
    public List<FloatMatrix> find(FindCriteria findCriteria, CbsHeader cbsHeader);

	@ServiceOperation(name = SVC_OP_NAME_FLOATMATRIX_BULK_CREATE, type = ServiceOperationType.EXECUTE)
	public boolean bulkCreate(List<FloatMatrix> bdoList);

}
