package com.silverlakesymmetri.cbs.dep.svc.impl;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.mysema.query.types.EntityPath;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.svc.AbstractBusinessService;
import com.silverlakesymmetri.cbs.commons.svc.BusinessObjectValidationCapable;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.IsoFeeMap;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.IsoFeeMapJpe;
import com.silverlakesymmetri.cbs.dep.svc.IsoFeeMapService;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.QIsoFeeMapJpe;

@Service
@Transactional
public class IsoFeeMapServiceImpl extends AbstractBusinessService<IsoFeeMap, IsoFeeMapJpe, String> implements IsoFeeMapService, BusinessObjectValidationCapable<IsoFeeMap> {

	@Override
	protected EntityPath<IsoFeeMapJpe> getEntityPath() {
		return QIsoFeeMapJpe.isoFeeMapJpe;
	}

	@Override
	protected String getIdFromDataObjectInstance(IsoFeeMap dataObject) {
		return dataObject.getIsoFeeType();
	}
	@Override
	public IsoFeeMap get(IsoFeeMap objectInstanceIdentifier) {
		return super.get(objectInstanceIdentifier);
	}
	
	@Override
	public List<IsoFeeMap> query(int offset, int resultLimit, String groupBy, String order, Map<String, Object> filters){
		return super.query(offset, resultLimit, groupBy, order, filters);
	}
	
	@Override
	public IsoFeeMap update(IsoFeeMap dataObject) {
		return super.update(dataObject);
	}
	
	@Override
	public boolean delete(IsoFeeMap dataObject) {
		return super.delete(dataObject);
	}
	
	@Override
	public List<IsoFeeMap> find(FindCriteria findCriteria, CbsHeader cbsHeader){
		return super.find(findCriteria, cbsHeader);
	}
	
	@Override
	public IsoFeeMap getByPk(String publicKey, IsoFeeMap reference) {
		return super.getByPk(publicKey, reference);
	}

}
