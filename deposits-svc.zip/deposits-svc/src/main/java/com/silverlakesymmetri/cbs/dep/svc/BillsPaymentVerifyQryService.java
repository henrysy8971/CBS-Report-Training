package com.silverlakesymmetri.cbs.dep.svc;

import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation;
import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation.ServiceOperationType;
import com.silverlakesymmetri.cbs.commons.svc.BusinessService;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.BillsPaymentOnlineVerify;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.BillsPaymentOnlineVerifyJpe;

public interface BillsPaymentVerifyQryService extends BusinessService<BillsPaymentOnlineVerify, BillsPaymentOnlineVerifyJpe> {

    public static final String SVC_OP_NAME_BILLPAYMENT_QRY_VERIFY = "BillsPaymentVerifyQryService.verify";

    @ServiceOperation(name = SVC_OP_NAME_BILLPAYMENT_QRY_VERIFY, type = ServiceOperationType.GET)
    public BillsPaymentOnlineVerify verify(String instCode, String paymentRef, String tranType);

}
