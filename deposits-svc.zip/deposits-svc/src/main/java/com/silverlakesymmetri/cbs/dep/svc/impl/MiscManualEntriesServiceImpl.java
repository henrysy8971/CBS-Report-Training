package com.silverlakesymmetri.cbs.dep.svc.impl;

import com.mysema.query.types.EntityPath;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.context.CbsSessionContext;
import com.silverlakesymmetri.cbs.commons.exception.base.CbsServiceProcessException;
import com.silverlakesymmetri.cbs.commons.exception.base.helper.ExceptionHelper;
import com.silverlakesymmetri.cbs.commons.svc.AbstractXmlApiBusinessService;
import com.silverlakesymmetri.cbs.commons.xmlapi.enums.CbsXmlApiOperation;
import com.silverlakesymmetri.cbs.csd.util.DateHelperDataHolder;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.AcctSweep;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.MiscManualEntries;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.AcctJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.MiscManualEntriesJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.QMiscManualEntriesJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.id.MiscManualEntriesPk;
import com.silverlakesymmetri.cbs.dep.svc.MiscManualEntriesService;
import com.silverlakesymmetri.cbs.dep.svc.mapper.MiscManualEntriesServiceMapper;
import com.silverlakesymmetri.cbs.dep.xmlapi.DEPMISCHISTAPIType;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Map;

@Service
public class MiscManualEntriesServiceImpl extends AbstractXmlApiBusinessService<MiscManualEntries, MiscManualEntriesJpe, MiscManualEntriesPk, DEPMISCHISTAPIType, DEPMISCHISTAPIType>
        implements MiscManualEntriesService {

    private static final String TRAN_HIST_SEQ = "DEP_TRAN_HIST_S";
    private static final String CBS_CHANNEL_SOURCE = "HTTP-UI";
    private static final String BRANCH_CANNOT_BE_NULL = "CBS.B.DEP.MISC_MANUAL_ENTRIES_SERVICE.0001";

    @Autowired
    MiscManualEntriesServiceMapper mapper;

    @Override
    protected EntityPath<MiscManualEntriesJpe> getEntityPath() {
        return QMiscManualEntriesJpe.miscManualEntriesJpe;
    }

    @Override
    protected MiscManualEntriesPk getIdFromDataObjectInstance(MiscManualEntries dataObject) {
        MiscManualEntriesJpe jpe = jaxbSdoHelper.unwrap(dataObject);
        return new MiscManualEntriesPk(jpe.getSeqNo(), jpe.getTranDate());
    }

    @Override
    public MiscManualEntries create(MiscManualEntries dataObject) {
        return super.create(dataObject);
    }

    @Override
    protected MiscManualEntries preCreateValidation(MiscManualEntries dataObject) {
        CbsSessionContext sessionCtx = cbsRuntimeContextManager.getContext(CbsSessionContext.class);
        if (sessionCtx.getChannelSource().equals(CBS_CHANNEL_SOURCE)) {
            dataObject.setBranch(sessionCtx.getBranch());
        }

        validateBranch(dataObject);

        long mainSeqNo = dataService.nextSequenceValue(TRAN_HIST_SEQ).longValue();
        dataObject.setSeqNo(mainSeqNo);

        return super.preCreateValidation(dataObject);
    }

    private void validateBranch(MiscManualEntries dataObject) {
        Collection<Throwable> exceptions = new ArrayList<>();
        // Effect From Date cannot be a holiday

        if(dataObject.getBranch() == null || dataObject.getBranch().isEmpty()) {
            String msg = messageUtils.getMessage(BRANCH_CANNOT_BE_NULL, new String[] { });
            CbsServiceProcessException exec = new CbsServiceProcessException(BRANCH_CANNOT_BE_NULL, msg);
            exceptions.add(exec);
        }

        ExceptionHelper.createAndThrowAggregateException(exceptions);
    }

    @Override
    public MiscManualEntries update(MiscManualEntries dataObject) {
        return super.update(dataObject);
    }

    @Override
    public boolean delete(MiscManualEntries dataObject) {
        return super.delete(dataObject);
    }

    @Override
    public List<MiscManualEntries> query(int offset, int resultLimit, String groupBy, String order, Map<String, Object> filters) {
        return super.query(offset, resultLimit, groupBy, order, filters);
    }

    @Override
    public List<MiscManualEntries> find(FindCriteria findCriteria, CbsHeader cbsHeader) {
        return super.find(findCriteria, cbsHeader);
    }

    @Override
    public MiscManualEntries getByPk(String publicKey, MiscManualEntries reference) {
        return super.getByPk(publicKey, reference);
    }

    @Override
    protected DEPMISCHISTAPIType transformBdoToXmlApiRqCreate(MiscManualEntries dataObject) {
        return transformMiscManualEntriesToDEPMISCHISTAPIType(dataObject, CbsXmlApiOperation.INSERT);
    }

    @Override
    protected DEPMISCHISTAPIType transformBdoToXmlApiRqUpdate(MiscManualEntries dataObject) {
        return  transformMiscManualEntriesToDEPMISCHISTAPIType(dataObject, CbsXmlApiOperation.UPDATE);
    }

    @Override
    protected DEPMISCHISTAPIType transformBdoToXmlApiRqDelete(MiscManualEntries dataObject) {
        return  transformMiscManualEntriesToDEPMISCHISTAPIType(dataObject, CbsXmlApiOperation.DELETE);
    }

    @Override
    protected MiscManualEntries processXmlApiRs(MiscManualEntries dataObject, DEPMISCHISTAPIType depmischistapiType) {
        if (dataObject == null){
            dataObject = jaxbSdoHelper.createSdoInstance(MiscManualEntries.class);
        }
        MiscManualEntriesJpe jpe = mapper.mapToJpe(depmischistapiType,jaxbSdoHelper.unwrap(dataObject));
        return jaxbSdoHelper.wrap(jpe);
    }

    @Override
    protected List<MiscManualEntries> processXmlApiListRs(MiscManualEntries dataObject, DEPMISCHISTAPIType depmischistapiType) {
        return null;
    }

    @Override
    protected Class<DEPMISCHISTAPIType> getXmlApiResponseClass() {
        return DEPMISCHISTAPIType.class;
    }

    private DEPMISCHISTAPIType transformMiscManualEntriesToDEPMISCHISTAPIType(MiscManualEntries dataObject, CbsXmlApiOperation oper) {
        MiscManualEntriesJpe jpe = jaxbSdoHelper.unwrap(dataObject);
        jpe.setTranDate(dateTimeHelper.getRunDate());
        DEPMISCHISTAPIType apiType = new DEPMISCHISTAPIType();
        apiType = mapper.mapToApi(jpe, oper, apiType);
        super.setTechColsFromDataObject(dataObject, apiType);

        return apiType;
    }
}
