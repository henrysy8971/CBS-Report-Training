package com.silverlakesymmetri.cbs.dep.svc.impl;

import com.mysema.query.types.EntityPath;
import com.silverlakesymmetri.cbs.commons.svc.AbstractBusinessService;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.RecalcTax;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.QRecalcTaxJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.RecalcTaxJpe;
import com.silverlakesymmetri.cbs.dep.svc.DepUtilityService;
import com.silverlakesymmetri.cbs.dep.svc.RecalcTaxService;
import com.silverlakesymmetri.cbs.dep.util.RecalcTaxObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Collections;
import java.util.List;
import java.util.Map;

@Service
public class RecalcTaxServiceImpl extends AbstractBusinessService<RecalcTax, RecalcTaxJpe, String> implements RecalcTaxService {

	@Autowired
	private DepUtilityService depUtilityService;

	@Override
	protected String getIdFromDataObjectInstance(RecalcTax dataObject) {
		return "";
	}

	@Override
	protected EntityPath<RecalcTaxJpe> getEntityPath() {
		return QRecalcTaxJpe.recalcTaxJpe;
	}
	
	@Override
	public List<RecalcTax> query(int offset, int resultLimit, String groupBy, String order,
			Map<String, Object> filters) {

		String scType = (String) filters.get("scType");
		Double scAmt = filters.get("scAmt") == null ? null : Double.valueOf((String) filters.get("scAmt"));
		Double scTaxAmt = filters.get("scTaxAmt") == null ? null : Double.valueOf((String) filters.get("scTaxAmt"));
		String ccy = (String) filters.get("ccy");
		String acctNo = (String) filters.get("acctNo");
		String certNo = (String) filters.get("certNo");
		RecalcTaxObject recalcTaxObject = depUtilityService.getRecalcTaxExt(scType, scAmt, scTaxAmt, ccy, acctNo, certNo);
		if (recalcTaxObject == null) {
			return Collections.emptyList();
		}
		return Collections.singletonList(mapFromRecalcTaxObject(recalcTaxObject));
	}

	private RecalcTax mapFromRecalcTaxObject(RecalcTaxObject recalcTaxObject) {
		RecalcTax recalcTax = jaxbSdoHelper.createSdoInstance(RecalcTax.class);
		recalcTax.setScType(recalcTaxObject.getScType());
		recalcTax.setScAmt(recalcTaxObject.getScAmt());
		recalcTax.setScTaxAmt(recalcTaxObject.getScTaxAmt());
		recalcTax.setCcy(recalcTaxObject.getCcy());
		recalcTax.setAcctNo(recalcTaxObject.getAcctNo());
		recalcTax.setCertNo(recalcTaxObject.getCertNo());
		return recalcTax;
	}
}
