package com.silverlakesymmetri.cbs.dep.svc;

import java.util.List;
import java.util.Map;

import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation;
import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation.ServiceOperationType;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.svc.BusinessService;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.IsoFeeMap;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.IsoFeeMapJpe;

public interface IsoFeeMapService extends BusinessService<IsoFeeMap, IsoFeeMapJpe>{
	public static final String SVC_OP_NAME_ISOFEEMAPSERVICE_CREATE = "IsoFeeMapService.create";
	public static final String SVC_OP_NAME_ISOFEEMAPSERVICE_UPDATE = "IsoFeeMapService.update";
	public static final String SVC_OP_NAME_ISOFEEMAPSERVICE_DELETE = "IsoFeeMapService.delete";
	public static final String SVC_OP_NAME_ISOFEEMAPSERVICE_QUERY = "IsoFeeMapService.query";
	public static final String SVC_OP_NAME_ISOFEEMAPSERVICE_FIND = "IsoFeeMapService.find";
	public static final String SVC_OP_NAME_ISOFEEMAPSERVICE_GET = "IsoFeeMapService.get";
	
	@ServiceOperation(name = SVC_OP_NAME_ISOFEEMAPSERVICE_CREATE)
	public IsoFeeMap create(IsoFeeMap dataObject);

	@ServiceOperation(name = SVC_OP_NAME_ISOFEEMAPSERVICE_UPDATE)
	public IsoFeeMap update(IsoFeeMap dataObject);

	@ServiceOperation(name = SVC_OP_NAME_ISOFEEMAPSERVICE_DELETE)
	public boolean delete(IsoFeeMap dataObject);

	@ServiceOperation(name = SVC_OP_NAME_ISOFEEMAPSERVICE_QUERY)
	public List<IsoFeeMap> query(int offset, int resultLimit, String groupBy, String order,
			Map<String, Object> filters);

	@ServiceOperation(name = SVC_OP_NAME_ISOFEEMAPSERVICE_FIND)
	public List<IsoFeeMap> find(FindCriteria findCriteria, CbsHeader cbsHeader);

	@ServiceOperation(name = SVC_OP_NAME_ISOFEEMAPSERVICE_GET, type = ServiceOperationType.GET)
	public IsoFeeMap getByPk(String publicKey, IsoFeeMap reference);
}
