package com.silverlakesymmetri.cbs.dep.svc.mapper;

import com.silverlakesymmetri.cbs.commons.jpa.util.DateTimeHelper;
import com.silverlakesymmetri.cbs.commons.xmlapi.enums.CbsXmlApiOperation;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.AcctTypeChangeJpe;
import com.silverlakesymmetri.cbs.dep.svc.mapper.decorator.AcctTypeTransferServiceDecorator;
import com.silverlakesymmetri.cbs.dep.svc.mapper.mapping.AcctTypeTransferToDEPACCTTYPETFRAPITypeMapper;
import com.silverlakesymmetri.cbs.dep.xmlapi.DEPACCTTYPETFRAPIType;
import org.mapstruct.*;

import java.util.Map;

/**
 * Created by Emerson.Sanchez on 14/10/2019.
 */
@Mapper(config=AcctTypeTransferToDEPACCTTYPETFRAPITypeMapper.class, uses={ DateTimeHelper.class})
@DecoratedWith(AcctTypeTransferServiceDecorator.class)
public interface AcctTypeTransferServiceMapper {
    @Mappings({
            @Mapping(expression = "java(operation != null ? operation.getOperation() : null)", target="OPERATION")
    })
    @InheritConfiguration
    public DEPACCTTYPETFRAPIType mapToApi(AcctTypeChangeJpe jpe, @Context CbsXmlApiOperation operation);


    @InheritInverseConfiguration(name = "jpeToApiType")
    public AcctTypeChangeJpe mapToJpe(DEPACCTTYPETFRAPIType api, @MappingTarget AcctTypeChangeJpe jpe);
}
