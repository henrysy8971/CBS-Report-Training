package com.silverlakesymmetri.cbs.dep.svc.mapper;

import java.util.Map;

import com.silverlakesymmetri.cbs.dep.svc.mapper.mapping.DataElementstoDEPATMAPITypeMapper;
import com.silverlakesymmetri.cbs.dep.xmlapi.DEPATMAPIType;
import org.mapstruct.Context;
import org.mapstruct.DecoratedWith;
import org.mapstruct.InheritConfiguration;
import org.mapstruct.InheritInverseConfiguration;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingTarget;
import org.mapstruct.Mappings;

import com.silverlakesymmetri.cbs.commons.jpa.util.DateTimeHelper;
import com.silverlakesymmetri.cbs.commons.xmlapi.enums.CbsXmlApiOperation;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.DataElementsJpe;
import com.silverlakesymmetri.cbs.dep.svc.mapper.decorator.AtmTranServiceDecorator;

@Mapper(config= DataElementstoDEPATMAPITypeMapper.class, uses={ DateTimeHelper.class})
@DecoratedWith(AtmTranServiceDecorator.class)
public interface AtmTranServiceMapper {

	@Mappings({
		 @Mapping(expression = "java(oper != null ? oper.getOperation() : null)", target="OPERATION")
	 })
	@InheritConfiguration
	public DEPATMAPIType mapToApi(DataElementsJpe jpe, @Context CbsXmlApiOperation oper, @Context Map otherInfo);
	
	@InheritInverseConfiguration(name = "mapDataElementsToDEPATMAPIType")
	//@Mapping(source = "EFFECTDATE", target="trfDate", qualifiedByName = {"DateTimeHelper","convertCbsApiDateToString"})
	public DataElementsJpe mapToJpe(DEPATMAPIType api, @MappingTarget DataElementsJpe jpe);
	
}
