package com.silverlakesymmetri.cbs.dep.svc.mapper.decorator;



import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

import com.silverlakesymmetri.cbs.commons.xmlapi.enums.CbsXmlApiOperation;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.AcctRestraintJpe;
import com.silverlakesymmetri.cbs.dep.svc.mapper.AcctRestraintServiceMapper;
import com.silverlakesymmetri.cbs.dep.xmlapi.DEPRESTRAINTSAPIType;

public abstract class AcctRestraintServiceDecorator extends FeeServiceDecorator implements AcctRestraintServiceMapper {

		@Autowired
		@Qualifier("delegate")
		protected AcctRestraintServiceMapper delegate;
		
		@Override
		public DEPRESTRAINTSAPIType mapToApi(AcctRestraintJpe jpe, CbsXmlApiOperation oper, Map otherInfo) {
			if(jpe.getAutoGenFee() == null) {
				jpe.setAutoGenFee("N");
			}
			DEPRESTRAINTSAPIType req  = (DEPRESTRAINTSAPIType)delegate.mapToApi(jpe, oper, otherInfo);
			mapFeeToApi(jpe, req);
			return  req;
		}
		
		public AcctRestraintJpe mapToJpe(DEPRESTRAINTSAPIType api, AcctRestraintJpe jpe)
		{
			//jpe.setSeqNo(api.getREFERENCENO().longValue());
			if (jpe == null) {
				jpe = new AcctRestraintJpe();
			}
			if (api == null) {
				return jpe;
			}
			jpe = delegate.mapToJpe(api, jpe);
			mapFeeToJpe(api, jpe);
			return jpe;
		}
}
