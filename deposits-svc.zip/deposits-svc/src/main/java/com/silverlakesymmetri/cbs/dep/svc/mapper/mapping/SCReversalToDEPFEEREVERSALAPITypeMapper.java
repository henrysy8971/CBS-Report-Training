package com.silverlakesymmetri.cbs.dep.svc.mapper.mapping;

import org.mapstruct.MapperConfig;
import org.mapstruct.Mapping;
import org.mapstruct.Mappings;

import com.silverlakesymmetri.cbs.commons.jpa.util.DateTimeHelper;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.SCReversalJpe;
import com.silverlakesymmetri.cbs.dep.xmlapi.DEPFEEREVERSALAPIType;

@MapperConfig(uses={ DateTimeHelper.class})
public interface SCReversalToDEPFEEREVERSALAPITypeMapper {

	@Mappings({
		@Mapping(source = "actionInd", target = "ACTIONINDICATOR"),
		@Mapping(source = "status", target = "STATUS"),
		@Mapping(source = "scLocation", target = "SCLOCATION"),
		@Mapping(source = "scDate", target = "SCDATE", qualifiedByName = {"DateTimeHelper","convertDateToCbsXmlApiDate"}),
		@Mapping(source = "scSeqNo", target = "SCSEQNO"),
		@Mapping(source = "scType", target = "SCTYPE"),
		@Mapping(source = "scRateType", target = "SCRATETYPE"),
		@Mapping(source = "internalKey", target = "RBINTERNALKEY"),
		@Mapping(source = "reasonType", target = "REASONTYPE"),
		@Mapping(source = "reasonDesc", target = "REASONDESC")
	})
	public DEPFEEREVERSALAPIType mapSCReversalToDEPFEEREVERSALAPIType(SCReversalJpe jpe);

}
