package com.silverlakesymmetri.cbs.dep.svc.impl;

import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.silverlakesymmetri.cbs.dep.svc.util.AcctHelper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mysema.query.types.EntityPath;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.jpa.util.DateTimeHelper;
import com.silverlakesymmetri.cbs.commons.svc.AbstractBusinessService;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.AcctStats;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.AcctJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.AcctStatsJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.QAcctStatsJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.id.AcctStatsPk;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.util.DepJpeConstants;
import com.silverlakesymmetri.cbs.dep.jpa.util.DepUtil;
import com.silverlakesymmetri.cbs.dep.jpa.util.DepStorHelper;
import com.silverlakesymmetri.cbs.dep.svc.AcctStatsService;


@Service
public class AcctStatsServiceImpl extends AbstractBusinessService<AcctStats, AcctStatsJpe, AcctStatsPk> implements AcctStatsService {

	private static final String INTERNAL_KEY = "internalKey";
	private static final String ACCT_NO = "acctNo";
	private static final String CERTIFICATE_NO = "certificateNo";
	
	@Autowired
	private DepStorHelper depStorHelper;
	
	@Autowired
	private DepUtil depUtil;
	
	@Autowired
    protected DateTimeHelper dateTimeHelper;
	
	@Autowired
	private AcctHelper acctHelper;
	
	@Override
	public AcctStats getByPk(String publicKey, AcctStats accStats) {
		return setDefaultAmounts(super.getByPk(publicKey, accStats), getReferenceAcct(publicKey));
	}

	@Override
	public List<AcctStats> query(int offset, int resultLimit, String groupBy, String order,
			Map<String, Object> filters) {
		
		Long internalKey = null;
		if (filters.containsKey(ACCT_NO)) {
			String acctNo = (String) filters.get(ACCT_NO);
			if (filters.containsKey(CERTIFICATE_NO)) {
				String certificateNo = (String) filters.get(CERTIFICATE_NO);
				internalKey = acctHelper.getInternalKeyByAcctNoAndCertificateNo(acctNo, certificateNo);
				filters.remove(CERTIFICATE_NO);
			} else {
				internalKey = acctHelper.getInternalKeyByAcctNo(acctNo);
			}
			filters.remove(ACCT_NO);
		}

		if (internalKey != null) {
			filters.put(INTERNAL_KEY, internalKey);
		}
		
		List<AcctStats> acctStatsList = super.query(offset, resultLimit, groupBy, order, filters);

		if (!(acctStatsList == null || acctStatsList.isEmpty() || internalKey == null)) {
			AcctStats acctStats = acctStatsList.get(0);
			return Collections.singletonList(setDefaultAmounts(acctStats, getReferenceAcct(acctStats.getAcctNo())));
		}

		return Collections.emptyList();
	}

	@Override
	public List<AcctStats> find(FindCriteria findCriteria, CbsHeader cbsHeader) {
		return super.find(findCriteria, cbsHeader);
	}

	@Override
	protected AcctStatsPk getIdFromDataObjectInstance(AcctStats dataObject) {
		Map<String, Object> params = new HashMap<String, Object>();
		params.put("acctNo", dataObject.getAcctNo());
		Long result = dataService.getWithNamedQuery(DepJpeConstants.ACCT_JPE_FIND_INTERNAL_KEY_BY_ACCT_NO, params, Long.class);
		return new AcctStatsPk(result);
	}

	@Override
	protected EntityPath<AcctStatsJpe> getEntityPath() {
		return QAcctStatsJpe.acctStatsJpe;
	}

	private AcctJpe getReferenceAcct(String acctNo) {
		Map<String, Object> params = new HashMap<>();
		params.put("acctNo", acctNo);
		List<AcctJpe> acctList = dataService.findWithNamedQuery(DepJpeConstants.ACCT_JPE_FIND_ACCT_BY_ACCT_NO, params, AcctJpe.class);
		return !(acctList == null || acctList.isEmpty()) ? acctList.get(0) : null;
	}

	private AcctStats setDefaultAmounts(AcctStats acctStats, AcctJpe acctJpe) {
		if (acctJpe == null) {
			return acctStats;
		}

		Map<String, Object> result = depStorHelper.getAveBal(acctJpe.getInternalKey(), acctJpe.getDepositType(),
				acctJpe.getAcctStatus(), acctJpe.getAcctOpenDate(), acctJpe.getOpenTranDate());

		if(!(result == null || result.isEmpty())) {
			for (String key : result.keySet()) {
				switch (key) {
					case "aveBalMthly":
						if (result.get(key) != null) {
							Double avgDailyBalMtd = (Double) result.get(key);
							acctStats.setAvgDailyBalMtd(avgDailyBalMtd * (-1));
						}
						break;
					case "aveBalYrly":
						if (result.get(key) != null) {
							Double avgDailyBalYtd = (Double) result.get(key);
							acctStats.setAvgDailyBalYtd(avgDailyBalYtd * (-1));
						}
						break;
				}
			}
		}

		//Set Default Value Double 0.0 if null, if less than 0 set values to positive and if positive set values to negative
		acctStats.setHighBalCtd(depUtil.getNegateOrDefault(acctStats.getHighBalCtd(), 0.0));
		acctStats.setHighBalMtd(depUtil.getNegateOrDefault(acctStats.getHighBalMtd(), 0.0));
		acctStats.setHighBalYtd(depUtil.getNegateOrDefault(acctStats.getHighBalYtd(), 0.0));

		acctStats.setLowBalCtd(depUtil.getNegateOrDefault(acctStats.getLowBalCtd(), 0.0));
		acctStats.setLowBalMtd(depUtil.getNegateOrDefault(acctStats.getLowBalMtd(), 0.0));
		acctStats.setLowBalYtd(depUtil.getNegateOrDefault(acctStats.getLowBalYtd(), 0.0));

		if (acctStats.getCtdDays() == null) {
			acctStats.setCtdDays(0);
		}

		//Compute for the cycle to date average balance
		Double aveBalCtd = depStorHelper.getAveBalCtd(acctJpe.getAcctStatus(), acctJpe.getDepositType(),
				acctStats.getCtrlDate(), acctStats.getStatCtrlDate(), dateTimeHelper.getRunDate(),
				acctJpe.getOpenTranDate(), acctJpe.getAcctOpenDate(), acctStats.getAcctBal(),
				acctStats.getPrevAcctBal(), acctStats.getAggBalCtd(), acctStats.getCtdDays());
		acctStats.setAvgDailyBalCtd(aveBalCtd * -1);
		return acctStats;
	}
}
