package com.silverlakesymmetri.cbs.dep.svc.mapper.mapping;

import org.mapstruct.MapperConfig;
import org.mapstruct.Mapping;
import org.mapstruct.Mappings;

import com.silverlakesymmetri.cbs.commons.jpa.util.DateTimeHelper;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.OdOvdAdHocJpe;
import com.silverlakesymmetri.cbs.dep.xmlapi.DEPODOVDAPIType;

@MapperConfig(uses = { DateTimeHelper.class, OdOvdAdHocToDEPODOVDAPITypeMapper.class })
public interface OdOvdAdHocToDEPODOVDAPITypeMapper {
	@Mappings({
		@Mapping(source = "ovdSeqNo", target = "OVDSEQNO"),
		@Mapping(source = "internalKey", target = "INTERNALKEY"),
		@Mapping(source = "agreementNo", target = "AGREEMENTNO"),
		@Mapping(source = "odSeqNo", target = "ODSEQNO"),
		@Mapping(source = "tranType", target = "TRANTYPE"),
		@Mapping(source = "tranDate", target = "TRANDATE", qualifiedByName = { "DateTimeHelper", "convertDateToCbsXmlApiDate" }),
		@Mapping(source = "effectDate", target = "EFFECTDATE", qualifiedByName = { "DateTimeHelper", "convertDateToCbsXmlApiDate" }),
		@Mapping(source = "tranAmt", target = "TRANAMT"),
		@Mapping(source = "ccy", target = "CCY"),
		@Mapping(source = "acctAmt", target = "ACCTAMT"),
		@Mapping(source = "narrative", target = "NARRATIVE"),
		@Mapping(source = "officerId", target = "OFFICERID"),
		@Mapping(source = "fromRateFlag", target = "FROMRATEFLAG"),
		@Mapping(source = "fromXrate", target = "FROMXRATE"),
		@Mapping(source = "fromId", target = "FROMID"),
		@Mapping(source = "baseEquivAmt", target = "BASEEQUIVAMT"),
		@Mapping(source = "toRateFlag", target = "TORATEFLAG"),
		@Mapping(source = "toXrate", target = "TOXRATE"),
		@Mapping(source = "toId", target = "TOID"),
		@Mapping(source = "origCrossRate", target = "ORIGCROSSRATE"),
		@Mapping(source = "origCrossId", target = "ORIGCROSSID"),
		@Mapping(source = "origAcctAmt", target = "ORIGACCTAMT"),
		@Mapping(source = "ovCrossRate", target = "OVCROSSRATE"),
		@Mapping(source = "ovCrossId", target = "OVCROSSID"),
		// @Mapping(source = "orfInd", target = "ORFIND"),
		@Mapping(source = "maturityDate", target = "MATURITYDATE", qualifiedByName = { "DateTimeHelper", "convertDateToCbsXmlApiDate" }),
		@Mapping(source = "feeSeqNo", target = "FEESEQNO"),
		@Mapping(source = "startAmortizationDate", target = "STARTAMORTIZATIONDATE", qualifiedByName = { "DateTimeHelper", "convertDateToCbsXmlApiDate" }),
		@Mapping(source = "endAmortizationDate", target = "ENDAMORTIZATIONDATE", qualifiedByName = { "DateTimeHelper", "convertDateToCbsXmlApiDate" }),
		@Mapping(source = "status", target = "STATUS"),
		@Mapping(source = "rbTranDate", target = "RBTRANDATE", qualifiedByName = { "DateTimeHelper", "convertDateToCbsXmlApiDate" }),
		@Mapping(source = "rbSeqNo", target = "RBSEQNO"),
		@Mapping(source = "lastErrorNo", target = "LASTERRORNO"),
		@Mapping(source = "reversalOvdSeqNo", target = "REVERSALOVDSEQNO"),
		@Mapping(source = "scEventType", target = "SCEVENTTYPE"),
		@Mapping(source = "scType", target = "SCTYPE"),
		@Mapping(source = "scRateType", target = "SCRATETYPE"),
		@Mapping(source = "scCalcBalType", target = "SCCALCBALTYPE"),
		@Mapping(source = "scCalcBal", target = "SCCALCBAL"),
		@Mapping(source = "scCalcBalCcy", target = "SCCALCBALCCY"),
		@Mapping(source = "input1", target = "INPUT1"),
		@Mapping(source = "input2", target = "INPUT2"),
		@Mapping(source = "input3", target = "INPUT3"),
		@Mapping(source = "input4", target = "INPUT4"),
		@Mapping(source = "input5", target = "INPUT5"),
		@Mapping(source = "input6", target = "INPUT6"),
		@Mapping(source = "input7", target = "INPUT7"),
		@Mapping(source = "input8", target = "INPUT8"),
		@Mapping(source = "channel", target = "CHANNEL"),
		@Mapping(source = "channelSource", target = "CHANNELSOURCE"),
		@Mapping(source = "productClass", target = "PRODUCTCLASS"),
		@Mapping(source = "scMode", target = "SCMODE"),
		@Mapping(source = "scReasonType", target = "SCREASONTYPE"),
		@Mapping(source = "scReasonDesc", target = "SCREASONDESC"),
		@Mapping(source = "scAmtStandard", target = "SCAMTSTANDARD"),
		@Mapping(source = "scTaxAmtStandard", target = "SCTAXAMTSTANDARD"),
		@Mapping(source = "scAmt", target = "SCAMT"),
		@Mapping(source = "scTaxAmt", target = "SCTAXAMT"),
		@Mapping(source = "scDate", target = "SCDATE", qualifiedByName = { "DateTimeHelper", "convertDateToCbsXmlApiDate" }),
		@Mapping(source = "scSeqNo", target = "SCSEQNO")
	})
	public DEPODOVDAPIType mapOdOvdAdHocToDEPODOVDAPIType(OdOvdAdHocJpe jpe);
}
