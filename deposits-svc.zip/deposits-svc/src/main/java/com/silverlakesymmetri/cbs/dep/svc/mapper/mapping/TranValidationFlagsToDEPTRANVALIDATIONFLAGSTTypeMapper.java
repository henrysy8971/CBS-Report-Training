package com.silverlakesymmetri.cbs.dep.svc.mapper.mapping;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Mappings;

import com.silverlakesymmetri.cbs.commons.jpa.util.DateTimeHelper;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.TranValidationFlagsJpe;
import com.silverlakesymmetri.cbs.dep.xmlapi.DEPTRANVALIDATIONFLAGSTType;

@Mapper(uses = { DateTimeHelper.class })
public interface TranValidationFlagsToDEPTRANVALIDATIONFLAGSTTypeMapper {

	@Mappings({
	    @Mapping(source = "ignRestraint", target = "IGNRESTRAINT"),
	    @Mapping(source = "ignAvailBal", target = "IGNAVAILBAL"),
	    @Mapping(source = "chkOverride", target = "CHKOVERRIDE"),
	    @Mapping(source = "chkTellerLimit", target = "CHKTELLERLIMIT"),
	    @Mapping(source = "chkEffDate", target = "CHKEFFDATE")
	})
	public DEPTRANVALIDATIONFLAGSTType mapTranValidationFlagsToDEPTRANVALIDATIONFLAGST(TranValidationFlagsJpe jpe);
		
}
