package com.silverlakesymmetri.cbs.dep.svc;

import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation;
import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation.ServiceOperationType;
import com.silverlakesymmetri.cbs.commons.svc.BusinessService;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.AcctClosure;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.AcctClosureJpe;

import java.util.List;
import java.util.Map;

public interface AcctClosureQueryService extends BusinessService<AcctClosure, AcctClosureJpe> {
	String SVC_OP_NAME_ACCTCLOSUREQUERYSERVICE_QUERY = "AcctClosureQueryService.query";

	@ServiceOperation(name = SVC_OP_NAME_ACCTCLOSUREQUERYSERVICE_QUERY, type = ServiceOperationType.GET)
	List<AcctClosure> query(int offset, int resultLimit, String groupBy, String order, Map<String, Object> filters);
}
