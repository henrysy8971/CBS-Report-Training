package com.silverlakesymmetri.cbs.dep.svc.impl;

import com.mysema.query.types.EntityPath;
import com.silverlakesymmetri.cbs.commons.svc.AbstractXmlApiBusinessService;
import com.silverlakesymmetri.cbs.commons.xmlapi.enums.CbsXmlApiOperation;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.AcctInterestDetailQry;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.AcctInterestDetailQryJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.QAcctInterestDetailQryJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.id.AcctInterestDetailQryPk;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.util.DepJpeConstants;
import com.silverlakesymmetri.cbs.dep.svc.AcctInterestDetailQryService;
import com.silverlakesymmetri.cbs.dep.svc.mapper.AcctInterestDetailServiceMapper;
import com.silverlakesymmetri.cbs.dep.svc.util.AcctHelper;
import com.silverlakesymmetri.cbs.dep.xmlapi.DEPINTDETAILQRYAPIType;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class AcctInterestDetailQryServiceImpl extends AbstractXmlApiBusinessService<AcctInterestDetailQry, AcctInterestDetailQryJpe, AcctInterestDetailQryPk, DEPINTDETAILQRYAPIType, DEPINTDETAILQRYAPIType>
        implements AcctInterestDetailQryService {

    private static final String ACCT_NO = "acctNo";
    private static final String CERTIFICATE_NO = "certificateNo";

    @Autowired
    private AcctInterestDetailServiceMapper acctInterestDetailServiceMapper;

    @Autowired
    private AcctHelper acctHelper;

    @Override
    protected AcctInterestDetailQryPk getIdFromDataObjectInstance(AcctInterestDetailQry dataObject) {
        AcctInterestDetailQryJpe jpe = jaxbSdoHelper.unwrap(dataObject);
        return new AcctInterestDetailQryPk(jpe.getInternalKey());
    }

    @Override
    protected EntityPath<AcctInterestDetailQryJpe> getEntityPath() {
        return QAcctInterestDetailQryJpe.acctInterestDetailQryJpe;
    }
    
    @Override
    public AcctInterestDetailQry getByPk(String publicKey, AcctInterestDetailQry reference) {
    	if(reference == null) {
    		reference = jaxbSdoHelper.createSdoInstance(AcctInterestDetailQry.class);
    	}
    	reference.setAcctNo(publicKey);
    	return getAcctInterestDetail(reference);
    }

    @Override
    public List<AcctInterestDetailQry> query(int offset, int resultLimit, String groupBy, String order,
                                      Map<String, Object> filters) {

        AcctInterestDetailQry reference = jaxbSdoHelper.createSdoInstance(AcctInterestDetailQry.class);
        if (filters.containsKey(ACCT_NO)) {
            reference.setAcctNo((String) filters.get(ACCT_NO));
        }
        if (filters.containsKey(CERTIFICATE_NO)) {
            reference.setCertificateNo((String) filters.get(CERTIFICATE_NO));
        }

        AcctInterestDetailQry acctInterestDetailQry = getAcctInterestDetail(reference);
        if (acctInterestDetailQry == null) {
            return Collections.emptyList();
        }
        return Collections.singletonList(acctInterestDetailQry);
    }

    @Override
    protected DEPINTDETAILQRYAPIType transformBdoToXmlApiRqCreate(AcctInterestDetailQry dataObject) {
        return null;
    }

    @Override
    protected DEPINTDETAILQRYAPIType transformBdoToXmlApiRqUpdate(AcctInterestDetailQry dataObject) {
        return null;
    }

    @Override
    protected DEPINTDETAILQRYAPIType transformBdoToXmlApiRqDelete(AcctInterestDetailQry dataObject) {
        return null;
    }

    @Override
    public AcctInterestDetailQry getAcctInterestDetail(AcctInterestDetailQry dataObject) {
        return queryDataObject(transformAcctInterestDetailQryToDEPINTDETAILQRYAPIType(dataObject, CbsXmlApiOperation.QUERY));
    }

    @Override
    protected AcctInterestDetailQry processXmlApiRs(AcctInterestDetailQry dataObject, DEPINTDETAILQRYAPIType apiType) {
        AcctInterestDetailQryJpe jpe = acctInterestDetailServiceMapper.mapToJpe(apiType);

        jpe.setAcctNo(getAcctNo(jpe.getInternalKey()));
        jpe.setCrCalcBal(getCrCalcBal(jpe.getInternalKey()));
        jpe.setDrCalcBal(getDrCalcBal(jpe.getInternalKey()));

        jpe.setCrIntPaidLastCycle((jpe.getCrIntPosted() == null ? 0 : jpe.getCrIntAdjPosted()) + (jpe.getCrIntAdjPosted() == null ? 0 : jpe.getCrIntAdjPosted()));
        jpe.setCrIntPaidYearToDate((jpe.getCrIntPaidYtd() == null ? 0 : jpe.getCrIntPaidYtd()) + (jpe.getCrIntAdjYtd() == null ? 0 : jpe.getCrIntAdjYtd()));

        jpe.setDrIntPaidLastCycle((jpe.getDrIntPosted() == null ? 0 : jpe.getDrIntAdjPosted()) + (jpe.getDrIntAdjPosted() == null ? 0 : jpe.getDrIntAdjPosted()));
        jpe.setDrIntPaidYearToDate((jpe.getDrIntCollYtd() == null ? 0 : jpe.getDrIntCollYtd()) + (jpe.getDrIntAdjYtd() == null ? 0 : jpe.getDrIntAdjYtd()));

        return jaxbSdoHelper.wrap(jpe);
    }

    @Override
    protected List<AcctInterestDetailQry> processXmlApiListRs(AcctInterestDetailQry dataObject, DEPINTDETAILQRYAPIType depintdetailqryapiType) {
        return null;
    }

    @Override
    protected Class<DEPINTDETAILQRYAPIType> getXmlApiResponseClass() {
        return DEPINTDETAILQRYAPIType.class;
    }

    private DEPINTDETAILQRYAPIType transformAcctInterestDetailQryToDEPINTDETAILQRYAPIType(AcctInterestDetailQry dataObject, CbsXmlApiOperation oper) {
        AcctInterestDetailQryJpe jpe = jaxbSdoHelper.unwrap(dataObject);
        DEPINTDETAILQRYAPIType apiType =  acctInterestDetailServiceMapper.mapToApi(jpe, oper);

        Long internalKey = 0L;
        if (StringUtils.isNotBlank(dataObject.getAcctNo())) {
            if (StringUtils.isNotBlank(dataObject.getCertificateNo())) {
                internalKey = acctHelper.getInternalKeyByAcctNoAndCertificateNo(dataObject.getAcctNo(), dataObject.getCertificateNo());
            } else {
                internalKey = acctHelper.getInternalKeyByAcctNo(dataObject.getAcctNo());
            }
        }
        if (internalKey == null) {
            apiType.setINTERNALKEY(0);
        } else {
            apiType.setINTERNALKEY(internalKey.doubleValue());
        }
        apiType.setOPERATION(oper.getOperation());
        super.setTechColsFromDataObject(dataObject, apiType);

        return apiType;
    }

    private Long getInternalKey(String acctNo) {
        Map<String, Object> params = new HashMap<>();
        params.put("acctNo", acctNo);

        return dataService.getWithNamedQuery(DepJpeConstants.ACCT_JPE_FIND_INTERNAL_KEY_BY_ACCT_NO, params, Long.class);
    }

    private String getAcctNo(Long internalKey) {
        Map<String, Object> params = new HashMap<>();
        params.put("internalKey", internalKey);

        return dataService.getWithNamedQuery(DepJpeConstants.ACCT_JPE_FIND_ACCT_NO_BY_INTERNAL_KEY, params, String.class);
    }

    private String getCrCalcBal(Long internalKey) {
        Map<String, Object> params = new HashMap<>();
        params.put("internalKey", internalKey);
        
        List<String> crCalcBals = new ArrayList<String>();
        try {
        	crCalcBals = dataService.findWithNamedQuery(DepJpeConstants.PROD_DEFAULT_JPE_FIND_CR_CALC_BAL_BY_INTERNAL_KEY, params, String.class);
        } catch(Exception e) {
        	return null;
        }
        
        if (!(crCalcBals == null || crCalcBals.isEmpty())) {
            return crCalcBals.get(0);
        }
        
        return null;
    }

    private String getDrCalcBal(Long internalKey) {
        Map<String, Object> params = new HashMap<>();
        params.put("internalKey", internalKey);

        List<String> drCalcBals = new ArrayList<String>();
        try {
        	drCalcBals = dataService.findWithNamedQuery(DepJpeConstants.PROD_DEFAULT_JPE_FIND_DR_CALC_BAL_BY_INTERNAL_KEY, params, String.class);
        } catch(Exception e) {
        	return null;
        }
        
        if (!(drCalcBals == null || drCalcBals.isEmpty())) {
            return drCalcBals.get(0);
        }
        
        return null;
    }
}
