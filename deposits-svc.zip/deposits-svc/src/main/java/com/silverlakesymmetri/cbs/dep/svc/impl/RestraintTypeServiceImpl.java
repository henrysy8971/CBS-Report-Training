package com.silverlakesymmetri.cbs.dep.svc.impl;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.mysema.query.types.EntityPath;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.RestraintType;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.RestraintTypeJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.QRestraintTypeJpe;
import com.silverlakesymmetri.cbs.dep.svc.RestraintTypeService;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.svc.AbstractBusinessService;

@Service
@Transactional
public class RestraintTypeServiceImpl extends AbstractBusinessService<RestraintType, RestraintTypeJpe, String> implements RestraintTypeService {

	@Override
	protected EntityPath<RestraintTypeJpe> getEntityPath() {
		return QRestraintTypeJpe.restraintTypeJpe;
	}

	@Override
	protected String getIdFromDataObjectInstance(RestraintType dataObject) {
		return dataObject.getRestraintType();
	}

	@Override
	public RestraintType getByPk(String publicKey, RestraintType reference) {
		return super.getByPk(publicKey, reference);
	}

	@Override
	public RestraintType create(RestraintType dataObject) {
		return super.create(dataObject);
	}

	@Override
	public RestraintType update(RestraintType dataObject) {
		return super.update(dataObject);
	}

	@Override
	public List<RestraintType> query(int offset, int resultLimit, String groupBy, String order,
			Map<String, Object> filters) {
		return super.query(offset, resultLimit, groupBy, order, filters);
	}

	@Override
	public boolean delete(RestraintType dataObject) {
		return super.delete(dataObject);
	}

	@Override
	public List<RestraintType> find(FindCriteria findCriteria, CbsHeader cbsHeader) {
		return super.find(findCriteria, cbsHeader);
	}

}
