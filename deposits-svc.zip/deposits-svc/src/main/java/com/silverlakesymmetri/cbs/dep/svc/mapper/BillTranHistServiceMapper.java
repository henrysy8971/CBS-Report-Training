package com.silverlakesymmetri.cbs.dep.svc.mapper;

import java.util.Map;

import org.mapstruct.Context;
import org.mapstruct.DecoratedWith;
import org.mapstruct.InheritConfiguration;
import org.mapstruct.InheritInverseConfiguration;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingTarget;
import org.mapstruct.Mappings;

import com.silverlakesymmetri.cbs.commons.jpa.util.DateTimeHelper;
import com.silverlakesymmetri.cbs.commons.xmlapi.enums.CbsXmlApiOperation;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.BillTranHistJpe;
import com.silverlakesymmetri.cbs.dep.svc.mapper.decorator.BillTranHistServiceDecorator;
import com.silverlakesymmetri.cbs.dep.svc.mapper.mapping.BillTranHistToDEPPAYBILLSAPITypeMapper;
import com.silverlakesymmetri.cbs.dep.xmlapi.DEPPAYBILLSAPIType;

@Mapper(config=BillTranHistToDEPPAYBILLSAPITypeMapper.class, uses={ DateTimeHelper.class})
@DecoratedWith(BillTranHistServiceDecorator.class)
public interface BillTranHistServiceMapper {

	@Mappings({
		 @Mapping(expression = "java(oper != null ? oper.getOperation() : null)", target="OPERATION")
	 })
	@InheritConfiguration
	public DEPPAYBILLSAPIType mapToApi(BillTranHistJpe jpe, @Context CbsXmlApiOperation oper, @Context Map otherInfo);
	
	@Mappings({
		@Mapping(source="TRANSEQNO", target ="tranSeqNo"),
		@Mapping(source="EFFECTDATE", target = "effectDate", qualifiedByName = {"DateTimeHelper","convertCbsApiDateToString"})
	 })
	@InheritInverseConfiguration(name = "mapBillTranHistToDEPPAYBILLSAPIType")
	public BillTranHistJpe mapToJpe(DEPPAYBILLSAPIType api, @MappingTarget BillTranHistJpe jpe);
	
}
