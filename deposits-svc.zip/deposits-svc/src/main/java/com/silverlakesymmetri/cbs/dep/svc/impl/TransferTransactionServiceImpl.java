package com.silverlakesymmetri.cbs.dep.svc.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mysema.query.types.EntityPath;
import com.silverlakesymmetri.cbs.commons.exception.base.CbsRuntimeException;
import com.silverlakesymmetri.cbs.commons.jpa.entity.CbsBpmInfoJpe;
import com.silverlakesymmetri.cbs.commons.logging.CbsAppLogger;
import com.silverlakesymmetri.cbs.commons.logging.CbsAppLoggerFactory;
import com.silverlakesymmetri.cbs.commons.svc.AbstractXmlApiBusinessService;
import com.silverlakesymmetri.cbs.commons.svc.BusinessObjectValidationCapable;
import com.silverlakesymmetri.cbs.commons.svc.LimitsCheckingCapable;
import com.silverlakesymmetri.cbs.commons.xmlapi.enums.CbsXmlApiOperation;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.DepFeeApply;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.ScDetailOut;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.TransferTransaction;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.QTransferTransactionJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.TransferTransactionJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.id.TransferTransactionPk;
import com.silverlakesymmetri.cbs.dep.svc.DepositsExpEmkService;
import com.silverlakesymmetri.cbs.dep.svc.DepositsValidatorService;
import com.silverlakesymmetri.cbs.dep.svc.TransferTransactionService;
import com.silverlakesymmetri.cbs.dep.svc.mapper.TransferTransactionServiceMapper;
import com.silverlakesymmetri.cbs.dep.xmlapi.DEPFEEAPPLYDTLOUTTType;
import com.silverlakesymmetri.cbs.dep.xmlapi.DEPTRANSFERINSAPIType;
import com.silverlakesymmetri.cbs.dep.xmlapi.DEPTRANVALIDATIONFLAGSTType;
import com.silverlakesymmetri.cbs.lmt.util.ExpEmkObjectHolder;
import com.silverlakesymmetri.cbs.lmt.util.LimitsUtility;

/**
 * 
 * @author Jeffrey.Villanueva
 *
 */
@Service
public class TransferTransactionServiceImpl
		extends AbstractXmlApiBusinessService<TransferTransaction, TransferTransactionJpe, TransferTransactionPk, DEPTRANSFERINSAPIType, DEPTRANSFERINSAPIType>
		implements TransferTransactionService, BusinessObjectValidationCapable<TransferTransaction>, LimitsCheckingCapable<TransferTransaction> {
	
	private static final String CBS_CHANNEL_CODE = "CBS";
	private static final String CBS_CHANNEL_SOURCE = "HTTP-UI";
	private static final String ERROR_BRANCH_IS_NULL = "CBS.B.DEP.TRANSFERTRANSACTION_SERVICE.0001";
	private static final String TRAN_HIST_SEQ = "DEP_TRAN_HIST_S";
	
	@Autowired
	TransferTransactionServiceMapper mapper;

	@Autowired
	private DepositsExpEmkService depositsExpEmkService;	
	
	@Autowired
    DepositsValidatorService depositsValidatorService;

    @Autowired
    private LimitsUtility limitsUtility;
    
    private static CbsAppLogger logger = CbsAppLoggerFactory.getLogger(TransferTransactionServiceImpl.class.getName());

    @Override
	protected TransferTransactionPk getIdFromDataObjectInstance(TransferTransaction dataObject) {
		return new TransferTransactionPk(1l); // dummy
	}

	@Override
	protected EntityPath<TransferTransactionJpe> getEntityPath() {
		return QTransferTransactionJpe.transferTransactionJpe;
	}

	@Override
	public TransferTransaction preCreateValidation(TransferTransaction dataObject) {
		long mainSeqNo = dataService.nextSequenceValue(TRAN_HIST_SEQ).longValue();
		dataObject.setSeqNo(mainSeqNo);
		return super.preCreateValidation(dataObject);
	}
	
	/* (non-Javadoc)
	 * @see com.silverlakesymmetri.cbs.commons.svc.AbstractBusinessService#create(com.silverlakesymmetri.cbs.commons.bdo.CbsBusinessDataObject)
	 */
	@Override
	public TransferTransaction create(TransferTransaction dataObject) {
		TransferTransaction originalDataObject = dataObject;
		if(dataObject.getTfrDetailList() != null && dataObject.getTfrDetailList().size() > 0){
			if(dataObject.getTfrDetailList().get(0).getTranDate() == null){
				dataObject.getTfrDetailList().get(0).setTranDate(dateTimeHelper.getSDODateTime(dateTimeHelper.getRunDate()));
			}
		}
		executeStoredProcedure(dataObject, shouldPerformValidate(dataObject));
		postCreateObject(dataObject, originalDataObject);
		return dataObject;
	}

	@Override
	protected DEPTRANSFERINSAPIType transformBdoToXmlApiRqCreate(TransferTransaction dataObject) {
		return tranformAcctToDEPTRANSFERINSAPIType(dataObject, CbsXmlApiOperation.INSERT);
	}

	private DEPTRANSFERINSAPIType tranformAcctToDEPTRANSFERINSAPIType(TransferTransaction bdo,
			CbsXmlApiOperation oper) {
		TransferTransactionJpe jpe = jaxbSdoHelper.unwrap(bdo);
		DEPTRANSFERINSAPIType apiType =   mapper.mapToApi(jpe, oper);	
		super.setTechColsFromDataObject(bdo, apiType);
		
		apiType.setOPERATION(oper.getOperation());
		
		apiType.setDRTRANTYPE(bdo.getDebitTranType());
		apiType.setCRTRANTYPE(bdo.getCreditTranType());
		DEPTRANVALIDATIONFLAGSTType depTranValidationFlags = new DEPTRANVALIDATIONFLAGSTType();
		depTranValidationFlags.setCHKEFFDATE(apiType.getCHKEFFDATE());
		depTranValidationFlags.setCHKOVERRIDE(apiType.getCHKOVERRIDE());
		depTranValidationFlags.setCHKTELLERLIMIT(apiType.getCHKTELLERLIMIT());
		depTranValidationFlags.setIGNAVAILBAL(apiType.getIGNAVAILBAL());
		depTranValidationFlags.setIGNRESTRAINT(apiType.getIGNRESTRAINT());
		if (apiType.getDRSCAPPLYIN() != null) {
			apiType.getDRSCAPPLYIN().setTRANVALIDATIONFLAGS(depTranValidationFlags);
		}
		if (apiType.getCRSCAPPLYIN() != null) {
			apiType.getCRSCAPPLYIN().setTRANVALIDATIONFLAGS(depTranValidationFlags);
		}

		return apiType;
	}
	
	@Override
	protected DEPTRANSFERINSAPIType transformBdoToXmlApiRqUpdate(TransferTransaction dataObject) {
		return null;
	}

	@Override
	protected DEPTRANSFERINSAPIType transformBdoToXmlApiRqDelete(TransferTransaction dataObject) {
		return null;
	}

	@Override
	protected TransferTransaction processXmlApiRs(TransferTransaction dataObject, DEPTRANSFERINSAPIType xmlApiRs) {
		String acctNo = dataObject.getAcctNo();
		if (xmlApiRs != null) {
			Number drSeqNo = xmlApiRs.getDRTRANSEQNO();
			Number crSeqNo = xmlApiRs.getCRTRANSEQNO();

			int drIdx1 = 0;
			final Map<Integer, ScDetailOut> drScDetailOutMap = new HashMap<Integer, ScDetailOut>();
			for (DEPFEEAPPLYDTLOUTTType depFeeApplyOutType : xmlApiRs.getDRSCDETAILOUT().getDEPFEEAPPLYDTLOUTT()) {
				ScDetailOut scDetailOut = this.jaxbSdoHelper.createSdoInstance(ScDetailOut.class);
				scDetailOut.setScEventType(depFeeApplyOutType.getSCEVENTTYPE());
				scDetailOut.setScType(depFeeApplyOutType.getSCTYPE());
				scDetailOut.setScRateType(depFeeApplyOutType.getSCRATETYPE());
				scDetailOut.setScRbSeqNo(depFeeApplyOutType.getSCRBSEQNO());
				scDetailOut.setTaxRbSeqNo(depFeeApplyOutType.getTAXRBSEQNO());
				drScDetailOutMap.put(drIdx1, scDetailOut);
				++drIdx1;
			}
			int crIdx1 = 0;
			final Map<Integer, ScDetailOut> crScDetailOutMap = new HashMap<Integer, ScDetailOut>();
			for (DEPFEEAPPLYDTLOUTTType depFeeApplyOutType2 : xmlApiRs.getCRSCDETAILOUT().getDEPFEEAPPLYDTLOUTT()) {
				ScDetailOut scDetailOut2 = this.jaxbSdoHelper.createSdoInstance(ScDetailOut.class);
				scDetailOut2.setScEventType(depFeeApplyOutType2.getSCEVENTTYPE());
				scDetailOut2.setScType(depFeeApplyOutType2.getSCTYPE());
				scDetailOut2.setScRateType(depFeeApplyOutType2.getSCRATETYPE());
				scDetailOut2.setScRbSeqNo(depFeeApplyOutType2.getSCRBSEQNO());
				scDetailOut2.setTaxRbSeqNo(depFeeApplyOutType2.getTAXRBSEQNO());
				crScDetailOutMap.put(crIdx1, scDetailOut2);
				++crIdx1;
			}

			if (acctNo.equals(xmlApiRs.getCRACCTNO())) {
				dataObject.setSeqNo(crSeqNo.longValue());
				dataObject.getTfrDetailList().forEach(tfrDetail -> {
					tfrDetail.setSeqNo(crSeqNo.longValue());
					tfrDetail.setCrSeqNo(crSeqNo.longValue());
					tfrDetail.setDrSeqNo(drSeqNo.longValue());
					tfrDetail.setAvailBal(xmlApiRs.getCRACCTAVAILBAL());
					tfrDetail.setLedgerBal(xmlApiRs.getCRACCTLEDGERBAL());
					tfrDetail.setCpartyAvailBal(xmlApiRs.getDRACCTAVAILBAL());
					tfrDetail.setCpartyLedgerBal(xmlApiRs.getDRACCTLEDGERBAL());

					int idx1 = 0;
					for (DepFeeApply depFeeApply: tfrDetail.getDrFeeApplyList()) {
						if (drScDetailOutMap.containsKey(idx1)) {
							depFeeApply.setScDetailOut(drScDetailOutMap.get(idx1));
						}
						idx1++;
					}

					idx1 = 0;
					for (DepFeeApply depFeeApply: tfrDetail.getCrFeeApplyList()) {
						if (crScDetailOutMap.containsKey(idx1)) {
							depFeeApply.setScDetailOut(crScDetailOutMap.get(idx1));
						}
						idx1++;
					}
				});
			} else if (acctNo.equals(xmlApiRs.getDRACCTNO())) {
				dataObject.setSeqNo(drSeqNo.longValue());
				dataObject.getTfrDetailList().forEach(tfrDetail -> {
					tfrDetail.setSeqNo(drSeqNo.longValue());
					tfrDetail.setCrSeqNo(crSeqNo.longValue());
					tfrDetail.setDrSeqNo(drSeqNo.longValue());
					tfrDetail.setAvailBal(xmlApiRs.getDRACCTAVAILBAL());
					tfrDetail.setLedgerBal(xmlApiRs.getDRACCTLEDGERBAL());
					tfrDetail.setCpartyAvailBal(xmlApiRs.getCRACCTAVAILBAL());
					tfrDetail.setCpartyLedgerBal(xmlApiRs.getCRACCTLEDGERBAL());

					int idx1 = 0;
					for (DepFeeApply depFeeApply: tfrDetail.getDrFeeApplyList()) {
						if (drScDetailOutMap.containsKey(idx1)) {
							depFeeApply.setScDetailOut(drScDetailOutMap.get(idx1));
						}
						idx1++;
					}

					idx1 = 0;
					for (DepFeeApply depFeeApply: tfrDetail.getCrFeeApplyList()) {
						if (crScDetailOutMap.containsKey(idx1)) {
							depFeeApply.setScDetailOut(crScDetailOutMap.get(idx1));
						}
						idx1++;
					}
				});
			}
		}
		return dataObject;
	}

	@Override
	protected List<TransferTransaction> processXmlApiListRs(TransferTransaction dataObject,
			DEPTRANSFERINSAPIType xmlApiRs) {
		return null;
	}

	@Override
	protected Class<DEPTRANSFERINSAPIType> getXmlApiResponseClass() {
		return DEPTRANSFERINSAPIType.class;
	}
	
	@Override
	public TransferTransaction validateCreateRequest(TransferTransaction dataObject) {
		//long orgId = cbsRuntimeContextManager.getContext(CbsSessionContext.class).getOrgId();
		/*
		1. query to check if at least 1 acct type is ISL
		2. if at least 1 is ISL, proceed with validateTransferAllowed
		 */

		/*
		final Map<String, Object> parameters = new HashMap<>();
		parameters.put("orgId", orgId);
		parameters.put("fromAcctNo", dataObject.getAcctNo());
		parameters.put("toAcctNo", dataObject.getTfrDetailList().get(0).getCpartyAcctNo());

		BigDecimal cntIsl = new BigDecimal(0);
		cntIsl = dataService.getWithNamedQuery(DepJpeConstants.ACCT_TYPE_JPE_GET_ISLAMIC_COUNT, parameters, BigDecimal.class);

		if (cntIsl.intValue() > 0) {
			validateTransferAllowed(dataObject);
		}
		*/

		return super.validateCreateRequest(dataObject);
	}
	/*
	private void validateTransferAllowed(TransferTransaction dataObject){
		
		TransferTransactionJpe main = unwrap(dataObject);
		if (main.getTfrDetailList() == null || main.getTfrDetailList().isEmpty()){
			return;
		}

		TransferTransactionDetailJpe jpe = main.getTfrDetailList().get(0);
		String transferMode = dataObject.getTransferMode();
		if ("DR".equals(transferMode)) {
			String returnCode = depositsValidatorService.isFinancialTransferAllowedByAcctNos(jpe.getAcctNo(), jpe.getCpartyAcctNo());
		} 
		else if ("CR".equals(transferMode)) {
			String returnCode = depositsValidatorService.isFinancialTransferAllowedByAcctNos(jpe.getCpartyAcctNo(), jpe.getAcctNo());
		}
	}
	*/

    @Override
    public CbsBpmInfoJpe doCheckLimit(TransferTransaction dataObject) {
        ExpEmkObjectHolder expEmkObject = depositsExpEmkService.getLimitsDetails(dataObject,
                DepositsExpEmkServiceImpl.WHD_EVENT_TYPE, DepositsExpEmkServiceImpl.DR_AMT_TYPE);
        return limitsUtility.getLimitExceptionApprover(expEmkObject, dataObject);
    }

    @Override
    public TransferTransaction getLimitExceptions(TransferTransaction dataObject) {
        ExpEmkObjectHolder expEmkObject = depositsExpEmkService.getLimitsDetails(dataObject,
                DepositsExpEmkServiceImpl.WHD_EVENT_TYPE, DepositsExpEmkServiceImpl.DR_AMT_TYPE);
        return limitsUtility.getLimitExceptionDetails(expEmkObject, dataObject);
    }

	@Override
	public Long getEffectivityDate(TransferTransaction dataObject) {
		// TODO Auto-generated method stub
		return null;
	}

    @Override
    public void validateApiRequest(TransferTransaction dataObject, DEPTRANSFERINSAPIType xmlApiRq){
        try {
            String xmlApiReq = removeModifiedByAndModifiedDt(convertXmlApiRqToString(xmlApiRq));
            String xmlHeaderIn = convertXmlApiRqToString(createHeaderFromDataObject(dataObject));
            validate(dataObject, xmlApiReq, xmlHeaderIn);
        } catch (CbsRuntimeException cre) {
            throw cre;
        } catch (Exception e) {
            logger.error("Unhandled error encountered: {}", e.getMessage(), e);
            throw new RuntimeException(e);
        }
    }
}
