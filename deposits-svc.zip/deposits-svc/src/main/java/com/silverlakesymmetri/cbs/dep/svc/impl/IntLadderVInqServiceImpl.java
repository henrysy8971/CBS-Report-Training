package com.silverlakesymmetri.cbs.dep.svc.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.mysema.query.types.EntityPath;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.svc.AbstractBusinessService;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.IntLadderVInq;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.IntLadderVInqJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.QIntLadderVInqJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.id.IntLadderVInqPk;
// import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.util.DepJpeConstants;
import com.silverlakesymmetri.cbs.dep.svc.IntLadderVInqService;

@Service
@Transactional(readOnly = true)
public class IntLadderVInqServiceImpl extends AbstractBusinessService<IntLadderVInq, IntLadderVInqJpe, IntLadderVInqPk> implements IntLadderVInqService{
	
	@Override
	protected IntLadderVInqPk getIdFromDataObjectInstance(IntLadderVInq dataObject) {
		IntLadderVInqPk jpe = jaxbSdoHelper.unwrap(dataObject);
		return new IntLadderVInqPk(jpe.getInternalKey(), jpe.getDateFrom(), jpe.getDateTo());
	}

	@Override
	protected EntityPath<IntLadderVInqJpe> getEntityPath() {
		return QIntLadderVInqJpe.intLadderVInqJpe;
	}
	
	@Override
	public IntLadderVInq get(IntLadderVInq objectInstanceIdentifier) {
		return super.get(objectInstanceIdentifier);
	}

	@Override
	public List<IntLadderVInq> query(int offset, int resultLimit, String groupBy, String order,
			Map<String, Object> filters) {
		return super.query(offset, resultLimit, groupBy, order, filters);
	}

	@Override
	public List<IntLadderVInq> find(FindCriteria findCriteria, CbsHeader cbsHeader) {
		return super.find(findCriteria, cbsHeader);
	}

	@Override
	public IntLadderVInq getByPk(String publicKey, IntLadderVInq reference) {
		return super.getByPk(publicKey, reference);
	}

}
