package com.silverlakesymmetri.cbs.dep.svc.mapper.mapping;

import org.mapstruct.MapperConfig;
import org.mapstruct.Mapping;
import org.mapstruct.Mappings;

import com.silverlakesymmetri.cbs.commons.jpa.util.DateTimeHelper;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.InwdChequeManualCaptureJpe;
import com.silverlakesymmetri.cbs.dep.xmlapi.DEPINWDCHEQUEAPIType;

@MapperConfig(uses = { DateTimeHelper.class, InwdChequeManualCaptureToDEPINWDCHEQUEAPITypeMapper.class })
public interface InwdChequeManualCaptureToDEPINWDCHEQUEAPITypeMapper {
	@Mappings({
		@Mapping(source = "seqNo", target = "SEQNO"),
		@Mapping(source = "chequeNo", target = "CHEQUENO"),
		@Mapping(source = "branch", target = "BRANCH"),
		@Mapping(source = "inwdType", target = "INWDTYPE"),
		@Mapping(source = "sourceType", target = "SOURCETYPE"),
		@Mapping(source = "acctNo", target = "ACCTNO"),
		@Mapping(source = "tranCode", target = "TRANCODE"),
		@Mapping(source = "tranAmt", target = "TRANAMT"),
		@Mapping(source = "tranDate", target = "TRANDATE", qualifiedByName = { "DateTimeHelper", "convertDateToCbsXmlApiDate" }),
		@Mapping(source = "orgBank", target = "ORGBANK"),
		@Mapping(source = "orgBranch", target = "ORGBRANCH"),
		@Mapping(source = "orgAcctNo", target = "ORGACCTNO"),
		@Mapping(source = "orgAcctName", target = "ORGACCTNAME"),
		@Mapping(source = "remarks", target = "REMARKS"),
		@Mapping(source = "rejectCode", target = "REJECTCODE"),
		@Mapping(source = "errorNo", target = "ERRORNO"),
		@Mapping(source = "status", target = "STATUS")
	})
	public DEPINWDCHEQUEAPIType mapInwdChequeManualCaptureToDEPINWDCHEQUEAPIType(InwdChequeManualCaptureJpe jpe);
}
