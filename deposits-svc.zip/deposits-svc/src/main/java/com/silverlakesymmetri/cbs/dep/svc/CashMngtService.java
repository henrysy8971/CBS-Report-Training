package com.silverlakesymmetri.cbs.dep.svc;

import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation;
import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation.ServiceOperationType;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.svc.BusinessService;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.CashMngt;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.CashMngtJpe;

import java.util.List;
import java.util.Map;

public interface CashMngtService extends BusinessService<CashMngt, CashMngtJpe> {


    String SVC_OP_NAME_CASHMNGTSERVICE_CREATE = "CashMngtService.create";
    String SVC_OP_NAME_CASHMNGTSERVICE_GET = "CashMngtService.get";
    String SVC_OP_NAME_CASHMNGTSERVICE_FIND = "CashMngtService.find";
    String SVC_OP_NAME_CASHMNGTSERVICE_QUERY = "CashMngtService.query";

    @ServiceOperation(name = SVC_OP_NAME_CASHMNGTSERVICE_CREATE,  type = ServiceOperationType.CREATE)
    public CashMngt create(CashMngt dataObject);
    
	@ServiceOperation(name = SVC_OP_NAME_CASHMNGTSERVICE_GET, type = ServiceOperationType.GET)
    public CashMngt getByPk(String publicKey, CashMngt reference);

    @ServiceOperation(name = SVC_OP_NAME_CASHMNGTSERVICE_QUERY)
    List<CashMngt> query(int offset, int resultLimit, String groupBy, String order, Map<String, Object> filters);

    @ServiceOperation(name = SVC_OP_NAME_CASHMNGTSERVICE_FIND)
    List<CashMngt> find(FindCriteria findCriteria, CbsHeader cbsHeader);
}
