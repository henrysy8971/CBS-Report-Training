package com.silverlakesymmetri.cbs.dep.svc.mapper.decorator;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

import com.silverlakesymmetri.cbs.commons.xmlapi.enums.CbsXmlApiOperation;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.FeeInquiryDtlsJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.FeeInquiryHdrJpe;
import com.silverlakesymmetri.cbs.dep.svc.mapper.DepositsFeeServiceMapper;
import com.silverlakesymmetri.cbs.dep.svc.mapper.mapping.DEPFEEDETAILSTYPETypeToFeeInquiryDtlsMapper;
import com.silverlakesymmetri.cbs.dep.xmlapi.DEPFEEDETAILSAPIType;
import com.silverlakesymmetri.cbs.dep.xmlapi.DEPFEEDETAILSTYPEType;

public abstract class DepositsFeeServiceDecorator implements DepositsFeeServiceMapper {
	
	@Autowired
	@Qualifier("delegate")
	protected  DepositsFeeServiceMapper delegate;
	
	@Autowired
	protected DEPFEEDETAILSTYPETypeToFeeInquiryDtlsMapper feeInquiryDtlsMapper;
	
	private static final String CBS_CHANNEL_SOURCE = "HTTP-UI";
	
	@Override
	public DEPFEEDETAILSAPIType mapToApi(FeeInquiryHdrJpe jpe, CbsXmlApiOperation oper, Map otherInfo){
		DEPFEEDETAILSAPIType req = (DEPFEEDETAILSAPIType) delegate.mapToApi(jpe, oper, otherInfo);
		
		if (otherInfo.containsKey(CHANNEL_SOURCE) && otherInfo.get(CHANNEL_SOURCE).equals(CBS_CHANNEL_SOURCE)) {
			if (otherInfo.containsKey(BRANCH)){
				req.setTRANBRANCH((String) otherInfo.get(BRANCH));
			}
		} else {
			req.setTRANBRANCH(jpe.getBookBranch());
		}
		
		return  req;
	}
	
	@Override
	public FeeInquiryHdrJpe mapToJpe(DEPFEEDETAILSAPIType api, FeeInquiryHdrJpe jpe){
		List<FeeInquiryDtlsJpe> jpeList = new ArrayList<>();
		if (api != null && api.getFEEDETAILSLIST() != null && api.getFEEDETAILSLIST().getDEPFEEDETAILSTYPE().size() > 0) {
			for (DEPFEEDETAILSTYPEType feeDtls : api.getFEEDETAILSLIST().getDEPFEEDETAILSTYPE()) {
				FeeInquiryDtlsJpe dtlsJpe = feeInquiryDtlsMapper.mapApitoJpe(feeDtls);
				jpeList.add(dtlsJpe);
			}
		}
		jpe.setFeeInquiryDtlsList(jpeList);
		return jpe;
	}
}


