package com.silverlakesymmetri.cbs.dep.svc.mapper.mapping;

import org.mapstruct.MapperConfig;
import org.mapstruct.Mapping;
import org.mapstruct.Mappings;

import com.silverlakesymmetri.cbs.commons.jpa.util.DateTimeHelper;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.TdDepositTransactionJpe;
import com.silverlakesymmetri.cbs.dep.xmlapi.DEPTDPLACEMENTAPIType;

@MapperConfig(uses={ DateTimeHelper.class})
public interface TdDepositTransactionToDEPTDPLACEMENTAPITypeMapper {

	@Mappings({
		@Mapping(source = "acctNo", target="ACCTNO"),
		@Mapping(source = "certificateNo", target="CERTIFICATENO"),
		@Mapping(source = "tranType", target="CRTRANTYPE"),
	    @Mapping(source = "effectDate", target="EFFECTDATE", qualifiedByName = {"DateTimeHelper","convertDateToCbsXmlApiDate"}),
	    @Mapping(source = "ccy", target="TRANCCY"),
	    @Mapping(source = "amount", target="TRANAMT"),
	    @Mapping(source = "equivAmount", target="BASEEQUIVAMT"),
	    @Mapping(source = "refBank", target="REFERENCEBANK"),
	    @Mapping(source = "refBranch", target="REFERENCEBRANCH"),
	    @Mapping(source = "issuerAcctNo", target="ISSUINGACCTNO"),
	    @Mapping(source = "reference", target="REFERENCE"),
	    @Mapping(source = "floatDays", target="FLOATDAYS"),
	    @Mapping(source = "crossRate", target="CROSSRATE"),
	    @Mapping(source = "rateReferenceId", target="CROSSRATEREFERENCE"),
	    @Mapping(source = "rateOrigin", target="CROSSRATEORIGIN"),
	    @Mapping(source = "origCrossRate", target="ORIGCROSSRATE"),
	    @Mapping(source = "clientName", target="CLIENTNAME"),
	    @Mapping(source = "clientAddress", target="CLIENTADDR"),
	    @Mapping(source = "idType", target="IDTYPE"),
	    @Mapping(source = "idNumber", target="CLIENTID"),
	    @Mapping(source = "residentFlag", target="RESIDENT"),
	    @Mapping(source = "clientType", target="CLIENTTYPE"),
	    @Mapping(source = "categoryType", target="CATEGORYTYPE"),
	    @Mapping(source = "country", target="COUNTRY"),
	    @Mapping(source = "domesticForeignFlag", target="DOMESTICFOREIGN"),
	    @Mapping(source = "placeOfIssuance", target="PLACEOFISSUANCE"),
	    @Mapping(source = "narrative", target="CRTRANDESC"),
	    @Mapping(source = "branch", target="TRANBRANCH"),
		@Mapping(source = "seqNo", target="CRSEQNO")
	 })
	public DEPTDPLACEMENTAPIType mapTdDepositTransactionToDEPTDPLACEMENTAPIType(TdDepositTransactionJpe jpe);
}
