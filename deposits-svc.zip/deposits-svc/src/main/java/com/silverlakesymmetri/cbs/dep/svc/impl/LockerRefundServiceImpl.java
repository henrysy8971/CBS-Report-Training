package com.silverlakesymmetri.cbs.dep.svc.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mysema.query.types.EntityPath;
import com.silverlakesymmetri.cbs.commons.svc.AbstractXmlApiBusinessService;
import com.silverlakesymmetri.cbs.commons.xmlapi.enums.CbsXmlApiOperation;
import com.silverlakesymmetri.cbs.csd.jpa.mapping.sdo.ScVJpe;
import com.silverlakesymmetri.cbs.csd.jpa.mapping.sdo.util.CsdJpeConstants;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.LockerRefund;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.AcctJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.LockerRefundJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.QLockerRefundJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.SdbAcctJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.id.LockerRefundPk;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.id.SdbAcctPk;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.util.DepJpeConstants;
import com.silverlakesymmetri.cbs.dep.svc.LockerRefundService;
import com.silverlakesymmetri.cbs.dep.svc.mapper.mapping.LockerRefundToDEPSDBREVERSALAPITypeMapper;
import com.silverlakesymmetri.cbs.dep.xmlapi.DEPSDBREVERSALAPIType;

@Service
public class LockerRefundServiceImpl extends AbstractXmlApiBusinessService<LockerRefund, LockerRefundJpe, LockerRefundPk, DEPSDBREVERSALAPIType, DEPSDBREVERSALAPIType> implements LockerRefundService {
	
	@Autowired
	private LockerRefundToDEPSDBREVERSALAPITypeMapper mapper;
	
	@Override
	protected EntityPath<LockerRefundJpe> getEntityPath() {
		// TODO Auto-generated method stub
		return QLockerRefundJpe.lockerRefundJpe;
	}

	@Override
	protected LockerRefundPk getIdFromDataObjectInstance(LockerRefund bdo) {
		Map<String, Object> params = new HashMap<>();
		params.put("contractNo", bdo.getContractNo());
		Long result = dataService.getWithNamedQuery(DepJpeConstants.SDB_ACCT_JPE_GET_SDB_INTERNAL_KEY_BY_CONTRACT_NO, params, Long.class);
		return new LockerRefundPk(result);
	}
	
	@Override
	public LockerRefund create(LockerRefund arg0) {
		// TODO Auto-generated method stub
		return super.create(arg0);
	}

	@Override
	protected LockerRefund preCreateValidation(LockerRefund dataObject) {
		LockerRefundJpe jpe = jaxbSdoHelper.unwrap(dataObject);
		if (StringUtils.isNotBlank(jpe.getContractNo()) && StringUtils.isBlank(jpe.getAcctNo())) {
			Map<String, Object> param = new HashMap<>();
			param.put("contractNo", jpe.getContractNo());
			String rentalFeeAcctNo = dataService.getWithNamedQuery(DepJpeConstants.SDB_ACCT_JPE_GET_RENTAL_FEE_ACCT_NO_BY_CONTRACT_NO, param, String.class);
			jpe.setAcctNo(rentalFeeAcctNo);
			
		}
		jpe.setTranDate(dateTimeHelper.getRunDate());
		return super.preCreateValidation(dataObject);
	}

	@Override
	public LockerRefund getByPk(String publicKey, LockerRefund reference) {
		LockerRefund bdo = jaxbSdoHelper.createSdoInstance(LockerRefund.class);
		bdo.setContractNo(publicKey);
		return bdo; 
	}

	@Override
	protected Class<DEPSDBREVERSALAPIType> getXmlApiResponseClass() {
		return DEPSDBREVERSALAPIType.class;
	}

	@Override
	protected List<LockerRefund> processXmlApiListRs(LockerRefund arg0, DEPSDBREVERSALAPIType arg1) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	protected LockerRefund processXmlApiRs(LockerRefund dataObject, DEPSDBREVERSALAPIType xmlApiRs) {
		LockerRefundJpe jpe = mapper.mapDEPSDBREVERSALAPITypeToLockerRefund(xmlApiRs);
		SdbAcctJpe sdbAcctJpe = dataService.find(SdbAcctJpe.class, new SdbAcctPk(jpe.getSdbInternalKey()));
		jpe.setContractNo(sdbAcctJpe.getContractNo());
		jpe.setContractDesc(sdbAcctJpe.getContractDesc());
		jpe.setClientNo(sdbAcctJpe.getClientNo());
		jpe.setCcy(sdbAcctJpe.getCcy());
		jpe.setTranAmt(dataObject.getTranAmt());
		return jaxbSdoHelper.wrap(jpe);
	}

	@Override
	protected DEPSDBREVERSALAPIType transformBdoToXmlApiRqCreate(LockerRefund dataObject) {
		return tranformToDEPSDBREVERSALAPIType(dataObject, CbsXmlApiOperation.UPDATE);
	}

	private DEPSDBREVERSALAPIType tranformToDEPSDBREVERSALAPIType(LockerRefund dataObject,
			CbsXmlApiOperation oper) {
		LockerRefundJpe jpe = jaxbSdoHelper.unwrap(dataObject);
		
		Map<String, Object> param = new HashMap<String, Object>();
		param.put("acctNo", jpe.getAcctNo());
		AcctJpe acctJpe = dataService.getWithNamedQuery(DepJpeConstants.ACCT_JPE_FIND_BY_ACCTNO, param, AcctJpe.class);
		LockerRefundPk pk = getIdFromDataObjectInstance(dataObject);
		
		
		ScVJpe scVJpe = null;
		if ("D".equals(dataObject.getPurposeCode())) {
			Map<String, Object> p = new HashMap<>();
			p.put("prodNo", jpe.getContractNo());
			p.put("rbInternalKey", acctJpe.getInternalKey());
			List<ScVJpe> resultList = dataService.findWithNamedQuery(CsdJpeConstants.SDB_REFUND_GET_KEY_DEPOSIT_DETAIS, p, ScVJpe.class);
			if (resultList != null && !resultList.isEmpty()) {
				scVJpe = resultList.get(0);
			}
		} else if ("N".equals(dataObject.getPurposeCode())) {
			SdbAcctJpe sdbAcctJpe = dataService.find(SdbAcctJpe.class, new SdbAcctPk(pk.getSdbInternalKey()));
			Map<String, Object> p = new HashMap<>();
			p.put("prodNo", jpe.getContractNo());
			p.put("rbInternalKey", acctJpe.getInternalKey());
			p.put("scDate", sdbAcctJpe.getStartDate());
			if (dateTimeHelper.compareDates(sdbAcctJpe.getDateOpen(), sdbAcctJpe.getStartDate()) == 0) {
				List<ScVJpe> resultList = dataService.findWithNamedQuery(CsdJpeConstants.SDB_REFUND_GET_RENTAL_FEE_DETAIS_FOR_NEW_SDB, p, ScVJpe.class);
				if (resultList != null && !resultList.isEmpty()) {
					scVJpe = resultList.get(0);
				}
			} else {
				List<ScVJpe> resultList = dataService.findWithNamedQuery(CsdJpeConstants.SDB_REFUND_GET_RENTAL_FEE_DETAIS_RENEW_SDB, p, ScVJpe.class);
				if (resultList != null && !resultList.isEmpty()) {
					scVJpe = resultList.get(0);
				}
			}
		}
		
		jpe.setInternalKey(acctJpe.getInternalKey());
		jpe.setSdbInternalKey(pk.getSdbInternalKey());
		
		if (scVJpe != null) {
			jpe.setStatus(scVJpe.getStatus());
			jpe.setScLocation(scVJpe.getScLocation());
			jpe.setTranDate(scVJpe.getScDate());
			jpe.setScSeqNo(scVJpe.getScSeqNo());
			jpe.setScType(scVJpe.getScType());
			jpe.setScRbSeqNo(scVJpe.getScRbSeqNo());
			jpe.setTaxRbSeqNo(scVJpe.getTaxRbSeqNo());
		}
		
		DEPSDBREVERSALAPIType apiType = mapper.mapLockerRefundToDEPSDBREVERSALAPIType(jpe);
		super.setTechColsFromDataObject(dataObject, apiType);
		apiType.setACTIONINDICATOR("REFUND");
		apiType.setOPERATION(oper.getOperation());
		apiType.setRBINTERNALKEY(acctJpe.getInternalKey());
		
		return apiType;
	}

	@Override
	protected DEPSDBREVERSALAPIType transformBdoToXmlApiRqDelete(LockerRefund arg0) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	protected DEPSDBREVERSALAPIType transformBdoToXmlApiRqUpdate(LockerRefund arg0) {
		// TODO Auto-generated method stub
		return null;
	}

	
	
}
