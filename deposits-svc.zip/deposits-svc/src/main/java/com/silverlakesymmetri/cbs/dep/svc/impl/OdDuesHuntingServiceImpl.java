package com.silverlakesymmetri.cbs.dep.svc.impl;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mysema.query.types.EntityPath;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.jpa.entity.FindCriteriaJpe;
import com.silverlakesymmetri.cbs.commons.svc.AbstractBusinessService;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.OdRepository;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.OdRepositoryDtl;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.OdRepositoryJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.QOdRepositoryJpe;
import com.silverlakesymmetri.cbs.dep.jpa.util.DepOdRepositoryHelper;
import com.silverlakesymmetri.cbs.dep.svc.OdDuesHuntingService;
import com.silverlakesymmetri.cbs.dep.util.OdRepositoryObj;

@Service
public class OdDuesHuntingServiceImpl extends AbstractBusinessService<OdRepository, OdRepositoryJpe, Long> implements OdDuesHuntingService {

	@Autowired
	DepOdRepositoryHelper depOdRepositoryHelper;
	
	@Override
	protected EntityPath<OdRepositoryJpe> getEntityPath() {
		return QOdRepositoryJpe.odRepositoryJpe;
	}

	@Override
	protected Long getIdFromDataObjectInstance(OdRepository arg0) {
		return arg0.getInternalKey();
	}

	@Override
	public List<OdRepository> query(int offset, int resultLimit, String groupBy, String order,
			Map<String, Object> filters) {
		return super.query(offset, resultLimit, groupBy, order, filters);
	}

	@Override
	public Long count(FindCriteria findCriteria, CbsHeader cbsHeader) {
		return dataService.getRowCount(OdRepositoryJpe.class, new FindCriteriaJpe());
	}

	@Override
	public OdRepositoryObj autoHunting(OdRepositoryObj dataObject) {
		depOdRepositoryHelper.autoHunting(dataObject.getGenerationTime(), dataObject.getInternalKey(), dataObject.getAcctClosure(), dataObject.getDebugMode());
		return dataObject;
	}
	
}