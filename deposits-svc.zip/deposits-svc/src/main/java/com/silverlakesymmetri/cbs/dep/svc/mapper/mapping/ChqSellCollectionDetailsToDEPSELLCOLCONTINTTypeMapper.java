package com.silverlakesymmetri.cbs.dep.svc.mapper.mapping;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Mappings;

import com.silverlakesymmetri.cbs.commons.jpa.util.DateTimeHelper;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.ChqSellCollectionDetailsJpe;
import com.silverlakesymmetri.cbs.dep.xmlapi.DEPSELLCOLCONTINTType;

@Mapper(uses = { DateTimeHelper.class })
public interface ChqSellCollectionDetailsToDEPSELLCOLCONTINTTypeMapper {
	
	@Mappings({
		@Mapping(source = "collectingPersonName", target = "COLLECTNAME"),
		@Mapping(source = "collectingPersonIdType", target = "COLLECTIDTYPE"),
		@Mapping(source = "collectingPersonId", target = "COLLECTID"),
		@Mapping(source = "collectingPersonContactType", target = "COLLECTCONTACTTYPE"),
		@Mapping(source = "collectingPersonAddress", target = "COLLECTADDRESS"),
		@Mapping(source = "collectingPersonCity", target = "COLLECTCITY"),
		@Mapping(source = "collectingPersonState", target = "COLLECTSTATE"),
		@Mapping(source = "collectingPersonCountry", target = "COLLECTCOUNTRY"),
		@Mapping(source = "collectingPersonPostalCode", target = "COLLECTPOSTALCODE"),
		@Mapping(source = "collectingPersonInstr", target = "COLLECTINSTR")
	})
	public DEPSELLCOLCONTINTType jpeToApiType(ChqSellCollectionDetailsJpe jpe);
	
}
