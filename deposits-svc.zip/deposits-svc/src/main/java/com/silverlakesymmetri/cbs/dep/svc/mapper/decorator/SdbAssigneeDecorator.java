package com.silverlakesymmetri.cbs.dep.svc.mapper.decorator;

import java.util.HashMap;
import java.util.Map;

import org.mapstruct.Context;
import org.mapstruct.MappingTarget;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

import com.silverlakesymmetri.cbs.commons.jpa.service.CbsGenericDataService;
import com.silverlakesymmetri.cbs.commons.xmlapi.enums.CbsXmlApiOperation;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.SdbAssigneeJpe;
import com.silverlakesymmetri.cbs.dep.svc.mapper.SdbAssigneeMapper;
import com.silverlakesymmetri.cbs.dep.xmlapi.DEPSDBASSIGNEEAPIType;
import com.silverlakesymmetri.cbs.mcl.jpa.mapping.sdo.util.MclJpeConstants;

public abstract class SdbAssigneeDecorator implements SdbAssigneeMapper {

	@Autowired
	@Qualifier("delegate")
	protected SdbAssigneeMapper delegate;

	@Autowired(required = true)
	@Qualifier("cbsGenericDataService")
	protected CbsGenericDataService dataService;

	private Long getClientId(String clientNo) {
		Map<String, Object> params = new HashMap<String, Object>();
		params.put("clientNo", clientNo);
		Long clientId = dataService.getWithNamedQuery(MclJpeConstants.CLIENT_JPE_FIND_CLIENT_ID_USING_CLIENT_NO, params,
				Long.class);
		return clientId;
	}

	@SuppressWarnings("rawtypes")
	@Override
	public DEPSDBASSIGNEEAPIType mapToApi(SdbAssigneeJpe jpe, @Context CbsXmlApiOperation oper,
			@Context Map otherInfo) {

		if (jpe.getClientId() != null) {
			jpe.setClientId(getClientId(jpe.getClientNo()));
		}

		DEPSDBASSIGNEEAPIType req = (DEPSDBASSIGNEEAPIType) delegate.mapToApi(jpe, oper, otherInfo);
		if (otherInfo.containsKey("sdbMainClientId")) {
			try {
				//req.setSDBMAINCLIENTNO(Double.parseDouble((String) otherInfo.get("sdbMainClientId")));
				req.setSDBMAINCLIENTNO((Double) otherInfo.get("sdbMainClientId"));
			} catch (Exception e) {
			}
		}

		return req;
	}

	@Override
	public SdbAssigneeJpe mapToJpe(DEPSDBASSIGNEEAPIType api, @MappingTarget SdbAssigneeJpe jpe) {

		if (jpe == null) {
			jpe = new SdbAssigneeJpe();
		}

		if (api == null) {
			return jpe;
		}

		delegate.mapToJpe(api, jpe);

		return jpe;
	}

}
