package com.silverlakesymmetri.cbs.dep.svc.mapper.decorator;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.silverlakesymmetri.cbs.dep.svc.mapper.TranValidationFlagsMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

import com.silverlakesymmetri.cbs.commons.context.CbsRuntimeContextManager;
import com.silverlakesymmetri.cbs.commons.context.CbsSessionContext;
import com.silverlakesymmetri.cbs.commons.jpa.service.CbsGenericDataService;
import com.silverlakesymmetri.cbs.commons.jpa.util.DateTimeHelper;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.ChqSellDdBnkJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.ChqSellJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.ChqSellTranJpe;
import com.silverlakesymmetri.cbs.dep.svc.mapper.mapping.ChqSellApplicantDetailsToDEPSELLAPPTYPEINTTypeMapper;
import com.silverlakesymmetri.cbs.dep.svc.mapper.mapping.ChqSellCollectionDetailsToDEPSELLCOLCONTINTTypeMapper;
import com.silverlakesymmetri.cbs.dep.svc.mapper.mapping.ChqSellDdBnkToDEPCHEQUESELLDDINTTypeMapper;
import com.silverlakesymmetri.cbs.dep.svc.mapper.mapping.ChqSellToDEPCHEQUESELLAPITypeMapper;
import com.silverlakesymmetri.cbs.dep.svc.mapper.mapping.ChqSellTranToDEPCHQBUYSELLPYMTINTTypeMapper;
import com.silverlakesymmetri.cbs.dep.xmlapi.DEPCHEQUESELLAPIType;
import com.silverlakesymmetri.cbs.dep.xmlapi.DEPCHEQUESELLDDINCOLLType;
import com.silverlakesymmetri.cbs.dep.xmlapi.DEPCHEQUESELLDDINTType;
import com.silverlakesymmetri.cbs.dep.xmlapi.DEPCHQBUYSELLPYMTINCOLLType;
import com.silverlakesymmetri.cbs.dep.xmlapi.DEPCHQBUYSELLPYMTINTType;
import com.silverlakesymmetri.cbs.dep.xmlapi.DEPSELLAPPLICANTINCOLLType;
import com.silverlakesymmetri.cbs.dep.xmlapi.DEPSELLAPPLICANTINTType;
import com.silverlakesymmetri.cbs.dep.xmlapi.DEPSELLCOLCONTINCOLLType;
import com.silverlakesymmetri.cbs.dep.xmlapi.DEPSELLCOLCONTINTType;
import com.silverlakesymmetri.cbs.mcl.jpa.mapping.sdo.util.MclJpeConstants;
                                                                    
public abstract class ChqSellToDEPCHEQUESELLAPITYPEDecorator extends FeeServiceDecorator implements ChqSellToDEPCHEQUESELLAPITypeMapper, TranValidationFlagsMapper {
	
	@Autowired
	@Qualifier("delegate")
	protected  ChqSellToDEPCHEQUESELLAPITypeMapper delegate;
	
	@Autowired
	protected ChqSellApplicantDetailsToDEPSELLAPPTYPEINTTypeMapper chqSellApplicantDetailsMapper;
	
	@Autowired
	protected ChqSellCollectionDetailsToDEPSELLCOLCONTINTTypeMapper chqSellCollectionDetailsMapper;
	
	@Autowired
	protected ChqSellDdBnkToDEPCHEQUESELLDDINTTypeMapper chqSellDdBnkMapper;
	
	@Autowired
	protected ChqSellTranToDEPCHQBUYSELLPYMTINTTypeMapper chqSellTranMapper;
	
	@Autowired
    protected DateTimeHelper dateTimeHelper;
	
	@Autowired
	protected CbsRuntimeContextManager _ctxMngr;
	
	@Autowired(required = true)
	@Qualifier("cbsGenericDataService")
	protected CbsGenericDataService dataService;

	@Override
	public DEPCHEQUESELLAPIType jpeToApiType(ChqSellJpe jpe) {
		CbsSessionContext sessionCtx = _ctxMngr.getContext(CbsSessionContext.class);
		DEPCHEQUESELLAPIType req = (DEPCHEQUESELLAPIType) delegate.jpeToApiType(jpe);
		
		// Applicant Details
		DEPSELLAPPLICANTINTType applicant = (DEPSELLAPPLICANTINTType) chqSellApplicantDetailsMapper.jpeToApiType(jpe.getChqSellApplicantDetailsRec());
		Map<String,Object> params = new HashMap<>();
		params.put("clientNo", jpe.getChqSellApplicantDetailsRec().getApplicantClientNo());
		List<Long> idList = dataService.findWithNamedQuery(MclJpeConstants.CLIENT_JPE_FIND_ID_FROM_REF_NO, params, Long.class);
		if(null != idList && idList.size() > 0) {
			applicant.setAPPLCLIENTNO(new Double(idList.get(0)));
		}
		if (jpe.getChqSellApplicantDetailsRec() != null && "N".equals(jpe.getChqSellApplicantDetailsRec().getExistingClient())){
        	applicant.setAPPLCONTACTREFNO(jpe.getChqSellApplicantDetailsRec().getApplicantContactType());
        }
		
		List<DEPSELLAPPLICANTINTType> applicantList = new ArrayList<>();
		applicantList.add(applicant);
		DEPSELLAPPLICANTINCOLLType applicantInCollType = new DEPSELLAPPLICANTINCOLLType();
		applicantInCollType.getDEPSELLAPPLICANTINT().addAll(applicantList);
		req.setRBSELLAPPLICANTINDTLS(applicantInCollType);
		
		// Collection Details
		DEPSELLCOLCONTINTType collectionDtl = (DEPSELLCOLCONTINTType) chqSellCollectionDetailsMapper.jpeToApiType(jpe.getChqSellCollectionDetailsRec());
		List<DEPSELLCOLCONTINTType> collectionDtlList = new ArrayList<>();
		collectionDtlList.add(collectionDtl);
		DEPSELLCOLCONTINCOLLType collectionDtlColType = new DEPSELLCOLCONTINCOLLType();
		collectionDtlColType.getDEPSELLCOLCONTINT().addAll(collectionDtlList);
		req.setRBSELLCOLCONTINDTLS(collectionDtlColType);
		
		BigDecimal totalAmt = new BigDecimal(0);
		Long totalQty = new Long(0);
		if (jpe!=null && jpe.getProcType()!=null){
			DEPCHEQUESELLDDINCOLLType ddInCollType = new DEPCHEQUESELLDDINCOLLType();
			if (("DFT".equals(jpe.getProcType()) || "BNK".equals(jpe.getProcType()))){
				// BNK/DFT Details
				for (ChqSellDdBnkJpe chqSellDdBnk : jpe.getChqSellDdBnkList()){
					DEPCHEQUESELLDDINTType ddIntType = (DEPCHEQUESELLDDINTType) chqSellDdBnkMapper.chqSellDdBankJpeToApiType(chqSellDdBnk);
					ddIntType.setBENEFNAME(chqSellDdBnk.getChqSellBeneficiaryRec().getBeneficiaryName());
					ddIntType.setBENEFADDRESS(chqSellDdBnk.getChqSellBeneficiaryRec().getBeneficiaryAddress());
					ddIntType.setBENEFCITY(chqSellDdBnk.getChqSellBeneficiaryRec().getBeneficiaryCity());
					ddIntType.setBENEFSTATE(chqSellDdBnk.getChqSellBeneficiaryRec().getBeneficiaryState());
					ddIntType.setBENEFCOUNTRY(chqSellDdBnk.getChqSellBeneficiaryRec().getBeneficiaryCountry());
					ddIntType.setBENEFPOSTALCODE(chqSellDdBnk.getChqSellBeneficiaryRec().getBeneficiaryPostalCode());
					ddIntType.setBENEFCONTACTTYPE(chqSellDdBnk.getChqSellBeneficiaryRec().getBeneficiaryContactType());
					
					ddInCollType.getDEPCHEQUESELLDDINT().add(ddIntType);
				}

				req.setRBCHEQUESELLDDINDTLS(ddInCollType);
				totalAmt = new BigDecimal(jpe.getTotalAmtDftBnk());
				req.setTOTALAMT(totalAmt.doubleValue());
				totalQty = jpe.getTotalQtyDftBnk();
				req.setTOTALQTY(new Double(totalQty).doubleValue());
			} else {
				// TCH Details
				for (ChqSellDdBnkJpe chqSellTc : jpe.getChqSellTcList()){
					DEPCHEQUESELLDDINTType ddIntType = (DEPCHEQUESELLDDINTType) chqSellDdBnkMapper.chqSellDdBankJpeToApiType(chqSellTc);
					if (null!=chqSellTc.getDenomination()){
						ddIntType.setAMOUNT(new Double(chqSellTc.getDenomination()));
					}					
					ddInCollType.getDEPCHEQUESELLDDINT().add(ddIntType);
					totalAmt.add(new BigDecimal(chqSellTc.getAmount()));
					totalQty = totalQty + chqSellTc.getQuantity();
				}
				req.setRBCHEQUESELLDDINDTLS(ddInCollType);
				req.setTOTALAMT(totalAmt.doubleValue());
				req.setTOTALQTY(new Double(totalQty).doubleValue());
			}
		}
		
		//ChqSellTcJpe
		//No equivalent API object yet
		
		// Transaction List / Payment Details
		DEPCHQBUYSELLPYMTINCOLLType pymtInCollType = new DEPCHQBUYSELLPYMTINCOLLType();
		for (ChqSellTranJpe chqSellTran : jpe.getChqSellTranList()){
			DEPCHQBUYSELLPYMTINTType pymtIntType = (DEPCHQBUYSELLPYMTINTType) chqSellTranMapper.jpeToApiType(chqSellTran);
			pymtIntType.setTRANDATE(dateTimeHelper.convertToCbsXmlApiDate(dateTimeHelper.getRunDate()));
			pymtIntType.setEFFECTDATE(dateTimeHelper.convertToCbsXmlApiDate(dateTimeHelper.getRunDate()));
			pymtIntType.setOVERRIDEOFFICER(sessionCtx.getUserCode());
			
			pymtInCollType.getDEPCHQBUYSELLPYMTINT().add(pymtIntType);
		}
		req.setRBCHEQUESELLPYMTINDTLS(pymtInCollType);
		
		//ChqSellScDtlsJpe
		//No equivalent in API - dep_ci_fee_apply_in

		req.setTRANVALIDATIONFLAGS(mapValidationFlags(jpe.getChqSellTranList().isEmpty() ? null
				: jpe.getChqSellTranList().get(0), "N", "N", "N", "Y", "Y"));
		
		if (jpe.getChqSellScDtlsRec() != null) {
			mapFeeToApi(jpe.getChqSellScDtlsRec(), req);
		}
		
		return req;
	}
	
}


