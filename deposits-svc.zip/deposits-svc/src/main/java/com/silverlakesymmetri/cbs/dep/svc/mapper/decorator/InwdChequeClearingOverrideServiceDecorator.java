package com.silverlakesymmetri.cbs.dep.svc.mapper.decorator;

import java.util.Map;

import org.mapstruct.Context;
import org.mapstruct.MappingTarget;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

import com.silverlakesymmetri.cbs.commons.xmlapi.enums.CbsXmlApiOperation;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.InwdChequeHistJpe;
import com.silverlakesymmetri.cbs.dep.svc.mapper.InwdChequeClearingOverrideServiceMapper;
import com.silverlakesymmetri.cbs.dep.xmlapi.DEPINWDCCOVERRIDEAPIType;
                                                                    
public abstract class InwdChequeClearingOverrideServiceDecorator implements InwdChequeClearingOverrideServiceMapper{
	
	@Autowired
	@Qualifier("delegate")
	protected  InwdChequeClearingOverrideServiceMapper delegate;
		
	@Override
	public DEPINWDCCOVERRIDEAPIType mapToApi(InwdChequeHistJpe jpe, @Context CbsXmlApiOperation oper, @Context Map otherInfo){
		
		DEPINWDCCOVERRIDEAPIType req = (DEPINWDCCOVERRIDEAPIType)delegate.mapToApi(jpe, oper, otherInfo);
		
		return  req;
	}
	
	@Override
	public InwdChequeHistJpe mapToJpe(DEPINWDCCOVERRIDEAPIType api, @MappingTarget InwdChequeHistJpe jpe){
		
		if (jpe == null){
			jpe = new InwdChequeHistJpe();
		}
		
		if (api == null){
			return jpe;
		}
		
		delegate.mapToJpe(api, jpe);
			
		return jpe;
	}
	

}


