package com.silverlakesymmetri.cbs.dep.svc;

import java.util.List;
import java.util.Map;

import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation;
import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation.ServiceOperationType;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.svc.BusinessService;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.ChequeStatusUpdate;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.ChequeStatusUpdateJpe;

public interface ChequeStatusUpdateService extends BusinessService<ChequeStatusUpdate, ChequeStatusUpdateJpe>{
	
	public static final String SVC_OP_NAME_CHEQUESTATUSUPDATE_GET= "ChequeStatusUpdateService.get";
	public static final String SVC_OP_NAME_CHEQUESTATUSUPDATE_QUERY= "ChequeStatusUpdateService.query";
	public static final String SVC_OP_NAME_CHEQUESTATUSUPDATE_CREATE= "ChequeStatusUpdateService.create";
	public static final String SVC_OP_NAME_CHEQUESTATUSUPDATE_UPDATE= "ChequeStatusUpdateService.update";
	public static final String SVC_OP_NAME_CHEQUESTATUSUPDATE_DELETE= "ChequeStatusUpdateService.delete";
	public static final String SVC_OP_NAME_CHEQUESTATUSUPDATE_FIND= "ChequeStatusUpdateService.find";
	public static final String  SVC_OP_NAME_CHEQUESTATUSUPDATE_COUNT = "ChequeStatusUpdateService.count";
	
	@ServiceOperation(name = SVC_OP_NAME_CHEQUESTATUSUPDATE_CREATE)
    public ChequeStatusUpdate create(ChequeStatusUpdate dataObject);

    @ServiceOperation(name = SVC_OP_NAME_CHEQUESTATUSUPDATE_UPDATE)
    public ChequeStatusUpdate update(ChequeStatusUpdate dataObject);

    @ServiceOperation(name = SVC_OP_NAME_CHEQUESTATUSUPDATE_DELETE)
    public boolean delete(ChequeStatusUpdate dataObject);

    @ServiceOperation(name = SVC_OP_NAME_CHEQUESTATUSUPDATE_QUERY)
    public List<ChequeStatusUpdate> query(int offset, int resultLimit, String groupBy, String order, Map<String, Object> filters);

    @ServiceOperation(name = SVC_OP_NAME_CHEQUESTATUSUPDATE_FIND)
    public List<ChequeStatusUpdate> find(FindCriteria findCriteria, CbsHeader cbsHeader);

    @ServiceOperation(name = SVC_OP_NAME_CHEQUESTATUSUPDATE_GET, type = ServiceOperationType.GET)
    public ChequeStatusUpdate getByPk(String publicKey, ChequeStatusUpdate reference);

	@ServiceOperation(name = SVC_OP_NAME_CHEQUESTATUSUPDATE_COUNT, type = ServiceOperationType.GET)
	public Long count(FindCriteria findCriteria, CbsHeader cbsHeader);

}
