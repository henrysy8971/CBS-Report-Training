package com.silverlakesymmetri.cbs.dep.svc.mapper.impl;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.inject.Inject;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

import com.silverlakesymmetri.cbs.commons.jpa.extension.JaxbSdoHelper;
import com.silverlakesymmetri.cbs.commons.jpa.service.CbsGenericDataService;
import com.silverlakesymmetri.cbs.commons.jpa.util.DateTimeHelper;
import com.silverlakesymmetri.cbs.commons.jpa.util.JpaEntityChangeTracker;
import com.silverlakesymmetri.cbs.commons.xmlapi.enums.CbsXmlApiOperation;
import com.silverlakesymmetri.cbs.core.constants.CoreConstants;
import com.silverlakesymmetri.cbs.csd.jpa.mapping.sdo.ProdScIndividualJpe;
import com.silverlakesymmetri.cbs.csd.xmlapi.CSDPRODSCDEFAPIType;
import com.silverlakesymmetri.cbs.csd.xmlapi.CSDPRODSCINDIVIDUALAPIType;
import com.silverlakesymmetri.cbs.csd.xmlapi.CSDPRODSCINDIVIDUALCOLLType;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.Acct;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.AcctStmt;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.IntDetail;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.JointAcct;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.Tda;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.AcctJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.DepFeeApplyJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.JointAcctJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.ProdScMaintFeeJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.util.DepJpeConstants;
import com.silverlakesymmetri.cbs.dep.jpa.util.DepTDStorHelper;
import com.silverlakesymmetri.cbs.dep.svc.mapper.AcctTDServiceMapper;
import com.silverlakesymmetri.cbs.dep.svc.mapper.mapping.DepFeeApplyToDEPFEEAPPLYINTypeMapper;
import com.silverlakesymmetri.cbs.dep.svc.mapper.mapping.DepTranOtherDataToDEPTRANOTHERDATATTypeMapper;
import com.silverlakesymmetri.cbs.dep.svc.mapper.mapping.ScDetailInToDEPFEEAPPLYDTLINTTypeMapper;
import com.silverlakesymmetri.cbs.dep.svc.mapper.mapping.TranValidationFlagsToDEPTRANVALIDATIONFLAGSTTypeMapper;
import com.silverlakesymmetri.cbs.dep.xmlapi.DEPFEEAPPLYDTLINCOLLType;
import com.silverlakesymmetri.cbs.dep.xmlapi.DEPFEEAPPLYDTLINTType;
import com.silverlakesymmetri.cbs.dep.xmlapi.DEPFEEAPPLYINType;
import com.silverlakesymmetri.cbs.dep.xmlapi.DEPJOINTACCTAPIType;
import com.silverlakesymmetri.cbs.dep.xmlapi.DEPJOINTACCTCOLLType;
import com.silverlakesymmetri.cbs.dep.xmlapi.DEPPRODSCMAINTFEEAPIType;
import com.silverlakesymmetri.cbs.dep.xmlapi.DEPPRODSCMAINTFEECOLLType;
import com.silverlakesymmetri.cbs.dep.xmlapi.DEPSTMTAPIType;
import com.silverlakesymmetri.cbs.dep.xmlapi.DEPSTMTCOLLType;
import com.silverlakesymmetri.cbs.dep.xmlapi.DEPTDAAPIType;
import com.silverlakesymmetri.cbs.dep.xmlapi.DEPTDAWRAPPERAPIType;
import com.silverlakesymmetri.cbs.dep.xmlapi.DEPTRANOTHERDATACOLLType;
import com.silverlakesymmetri.cbs.mcl.jpa.mapping.sdo.util.MclJpeConstants;

@Component
public class AcctTDServiceMapperImpl implements AcctTDServiceMapper {

	@Autowired(required = true)
	@Qualifier("cbsGenericDataService")
	protected CbsGenericDataService dataService;

	@Autowired
	protected DateTimeHelper dateTimeHelper;

	@Autowired
	protected DepFeeApplyToDEPFEEAPPLYINTypeMapper feeApplyMapper;

	@Autowired
	protected ScDetailInToDEPFEEAPPLYDTLINTTypeMapper scDetailInMapper;

	@Autowired
	protected DepTranOtherDataToDEPTRANOTHERDATATTypeMapper depTranOtherDataMapper;

	@Autowired
	protected TranValidationFlagsToDEPTRANVALIDATIONFLAGSTTypeMapper tranValidationFlagsMapper;

	@Autowired
	private DepTDStorHelper depTDStorHelper;

	@Inject
	protected JaxbSdoHelper jaxbSdoHelper;

	public DEPTDAWRAPPERAPIType mapToApi(Acct bdo, CbsXmlApiOperation oper) {

		AcctJpe jpe = jaxbSdoHelper.unwrap(bdo, AcctJpe.class);
		DEPTDAWRAPPERAPIType xmlApiObj = new DEPTDAWRAPPERAPIType();

		if (xmlApiObj.getDEPTDAREC() == null) {
			xmlApiObj.setDEPTDAREC(new DEPTDAAPIType());
		}

		xmlApiObj.getDEPTDAREC().setOPERATION(oper.getOperation());
		setDEPTDAAPI(bdo, jpe, xmlApiObj.getDEPTDAREC());
		JpaEntityChangeTracker ct = dataService.getJpaEntityChangeTracker(jpe);

		if (CbsXmlApiOperation.INSERT.equals(oper)) {
			if (!"SG".equals(jpe.getOwnershipType())) {
				transformJointAcctToDEPJOINTACCTAPIType(jpe.getJointAcctList(), oper, xmlApiObj);
			}
			if ("S".equals(bdo.getStmtPbk())) {
				transformAcctStmtToDEPSTMTAPIType(bdo, oper, xmlApiObj);
			}
		} else if (CbsXmlApiOperation.UPDATE.equals(oper)) {
			if ("SG".equals(jpe.getOwnershipType())) {
				for (JointAcctJpe jointAcctJpe : jpe.getJointAcctList()) {
					createDEPJOINTACCTAPI(CbsXmlApiOperation.DELETE, xmlApiObj, jointAcctJpe);
				}
			} else {
				// joint acct handle delete
				List<JointAcctJpe> delJointJpeList = ct.getDeletedObjects("jointAcctList", JointAcctJpe.class);
				transformJointAcctToDEPJOINTACCTAPIType(delJointJpeList, CbsXmlApiOperation.DELETE, xmlApiObj);
				// joint acct handle add and update
				for (JointAcctJpe jointAcctJpe : jpe.getJointAcctList()) {
					JpaEntityChangeTracker jointAcctCt = dataService.getJpaEntityChangeTracker(jointAcctJpe);
					if (jointAcctCt.isUpdated()) {
						createDEPJOINTACCTAPI(oper, xmlApiObj, jointAcctJpe);
					} else if (jointAcctCt.isNew()) {
						createDEPJOINTACCTAPI(CbsXmlApiOperation.INSERT, xmlApiObj, jointAcctJpe);
					}
				}
			}
			if ("S".equals(bdo.getStmtPbk())) {
				transformAcctStmtToDEPSTMTAPIType(bdo, oper, xmlApiObj);
			}
		}

		CSDPRODSCDEFAPIType prodScDefApi = null;
		if (jpe.getProdScDefRec() != null) {
			JpaEntityChangeTracker track = dataService.getJpaEntityChangeTracker(jpe.getProdScDefRec());
			if (track.isUpdated()) {
				prodScDefApi = new CSDPRODSCDEFAPIType();
				prodScDefApi.setPRODNO(jpe.getProdScDefRec().getProdNo());
				if (jpe.getProdScDefRec().getProdKey() != null) {
					prodScDefApi.setPRODKEY(jpe.getProdScDefRec().getProdKey().doubleValue());
				}
				prodScDefApi.setMODULEID(jpe.getProdScDefRec().getModuleId());
				prodScDefApi.setSUBTYPE(jpe.getProdScDefRec().getSubType());
				prodScDefApi.setSTOPSC(jpe.getProdScDefRec().getStopSc());
				Long thirdPartyKey = getInternalKey(jpe.getProdScDefRec().getThirdPartyAcctNo());
				if (thirdPartyKey != null) {
					prodScDefApi.setTHIRDPARTYKEY(thirdPartyKey.doubleValue());
				}
				prodScDefApi.setSCEXCEPTION(jpe.getProdScDefRec().getScException());
				prodScDefApi.setSCGROUPCODE(jpe.getProdScDefRec().getScGroupCode());
				prodScDefApi.setSCPACKTYPE(jpe.getProdScDefRec().getScPackType());
				prodScDefApi.setFWELIGIBLE(jpe.getProdScDefRec().getFwEligible());
				prodScDefApi.setFWSTATUS(jpe.getProdScDefRec().getFwStatus());
				if (StringUtils.isNotBlank(jpe.getProdScDefRec().getTaxFiler())) {
					prodScDefApi.setTAXFILER(jpe.getProdScDefRec().getTaxFiler());
				} else {
					prodScDefApi.setTAXFILER("N");	
				}
				prodScDefApi.setOPERATION(CbsXmlApiOperation.UPDATE.getOperation());
			}
		}
		xmlApiObj.setCSDPRODSCDEFREC(prodScDefApi);

		if (CbsXmlApiOperation.INSERT.equals(oper)) {
			transformProdScIndividualToCSDPRODSCINDIVIDUALAPIType(jpe.getProdScIndividualList(), oper, xmlApiObj);
		} else if (CbsXmlApiOperation.UPDATE.equals(oper)) {
			// Prod Sc Individual handle delete
			List<ProdScIndividualJpe> delProdScIndividualList = ct.getDeletedObjects("prodScIndividualList",
					ProdScIndividualJpe.class);
			transformProdScIndividualToCSDPRODSCINDIVIDUALAPIType(delProdScIndividualList, CbsXmlApiOperation.DELETE,
					xmlApiObj);
			// Prod Sc Individual handle add and update
			for (ProdScIndividualJpe prodScIndividualJpe : jpe.getProdScIndividualList()) {
				JpaEntityChangeTracker prodScIndividualCt = dataService.getJpaEntityChangeTracker(prodScIndividualJpe);
				if (prodScIndividualCt.isUpdated()) {
					createCSDPRODSCINDIVIDUALAPI(oper, xmlApiObj, prodScIndividualJpe);
				} else if (prodScIndividualCt.isNew()) {
					createCSDPRODSCINDIVIDUALAPI(CbsXmlApiOperation.INSERT, xmlApiObj, prodScIndividualJpe);
				}
			}
		}

		if (CbsXmlApiOperation.INSERT.equals(oper)) {
			transformProdScMaintFeeToDEPPRODSCMAINTFEEAPIType(jpe.getProdScMaintFeeList(), oper, xmlApiObj);
		} else if (CbsXmlApiOperation.UPDATE.equals(oper)) {
			// Prod Sc Maint Fee handle delete
			List<ProdScMaintFeeJpe> delProdScMaintFeeList = ct.getDeletedObjects("prodScMaintFeeList",
					ProdScMaintFeeJpe.class);
			transformProdScMaintFeeToDEPPRODSCMAINTFEEAPIType(delProdScMaintFeeList, CbsXmlApiOperation.DELETE,
					xmlApiObj);
			// Prod Sc Maint Fee handle add and update
			for (ProdScMaintFeeJpe prodScMaintFeeJpe : jpe.getProdScMaintFeeList()) {
				JpaEntityChangeTracker prodScMaintFeeCt = dataService.getJpaEntityChangeTracker(prodScMaintFeeJpe);
				if (prodScMaintFeeCt.isUpdated()) {
					createDEPPRODSCMAINTFEEAPI(oper, xmlApiObj, prodScMaintFeeJpe);
				} else if (prodScMaintFeeCt.isNew()) {
					createDEPPRODSCMAINTFEEAPI(CbsXmlApiOperation.INSERT, xmlApiObj, prodScMaintFeeJpe);
				}
			}
		}

		if (CbsXmlApiOperation.UPDATE.equals(oper)) {
			//Object officerId = ct.getAttributeOldValue("officerId");
			if (bdo.getHeader().getApplUserCode() != null) {
				xmlApiObj.getDEPTDAREC().setLASTCHANGEOFFICER(bdo.getHeader().getApplUserCode());
			} else {
				xmlApiObj.getDEPTDAREC().setLASTCHANGEOFFICER(bdo.getOfficerId());
			}
		} else if (CbsXmlApiOperation.INSERT.equals(oper)) {
			if (bdo.getHeader().getApplUserCode() != null) {
				xmlApiObj.getDEPTDAREC().setLASTCHANGEOFFICER(bdo.getHeader().getApplUserCode());
			}
		}

		return xmlApiObj;
	}

	private void createDEPJOINTACCTAPI(CbsXmlApiOperation oper, DEPTDAWRAPPERAPIType xmlApiObj,
			JointAcctJpe jointAcctJpe) {
		DEPJOINTACCTAPIType jointApi = new DEPJOINTACCTAPIType();
		jointApi.setOPERATION(oper.getOperation());
		jointApi.setACCTNO(xmlApiObj.getDEPTDAREC().getACCTNO());
		jointApi.setACCTDESC(xmlApiObj.getDEPTDAREC().getACCTDESC());
		jointApi.setINTERNALKEY(xmlApiObj.getDEPTDAREC().getINTERNALKEY());
		if (jointAcctJpe.getClientId() == null && jointAcctJpe.getClientNo() != null) {
			jointAcctJpe.setClientId(this.getClientId(jointAcctJpe.getClientNo()));
		}
		if (jointAcctJpe.getClientId() != null) {
			jointApi.setJOINTCLIENTNO(jointAcctJpe.getClientId());
		}
		jointApi.setOWNERSHIPTYPE(xmlApiObj.getDEPTDAREC().getOWNERSHIPTYPE());
		jointApi.setOFFICERID(xmlApiObj.getDEPTDAREC().getOFFICERID());
		if (xmlApiObj.getDEPJOINTACCTLIST() == null) {
			xmlApiObj.setDEPJOINTACCTLIST(new DEPJOINTACCTCOLLType());
		}
		xmlApiObj.getDEPJOINTACCTLIST().getDEPJOINTACCTAPI().add(jointApi);
	}

	private void transformJointAcctToDEPJOINTACCTAPIType(List<JointAcctJpe> jpeList, CbsXmlApiOperation oper,
			DEPTDAWRAPPERAPIType xmlApiObj) {
		if (jpeList != null && jpeList.size() > 0) {
			for (JointAcctJpe jointAcctJpe : jpeList) {
				createDEPJOINTACCTAPI(oper, xmlApiObj, jointAcctJpe);
			}
		}
	}

	private void transformAcctStmtToDEPSTMTAPIType(Acct bdo, CbsXmlApiOperation oper, DEPTDAWRAPPERAPIType xmlApiObj) {
		if (bdo.getAcctStmtRec() != null) {
			DEPSTMTAPIType stmtApi = new DEPSTMTAPIType();
			setDEPSTMTAPI(bdo, stmtApi, oper, xmlApiObj);
			if (xmlApiObj.getDEPSTMTLIST() == null) {
				xmlApiObj.setDEPSTMTLIST(new DEPSTMTCOLLType());
			}
			xmlApiObj.getDEPSTMTLIST().getDEPSTMTAPI().add(stmtApi);
		}
	}

	private void setDEPSTMTAPI(Acct bdo, DEPSTMTAPIType api, CbsXmlApiOperation oper, DEPTDAWRAPPERAPIType xmlApiObj) {
		DEPTDAAPIType depAcctApi = xmlApiObj.getDEPTDAREC();
		AcctStmt acctStmtBdo = bdo.getAcctStmtRec();
		List<JointAcct> jointAcctBdoList = bdo.getJointAcctList();
		if (depAcctApi.getINTERNALKEY() != null) {
			api.setINTERNALKEY(depAcctApi.getINTERNALKEY());
		}
		Number stmtRefNo = acctStmtBdo.getStmtRefNo();
		if (stmtRefNo != null) {
			api.setSTMTREFNO(stmtRefNo.doubleValue());
		}
		api.setOPERATION(oper.getOperation());
		api.setACCTNO(depAcctApi.getACCTNO());
		api.setACCTDESC(depAcctApi.getACCTDESC());
		api.setCCY(depAcctApi.getCCY());
		api.setDISTRCHANNEL(acctStmtBdo.getDistrChannel());
		api.setTEMPLATE(acctStmtBdo.getTemplate());
		Number lastStmtNoNumber = acctStmtBdo.getLastStmtNo();
		if (lastStmtNoNumber != null) {
			api.setLASTSTMTNO(lastStmtNoNumber.doubleValue());
		}

		if (CbsXmlApiOperation.INSERT.equals(oper) && lastStmtNoNumber == null) {
			api.setLASTSTMTNO(0d);
		}

		api.setSTMTTYPE(acctStmtBdo.getStmtType());
		api.setCONSSC(acctStmtBdo.getConsSc());
		api.setSTMTAFTERMOVEMENT(acctStmtBdo.getStmtAfterMovement());
		api.setSTMTATCAP(acctStmtBdo.getStmtAtCap());
		api.setSUPPRESSPRINT(acctStmtBdo.getSuppressPrint());
		api.setCONTACTREFNO(acctStmtBdo.getContactRefNo());

		List<Long> clientIdList = getContactClientIdList(acctStmtBdo.getContactRefNo());
		if (jointAcctBdoList != null && clientIdList != null) {
			for (JointAcct jointAcctBdo : jointAcctBdoList) {
				for (Long clientId : clientIdList) {
					if (clientId != null && jointAcctBdo.getClientNo() != null) {
						Long jointAcctClientId = this.getClientId(jointAcctBdo.getClientNo());
						if (clientId.compareTo(jointAcctClientId) == 0) {
							api.setCLIENTNO(jointAcctClientId);
							break;
						}
					}
				}
				if (api.getCLIENTNO() != null) { break; }
			}
		}
		if (api.getCLIENTNO() == null) {
			api.setCLIENTNO(depAcctApi.getCLIENTNO());
		}

		api.setONMATURITYSTMT(acctStmtBdo.getOnMaturityStmt());
		api.setSTMTHANDLING(acctStmtBdo.getStmtHandling());
		api.setSUSPENDMAILCODE(acctStmtBdo.getSuspendMailCode());
		api.setPERIODFREQ(acctStmtBdo.getPeriodFreq());
		if (acctStmtBdo.getNextStmtDate() != null) {
			api.setNEXTSTMTDATE(dateTimeHelper.convertToCbsXmlApiDate(acctStmtBdo.getNextStmtDate()));
		}
		Number stmtDayNumber = acctStmtBdo.getStmtDay();
		if (stmtDayNumber != null) {
			api.setSTMTDAY(stmtDayNumber.doubleValue());
		}
		api.setCTRLCOMMAND(acctStmtBdo.getCtrlCommand());
		api.setSTMTLANG(acctStmtBdo.getStmtLang());
		api.setSTMTPBK(depAcctApi.getSTMTPBK());
		api.setOFFICERID(depAcctApi.getOFFICERID());

		api.setBRANCH(depAcctApi.getBRANCH());
		api.setACCTTYPE(depAcctApi.getACCTTYPE());
		api.setMATURITYDATE(depAcctApi.getMATURITYDATE());

		// no ui field yet, so default
		api.setNOOFCOPIES(1d);
	}

	private void setDEPTDAAPI(Acct bdo, AcctJpe jpe, DEPTDAAPIType depAcctApiType) {
		depAcctApiType.setACCTNO(bdo.getAcctNo());
		depAcctApiType.setINTERNALKEY(jpe.getInternalKey());
		depAcctApiType.setACCTTYPE(bdo.getAcctType());
		if (jpe.getClientId() != null) {
			depAcctApiType.setCLIENTNO(Long.valueOf(jpe.getClientId()));
		}
		depAcctApiType.setIBANCODE(bdo.getIbanCode());
		depAcctApiType.setACCTDESC(bdo.getAcctDesc());
		depAcctApiType.setBRANCH(bdo.getBranch());
		depAcctApiType.setCCY(bdo.getCcy());
		depAcctApiType.setOWNERSHIPTYPE(bdo.getOwnershipType());
		depAcctApiType.setACCTSTATUS(bdo.getAcctStatus());
		if (bdo.getAcctOpenDate() != null) {
			depAcctApiType.setACCTOPENDATE(dateTimeHelper.convertToCbsXmlApiDate(bdo.getAcctOpenDate()));
		}
		// no last change date
		depAcctApiType.setPROFITCENTRE(bdo.getProfitCentre());
		depAcctApiType.setCLIENTIND(bdo.getClientInd());
		depAcctApiType.setUSERID(bdo.getHeader().getApplUserCode());
		if (bdo.getHeader() != null && bdo.getHeader().getClientInfo() != null) {
			depAcctApiType.setWSID(bdo.getHeader().getClientInfo().getWsId());
		}
		depAcctApiType.setOFFICERID(bdo.getOfficerId());
		depAcctApiType.setSTMTPBK(bdo.getStmtPbk());
		depAcctApiType.setHOSTCHECKFLAG("N");
		depAcctApiType.setCERTIFICATENO(bdo.getCertificateNo());
		depAcctApiType.setCLIENTNO(this.getClientId(bdo.getClientNo()));
		if (StringUtils.isNotBlank(bdo.getAutoGenerateAcctNo())
				&& ("Y".equals(bdo.getAutoGenerateAcctNo()) || "N".equals(bdo.getAutoGenerateAcctNo()))) {
			depAcctApiType.setAUTOGENERATEACCTNO(bdo.getAutoGenerateAcctNo());
		}
		depAcctApiType.setNBCCODE(bdo.getNbcCode());
		if (bdo.getHoRepCode() != null) {
			depAcctApiType.setHOREPCODE(new Double(bdo.getHoRepCode()));
		}
		depAcctApiType.setOLDPRODUCTCODE(bdo.getOldProductCode());

		if (bdo.getTdaRec() != null) {
			Tda tda = bdo.getTdaRec();
			depAcctApiType.setPRINCIPALAMT(tda.getPrincipalAmt());
			Number depTermPeriod = tda.getDepTermPeriod();
			if (depTermPeriod != null) {
				depAcctApiType.setDEPTERMPERIOD(depTermPeriod.doubleValue());
			}
			depAcctApiType.setDEPTERMTYPE(tda.getDepTermType());
			Number depTermDays = tda.getDepTermDays();
			if (depTermDays != null) {
				depAcctApiType.setDEPTERMDAYS(depTermDays.intValue());
			}
			if (tda.getMaturityDate() != null) {
				depAcctApiType.setMATURITYDATE(dateTimeHelper.convertToCbsXmlApiDate(tda.getMaturityDate()));
			} else {
				if (depTermPeriod != null && depAcctApiType.getDEPTERMTYPE() != null) {
					Date maturityDate = depTDStorHelper.calcFdMatDate(depTermPeriod.intValue(),
							depAcctApiType.getDEPTERMTYPE(), depAcctApiType.getDEPTERMDAYS(), bdo.getCcy(), bdo.getClientNo(), bdo.getBranch(),
							dateTimeHelper.getRunDate(), null);
					if (maturityDate != null) {
						depAcctApiType.setMATURITYDATE(dateTimeHelper.convertToCbsXmlApiDate(dateTimeHelper.getSDODateTime(maturityDate)));
					}
				}
			}
			depAcctApiType.setAUTORENEWROLLOVER(tda.getAutoRenewRollover());
			depAcctApiType.setBILLOFEXCHANGE(tda.getBillOfExchange());
			if ("W".equals(tda.getAutoRenewRollover())) {
				// times renew auto
				Number renewNo = tda.getRenewNo();
				if (renewNo != null) {
					depAcctApiType.setRENEWROLLNO(renewNo.doubleValue());
				}
			} else if ("O".equals(tda.getAutoRenewRollover())) {
				// times rolloverNo auto
				Number rolloverNo = tda.getRolloverNo();
				if (rolloverNo != null) {
					depAcctApiType.setRENEWROLLNO(rolloverNo.doubleValue());
				}
			}
			// display only fields
			// tda.getTdBonfType();
			// tda.getPrincipalBonusRate();
			// tda.getLastMvmtDate();
			// tda.getLastMvmtStatus();
			// tda.getTimesRenewed();
			// tda.getTimesRolledover();
			// tda.getPrevAccountNo();
		}

		if (bdo.getIntDetailRec() != null) {
			IntDetail intDtl = bdo.getIntDetailRec();
			depAcctApiType.setTDRELATIONIND(intDtl.getTdRelationInd());
			depAcctApiType.setCRPRINACCT(intDtl.getCrPrinAcct());
			// intDtl.getCrPrinAcctCcy();
			depAcctApiType.setINTERESTBONF(intDtl.getInterestBonf());
			depAcctApiType.setCRACCTLEVELINTRATE(intDtl.getCrAcctLevelIntRate());
			depAcctApiType.setCRSPREADRATE(intDtl.getCrSpreadRate());
			// intDtl.getCrEffectiveRate();
			depAcctApiType.setCRINTTYPE(intDtl.getCrIntType());
			// intDtl.getCrIntRateInd();
			depAcctApiType.setCRTAXTYPE(intDtl.getCrTaxType());
			depAcctApiType.setCRTDPAYOUT(intDtl.getCrTdPayout());
			depAcctApiType.setCAPONDEC31(intDtl.getCapOnDec31());
			depAcctApiType.setCRPERIODFREQ(intDtl.getCrPeriodFreq());
			if (intDtl.getCrNextCycleDate() != null) {
				depAcctApiType.setCRNEXTCYCLEDATE(dateTimeHelper.convertToCbsXmlApiDate(intDtl.getCrNextCycleDate()));
			}
			if (intDtl.getCrIntDay() != null) {
				depAcctApiType.setCRINTDAY(Double.valueOf(intDtl.getCrIntDay()));
			}
			depAcctApiType.setCRCOFAPPTYPE(intDtl.getCrCofAppType());
			if ("F".equals(intDtl.getCrCofAppType())) {
				depAcctApiType.setCRCOFRATE(intDtl.getCrCofRate());
			} else if ("A".equals(intDtl.getCrCofAppType())) {
				depAcctApiType.setCRFUNDTYPE(intDtl.getCrFundType());
			}
			depAcctApiType.setCRCOFLIQPREMIA(intDtl.getCrCofLiqPremia());
			// intDtl.getCrCofEffectRate();
			depAcctApiType.setCRINTACCT(intDtl.getCrIntAcct());
			// intDtl.getCrIntAcctCcy();
			depAcctApiType.setCRINTCAP("Y"); // always set to Y
		}

		if (jpe.getDepFeeApplyList() != null && jpe.getDepFeeApplyList().size() > 0) {
			DEPFEEAPPLYINType feeApplyIn = null;
			for (DepFeeApplyJpe depFeeApply : jpe.getDepFeeApplyList()) {
				if (depFeeApply.getScDetailIn() != null && (depFeeApply.getScDetailIn().getScAmt() == null
						|| depFeeApply.getScDetailIn().getScAmt().doubleValue() == 0.00)) {
					continue;
				}
				if (feeApplyIn == null) {
					feeApplyIn = feeApplyMapper.mapDepFeeApplyToDEPFEEAPPLYIN(depFeeApply);
					feeApplyIn.setSCDETAILIN(new DEPFEEAPPLYDTLINCOLLType());
					feeApplyIn.setRBTRANOTHERDATAIN(new DEPTRANOTHERDATACOLLType());
				}
				feeApplyIn.getSCDETAILIN().getDEPFEEAPPLYDTLINT()
						.add(scDetailInMapper.mapScDetailInToDEPFEEAPPLYDTLIN(depFeeApply.getScDetailIn()));
				feeApplyIn.getRBTRANOTHERDATAIN().getDEPTRANOTHERDATAT().add(depTranOtherDataMapper
						.mapTranValidationFlagsToDEPTRANVALIDATIONFLAGST(depFeeApply.getRbTranOtherData()));
				feeApplyIn.setTRANVALIDATIONFLAGS(tranValidationFlagsMapper
						.mapTranValidationFlagsToDEPTRANVALIDATIONFLAGST(depFeeApply.getTranValidationFlags()));
			}
			if (feeApplyIn != null) {
				// TODO: temporary fix - remove this when Cash payment is available
				for (DEPFEEAPPLYDTLINTType fee : feeApplyIn.getSCDETAILIN().getDEPFEEAPPLYDTLINT()) {
					fee.setSCPAYMENTMODE("A");
				}
			}
			depAcctApiType.setSCAPPLYIN(feeApplyIn);
		}
	}

	private void transformProdScIndividualToCSDPRODSCINDIVIDUALAPIType(List<ProdScIndividualJpe> jpeList,
			CbsXmlApiOperation oper, DEPTDAWRAPPERAPIType xmlApiObj) {
		if (jpeList != null && jpeList.size() > 0) {
			for (ProdScIndividualJpe prodScIndividualJpe : jpeList) {
				createCSDPRODSCINDIVIDUALAPI(oper, xmlApiObj, prodScIndividualJpe);
			}
		}
	}

	private void createCSDPRODSCINDIVIDUALAPI(CbsXmlApiOperation oper, DEPTDAWRAPPERAPIType xmlApiObj,
			ProdScIndividualJpe prodScIndividualJpe) {
		CSDPRODSCINDIVIDUALAPIType scIndvApi = new CSDPRODSCINDIVIDUALAPIType();
		scIndvApi.setPRODSCINDVLREFNO(prodScIndividualJpe.getProdScIndvlRefNo());
		scIndvApi.setPRODKEY(Double.valueOf(xmlApiObj.getDEPTDAREC().getINTERNALKEY()));
		scIndvApi.setMODULEID(prodScIndividualJpe.getModuleId());
		scIndvApi.setSUBTYPE(prodScIndividualJpe.getSubType());
		scIndvApi.setSCTYPE(prodScIndividualJpe.getScType());
		scIndvApi.setSCRATETYPE(prodScIndividualJpe.getScRateType());
		if (prodScIndividualJpe.getEffectFromDate() != null) {
			scIndvApi.setEFFECTFROMDATE(dateTimeHelper.convertToCbsXmlApiDate(prodScIndividualJpe.getEffectFromDate()));
		}
		if (prodScIndividualJpe.getEffectToDate() != null) {
			scIndvApi.setEFFECTTODATE(dateTimeHelper.convertToCbsXmlApiDate(prodScIndividualJpe.getEffectToDate()));
		}
		scIndvApi.setREASONTYPE(prodScIndividualJpe.getReasonType());
		scIndvApi.setREASONDESC(prodScIndividualJpe.getReasonDesc());
		scIndvApi.setPERCSTANDARDSC(prodScIndividualJpe.getPercStandardSc());
		scIndvApi.setMINSCAMT(prodScIndividualJpe.getMinScAmt());
		scIndvApi.setMAXSCAMT(prodScIndividualJpe.getMaxScAmt());
		scIndvApi.setMAXDISCOUNTSCAMT(prodScIndividualJpe.getMaxDiscountScAmt());
		scIndvApi.setCCY(xmlApiObj.getDEPTDAREC().getCCY());
		scIndvApi.setOPERATION(oper.getOperation());
		if (xmlApiObj.getCSDPRODSCINDIVIDUALLIST() == null) {
			xmlApiObj.setCSDPRODSCINDIVIDUALLIST(new CSDPRODSCINDIVIDUALCOLLType());
		}
		xmlApiObj.getCSDPRODSCINDIVIDUALLIST().getCSDPRODSCINDIVIDUALAPI().add(scIndvApi);
	}

	private void transformProdScMaintFeeToDEPPRODSCMAINTFEEAPIType(List<ProdScMaintFeeJpe> jpeList,
			CbsXmlApiOperation oper, DEPTDAWRAPPERAPIType xmlApiObj) {
		if (jpeList != null && jpeList.size() > 0) {
			for (ProdScMaintFeeJpe prodScMaintFeeJpe : jpeList) {
				createDEPPRODSCMAINTFEEAPI(oper, xmlApiObj, prodScMaintFeeJpe);
			}
		}
	}

	private void createDEPPRODSCMAINTFEEAPI(CbsXmlApiOperation oper, DEPTDAWRAPPERAPIType xmlApiObj,
			ProdScMaintFeeJpe prodScMaintFeeJpe) {
		DEPPRODSCMAINTFEEAPIType scMaintApi = new DEPPRODSCMAINTFEEAPIType();
		scMaintApi.setPRODKEY(Double.valueOf(xmlApiObj.getDEPTDAREC().getINTERNALKEY()));
		scMaintApi.setMODULEID(prodScMaintFeeJpe.getModuleId());
		scMaintApi.setSUBTYPE(prodScMaintFeeJpe.getSubType());
		scMaintApi.setSCTYPE(prodScMaintFeeJpe.getScType());
		scMaintApi.setSCRATETYPE(prodScMaintFeeJpe.getScRateType());
		scMaintApi.setSCPERIODFREQ(prodScMaintFeeJpe.getScPeriodFreq());
		if (prodScMaintFeeJpe.getScNextDate() != null) {
			scMaintApi.setSCNEXTDATE(dateTimeHelper.convertToCbsXmlApiDate(prodScMaintFeeJpe.getScNextDate()));
		}
		if (prodScMaintFeeJpe.getScLastDate() != null) {
			scMaintApi.setSCLASTDATE(dateTimeHelper.convertToCbsXmlApiDate(prodScMaintFeeJpe.getScLastDate()));
		}
		if (prodScMaintFeeJpe.getScDay() != null) {
			scMaintApi.setSCDAY(prodScMaintFeeJpe.getScDay().doubleValue());
		}
		scMaintApi.setOPERATION(oper.getOperation());
		if (xmlApiObj.getDEPPRODSCMAINTFEELIST() == null) {
			xmlApiObj.setDEPPRODSCMAINTFEELIST(new DEPPRODSCMAINTFEECOLLType());
		}
		xmlApiObj.getDEPPRODSCMAINTFEELIST().getDEPPRODSCMAINTFEEAPI().add(scMaintApi);
	}

	public Acct mapToJpe(DEPTDAWRAPPERAPIType api, Acct bdo) {
		return null;
	}

	private Long getClientId(String clientNo) {
		Long clientId = null;
		if (!StringUtils.isEmpty(clientNo)) {
			Map<String, Object> params = new HashMap<String, Object>();
			params.put(CoreConstants.ATTR_CLIENT_NO, clientNo);
			List<Long> clientIdList = dataService.findWithNamedQuery(MclJpeConstants.CLIENT_JPE_FIND_CLIENT_ID_USING_CLIENT_NO, params, Long.class);
			if (clientIdList != null && clientIdList.size() > 0) {
				clientId = clientIdList.get(0);
			}
		}
		return clientId;
	}

	private Long getInternalKey(String acctNo) {
		Long internalKey = null;
		if (!StringUtils.isEmpty(acctNo)) {
			Map<String, Object> params = new HashMap<String, Object>();
			params.put("acctNo", acctNo);
			 List<Long> internalKeyList = dataService.findWithNamedQuery(DepJpeConstants.ACCT_JPE_FIND_INTERNAL_KEY_BY_ACCT_NO, params, Long.class);
			 if (internalKeyList != null && internalKeyList.size() > 0) {
				 internalKey = internalKeyList.get(0);
			 }
		}
		return internalKey;
	}

	private List<Long> getContactClientIdList(String contactRefNo) {
		if (!StringUtils.isEmpty(contactRefNo)) {
			List<Long> list = dataService.findWithQuery(String.format(
					"SELECT DISTINCT a.clientId FROM ClientJpe a, ClientContactJpe b WHERE a.clientId = b.clientId AND b.contactRefNo = '%s'",
					contactRefNo), Long.class);
			return list;
		}
		return null;
	}

}
