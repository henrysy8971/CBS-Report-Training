package com.silverlakesymmetri.cbs.dep.svc.mapper;

import com.silverlakesymmetri.cbs.commons.xmlapi.enums.CbsXmlApiOperation;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.CiRdBunchDistJpe;
import com.silverlakesymmetri.cbs.dep.xmlapi.DEPCIRDAPIType;


public interface ChequeDistributionServiceMapper{
	
	public DEPCIRDAPIType mapToApi(CiRdBunchDistJpe jpe, CbsXmlApiOperation oper);
	
//	public CiRdRegJpe mapToJpe(DEPCIRDAPIType api, CiRdBunchDistJpe jpe);
	
}

