package com.silverlakesymmetri.cbs.dep.svc.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.silverlakesymmetri.cbs.dep.xmlapi.DEPATMAPIType;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.mysema.query.types.EntityPath;
import com.silverlakesymmetri.cbs.commons.exception.CbsRuntimeException;
import com.silverlakesymmetri.cbs.commons.exception.base.CbsOtherDetailsException;
import com.silverlakesymmetri.cbs.commons.exception.base.CbsServiceException;
import com.silverlakesymmetri.cbs.commons.svc.AbstractXmlApiBusinessService;
import com.silverlakesymmetri.cbs.commons.svc.BusinessObjectValidationCapable;
import com.silverlakesymmetri.cbs.commons.xmlapi.enums.CbsXmlApiOperation;
import com.silverlakesymmetri.cbs.commons.xmlapi.rq.CUTAPIHEADERINType;
import com.silverlakesymmetri.cbs.commons.xmlapi.rs.CUTAPIHEADEROUTCPLXType;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.AtmTran;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.AtmTranJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.DataElementsJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.QAtmTranJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.id.AtmTranPk;
//import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.id.AtmTranPk;
import com.silverlakesymmetri.cbs.dep.svc.AtmTranService;
import com.silverlakesymmetri.cbs.dep.svc.mapper.AtmTranServiceMapper;
import com.silverlakesymmetri.cbs.dep.xmlapi.DEPISOFINREQAPIType;

@Service
@Transactional
public class AtmTranServiceImpl extends AbstractXmlApiBusinessService<AtmTran, AtmTranJpe, AtmTranPk, DEPATMAPIType, DEPATMAPIType>
implements AtmTranService, BusinessObjectValidationCapable<AtmTran> {

	@Autowired
	AtmTranServiceMapper mapper;
	
	@Override
	public AtmTran getByPk(String publicKey, AtmTran reference) {
		return super.getByPk(publicKey, reference);
	}

	@Override
	protected Class<DEPATMAPIType> getXmlApiResponseClass() {
		return DEPATMAPIType.class;
	}

	@Override
	protected List<AtmTran> processXmlApiListRs(AtmTran arg0, DEPATMAPIType arg1) {
		return null;
	}
	
	@Override
	protected AtmTran handleXmlApiRs(AtmTran dataObject, DEPATMAPIType xmlApiRs,
			CUTAPIHEADEROUTCPLXType headerOutCplx) {		
		AtmTranJpe jpe = null;
		if (dataObject != null) {
			jpe = unwrap(dataObject);
		}
		
		try {
			processErrors(headerOutCplx, jpe, null);
		} catch (CbsRuntimeException e) {
			AtmTran atmTran = processXmlApiRs(dataObject, xmlApiRs);
			CbsOtherDetailsException otherDtlsExc = new CbsOtherDetailsException(e, (Object) atmTran); 
			if (otherDtlsExc != null) {
				throw otherDtlsExc;
			}
		}
		
		return processXmlApiRs(dataObject, xmlApiRs);
	}

	@Override
	protected AtmTran processXmlApiRs(AtmTran dataObject, DEPATMAPIType api) {
		AtmTranJpe jpe = jaxbSdoHelper.unwrap(dataObject, AtmTranJpe.class);
		DataElementsJpe jpeDe = jaxbSdoHelper.unwrap(dataObject.getDataElementsRec(), DataElementsJpe.class);
		jpeDe = mapper.mapToJpe(api, jpeDe);
		jpe.setDataElementsRec(jpeDe);
		
		return jaxbSdoHelper.wrap(jpe);
	}

	@Override
	public AtmTran create(AtmTran dataObject) {
		//return super.queryDataObject(transformBdoToXmlApiRqCreate(dataObject));
		return super.create(dataObject);
	}

	@Override
	protected DEPATMAPIType transformBdoToXmlApiRqCreate(AtmTran dataObject) {
		Map map = new HashMap();
		
		AtmTranJpe jpe = jaxbSdoHelper.unwrap(dataObject);
		DEPATMAPIType api =  mapper.mapToApi(jpe.getDataElementsRec(), CbsXmlApiOperation.INSERT, map);
		super.setTechColsFromDataObject(dataObject, api);

		return api;
	}

	@Override
	protected DEPATMAPIType transformBdoToXmlApiRqDelete(AtmTran arg0) {
		return null;
	}

	@Override
	protected DEPATMAPIType transformBdoToXmlApiRqUpdate(AtmTran arg0) {
		return null;
	}

	@Override
	protected EntityPath<AtmTranJpe> getEntityPath() {
		return QAtmTranJpe.atmTranJpe;
	}

	@Override
	protected AtmTranPk getIdFromDataObjectInstance(AtmTran dataObject) {
		return new AtmTranPk(dataObject.getAtmSeqNo());
	}

	@Override
	protected CUTAPIHEADERINType createHeader() {
		// set new field to return payload for unsuccessful transaction. 
		return super.createHeader();
	}

	@Override
	protected AtmTran preCreateValidation(AtmTran dataObject) {
		dataObject.setAtmSeqNo(1);
		return super.preCreateValidation(dataObject);
	}

}
