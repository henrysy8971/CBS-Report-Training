package com.silverlakesymmetri.cbs.dep.svc.mapper.mapping;

import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.*;
import org.mapstruct.*;

@Mapper
public interface TransferTransactionWrapperServiceMapper {
/*
	@Mappings({
			@Mapping(source = "ignoreRestraint", target = "ignoreRestraint", defaultValue = "N"),
			@Mapping(source = "ignoreAvailbal", target = "ignoreAvailbal", defaultValue = "N"),
			@Mapping(source = "checkOverride", target = "checkOverride", defaultValue = "N"),
			@Mapping(source = "checkTellerLimit", target = "checkTellerLimit", defaultValue = "N"),
			@Mapping(source = "checkEffdate", target = "checkEffdate", defaultValue = "N"),
	})
	TransferTransactionJpe mapToTransferTransaction(TransferTransactionJpe jpe);

	@InheritInverseConfiguration
	TransferTransactionWrapperJpe mapFromTransferTransaction(TransferTransactionJpe jpe);

	@Mappings({
			@Mapping(source = "ignoreRestraint", target = "ignoreRestraint", defaultValue = "N"),
			@Mapping(source = "ignoreAvailbal", target = "ignoreAvailbal", defaultValue = "N"),
			@Mapping(source = "checkOverride", target = "checkOverride", defaultValue = "N"),
			@Mapping(source = "checkTellerLimit", target = "checkTellerLimit", defaultValue = "N"),
			@Mapping(source = "checkEffdate", target = "checkEffdate", defaultValue = "N"),
	})
	TdTransferTransactionJpe mapToTdTransferTransaction(TransferTransactionWrapperJpe jpe,
														@MappingTarget TdTransferTransactionJpe targetJpe);

	@InheritInverseConfiguration
	TransferTransactionWrapperJpe mapFromTdTransferTransaction(TdTransferTransactionJpe jpe);
*/

	TdTransferTransactionJpe mapDetailToTdTransferTransaction(TransferTransactionDetailJpe jpe);

}
