package com.silverlakesymmetri.cbs.dep.svc.impl;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.mysema.query.types.EntityPath;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.svc.AbstractBusinessService;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.SdbFeeDueBalV;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.QSdbFeeDueBalVJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.SdbFeeDueBalVJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.id.SdbFeeDueBalVPk;
import com.silverlakesymmetri.cbs.dep.svc.SdbFeeDueBalVService;

@Service
@Transactional
public class SdbFeeDueBalVServiceImpl extends AbstractBusinessService<SdbFeeDueBalV, SdbFeeDueBalVJpe, SdbFeeDueBalVPk> implements SdbFeeDueBalVService {

	@Override
	protected SdbFeeDueBalVPk getIdFromDataObjectInstance(SdbFeeDueBalV arg0) {
		return new SdbFeeDueBalVPk(arg0.getSdbInternalKey());
	}
	
	@Override
	protected EntityPath<SdbFeeDueBalVJpe> getEntityPath() {
		return QSdbFeeDueBalVJpe.sdbFeeDueBalVJpe;
	}

	@Override
	public SdbFeeDueBalV get(SdbFeeDueBalV arg0) {
		return super.get(arg0);
	}

	@Override
	public List<SdbFeeDueBalV> query(int offset, int resultLimit, String groupBy, String order,
			Map<String, Object> filters) {
		return super.query(offset, resultLimit, groupBy, order, filters);
	}

	@Override
	public SdbFeeDueBalV getByPk(String publicKey, SdbFeeDueBalV reference) {
		return super.getByPk(publicKey, reference);
	}

	@Override
	public List<SdbFeeDueBalV> find(FindCriteria findCriteria, CbsHeader cbsHeader) {
		return super.find(findCriteria, cbsHeader);
	}

}