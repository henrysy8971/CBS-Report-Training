package com.silverlakesymmetri.cbs.dep.svc.mapper;

import java.util.Map;

import org.mapstruct.Context;
import org.mapstruct.DecoratedWith;
import org.mapstruct.InheritConfiguration;
import org.mapstruct.InheritInverseConfiguration;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingTarget;
import org.mapstruct.Mappings;

import com.silverlakesymmetri.cbs.commons.jpa.util.DateTimeHelper;
import com.silverlakesymmetri.cbs.commons.xmlapi.enums.CbsXmlApiOperation;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.FeeInquiryHdrJpe;
import com.silverlakesymmetri.cbs.dep.svc.mapper.decorator.DepositsFeeServiceDecorator;
import com.silverlakesymmetri.cbs.dep.svc.mapper.mapping.FeeInquiryHdrToDEPFEEDETAILSAPITypeMapper;
import com.silverlakesymmetri.cbs.dep.xmlapi.DEPFEEDETAILSAPIType;

@Mapper(config=FeeInquiryHdrToDEPFEEDETAILSAPITypeMapper.class, uses={DateTimeHelper.class})
@DecoratedWith(DepositsFeeServiceDecorator.class)
public interface DepositsFeeServiceMapper{
	
	public  static final String BRANCH = "BRANCH";
	public  static final String CHANNEL_SOURCE = "CHANNEL_SOURCE";
	
	@Mappings({
		@Mapping(expression = "java(oper != null ? oper.getOperation() : null)", target="OPERATION")
	})
	@InheritConfiguration
	public DEPFEEDETAILSAPIType mapToApi(FeeInquiryHdrJpe jpe, @Context CbsXmlApiOperation oper, @Context Map otherInfo);
	
	/*@Mappings({
		@Mapping(target = "effectDate", ignore = true),
	})*/
	@InheritInverseConfiguration(name = "mapFeeInquiryHdrToDEPFEEDETAILSAPIType")
	public FeeInquiryHdrJpe mapToJpe(DEPFEEDETAILSAPIType api, @MappingTarget FeeInquiryHdrJpe jpe);
	
}
