package com.silverlakesymmetri.cbs.dep.svc.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.mysema.query.types.EntityPath;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.context.CbsSessionContext;
import com.silverlakesymmetri.cbs.commons.jpa.util.CutEnvHelper;
import com.silverlakesymmetri.cbs.commons.jpa.util.JaxbDatetimeAdapter;
import com.silverlakesymmetri.cbs.commons.jpa.util.TechColumnsObject;
import com.silverlakesymmetri.cbs.commons.svc.AbstractBusinessService;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.BillTranHistInquiry;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.BillTranHistInquiryJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.QBillTranHistInquiryJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.TranDefJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.id.BillTranHistInquiryPk;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.id.TranDefPk;
import com.silverlakesymmetri.cbs.dep.jpa.util.DepBillsPaymentPrcHelper;
import com.silverlakesymmetri.cbs.dep.svc.BillTranHistInquiryService;

@Service
@Transactional
public class BillTranHistInquiryServiceImpl extends AbstractBusinessService<BillTranHistInquiry, BillTranHistInquiryJpe, BillTranHistInquiryPk> 
	implements BillTranHistInquiryService {

	@Autowired
	private CutEnvHelper cutEnvHelper;
	
	@Autowired
	private DepBillsPaymentPrcHelper depBillsPaymentPrcHelper;
	
	@Override
	protected BillTranHistInquiryPk getIdFromDataObjectInstance(BillTranHistInquiry dataObject) {
		return new BillTranHistInquiryPk(dataObject.getTranSeqNo());
	}

	@Override
	protected EntityPath<BillTranHistInquiryJpe> getEntityPath() {
		return QBillTranHistInquiryJpe.billTranHistInquiryJpe;
	}

	@Override
	public List<BillTranHistInquiry> query(int offset, int resultLimit, String groupBy, String order,
			Map<String, Object> filters) {
		List<BillTranHistInquiry> list = super.query(offset, resultLimit, groupBy, order, filters);
		
		Map tranCodes = new HashMap();
		for (BillTranHistInquiry bt : list) {
			if (StringUtils.isBlank(bt.getTranType())){
				continue;
			}
			if (tranCodes.containsKey(bt.getTranType())){
				TranDefJpe tranDef = (TranDefJpe) tranCodes.get(bt.getTranType());
				bt.setTranCode(tranDef.getTranCode());
				continue;
			}
			TranDefPk tranDefPk = new TranDefPk(bt.getTranType());
			TranDefJpe tranDef = dataService.find(TranDefJpe.class, tranDefPk);
			tranCodes.put(bt.getTranType(), tranDef);
			bt.setTranCode(tranDef.getTranCode());
		}
		return list;
	}

	@Override
	public List<BillTranHistInquiry> find(FindCriteria findCriteria, CbsHeader cbsHeader) {
		return super.find(findCriteria, cbsHeader);
	}

	@Override
	public BillTranHistInquiry getByPk(String publicKey, BillTranHistInquiry reference) {
		BillTranHistInquiry bdo = super.getByPk(publicKey, reference);
		
		TranDefPk tranDefPk = new TranDefPk(bdo.getTranType());
		TranDefJpe tranDefJpe = dataService.find(TranDefJpe.class, tranDefPk);
		bdo.setTranCode(tranDefJpe.getTranCode());
		
		return bdo;
	}

	@Override
	public BillTranHistInquiry processCheque(BillTranHistInquiry bdo) {
		CbsSessionContext sessionCtx = cbsRuntimeContextManager.getContext(CbsSessionContext.class);
		
		TechColumnsObject tc = new TechColumnsObject();
		tc.setCreatedBy(bdo.getCreatedBy());
		tc.setJournalDate(JaxbDatetimeAdapter.parseDate(bdo.getJournalDt()));
		tc.setJournalNo(bdo.getJournalNo());
		tc.setModifiedBy(bdo.getModifiedBy());
		tc.setOrg_id((int) sessionCtx.getOrgId());
		
		if (bdo.getReturnClearCheque().equalsIgnoreCase("R") || bdo.getReturnClearCheque().equalsIgnoreCase("C")) {
		  cutEnvHelper.setEnv(tc);
		  if (bdo.getReturnClearCheque().equalsIgnoreCase("R")) {
		  	depBillsPaymentPrcHelper.ccReturnCheque(bdo.getTranSeqNo(), bdo.getTranCode(), sessionCtx.getUserCode(), bdo.getInstCode());
		  } else if (bdo.getReturnClearCheque().equalsIgnoreCase("C")) {
			depBillsPaymentPrcHelper.ccClearCheque(bdo.getTranSeqNo(), sessionCtx.getUserCode(), bdo.getInstCode());
		  }
		}
		
		BillTranHistInquiryPk billTranHistInquiryPk = new BillTranHistInquiryPk(bdo.getTranSeqNo());
		BillTranHistInquiryJpe billTranHistInquiryJpe = dataService.find(BillTranHistInquiryJpe.class, billTranHistInquiryPk);

		return jaxbSdoHelper.wrap(billTranHistInquiryJpe, BillTranHistInquiry.class);
	}

}
