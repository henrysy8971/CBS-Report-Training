package com.silverlakesymmetri.cbs.dep.svc.mapper.decorator;

import java.util.List;
import java.util.Map;

import com.silverlakesymmetri.cbs.dep.svc.mapper.TranValidationFlagsMapper;
import com.silverlakesymmetri.cbs.dep.xmlapi.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

import com.silverlakesymmetri.cbs.commons.xmlapi.enums.CbsXmlApiOperation;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.DepFeeApplyJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.TdDepositTransactionJpe;
import com.silverlakesymmetri.cbs.dep.svc.mapper.TdDepositTransactionServiceMapper;
import com.silverlakesymmetri.cbs.dep.svc.mapper.mapping.DepFeeApplyToDEPFEEAPPLYINTypeMapper;
import com.silverlakesymmetri.cbs.dep.svc.mapper.mapping.DepTranOtherDataToDEPTRANOTHERDATATTypeMapper;
import com.silverlakesymmetri.cbs.dep.svc.mapper.mapping.ScDetailInToDEPFEEAPPLYDTLINTTypeMapper;
import com.silverlakesymmetri.cbs.dep.svc.mapper.mapping.TranValidationFlagsToDEPTRANVALIDATIONFLAGSTTypeMapper;

public abstract class TdDepositTransactionServiceDecorator implements TdDepositTransactionServiceMapper, TranValidationFlagsMapper {
	@Autowired
	@Qualifier("delegate")
	protected TdDepositTransactionServiceMapper delegate;
	
	@Autowired
	protected DepFeeApplyToDEPFEEAPPLYINTypeMapper feeApplyMapper;

	@Autowired
	protected ScDetailInToDEPFEEAPPLYDTLINTTypeMapper scDetailInMapper;
	
	@Autowired
	protected TranValidationFlagsToDEPTRANVALIDATIONFLAGSTTypeMapper tranValidationFlagsMapper;
	
	@Autowired
	protected DepTranOtherDataToDEPTRANOTHERDATATTypeMapper depTranOtherDataMapper;

	@Override
	public DEPTDPLACEMENTAPIType mapToApi(TdDepositTransactionJpe jpe, CbsXmlApiOperation oper, Map otherInfo) {
		DEPTDPLACEMENTAPIType req = delegate.mapToApi(jpe, oper, otherInfo);
		
		req.setCRSCAPPLYIN(mapFeeToApi(jpe.getDepFeeApplyList()));
		
		req.setSOURCEMODULE("DEP");
		req.setAUTOGENFEE("N");
		req.setTRANVALIDATIONFLAGS(mapValidationFlags(jpe, "N", "N", "N", "N", "N"));

		return req;
	}

	@Override
	public TdDepositTransactionJpe mapToJpe(DEPTDPLACEMENTAPIType api, TdDepositTransactionJpe jpe) {
		return jpe;
	}
	
	private DEPFEEAPPLYINType mapFeeToApi(List<DepFeeApplyJpe> jpe) {
		DEPFEEAPPLYINType feeApplyIn = null;
		for (DepFeeApplyJpe depFeeApply : jpe) {
			if (feeApplyIn == null) {
				feeApplyIn = feeApplyMapper.mapDepFeeApplyToDEPFEEAPPLYIN(depFeeApply);
				feeApplyIn.setSCDETAILIN(new DEPFEEAPPLYDTLINCOLLType());
				feeApplyIn.setRBTRANOTHERDATAIN(new DEPTRANOTHERDATACOLLType());
			}
			feeApplyIn.getSCDETAILIN().getDEPFEEAPPLYDTLINT()
					.add(scDetailInMapper.mapScDetailInToDEPFEEAPPLYDTLIN(depFeeApply.getScDetailIn()));
			feeApplyIn.getRBTRANOTHERDATAIN().getDEPTRANOTHERDATAT().add(depTranOtherDataMapper
					.mapTranValidationFlagsToDEPTRANVALIDATIONFLAGST(depFeeApply.getRbTranOtherData()));
			feeApplyIn.setTRANVALIDATIONFLAGS(tranValidationFlagsMapper
					.mapTranValidationFlagsToDEPTRANVALIDATIONFLAGST(depFeeApply.getTranValidationFlags()));
		}			
		return feeApplyIn;
	}
}
