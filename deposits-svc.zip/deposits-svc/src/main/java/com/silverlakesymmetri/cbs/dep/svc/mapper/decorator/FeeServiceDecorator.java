package com.silverlakesymmetri.cbs.dep.svc.mapper.decorator;

import org.springframework.beans.factory.annotation.Autowired;

import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.DepFeeApplyJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.ScDetailOutJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.type.FeeApplicable;
import com.silverlakesymmetri.cbs.dep.svc.mapper.mapping.DEPFEEAPPLYDTLOUTTTypeToScDetailOutMapper;
import com.silverlakesymmetri.cbs.dep.svc.mapper.mapping.DepFeeApplyToDEPFEEAPPLYINTypeMapper;
import com.silverlakesymmetri.cbs.dep.svc.mapper.mapping.DepTranOtherDataToDEPTRANOTHERDATATTypeMapper;
import com.silverlakesymmetri.cbs.dep.svc.mapper.mapping.ScDetailInToDEPFEEAPPLYDTLINTTypeMapper;
import com.silverlakesymmetri.cbs.dep.svc.mapper.mapping.TranValidationFlagsToDEPTRANVALIDATIONFLAGSTTypeMapper;
import com.silverlakesymmetri.cbs.dep.xmlapi.DEPFEEAPPLYDTLINCOLLType;
import com.silverlakesymmetri.cbs.dep.xmlapi.DEPFEEAPPLYDTLOUTTType;
import com.silverlakesymmetri.cbs.dep.xmlapi.DEPFEEAPPLYINType;
import com.silverlakesymmetri.cbs.dep.xmlapi.DEPTRANOTHERDATACOLLType;
import com.silverlakesymmetri.cbs.dep.xmlapi.FeeApplicableType;

public abstract class FeeServiceDecorator {

	@Autowired
	protected DepFeeApplyToDEPFEEAPPLYINTypeMapper feeApplyMapper;

	@Autowired
	protected ScDetailInToDEPFEEAPPLYDTLINTTypeMapper scDetailInMapper;

	@Autowired
	protected DepTranOtherDataToDEPTRANOTHERDATATTypeMapper depTranOtherDataMapper;

	@Autowired
	protected TranValidationFlagsToDEPTRANVALIDATIONFLAGSTTypeMapper tranValidationFlagsMapper;

	@Autowired
	protected DEPFEEAPPLYDTLOUTTTypeToScDetailOutMapper scDetailOutMapper;

	protected FeeApplicableType mapFeeToApi(FeeApplicable jpe, FeeApplicableType api) {
		DEPFEEAPPLYINType feeApplyIn = null;
		for (DepFeeApplyJpe depFeeApply : jpe.getDepFeeApplyList()) {
			if (feeApplyIn == null) {
				feeApplyIn = feeApplyMapper.mapDepFeeApplyToDEPFEEAPPLYIN(depFeeApply);
				feeApplyIn.setSCDETAILIN(new DEPFEEAPPLYDTLINCOLLType());
				feeApplyIn.setRBTRANOTHERDATAIN(new DEPTRANOTHERDATACOLLType());
			}
			feeApplyIn.getSCDETAILIN().getDEPFEEAPPLYDTLINT()
					.add(scDetailInMapper.mapScDetailInToDEPFEEAPPLYDTLIN(depFeeApply.getScDetailIn()));
			feeApplyIn.getRBTRANOTHERDATAIN().getDEPTRANOTHERDATAT().add(depTranOtherDataMapper
					.mapTranValidationFlagsToDEPTRANVALIDATIONFLAGST(depFeeApply.getRbTranOtherData()));
			feeApplyIn.setTRANVALIDATIONFLAGS(tranValidationFlagsMapper
					.mapTranValidationFlagsToDEPTRANVALIDATIONFLAGST(depFeeApply.getTranValidationFlags()));
		}
		api.setSCAPPLYIN(feeApplyIn);
		return api;
	}

	protected FeeApplicable mapFeeToJpe(FeeApplicableType api, FeeApplicable jpe) {
		if (api.getSCDETAILOUT() != null && api.getSCDETAILOUT().getDEPFEEAPPLYDTLOUTT().size() > 0) {
			for (int i = 0; i < api.getSCDETAILOUT().getDEPFEEAPPLYDTLOUTT().size(); i++) {
				DEPFEEAPPLYDTLOUTTType feeApplyOut = api.getSCDETAILOUT().getDEPFEEAPPLYDTLOUTT().get(i);
				ScDetailOutJpe scDetailOut = scDetailOutMapper.mapDEPFEEAPPLYDTLOUTTToScDetailOut(feeApplyOut);
				if (jpe.getDepFeeApplyList().get(i) != null) {
					jpe.getDepFeeApplyList().get(i).setScDetailOut(scDetailOut);
				}
			}
		}
		return jpe;
	}

}

