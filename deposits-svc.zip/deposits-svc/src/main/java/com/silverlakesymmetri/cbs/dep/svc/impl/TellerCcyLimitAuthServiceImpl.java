package com.silverlakesymmetri.cbs.dep.svc.impl;

import java.util.Arrays;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.mysema.query.types.EntityPath;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.logging.CbsAppLogger;
import com.silverlakesymmetri.cbs.commons.logging.annotation.Logger;
import com.silverlakesymmetri.cbs.commons.svc.AbstractBusinessService;
import com.silverlakesymmetri.cbs.commons.svc.BusinessObjectValidationCapable;
import com.silverlakesymmetri.cbs.commons.svc.CbsFileUploadCapable;
import com.silverlakesymmetri.cbs.commons.svc.util.FileUploadUtilImpl;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.TellerCcyLimitAuth;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.QTellerCcyLimitAuthJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.TellerCcyLimitAuthJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.id.TellerCcyLimitAuthPk;
import com.silverlakesymmetri.cbs.dep.svc.TellerCcyLimitAuthService;

@Service
@Transactional
public class TellerCcyLimitAuthServiceImpl
		extends AbstractBusinessService<TellerCcyLimitAuth, TellerCcyLimitAuthJpe, TellerCcyLimitAuthPk>
		implements TellerCcyLimitAuthService, BusinessObjectValidationCapable<TellerCcyLimitAuth>,
		CbsFileUploadCapable<TellerCcyLimitAuth> {

	@Logger
	CbsAppLogger logger;

	@SuppressWarnings("rawtypes")
	@Autowired
	private FileUploadUtilImpl fileUploadUtility;

	@Override
	protected EntityPath<TellerCcyLimitAuthJpe> getEntityPath() {
		return QTellerCcyLimitAuthJpe.tellerCcyLimitAuthJpe;
	}

	@Override
	protected TellerCcyLimitAuthPk getIdFromDataObjectInstance(TellerCcyLimitAuth dataObject) {
		return new TellerCcyLimitAuthPk(dataObject.getOfficerId(), dataObject.getCcy());
	}

	@Override
	public TellerCcyLimitAuth create(TellerCcyLimitAuth objectInstanceIdentifier) {
		return super.create(objectInstanceIdentifier);
	}

	@Override
	public List<TellerCcyLimitAuth> query(int offset, int resultLimit, String groupBy, String order,
			Map<String, Object> filters) {
		return super.query(offset, resultLimit, groupBy, order, filters);
	}

	@Override
	public TellerCcyLimitAuth update(TellerCcyLimitAuth dataObject) {
		return super.update(dataObject);
	}

	@Override
	public boolean delete(TellerCcyLimitAuth dataObject) {
		return super.delete(dataObject);
	}

	@Override
	public List<TellerCcyLimitAuth> find(FindCriteria findCriteria, CbsHeader cbsHeader) {
		return super.find(findCriteria, cbsHeader);
	}

	@Override
	public TellerCcyLimitAuth getByPk(String publicKey, TellerCcyLimitAuth reference) {
		return super.getByPk(publicKey, reference);
	}

	@Override
	public boolean bulkCreate(List<TellerCcyLimitAuth> bdoList) {
		validateBulkCreateList(bdoList);

		for (TellerCcyLimitAuth bdo : bdoList) {
			try {
				this.create(bdo);
			} catch (Exception e) {
				logger.error("Error encountered while processing jpe: {}", jaxbSdoHelper.unwrap(bdo), e);
				throw e;
			}
		}

		return true;
	}

	private void validateBulkCreateList(List<TellerCcyLimitAuth> bdoList) {
		isDuplicatesOnList(Arrays.asList("officerId", "ccy"), bdoList);
	}

	@SuppressWarnings("unchecked")
	@Override
	public boolean isDuplicatesOnList(List<String> uniqueKeys, List<TellerCcyLimitAuth> bdoList) {
		return fileUploadUtility.isDuplicatesOnList(uniqueKeys, bdoList);
	}

}
