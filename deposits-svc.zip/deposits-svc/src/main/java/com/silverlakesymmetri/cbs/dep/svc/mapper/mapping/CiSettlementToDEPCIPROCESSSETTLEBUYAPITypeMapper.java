package com.silverlakesymmetri.cbs.dep.svc.mapper.mapping;

import org.mapstruct.MapperConfig;
import org.mapstruct.Mapping;
import org.mapstruct.Mappings;

import com.silverlakesymmetri.cbs.commons.jpa.util.DateTimeHelper;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.CiSettlementJpe;
import com.silverlakesymmetri.cbs.dep.xmlapi.DEPCIPROCESSSETTLEBUYAPIType;

@MapperConfig(uses={ DateTimeHelper.class})
public interface CiSettlementToDEPCIPROCESSSETTLEBUYAPITypeMapper {
	
	@Mappings({ 
		@Mapping(source = "branch", target="TRANBRANCH"),
		@Mapping(source = "seqNo", target="SEQNO"),
		@Mapping(source = "realizedAmt", target="REALIZEDAMT"),
//		@Mapping(source = "quantity", target="CROSSRATE"),
//		@Mapping(source = "prefix", target="RATEREFERENCE")
	 })
	public DEPCIPROCESSSETTLEBUYAPIType mapCiSettlementToDEPCIPROCESSSETTLEBUYAPIType(CiSettlementJpe jpe);	
	

}

