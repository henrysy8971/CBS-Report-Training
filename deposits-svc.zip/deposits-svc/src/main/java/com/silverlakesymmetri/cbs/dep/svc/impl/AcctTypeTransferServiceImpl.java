package com.silverlakesymmetri.cbs.dep.svc.impl;

import java.util.List;
import java.util.Map;

import javax.persistence.NoResultException;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.google.common.collect.ImmutableMap;
import com.mysema.query.types.EntityPath;
import com.silverlakesymmetri.cbs.commons.svc.AbstractXmlApiBusinessService;
import com.silverlakesymmetri.cbs.commons.svc.BusinessObjectValidationCapable;
import com.silverlakesymmetri.cbs.commons.xmlapi.enums.CbsXmlApiOperation;
import com.silverlakesymmetri.cbs.csd.jpa.mapping.sdo.ProfitCentreJpe;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.AcctTypeChange;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.AcctJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.AcctTypeChangeJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.ProdDefaultJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.QAcctTypeChangeJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.id.AcctTypeChangePk;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.util.DepJpeConstants;
import com.silverlakesymmetri.cbs.dep.svc.AcctTypeTransferService;
import com.silverlakesymmetri.cbs.dep.svc.DepositsValidatorService;
import com.silverlakesymmetri.cbs.dep.svc.mapper.AcctTypeTransferServiceMapper;
import com.silverlakesymmetri.cbs.dep.xmlapi.DEPACCTTYPETFRAPIType;

/**
 * Created by Emerson.Sanchez on 7/5/2019.
 */
@Service
@Transactional
public class AcctTypeTransferServiceImpl extends AbstractXmlApiBusinessService<AcctTypeChange, AcctTypeChangeJpe,
        AcctTypeChangePk, DEPACCTTYPETFRAPIType, DEPACCTTYPETFRAPIType> implements AcctTypeTransferService,
        BusinessObjectValidationCapable<AcctTypeChange> {
    private final static String DEP_ACCT_TYPE_CHANGE_SEQ = "DEP_ACCT_TYPE_CHANGE_S";

    @Autowired
    private AcctTypeTransferServiceMapper mapper;
    
    @Autowired
    DepositsValidatorService depositsValidatorService;

    @Override
    protected AcctTypeChangePk getIdFromDataObjectInstance(AcctTypeChange dataObject) {
        AcctTypeChangeJpe jpe = jaxbSdoHelper.unwrap(dataObject, AcctTypeChangeJpe.class);
        return new AcctTypeChangePk(jpe.getInternalKey(), jpe.getSeqNo());
    }

    @Override
    protected EntityPath<AcctTypeChangeJpe> getEntityPath() {
        return QAcctTypeChangeJpe.acctTypeChangeJpe;
    }

    @Override
    public AcctTypeChange getByPk(String publicKey, AcctTypeChange reference) {
        AcctTypeChange acctTypeChange = null;
        String acctNo = publicKey;
        boolean hasCorrectPublicKey = false;
        if (publicKey.contains("~")) {
            String[] keys = publicKey.split("~");
            acctNo = keys[0];
            hasCorrectPublicKey = true;
        }

        Map<String, Object> params = new ImmutableMap.Builder<String, Object>().put("acctNo", acctNo).build();
        AcctJpe acct = dataService.getWithNamedQuery(DepJpeConstants.ACCT_JPE_FIND_BY_ACCTNO, params,
                AcctJpe.class);
        params = new ImmutableMap.Builder<String, Object>().put("internalKey", acct.getInternalKey()).build();

        if(hasCorrectPublicKey) {
            acctTypeChange = super.getByPk(publicKey, reference);
        } else {
            try {
                AcctTypeChangeJpe acctTypeChangeJpe = dataService.getWithNamedQuery(DepJpeConstants.
                        ACCT_TYPE_CHANGE_JPE_FIND_BY_INTERNAL_KEY, params, AcctTypeChangeJpe.class);
                acctTypeChange = jaxbSdoHelper.wrap(acctTypeChangeJpe);
            } catch (NoResultException e){}
        }
        if (acctTypeChange == null) {
            acctTypeChange = jaxbSdoHelper.createSdoInstance(AcctTypeChange.class);
            acctTypeChange.setOldAcctType(acct.getAcctType());
            acctTypeChange.setAcctNo(acct.getAcctNo());
            if (acct.getProfitCentre() != null) {
                ProfitCentreJpe profitCentreJpe = this.dataService.find(ProfitCentreJpe.class, acct.getProfitCentre());
                if (profitCentreJpe != null) {
                    acctTypeChange.setOldProfitCentre(profitCentreJpe.getProfitCentre());
                }
            }

            ProdDefaultJpe prodDefaultJpe = this.dataService.find(ProdDefaultJpe.class, acct.getAcctType());
            if (prodDefaultJpe != null) {
                acctTypeChange.setOldTaxType(prodDefaultJpe.getCrTaxType());
            }
        }
        return acctTypeChange;
    } 

    /*@Override
    public AcctTypeChange create(AcctTypeChange dataObject) {
        Map<String, Object> params = new ImmutableMap.Builder<String, Object>().put("acctNo", dataObject.getAcctNo())
                .build();
        AcctJpe acct = dataService.getWithNamedQuery(DepJpeConstants.ACCT_JPE_FIND_BY_ACCTNO, params,
                AcctJpe.class);
        dataObject.setInternalKey(acct.getInternalKey());
        return super.create(dataObject);
    }*/

    @Override
	public List<AcctTypeChange> query(int offset, int resultLimit, String groupBy, String order,
			Map<String, Object> filters) {
		return super.query(offset, resultLimit, groupBy, order, filters);
	}

	@Override
    protected AcctTypeChange preCreateValidation(AcctTypeChange dataObject) {
        AcctTypeChangeJpe jpe = jaxbSdoHelper.unwrap(dataObject, AcctTypeChangeJpe.class);
        if(jpe.getSeqNo() == null){
            long mainSeqNo = dataService.nextSequenceValue(DEP_ACCT_TYPE_CHANGE_SEQ).longValue();
            jpe.setSeqNo(mainSeqNo);
            dataObject.setSeqNo(mainSeqNo);
        }
        Map<String, Object> params = new ImmutableMap.Builder<String, Object>().put("acctNo", dataObject.getAcctNo())
                .build();
        AcctJpe acct = dataService.getWithNamedQuery(DepJpeConstants.ACCT_JPE_FIND_BY_ACCTNO, params,
                AcctJpe.class);

        jpe.setInternalKey(acct.getInternalKey());

        if (StringUtils.isBlank(jpe.getOldAcctType())){
            jpe.setOldAcctType(acct.getAcctType());
        }
        if (StringUtils.isBlank(jpe.getOldProfitCentre())){
            jpe.setOldProfitCentre(acct.getProfitCentre());
        }
        if (StringUtils.isBlank(jpe.getOldTaxType())){
            if (acct.getIntDetailRec() != null){
                jpe.setOldTaxType(acct.getIntDetailRec().getCrTaxType());
            }
        }

        dataObject = wrap(jpe);
        return super.preCreateValidation(dataObject);
    }

    /*@Override
    public AcctTypeChange update(AcctTypeChange dataObject) {
        return super.update(dataObject);
    }*/

    @Override
    protected DEPACCTTYPETFRAPIType transformBdoToXmlApiRqCreate(AcctTypeChange dataObject) {
        return tranformBDOToAPIType(dataObject, CbsXmlApiOperation.INSERT);
    }

    @Override
    protected DEPACCTTYPETFRAPIType transformBdoToXmlApiRqUpdate(AcctTypeChange dataObject) {
        return tranformBDOToAPIType(dataObject, CbsXmlApiOperation.UPDATE);
    }

    @Override
    protected DEPACCTTYPETFRAPIType transformBdoToXmlApiRqDelete(AcctTypeChange dataObject) {
        return tranformBDOToAPIType(dataObject, CbsXmlApiOperation.DELETE);
    }

    private DEPACCTTYPETFRAPIType tranformBDOToAPIType(AcctTypeChange bdo, CbsXmlApiOperation operation) {
        DEPACCTTYPETFRAPIType apiType = new DEPACCTTYPETFRAPIType();
        AcctTypeChangeJpe jpe = jaxbSdoHelper.unwrap(bdo, AcctTypeChangeJpe.class);
        apiType = mapper.mapToApi(jpe, operation);
        if (bdo.getEffectDate() != null) {
        	apiType.setEFFECTDATE(dateTimeHelper.convertToCbsXmlApiDate(bdo.getEffectDate()));
        }
        super.setTechColsFromDataObject(bdo, apiType);
        return apiType;
    }

    @Override
    protected AcctTypeChange processXmlApiRs(AcctTypeChange dataObject, DEPACCTTYPETFRAPIType depaccttypetfrapiType) {
        return dataObject;
    }

    @Override
    protected List<AcctTypeChange> processXmlApiListRs(AcctTypeChange dataObject, DEPACCTTYPETFRAPIType depaccttypetfrapiType) {
        return null;
    }

    @Override
    protected Class<DEPACCTTYPETFRAPIType> getXmlApiResponseClass() {
        return DEPACCTTYPETFRAPIType.class;
    }
    
    public AcctTypeChange validateCreateRequest(AcctTypeChange dataObject) {
    	
    	String returnCode = depositsValidatorService.isAcctTypeTransferAllowedByAcctTypes(getCurrAcctType(dataObject), dataObject.getNewAcctType());
    	return super.validateCreateRequest(dataObject);
    }
    
    public AcctTypeChange validateUpdateRequest(AcctTypeChange dataObject) {
    	
    	String returnCode = depositsValidatorService.isAcctTypeTransferAllowedByAcctTypes(getCurrAcctType(dataObject), dataObject.getNewAcctType());
    	return super.validateUpdateRequest(dataObject);
    }

    private String getCurrAcctType(AcctTypeChange dataObject){

        if (!StringUtils.isBlank(dataObject.getOldAcctType())){
            return dataObject.getOldAcctType();
        }

        Map<String, Object> params = new ImmutableMap.Builder<String, Object>().put("acctNo", dataObject.getAcctNo())
                .build();
        AcctJpe acct = dataService.getWithNamedQuery(DepJpeConstants.ACCT_JPE_FIND_BY_ACCTNO, params,
                AcctJpe.class);

        return acct.getAcctType();
    }
}
