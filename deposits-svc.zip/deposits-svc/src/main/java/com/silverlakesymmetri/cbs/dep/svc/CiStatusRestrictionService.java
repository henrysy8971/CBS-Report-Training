package com.silverlakesymmetri.cbs.dep.svc;

import java.util.List;
import java.util.Map;

import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation;
import com.silverlakesymmetri.cbs.commons.svc.BusinessService;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.CiStatusRestriction;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.CiStatusRestrictionJpe;

public interface CiStatusRestrictionService extends BusinessService<CiStatusRestriction, CiStatusRestrictionJpe> {

	String SVC_OP_NAME_CISTATUSRESTRICTIONSERVICE_QUERY = "CiStatusRestrictionService.query";

    @ServiceOperation(name = SVC_OP_NAME_CISTATUSRESTRICTIONSERVICE_QUERY)
    List<CiStatusRestriction> query(int offset, int resultLimit, String groupBy, String order, Map<String, Object> filters);
}
