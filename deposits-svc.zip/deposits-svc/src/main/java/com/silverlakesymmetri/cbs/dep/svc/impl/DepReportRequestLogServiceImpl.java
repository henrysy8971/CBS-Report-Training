package com.silverlakesymmetri.cbs.dep.svc.impl;

import java.io.IOException;
import java.io.InputStream;
import java.util.*;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.mysema.query.types.EntityPath;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.bdo.sdo.ReportRequestLog;
import com.silverlakesymmetri.cbs.commons.constants.ReportConstants;
import com.silverlakesymmetri.cbs.commons.context.CbsSessionContext;
import com.silverlakesymmetri.cbs.commons.jpa.mapping.sdo.QReportRequestLogJpe;
import com.silverlakesymmetri.cbs.commons.jpa.mapping.sdo.RegistryJpe;
import com.silverlakesymmetri.cbs.commons.jpa.mapping.sdo.ReportRequestLogJpe;
import com.silverlakesymmetri.cbs.commons.jpa.mapping.sdo.id.ReportRequestLogPk;
import com.silverlakesymmetri.cbs.commons.svc.AbstractReportRequestLogService;
import com.silverlakesymmetri.cbs.dep.svc.DepReportRequestLogService;

@Service
@Transactional
public class DepReportRequestLogServiceImpl extends AbstractReportRequestLogService<ReportRequestLog, ReportRequestLogJpe, ReportRequestLogPk> implements DepReportRequestLogService {


	@Override
	protected ReportRequestLogPk getIdFromDataObjectInstance(ReportRequestLog dataObject) {
		ReportRequestLogPk id = new ReportRequestLogPk(dataObject.getReportId(), dataObject.getRequestedBy(), dateHelper.getDate(dataObject.getRequestDate()));
		return id;
	}

	@Override
	protected EntityPath<ReportRequestLogJpe> getEntityPath() {
		return QReportRequestLogJpe.reportRequestLogJpe;
	}

	@Override
    public ReportRequestLog getByPk(String publicKey, ReportRequestLog reference) {
    	return super.getByPk(publicKey, reference);
    }

	@Override
    public ReportRequestLog create(ReportRequestLog dataObject) {
		return super.create(dataObject);
    }

	@Override
    public ReportRequestLog update(ReportRequestLog dataObject) {
		return super.update(dataObject);
    }

	@Override
    public boolean delete(ReportRequestLog dataObject) {
		return super.delete(dataObject);
    }

	@Override
    public List<ReportRequestLog> query(int offset, int resultLimit, String groupBy, String order, Map<String, Object> filters){
		return super.query(offset, resultLimit, groupBy, order, filters);
    }

	@Override
    public List<ReportRequestLog> find(FindCriteria findCriteria, CbsHeader cbsHeader){
		return super.find(findCriteria, cbsHeader);
    }

	@Override
    public InputStream getReportStream(String screenPath) {
    	return getClass().getClassLoader().getResourceAsStream(screenPath);
    }
	
	@Override
	public void addModuleRelatedParameters(Map<String, Object> reportParams) {
		Map<String, RegistryJpe> registries = registryService.getMapByMetaCodeModuleCode("CSD", "CORE_REGISTRY");
		if(registries != null && registries.size() > 0) {
			RegistryJpe reg = registries.get("localCcy");
			if(reg != null) {
				reportParams.put(ReportConstants.LOCAL_CCY, reg.getValue());
			}
			reg = registries.get("ccyBase");
			if(reg != null) {
				reportParams.put(ReportConstants.BASE_CCY, reg.getValue());
			}
		}

        Locale locale = (Locale) reportParams.get(ReportConstants.REPORT_LOCALE);
        ResourceBundle bundle = ResourceBundle.getBundle(ReportConstants.DEP_RESOURCE_BUNDLE_LOCATION, locale);
		if(Boolean.TRUE.equals(reportParams.get("isIslamicUserSession")) && sessionCtx.isIslamicConfigOn()){
			bundle = ResourceBundle.getBundle(ReportConstants.DEP_ISL_RESOURCE_BUNDLE_LOCATION, locale);
		}
        reportParams.put(ReportConstants.REPORT_RESOURCE_BUNDLE, bundle);

        Properties prop = new Properties();
        try {
            prop.load(this.getClass().getClassLoader().getResourceAsStream("message/ScaDepMsgBundle"+getLocaleExtension(locale)+".properties"));
            Properties scaCut = new Properties();
            scaCut.load(this.getClass().getClassLoader().getResourceAsStream("message/ScaCutMsgBundle"+getLocaleExtension(locale)+".properties"));
            Properties scaCore = new Properties();
            scaCore.load(this.getClass().getClassLoader().getResourceAsStream("message/ScaCoreMsgBundle"+getLocaleExtension(locale)+".properties"));
            Properties scaCsd = new Properties();
            scaCsd.load(this.getClass().getClassLoader().getResourceAsStream("message/ScaCsdMsgBundle"+getLocaleExtension(locale)+".properties"));
            Properties scaMcl = new Properties();
            scaMcl.load(this.getClass().getClassLoader().getResourceAsStream("message/ScaMclMsgBundle"+getLocaleExtension(locale)+".properties"));
            Properties scaPim = new Properties();
            scaPim.load(this.getClass().getClassLoader().getResourceAsStream("message/ScaPimMsgBundle"+getLocaleExtension(locale)+".properties"));
            Properties scaGla = new Properties();
            scaGla.load(this.getClass().getClassLoader().getResourceAsStream("message/ScaGlaMsgBundle"+getLocaleExtension(locale)+".properties"));
            Properties scaLpm = new Properties();
            scaLpm.load(this.getClass().getClassLoader().getResourceAsStream("message/ScaLpmMsgBundle"+getLocaleExtension(locale)+".properties"));
            Properties scaSwf = new Properties();
            scaSwf.load(this.getClass().getClassLoader().getResourceAsStream("message/ScaSwfMsgBundle"+getLocaleExtension(locale)+".properties"));
            Properties scaXps = new Properties();
            scaXps.load(this.getClass().getClassLoader().getResourceAsStream("message/ScaXpsMsgBundle"+getLocaleExtension(locale)+".properties"));
            Properties scaCol = new Properties();
            scaCol.load(this.getClass().getClassLoader().getResourceAsStream("message/ScaColMsgBundle"+getLocaleExtension(locale)+".properties"));
            Properties scaLmt = new Properties();
            scaLmt.load(this.getClass().getClassLoader().getResourceAsStream("message/ScaLmtMsgBundle"+getLocaleExtension(locale)+".properties"));

            prop.putAll(scaCut);
            prop.putAll(scaCore);
            prop.putAll(scaCsd);
            prop.putAll(scaMcl);
            prop.putAll(scaPim);
            prop.putAll(scaGla);
            prop.putAll(scaLpm);
            prop.putAll(scaSwf);
            prop.putAll(scaXps);
            prop.putAll(scaCol);
            prop.putAll(scaLmt);
        } catch (IOException e) {}
        reportParams.put(ReportConstants.ERROR_MESSAGE_PROPERTY, prop);
	}

	@Override
	public String getModuleCode() {
		return "DEP";
	}

	@Override
	public ReportRequestLog start(Map<String, Object> params) {
		return super.start(params);
	}

	@Override
	public ReportRequestLog createRequest(Map<String, Object> params) {
		return super.generate(params);
	}

}
