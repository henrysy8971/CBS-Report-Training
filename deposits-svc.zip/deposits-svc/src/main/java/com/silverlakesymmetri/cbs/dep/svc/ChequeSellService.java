package com.silverlakesymmetri.cbs.dep.svc;

import java.util.List;
import java.util.Map;

import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation;
import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation.ServiceOperationType;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.svc.BusinessService;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.ChqSell;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.ChqSellJpe;

public interface ChequeSellService extends BusinessService<ChqSell, ChqSellJpe> {
	public static final String SVC_OP_NAME_CHEQUESELLSERVICE_GET= "ChequeSellService.get";
	public static final String SVC_OP_NAME_CHEQUESELLSERVICE_QUERY= "ChequeSellService.query";
	public static final String SVC_OP_NAME_CHEQUESELLSERVICE_FIND= "ChequeSellService.find";
	public static final String SVC_OP_NAME_CHEQUESELLSERVICE_CREATE= "ChequeSellService.create";
	public static final String SVC_OP_NAME_CHEQUESELLSERVICE_UPDATE= "ChequeSellService.update";
	public static final String SVC_OP_NAME_CHEQUESELLSERVICE_DELETE= "ChequeSellService.delete";
	public static final String SVC_OP_NAME_CHEQUESELLSERVICE_COUNT = "ChequeSellService.count";
	
    @ServiceOperation(name = SVC_OP_NAME_CHEQUESELLSERVICE_QUERY)
    public List<ChqSell> query(int offset, int resultLimit, String groupBy, String order, Map<String, Object> filters);

    @ServiceOperation(name = SVC_OP_NAME_CHEQUESELLSERVICE_FIND)
    public List<ChqSell> find(FindCriteria findCriteria, CbsHeader cbsHeader);

    @ServiceOperation(name = SVC_OP_NAME_CHEQUESELLSERVICE_GET, type = ServiceOperationType.GET)
    public ChqSell getByPk(String publicKey, ChqSell reference);
    
    @ServiceOperation(name = SVC_OP_NAME_CHEQUESELLSERVICE_CREATE)
    public ChqSell create(ChqSell dataObject);
    
    @ServiceOperation(name = SVC_OP_NAME_CHEQUESELLSERVICE_COUNT, type = ServiceOperationType.GET)
	public Long count(FindCriteria findCriteria, CbsHeader cbsHeader);
    
}
