package com.silverlakesymmetri.cbs.dep.svc;

import java.util.List;
import java.util.Map;

import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation;
import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation.ServiceOperationType;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.svc.BusinessService;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.IntDetail;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.IntDetailJpe;


public interface IntDetailService extends BusinessService<IntDetail, IntDetailJpe> {

    public static final String SVC_OP_NAME_INTDETAIL_GET = "IntDetailService.get";
    public static final String SVC_OP_NAME_INTDETAIL_CREATE = "IntDetailService.create";
    public static final String SVC_OP_NAME_INTDETAIL_UPDATE = "IntDetailService.update";
    public static final String SVC_OP_NAME_INTDETAIL_DELETE = "IntDetailService.delete";
    public static final String SVC_OP_NAME_INTDETAIL_QUERY = "IntDetailService.query";
    public static final String SVC_OP_NAME_INTDETAIL_FIND = "IntDetailService.find";

    @ServiceOperation(name = SVC_OP_NAME_INTDETAIL_GET, type = ServiceOperationType.GET)
    public IntDetail getByPk(String publicKey, IntDetail reference);
    
//    @ServiceOperation(name = SVC_OP_NAME_INTDETAIL_CREATE)
//    public IntDetail create(IntDetail objectInstanceIdentifier);
//    
//    @ServiceOperation(name = SVC_OP_NAME_INTDETAIL_UPDATE)
//    public IntDetail update(IntDetail objectInstanceIdentifier);
//    
//    @ServiceOperation(name = SVC_OP_NAME_INTDETAIL_DELETE)
//    public boolean delete(IntDetail objectInstanceIdentifier);
    
    @ServiceOperation(name = SVC_OP_NAME_INTDETAIL_QUERY)
    public List<IntDetail> query(int offset, int resultLimit, String groupBy, String order, Map<String, Object> filters);

    @ServiceOperation(name = SVC_OP_NAME_INTDETAIL_FIND)
    public List<IntDetail> find(FindCriteria findCriteria, CbsHeader cbsHeader);


}
