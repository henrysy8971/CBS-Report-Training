package com.silverlakesymmetri.cbs.dep.svc.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mysema.query.types.EntityPath;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.context.CbsSessionContext;
import com.silverlakesymmetri.cbs.commons.exception.CbsRuntimeException;
import com.silverlakesymmetri.cbs.commons.jpa.entity.FindCriteriaJpe;
import com.silverlakesymmetri.cbs.commons.logging.CbsAppLogger;
import com.silverlakesymmetri.cbs.commons.logging.CbsAppLoggerFactory;
import com.silverlakesymmetri.cbs.commons.svc.AbstractXmlApiBusinessService;
import com.silverlakesymmetri.cbs.commons.svc.BusinessObjectValidationCapable;
import com.silverlakesymmetri.cbs.commons.xmlapi.enums.CbsXmlApiOperation;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.ChqSell;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.ChqSellDdBnk;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.ChqSellTran;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.ChqSellDdBnkJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.ChqSellJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.ChqSellTranJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.QChqSellJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.id.ChqSellPk;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.util.DepJpeConstants;
import com.silverlakesymmetri.cbs.dep.svc.ChequeSellService;
import com.silverlakesymmetri.cbs.dep.svc.mapper.mapping.ChqSellToDEPCHEQUESELLAPITypeMapper;
import com.silverlakesymmetri.cbs.dep.svc.mapper.mapping.DEPCHQBUYSELLPYMTOUTTTypeToChqSellTranMapper;
import com.silverlakesymmetri.cbs.dep.xmlapi.DEPCHEQUESELLAPIType;
import com.silverlakesymmetri.cbs.dep.xmlapi.DEPCHQBUYSELLOUTTType;
import com.silverlakesymmetri.cbs.dep.xmlapi.DEPCHQBUYSELLPYMTOUTTType;

@Service
public class ChequeSellServiceImpl extends AbstractXmlApiBusinessService<ChqSell, ChqSellJpe, ChqSellPk, DEPCHEQUESELLAPIType, DEPCHEQUESELLAPIType> implements ChequeSellService, BusinessObjectValidationCapable<ChqSell> {
	
	private static final String INTERNAL_KEY = "internalKey";
	private static final String ACCT_NO = "acctNo";
	private static final String CBS_CHANNEL_SOURCE = "HTTP-UI";
	private static final String DEP_CI_GRP_SEQ_NO = "DEP_CI_GRP_SEQ_NO_S";
	
	private static CbsAppLogger logger = CbsAppLoggerFactory.getLogger(ChequeSellServiceImpl.class.getName());
	
	@Autowired
	private ChqSellToDEPCHEQUESELLAPITypeMapper mapper;

	@Autowired
	private DEPCHQBUYSELLPYMTOUTTTypeToChqSellTranMapper sellTranMapper;
	
	@Override
	public ChqSell getByPk(String publicKey, ChqSell reference) {
		return super.getByPk(publicKey, reference);
	}
	
	@Override
	protected EntityPath<ChqSellJpe> getEntityPath() {
		return QChqSellJpe.chqSellJpe;
	}
	
	@Override
	protected ChqSellPk getIdFromDataObjectInstance(ChqSell dataObject) {
		return new ChqSellPk(dataObject.getGrpCiSeqNoSell());
	}
	
	@Override
	public List<ChqSell> query(int offset, int resultLimit, String groupBy, String order,
			Map<String, Object> filters) {
		
		if(filters.containsKey(ACCT_NO)){			
			Map<String, Object> params = new HashMap<String, Object>();
			params.put(ACCT_NO, filters.get(ACCT_NO));
			Long result = dataService.getWithNamedQuery(DepJpeConstants.ACCT_JPE_FIND_INTERNAL_KEY_BY_ACCT_NO, params, Long.class);
			
			filters.remove(ACCT_NO);
			filters.put(INTERNAL_KEY, result);
		}
		
		return super.query(offset, resultLimit, groupBy, order, filters);
	}
	
	@Override
	public List<ChqSell> find(FindCriteria findCriteria, CbsHeader cbsHeader) {
		return super.find(findCriteria, cbsHeader);
	}
	
	@Override
	public ChqSell create(ChqSell dataObject) {
		return super.create(dataObject);
	}
	
	@Override
	public Long count(FindCriteria findCriteria, CbsHeader cbsHeader) {
		return dataService.getRowCount(ChqSellJpe.class, new FindCriteriaJpe());
	}
	
	@Override
	protected Class<DEPCHEQUESELLAPIType> getXmlApiResponseClass() {
		return DEPCHEQUESELLAPIType.class;
	}
	
	@Override
	protected List<ChqSell> processXmlApiListRs(ChqSell dataObject, DEPCHEQUESELLAPIType xmlApiRs) {
		return null;
	}
	
	@Override
	protected ChqSell processXmlApiRs(ChqSell dataObject, DEPCHEQUESELLAPIType xmlApiRs) {
		Double segNo = xmlApiRs.getGRPCISEQNO();
		dataObject.setGrpCiSeqNoSell(segNo.longValue());
		
		ChqSellJpe jpe = jaxbSdoHelper.unwrap(dataObject);
		List<ChqSellTranJpe> origChqSellTranList = jpe.getChqSellTranList();
		jpe.setChqSellTranList(new ArrayList<>());
		
		for (DEPCHQBUYSELLOUTTType xmlApiRec: xmlApiRs.getRBCHEQUESELLOUTDTLS().getDEPCHQBUYSELLOUTT()) {
			for (ChqSellDdBnkJpe chqSellDdBnkRec: jpe.getChqSellDdBnkList()) {
				if (xmlApiRec.getPOSITION() == chqSellDdBnkRec.getPosition().doubleValue()) {
					chqSellDdBnkRec.setStartChequeNo(new Double(xmlApiRec.getSTARTCHEQUE()).longValue());
					chqSellDdBnkRec.setEndChequeNo(new Double(xmlApiRec.getENDCHEQUE()).longValue());
					chqSellDdBnkRec.setStartSeq(new Double(xmlApiRec.getSTARTSEQ()).longValue());
					chqSellDdBnkRec.setEndSeq(new Double(xmlApiRec.getENDSEQ()).longValue());
				}
			}
			
			for (ChqSellDdBnkJpe tcRec: jpe.getChqSellTcList()) {
				if (xmlApiRec.getPOSITION() == tcRec.getPosition().doubleValue()) {
					tcRec.setStartChequeNo(new Double(xmlApiRec.getSTARTCHEQUE()).longValue());
					tcRec.setEndChequeNo(new Double(xmlApiRec.getENDCHEQUE()).longValue());
				}
			}
		}

		for (DEPCHQBUYSELLPYMTOUTTType xmlApiRec: xmlApiRs.getRBCHEQUESELLPYMTOUTDTLS().getDEPCHQBUYSELLPYMTOUTT()) {
			ChqSellTranJpe chqSellTranRs = sellTranMapper.apiTypeToJpe(xmlApiRec);
			if(chqSellTranRs.getTranSeqNo() != null && chqSellTranRs.getTranSeqNo().longValue() > 0){
				if(origChqSellTranList != null && origChqSellTranList.size() > 0){
					for(ChqSellTranJpe chqSellTranRq : origChqSellTranList){
						if (chqSellTranRq.getAcctNo() != null) {
							if (chqSellTranRq.getAcctNo().equals(chqSellTranRs.getAcctNo())) {
								chqSellTranRs.setVirtualAttributeList(chqSellTranRq.getVirtualAttributeList());
								break;
							}
						}
					}
				}
				jpe.getChqSellTranList().add(chqSellTranRs);
			}
		}
		
		return jaxbSdoHelper.wrap(jpe);
	}
	
	@Override
	protected DEPCHEQUESELLAPIType transformBdoToXmlApiRqCreate(ChqSell dataObject) {
		return transformChqSellToDEPCHEQUESELLAPIType(dataObject, CbsXmlApiOperation.INSERT);
	}

	@Override
	protected DEPCHEQUESELLAPIType transformBdoToXmlApiRqDelete(ChqSell dataObject) {
		return null;
	}

	@Override
	protected DEPCHEQUESELLAPIType transformBdoToXmlApiRqUpdate(ChqSell dataObject) {
		return null;
	}
	
	private DEPCHEQUESELLAPIType transformChqSellToDEPCHEQUESELLAPIType(ChqSell dataObject, CbsXmlApiOperation oper){
		ChqSellJpe jpe = jaxbSdoHelper.unwrap(dataObject);
		DEPCHEQUESELLAPIType api =  mapper.jpeToApiType(jpe);
		super.setTechColsFromDataObject(dataObject, api);
		api.setOPERATION(oper.getOperation());
		
        CbsSessionContext sessionCtx = cbsRuntimeContextManager.getContext(CbsSessionContext.class);
        String branch = sessionCtx.getBranch();
        
        if (sessionCtx.getChannelSource().equals(CBS_CHANNEL_SOURCE)) {
        	api.setTRANBRANCH((String) branch);
		} else {
			api.setTRANBRANCH(jpe.getBranch());
		}
		
	    if (dataObject.getChqSellApplicantDetailsRec()!=null){
	    	if (dataObject.getChqSellApplicantDetailsRec().getCollectionMode()!=null){
	    		api.setCOLLECTMODE(dataObject.getChqSellApplicantDetailsRec().getCollectionMode());
	    	}	    	
	    	if (dataObject.getChqSellApplicantDetailsRec().getCollectionBranch()!=null){
	    		api.setCOLLECTBRANCH(dataObject.getChqSellApplicantDetailsRec().getCollectionBranch());
	    	} else {
	    		if (sessionCtx.getChannelSource().equals(CBS_CHANNEL_SOURCE)) {
	    			api.setCOLLECTBRANCH(branch);
	    		} else {
	    			api.setCOLLECTBRANCH(jpe.getBranch());
	    		}
	    	}
	    } else {
	    	if (sessionCtx.getChannelSource().equals(CBS_CHANNEL_SOURCE)) {
	    		api.setCOLLECTBRANCH(branch);
	    	} else {
	    		api.setCOLLECTBRANCH(jpe.getBranch());
	    	}
	    }

		return api;
	}

	@Override
	protected ChqSell preCreateValidation(ChqSell dataObject) {
		long mainSeqNo = dataService.nextSequenceValue(DEP_CI_GRP_SEQ_NO).longValue();
		dataObject.setGrpCiSeqNoSell(mainSeqNo);

		if (dataObject.getChqSellApplicantDetailsRec() != null) {
			dataObject.getChqSellApplicantDetailsRec().setGrpCiSeqNoSell(mainSeqNo);
		}

		if (dataObject.getChqSellCollectionDetailsRec() != null) {
			dataObject.getChqSellCollectionDetailsRec().setGrpCiSeqNoSell(mainSeqNo);
		}

		for (ChqSellDdBnk ddBnkRec : dataObject.getChqSellTcList()) {
			ddBnkRec.setGrpCiSeqNoSell(mainSeqNo);
		}

		for (ChqSellDdBnk ddBnkRec : dataObject.getChqSellDdBnkList()) {
			ddBnkRec.setGrpCiSeqNoSell(mainSeqNo);
		}

		for (ChqSellTran sellTranRec : dataObject.getChqSellTranList()) {
			sellTranRec.setGrpCiSeqNoSell(mainSeqNo);
		}

		if (dataObject.getChqSellScDtlsRec() != null) {
			dataObject.getChqSellScDtlsRec().setGrpCiSeqNoSell(mainSeqNo);
		}

		return super.preCreateValidation(dataObject);
	}

	@Override
	public void validateApiRequest(ChqSell dataObject, DEPCHEQUESELLAPIType xmlApiRq) {
        try {
            String xmlApiReq = removeModifiedByAndModifiedDt(convertXmlApiRqToString(xmlApiRq));
            String xmlHeaderIn = convertXmlApiRqToString(createHeaderFromDataObject(dataObject));
            validate(dataObject, xmlApiReq, xmlHeaderIn);
        } catch (CbsRuntimeException cre) {
            throw cre;
        } catch (Exception e) {
            logger.error("Unhandled error encountered: {}", e.getMessage(), e);
            throw new RuntimeException(e);
        }
    }

}
