package com.silverlakesymmetri.cbs.dep.svc.mapper;

import java.util.Map;

import org.mapstruct.Context;
import org.mapstruct.DecoratedWith;
import org.mapstruct.InheritConfiguration;
import org.mapstruct.InheritInverseConfiguration;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingTarget;
import org.mapstruct.Mappings;

import com.silverlakesymmetri.cbs.commons.jpa.util.DateTimeHelper;
import com.silverlakesymmetri.cbs.commons.xmlapi.enums.CbsXmlApiOperation;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.CiRdRegJpe;
import com.silverlakesymmetri.cbs.dep.svc.mapper.decorator.ChequeRegistrationServiceDecorator;
import com.silverlakesymmetri.cbs.dep.svc.mapper.mapping.CiRdRegToDEPCIRDAPITypeMapper;
import com.silverlakesymmetri.cbs.dep.xmlapi.DEPCIRDAPIType;

@Mapper(config=CiRdRegToDEPCIRDAPITypeMapper.class, uses={ DateTimeHelper.class})
@DecoratedWith(ChequeRegistrationServiceDecorator.class)
public interface ChequeRegistrationServiceMapper{
	
//	public  static final String BRANCH = "BRANCH";
	@Mappings({
		 @Mapping(expression = "java(oper != null ? oper.getOperation() : null)", target="OPERATION")
	 })
	@Mapping(source = "regDate", target="REGDATE", qualifiedByName = {"DateTimeHelper","convertDateToCbsXmlApiDate"})
	@InheritInverseConfiguration(name = "mapDEPCIRDAPITypeToCiRdRegJpe")
	public DEPCIRDAPIType mapToApi(CiRdRegJpe jpe, @Context CbsXmlApiOperation oper, @Context Map otherInfo);
	
	@InheritConfiguration
	public CiRdRegJpe mapToJpe(DEPCIRDAPIType api, @MappingTarget CiRdRegJpe jpe);
	
}
