package com.silverlakesymmetri.cbs.dep.svc;

import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation;
import com.silverlakesymmetri.cbs.commons.svc.BusinessService;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.AcctInterestDetailQry;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.AcctInterestDetailQryJpe;

import java.util.List;
import java.util.Map;

public interface AcctInterestDetailQryService extends BusinessService<AcctInterestDetailQry, AcctInterestDetailQryJpe> {

    public static final String SVC_OP_NAME_ACCTINTERESTDETAILQRYSERVICE_GETACCTINTERESTDETAIL = "AcctInterestDetailQryService.getAcctInterestDetail";
    public static final String SVC_OP_NAME_ACCTINTERESTDETAILQRYSERVICE_GETBYPK = "AcctInterestDetailQryService.getByPk";
    public static final String SVC_OP_NAME_ACCTINTERESTDETAILQRYSERVICE_QUERY = "AcctInterestDetailQryService.query";

    @ServiceOperation(name = SVC_OP_NAME_ACCTINTERESTDETAILQRYSERVICE_GETACCTINTERESTDETAIL, type = ServiceOperation.ServiceOperationType.EXECUTE)
    public AcctInterestDetailQry getAcctInterestDetail(AcctInterestDetailQry dataObject);

    @ServiceOperation(name = SVC_OP_NAME_ACCTINTERESTDETAILQRYSERVICE_GETBYPK, type = ServiceOperation.ServiceOperationType.GET)
    public AcctInterestDetailQry getByPk(String publicKey, AcctInterestDetailQry reference);

    @ServiceOperation(name = SVC_OP_NAME_ACCTINTERESTDETAILQRYSERVICE_QUERY)
    public List<AcctInterestDetailQry> query(int offset, int resultLimit, String groupBy, String order, Map<String, Object> filters);

}
