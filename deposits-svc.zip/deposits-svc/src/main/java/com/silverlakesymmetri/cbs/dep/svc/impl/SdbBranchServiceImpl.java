package com.silverlakesymmetri.cbs.dep.svc.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.mysema.query.types.EntityPath;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.svc.AbstractBusinessService;
import com.silverlakesymmetri.cbs.csd.bdo.sdo.Branch;
import com.silverlakesymmetri.cbs.csd.jpa.mapping.sdo.BranchJpe;
import com.silverlakesymmetri.cbs.csd.jpa.mapping.sdo.QBranchJpe;
import com.silverlakesymmetri.cbs.csd.jpa.mapping.sdo.id.BranchPk;
import com.silverlakesymmetri.cbs.dep.svc.SdbBranchService;

@Service
@Transactional
public class SdbBranchServiceImpl extends AbstractBusinessService<Branch, BranchJpe, BranchPk> implements SdbBranchService {

	
	@Override
    public Branch getByPk(String publicKey, Branch reference) {
        return super.getByPk(publicKey, reference);
    }
	
	private static final String SDB_BRANCH_LOV = "SELECT DISTINCT br"
			+ " FROM BranchJpe br"
			+ " INNER JOIN SdbInventoryJpe inv"
			+ "   ON (br.branch = inv.branch)"
			+ " WHERE 1=1 AND br.branch like :branch";

	
    @Override
    public List<Branch> query(int offset, int resultLimit, String groupBy, String order, Map<String, Object> filters) {
    	
    	if (filters == null){
    		filters = new HashMap<String, Object>();
    	}
    		
    	if (!filters.containsKey("branch")){
    		filters.put("branch", "%");
    	}
   
    	List<BranchJpe> jpeList = (List<BranchJpe>) dataService.findWithQuery(SDB_BRANCH_LOV, filters, offset, resultLimit, BranchJpe.class);
    	        
        List<Branch> retList = new ArrayList<>();
		if (jpeList != null && jpeList.size() > 0) {
			for(BranchJpe jpe: jpeList){
				retList.add(jaxbSdoHelper.wrap(jpe, Branch.class));				
			}
		}
		
		return retList;    	
    }

    @Override
    public List<Branch> find(FindCriteria findCriteria, CbsHeader cbsHeader) {
        return super.find(findCriteria, cbsHeader);
    }


	@Override
	protected BranchPk getIdFromDataObjectInstance(Branch dataObject) {
		// TODO Auto-generated method stub
		return new BranchPk(dataObject.getBranch());
	}

	@Override
	protected EntityPath<BranchJpe> getEntityPath() {
		// TODO Auto-generated method stub
		return QBranchJpe.branchJpe;
	}
	
}
