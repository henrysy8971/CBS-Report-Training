package com.silverlakesymmetri.cbs.dep.svc;

import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation;
import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation.ServiceOperationType;
import com.silverlakesymmetri.cbs.commons.svc.BusinessService;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.AcctBranchTransfer;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.AcctBranchTransferJpe;

public interface AcctBranchTransferService extends BusinessService<AcctBranchTransfer, AcctBranchTransferJpe> {

    public static final String SVC_OP_NAME_ACCTBRANCHTRANSFERSERVICE_CREATE = "AcctBranchTransferService.create";
    public static final String SVC_OP_NAME_ACCTBRANCHTRANSFERSERVICE_GET = "AcctBranchTransferService.get";

    @ServiceOperation(name = SVC_OP_NAME_ACCTBRANCHTRANSFERSERVICE_CREATE)
    public AcctBranchTransfer create(AcctBranchTransfer dataObject);

	@ServiceOperation(name = SVC_OP_NAME_ACCTBRANCHTRANSFERSERVICE_GET, type = ServiceOperationType.GET)
    public AcctBranchTransfer getByPk(String acct, AcctBranchTransfer acctClosureCheck);

}
