package com.silverlakesymmetri.cbs.dep.svc.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.mysema.query.types.EntityPath;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.svc.AbstractXmlApiBusinessService;
import com.silverlakesymmetri.cbs.commons.xmlapi.enums.CbsXmlApiOperation;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.TdaVInq;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.QTdaVInqJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.TdaVInqJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.id.TdaVInqPk;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.util.DepJpeConstants;
import com.silverlakesymmetri.cbs.dep.svc.TdaVInqService;
import com.silverlakesymmetri.cbs.dep.svc.mapper.TdaVInqServiceMapper;
import com.silverlakesymmetri.cbs.dep.xmlapi.DEPTDHISTORYQRYAPIType;

@Service
@Transactional
public class TdaVInqServiceImpl extends
		AbstractXmlApiBusinessService<TdaVInq, TdaVInqJpe, TdaVInqPk, DEPTDHISTORYQRYAPIType, DEPTDHISTORYQRYAPIType>
		implements TdaVInqService {

	@Autowired
	TdaVInqServiceMapper mapper;

	@Override
	protected TdaVInqPk getIdFromDataObjectInstance(TdaVInq dataObject) {
		HashMap<String, Object> params = new HashMap<String, Object>();
		params.put("acctNo", dataObject.getAcctNo());
		Long internalKey = dataService.getWithNamedQuery(DepJpeConstants.ACCT_JPE_FIND_INTERNAL_KEY_BY_ACCT_NO, params,
				Long.class);
		return new TdaVInqPk(dataObject.getSeqNo(), internalKey);
	}

	@Override
	protected EntityPath<TdaVInqJpe> getEntityPath() {
		return QTdaVInqJpe.tdaVInqJpe;
	}

	@Override
	public List<TdaVInq> query(int offset, int resultLimit, String groupBy, String order, Map<String, Object> filters) {
		return super.query(offset, resultLimit, groupBy, order, filters);
	}

	@Override
	public List<TdaVInq> find(FindCriteria findCriteria, CbsHeader cbsHeader) {
		return super.find(findCriteria, cbsHeader);
	}

	@Override
	public TdaVInq getByPk(String publicKey, TdaVInq reference) {
		if (publicKey != null) {
			String[] arr = publicKey.split("~");
			String acctNo = "";
			Long seqNo = 0L;
			if (arr.length > 1) {
				acctNo = arr[0];
			}
			if (arr.length >= 2) {
				try {
					seqNo = Long.parseLong(arr[1]);
				} catch (NumberFormatException e) {
					seqNo = 0L;
				}
			}
			return getData(acctNo, seqNo);
		}
		return null;
	}

	@Override
	protected Class<DEPTDHISTORYQRYAPIType> getXmlApiResponseClass() {
		return DEPTDHISTORYQRYAPIType.class;
	}

	@Override
	protected List<TdaVInq> processXmlApiListRs(TdaVInq dataObject, DEPTDHISTORYQRYAPIType xmlApiRs) {
		return null;
	}

	@Override
	protected TdaVInq processXmlApiRs(TdaVInq dataObject, DEPTDHISTORYQRYAPIType xmlApiRs) {
		TdaVInqJpe jpe = jaxbSdoHelper.unwrap(dataObject);
		return jaxbSdoHelper.wrap(mapper.mapToJpe(xmlApiRs, jpe));
	}

	@Override
	protected DEPTDHISTORYQRYAPIType transformBdoToXmlApiRqCreate(TdaVInq dataObject) {
		return null;
	}

	@Override
	protected DEPTDHISTORYQRYAPIType transformBdoToXmlApiRqDelete(TdaVInq dataObject) {
		return null;
	}

	@Override
	protected DEPTDHISTORYQRYAPIType transformBdoToXmlApiRqUpdate(TdaVInq dataObject) {
		return null;
	}

	private TdaVInq getData(String acctNo, Long seqNo) {
		HashMap<String, Object> params = new HashMap<String, Object>();
		params.put("acctNo", acctNo);
		Long internalKey = dataService.getWithNamedQuery(DepJpeConstants.ACCT_JPE_FIND_INTERNAL_KEY_BY_ACCT_NO, params,
				Long.class);
		DEPTDHISTORYQRYAPIType xmlApiRq = new DEPTDHISTORYQRYAPIType();
		xmlApiRq.setOPERATION(CbsXmlApiOperation.QUERY.getOperation());
		xmlApiRq.setSEQNO(seqNo);
		xmlApiRq.setINTERNALKEY(internalKey);
		super.setTechColumns(xmlApiRq);
		DEPTDHISTORYQRYAPIType xmlApiRs = super.queryXmlApiRs(xmlApiRq);
		TdaVInqJpe jpe = new TdaVInqJpe();
		TdaVInq bdo = jaxbSdoHelper.wrap(mapper.mapToJpe(xmlApiRs, jpe));

		if (bdo.getCalcNetInterestAmt() == null) {
			bdo.setCalcNetInterestAmt(0d);
		}
		if (bdo.getPrincipalAmt() == null) {
			bdo.setPrincipalAmt(0d);
		}
		if (bdo.getNetInterestAmt() == null) {
			bdo.setNetInterestAmt(0d);
		}
		if (bdo.getAddtlPrincipal() == null) {
			bdo.setAddtlPrincipal(0d);
		}
		if (bdo.getEffectiveRate() == null) {
			bdo.setEffectiveRate(0d);
		}
		if (!StringUtils.isEmpty(bdo.getDepTermType()) && bdo.getDepTermPeriod() != null) {
			StringBuilder sb = new StringBuilder(bdo.getDepTermPeriod().intValue() + " " + bdo.getDepTermType().trim());
			if (bdo.getDepTermDays() == null) {
				sb.append("0D");
			} else {
				sb.append(bdo.getDepTermDays().intValue() + "D");
			}
			bdo.setDepTerm(sb.toString());
		}

		return bdo;
	}

}
