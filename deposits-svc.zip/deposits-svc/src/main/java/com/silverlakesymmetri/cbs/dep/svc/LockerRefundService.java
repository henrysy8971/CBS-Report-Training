package com.silverlakesymmetri.cbs.dep.svc;

import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation;
import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation.ServiceOperationType;
import com.silverlakesymmetri.cbs.commons.svc.BusinessService;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.LockerRefund;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.LockerRefundJpe;

public interface LockerRefundService extends BusinessService<LockerRefund, LockerRefundJpe> {
	public static final String SVC_OP_NAME_LOCKERREFUNDSERVICE_GET= "LockerRefundService.get";
	public static final String SVC_OP_NAME_LOCKERREFUNDSERVICE_QUERY= "LockerRefundService.query";
	public static final String SVC_OP_NAME_LOCKERREFUNDSERVICE_CREATE= "LockerRefundService.create";
	public static final String SVC_OP_NAME_LOCKERREFUNDSERVICE_UPDATE= "LockerRefundService.update";
	public static final String SVC_OP_NAME_LOCKERREFUNDSERVICE_DELETE= "LockerRefundService.delete";
	public static final String SVC_OP_NAME_LOCKERREFUNDSERVICE_FIND= "LockerRefundService.find";

	@ServiceOperation(name = SVC_OP_NAME_LOCKERREFUNDSERVICE_CREATE)
    public LockerRefund create(LockerRefund dataObject);

    @ServiceOperation(name = SVC_OP_NAME_LOCKERREFUNDSERVICE_GET, type = ServiceOperationType.GET)
    public LockerRefund getByPk(String publicKey, LockerRefund reference);
}
