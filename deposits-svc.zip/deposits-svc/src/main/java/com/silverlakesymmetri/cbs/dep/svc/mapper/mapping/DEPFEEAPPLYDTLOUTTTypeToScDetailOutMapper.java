package com.silverlakesymmetri.cbs.dep.svc.mapper.mapping;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Mappings;

import com.silverlakesymmetri.cbs.commons.jpa.util.DateTimeHelper;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.ScDetailOutJpe;
import com.silverlakesymmetri.cbs.dep.xmlapi.DEPFEEAPPLYDTLOUTTType;

@Mapper(uses = { DateTimeHelper.class })
public interface DEPFEEAPPLYDTLOUTTTypeToScDetailOutMapper {

	@Mappings({
	    @Mapping(target = "position", source = "POSITION"),
	    @Mapping(target = "scEventType", source = "SCEVENTTYPE"),
	    @Mapping(target = "scType", source = "SCTYPE"),
	    @Mapping(target = "scRateType", source = "SCRATETYPE"),
	    @Mapping(target = "scSeqNo", source = "SCSEQNO"),
	    @Mapping(target = "scDate", source = "SCDATE", qualifiedByName = {"DateTimeHelper","convertCbsApiDateToString"}),
	    @Mapping(target = "scRbSeqNo", source = "SCRBSEQNO"),
	    @Mapping(target = "taxRbSeqNo", source = "TAXRBSEQNO"),
	    @Mapping(target = "scAmt", source = "SCAMT"),
	    @Mapping(target = "scTaxAmt", source = "SCTAXAMT")
	})
	public ScDetailOutJpe mapDEPFEEAPPLYDTLOUTTToScDetailOut(DEPFEEAPPLYDTLOUTTType api);
		
}
