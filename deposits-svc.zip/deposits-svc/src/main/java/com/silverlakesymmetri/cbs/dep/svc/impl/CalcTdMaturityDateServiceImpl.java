package com.silverlakesymmetri.cbs.dep.svc.impl;

import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mysema.query.types.EntityPath;
import com.silverlakesymmetri.cbs.commons.jpa.util.DateTimeHelper;
import com.silverlakesymmetri.cbs.commons.svc.AbstractBusinessService;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.CalcTdMaturityDate;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.CalcTdMaturityDateJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.QCalcTdMaturityDateJpe;
import com.silverlakesymmetri.cbs.dep.svc.CalcTdMaturityDateService;
import com.silverlakesymmetri.cbs.dep.svc.DepTDStorUtilService;

@Service
public class CalcTdMaturityDateServiceImpl extends AbstractBusinessService<CalcTdMaturityDate, CalcTdMaturityDateJpe, String> implements CalcTdMaturityDateService {

	@Autowired
	private DepTDStorUtilService depTDStorUtilService;
	
	@Autowired
	private DateTimeHelper dateTimeHelper;
	
	@Override
	protected String getIdFromDataObjectInstance(CalcTdMaturityDate dataObject) {
		return "";
	}

	@Override
	protected EntityPath<CalcTdMaturityDateJpe> getEntityPath() {
		return QCalcTdMaturityDateJpe.calcTdMaturityDateJpe;
	}
	
	@Override
	public List<CalcTdMaturityDate> query(int offset, int resultLimit, String groupBy, String order,
			Map<String, Object> filters) {
		
		Integer freqPeriod = Integer.parseInt((String) filters.get("freqPeriod"));
		String freqType = (String) filters.get("freqType");
		Integer freqDay = 0;
		if (filters.containsKey("freqDay")) {
			if (filters.get("freqDay") != null) {
				try {
					freqDay = Integer.parseInt((String) filters.get("freqDay"));
				} catch (Exception e) {
				}
			}
		}
		String ccy = (String) filters.get("ccy");
		String clientNo = (String) filters.get("clientNo");
		String branch = (String) filters.get("branch");
		Date runDate = (dateTimeHelper.getDate((String) filters.get("runDate")));
		
		String maturityDate = depTDStorUtilService.calcFdMatDate(freqPeriod, freqType, freqDay, ccy, clientNo, branch, runDate);
		if (maturityDate == null) {
			return Collections.emptyList();
		}
		return Collections.singletonList(mapToCalcTdMaturityDate(freqPeriod, freqType, freqDay, ccy, clientNo, branch, runDate, maturityDate));
	}
	
	private CalcTdMaturityDate mapToCalcTdMaturityDate(Integer freqPeriod, String freqType, Integer freqDay, String ccy, String clientNo, String branch, Date runDate, String maturityDate) {
		CalcTdMaturityDateJpe calcTdMaturityDateJpe = new CalcTdMaturityDateJpe();
		calcTdMaturityDateJpe.setFreqPeriod(freqPeriod);
		calcTdMaturityDateJpe.setFreqType(freqType);
		calcTdMaturityDateJpe.setFreqDay(freqDay);
		calcTdMaturityDateJpe.setCcy(ccy);
		calcTdMaturityDateJpe.setClientNo(clientNo);
		calcTdMaturityDateJpe.setBranch(branch);
		calcTdMaturityDateJpe.setRunDate(runDate);
		calcTdMaturityDateJpe.setNewDate(dateTimeHelper.getDate(maturityDate));
		return jaxbSdoHelper.wrap(calcTdMaturityDateJpe);
	}
}
