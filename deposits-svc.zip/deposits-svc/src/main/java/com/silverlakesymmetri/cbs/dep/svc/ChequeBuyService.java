package com.silverlakesymmetri.cbs.dep.svc;

import java.util.List;
import java.util.Map;

import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation;
import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation.ServiceOperationType;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.svc.BusinessService;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.ChqBuy;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.ChqBuyJpe;

public interface ChequeBuyService extends BusinessService<ChqBuy, ChqBuyJpe> {
	public static final String SVC_OP_NAME_CHEQUEBUYSERVICE_GET= "ChequeBuyService.get";
	public static final String SVC_OP_NAME_CHEQUEBUYSERVICE_QUERY= "ChequeBuyService.query";
	public static final String SVC_OP_NAME_CHEQUEBUYSERVICE_FIND= "ChequeBuyService.find";
	public static final String SVC_OP_NAME_CHEQUEBUYSERVICE_CREATE= "ChequeBuyService.create";
	public static final String SVC_OP_NAME_CHEQUEBUYSERVICE_UPDATE= "ChequeBuyService.update";
	public static final String SVC_OP_NAME_CHEQUEBUYSERVICE_DELETE= "ChequeBuyService.delete";
	public static final String SVC_OP_NAME_CHEQUEBUYSERVICE_COUNT = "ChequeBuyService.count";
	
    @ServiceOperation(name = SVC_OP_NAME_CHEQUEBUYSERVICE_QUERY)
    public List<ChqBuy> query(int offset, int resultLimit, String groupBy, String order, Map<String, Object> filters);

    @ServiceOperation(name = SVC_OP_NAME_CHEQUEBUYSERVICE_FIND)
    public List<ChqBuy> find(FindCriteria findCriteria, CbsHeader cbsHeader);

    @ServiceOperation(name = SVC_OP_NAME_CHEQUEBUYSERVICE_GET, type = ServiceOperationType.GET)
    public ChqBuy getByPk(String publicKey, ChqBuy reference);
    
    @ServiceOperation(name = SVC_OP_NAME_CHEQUEBUYSERVICE_CREATE)
    public ChqBuy create(ChqBuy dataObject);
    
    @ServiceOperation(name = SVC_OP_NAME_CHEQUEBUYSERVICE_COUNT, type = ServiceOperationType.GET)
	public Long count(FindCriteria findCriteria, CbsHeader cbsHeader);
    
}
