package com.silverlakesymmetri.cbs.dep.svc.mapper.decorator;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

import com.silverlakesymmetri.cbs.commons.xmlapi.enums.CbsXmlApiOperation;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.AcctBranchTransferJpe;
import com.silverlakesymmetri.cbs.dep.svc.mapper.AcctBranchTransferServiceMapper;
import com.silverlakesymmetri.cbs.dep.xmlapi.DEPACCTBRANCHTRANSFERAPIType;
                                                                    
public abstract class AcctBranchTransferServiceDecorator extends FeeServiceDecorator implements AcctBranchTransferServiceMapper{
	
	@Autowired
	@Qualifier("delegate")
	protected  AcctBranchTransferServiceMapper delegate;
		
	@Override
	public DEPACCTBRANCHTRANSFERAPIType mapToApi(AcctBranchTransferJpe jpe, CbsXmlApiOperation oper, Map otherInfo){
		
		DEPACCTBRANCHTRANSFERAPIType req = (DEPACCTBRANCHTRANSFERAPIType)delegate.mapToApi(jpe, oper, otherInfo);
		mapFeeToApi(jpe, req);
		
		return  req;
	}
	
	@Override
	public AcctBranchTransferJpe mapToJpe(DEPACCTBRANCHTRANSFERAPIType api, AcctBranchTransferJpe jpe){
		
		if (jpe == null){
			jpe = new AcctBranchTransferJpe();
		}
		
		if (api == null){
			return jpe;
		}
		
		delegate.mapToJpe(api, jpe);
			
		return jpe;
	}
	

}


