package com.silverlakesymmetri.cbs.dep.svc.impl;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.mysema.query.types.EntityPath;
import com.mysema.query.types.OrderSpecifier;
import com.mysema.query.types.Predicate;
import com.mysema.query.types.expr.BooleanExpression;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.enums.ChangeOperation;
import com.silverlakesymmetri.cbs.commons.logging.CbsAppLogger;
import com.silverlakesymmetri.cbs.commons.logging.annotation.Logger;
import com.silverlakesymmetri.cbs.commons.svc.AbstractBusinessService;
import com.silverlakesymmetri.cbs.commons.svc.CbsFileUploadCapable;
import com.silverlakesymmetri.cbs.commons.svc.util.FileUploadUtilImpl;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.ExternalBranch;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.ExternalBranchJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.QExternalBranchJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.id.ExternalBranchPk;
import com.silverlakesymmetri.cbs.dep.svc.ExternalBranchService;

@Service
@Transactional
public class ExternalBranchServiceImpl extends AbstractBusinessService<ExternalBranch, ExternalBranchJpe, ExternalBranchPk> implements ExternalBranchService, CbsFileUploadCapable<ExternalBranch> {

	@Logger
	CbsAppLogger logger;

	@Autowired
	private FileUploadUtilImpl fileUploadUtility;

	@Override
	protected EntityPath<ExternalBranchJpe> getEntityPath() {
		return QExternalBranchJpe.externalBranchJpe;
	}

	@Override
	protected ExternalBranchPk getIdFromDataObjectInstance(ExternalBranch dataObject) {
		return new ExternalBranchPk(dataObject.getBranchCode(), dataObject.getBankCode());
	}

	@Override
	public ExternalBranch getByPk(String publicKey, ExternalBranch reference) {
		return super.getByPk(publicKey, reference);
	}

	@Override
	public ExternalBranch create(ExternalBranch dataObject) {
		return super.create(dataObject);
	}

	@Override
	public ExternalBranch update(ExternalBranch dataObject) {
		return null;
	}

	@Override
	public List<ExternalBranch> query(int offset, int resultLimit, String groupBy, String order, Map<String, Object> filters) {
		if (resultLimit == 0) resultLimit = 10;
		final List<OrderSpecifier<?>> orders = getOrderSpecifier(QExternalBranchJpe.externalBranchJpe, groupBy, order);
		Predicate predicate = convertMapToPredicate(filters);
		List<ExternalBranch> list = super.query(QExternalBranchJpe.externalBranchJpe, offset, resultLimit, predicate, orders);
		if (list == null) {
			list = new ArrayList<ExternalBranch>();
		}
		return list;
	}

    private Predicate convertMapToPredicate(Map<String, Object> filters) {

    	List<String> bankList = new ArrayList<>();
		String bankIncludeList = null;

		if (filters.containsKey("bankIncludeList")) {
			bankIncludeList = (String) filters.get("bankIncludeList");
			filters.remove("bankIncludeList");
		}

		if (!StringUtils.isAllBlank(bankIncludeList)) {
			bankList = Arrays.asList(bankIncludeList.split(","));
		}

		List<String> branchList = new ArrayList<>();
    	String branchIncludeList = null;

    	if (filters.containsKey("branchIncludeList")) {
			branchIncludeList = (String) filters.get("branchIncludeList");
			filters.remove("branchIncludeList");
		}

		if (!StringUtils.isAllBlank(branchIncludeList)) {
			branchList = Arrays.asList(branchIncludeList.split(","));
		}

		Predicate predicate = convertMapToPredicate(QExternalBranchJpe.externalBranchJpe, filters);

		if (!bankList.isEmpty() || !branchList.isEmpty()) {
			BooleanExpression booleanExpr = null;
			if (!bankList.isEmpty() && !branchList.isEmpty()) {
				booleanExpr = QExternalBranchJpe.externalBranchJpe.bankCode.in(bankList).and(QExternalBranchJpe.externalBranchJpe.branchCode.in(branchList));
			} else if (!bankList.isEmpty()) {
				booleanExpr = QExternalBranchJpe.externalBranchJpe.bankCode.in(bankList);
			} else if (!branchList.isEmpty()) {
				QExternalBranchJpe.externalBranchJpe.branchCode.in(branchList);
			}
			if (booleanExpr != null) {
				if (predicate != null) {
					predicate = ((BooleanExpression) predicate).and(booleanExpr);
				} else {
					predicate = booleanExpr;
				}
			}
		}

		return predicate;

    }

    @Override
	public boolean delete(ExternalBranch dataObject) {
		return false;
	}

	@Override
	public List<ExternalBranch> find(FindCriteria findCriteria, CbsHeader cbsHeader) {
		return super.find(findCriteria, cbsHeader);
	}

	@Override
	public boolean bulkCreate(List<ExternalBranch> bdoList) {
		validateBulkCreateList(bdoList);
		for (ExternalBranch bdo: bdoList) {
			try {
				fileUploadUtility.validateConstraints(bdo, ChangeOperation.Create);
				ExternalBranchJpe jpe = unwrap(bdo);
				jpe.setActiveYn(false);
				jpe.setUsedYn(false);
				this.create(wrap(jpe));
			} catch (Exception e) {
				logger.error("Error encountered while processing jpe: {}", jaxbSdoHelper.unwrap(bdo), e);
				throw e;
			}
		}
		return true;
	}

	private void validateBulkCreateList(List<ExternalBranch> bdoList) {
		// look for duplicate combination
		List<String> uniqueKeyString = new ArrayList<>();
		uniqueKeyString.add("branchCode");
		uniqueKeyString.add("bankCode");
		this.isDuplicatesOnList(uniqueKeyString, bdoList);
	}

	@Override
	public boolean isDuplicatesOnList(List<String> uniqueKeys, List<ExternalBranch> list) {
		return fileUploadUtility.isDuplicatesOnList(uniqueKeys, list);
	}
}
