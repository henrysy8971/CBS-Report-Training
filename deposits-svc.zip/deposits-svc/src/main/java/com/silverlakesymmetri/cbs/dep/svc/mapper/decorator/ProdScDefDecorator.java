package com.silverlakesymmetri.cbs.dep.svc.mapper.decorator;

import java.util.Map;

import org.mapstruct.Context;
import org.mapstruct.MappingTarget;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

import com.silverlakesymmetri.cbs.commons.xmlapi.enums.CbsXmlApiOperation;
import com.silverlakesymmetri.cbs.csd.jpa.mapping.sdo.ProdScDefJpe;
import com.silverlakesymmetri.cbs.csd.xmlapi.CSDPRODSCDEFAPIType;
import com.silverlakesymmetri.cbs.dep.svc.mapper.ProdScDefMapper;
                                                                    
public abstract class ProdScDefDecorator implements ProdScDefMapper{
	
	@Autowired
	@Qualifier("delegate")
	protected  ProdScDefMapper delegate;
	
//	@Autowired(required = true)
//    @Qualifier("cbsGenericDataService")
//    protected CbsGenericDataService dataService;
			
	@Override
	public CSDPRODSCDEFAPIType mapToApi(ProdScDefJpe jpe, @Context CbsXmlApiOperation oper, @Context Map otherInfo){
				
		CSDPRODSCDEFAPIType req = (CSDPRODSCDEFAPIType)delegate.mapToApi(jpe, oper, otherInfo);

		return  req;
	}
	
	@Override
	public ProdScDefJpe mapToJpe(CSDPRODSCDEFAPIType api, @MappingTarget ProdScDefJpe jpe){
		
		if (jpe == null){
			jpe = new ProdScDefJpe();
		}
		
		if (api == null){
			return jpe;
		}
		
		delegate.mapToJpe(api, jpe);
			
		return jpe;
	}
	

}


