package com.silverlakesymmetri.cbs.dep.svc.mapper;

import java.util.Map;

import org.mapstruct.Context;
import org.mapstruct.InheritConfiguration;
import org.mapstruct.InheritInverseConfiguration;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingTarget;
import org.mapstruct.Mappings;

import com.silverlakesymmetri.cbs.commons.jpa.util.DateTimeHelper;
import com.silverlakesymmetri.cbs.commons.xmlapi.enums.CbsXmlApiOperation;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.OnlineIntCapJpe;
import com.silverlakesymmetri.cbs.dep.svc.mapper.mapping.OnlineIntCapToDEPACCTINTCAPAPITypeMapper;
import com.silverlakesymmetri.cbs.dep.xmlapi.DEPACCTINTCAPAPIType;

@Mapper(config=OnlineIntCapToDEPACCTINTCAPAPITypeMapper.class, uses={ DateTimeHelper.class})
public interface OnlineIntCapServiceMapper{
	
	@Mappings({
		 @Mapping(expression = "java(oper != null ? oper.getOperation() : null)", target="OPERATION")
	 })
	@InheritConfiguration
	public DEPACCTINTCAPAPIType mapToApi(OnlineIntCapJpe jpe, @Context CbsXmlApiOperation oper, @Context Map otherInfo);
	
	
	@InheritInverseConfiguration(name = "mapOnlineIntCapToDEPACCTINTCAPAPIType")
//	@Mapping(source = "EFFECTDATE", target="trfDate", qualifiedByName = {"DateTimeHelper","convertCbsApiDateToString"})
	public OnlineIntCapJpe mapToJpe(DEPACCTINTCAPAPIType api, @MappingTarget OnlineIntCapJpe jpe);
	
}
