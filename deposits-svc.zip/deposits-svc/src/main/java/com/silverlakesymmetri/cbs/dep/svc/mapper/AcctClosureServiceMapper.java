package com.silverlakesymmetri.cbs.dep.svc.mapper;

import org.mapstruct.Context;
import org.mapstruct.DecoratedWith;
import org.mapstruct.InheritConfiguration;
import org.mapstruct.InheritInverseConfiguration;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingTarget;
import org.mapstruct.Mappings;

import com.silverlakesymmetri.cbs.commons.xmlapi.enums.CbsXmlApiOperation;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.AcctClosureJpe;
import com.silverlakesymmetri.cbs.dep.svc.mapper.decorator.AcctClosureServiceDecorator;
import com.silverlakesymmetri.cbs.dep.svc.mapper.mapping.AcctClosureToDEPACCTCLOSUREAPITypeMapper;
import com.silverlakesymmetri.cbs.dep.xmlapi.DEPACCTCLOSUREAPIType;

@Mapper(config=AcctClosureToDEPACCTCLOSUREAPITypeMapper.class)
@DecoratedWith(AcctClosureServiceDecorator.class)
public interface AcctClosureServiceMapper{
	

	@Mappings({
		 @Mapping(expression = "java(oper != null ? oper.getOperation() : null)", target="OPERATION")
	 })
	@InheritConfiguration
	public DEPACCTCLOSUREAPIType mapToApi(AcctClosureJpe jpe, @Context CbsXmlApiOperation oper);
	
	@InheritInverseConfiguration(name = "mapAcctClosureToDEPACCTCLOSUREAPIType")
//	@Mappings({ 
//		@Mapping(target = "lastCrIntAccruedDate", source="CRLASTACCRDATE", qualifiedByName = {"DateTimeHelper","convertCbsApiDateToString"}),
//		@Mapping(target = "acctOpenDate", source="ACCTOPENDATE", qualifiedByName = {"DateTimeHelper","convertCbsApiDateToString"})
//	})
	public AcctClosureJpe mapToJpe(DEPACCTCLOSUREAPIType api, @MappingTarget AcctClosureJpe jpe);
}
