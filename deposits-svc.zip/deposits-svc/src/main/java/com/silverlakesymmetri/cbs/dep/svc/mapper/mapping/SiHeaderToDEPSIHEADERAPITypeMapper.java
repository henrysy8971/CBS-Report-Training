package com.silverlakesymmetri.cbs.dep.svc.mapper.mapping;

import org.mapstruct.MapperConfig;
import org.mapstruct.Mapping;
import org.mapstruct.Mappings;

import com.silverlakesymmetri.cbs.commons.jpa.util.DateTimeHelper;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.SiHeaderJpe;
import com.silverlakesymmetri.cbs.dep.xmlapi.DEPSIHEADERAPIType;

@MapperConfig(uses={ DateTimeHelper.class})
public interface SiHeaderToDEPSIHEADERAPITypeMapper {
	
	@Mappings({
		@Mapping(source ="INTERNALKEY", 		target="internalKey"), 
		@Mapping(source ="SEQNO", 				target="seqNo"), 
		@Mapping(source ="PRIORITYNO", 		target="priorityNo"), 
		@Mapping(source ="NOOFPAYMENT", 		target="noOfPayment"), 
		@Mapping(source ="PAYMENTMADE", 		target="paymentMade"), 
		@Mapping(source ="TOPAYAMT", 			target="topayAmt"), 
		@Mapping(source ="PAIDAMT", 			target="paidAmt"), 
		@Mapping(source ="FAILEDPAYMENT", 		target="failedPayment"), 
		@Mapping(source ="TOTALFAILEDPAYMENT",target="totalFailedPayment"), 
		@Mapping(source ="CCY", 				target="ccy"), 
		@Mapping(source ="RATEFLAG", 			target="rateFlag"), 
		@Mapping(source ="MARGINRATE", 		target="marginRate"), 
		@Mapping(source ="SETTLETYPE", 		target="settleType"), 
		@Mapping(source ="SETTLEMETHOD", 		target="settleMethod"), 
		@Mapping(source ="ADVICECDB", 			target="adviceCdb"), 
		@Mapping(source ="REFERENCE", 			target="reference"), 
		@Mapping(source ="PURPOSECODE", 		target="purposeCode"), 
		@Mapping(source ="SERVCHARGE", 		target="servCharge"), 
		@Mapping(source ="REMITTERDESC", 		target="remitterDesc"), 
		@Mapping(source ="BENEFICIARYDESC", 	target="beneficiaryDesc"), 
		@Mapping(source ="SIOPENDATE", 		target="siOpenDate", qualifiedByName = {"DateTimeHelper","convertCbsApiDateToString"}), 
		@Mapping(source ="BENFACCTNO", 		target="benfAcctNo"), 
//		@Mapping(source ="BENFCERTIFICATENO", target="benfCertificateNo"), 
		@Mapping(source ="STATUS", 				target="status"), 
//		@Mapping(source ="LASTCHANGEOFFICER", source="CHECKDESC"), 
		@Mapping(source ="APPROVALOFFICER", 	target="approvalOfficer"), 
		@Mapping(source ="APPROVALDATE", 		target="approvalDate", qualifiedByName = {"DateTimeHelper","convertCbsApiDateToString"}), 
		@Mapping(source ="EXPIRYREMARKS", 		target="expiryRemarks")
	 })
	public SiHeaderJpe mapSiHeaderJpeToDEPSIHEADERAPIType(DEPSIHEADERAPIType  api);	
	
//	public DEPSIHEADERAPIType mapSiHeaderJpeToDEPSIHEADERAPIType(SiHeaderJpe  jpe);	

}



