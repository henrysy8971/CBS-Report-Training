package com.silverlakesymmetri.cbs.dep.svc.impl;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mysema.query.types.EntityPath;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.jpa.entity.CbsBpmInfoJpe;
import com.silverlakesymmetri.cbs.commons.jpa.entity.FindCriteriaJpe;
import com.silverlakesymmetri.cbs.commons.jpa.util.JaxbDatetimeAdapter;
import com.silverlakesymmetri.cbs.commons.svc.AbstractXmlApiBusinessService;
import com.silverlakesymmetri.cbs.commons.svc.BusinessObjectValidationCapable;
import com.silverlakesymmetri.cbs.commons.svc.LimitsCheckingCapable;
import com.silverlakesymmetri.cbs.commons.util.CbsStringUtil;
import com.silverlakesymmetri.cbs.commons.xmlapi.enums.CbsXmlApiOperation;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.TranHist;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.QTranHistJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.TranHistJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.id.TranHistPk;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.util.DepJpeConstants;
import com.silverlakesymmetri.cbs.dep.svc.DepositsExpEmkService;
import com.silverlakesymmetri.cbs.dep.svc.TranHistRevService;
import com.silverlakesymmetri.cbs.dep.xmlapi.DEPTRANREVERSALAPIType;
import com.silverlakesymmetri.cbs.lmt.util.ExpEmkObjectHolder;
import com.silverlakesymmetri.cbs.lmt.util.LimitsUtility;

@Service
public class TranHistRevServiceImpl extends AbstractXmlApiBusinessService<TranHist, TranHistJpe, TranHistPk,
        DEPTRANREVERSALAPIType, DEPTRANREVERSALAPIType> implements TranHistRevService,
        BusinessObjectValidationCapable<TranHist>, LimitsCheckingCapable<TranHist> {
	
	private static final String INTERNAL_KEY = "internalKey";
	private static final String ACCT_NO = "acctNo";
	@Autowired
	private DepositsExpEmkService depositsExpEmkService;

    @Autowired
    private LimitsUtility limitsUtility;

	@Override
	
	public TranHist getByPk(String publicKey, TranHist reference) {
		TranHist tranHist = super.getByPk(publicKey, reference);
		
		if (tranHist.getTfrSeqNo() != null) {
			TranHistPk pk = new TranHistPk(tranHist.getTfrSeqNo(), JaxbDatetimeAdapter.parseDate(tranHist.getTranDate()));
			TranHistJpe cPartyTranHistJpe = dataService.find(TranHistJpe.class, pk);
			tranHist.setCPartyRec(jaxbSdoHelper.wrap(cPartyTranHistJpe, TranHist.class));
		}
		
		if (tranHist != null) tranHist.setTerminalId(CbsStringUtil.maskIpAddr(tranHist.getTerminalId()));
		return tranHist; 
	}
	
	@Override
	protected EntityPath<TranHistJpe> getEntityPath() {
		return QTranHistJpe.tranHistJpe;
	}
	
	@Override
	protected TranHistPk getIdFromDataObjectInstance(TranHist dataObject) {
		return new TranHistPk(dataObject.getSeqNo(), JaxbDatetimeAdapter.parseDate(dataObject.getTranDate()));
	}
	
	@Override
	public List<TranHist> query(int offset, int resultLimit, String groupBy, String order,
			Map<String, Object> filters) {
		
		if(filters.containsKey(ACCT_NO)){			
			Map<String, Object> params = new HashMap<String, Object>();
			params.put(ACCT_NO, filters.get(ACCT_NO));
			Long result = dataService.getWithNamedQuery(DepJpeConstants.ACCT_JPE_FIND_INTERNAL_KEY_BY_ACCT_NO, params, Long.class);
			
			filters.remove(ACCT_NO);
			filters.put(INTERNAL_KEY, result);
		}
		
		List<TranHist> tranHistList = super.query(offset, resultLimit, groupBy, order, filters);
		if(tranHistList == null){
			tranHistList = new ArrayList<TranHist>();
		}
		
		for (TranHist th : tranHistList) {
			th.setTerminalId(CbsStringUtil.maskIpAddr(th.getTerminalId()));
			if (th.getTfrSeqNo() != null) {
				TranHistPk pk = new TranHistPk(th.getTfrSeqNo(), JaxbDatetimeAdapter.parseDate(th.getTranDate()));
				TranHistJpe cPartyTranHistJpe = dataService.find(TranHistJpe.class, pk);
				th.setCPartyRec(jaxbSdoHelper.wrap(cPartyTranHistJpe, TranHist.class));
			}
		}
		
		return tranHistList;
	}
	
	@Override
	public List<TranHist> find(FindCriteria findCriteria, CbsHeader cbsHeader) {
		List<TranHist> list = super.find(findCriteria, cbsHeader);
		if (list != null) {
			for (TranHist bdo : list) {
				bdo.setTerminalId(CbsStringUtil.maskIpAddr(bdo.getTerminalId()));
			}
		}
		return list;
	}
	
	@Override
	public TranHist create(TranHist dataObject) {
		TranHist bdo = super.create(dataObject);
		if (bdo != null) bdo.setTerminalId(CbsStringUtil.maskIpAddr(bdo.getTerminalId()));
		return bdo;
	}

	@Override
	public TranHist update(TranHist dataObject) {
		TranHist bdo = super.update(dataObject);
		if (bdo != null) bdo.setTerminalId(CbsStringUtil.maskIpAddr(bdo.getTerminalId()));
		return bdo;
	}

	@Override
	public Long count(FindCriteria findCriteria, CbsHeader cbsHeader) {
		FindCriteriaJpe findCriteriaJpe = new FindCriteriaJpe();
		if(findCriteria != null){
			findCriteriaJpe = jaxbSdoHelper.unwrap(findCriteria);
		}
		return dataService.getRowCount(TranHistJpe.class, findCriteriaJpe);
	}
	
	@Override
	protected Class<DEPTRANREVERSALAPIType> getXmlApiResponseClass() {
		return DEPTRANREVERSALAPIType.class;
	}
	
	@Override
	protected List<TranHist> processXmlApiListRs(TranHist dataObject, DEPTRANREVERSALAPIType xmlApiRs) {
		return null;
	}
	
	@Override
	protected TranHist processXmlApiRs(TranHist dataObject, DEPTRANREVERSALAPIType xmlApiRs) {
		Double segNo = xmlApiRs.getTRANSEQNO();
		Double revContraTranSeqNo = xmlApiRs.getREVCONTRATRANSEQNO();
		Double revTranSeqNo = xmlApiRs.getREVTRANSEQNO();
		dataObject.setSeqNo(segNo.longValue());
		dataObject.setRevContraTranSeqNo(revContraTranSeqNo.longValue());
		dataObject.setRevTranSeqNo(revTranSeqNo.longValue());
		dataObject.setTerminalId(CbsStringUtil.maskIpAddr(dataObject.getTerminalId()));
		return dataObject;
	}
	
	@Override
	protected DEPTRANREVERSALAPIType transformBdoToXmlApiRqCreate(TranHist dataObject) {
		return transformTranHistRevToDEPTRANREVERSALAPIType(dataObject, CbsXmlApiOperation.INSERT);
	}

	@Override
	protected DEPTRANREVERSALAPIType transformBdoToXmlApiRqDelete(TranHist dataObject) {
		return null;
	}

	@Override
	protected DEPTRANREVERSALAPIType transformBdoToXmlApiRqUpdate(TranHist dataObject) {
		return transformTranHistRevToDEPTRANREVERSALAPIType(dataObject, CbsXmlApiOperation.UPDATE);
	}
	
	private DEPTRANREVERSALAPIType transformTranHistRevToDEPTRANREVERSALAPIType(TranHist dataObject, CbsXmlApiOperation oper){
		DEPTRANREVERSALAPIType apiType = new DEPTRANREVERSALAPIType();
		super.setTechColsFromDataObject(dataObject, apiType);		
		apiType.setOPERATION(oper.getOperation());

		apiType.setTRANSEQNO(new Double(dataObject.getSeqNo()).doubleValue());
		apiType.setTRANDATE(dateTimeHelper.convertToCbsXmlApiDate(dataObject.getTranDate()));
		apiType.setREVTRANTYPE(dataObject.getReversalTranType());
		if (dataObject.getCPartyRec() != null) {
			apiType.setCONTRAREVTRANTYPE(dataObject.getCPartyRec().getReversalTranType());
		}
		apiType.setOVERRIDEOFFICER(dataObject.getOverrideOfficer());
		
		return apiType;
	}

	@Override
	public TranHist reverse(TranHist dataObject) {
        dataObject = super.update(dataObject);
        return dataObject;
    }

    @Override
    public CbsBpmInfoJpe doCheckLimit(TranHist dataObject) {
        ExpEmkObjectHolder expEmkObject = depositsExpEmkService.getLimitsDetails(dataObject,
                DepositsExpEmkServiceImpl.DEP_EVENT_TYPE, DepositsExpEmkServiceImpl.CR_AMT_TYPE);
        return limitsUtility.getLimitExceptionApprover(expEmkObject, dataObject);
    }

    @Override
    public TranHist getLimitExceptions(TranHist dataObject) {
        ExpEmkObjectHolder expEmkObject = depositsExpEmkService.getLimitsDetails(dataObject,
                DepositsExpEmkServiceImpl.DEP_EVENT_TYPE, DepositsExpEmkServiceImpl.CR_AMT_TYPE);
        TranHist bdo = limitsUtility.getLimitExceptionDetails(expEmkObject, dataObject);
        if (bdo != null) bdo.setTerminalId(CbsStringUtil.maskIpAddr(bdo.getTerminalId()));
        return bdo;
    }

	@Override
	public Long getEffectivityDate(TranHist dataObject) {
		if (dataObject != null) {
			if (!StringUtils.isBlank(dataObject.getEffectDate())) {
				Date date = dateTimeHelper.getDate(dataObject.getEffectDate());
				if (date != null) {
					return dateTimeHelper.removeTime(date).getTime();
				}
			}
		}
		return null;
	}
}
