package com.silverlakesymmetri.cbs.dep.svc.ext;

import com.silverlakesymmetri.cbs.commons.ext.ServiceExtensionPoint;
import com.silverlakesymmetri.cbs.commons.jpa.extension.JaxbSdoHelper;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.DepositClient;
import com.silverlakesymmetri.cbs.dep.svc.DepositClientService;
import com.silverlakesymmetri.cbs.mcl.bdo.sdo.Client;
import com.silverlakesymmetri.cbs.mcl.svc.ext.ClientBdsWrapperCreateServiceExt;
import org.apache.commons.collections.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 *
 * @author luis.talag
 */
@Service
public class DepositClientCreateServiceExtImpl implements ClientBdsWrapperCreateServiceExt, ServiceExtensionPoint {
    
    @Autowired
    private JaxbSdoHelper jaxbSdoHelper;
    
    @Autowired
    private DepositClientService depositClientService;

    @Override
    public String[] getExtendedBdoNames() {
        return new String[]{CLIENT_BDO};
    }

    @Override
    public String[] getExtendedServiceNames() {
        return new String[]{CLIENT_BDS_WRAPPER_CREATE_SERVICE_EXT};
    }

    @Override
    public void createDepositClient(Client client) {
        if (client.getDepClientYn()) {
            DepositClient depositClient = jaxbSdoHelper.createSdoInstance(DepositClient.class);
            depositClient.setClientNo(client.getClientNo());
            depositClient.setFwEligible("N");
            depositClient.setFwManualStatus("N");
            depositClient.setStopSc("N");
            depositClient.setOthTaxExemptInd("N");
            depositClient.setTaxFiler("N");

            if (!CollectionUtils.isEmpty(client.getClientManagerList())) {
                depositClient.setAcctExec(client.getClientManagerList().get(0).getManagerCode());
            }

            depositClientService.create(depositClient);
        }
    }

    @Override
    public void createLoanClient(Client dataObject) {
    }

    @Override
    public void beforeService(Object[] serviceParameters) {
    }

    @Override
    public Object afterService(Object result, Object[] serviceParameters) {
        return null;
    }

    @Override
    public void beforeQuery(Object[] serviceParameters) {
    }

    @Override
    public Object afterQuery(Object result, Object[] serviceParameters) {
        return null;
    }

    @Override
    public Object afterValidationBeforeMainService(Object result) {
        return null;
    }

}
