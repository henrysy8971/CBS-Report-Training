package com.silverlakesymmetri.cbs.dep.svc;

import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.svc.BusinessService;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.AcctTypeTfrHeader;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.AcctTypeTfrHeaderJpe;

import java.util.List;
import java.util.Map;

/**
 * Created by Emerson.Sanchez on 17/4/2019.
 */
public interface AcctTypeTfrBulkService extends BusinessService<AcctTypeTfrHeader, AcctTypeTfrHeaderJpe> {

    public static final String SVC_OP_NAME_ACCTTYPETFRBULKSERVICE_GET = "AcctTypeTfrBulkService.get";
    public static final String SVC_OP_NAME_ACCTTYPETFRBULKSERVICE_QUERY = "AcctTypeTfrBulkService.query";
    public static final String SVC_OP_NAME_ACCTTYPETFRBULKSERVICE_CREATE = "AcctTypeTfrBulkService.create";
    public static final String SVC_OP_NAME_ACCTTYPETFRBULKSERVICE_UPDATE = "AcctTypeTfrBulkService.update";
    public static final String SVC_OP_NAME_ACCTTYPETFRBULKSERVICE_DELETE = "AcctTypeTfrBulkService.delete";
    public static final String SVC_OP_NAME_ACCTTYPETFRBULKSERVICE_FIND = "AcctTypeTfrBulkService.find";
    public static final String SVC_OP_NAME_ACCTTYPETFRBULKSERVICE_COUNT = "AcctTypeTfrBulkService.count";

    @ServiceOperation(name = SVC_OP_NAME_ACCTTYPETFRBULKSERVICE_GET, type = ServiceOperation.ServiceOperationType.GET)
    public AcctTypeTfrHeader getByPk(String publicKey, AcctTypeTfrHeader reference);

    @ServiceOperation(name = SVC_OP_NAME_ACCTTYPETFRBULKSERVICE_CREATE)
    public AcctTypeTfrHeader create(AcctTypeTfrHeader dataObject);

    @ServiceOperation(name = SVC_OP_NAME_ACCTTYPETFRBULKSERVICE_UPDATE)
    public AcctTypeTfrHeader update(AcctTypeTfrHeader dataObject);

    @ServiceOperation(name = SVC_OP_NAME_ACCTTYPETFRBULKSERVICE_QUERY)
    public List<AcctTypeTfrHeader> query(int offset, int resultLimit, String groupBy, String order,
                                        Map<String, Object> filters);

    @ServiceOperation(name = SVC_OP_NAME_ACCTTYPETFRBULKSERVICE_DELETE)
    public boolean delete(AcctTypeTfrHeader dataObject);

    @ServiceOperation(name = SVC_OP_NAME_ACCTTYPETFRBULKSERVICE_FIND)
    public List<AcctTypeTfrHeader> find(FindCriteria findCriteria, CbsHeader cbsHeader);

    @ServiceOperation(name = SVC_OP_NAME_ACCTTYPETFRBULKSERVICE_COUNT, type = ServiceOperation.ServiceOperationType.GET)
    public Long count(FindCriteria findCriteria, CbsHeader cbsHeader);
}
