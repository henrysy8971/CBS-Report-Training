package com.silverlakesymmetri.cbs.dep.svc.impl;

import java.util.*;

import javax.mail.MessagingException;

import com.silverlakesymmetri.cbs.commons.exception.base.CbsServiceProcessException;
import com.silverlakesymmetri.cbs.commons.exception.base.helper.ExceptionHelper;
import com.silverlakesymmetri.cbs.csd.util.DateHelperDataHolder;
import com.silverlakesymmetri.cbs.csd.util.DateHelperUtil;
import org.apache.velocity.VelocityContext;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.bdo.sdo.DmsFile;
import com.silverlakesymmetri.cbs.commons.jpa.entity.CbsHeaderJpe;
import com.silverlakesymmetri.cbs.commons.jpa.mapping.sdo.enums.CommunicationChannelEnum;
import com.silverlakesymmetri.cbs.commons.jpa.util.BdoHelper;
import com.silverlakesymmetri.cbs.commons.xmlapi.enums.CbsXmlApiOperation;
import com.silverlakesymmetri.cbs.csd.xmlapi.CSDPRODSCINDIVIDUALAPIType;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.Acct;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.AcctJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.id.AcctPk;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.util.DepJpeConstants;
import com.silverlakesymmetri.cbs.dep.svc.AcctTDService;
import com.silverlakesymmetri.cbs.dep.svc.mapper.AcctTDServiceMapper;
import com.silverlakesymmetri.cbs.dep.xmlapi.DEPJOINTACCTAPIType;
import com.silverlakesymmetri.cbs.dep.xmlapi.DEPPRODSCMAINTFEEAPIType;
import com.silverlakesymmetri.cbs.dep.xmlapi.DEPSTMTAPIType;
import com.silverlakesymmetri.cbs.dep.xmlapi.DEPTDAWRAPPERAPIType;
import com.silverlakesymmetri.cbs.mcl.bdo.sdo.Client;
import com.silverlakesymmetri.cbs.xps.bdo.sdo.AdvicePreview;
import com.silverlakesymmetri.cbs.xps.bdo.sdo.DocDomainObjDefn;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.DocDomainObjDefnJpe;
import com.silverlakesymmetri.cbs.xps.svc.DocDomainObjDefnService;

/**
 *
 * @author Jeffrey.Villanueva
 *
 */
@Service
public class AcctTDServiceImpl extends AbstractAcctServiceImpl<DEPTDAWRAPPERAPIType, DEPTDAWRAPPERAPIType>
		implements AcctTDService {

	private static final String ERROR_ACCT_OPEN_DATE_IS_HOLIDAY = "CBS.B.DEP.ACCT_SERVICE.0011";

	@Autowired
	protected AcctTDServiceMapper acctTDServiceMapper;

	@Autowired
	private DocDomainObjDefnService docDomainObjDefnService;
	
	@Autowired
	private DateHelperUtil dateHelperUtil;

	@Override
	public Acct create(Acct dataObject) {
		Acct newAcct = super.create(dataObject);
		Map<String, Object> param = new HashMap<String, Object>();
		param.put("acctNo", newAcct.getAcctNo());
		AcctJpe acctJpe = dataService.getWithNamedQuery(DepJpeConstants.ACCT_JPE_FIND_BY_ACCTNO, param, AcctJpe.class);
		delegateDocDomainObjDefnCreateOrUpdate(acctJpe.getHeader(), dataObject.getDocDomainObjDefnList(),
				new ArrayList<DocDomainObjDefn>(), newAcct);
		generateMessageQueue(newAcct);
		return newAcct;
	}

	@Override
	protected Acct preCreateValidation(Acct dataObject) {
		validateDates(dataObject);
		return super.preCreateValidation(dataObject);
	}

	private void validateDates(Acct dataObject) {
		Collection<Throwable> exceptions = new ArrayList<>();

		if (dataObject.getAcctOpenDate() != null) {
			DateHelperDataHolder holder = dateHelperUtil.createGeneralDateDataHolder(dataObject.getType().getName(), "acctOpenDate", dataObject);
			if (dateHelperUtil.checkHoliday(holder)) {
				String msg = messageUtils.getMessage(ERROR_ACCT_OPEN_DATE_IS_HOLIDAY, new String[] { dataObject.getAcctOpenDate() });
				CbsServiceProcessException exec = new CbsServiceProcessException(ERROR_ACCT_OPEN_DATE_IS_HOLIDAY, msg);
				exceptions.add(exec);
			}
		}

		ExceptionHelper.createAndThrowAggregateException(exceptions);
	}

	@Override
	public Acct update(Acct dataObject) {
		Acct updatedObject = super.update(dataObject);
		AcctJpe acctJpe = jaxbSdoHelper.unwrap(updatedObject, AcctJpe.class);
		delegateDocDomainObjDefnCreateOrUpdate(acctJpe.getHeader(), dataObject.getDocDomainObjDefnList(),
				getDocDomainObjDefnsByAcctNo(dataObject.getAcctNo(), dataObject.getAcctType()), updatedObject);
		return updatedObject;
	}

	@Override
	public boolean delete(Acct dataObject) {
		return super.delete(dataObject);
	}

	@Override
	public List<Acct> query(int offset, int resultLimit, String groupBy, String order, Map<String, Object> filters) {
		return super.query(offset, resultLimit, groupBy, order, filters);
	}

	@Override
	public List<Acct> find(FindCriteria findCriteria, CbsHeader cbsHeader) {
		return super.find(findCriteria, cbsHeader);
	}

	@Override
	public Acct getByPk(String publicKey, Acct reference) {
		Acct acct = super.getByPk(publicKey, reference);
		if (acct != null) {
			acct.setDocDomainObjDefnList(getDocDomainObjDefnsByAcctNo(acct.getAcctNo(), acct.getAcctType()));
		}
		return acct;
	}

	@Override
	public Long count(FindCriteria findCriteria, CbsHeader cbsHeader) {
		return super.count(findCriteria, cbsHeader);
	}

	@Override
	protected DEPTDAWRAPPERAPIType transformBdoToXmlApiRqCreate(Acct dataObject) {
		return tranformAcctToDEPTDAWRAPPERAPIType(dataObject, CbsXmlApiOperation.INSERT);
	}

	@Override
	protected DEPTDAWRAPPERAPIType transformBdoToXmlApiRqUpdate(Acct dataObject) {
		return tranformAcctToDEPTDAWRAPPERAPIType(dataObject, CbsXmlApiOperation.UPDATE);
	}

	@Override
	protected DEPTDAWRAPPERAPIType transformBdoToXmlApiRqDelete(Acct dataObject) {
		return tranformAcctToDEPTDAWRAPPERAPIType(dataObject, CbsXmlApiOperation.DELETE);
	}

	private DEPTDAWRAPPERAPIType tranformAcctToDEPTDAWRAPPERAPIType(Acct bdo, CbsXmlApiOperation oper) {

		DEPTDAWRAPPERAPIType api = acctTDServiceMapper.mapToApi(bdo, oper);

		super.setTechColsFromDataObject(bdo, api.getDEPTDAREC());
		if (api.getDEPJOINTACCTLIST() == null || api.getDEPJOINTACCTLIST().getDEPJOINTACCTAPI() == null
				|| api.getDEPJOINTACCTLIST().getDEPJOINTACCTAPI().isEmpty()) {
		} else {
			for (DEPJOINTACCTAPIType joint : api.getDEPJOINTACCTLIST().getDEPJOINTACCTAPI()) {
				super.setTechColsFromDataObject(bdo, joint);
			}
		}

		if (api.getDEPSTMTLIST() == null || api.getDEPSTMTLIST().getDEPSTMTAPI() == null
				|| api.getDEPSTMTLIST().getDEPSTMTAPI().isEmpty()) {
		} else {
			for (DEPSTMTAPIType stmt : api.getDEPSTMTLIST().getDEPSTMTAPI()) {
				super.setTechColsFromDataObject(bdo, stmt);
			}
		}

		if (api.getCSDPRODSCDEFREC() != null) {
			super.setTechColsFromDataObject(bdo, api.getCSDPRODSCDEFREC());
		}

		if (api.getCSDPRODSCINDIVIDUALLIST() == null
				|| api.getCSDPRODSCINDIVIDUALLIST().getCSDPRODSCINDIVIDUALAPI() == null
				|| api.getCSDPRODSCINDIVIDUALLIST().getCSDPRODSCINDIVIDUALAPI().isEmpty()) {
		} else {
			for (CSDPRODSCINDIVIDUALAPIType indv : api.getCSDPRODSCINDIVIDUALLIST().getCSDPRODSCINDIVIDUALAPI()) {
				super.setTechColsFromDataObject(bdo, indv);
			}
		}

		if (api.getDEPPRODSCMAINTFEELIST() == null || api.getDEPPRODSCMAINTFEELIST().getDEPPRODSCMAINTFEEAPI() == null
				|| api.getDEPPRODSCMAINTFEELIST().getDEPPRODSCMAINTFEEAPI().isEmpty()) {
		} else {
			for (DEPPRODSCMAINTFEEAPIType scMaint : api.getDEPPRODSCMAINTFEELIST().getDEPPRODSCMAINTFEEAPI()) {
				super.setTechColsFromDataObject(bdo, scMaint);
			}
		}

		return api;
	}

	@Override
	protected Acct processXmlApiRs(Acct dataObject, DEPTDAWRAPPERAPIType xmlApiRs) {
		if (xmlApiRs != null && xmlApiRs.getDEPTDAREC() != null) {
			Number internalKey = xmlApiRs.getDEPTDAREC().getINTERNALKEY();
			if (internalKey != null) {
				AcctJpe acctJpe = dataService.find(AcctJpe.class, new AcctPk(internalKey.longValue()));
				return jaxbSdoHelper.wrap(acctJpe, Acct.class);
			}
		}
		return dataObject;
	}

	@Override
	protected List<Acct> processXmlApiListRs(Acct dataObject, DEPTDAWRAPPERAPIType xmlApiRs) {
		return null;
	}

	@Override
	protected Class<DEPTDAWRAPPERAPIType> getXmlApiResponseClass() {
		return DEPTDAWRAPPERAPIType.class;
	}

	@Override
	protected Map<String, String> executeStoredProcedure(String xmlApiReq, String xmlHeaderIn) {
		String xmlApiReqProcess = xmlApiReq.replaceAll("OPERATION=\"INSERT\"", "OPERATION=\"DO_INSERT\"")
				.replaceAll("OPERATION=\"UPDATE\"", "OPERATION=\"DO_UPDATE\"")
				.replaceAll("OPERATION=\"DELETE\"", "OPERATION=\"DO_DELETE\"");
		return super.executeStoredProcedure(xmlApiReqProcess, xmlHeaderIn);
	}

	@SuppressWarnings("unchecked")
	protected void delegateDocDomainObjDefnCreateOrUpdate(CbsHeaderJpe headerJpe, List<DocDomainObjDefn> sourceList,
			List<DocDomainObjDefn> targetList, Acct dataObject) {
		List<Object> sourceObjectList = (List<Object>) (Object) sourceList;
		List<Object> targetObjectList = (List<Object>) (Object) targetList;
		BdoHelper.ListDiffResult listDiffResult = getBdoHelper().diffItems(sourceObjectList, targetObjectList,
				new String[] { "docDomainObjDefnList" }, headerJpe, new BdoHelper.MergeAllPolicy(), true, true);

		if (listDiffResult.getNewItems() != null) {
			for (Object newItem : listDiffResult.getNewItems()) {
				docDomainObjDefnService.create((DocDomainObjDefn) newItem);
			}
		}

		if (listDiffResult.getUpdatedItems() != null) {
			for (Object updatedItem : listDiffResult.getUpdatedItems()) {
				docDomainObjDefnService.update((DocDomainObjDefn) updatedItem);
			}
		}

		if (listDiffResult.isChanged()) {
			dataObject.getDocDomainObjDefnList().clear();
			dataObject.getDocDomainObjDefnList().addAll(targetList);
		}
	}

	private List<DocDomainObjDefn> getDocDomainObjDefnsByAcctNo(String acctNo, String acctType) {
		Map<String, Object> map = new HashMap<>();
		map.put("refObjectKey", acctNo);
		map.put("refDomainKey", acctType);
		List<DocDomainObjDefnJpe> jpeList = dataService.find(map, DocDomainObjDefnJpe.class);
		List<DocDomainObjDefn> bdoList = new ArrayList<>(jpeList.size());
		for (DocDomainObjDefnJpe jpe : jpeList) {
			bdoList.add(jaxbSdoHelper.wrap(jpe, DocDomainObjDefn.class));
		}
		return bdoList;
	}

	@Override
	public DmsFile generateLetterOfThanks(String acctNo, String locale) {
		return super.generateLetterOfThanks(acctNo, locale);
	}
	
	@Override
	public DmsFile generateMaturityNotice(String acctNo, String locale) {
		VelocityContext context = new VelocityContext();
		
		//fill context with all related BDOs for this document
		Map<String, Object> parameters = new HashMap<String, Object>();
		parameters.put("acctNo", acctNo);
		AcctJpe jpe = dataService.getWithNamedQuery(com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.util.DepJpeConstants.ACCT_JPE_FIND_BY_ACCTNO, parameters, AcctJpe.class);
		Acct bdo = jaxbSdoHelper.wrap(jpe);
		context.put("Acct", bdo);
		context.put("Tda", bdo.getTdaRec());
		
		//call template builder
		boolean islamicDocument = isAcctIslamic(bdo.getAcctType());
		return documentTemplateBuilder.convertTemplateToDocument("MaturityNotice", context, locale, islamicDocument, acctNo);
	}
	
	@Override
	public AdvicePreview sendMaturityNotice(String acctNo, String locale, boolean isPreview) {
		VelocityContext context = new VelocityContext();
		
		//fill context with all related BDOs for this document
		Map<String, Object> parameters = new HashMap<String, Object>();
		parameters.put("acctNo", acctNo);
		AcctJpe jpe = dataService.getWithNamedQuery(com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.util.DepJpeConstants.ACCT_JPE_FIND_BY_ACCTNO, parameters, AcctJpe.class);
		Acct bdo = jaxbSdoHelper.wrap(jpe);
		context.put("Acct", bdo);
		context.put("Tda", bdo.getTdaRec());
		
		Client client = clientService.getByPk(bdo.getClientNo(), null);
		
		//call template builder
		boolean islamicDocument = isAcctIslamic(bdo.getAcctType());
		Map<String, String> messageContext = documentTemplateBuilder.convertTemplateToMessage("MaturityNoticeEmail", context, locale, islamicDocument);
		DmsFile attachment = documentTemplateBuilder.convertTemplateToDocument("MaturityNotice", context, locale, islamicDocument, acctNo);
		List<DmsFile> attachments = new ArrayList<DmsFile>();
		attachments.add(attachment);
		
		String mailAddress = clientService.getClientElectronicMailAddress(client.getClientNo());
		
		//create preview
		AdvicePreview mailPreview = jaxbSdoHelper.createSdoInstance(AdvicePreview.class);
		mailPreview.setRecipients(mailAddress);
		mailPreview.setSubject(messageContext.get("subject"));
		mailPreview.setMsgBody(messageContext.get("message"));
		mailPreview.setAttachments(attachments);

		if(isPreview){
			return mailPreview;
		}

		try {
			msgNotificationService.sendNotificationMessage(CommunicationChannelEnum.MAIL, mailAddress, messageContext.get("subject"), messageContext.get("message"), null, attachments);
		} catch (MessagingException e) {
			msgNotificationService.logFailedNotification("MaturityNotice-"+acctNo, CommunicationChannelEnum.MAIL, mailAddress, messageContext.get("subject"), messageContext.get("message"), attachments);
			return null;
		}
		return mailPreview;
	}
	
	@Override
	public AdvicePreview sendIntimationLetter(String acctNo, String locale, boolean isPreview) {
		return super.sendIntimationLetter(acctNo, locale, isPreview);
	}

}
