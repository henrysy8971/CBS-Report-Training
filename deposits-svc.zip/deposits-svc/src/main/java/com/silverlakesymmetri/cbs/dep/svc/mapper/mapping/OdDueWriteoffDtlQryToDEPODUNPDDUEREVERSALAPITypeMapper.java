package com.silverlakesymmetri.cbs.dep.svc.mapper.mapping;

import com.silverlakesymmetri.cbs.commons.jpa.util.DateTimeHelper;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.OdDueWriteoffDtlQryJpe;
import com.silverlakesymmetri.cbs.dep.xmlapi.DEPODUNPDDUEREVERSALAPIType;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Mappings;
import org.mapstruct.Named;

@Mapper(uses = { DateTimeHelper.class })
public interface OdDueWriteoffDtlQryToDEPODUNPDDUEREVERSALAPITypeMapper {
	
	@Mappings({
		@Mapping(target = "acctNo", source = "ACCTNO"),
		@Mapping(target = "internalKey", source = "INTERNALKEY"),
		@Mapping(target = "prinDueDtlYn", source = "PRINDUEDTL", qualifiedByName = "convertDoubleToBoolean"),
		@Mapping(target = "seqNo", source = "SEQNO"),
		@Mapping(target = "dueDate", source = "DUEDATE", qualifiedByName = {"DateTimeHelper","convertCbsApiDateToString"}),
		@Mapping(target = "dueType", source = "DUETYPE"),
		@Mapping(target = "dueDesc", source = "DUEDESC"),
		@Mapping(target = "dueAmt", source = "DUEAMT"),
		@Mapping(target = "paidAmt", source = "PAIDAMT")
		//REVREASON
	})
	public OdDueWriteoffDtlQryJpe apiTypeToJpe(DEPODUNPDDUEREVERSALAPIType apiType);
	
	@Mappings({
		@Mapping(source = "acctNo", target = "ACCTNO"),
		@Mapping(source = "internalKey", target = "INTERNALKEY"),
		@Mapping(source = "prinDueDtlYn", target = "PRINDUEDTL", qualifiedByName = "convertBooleanToDouble"),
		@Mapping(source = "seqNo", target = "SEQNO"),
		@Mapping(source = "dueDate", target = "DUEDATE", qualifiedByName = {"DateTimeHelper","convertDateToCbsXmlApiDate"}),
		@Mapping(source = "dueType", target = "DUETYPE"),
		@Mapping(source = "dueDesc", target = "DUEDESC"),
		@Mapping(source = "dueAmt", target = "DUEAMT"),
		@Mapping(source = "paidAmt", target = "PAIDAMT")
		//REVREASON
	})
	public DEPODUNPDDUEREVERSALAPIType jpeToApiType(OdDueWriteoffDtlQryJpe jpe);

	@Named("convertBooleanToDouble")
	public static Double convertBooleanToDouble(Boolean bool) {
		if (bool == null) {
			return null;
		} else if (bool.booleanValue()) {
			return 1d;
		} else {
			return 0d;
		}
	}

	@Named("convertDoubleToBoolean")
	public static Boolean convertDoubleToBoolean(Double dbl) {
		if (dbl == null) {
			return null;
		} else if (dbl.doubleValue() > 0d) {
			return Boolean.TRUE;
		} else {
			return Boolean.FALSE;
		}
	}
}
