package com.silverlakesymmetri.cbs.dep.svc.mapper.decorator;

import org.mapstruct.Context;
import org.mapstruct.MappingTarget;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

import com.silverlakesymmetri.cbs.commons.xmlapi.enums.CbsXmlApiOperation;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.AcctDashboardInfoBalJpe;
import com.silverlakesymmetri.cbs.dep.svc.mapper.AcctDashboardInfoBalServiceMapper;
import com.silverlakesymmetri.cbs.dep.xmlapi.DEPACCTQRYAPIType;

public abstract class AcctDashboardInfoBalServiceDecorator implements AcctDashboardInfoBalServiceMapper{
	
	@Autowired
	@Qualifier("delegate")
	protected  AcctDashboardInfoBalServiceMapper delegate;
	

	@Override
	public DEPACCTQRYAPIType mapToApi(AcctDashboardInfoBalJpe jpe, @Context CbsXmlApiOperation oper){
		
		DEPACCTQRYAPIType req = (DEPACCTQRYAPIType)delegate.mapToApi(jpe, oper);
		
		//Other things to do
		
		return  req;
	}
	
	@Override
	public AcctDashboardInfoBalJpe mapToJpe(DEPACCTQRYAPIType api, @MappingTarget AcctDashboardInfoBalJpe jpe){
		
		delegate.mapToJpe(api, jpe);
		
		//Other things to do
		
		return jpe;
	}
	

	
	
}


