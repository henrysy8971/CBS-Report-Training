package com.silverlakesymmetri.cbs.dep.svc.impl;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.mysema.query.types.EntityPath;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.jpa.util.DateTimeHelper;
import com.silverlakesymmetri.cbs.commons.svc.AbstractBusinessService;
import com.silverlakesymmetri.cbs.commons.util.CbsStringUtil;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.SdbTranHistQry;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.QSdbTranHistQryJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.SdbTranHistQryJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.id.SdbTranHistQryPk;
import com.silverlakesymmetri.cbs.dep.svc.SdbTranHistQryService;

@Service
@Transactional
public class SdbTranHistQryServiceImpl
		extends AbstractBusinessService<SdbTranHistQry, SdbTranHistQryJpe, SdbTranHistQryPk>
		implements SdbTranHistQryService {

	@Autowired
	private DateTimeHelper dateHelper;

	@Override
	protected EntityPath<SdbTranHistQryJpe> getEntityPath() {
		return QSdbTranHistQryJpe.sdbTranHistQryJpe;
	}

	@Override
	protected SdbTranHistQryPk getIdFromDataObjectInstance(SdbTranHistQry dataObject) {
		return new SdbTranHistQryPk(dataObject.getSeqNo(), dateHelper.getDate(dataObject.getTranDate()));
	}

	@Override
	public SdbTranHistQry getByPk(String publicKey, SdbTranHistQry reference) {
		SdbTranHistQry bdo = super.getByPk(publicKey, reference);
		if (bdo != null) bdo.setTerminalId(CbsStringUtil.maskIpAddr(bdo.getTerminalId()));
		return bdo;
	}

	@Override
	public List<SdbTranHistQry> query(int offset, int resultLimit, String groupBy, String order,
			Map<String, Object> filters) {
		List<SdbTranHistQry> list = super.query(offset, resultLimit, groupBy, order, filters);
		if (list != null) {
			for (SdbTranHistQry bdo : list) {
				bdo.setTerminalId(CbsStringUtil.maskIpAddr(bdo.getTerminalId()));
			}
		}
		return list;
	}

	@Override
	public List<SdbTranHistQry> find(FindCriteria findCriteria, CbsHeader cbsHeader) {
		List<SdbTranHistQry> list = super.find(findCriteria, cbsHeader);
		if (list != null) {
			for (SdbTranHistQry bdo : list) {
				bdo.setTerminalId(CbsStringUtil.maskIpAddr(bdo.getTerminalId()));
			}
		}
		return list;
	}

}
