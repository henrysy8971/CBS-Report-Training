package com.silverlakesymmetri.cbs.dep.svc.mapper.mapping;

import org.mapstruct.MapperConfig;
import org.mapstruct.Mapping;
import org.mapstruct.Mappings;

import com.silverlakesymmetri.cbs.commons.jpa.util.DateTimeHelper;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.SdbAcctJpe;
import com.silverlakesymmetri.cbs.dep.xmlapi.DEPSDBCLOSUREAPIType;

@MapperConfig(uses={ DateTimeHelper.class})
public interface SdbAcctToDEPSDBCLOSUREAPITypeMapper {

	@Mappings({
		@Mapping(source="contractNo", target ="CONTRACTNO"), 
		@Mapping(source="sdbInternalKey", target ="SDBINTERNALKEY"), 
		@Mapping(source="boxNo", target ="BOXNO"	), 
		@Mapping(source="closeDate", target ="CLOSEDATE", qualifiedByName = {"DateTimeHelper","convertDateToCbsXmlApiDate"}),
		@Mapping(source="closureReason", target ="CLOSUREREASON")
	 })
	public DEPSDBCLOSUREAPIType mapSdbAcctToDEPSDBCLOSUREAPIType(SdbAcctJpe  jpe);
}
