package com.silverlakesymmetri.cbs.dep.svc;

import java.util.List;
import java.util.Map;

import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation;
import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation.ServiceOperationType;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.svc.BusinessService;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.InterModuleTran;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.InterModuleTranJpe;

public interface InterModuleTranService extends BusinessService<InterModuleTran, InterModuleTranJpe> {

	public static final String SVC_OP_NAME_INTERMODULETRANSERVICE_GET = "InterModuleTranService.get";
	public static final String SVC_OP_NAME_INTERMODULETRANSERVICE_QUERY = "InterModuleTranService.query";
	public static final String SVC_OP_NAME_INTERMODULETRANSERVICE_FIND = "InterModuleTranService.find";
	public static final String SVC_OP_NAME_INTERMODULETRANSERVICE_COUNT = "InterModuleTranService.count";

	@ServiceOperation(name = SVC_OP_NAME_INTERMODULETRANSERVICE_GET, type = ServiceOperationType.GET)
	public InterModuleTran getByPk(String publicKey, InterModuleTran reference);

	@ServiceOperation(name = SVC_OP_NAME_INTERMODULETRANSERVICE_QUERY)
	public List<InterModuleTran> query(int offset, int resultLimit, String groupBy, String order,
			Map<String, Object> filters);

	@ServiceOperation(name = SVC_OP_NAME_INTERMODULETRANSERVICE_FIND)
	public List<InterModuleTran> find(FindCriteria findCriteria, CbsHeader cbsHeader);

	@ServiceOperation(name = SVC_OP_NAME_INTERMODULETRANSERVICE_COUNT, type = ServiceOperationType.GET)
	public Long count(FindCriteria findCriteria, CbsHeader cbsHeader);

}
