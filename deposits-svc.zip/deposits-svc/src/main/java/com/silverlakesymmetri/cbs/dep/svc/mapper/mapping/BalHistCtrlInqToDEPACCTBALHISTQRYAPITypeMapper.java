package com.silverlakesymmetri.cbs.dep.svc.mapper.mapping;

import org.mapstruct.Mapping;
import org.mapstruct.Mappings;

import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.BalHistCtrlInqJpe;
import com.silverlakesymmetri.cbs.dep.xmlapi.DEPACCTBALHISTQRYAPIType;

public interface BalHistCtrlInqToDEPACCTBALHISTQRYAPITypeMapper {

	@Mappings({
		@Mapping(source="internalKey", target ="INTERNALKEY"), 
		@Mapping(source="month", target ="MONTH"), 
		@Mapping(source="year", target ="YEAR"	)
	 })
	public DEPACCTBALHISTQRYAPIType mapBalHistCtrlInqToDEPACCTBALHISTQRYAPIType(BalHistCtrlInqJpe jpe);
}