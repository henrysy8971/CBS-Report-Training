package com.silverlakesymmetri.cbs.dep.svc.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.mysema.query.types.EntityPath;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.jpa.service.CbsGenericDataService;
import com.silverlakesymmetri.cbs.commons.jpa.util.DateTimeHelper;
import com.silverlakesymmetri.cbs.commons.svc.AbstractXmlApiBusinessService;
import com.silverlakesymmetri.cbs.commons.xmlapi.enums.CbsXmlApiOperation;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.AcctIntMaint;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.AcctIntMaintJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.AcctJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.QAcctIntMaintJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.util.DepJpeConstants;
import com.silverlakesymmetri.cbs.dep.svc.AcctIntMaintService;
import com.silverlakesymmetri.cbs.dep.svc.mapper.AcctIntMaintServiceMapper;
import com.silverlakesymmetri.cbs.dep.xmlapi.DEPACCTINTMAINTAPIType;

@Service
@Transactional
public class AcctIntMaintServiceImpl extends AbstractXmlApiBusinessService<AcctIntMaint, AcctIntMaintJpe, Long, DEPACCTINTMAINTAPIType, DEPACCTINTMAINTAPIType> implements AcctIntMaintService {

	@Autowired
	AcctIntMaintServiceMapper mapper;
		
    @Autowired
    private DateTimeHelper dateTimeHelper;

	@Autowired
	protected CbsGenericDataService dataService;

	@Override
	protected EntityPath<AcctIntMaintJpe> getEntityPath() {
		return QAcctIntMaintJpe.acctIntMaintJpe;
	}

	@Override
	protected Long getIdFromDataObjectInstance(AcctIntMaint dataObject) {
		return dataObject.getSeqNo();
	}

	@Override
	public AcctIntMaint getByPk(String publicKey, AcctIntMaint reference) {
		AcctIntMaint acctInt = super.getByPk(publicKey, reference);
		if(acctInt.getModifiedBy() == null){
			acctInt.setLastChangeDate(acctInt.getCreatedDt());
			acctInt.setLastChangeOfficer(acctInt.getCreatedBy());
		} else {
			acctInt.setLastChangeDate(acctInt.getModifiedDt());
			acctInt.setLastChangeOfficer(acctInt.getModifiedBy());
		}
		return acctInt;
	}
	
	@Override
	public AcctIntMaint preCreateValidation(AcctIntMaint dataObject) {
		Long nextSeqNo = dataService.nextSequenceValue("DEP_ACCT_INT_MAINT_S");
		dataObject.setSeqNo(nextSeqNo);
		return super.preCreateValidation(dataObject);
	}

	@Override
	public AcctIntMaint create(AcctIntMaint dataObject) {
		return super.create(dataObject);
	}

	@Override
	public AcctIntMaint update(AcctIntMaint dataObject) {
		return super.update(dataObject);
	}
	
	@Override
	public List<AcctIntMaint> query(int offset, int resultLimit, String groupBy, String order,
			Map<String, Object> filters) {
		return super.query(offset, resultLimit, groupBy, order, filters);
	}
	
	@Override
	public boolean delete(AcctIntMaint dataObject) {
		return super.delete(dataObject);
	}

	@Override
	public List<AcctIntMaint> find(FindCriteria findCriteria, CbsHeader cbsHeader) {
		return super.find(findCriteria, cbsHeader);
	}

	@Override
	protected Class<DEPACCTINTMAINTAPIType> getXmlApiResponseClass() {
		return DEPACCTINTMAINTAPIType.class;
	}

	@Override
	protected List<AcctIntMaint> processXmlApiListRs(AcctIntMaint arg0, DEPACCTINTMAINTAPIType arg1) {
		return null;
	}

	@Override
	protected AcctIntMaint processXmlApiRs(AcctIntMaint dataObject, DEPACCTINTMAINTAPIType xmlApiRs) {
		AcctIntMaintJpe jpe = jaxbSdoHelper.unwrap(dataObject);
		mapper.mapToJpe(xmlApiRs, jpe);
		dataObject = jaxbSdoHelper.wrap(jpe);
		return dataObject;
	}

	@Override
	protected DEPACCTINTMAINTAPIType transformBdoToXmlApiRqCreate(AcctIntMaint dataObject) {
		return transformAcctIntMaintToDEPACCTINTMAINTAPIType(dataObject, CbsXmlApiOperation.INSERT);
	}

	@Override
	protected DEPACCTINTMAINTAPIType transformBdoToXmlApiRqDelete(AcctIntMaint dataObject) {
		return transformAcctIntMaintToDEPACCTINTMAINTAPIType(dataObject, CbsXmlApiOperation.DELETE);
	}

	@Override
	protected DEPACCTINTMAINTAPIType transformBdoToXmlApiRqUpdate(AcctIntMaint dataObject) {
		return transformAcctIntMaintToDEPACCTINTMAINTAPIType(dataObject, CbsXmlApiOperation.UPDATE);
	}
	
	private DEPACCTINTMAINTAPIType transformAcctIntMaintToDEPACCTINTMAINTAPIType(AcctIntMaint dataObject, CbsXmlApiOperation oper){
		Map map = new HashMap();
		AcctIntMaintJpe jpe = jaxbSdoHelper.unwrap(dataObject, AcctIntMaintJpe.class);
		Map<String,Object> param = new HashMap<String, Object>();
		param.put("acctNo", jpe.getAcctNo());
		List<AcctJpe> acctJpeList = dataService.findWithNamedQuery(DepJpeConstants.ACCT_JPE_FIND_BY_ACCTNO, param, AcctJpe.class);
		if(acctJpeList != null && acctJpeList.size() > 0){
			AcctJpe acct = acctJpeList.get(0);
			jpe.setInternalKey(acct.getInternalKey());
		}
		DEPACCTINTMAINTAPIType apiType =  mapper.mapToApi(jpe, oper, map);
		super.setTechColsFromDataObject(dataObject, apiType);
		return apiType;
	}

}
