package com.silverlakesymmetri.cbs.dep.svc;

import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation;
import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation.ServiceOperationType;
import com.silverlakesymmetri.cbs.commons.svc.BusinessService;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.ChequeAssign;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.ChequeAssignJpe;

public interface ChequeAssignService extends BusinessService<ChequeAssign, ChequeAssignJpe> {
	
	public static final String SVC_OP_NAME_CHEQUEASSIGNSERVICE_CREATE = "ChequeAssignService.create";
	public static final String SVC_OP_NAME_CHEQUEASSIGNSERVICE_GET= "ChequeAssignService.get";
	
	@ServiceOperation(name = SVC_OP_NAME_CHEQUEASSIGNSERVICE_CREATE)
	public ChequeAssign create(ChequeAssign dataObject);
	
	@ServiceOperation(name = SVC_OP_NAME_CHEQUEASSIGNSERVICE_GET, type = ServiceOperationType.GET)
	public ChequeAssign get(ChequeAssign chequeAssign);
}
