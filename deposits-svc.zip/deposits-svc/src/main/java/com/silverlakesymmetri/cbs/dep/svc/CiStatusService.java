package com.silverlakesymmetri.cbs.dep.svc;

import java.util.List;
import java.util.Map;

import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation;
import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation.ServiceOperationType;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.svc.BusinessService;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.CiStatus;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.CiStatusJpe;


public interface CiStatusService extends BusinessService<CiStatus, CiStatusJpe> {

    public static final String SVC_OP_NAME_CISTATUS_GET = "CiStatusService.get";
    public static final String SVC_OP_NAME_CISTATUS_CREATE = "CiStatusService.create";
    public static final String SVC_OP_NAME_CISTATUS_UPDATE = "CiStatusService.update";
    public static final String SVC_OP_NAME_CISTATUS_DELETE = "CiStatusService.delete";
    public static final String SVC_OP_NAME_CISTATUS_QUERY = "CiStatusService.query";
    public static final String SVC_OP_NAME_CISTATUS_FIND = "CiStatusService.find";

    @ServiceOperation(name = SVC_OP_NAME_CISTATUS_GET, type = ServiceOperationType.GET)
    public CiStatus getByPk(String publicKey, CiStatus reference);
    
//    @ServiceOperation(name = SVC_OP_NAME_CISTATUS_CREATE)
//    public CiStatus create(CiStatus objectInstanceIdentifier);
//    
//    @ServiceOperation(name = SVC_OP_NAME_CISTATUS_UPDATE)
//    public CiStatus update(CiStatus objectInstanceIdentifier);
//    
//    @ServiceOperation(name = SVC_OP_NAME_CISTATUS_DELETE)
//    public boolean delete(CiStatus objectInstanceIdentifier);
    
    @ServiceOperation(name = SVC_OP_NAME_CISTATUS_QUERY)
    public List<CiStatus> query(int offset, int resultLimit, String groupBy, String order, Map<String, Object> filters);

    @ServiceOperation(name = SVC_OP_NAME_CISTATUS_FIND)
    public List<CiStatus> find(FindCriteria findCriteria, CbsHeader cbsHeader);


}
