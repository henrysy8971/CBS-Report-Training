package com.silverlakesymmetri.cbs.dep.svc.impl;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.mysema.query.types.EntityPath;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.svc.AbstractBusinessService;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.ExternalBank;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.ExternalBankJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.QExternalBankJpe;
import com.silverlakesymmetri.cbs.dep.svc.ExternalBankService;

@Service
@Transactional
public class ExternalBankServiceImpl extends AbstractBusinessService<ExternalBank, ExternalBankJpe, String> implements ExternalBankService {

	@Override
	protected EntityPath<ExternalBankJpe> getEntityPath() {
		return QExternalBankJpe.externalBankJpe;
	}

	@Override
	protected String getIdFromDataObjectInstance(ExternalBank dataObject) {
		return dataObject.getBankRefNo();
	}

	@Override
	public ExternalBank getByPk(String publicKey, ExternalBank reference) {
		return super.getByPk(publicKey, reference);
	}

	@Override
	public ExternalBank create(ExternalBank dataObject) {
		return super.create(dataObject);
	}

	@Override
	public ExternalBank update(ExternalBank dataObject) {
		return super.update(dataObject);
	}

	@Override
	public List<ExternalBank> query(int offset, int resultLimit, String groupBy, String order, Map<String, Object> filters) {
		return super.query(offset, resultLimit, groupBy, order, filters);
	}
	
	@Override
	public boolean delete(ExternalBank dataObject) {
		return super.delete(dataObject);
	}

	@Override
	public List<ExternalBank> find(FindCriteria findCriteria, CbsHeader cbsHeader) {
		return super.find(findCriteria, cbsHeader);
	}

}
