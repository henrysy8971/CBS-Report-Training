package com.silverlakesymmetri.cbs.dep.svc;

import java.util.List;
import java.util.Map;

import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation;
import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation.ServiceOperationType;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.svc.BusinessService;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.DepositSettle;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.DepositSettleJpe;

public interface DepositSettleService extends BusinessService<DepositSettle, DepositSettleJpe> {

    public static final String SVC_OP_NAME_DEPOSITSETTLESERVICE_GET = "DepositSettleService.get";
    public static final String SVC_OP_NAME_DEPOSITSETTLESERVICE_QUERY = "DepositSettleService.query";
    public static final String SVC_OP_NAME_DEPOSITSETTLESERVICE_CREATE = "DepositSettleService.create";
    public static final String SVC_OP_NAME_DEPOSITSETTLESERVICE_UPDATE = "DepositSettleService.update";
    public static final String SVC_OP_NAME_DEPOSITSETTLESERVICE_DELETE = "DepositSettleService.delete";
    public static final String SVC_OP_NAME_DEPOSITSETTLESERVICE_FIND = "DepositSettleService.find";

    @ServiceOperation(name = SVC_OP_NAME_DEPOSITSETTLESERVICE_GET, type = ServiceOperationType.GET)
    public DepositSettle getByPk(String publicKey, DepositSettle reference);

    @ServiceOperation(name = SVC_OP_NAME_DEPOSITSETTLESERVICE_CREATE)
    public DepositSettle create(DepositSettle dataObject);

    @ServiceOperation(name = SVC_OP_NAME_DEPOSITSETTLESERVICE_UPDATE)
    public DepositSettle update(DepositSettle dataObject);

    @ServiceOperation(name = SVC_OP_NAME_DEPOSITSETTLESERVICE_QUERY)
    public List<DepositSettle> query(int offset, int resultLimit, String groupBy, String order, Map<String, Object> filters);

    @ServiceOperation(name = SVC_OP_NAME_DEPOSITSETTLESERVICE_DELETE)
    public boolean delete(DepositSettle dataObject);

    @ServiceOperation(name = SVC_OP_NAME_DEPOSITSETTLESERVICE_FIND)
    public List<DepositSettle> find(FindCriteria findCriteria, CbsHeader cbsHeader);

}
