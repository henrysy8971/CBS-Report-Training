package com.silverlakesymmetri.cbs.dep.svc.impl;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.silverlakesymmetri.cbs.commons.aop.BpmCheckLimitPostProcess;
import com.silverlakesymmetri.cbs.commons.jpa.entity.CbsBpmInfoJpe;
import com.silverlakesymmetri.cbs.commons.svc.LimitsCheckingCapable;
import com.silverlakesymmetri.cbs.lmt.util.ExpEmkObjectHolder;
import com.silverlakesymmetri.cbs.lmt.util.LimitsUtility;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.mysema.query.types.EntityPath;
import com.silverlakesymmetri.cbs.commons.jpa.service.CbsGenericDataService;
import com.silverlakesymmetri.cbs.commons.jpa.util.DateTimeHelper;
import com.silverlakesymmetri.cbs.commons.svc.AbstractXmlApiBusinessService;
import com.silverlakesymmetri.cbs.commons.xmlapi.enums.CbsXmlApiOperation;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.FxBuySell;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.AcctJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.FxBuySellJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.QFxBuySellJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.util.DepJpeConstants;
import com.silverlakesymmetri.cbs.dep.svc.DepositsExpEmkService;
import com.silverlakesymmetri.cbs.dep.svc.FxBuySellService;
import com.silverlakesymmetri.cbs.dep.svc.mapper.FxBuySellServiceMapper;
import com.silverlakesymmetri.cbs.dep.xmlapi.DEPFXBUYSELLAPIType;

@Service
@Transactional
public class FxBuySellServiceImpl extends AbstractXmlApiBusinessService<FxBuySell, FxBuySellJpe, Long,
        DEPFXBUYSELLAPIType, DEPFXBUYSELLAPIType> implements FxBuySellService, LimitsCheckingCapable<FxBuySell> {
	
	@Autowired
	FxBuySellServiceMapper mapper;
		
    @Autowired
    private DateTimeHelper dateTimeHelper;

    @Autowired
    private LimitsUtility limitsUtility;
	
    @Autowired
    private DepositsExpEmkService depositsExpEmkService;

	@Autowired
	protected CbsGenericDataService dataService;

	@Override
	protected EntityPath<FxBuySellJpe> getEntityPath() {
		return QFxBuySellJpe.fxBuySellJpe;
	}

	@Override
	protected Long getIdFromDataObjectInstance(FxBuySell dataObject) {
		return dataObject.getMiscSeqNo();
	}

	@Override
    @BpmCheckLimitPostProcess
	public FxBuySell postTransaction(FxBuySell dataObject) {
        dataObject = executeStoredProcedure(dataObject, shouldPerformValidate(dataObject));
        return dataObject;
    }

	@Override
	protected DEPFXBUYSELLAPIType transformBdoToXmlApiRqCreate(FxBuySell dataObject) {
		return transformFxBuySellToDEPFXBUYSELLAPIType(dataObject, CbsXmlApiOperation.INSERT);
	}

	@Override
	protected DEPFXBUYSELLAPIType transformBdoToXmlApiRqUpdate(FxBuySell dataObject) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	protected DEPFXBUYSELLAPIType transformBdoToXmlApiRqDelete(FxBuySell dataObject) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	protected FxBuySell processXmlApiRs(FxBuySell dataObject, DEPFXBUYSELLAPIType xmlApiRs) {
		FxBuySellJpe jpe = jaxbSdoHelper.unwrap(dataObject);
		mapper.mapToJpe(xmlApiRs, jpe);
		dataObject = jaxbSdoHelper.wrap(jpe);
		return dataObject;
	}

	@Override
	protected Class<DEPFXBUYSELLAPIType> getXmlApiResponseClass() {
		return DEPFXBUYSELLAPIType.class;
	}
	
	private DEPFXBUYSELLAPIType transformFxBuySellToDEPFXBUYSELLAPIType(FxBuySell dataObject, CbsXmlApiOperation oper){
		Map map = new HashMap();
		FxBuySellJpe jpe = jaxbSdoHelper.unwrap(dataObject);
		DEPFXBUYSELLAPIType apiType =  mapper.mapToApi(jpe, oper, map);
		super.setTechColsFromDataObject(dataObject, apiType);
		return apiType;
	}

	@Override
	protected List<FxBuySell> processXmlApiListRs(FxBuySell dataObject, DEPFXBUYSELLAPIType xmlApiRs) {
		return null;
	}

	@Override
	protected FxBuySell preCreateValidation(FxBuySell dataObject) {
		defaultFields(dataObject);
		return super.preCreateValidation(dataObject);
	}

	private void defaultFields(FxBuySell dataObject) {
		if (dataObject != null) {
			if (dataObject.getPostDate() == null) {
				dataObject.setPostDate(dateTimeHelper.getSDODateTime(dateTimeHelper.getRunDate()));
			}
			if (dataObject.getTranDate() == null) {
				dataObject.setTranDate(dateTimeHelper.getSDODateTime(dateTimeHelper.getRunDate()));
			}
			if (dataObject.getSourceModule() == null) {
				dataObject.setSourceModule("DEP");
			}
			if (dataObject.getMiscSeqNo() == null) {
				dataObject.setMiscSeqNo(-1L);
			}
		}
	}

    @Override
    public CbsBpmInfoJpe doCheckLimit(FxBuySell dataObject) {
        if (dataObject.getAcctNo() != null) {
            ExpEmkObjectHolder expEmkObject = getExpEmkObjectHolder(dataObject);
            return limitsUtility.getLimitExceptionApprover(expEmkObject, dataObject);
        }
        return null;
    }

    @Override
    public FxBuySell getLimitExceptions(FxBuySell dataObject) {
        if (dataObject.getAcctNo() != null) {
            ExpEmkObjectHolder expEmkObject = getExpEmkObjectHolder(dataObject);
            return limitsUtility.getLimitExceptionDetails(expEmkObject, dataObject);
        }
        return null;
    }

    private ExpEmkObjectHolder getExpEmkObjectHolder(FxBuySell dataObject){
        AcctJpe acctJpe = null;
        Map<String,Object> param = new HashMap<String, Object>();
        param.put("acctNo", dataObject.getAcctNo());
        List<AcctJpe> acctJpeList = dataService.findWithNamedQuery(DepJpeConstants.ACCT_JPE_FIND_BY_ACCTNO, param, AcctJpe.class);
        acctJpe = acctJpeList.get(0);
        ExpEmkObjectHolder expEmkObject = null;
        if (dataObject.getPaymentType().equals("CRTA")) {
            expEmkObject = depositsExpEmkService.getLimitsDetails(dataObject, acctJpe,
                    DepositsExpEmkServiceImpl.DEP_EVENT_TYPE, DepositsExpEmkServiceImpl.CR_AMT_TYPE);
        }else {
            expEmkObject = depositsExpEmkService.getLimitsDetails(dataObject, acctJpe,
                    DepositsExpEmkServiceImpl.WHD_EVENT_TYPE, DepositsExpEmkServiceImpl.DR_AMT_TYPE);
        }
        return expEmkObject;
    }

	@Override
	public Long getEffectivityDate(FxBuySell dataObject) {
		if (dataObject != null) {
			if (!StringUtils.isBlank(dataObject.getEffectDate())) {
				Date date = dateTimeHelper.getDate(dataObject.getEffectDate());
				if (date != null) {
					return dateTimeHelper.removeTime(date).getTime();
				}
			}
		}
		return null;
	}
}
