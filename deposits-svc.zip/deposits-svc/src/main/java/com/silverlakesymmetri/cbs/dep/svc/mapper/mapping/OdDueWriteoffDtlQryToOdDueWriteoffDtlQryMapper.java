package com.silverlakesymmetri.cbs.dep.svc.mapper.mapping;

import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.OdDueWriteoffDtlJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.OdDueWriteoffDtlQryJpe;
import org.mapstruct.Mapper;

@Mapper
public interface OdDueWriteoffDtlQryToOdDueWriteoffDtlQryMapper {
	
	public OdDueWriteoffDtlQryJpe toOdDueWriteoffDtlQry(OdDueWriteoffDtlJpe apiType);
	
	public OdDueWriteoffDtlJpe toOdDueWriteoffDtl(OdDueWriteoffDtlQryJpe jpe);
	
}
