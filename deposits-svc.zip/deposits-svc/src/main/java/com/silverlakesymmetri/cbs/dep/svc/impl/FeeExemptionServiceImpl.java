package com.silverlakesymmetri.cbs.dep.svc.impl;

import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mysema.query.types.EntityPath;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.svc.AbstractBusinessService;
import com.silverlakesymmetri.cbs.commons.svc.BusinessObjectValidationCapable;
import com.silverlakesymmetri.cbs.commons.svc.ref.ReferenceNumberGeneratorService;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.FeeExemption;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.FeeExemptionJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.QFeeExemptionJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.id.FeeExemptionPk;
import com.silverlakesymmetri.cbs.dep.svc.FeeExemptionService;

@Service
public class FeeExemptionServiceImpl extends AbstractBusinessService<FeeExemption, FeeExemptionJpe, FeeExemptionPk>
		implements FeeExemptionService, BusinessObjectValidationCapable<FeeExemption> {

	@Autowired
	private ReferenceNumberGeneratorService referenceNumberGeneratorService;

	@Override
	protected FeeExemptionPk getIdFromDataObjectInstance(FeeExemption dataObject) {
		return new FeeExemptionPk(dataObject.getFeeExemptRefNo());
	}

	@Override
	protected EntityPath<FeeExemptionJpe> getEntityPath() {
		return QFeeExemptionJpe.feeExemptionJpe;
	}

	@Override
	public List<FeeExemption> query(int offset, int resultLimit, String groupBy, String order,
			Map<String, Object> filters) {
		return super.query(offset, resultLimit, groupBy, order, filters);
	}

	@Override
	public FeeExemption getByPk(String publicKey, FeeExemption reference) {
		return super.getByPk(publicKey, reference);
	}

	@Override
	public FeeExemption create(FeeExemption dataObject) {
		return super.create(dataObject);
	}

	@Override
	public FeeExemption update(FeeExemption dataObject) {
		return super.update(dataObject);
	}

	@Override
	public boolean delete(FeeExemption dataObject) {
		return super.delete(dataObject);
	}

	@Override
	public List<FeeExemption> find(FindCriteria findCriteria, CbsHeader cbsHeader) {
		return super.find(findCriteria, cbsHeader);
	}

	@Override
	protected FeeExemption preCreateValidation(FeeExemption dataObject) {
		if (StringUtils.isBlank(dataObject.getFeeExemptRefNo())) {
			referenceNumberGeneratorService.getNewRefNo(dataObject, "feeExemptRefNo");
		}
		return super.preCreateValidation(dataObject);
	}
}
