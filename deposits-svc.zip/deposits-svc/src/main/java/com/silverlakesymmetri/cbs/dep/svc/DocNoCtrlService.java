package com.silverlakesymmetri.cbs.dep.svc;

import java.util.List;
import java.util.Map;

import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation;
import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation.ServiceOperationType;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.svc.BusinessService;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.DocNoCtrl;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.DocNoCtrlJpe;

/**
 * 
 * @author Jeffrey.Villanueva
 *
 */
public interface DocNoCtrlService extends BusinessService<DocNoCtrl, DocNoCtrlJpe> {
	public static final String SVC_OP_NAME_DOCNOCTRLSERVICE_GET = "DocNoCtrlService.get";
    public static final String SVC_OP_NAME_DOCNOCTRLSERVICE_UPDATE = "DocNoCtrlService.update";
    public static final String SVC_OP_NAME_DOCNOCTRLSERVICE_QUERY = "DocNoCtrlService.query";
    public static final String SVC_OP_NAME_DOCNOCTRLSERVICE_FIND = "DocNoCtrlService.find";
    public static final String SVC_OP_NAME_DOCNOCTRLSERVICE_CREATE = "DocNoCtrlService.create";
    public static final String SVC_OP_NAME_DOCNOCTRLSERVICE_DELETE = "DocNoCtrlService.delete";
    
    @ServiceOperation(name = SVC_OP_NAME_DOCNOCTRLSERVICE_QUERY)
    public List<DocNoCtrl> query(int offset, int resultLimit, String groupBy, String order, Map<String, Object> filters);

    @ServiceOperation(name = SVC_OP_NAME_DOCNOCTRLSERVICE_CREATE)
    public DocNoCtrl create(DocNoCtrl dataObject);

    @ServiceOperation(name = SVC_OP_NAME_DOCNOCTRLSERVICE_UPDATE)
    public DocNoCtrl update(DocNoCtrl dataObject);   
    
    @ServiceOperation(name = SVC_OP_NAME_DOCNOCTRLSERVICE_DELETE)
    public boolean delete(DocNoCtrl dataObject);
    
    @ServiceOperation(name = SVC_OP_NAME_DOCNOCTRLSERVICE_GET, type = ServiceOperationType.GET)
    public DocNoCtrl getByPk(String publicKey, DocNoCtrl reference);
    
    @ServiceOperation(name = SVC_OP_NAME_DOCNOCTRLSERVICE_FIND)
    public List<DocNoCtrl> find(FindCriteria findCriteria, CbsHeader cbsHeader);

}
