package com.silverlakesymmetri.cbs.dep.svc.impl;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.mysema.query.types.EntityPath;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.svc.AbstractBusinessService;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.AcctCard;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.AcctCardJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.QAcctCardJpe;
import com.silverlakesymmetri.cbs.dep.svc.AcctCardService;

@Service
@Transactional
public class AcctCardServiceImpl extends AbstractBusinessService<AcctCard, AcctCardJpe, String> implements AcctCardService {

	@Override
	protected EntityPath<AcctCardJpe> getEntityPath() {
		return QAcctCardJpe.acctCardJpe;
	}

	@Override
	protected String getIdFromDataObjectInstance(AcctCard dataObject) {
		return dataObject.getAcctNo();
	}

	@Override
	public AcctCard getByPk(String publicKey, AcctCard reference) {
		return super.getByPk(publicKey, reference);
	}

	@Override
	public AcctCard create(AcctCard dataObject) {
		return super.create(dataObject);
	}

	@Override
	public AcctCard update(AcctCard dataObject) {
		return super.update(dataObject);
	}

	@Override
	public List<AcctCard> query(int offset, int resultLimit, String groupBy, String order,
			Map<String, Object> filters) {
		return super.query(offset, resultLimit, groupBy, order, filters);
	}

	@Override
	public boolean delete(AcctCard dataObject) {
		return super.delete(dataObject);
	}

	@Override
	public List<AcctCard> find(FindCriteria findCriteria, CbsHeader cbsHeader) {
		return super.find(findCriteria, cbsHeader);
	}

}
