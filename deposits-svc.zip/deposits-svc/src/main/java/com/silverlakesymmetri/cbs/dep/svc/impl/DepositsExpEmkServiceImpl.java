package com.silverlakesymmetri.cbs.dep.svc.impl;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import org.restlet.engine.util.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.config.ConfigurableBeanFactory;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;

import com.silverlakesymmetri.cbs.commons.bdo.CbsBusinessDataObject;
import com.silverlakesymmetri.cbs.commons.context.CbsRuntimeContextManager;
import com.silverlakesymmetri.cbs.commons.jpa.extension.JaxbSdoHelper;
import com.silverlakesymmetri.cbs.commons.jpa.service.CbsGenericDataService;
import com.silverlakesymmetri.cbs.commons.jpa.util.BdoHelper;
import com.silverlakesymmetri.cbs.commons.jpa.util.DateTimeHelper;
import com.silverlakesymmetri.cbs.core.util.CcyConversionObject;
import com.silverlakesymmetri.cbs.csd.jpa.mapping.sdo.CurrencyJpe;
import com.silverlakesymmetri.cbs.csd.svc.CcyConversionService;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.Acct;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.BillTranHist;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.DepositTransaction;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.FeeManualCharges;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.FxBuySell;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.TdDepositTransaction;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.TdTransferTransaction;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.TdaHist;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.TranHist;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.TransferTransaction;
import com.silverlakesymmetri.cbs.dep.enums.DepExpEmkAmtTypeEnum;
import com.silverlakesymmetri.cbs.dep.enums.DepExpEmkEventEnum;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.AcctJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.TranDefJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.TranHistJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.id.TranHistPk;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.util.DepJpeConstants;
import com.silverlakesymmetri.cbs.dep.svc.DepUtilityService;
import com.silverlakesymmetri.cbs.dep.svc.DepositsExpEmkService;
import com.silverlakesymmetri.cbs.lmt.bdo.sdo.ExposureEarmarkProcess;
import com.silverlakesymmetri.cbs.lmt.jpa.mapping.sdo.ExpEmkAvailExcessJpe;
import com.silverlakesymmetri.cbs.lmt.jpa.mapping.sdo.ExposureEarmarkProcessJpe;
import com.silverlakesymmetri.cbs.lmt.jpa.mapping.sdo.FacilityLinkageJpe;
import com.silverlakesymmetri.cbs.lmt.svc.ExposureEarmarkProcessService;
import com.silverlakesymmetri.cbs.lmt.svc.FacilityLinkageService;
import com.silverlakesymmetri.cbs.lmt.util.ExpEmkObjectHolder;

@Service
@Scope(ConfigurableBeanFactory.SCOPE_PROTOTYPE)
public class DepositsExpEmkServiceImpl implements DepositsExpEmkService {

	@Autowired
    private JaxbSdoHelper jaxbSdoHelper;
	
	@Autowired(required = true)
    @Qualifier("cbsGenericDataService")
    protected CbsGenericDataService dataService;

	@Autowired
	private CcyConversionService ccyConversionService;
	
	@Autowired
	private DepUtilityService depUtilityService;
	
	@Autowired
	private DateTimeHelper dateTimeHelper;
	
    @Autowired
    private CbsRuntimeContextManager cbsRuntimeContextManager;

    @Autowired
    private BdoHelper bdoHelper;
    
    @Autowired
    private FacilityLinkageService facilityLinkageService;
    
    @Autowired
    private ExposureEarmarkProcessService exposureEarmarkProcessingService;

    public static final String DR_AMT_TYPE = DepExpEmkAmtTypeEnum.DR.toString();
	public static final String WHD_EVENT_TYPE = DepExpEmkEventEnum.WHD.toString();
	public static final String CR_AMT_TYPE = DepExpEmkAmtTypeEnum.CR.toString();
	public static final String DEP_EVENT_TYPE = DepExpEmkEventEnum.DEP.toString();
	private ExposureEarmarkProcess createReverseExpEmk(ExpEmkObjectHolder bdo, Map<String,Object> oldValues) {
        ExposureEarmarkProcessJpe expEmkJpe = new ExposureEarmarkProcessJpe();
        expEmkJpe.setProductCode(bdo.getProductCode());
        expEmkJpe.setLimitsEventName(bdo.getLimitsEventName());
        expEmkJpe.setLimitsAmountType(bdo.getLimitsAmountType());
        expEmkJpe.setReversalYn(bdo.getReversalType() == "N" ? false : true);
        expEmkJpe.setModuleCode(bdo.getModuleCode());
        expEmkJpe.setExpEmkObjectType(bdo.getExpEmkObjectType());
        expEmkJpe.setExpEmkObjectKey(bdo.getExpEmkObjectKey());
        expEmkJpe.setExpEmkRefNo(bdo.getExpEmkRefNo());
        expEmkJpe.setBranch(bdo.getBranch());

        expEmkJpe.setClientNo(bdo.getClientNoCtp());
        expEmkJpe.setCcyExpEmk(bdo.getCcyValue());
        expEmkJpe.setOrigExpEmkAmt(bdo.getValueAmt().doubleValue());
        
        expEmkJpe.setManagerCode(bdo.getManagerCode());
        expEmkJpe.setProfitCentre(bdo.getProfitCentre());
        expEmkJpe.setTradeBookCode(bdo.getTradeBookCode());
        expEmkJpe.setTranDt(bdo.getTranDt());
        expEmkJpe.setEffectDt(bdo.getEffectDt());
        expEmkJpe.setMaturityDt(bdo.getMaturityDt());
        expEmkJpe.setForcePostYn(bdo.getForcePostYn());
        expEmkJpe.setProductAccountNo(bdo.getProductAccountNo());

        if (expEmkJpe.isReversalYn()) {
            expEmkJpe.setExpiredYn(false);
            expEmkJpe.setHistoryYn(bdo.getHistoryYn());
        }

        ExposureEarmarkProcess expEmkBdo = jaxbSdoHelper.wrap(expEmkJpe);

        if(expEmkJpe.isReversalYn()){
            //Collection<String> attributes = bdoHelper.getAttributeNames(ExternalExpEmk.class, true, false, true, false);
            
            for (Entry<String, Object> oldValue: oldValues.entrySet()){
                String attr = oldValue.getKey();

                if(attr.equals("clientNoCtp")){
                    bdoHelper.setValue(expEmkBdo, "clientNo", oldValue.getValue());
                }else if(attr.equals("ccyValue")){
                    bdoHelper.setValue(expEmkBdo, "ccyExpEmk", oldValue.getValue());
                }else if(attr.equals("valueAmt")){
                    bdoHelper.setValue(expEmkBdo, "origExpEmkAmt", oldValue.getValue());
                }else{
                    bdoHelper.setValue(expEmkBdo, oldValue.getKey(), oldValue.getValue());
                }
            }
        }

        exposureEarmarkProcessingService.prepareExpEmk(expEmkBdo, bdo.getReversalType());
        
        return expEmkBdo;
    }
	
	private void sortExpEmkAvailExcessList(ExpEmkObjectHolder expEmkObject) {
		if (expEmkObject != null && expEmkObject.getDataExtensionList() != null && expEmkObject.getDataExtensionList().size() > 0) {
			if (expEmkObject != null && expEmkObject.getDataExtensionList() != null && expEmkObject.getDataExtensionList().size() > 0) {
				for (CbsBusinessDataObject dataExtObject : expEmkObject.getDataExtensionList()) {
					if (dataExtObject != null && ExposureEarmarkProcess.class.isInstance(dataExtObject)) {
						ExposureEarmarkProcess expEarProcess = ExposureEarmarkProcess.class.cast(dataExtObject);
						ExposureEarmarkProcessJpe expEarProcessJpe = jaxbSdoHelper.unwrap(expEarProcess);
						if (expEarProcessJpe.getExpEmkAvailExcessList().size() > 0) {
							List<ExpEmkAvailExcessJpe> sortedList = new ArrayList<ExpEmkAvailExcessJpe>();
							sortedList.addAll(expEarProcessJpe.getExpEmkAvailExcessList());
							Collections.sort(sortedList);
							expEarProcessJpe.setExpEmkAvailExcessList(sortedList);
						}
					}
				}
			}
		}
	}
	
	@Override
	public ExpEmkObjectHolder generateBusinessRoleDataExtList(ExpEmkObjectHolder expEmkObject,
			Map<String, Object> oldValues) {

		// sanity check, there should be no entry here
		if (expEmkObject.getDataExtensionList() == null) {
		    expEmkObject.setDataExtensionList(new ArrayList<CbsBusinessDataObject>());
		} else if (expEmkObject.getDataExtensionList().size() > 0) {
		    expEmkObject.getDataExtensionList().clear();
		}
		
		ExposureEarmarkProcess expEarProcessResult = createReverseExpEmk(expEmkObject,oldValues);
        if (expEarProcessResult != null) {
            expEmkObject.getDataExtensionList().add(expEarProcessResult);
        }
		// sort ExpEmkAvailExcessList
		sortExpEmkAvailExcessList(expEmkObject);
		
		return expEmkObject;
	}

	@Override
	public Map<String, Object> whoIsMyApprover(ExpEmkObjectHolder expEmkObject) {
		return exposureEarmarkProcessingService.whoIsMyApprover(expEmkObject);
	}

	@Override
	public void processDataExtensionList(ExpEmkObjectHolder expEmkObject) {
		exposureEarmarkProcessingService.processDataExtensionList(expEmkObject);
	}
	
	@Override
	public List<FacilityLinkageJpe> getFacilityLinkageSetup(String productCode, String eventName, String amtType) {
	    List<FacilityLinkageJpe> linkages = facilityLinkageService.getFacilityCodeListBy(productCode,
	    		eventName, amtType);
	    
	    return linkages;
		
	}
	
	@Override
    public String getDefaultRateType() {
        return getRegistryEntry(DepJpeConstants.STRING_DEPOSIT_REGISTRY, DepJpeConstants.STRING_DEPOSIT_REGISTRY_DEFAULT_RATE_TYPE, String.class);
    }

    @Override
    public <T> T getRegistryEntry(String registryName, String entryName, Class<T> valueType) {
        return cbsRuntimeContextManager.getBestAvailableContext().getRegistryEntry(registryName, entryName, valueType);
    }

	private ExpEmkObjectHolder parseDepToLmt(AcctJpe jpe, Acct bdo, String reversal, TdDepositTransaction txnBdo, String eventType, String amtType) {

		Double postAmt = txnBdo.getEquivAmount(); //jpe.getActualBal() + txnBdo.getEquivAmount();
		Date defaultMaturityDt = null;
		if (eventType.equals(WHD_EVENT_TYPE) || eventType.equals(DEP_EVENT_TYPE)) {
	        try {
	        	DateFormat format = new SimpleDateFormat("dd/MM/yyyy");
	        	defaultMaturityDt=format.parse("31/12/2999");
	        } catch (Exception e) {
	            throw new RuntimeException("Error encountered converting date " + "31/12/2999", e);
	        }
		}
		if (eventType.equals(WHD_EVENT_TYPE) && jpe.getActualBal()<0 ){
				postAmt = jpe.getActualBal() + txnBdo.getEquivAmount();
		}
		if (eventType.equals(DEP_EVENT_TYPE) ) {
			if (jpe.getActualBal() - txnBdo.getEquivAmount()<0) {
				postAmt = jpe.getActualBal();	
			}
			
		}
		ExpEmkObjectHolder expEmkObj = new ExpEmkObjectHolder();
		expEmkObj.setBookDt(dateTimeHelper.getRunDate());
		expEmkObj.setBranch(bdo.getBranch());
		expEmkObj.setCcyValue(bdo.getCcy());
		expEmkObj.setClientNoCtp(bdo.getClientNo());
		expEmkObj.setEffectDt(dateTimeHelper.getRunDate());
		expEmkObj.setExpEmkObjectType(DepJpeConstants.STRING_DEP_EXP_EMK_OBJECT_TYPE);
		expEmkObj.setExpEmkObjectKey(jpe.getAcctNo());
		expEmkObj.setExpEmkRefNo(jpe.getAcctNo());
		expEmkObj.setForcePostYn(false);
		expEmkObj.setLimitsAmountType(amtType);
		expEmkObj.setLimitsEventName(eventType);
		expEmkObj.setManagerCode(bdo.getOfficerId());
		expEmkObj.setEffectDt(dateTimeHelper.getRunDate());
		expEmkObj.setModuleCode(DepJpeConstants.STRING_DEP_MODULE);
		expEmkObj.setProductAccountNo(bdo.getAcctNo());
		expEmkObj.setProductCode(bdo.getAcctType());
		expEmkObj.setProfitCentre(bdo.getProfitCentre());
		expEmkObj.setReversalType(reversal);
		expEmkObj.setReversalYn(reversal == "N" ? false : true);
		expEmkObj.setStatus("A");
		expEmkObj.setEffectDt(dateTimeHelper.getRunDate());
		expEmkObj.setTranDt(dateTimeHelper.getRunDate());
		expEmkObj.setMaturityDt(defaultMaturityDt);
		
		expEmkObj.setValueAmt(postAmt);
        
		return expEmkObj;
	}
	
	private ExpEmkObjectHolder parseDepToLmt(AcctJpe jpe, Acct bdo, String reversal, DepositTransaction txnBdo, String eventType, String amtType) {

		Double postAmt = txnBdo.getEquivAmount(); //jpe.getActualBal() + txnBdo.getEquivAmount();
		Date defaultMaturityDt = null;
		if (eventType.equals(WHD_EVENT_TYPE) || eventType.equals(DEP_EVENT_TYPE)) {
	        try {
	        	DateFormat format = new SimpleDateFormat("dd/MM/yyyy");
	        	defaultMaturityDt=format.parse("31/12/2999");
	        } catch (Exception e) {
	            throw new RuntimeException("Error encountered converting date " + "31/12/2999", e);
	        }
		}
		if (eventType.equals(WHD_EVENT_TYPE) && jpe.getActualBal()<0 ){
				postAmt = jpe.getActualBal() + txnBdo.getEquivAmount();
		}
		if (eventType.equals(DEP_EVENT_TYPE) ) {
			if (jpe.getActualBal() - txnBdo.getEquivAmount()<0) {
				postAmt = jpe.getActualBal();	
			}
			
		}
		ExpEmkObjectHolder expEmkObj = new ExpEmkObjectHolder();
		expEmkObj.setBookDt(dateTimeHelper.getRunDate());
		expEmkObj.setBranch(bdo.getBranch());
		expEmkObj.setCcyValue(bdo.getCcy());
		expEmkObj.setClientNoCtp(bdo.getClientNo());
		expEmkObj.setEffectDt(dateTimeHelper.getRunDate());
		expEmkObj.setExpEmkObjectType(DepJpeConstants.STRING_DEP_EXP_EMK_OBJECT_TYPE);
		expEmkObj.setExpEmkObjectKey(jpe.getAcctNo());
		expEmkObj.setExpEmkRefNo(jpe.getAcctNo());
		expEmkObj.setForcePostYn(false);
		expEmkObj.setLimitsAmountType(amtType);
		expEmkObj.setLimitsEventName(eventType);
		expEmkObj.setManagerCode(bdo.getOfficerId());
		expEmkObj.setEffectDt(dateTimeHelper.getRunDate());
		expEmkObj.setModuleCode(DepJpeConstants.STRING_DEP_MODULE);
		expEmkObj.setProductAccountNo(bdo.getAcctNo());
		expEmkObj.setProductCode(bdo.getAcctType());
		expEmkObj.setProfitCentre(bdo.getProfitCentre());
		expEmkObj.setReversalType(reversal);
		expEmkObj.setReversalYn(reversal == "N" ? false : true);
		expEmkObj.setStatus("A");
		expEmkObj.setEffectDt(dateTimeHelper.getRunDate());
		expEmkObj.setTranDt(dateTimeHelper.getRunDate());
		expEmkObj.setMaturityDt(defaultMaturityDt);
		
		expEmkObj.setValueAmt(postAmt);
        
		return expEmkObj;
	}
		
	@Override
	public ExpEmkObjectHolder processLimits(DepositTransaction dataObject, AcctJpe acctJpe, String eventType, String amtType) {
        ExpEmkObjectHolder expEmkObject = getLimitsDetails(dataObject, acctJpe, eventType, amtType);
        processDataExtensionList(expEmkObject);
        return expEmkObject;
	}

    @Override
    public ExpEmkObjectHolder getLimitsDetails(DepositTransaction dataObject, AcctJpe acctJpe, String eventType, String amtType) {
        ExpEmkObjectHolder expEmkObject = null;
        Acct bdo = jaxbSdoHelper.wrap(acctJpe);
        if ((((acctJpe.getActualBal() >= 0 || (acctJpe.getActualBal() < 0 && acctJpe.getActualBal() +
                dataObject.getEquivAmount() > 0)) && eventType.equals(WHD_EVENT_TYPE) && amtType.equals(DR_AMT_TYPE)) ||
                (acctJpe.getActualBal() > 0 && eventType.equals(DEP_EVENT_TYPE) && amtType.equals(CR_AMT_TYPE)))) {

            expEmkObject = this.parseDepToLmt(acctJpe, bdo, "N", dataObject, eventType, amtType);
            expEmkObject = generateBusinessRoleDataExtList(expEmkObject, null);
        }
        return expEmkObject;
    }
	
	@Override
	public ExpEmkObjectHolder processLimits(TdDepositTransaction dataObject, AcctJpe acctJpe, String eventType, String amtType) {
        ExpEmkObjectHolder expEmkObject = getLimitsDetails(dataObject, acctJpe, eventType, amtType);
        processDataExtensionList(expEmkObject);
        return expEmkObject;
	}

    @Override
    public ExpEmkObjectHolder getLimitsDetails(TdDepositTransaction dataObject, AcctJpe acctJpe, String eventType, String amtType) {
        Acct bdo = jaxbSdoHelper.wrap(acctJpe);
        ExpEmkObjectHolder expEmkObject = null;
        if ((((acctJpe.getActualBal() >= 0 || (acctJpe.getActualBal() < 0 && acctJpe.getActualBal() +
                dataObject.getEquivAmount() > 0)) && eventType.equals(WHD_EVENT_TYPE) && amtType.equals(DR_AMT_TYPE)) ||
                (acctJpe.getActualBal() > 0 && eventType.equals(DEP_EVENT_TYPE) && amtType.equals(CR_AMT_TYPE)))) {

            expEmkObject = this.parseDepToLmt(acctJpe, bdo, "N", dataObject, eventType, amtType);
            expEmkObject = generateBusinessRoleDataExtList(expEmkObject, null);
        }
        return expEmkObject;
    }

    @Override
	public ExpEmkObjectHolder processLimits(TransferTransaction dataObject, String eventType, String amtType) {
		AcctJpe acctJpeCr = new AcctJpe();
		AcctJpe acctJpeDr = new AcctJpe();
        ExpEmkObjectHolder expEmkObject = null;
        if (dataObject!=null) {
			if (dataObject.getTransferMode()!=null) {
				if ("CR".equals(dataObject.getTransferMode())) {
					Map<String, Object> param = new HashMap<String, Object>();
					param.put("acctNo", dataObject.getAcctNo());
					acctJpeCr = dataService.getWithNamedQuery(DepJpeConstants.ACCT_JPE_FIND_ACCT_BY_ACCT_NO, param, AcctJpe.class);

					if (dataObject.getTfrDetailList().size()>0) {
						if (dataObject.getTfrDetailList().get(0).getCpartyAcctNo()!=null) {
							Map<String, Object> param2 = new HashMap<String, Object>();
							param2.put("acctNo", dataObject.getTfrDetailList().get(0).getCpartyAcctNo());
							acctJpeDr = dataService.getWithNamedQuery(DepJpeConstants.ACCT_JPE_FIND_ACCT_BY_ACCT_NO, param2, AcctJpe.class);
						}
					}
				}else {
					Map<String, Object> param = new HashMap<String, Object>();
					param.put("acctNo", dataObject.getAcctNo());
					acctJpeDr = dataService.getWithNamedQuery(DepJpeConstants.ACCT_JPE_FIND_ACCT_BY_ACCT_NO, param, AcctJpe.class);

					if (dataObject.getTfrDetailList().size()>0) {
						if (dataObject.getTfrDetailList().get(0).getCpartyAcctNo()!=null) {
							Map<String, Object> param2 = new HashMap<String, Object>();
							param2.put("acctNo", dataObject.getTfrDetailList().get(0).getCpartyAcctNo());
							acctJpeCr = dataService.getWithNamedQuery(DepJpeConstants.ACCT_JPE_FIND_ACCT_BY_ACCT_NO, param2, AcctJpe.class);
						}
					}
				}
				
				//process CR side
				if (acctJpeCr.getActualBal() > 0 ) {
                    expEmkObject = this.parseDepToLmt(dataObject, acctJpeCr, acctJpeDr, "N", DEP_EVENT_TYPE, CR_AMT_TYPE);
                    expEmkObject = generateBusinessRoleDataExtList(expEmkObject, null);
                    processDataExtensionList(expEmkObject);
                }
                //process DR side
				if ((acctJpeDr.getActualBal()>=0 || 
					(acctJpeDr.getActualBal()<0 && acctJpeDr.getActualBal()+convertUsingRate(dataObject, acctJpeCr, acctJpeDr, dataObject.getTfrDetailList().get(0).getAmount())>0) ) 
					) {
                    expEmkObject = this.parseDepToLmt(dataObject, acctJpeCr, acctJpeDr, "N", WHD_EVENT_TYPE, DR_AMT_TYPE);
                    expEmkObject = generateBusinessRoleDataExtList(expEmkObject, null);
                    processDataExtensionList(expEmkObject);
                }

            }
			
		}
        return expEmkObject;
    }

    @Override
    public ExpEmkObjectHolder getLimitsDetails(TransferTransaction dataObject, String eventType, String amtType) {
        AcctJpe acctJpeCr = new AcctJpe();
        AcctJpe acctJpeDr = new AcctJpe();
        ExpEmkObjectHolder expEmkObject = null;
        if (dataObject!=null) {
            if (dataObject.getTransferMode()!=null) {
                if ("CR".equals(dataObject.getTransferMode())) {
                    Map<String, Object> param = new HashMap<String, Object>();
                    param.put("acctNo", dataObject.getAcctNo());
                    acctJpeCr = dataService.getWithNamedQuery(DepJpeConstants.ACCT_JPE_FIND_ACCT_BY_ACCT_NO, param, AcctJpe.class);

                    if (dataObject.getTfrDetailList().size()>0) {
                        if (dataObject.getTfrDetailList().get(0).getCpartyAcctNo()!=null) {
                            Map<String, Object> param2 = new HashMap<String, Object>();
                            param2.put("acctNo", dataObject.getTfrDetailList().get(0).getCpartyAcctNo());
                            acctJpeDr = dataService.getWithNamedQuery(DepJpeConstants.ACCT_JPE_FIND_ACCT_BY_ACCT_NO, param2, AcctJpe.class);
                        }
                    }
                }else {
                    Map<String, Object> param = new HashMap<String, Object>();
                    param.put("acctNo", dataObject.getAcctNo());
                    acctJpeDr = dataService.getWithNamedQuery(DepJpeConstants.ACCT_JPE_FIND_ACCT_BY_ACCT_NO, param, AcctJpe.class);

                    if (dataObject.getTfrDetailList().size()>0) {
                        if (dataObject.getTfrDetailList().get(0).getCpartyAcctNo()!=null) {
                            Map<String, Object> param2 = new HashMap<String, Object>();
                            param2.put("acctNo", dataObject.getTfrDetailList().get(0).getCpartyAcctNo());
                            acctJpeCr = dataService.getWithNamedQuery(DepJpeConstants.ACCT_JPE_FIND_ACCT_BY_ACCT_NO, param2, AcctJpe.class);
                        }
                    }
                }

                //process CR side
                if (acctJpeCr.getActualBal() > 0 ) {
                    expEmkObject = this.parseDepToLmt(dataObject, acctJpeCr, acctJpeDr, "N", DEP_EVENT_TYPE, CR_AMT_TYPE);
                    expEmkObject = generateBusinessRoleDataExtList(expEmkObject, null);
                }
                //process DR side
                if ((acctJpeDr.getActualBal()>=0 ||
                        (acctJpeDr.getActualBal()<0 && acctJpeDr.getActualBal()+convertUsingRate(dataObject, acctJpeCr, acctJpeDr, dataObject.getTfrDetailList().get(0).getAmount())>0) )
                        ) {
                    expEmkObject = this.parseDepToLmt(dataObject, acctJpeCr, acctJpeDr, "N", WHD_EVENT_TYPE, DR_AMT_TYPE);
                    expEmkObject = generateBusinessRoleDataExtList(expEmkObject, null);
                }
            }
        }
        return expEmkObject;
    }

	private ExpEmkObjectHolder parseDepToLmt(TransferTransaction dataObject, AcctJpe acctJpeCr, AcctJpe acctJpeDr, String reversal, String eventType, String amtType) {
		Double postAmt = dataObject.getTfrDetailList().get(0).getEquivAmount(); 
		Double postAmtDr = dataObject.getTfrDetailList().get(0).getEquivAmount(); 
		if (!acctJpeCr.getCcy().equals(acctJpeDr.getCcy())) {
			if ("CR".equals(dataObject.getTransferMode())) {
				postAmtDr = convertUsingRate(dataObject, acctJpeCr, acctJpeDr, dataObject.getTfrDetailList().get(0).getAmount());
			}else {
				postAmt = convertUsingRate(dataObject, acctJpeCr, acctJpeDr, dataObject.getTfrDetailList().get(0).getAmount());
			}
		}
		Date defaultMaturityDt = null;
		if (eventType.equals(WHD_EVENT_TYPE) || eventType.equals(DEP_EVENT_TYPE)) {
	        try {
	        	DateFormat format = new SimpleDateFormat("dd/MM/yyyy");
	        	defaultMaturityDt=format.parse("31/12/2999");
	        } catch (Exception e) {
	            throw new RuntimeException("Error encountered converting date " + "31/12/2999", e);
	        }
		}
		if (eventType.equals(WHD_EVENT_TYPE) && acctJpeDr!= null  ){
			postAmt = postAmtDr;
			if (acctJpeDr.getActualBal()<0) {
				postAmt = acctJpeDr.getActualBal() + postAmtDr;
			}
		}
		
		if (eventType.equals(DEP_EVENT_TYPE) && acctJpeCr!=null ) {
			if (acctJpeCr.getActualBal() - postAmt<0) {
				postAmt = acctJpeCr.getActualBal();	
			}
			
		}
		ExpEmkObjectHolder expEmkObj = new ExpEmkObjectHolder();
		switch(amtType) {
		   case "CR" :
				expEmkObj.setBranch(acctJpeCr.getBranch());
				expEmkObj.setCcyValue(acctJpeCr.getCcy());
				expEmkObj.setClientNoCtp(acctJpeCr.getClientNo());
				expEmkObj.setExpEmkObjectKey(acctJpeCr.getAcctNo());
				expEmkObj.setExpEmkRefNo(acctJpeCr.getAcctNo());
				expEmkObj.setManagerCode(acctJpeCr.getOfficerId());
				expEmkObj.setProductAccountNo(acctJpeCr.getAcctNo());
				expEmkObj.setProductCode(acctJpeCr.getAcctType());
				expEmkObj.setProfitCentre(acctJpeCr.getProfitCentre());
			   break;
		   case "DR" :
				expEmkObj.setBranch(acctJpeDr.getBranch());
				expEmkObj.setCcyValue(acctJpeDr.getCcy());
				expEmkObj.setClientNoCtp(acctJpeDr.getClientNo());
				expEmkObj.setExpEmkObjectKey(acctJpeDr.getAcctNo());
				expEmkObj.setExpEmkRefNo(acctJpeDr.getAcctNo());
				expEmkObj.setManagerCode(acctJpeDr.getOfficerId());
				expEmkObj.setProductAccountNo(acctJpeDr.getAcctNo());
				expEmkObj.setProductCode(acctJpeDr.getAcctType());
				expEmkObj.setProfitCentre(acctJpeDr.getProfitCentre());
			   break;
		}
		expEmkObj.setBookDt(dateTimeHelper.getRunDate());
		expEmkObj.setEffectDt(dateTimeHelper.getRunDate());
		expEmkObj.setExpEmkObjectType(DepJpeConstants.STRING_DEP_EXP_EMK_OBJECT_TYPE);
		expEmkObj.setForcePostYn(false);
		expEmkObj.setLimitsAmountType(amtType);
		expEmkObj.setLimitsEventName(eventType);
		expEmkObj.setEffectDt(dateTimeHelper.getRunDate());
		expEmkObj.setModuleCode(DepJpeConstants.STRING_DEP_MODULE);
		expEmkObj.setReversalType(reversal);
		expEmkObj.setReversalYn(reversal == "N" ? false : true);
		expEmkObj.setStatus("A");
		expEmkObj.setEffectDt(dateTimeHelper.getRunDate());
		expEmkObj.setTranDt(dateTimeHelper.getRunDate());
		expEmkObj.setMaturityDt(defaultMaturityDt);
		
		expEmkObj.setValueAmt(postAmt);

        
		return expEmkObj;
	}
	
	
	@Override
	public ExpEmkObjectHolder processLimits(TdTransferTransaction dataObject, String eventType, String amtType) {
		AcctJpe acctJpeCr = new AcctJpe();
		AcctJpe acctJpeDr = new AcctJpe();
        ExpEmkObjectHolder expEmkObject = null;
        if (dataObject!=null) {
			Map<String, Object> param = new HashMap<String, Object>();
			param.put("acctNo", dataObject.getAcctNo());
			acctJpeCr = dataService.getWithNamedQuery(DepJpeConstants.ACCT_JPE_FIND_ACCT_BY_ACCT_NO, param, AcctJpe.class);

			if (dataObject.getCpartyAcctNo()!=null) {
				Map<String, Object> param2 = new HashMap<String, Object>();
				param2.put("acctNo", dataObject.getCpartyAcctNo());
				acctJpeDr = dataService.getWithNamedQuery(DepJpeConstants.ACCT_JPE_FIND_ACCT_BY_ACCT_NO, param2, AcctJpe.class);
			}
			//process CR side
			if (acctJpeCr.getActualBal() > 0 ) {
                expEmkObject = this.parseDepToLmt(dataObject, acctJpeCr, acctJpeDr, "N", DEP_EVENT_TYPE, CR_AMT_TYPE);
                expEmkObject = generateBusinessRoleDataExtList(expEmkObject, null);
                processDataExtensionList(expEmkObject);
            }
            //process DR side
			if (acctJpeDr!=null && acctJpeDr.getAcctNo()!=null) {
				if ((acctJpeDr.getActualBal()>=0 || 
						(acctJpeDr.getActualBal()<0 && acctJpeDr.getActualBal()+convertUsingRate(dataObject, acctJpeCr, acctJpeDr, dataObject.getAmount())>0) ) 
						) {
                    expEmkObject = this.parseDepToLmt(dataObject, acctJpeCr, acctJpeDr, "N", WHD_EVENT_TYPE, DR_AMT_TYPE);
                    expEmkObject = generateBusinessRoleDataExtList(expEmkObject, null);
                    processDataExtensionList(expEmkObject);
                }
            }
		}
        return expEmkObject;
    }

    @Override
    public ExpEmkObjectHolder getLimitsDetails(TdTransferTransaction dataObject, String eventType, String amtType) {
        AcctJpe acctJpeCr = new AcctJpe();
        AcctJpe acctJpeDr = new AcctJpe();
        ExpEmkObjectHolder expEmkObject = null;
        if (dataObject!=null) {
            Map<String, Object> param = new HashMap<String, Object>();
            param.put("acctNo", dataObject.getAcctNo());
            acctJpeCr = dataService.getWithNamedQuery(DepJpeConstants.ACCT_JPE_FIND_ACCT_BY_ACCT_NO, param, AcctJpe.class);

            if (dataObject.getCpartyAcctNo()!=null) {
                Map<String, Object> param2 = new HashMap<String, Object>();
                param2.put("acctNo", dataObject.getCpartyAcctNo());
                acctJpeDr = dataService.getWithNamedQuery(DepJpeConstants.ACCT_JPE_FIND_ACCT_BY_ACCT_NO, param2, AcctJpe.class);
            }
            //process CR side
            if (acctJpeCr.getActualBal() > 0 ) {
                expEmkObject = this.parseDepToLmt(dataObject, acctJpeCr, acctJpeDr, "N", DEP_EVENT_TYPE, CR_AMT_TYPE);
                expEmkObject = generateBusinessRoleDataExtList(expEmkObject, null);
            }
            //process DR side
            if (acctJpeDr!=null && acctJpeDr.getAcctNo()!=null) {
                if ((acctJpeDr.getActualBal()>=0 ||
                        (acctJpeDr.getActualBal()<0 && acctJpeDr.getActualBal()+convertUsingRate(dataObject, acctJpeCr, acctJpeDr, dataObject.getAmount())>0) )
                        ) {
                    expEmkObject = this.parseDepToLmt(dataObject, acctJpeCr, acctJpeDr, "N", WHD_EVENT_TYPE, DR_AMT_TYPE);
                    expEmkObject = generateBusinessRoleDataExtList(expEmkObject, null);
                }
            }
        }
        return expEmkObject;
    }
	
	private ExpEmkObjectHolder parseDepToLmt(TdTransferTransaction dataObject, AcctJpe acctJpeCr, AcctJpe acctJpeDr, String reversal, String eventType, String amtType) {
		Double postAmt = dataObject.getEquivAmount(); 
		Double postAmtDr = dataObject.getEquivAmount(); 
		if (!acctJpeCr.getCcy().equals(acctJpeDr.getCcy())) {
			if (acctJpeDr!=null) {
				postAmtDr = convertUsingRate(dataObject, acctJpeCr, acctJpeDr, dataObject.getAmount());
			}
		}
		Date defaultMaturityDt = null;
		if (eventType.equals(WHD_EVENT_TYPE) || eventType.equals(DEP_EVENT_TYPE)) {
	        try {
	        	DateFormat format = new SimpleDateFormat("dd/MM/yyyy");
	        	defaultMaturityDt=format.parse("31/12/2999");
	        } catch (Exception e) {
	            throw new RuntimeException("Error encountered converting date " + "31/12/2999", e);
	        }
		}
		if (eventType.equals(WHD_EVENT_TYPE) && acctJpeDr!= null  ){
			postAmt = postAmtDr;
			if (acctJpeDr.getActualBal()<0) {
				postAmt = acctJpeDr.getActualBal() + postAmtDr;
			}
		}
		
		if (eventType.equals(DEP_EVENT_TYPE) && acctJpeCr!=null ) {
			if (acctJpeCr.getActualBal() - postAmt<0) {
				postAmt = acctJpeCr.getActualBal();	
			}
			
		}
		ExpEmkObjectHolder expEmkObj = new ExpEmkObjectHolder();
		switch(amtType) {
		   case "CR" :
				expEmkObj.setBranch(acctJpeCr.getBranch());
				expEmkObj.setCcyValue(acctJpeCr.getCcy());
				expEmkObj.setClientNoCtp(acctJpeCr.getClientNo());
				expEmkObj.setExpEmkObjectKey(acctJpeCr.getAcctNo());
				expEmkObj.setExpEmkRefNo(acctJpeCr.getAcctNo());
				expEmkObj.setManagerCode(acctJpeCr.getOfficerId());
				expEmkObj.setProductAccountNo(acctJpeCr.getAcctNo());
				expEmkObj.setProductCode(acctJpeCr.getAcctType());
				expEmkObj.setProfitCentre(acctJpeCr.getProfitCentre());
			   break;
		   case "DR" :
				expEmkObj.setBranch(acctJpeDr.getBranch());
				expEmkObj.setCcyValue(acctJpeDr.getCcy());
				expEmkObj.setClientNoCtp(acctJpeDr.getClientNo());
				expEmkObj.setExpEmkObjectKey(acctJpeDr.getAcctNo());
				expEmkObj.setExpEmkRefNo(acctJpeDr.getAcctNo());
				expEmkObj.setManagerCode(acctJpeDr.getOfficerId());
				expEmkObj.setProductAccountNo(acctJpeDr.getAcctNo());
				expEmkObj.setProductCode(acctJpeDr.getAcctType());
				expEmkObj.setProfitCentre(acctJpeDr.getProfitCentre());
			   break;
		}
		expEmkObj.setBookDt(dateTimeHelper.getRunDate());
		expEmkObj.setEffectDt(dateTimeHelper.getRunDate());
		expEmkObj.setExpEmkObjectType(DepJpeConstants.STRING_DEP_EXP_EMK_OBJECT_TYPE);
		expEmkObj.setForcePostYn(false);
		expEmkObj.setLimitsAmountType(amtType);
		expEmkObj.setLimitsEventName(eventType);
		expEmkObj.setEffectDt(dateTimeHelper.getRunDate());
		expEmkObj.setModuleCode(DepJpeConstants.STRING_DEP_MODULE);
		expEmkObj.setReversalType(reversal);
		expEmkObj.setReversalYn(reversal == "N" ? false : true);
		expEmkObj.setStatus("A");
		expEmkObj.setEffectDt(dateTimeHelper.getRunDate());
		expEmkObj.setTranDt(dateTimeHelper.getRunDate());
		expEmkObj.setMaturityDt(defaultMaturityDt);
		
		expEmkObj.setValueAmt(postAmt);

        
		return expEmkObj;
	}
		
	private Double convertUsingRate(TransferTransaction txnBdo, AcctJpe acctJpeCr, AcctJpe acctJpeDr, Double fromAmt) {
		Double amount = fromAmt;
		
		//assign to ccyconversionobject and call ccyconversion to get proper conversion factor used
		String xrateType = getDefaultRateType();
		String tranType = null;
		String toCcy = null;
		String fromCcy = null;
		String branch = null;
		if ("CR".equals(txnBdo.getTransferMode())) {
			tranType = txnBdo.getDebitTranType();
			toCcy = acctJpeDr.getCcy();
			fromCcy = acctJpeCr.getCcy();
			branch = acctJpeDr.getBranch();
		}else {
			tranType = txnBdo.getCreditTranType();
			toCcy = acctJpeCr.getCcy();
			fromCcy = acctJpeDr.getCcy();
			branch = acctJpeCr.getBranch();
		}
		TranDefJpe tranDefJpe = dataService.find(TranDefJpe.class, tranType);
		if (tranDefJpe!=null) {
			if (tranDefJpe.getRateType()!=null&&!tranDefJpe.getRateType().isEmpty()) {
				xrateType=tranDefJpe.getRateType();
			}
		}
		
		CcyConversionObject obj = new CcyConversionObject();
		
        if (fromCcy != null && toCcy != null && toCcy.equals(fromCcy)) {
            return amount;
        } else {
        	obj.setxRateType(xrateType);
            obj.setTranType(tranType);
        	obj.setBranch(branch);
            obj.setCrDrInd(tranDefJpe.getCrDrMaintInd());
            obj.setFromCcy(fromCcy);
            obj.setFromAmt(amount);
            obj.setToCcy(toCcy);
            obj.setToAmt(0d);
            obj.setTranDt(dateTimeHelper.getRunDate());
            obj.setMarginRate(0d);
            obj.setCrossRate(0d);
            obj.setFormatYn(true);
            
            obj = depUtilityService.getEquivalentAmount(obj);
            amount = obj.getToAmt();
        }		
		
		CurrencyJpe ccyJpe = dataService.find(CurrencyJpe.class, toCcy);
		if (ccyJpe!=null) {
			return (ccyConversionService.formatAmt(amount, toCcy, ccyJpe.getRoundTrunc(), ccyJpe.getDeciPlaces()));
		}
		return amount;
	}
	
	private Double convertUsingRate(TdTransferTransaction txnBdo, AcctJpe acctJpeCr, AcctJpe acctJpeDr, Double fromAmt) {
		Double amount = fromAmt;
		
		//assign to ccyconversionobject and call ccyconversion to get proper conversion factor used
		
		CcyConversionObject obj = new CcyConversionObject();
		String xrateType = getDefaultRateType();
		String tranType = null;
		String toCcy = null;
		String fromCcy = null;
		String branch = null;
			tranType = txnBdo.getDebitTranType();
			toCcy = acctJpeDr.getCcy();
			fromCcy = acctJpeCr.getCcy();
			branch = acctJpeDr.getBranch();

		TranDefJpe tranDefJpe = dataService.find(TranDefJpe.class, tranType);
		if (tranDefJpe!=null) {
			if (tranDefJpe.getRateType()!=null&&!tranDefJpe.getRateType().isEmpty()) {
				xrateType=tranDefJpe.getRateType();
			}
		}
		
        if (fromCcy != null && toCcy != null && toCcy.equals(fromCcy)) {
            return amount;
        } else {
        	obj.setxRateType(xrateType);
            obj.setTranType(tranType);
        	obj.setBranch(branch);
            obj.setCrDrInd(tranDefJpe.getCrDrMaintInd());
            obj.setFromCcy(fromCcy);
            obj.setFromAmt(amount);
            obj.setToCcy(toCcy);
            obj.setToAmt(0d);
            obj.setTranDt(dateTimeHelper.getRunDate());
            obj.setMarginRate(0d);
            obj.setCrossRate(0d);
            obj.setFormatYn(true);
            
            obj = depUtilityService.getEquivalentAmount(obj);
            amount = obj.getToAmt();
        }		
		
		CurrencyJpe ccyJpe = dataService.find(CurrencyJpe.class, toCcy);
		if (ccyJpe!=null) {
			return (ccyConversionService.formatAmt(amount, toCcy, ccyJpe.getRoundTrunc(), ccyJpe.getDeciPlaces()));
		}
		return amount;
	}
		
	@Override
	public ExpEmkObjectHolder processLimits(TdaHist dataObject, String eventType, String amtType) {
		AcctJpe acctJpeCr = new AcctJpe();
		AcctJpe acctJpeDr = new AcctJpe();
        ExpEmkObjectHolder expEmkObject = null;
        double amt = 0d;
		if (dataObject!=null) {
			Map<String, Object> param = new HashMap<String, Object>();
			param.put("acctNo", dataObject.getAcctNo());
			acctJpeDr = dataService.getWithNamedQuery(DepJpeConstants.ACCT_JPE_FIND_ACCT_BY_ACCT_NO, param, AcctJpe.class);

			if (dataObject.getTdaPymtDtlsList()!=null && dataObject.getTdaPymtDtlsList().size() > 0 && dataObject.getTdaPymtDtlsList().get(0).getTranAmtTdCcy()!=null) {
				
				amt = Math.abs(dataObject.getTdaPymtDtlsList().get(0).getTranAmtTdCcy());
			}
			
			if (dataObject.getTdaPymtDtlsList()!=null && dataObject.getTdaPymtDtlsList().size() > 0 && dataObject.getTdaPymtDtlsList().get(0).getCrThirdPartyAcct()!=null) {
				
				Map<String, Object> param2 = new HashMap<String, Object>();
				param2.put("acctNo", dataObject.getTdaPymtDtlsList().get(0).getCrThirdPartyAcct());
				acctJpeCr = dataService.getWithNamedQuery(DepJpeConstants.ACCT_JPE_FIND_ACCT_BY_ACCT_NO, param2, AcctJpe.class);
			}
			//process CR side
			if (acctJpeCr != null && acctJpeCr.getActualBal() != null && acctJpeCr.getActualBal() > 0) {
				expEmkObject= this.parseDepToLmt(dataObject, acctJpeCr, acctJpeDr, "N", DEP_EVENT_TYPE, CR_AMT_TYPE);
		        expEmkObject = generateBusinessRoleDataExtList(expEmkObject, null);
		        processDataExtensionList(expEmkObject);			
			}
			//process DR side
			if (acctJpeDr!=null && acctJpeDr.getAcctNo()!=null) {
				if (acctJpeDr.getActualBal() == null) acctJpeDr.setActualBal(0d);
				if ((acctJpeDr.getActualBal()>=0 || 
						(acctJpeDr.getActualBal()<0 && acctJpeDr.getActualBal()+amt>0) ) 
						) {
                    expEmkObject = this.parseDepToLmt(dataObject, acctJpeCr, acctJpeDr, "N", WHD_EVENT_TYPE, DR_AMT_TYPE);
                    expEmkObject = generateBusinessRoleDataExtList(expEmkObject, null);
                    processDataExtensionList(expEmkObject);
                }
            }
			
		}
        return expEmkObject;
    }

    @Override
    public ExpEmkObjectHolder getLimitsDetails(TdaHist dataObject, String eventType, String amtType) {
        AcctJpe acctJpeCr = new AcctJpe();
        AcctJpe acctJpeDr = new AcctJpe();
        ExpEmkObjectHolder expEmkObject = null;
        double amt = 0d;
        if (dataObject!=null) {
            Map<String, Object> param = new HashMap<String, Object>();
            param.put("acctNo", dataObject.getAcctNo());
            acctJpeDr = dataService.getWithNamedQuery(DepJpeConstants.ACCT_JPE_FIND_ACCT_BY_ACCT_NO, param, AcctJpe.class);

            if (dataObject.getTdaPymtDtlsList()!=null && dataObject.getTdaPymtDtlsList().size() > 0 && dataObject.getTdaPymtDtlsList().get(0).getTranAmtTdCcy()!=null) {

                amt = Math.abs(dataObject.getTdaPymtDtlsList().get(0).getTranAmtTdCcy());
            }

            if (dataObject.getTdaPymtDtlsList()!=null && dataObject.getTdaPymtDtlsList().size() > 0 ) {
            	if (!StringUtils.isNullOrEmpty(dataObject.getTdaPymtDtlsList().get(0).getCrThirdPartyAcct())) {
                    Map<String, Object> param2 = new HashMap<String, Object>();
                    param2.put("acctNo", dataObject.getTdaPymtDtlsList().get(0).getCrThirdPartyAcct());
                    acctJpeCr = dataService.getWithNamedQuery(DepJpeConstants.ACCT_JPE_FIND_ACCT_BY_ACCT_NO, param2, AcctJpe.class);
            	}
            }
            //process CR side
            if (acctJpeCr!=null &
                    (acctJpeCr.getActualBal() > 0 )) {
                expEmkObject = this.parseDepToLmt(dataObject, acctJpeCr, acctJpeDr, "N", DEP_EVENT_TYPE, CR_AMT_TYPE);
                expEmkObject = generateBusinessRoleDataExtList(expEmkObject, null);
            }
            //process DR side
            if (acctJpeDr!=null && acctJpeDr.getAcctNo()!=null) {
                if ((acctJpeDr.getActualBal()>=0 ||
                        (acctJpeDr.getActualBal()<0 && acctJpeDr.getActualBal()+amt>0) )
                        ) {
                    expEmkObject = this.parseDepToLmt(dataObject, acctJpeCr, acctJpeDr, "N", WHD_EVENT_TYPE, DR_AMT_TYPE);
                    expEmkObject = generateBusinessRoleDataExtList(expEmkObject, null);
                }
            }

        }
        return expEmkObject;
    }

	private ExpEmkObjectHolder parseDepToLmt(TdaHist dataObject, AcctJpe acctJpeCr, AcctJpe acctJpeDr, String reversal, String eventType, String amtType) {
		Double postAmt = Math.abs(dataObject.getTdaPymtDtlsList().get(0).getTranAmtTdCcy()); 
		Double postAmtDr = postAmt; 

		Date defaultMaturityDt = null;
		if (eventType.equals(WHD_EVENT_TYPE) || eventType.equals(DEP_EVENT_TYPE)) {
	        try {
	        	DateFormat format = new SimpleDateFormat("dd/MM/yyyy");
	        	defaultMaturityDt=format.parse("31/12/2999");
	        } catch (Exception e) {
	            throw new RuntimeException("Error encountered converting date " + "31/12/2999", e);
	        }
		}
		if (eventType.equals(WHD_EVENT_TYPE) && acctJpeDr!= null  ){
			postAmt = postAmtDr;
			if (acctJpeDr.getActualBal()<0) {
				postAmt = acctJpeDr.getActualBal() + postAmtDr;
			}
		}
		
		if (eventType.equals(DEP_EVENT_TYPE) && acctJpeCr!=null ) {
			if (acctJpeCr.getActualBal() - postAmt<0) {
				postAmt = acctJpeCr.getActualBal();	
			}
			
		}
		ExpEmkObjectHolder expEmkObj = new ExpEmkObjectHolder();
		switch(amtType) {
		   case "CR" :
				expEmkObj.setBranch(acctJpeCr.getBranch());
				expEmkObj.setCcyValue(acctJpeCr.getCcy());
				expEmkObj.setClientNoCtp(acctJpeCr.getClientNo());
				expEmkObj.setExpEmkObjectKey(acctJpeCr.getAcctNo());
				expEmkObj.setExpEmkRefNo(acctJpeCr.getAcctNo());
				expEmkObj.setManagerCode(acctJpeCr.getOfficerId());
				expEmkObj.setProductAccountNo(acctJpeCr.getAcctNo());
				expEmkObj.setProductCode(acctJpeCr.getAcctType());
				expEmkObj.setProfitCentre(acctJpeCr.getProfitCentre());
			   break;
		   case "DR" :
				expEmkObj.setBranch(acctJpeDr.getBranch());
				expEmkObj.setCcyValue(acctJpeDr.getCcy());
				expEmkObj.setClientNoCtp(acctJpeDr.getClientNo());
				expEmkObj.setExpEmkObjectKey(acctJpeDr.getAcctNo());
				expEmkObj.setExpEmkRefNo(acctJpeDr.getAcctNo());
				expEmkObj.setManagerCode(acctJpeDr.getOfficerId());
				expEmkObj.setProductAccountNo(acctJpeDr.getAcctNo());
				expEmkObj.setProductCode(acctJpeDr.getAcctType());
				expEmkObj.setProfitCentre(acctJpeDr.getProfitCentre());
			   break;
		}
		expEmkObj.setBookDt(dateTimeHelper.getRunDate());
		expEmkObj.setEffectDt(dateTimeHelper.getRunDate());
		expEmkObj.setExpEmkObjectType(DepJpeConstants.STRING_DEP_EXP_EMK_OBJECT_TYPE);
		expEmkObj.setForcePostYn(false);
		expEmkObj.setLimitsAmountType(amtType);
		expEmkObj.setLimitsEventName(eventType);
		expEmkObj.setEffectDt(dateTimeHelper.getRunDate());
		expEmkObj.setModuleCode(DepJpeConstants.STRING_DEP_MODULE);
		expEmkObj.setReversalType(reversal);
		expEmkObj.setReversalYn(reversal == "N" ? false : true);
		expEmkObj.setStatus("A");
		expEmkObj.setEffectDt(dateTimeHelper.getRunDate());
		expEmkObj.setTranDt(dateTimeHelper.getRunDate());
		expEmkObj.setMaturityDt(defaultMaturityDt);
		
		expEmkObj.setValueAmt(postAmt);

		return expEmkObj;
	}
	
	@Override
	public ExpEmkObjectHolder processLimits(TranHist dataObject, String eventType, String amtType) {
        ExpEmkObjectHolder expEmkObject = null;
		AcctJpe acctJpeCr = new AcctJpe();
		AcctJpe acctJpeDr = new AcctJpe();
		TranHistJpe tranHistJpe = jaxbSdoHelper.unwrap(dataObject, TranHistJpe.class);
		TranHistJpe tranHistDrCtrJpe = new TranHistJpe();
		TranHistJpe tranHistCrCtrJpe = new TranHistJpe();
		if (dataObject!=null) {
			if (dataObject.getCrDrMaintInd()!=null) {
				if ("D".equals(dataObject.getCrDrMaintInd())) {
					Map<String, Object> param = new HashMap<String, Object>();
					param.put("acctNo", dataObject.getAcctNo());
					acctJpeCr = dataService.getWithNamedQuery(DepJpeConstants.ACCT_JPE_FIND_ACCT_BY_ACCT_NO, param, AcctJpe.class);

					if (dataObject.getTfrSeqNo()!=null) {

						TranHistPk tranHistPk = new TranHistPk();
						tranHistPk.setSeqNo(dataObject.getTfrSeqNo());
						tranHistPk.setTranDate(tranHistJpe.getTranDate());
						tranHistDrCtrJpe = dataService.find(TranHistJpe.class, tranHistPk);
						if (tranHistDrCtrJpe.getAcctNo()!=null) {
							Map<String, Object> param2 = new HashMap<String, Object>();
							param2.put("acctNo", tranHistDrCtrJpe.getAcctNo());
							acctJpeDr = dataService.getWithNamedQuery(DepJpeConstants.ACCT_JPE_FIND_ACCT_BY_ACCT_NO, param2, AcctJpe.class);
						}
					}

				}else {
					Map<String, Object> param = new HashMap<String, Object>();
					param.put("acctNo", dataObject.getAcctNo());
					acctJpeDr = dataService.getWithNamedQuery(DepJpeConstants.ACCT_JPE_FIND_ACCT_BY_ACCT_NO, param, AcctJpe.class);

					if (dataObject.getTfrSeqNo()!=null) {
						TranHistPk tranHistPk = new TranHistPk();
						tranHistPk.setSeqNo(dataObject.getTfrSeqNo());
						tranHistPk.setTranDate(tranHistJpe.getTranDate());
						tranHistCrCtrJpe = dataService.find(TranHistJpe.class, tranHistPk);
						
						if (tranHistCrCtrJpe.getAcctNo()!=null) {
							Map<String, Object> param2 = new HashMap<String, Object>();
							param2.put("acctNo", tranHistCrCtrJpe.getAcctNo());
							acctJpeCr = dataService.getWithNamedQuery(DepJpeConstants.ACCT_JPE_FIND_ACCT_BY_ACCT_NO, param2, AcctJpe.class);

						}
					}
				}
				//process CR side
				if (acctJpeCr!=null && acctJpeCr.getAcctNo()!=null) {
					if (acctJpeCr.getActualBal() > 0 ) {
						if ("D".equals(dataObject.getCrDrMaintInd())) {
                            expEmkObject = this.parseDepToLmt(dataObject, acctJpeCr, "N", DEP_EVENT_TYPE, CR_AMT_TYPE);
                        }else {
                            expEmkObject = this.parseDepToLmt(jaxbSdoHelper.wrap(tranHistCrCtrJpe, TranHist.class), acctJpeCr, "N", DEP_EVENT_TYPE, CR_AMT_TYPE);
                        }
                        expEmkObject = generateBusinessRoleDataExtList(expEmkObject, null);
				        processDataExtensionList(expEmkObject);			
					}					
				}
				//process DR side
				if (acctJpeDr!=null && acctJpeDr.getAcctNo()!=null) {
					expEmkObject = null;
					if ("C".equals(dataObject.getCrDrMaintInd())) {
						if ((acctJpeDr.getActualBal()>=0 || 
								(acctJpeDr.getActualBal()<0 && acctJpeDr.getActualBal()+(dataObject.getTranAmt())>0) ) 
								) {
                            expEmkObject = this.parseDepToLmt(dataObject, acctJpeDr, "N", WHD_EVENT_TYPE, DR_AMT_TYPE);
                            expEmkObject = generateBusinessRoleDataExtList(expEmkObject, null);
                            processDataExtensionList(expEmkObject);
                        }

                    }else {
						TranHist tranHistDr = jaxbSdoHelper.wrap(tranHistDrCtrJpe, TranHist.class);
						if ((acctJpeDr.getActualBal()>=0 || 
								(acctJpeDr.getActualBal()<0 && acctJpeDr.getActualBal()+(tranHistDr.getTranAmt())>0) ) 
								) {
                            expEmkObject = this.parseDepToLmt(tranHistDr, acctJpeDr, "N", WHD_EVENT_TYPE, DR_AMT_TYPE);
                            expEmkObject = generateBusinessRoleDataExtList(expEmkObject, null);
                            processDataExtensionList(expEmkObject);
                        }
                    }
				}					
			}			
		}
        return expEmkObject;
	}

    @Override
    public ExpEmkObjectHolder getLimitsDetails(TranHist dataObject, String eventType, String amtType) {
        ExpEmkObjectHolder expEmkObject = null;
        AcctJpe acctJpeCr = new AcctJpe();
        AcctJpe acctJpeDr = new AcctJpe();
        TranHistJpe tranHistJpe = jaxbSdoHelper.unwrap(dataObject, TranHistJpe.class);
        TranHistJpe tranHistDrCtrJpe = new TranHistJpe();
        TranHistJpe tranHistCrCtrJpe = new TranHistJpe();
        if (dataObject!=null) {
            if (dataObject.getCrDrMaintInd()!=null) {
                if ("D".equals(dataObject.getCrDrMaintInd())) {
                    Map<String, Object> param = new HashMap<String, Object>();
                    param.put("acctNo", dataObject.getAcctNo());
                    acctJpeCr = dataService.getWithNamedQuery(DepJpeConstants.ACCT_JPE_FIND_ACCT_BY_ACCT_NO, param, AcctJpe.class);

                    if (dataObject.getTfrSeqNo()!=null) {

                        TranHistPk tranHistPk = new TranHistPk();
                        tranHistPk.setSeqNo(dataObject.getTfrSeqNo());
                        tranHistPk.setTranDate(tranHistJpe.getTranDate());
                        tranHistDrCtrJpe = dataService.find(TranHistJpe.class, tranHistPk);
                        if (tranHistDrCtrJpe.getAcctNo()!=null) {
                            Map<String, Object> param2 = new HashMap<String, Object>();
                            param2.put("acctNo", tranHistDrCtrJpe.getAcctNo());
                            acctJpeDr = dataService.getWithNamedQuery(DepJpeConstants.ACCT_JPE_FIND_ACCT_BY_ACCT_NO, param2, AcctJpe.class);
                        }
                    }

                }else {
                    Map<String, Object> param = new HashMap<String, Object>();
                    param.put("acctNo", dataObject.getAcctNo());
                    acctJpeDr = dataService.getWithNamedQuery(DepJpeConstants.ACCT_JPE_FIND_ACCT_BY_ACCT_NO, param, AcctJpe.class);

                    if (dataObject.getTfrSeqNo()!=null) {
                        TranHistPk tranHistPk = new TranHistPk();
                        tranHistPk.setSeqNo(dataObject.getTfrSeqNo());
                        tranHistPk.setTranDate(tranHistJpe.getTranDate());
                        tranHistCrCtrJpe = dataService.find(TranHistJpe.class, tranHistPk);

                        if (tranHistCrCtrJpe.getAcctNo()!=null) {
                            Map<String, Object> param2 = new HashMap<String, Object>();
                            param2.put("acctNo", tranHistCrCtrJpe.getAcctNo());
                            acctJpeCr = dataService.getWithNamedQuery(DepJpeConstants.ACCT_JPE_FIND_ACCT_BY_ACCT_NO, param2, AcctJpe.class);

                        }
                    }
                }
                //process CR side
                if (acctJpeCr!=null && acctJpeCr.getAcctNo()!=null) {
                    if (acctJpeCr.getActualBal() > 0 ) {
                        if ("D".equals(dataObject.getCrDrMaintInd())) {
                            expEmkObject = this.parseDepToLmt(dataObject, acctJpeCr, "N", DEP_EVENT_TYPE, CR_AMT_TYPE);
                        }else {
                            expEmkObject = this.parseDepToLmt(jaxbSdoHelper.wrap(tranHistCrCtrJpe, TranHist.class), acctJpeCr, "N", DEP_EVENT_TYPE, CR_AMT_TYPE);
                        }
                        expEmkObject = generateBusinessRoleDataExtList(expEmkObject, null);
                    }
                }
                //process DR side
                if (acctJpeDr!=null && acctJpeDr.getAcctNo()!=null) {
                    expEmkObject = null;
                    if ("C".equals(dataObject.getCrDrMaintInd())) {
                        if ((acctJpeDr.getActualBal()>=0 ||
                                (acctJpeDr.getActualBal()<0 && acctJpeDr.getActualBal()+(dataObject.getTranAmt())>0) )
                                ) {
                            expEmkObject = this.parseDepToLmt(dataObject, acctJpeDr, "N", WHD_EVENT_TYPE, DR_AMT_TYPE);
                            expEmkObject = generateBusinessRoleDataExtList(expEmkObject, null);
                        }

                    }else {
                        TranHist tranHistDr = jaxbSdoHelper.wrap(tranHistDrCtrJpe, TranHist.class);
                        if ((acctJpeDr.getActualBal()>=0 ||
                                (acctJpeDr.getActualBal()<0 && acctJpeDr.getActualBal()+(tranHistDr.getTranAmt())>0) )
                                ) {
                            expEmkObject = this.parseDepToLmt(tranHistDr, acctJpeDr, "N", WHD_EVENT_TYPE, DR_AMT_TYPE);
                            expEmkObject = generateBusinessRoleDataExtList(expEmkObject, null);
                        }
                    }
                }
            }
        }
        return expEmkObject;
    }
	
	private ExpEmkObjectHolder parseDepToLmt(TranHist dataObject, AcctJpe acctJpe, String reversal, String eventType, String amtType) {
		Double postAmt = dataObject.getTranAmt(); 
		Date defaultMaturityDt = null;
		if (eventType.equals(WHD_EVENT_TYPE) || eventType.equals(DEP_EVENT_TYPE)) {
	        try {
	        	DateFormat format = new SimpleDateFormat("dd/MM/yyyy");
	        	defaultMaturityDt=format.parse("31/12/2999");
	        } catch (Exception e) {
	            throw new RuntimeException("Error encountered converting date " + "31/12/2999", e);
	        }
		}
		if (eventType.equals(WHD_EVENT_TYPE) && acctJpe!= null && acctJpe.getAcctNo()!=null  ){
			if (acctJpe.getActualBal()<0) {
				postAmt = acctJpe.getActualBal() + postAmt;
			}
		}
		
		if (eventType.equals(DEP_EVENT_TYPE) && acctJpe!=null && acctJpe.getAcctNo()!=null) {
			if (acctJpe.getActualBal() - postAmt<0) {
				postAmt = acctJpe.getActualBal();	
			}
			
		}
		ExpEmkObjectHolder expEmkObj = new ExpEmkObjectHolder();
		
		expEmkObj.setBranch(acctJpe.getBranch());
		expEmkObj.setCcyValue(acctJpe.getCcy());
		expEmkObj.setClientNoCtp(acctJpe.getClientNo());
		expEmkObj.setExpEmkObjectKey(acctJpe.getAcctNo());
		expEmkObj.setExpEmkRefNo(acctJpe.getAcctNo());
		expEmkObj.setManagerCode(acctJpe.getOfficerId());
		expEmkObj.setProductAccountNo(acctJpe.getAcctNo());
		expEmkObj.setProductCode(acctJpe.getAcctType());
		expEmkObj.setProfitCentre(acctJpe.getProfitCentre());		
		expEmkObj.setBookDt(dateTimeHelper.getRunDate());
		expEmkObj.setEffectDt(dateTimeHelper.getRunDate());
		expEmkObj.setExpEmkObjectType(DepJpeConstants.STRING_DEP_EXP_EMK_OBJECT_TYPE);
		expEmkObj.setForcePostYn(false);
		expEmkObj.setLimitsAmountType(amtType);
		expEmkObj.setLimitsEventName(eventType);
		expEmkObj.setEffectDt(dateTimeHelper.getRunDate());
		expEmkObj.setModuleCode(DepJpeConstants.STRING_DEP_MODULE);
		expEmkObj.setReversalType(reversal);
		expEmkObj.setReversalYn(reversal == "N" ? false : true);
		expEmkObj.setStatus("A");
		expEmkObj.setEffectDt(dateTimeHelper.getRunDate());
		expEmkObj.setTranDt(dateTimeHelper.getRunDate());
		expEmkObj.setMaturityDt(defaultMaturityDt);
		
		expEmkObj.setValueAmt(postAmt);

        
		return expEmkObj;
	}
	
	@Override
	public ExpEmkObjectHolder processLimits(FxBuySell dataObject, AcctJpe acctJpe, String eventType, String amtType) {
        ExpEmkObjectHolder expEmkObject = getLimitsDetails(dataObject, acctJpe, eventType, amtType);
        processDataExtensionList(expEmkObject);
        return expEmkObject;
    }

    @Override
    public ExpEmkObjectHolder getLimitsDetails(FxBuySell dataObject, AcctJpe acctJpe, String eventType, String amtType) {
        ExpEmkObjectHolder expEmkObject = null;
        Acct bdo = jaxbSdoHelper.wrap(acctJpe);
        Double tranAmt = dataObject.getTranAmt();
        if (acctJpe.getCcy().equals(dataObject.getContraCcy())) {
            tranAmt = dataObject.getContraEquivAmt();
        }
        if ((((acctJpe.getActualBal() >= 0 || (acctJpe.getActualBal() < 0 && acctJpe.getActualBal() + tranAmt > 0)) &&
                eventType.equals(WHD_EVENT_TYPE) && amtType.equals(DR_AMT_TYPE) ) || (acctJpe.getActualBal() > 0 &&
                eventType.equals(DEP_EVENT_TYPE) && amtType.equals(CR_AMT_TYPE) ))) {
            expEmkObject = this.parseDepToLmt(acctJpe, bdo, "N", dataObject, eventType, amtType);
            expEmkObject = generateBusinessRoleDataExtList(expEmkObject, null);
        }
        return expEmkObject;
    }

    private ExpEmkObjectHolder parseDepToLmt(AcctJpe jpe, Acct bdo, String reversal, FxBuySell txnBdo, String eventType, String amtType) {
		Double postAmt = txnBdo.getTranAmt(); //jpe.getActualBal() + txnBdo.getEquivAmount();
		if (jpe.getCcy().equals(txnBdo.getContraCcy())) {
			postAmt = txnBdo.getContraEquivAmt();
		}
		Date defaultMaturityDt = null;
		if (eventType.equals(WHD_EVENT_TYPE) || eventType.equals(DEP_EVENT_TYPE)) {
	        try {
	        	DateFormat format = new SimpleDateFormat("dd/MM/yyyy");
	        	defaultMaturityDt=format.parse("31/12/2999");
	        } catch (Exception e) {
	            throw new RuntimeException("Error encountered converting date " + "31/12/2999", e);
	        }
		}
		if (eventType.equals(WHD_EVENT_TYPE) && jpe.getActualBal()<0 ){
				postAmt = jpe.getActualBal() + postAmt;
		}
		if (eventType.equals(DEP_EVENT_TYPE) ) {
			if (jpe.getActualBal() - postAmt<0) {
				postAmt = jpe.getActualBal();	
			}
			
		}
		ExpEmkObjectHolder expEmkObj = new ExpEmkObjectHolder();
		expEmkObj.setBookDt(dateTimeHelper.getRunDate());
		expEmkObj.setBranch(bdo.getBranch());
		expEmkObj.setCcyValue(bdo.getCcy());
		expEmkObj.setClientNoCtp(bdo.getClientNo());
		expEmkObj.setEffectDt(dateTimeHelper.getRunDate());
		expEmkObj.setExpEmkObjectType(DepJpeConstants.STRING_DEP_EXP_EMK_OBJECT_TYPE);
		expEmkObj.setExpEmkObjectKey(jpe.getAcctNo());
		expEmkObj.setExpEmkRefNo(jpe.getAcctNo());
		expEmkObj.setForcePostYn(false);
		expEmkObj.setLimitsAmountType(amtType);
		expEmkObj.setLimitsEventName(eventType);
		expEmkObj.setManagerCode(bdo.getOfficerId());
		expEmkObj.setEffectDt(dateTimeHelper.getRunDate());
		expEmkObj.setModuleCode(DepJpeConstants.STRING_DEP_MODULE);
		expEmkObj.setProductAccountNo(bdo.getAcctNo());
		expEmkObj.setProductCode(bdo.getAcctType());
		expEmkObj.setProfitCentre(bdo.getProfitCentre());
		expEmkObj.setReversalType(reversal);
		expEmkObj.setReversalYn(reversal == "N" ? false : true);
		expEmkObj.setStatus("A");
		expEmkObj.setEffectDt(dateTimeHelper.getRunDate());
		expEmkObj.setTranDt(dateTimeHelper.getRunDate());
		expEmkObj.setMaturityDt(defaultMaturityDt);
		
		expEmkObj.setValueAmt(postAmt);
        
		return expEmkObj;
	}
	
	@Override
	public ExpEmkObjectHolder processLimits(BillTranHist dataObject, AcctJpe acctJpe, String eventType, String amtType) {
        ExpEmkObjectHolder expEmkObject = getLimitsDetails(dataObject, acctJpe, eventType, amtType);
        processDataExtensionList(expEmkObject);
        return expEmkObject;
    }

    @Override
    public ExpEmkObjectHolder getLimitsDetails(BillTranHist dataObject, AcctJpe acctJpe, String eventType, String amtType) {
        ExpEmkObjectHolder expEmkObject = null;
        Acct bdo = jaxbSdoHelper.wrap(acctJpe);
        Double tranAmt = dataObject.getEquivAmt();
        if ((((acctJpe.getActualBal() >= 0 || (acctJpe.getActualBal() < 0 && acctJpe.getActualBal() + tranAmt > 0)) &&
                eventType.equals(WHD_EVENT_TYPE) && amtType.equals(DR_AMT_TYPE)) ||(acctJpe.getActualBal() > 0 &&
                eventType.equals(DEP_EVENT_TYPE) && amtType.equals(CR_AMT_TYPE)))) {
            expEmkObject = this.parseDepToLmt(acctJpe, bdo, "N", dataObject, eventType, amtType);
            expEmkObject = generateBusinessRoleDataExtList(expEmkObject, null);
        }
        return expEmkObject;
    }

    private ExpEmkObjectHolder parseDepToLmt(AcctJpe jpe, Acct bdo, String reversal, BillTranHist txnBdo, String eventType, String amtType) {
		Double postAmt = txnBdo.getEquivAmt(); //jpe.getActualBal() + txnBdo.getEquivAmount();
		
		Date defaultMaturityDt = null;
		if (eventType.equals(WHD_EVENT_TYPE) || eventType.equals(DEP_EVENT_TYPE)) {
	        try {
	        	DateFormat format = new SimpleDateFormat("dd/MM/yyyy");
	        	defaultMaturityDt=format.parse("31/12/2999");
	        } catch (Exception e) {
	            throw new RuntimeException("Error encountered converting date " + "31/12/2999", e);
	        }
		}
		if (eventType.equals(WHD_EVENT_TYPE) && jpe.getActualBal()<0 ){
				postAmt = jpe.getActualBal() + postAmt;
		}
		if (eventType.equals(DEP_EVENT_TYPE) ) {
			if (jpe.getActualBal() - postAmt<0) {
				postAmt = jpe.getActualBal();	
			}
			
		}
		ExpEmkObjectHolder expEmkObj = new ExpEmkObjectHolder();
		expEmkObj.setBookDt(dateTimeHelper.getRunDate());
		expEmkObj.setBranch(bdo.getBranch());
		expEmkObj.setCcyValue(bdo.getCcy());
		expEmkObj.setClientNoCtp(bdo.getClientNo());
		expEmkObj.setEffectDt(dateTimeHelper.getRunDate());
		expEmkObj.setExpEmkObjectType(DepJpeConstants.STRING_DEP_EXP_EMK_OBJECT_TYPE);
		expEmkObj.setExpEmkObjectKey(jpe.getAcctNo());
		expEmkObj.setExpEmkRefNo(jpe.getAcctNo());
		expEmkObj.setForcePostYn(false);
		expEmkObj.setLimitsAmountType(amtType);
		expEmkObj.setLimitsEventName(eventType);
		expEmkObj.setManagerCode(bdo.getOfficerId());
		expEmkObj.setEffectDt(dateTimeHelper.getRunDate());
		expEmkObj.setModuleCode(DepJpeConstants.STRING_DEP_MODULE);
		expEmkObj.setProductAccountNo(bdo.getAcctNo());
		expEmkObj.setProductCode(bdo.getAcctType());
		expEmkObj.setProfitCentre(bdo.getProfitCentre());
		expEmkObj.setReversalType(reversal);
		expEmkObj.setReversalYn(reversal == "N" ? false : true);
		expEmkObj.setStatus("A");
		expEmkObj.setEffectDt(dateTimeHelper.getRunDate());
		expEmkObj.setTranDt(dateTimeHelper.getRunDate());
		expEmkObj.setMaturityDt(defaultMaturityDt);
		
		expEmkObj.setValueAmt(postAmt);
        
		return expEmkObj;
	}
	
	@Override
	public ExpEmkObjectHolder processLimits(FeeManualCharges dataObject, AcctJpe acctJpe, String eventType, String amtType) {
        ExpEmkObjectHolder expEmkObject = getLimitsDetails(dataObject, acctJpe, eventType, amtType);
        processDataExtensionList(expEmkObject);
        return expEmkObject;
    }

    @Override
    public ExpEmkObjectHolder getLimitsDetails(FeeManualCharges dataObject, AcctJpe acctJpe, String eventType, String amtType) {
        ExpEmkObjectHolder expEmkObject = null;
        Acct bdo = jaxbSdoHelper.wrap(acctJpe);
        Double tranAmt = dataObject.getScAmt();
        if ((((acctJpe.getActualBal() >= 0 || (acctJpe.getActualBal() < 0 && acctJpe.getActualBal() + tranAmt > 0)) &&
                eventType.equals(WHD_EVENT_TYPE) && amtType.equals(DR_AMT_TYPE)) ||(acctJpe.getActualBal() > 0 &&
                eventType.equals(DEP_EVENT_TYPE) && amtType.equals(CR_AMT_TYPE)))) {
            expEmkObject = this.parseDepToLmt(acctJpe, bdo, "N", dataObject, eventType, amtType);
            expEmkObject = generateBusinessRoleDataExtList(expEmkObject, null);
        }
        return expEmkObject;
    }

    private ExpEmkObjectHolder parseDepToLmt(AcctJpe jpe, Acct bdo, String reversal, FeeManualCharges txnBdo, String eventType, String amtType) {
		Double postAmt = txnBdo.getScAmt(); 
		
		Date defaultMaturityDt = null;
		if (eventType.equals(WHD_EVENT_TYPE) || eventType.equals(DEP_EVENT_TYPE)) {
	        try {
	        	DateFormat format = new SimpleDateFormat("dd/MM/yyyy");
	        	defaultMaturityDt=format.parse("31/12/2999");
	        } catch (Exception e) {
	            throw new RuntimeException("Error encountered converting date " + "31/12/2999", e);
	        }
		}
		if (eventType.equals(WHD_EVENT_TYPE) && jpe.getActualBal()<0 ){
				postAmt = jpe.getActualBal() + postAmt;
		}
		if (eventType.equals(DEP_EVENT_TYPE) ) {
			if (jpe.getActualBal() - postAmt<0) {
				postAmt = jpe.getActualBal();	
			}
			
		}
		ExpEmkObjectHolder expEmkObj = new ExpEmkObjectHolder();
		expEmkObj.setBookDt(dateTimeHelper.getRunDate());
		expEmkObj.setBranch(bdo.getBranch());
		expEmkObj.setCcyValue(bdo.getCcy());
		expEmkObj.setClientNoCtp(bdo.getClientNo());
		expEmkObj.setEffectDt(dateTimeHelper.getRunDate());
		expEmkObj.setExpEmkObjectType(DepJpeConstants.STRING_DEP_EXP_EMK_OBJECT_TYPE);
		expEmkObj.setExpEmkObjectKey(jpe.getAcctNo());
		expEmkObj.setExpEmkRefNo(jpe.getAcctNo());
		expEmkObj.setForcePostYn(false);
		expEmkObj.setLimitsAmountType(amtType);
		expEmkObj.setLimitsEventName(eventType);
		expEmkObj.setManagerCode(bdo.getOfficerId());
		expEmkObj.setEffectDt(dateTimeHelper.getRunDate());
		expEmkObj.setModuleCode(DepJpeConstants.STRING_DEP_MODULE);
		expEmkObj.setProductAccountNo(bdo.getAcctNo());
		expEmkObj.setProductCode(bdo.getAcctType());
		expEmkObj.setProfitCentre(bdo.getProfitCentre());
		expEmkObj.setReversalType(reversal);
		expEmkObj.setReversalYn(reversal == "N" ? false : true);
		expEmkObj.setStatus("A");
		expEmkObj.setEffectDt(dateTimeHelper.getRunDate());
		expEmkObj.setTranDt(dateTimeHelper.getRunDate());
		expEmkObj.setMaturityDt(defaultMaturityDt);
		
		expEmkObj.setValueAmt(postAmt);
        
		return expEmkObj;
	}	
}
