package com.silverlakesymmetri.cbs.dep.svc.impl;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.mysema.query.types.EntityPath;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.exception.base.CbsServiceProcessException;
import com.silverlakesymmetri.cbs.commons.exception.base.helper.ExceptionHelper;
import com.silverlakesymmetri.cbs.commons.jpa.util.CutEnvHelper;
import com.silverlakesymmetri.cbs.commons.jpa.util.DateTimeHelper;
import com.silverlakesymmetri.cbs.commons.jpa.util.JaxbDatetimeAdapter;
import com.silverlakesymmetri.cbs.commons.jpa.util.TechColumnsObject;
import com.silverlakesymmetri.cbs.commons.svc.AbstractBusinessService;
import com.silverlakesymmetri.cbs.commons.svc.CustomValidationCapable;
import com.silverlakesymmetri.cbs.commons.util.CurrentTenantResolver;
import com.silverlakesymmetri.cbs.csd.util.DateHelperDataHolder;
import com.silverlakesymmetri.cbs.csd.util.DateHelperUtil;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.FloatAdjustmentBranch;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.FloatRolldown;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.TranHist;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.FloatRolldownJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.QFloatRolldownJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.TranHistJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.id.FloatRolldownPk;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.id.TranHistPk;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.util.DepJpeConstants;
import com.silverlakesymmetri.cbs.dep.jpa.util.DepSodHelper;
import com.silverlakesymmetri.cbs.dep.svc.FloatRolldownService;
import com.silverlakesymmetri.cbs.dep.svc.TranHistService;
import com.silverlakesymmetri.cbs.dep.svc.util.AcctHelper;

@Service
@Transactional
public class FloatRolldownServiceImpl extends AbstractBusinessService<FloatRolldown, FloatRolldownJpe, FloatRolldownPk> 
	implements FloatRolldownService, CustomValidationCapable<TranHist> {
	
	private static final String ERROR_POST_DATE_IS_HOLIDAY = "CBS.B.DEP.FLOAT_ROLLDOWN_SERVICE.0004";
	private static final String INTERNAL_KEY = "internalKey";
	private static final String ACCT_NO = "acctNo";
	private static final String CERTIFICATE_NO = "certificateNo";
	
	@Autowired
	TranHistService tranHistService;

	@Autowired
    private DateTimeHelper dateTimeHelper;
	
	@Autowired
	private CutEnvHelper cutEnvHelper;
	
	@Autowired
	private DepSodHelper depSodHelper;
	
	@Autowired
	private DateHelperUtil dateHelperUtil;
	
	@Autowired
    protected CurrentTenantResolver<Integer> currentTenantResolver;

	@Autowired
	private AcctHelper acctHelper;

	@Override
	protected EntityPath<FloatRolldownJpe> getEntityPath() {
		return QFloatRolldownJpe.floatRolldownJpe;
	}

	@Override
	protected FloatRolldownPk getIdFromDataObjectInstance(FloatRolldown dataObject) {
		return new FloatRolldownPk(dataObject.getSeqNo(), JaxbDatetimeAdapter.parseDate(dataObject.getTranDate()));
	}
	
	@Override
	protected FloatRolldown preUpdateValidation(FloatRolldown dataObject) {
		validateDates(dataObject);
		return super.preUpdateValidation(dataObject);
	}
	
	private void validateDates(FloatRolldown dataObject) {
		Collection<Throwable> exceptions = new ArrayList<Throwable>();
		
		TranHistPk pk = new TranHistPk(dataObject.getSeqNo(), JaxbDatetimeAdapter.parseDate(dataObject.getTranDate()));
		TranHistJpe tranHistJpe = dataService.find(TranHistJpe.class, pk);
		if (tranHistJpe != null) {
			TranHist tranHistBdo = jaxbSdoHelper.wrap(tranHistJpe, TranHist.class);
			tranHistBdo.setPostDate(dataObject.getPostDate());
			
			// Effect From Date cannot be a holiday
			if (dataObject.getPostDate() != null) {
				DateHelperDataHolder holder = dateHelperUtil.createGeneralDateDataHolder(tranHistBdo.getType().getName(), "postDate", tranHistBdo);
				if (dateHelperUtil.checkHoliday(holder)) {
					String msg = messageUtils.getMessage(ERROR_POST_DATE_IS_HOLIDAY, new String[] { tranHistBdo.getPostDate() });
		            CbsServiceProcessException exec = new CbsServiceProcessException(ERROR_POST_DATE_IS_HOLIDAY, msg);
		            exceptions.add(exec);
				}
			}
			
			ExceptionHelper.createAndThrowAggregateException(exceptions);
		}
	}

	@Override
	public FloatRolldown create(FloatRolldown dataObject) {
		return super.create(dataObject);
	}

	@Override
	public boolean delete(FloatRolldown dataObject) {
		return super.delete(dataObject);
	}

	@Override
	public List<FloatRolldown> find(FindCriteria dataObject, CbsHeader cbsHeader) {
		return super.find(dataObject, cbsHeader);
	}

	@Override
	public <T> T findByPk(String dataObject, Class<T> arg1) {
		return super.findByPk(dataObject, arg1);
	}

	@Override
	public FloatRolldown get(FloatRolldown dataObject) {
		return super.get(dataObject);
	}

	@Override
	public FloatRolldown update(FloatRolldown dataObject) {
		return super.update(dataObject);
	}

	@Override
	public List<FloatRolldown> query(int offset, int resultLimit, String groupBy, String order,
			Map<String, Object> filters) {

		if (filters.containsKey(ACCT_NO)) {
			Long internalKey;
			String acctNo = (String) filters.get(ACCT_NO);
			if (filters.containsKey(CERTIFICATE_NO)) {
				String certificateNo = (String) filters.get(CERTIFICATE_NO);
				internalKey = acctHelper.getInternalKeyByAcctNoAndCertificateNo(acctNo, certificateNo);
				filters.remove(CERTIFICATE_NO);
			} else {
				internalKey = acctHelper.getInternalKeyByAcctNo(acctNo);
			}
			filters.remove(ACCT_NO);
			filters.put(INTERNAL_KEY, internalKey);
		}
		
		List<FloatRolldown> list = super.query(offset, resultLimit, groupBy, order, filters);

		List<FloatRolldown> floatRolldownList = new ArrayList<>();
		
		if (list != null) {
			for (FloatRolldown fr : list) {
				TranHistPk pk = new TranHistPk(fr.getSeqNo(), JaxbDatetimeAdapter.parseDate(fr.getTranDate()));
				TranHistJpe tranHistJpe = dataService.find(TranHistJpe.class, pk);

				if (tranHistJpe == null) {
					fr.setBank("???/" + fr.getBank());
				} else {
					fr.setBank(tranHistJpe.getReference() + "/" + fr.getBank());
				}

				floatRolldownList.add(fr);
			}
		}
		
		return floatRolldownList;
	}

	@Override
	public TranHist updTranHist(TranHist dataObject) {				
		long diffInMil;
		int floatDays;
		int floatCtr = 0;
		Date postDate;
		String postDateReq = dataObject.getPostDate();
		
		if (JaxbDatetimeAdapter.parseDate(dataObject.getEffectDate()).compareTo(dateTimeHelper.getRunDate()) > 0) {
			diffInMil = JaxbDatetimeAdapter.parseDate(dataObject.getEffectDate()).getTime() - dateTimeHelper.getRunDate().getTime();
		} else {
			diffInMil = JaxbDatetimeAdapter.parseDate(dataObject.getPostDate()).getTime() - dateTimeHelper.getRunDate().getTime();
		}
		
		floatDays = Math.abs((int) TimeUnit.DAYS.convert(diffInMil, TimeUnit.MILLISECONDS));
		
		FloatRolldownPk floatPk = new FloatRolldownPk(dataObject.getSeqNo(), JaxbDatetimeAdapter.parseDate(dataObject.getTranDate()));
		FloatRolldownJpe floatRolldownJpe = dataService.find(FloatRolldownJpe.class, floatPk);
		
		FloatRolldown floatRolldownBdo = jaxbSdoHelper.wrap(floatRolldownJpe, FloatRolldown.class);
		
		TranHist bdoTmp = dataObject;
		
		if (floatDays != 0) {
			postDate = dateTimeHelper.getRunDate();
			while (floatDays > 0) {
				postDate = dateTimeHelper.addDays(postDate, 1);
				bdoTmp.setPostDate(dateTimeHelper.getXmlDateTime(postDate));
				DateHelperDataHolder holder = dateHelperUtil.createGeneralDateDataHolder(bdoTmp.getType().getName(), "postDate", bdoTmp);
				if (!dateHelperUtil.checkHoliday(holder)) {
					floatCtr++;
				}
				floatDays--;
			}
		}
		
		List<Long> listSeqNo = new ArrayList<Long>();
		listSeqNo.add(dataObject.getSeqNo());
		
		if (JaxbDatetimeAdapter.parseDate(dataObject.getPostDate()).compareTo(dateTimeHelper.getRunDate()) == 0) {
			TechColumnsObject tc = new TechColumnsObject();
			tc.setCreatedBy(dataObject.getCreatedBy());
			tc.setJournalDate(JaxbDatetimeAdapter.parseDate(dataObject.getJournalDt()));
			tc.setJournalNo(dataObject.getJournalNo());
			tc.setModifiedBy(dataObject.getModifiedBy());
			tc.setOrg_id(currentTenantResolver.getCurrentTenantId());
			cutEnvHelper.setEnv(tc);
			depSodHelper.acctFloatAdj(floatRolldownBdo.getInternalKey(), floatRolldownBdo.getFloatAmt().doubleValue(), dateTimeHelper.getRunDate());
			
			delete(floatRolldownBdo);
		} else {
			//floatRolldownJpe.setFloatDays(floatCtr);
			//floatRolldownJpe.setPostDate(JaxbDatetimeAdapter.parseDate(postDateReq));
			//dataService.update(floatRolldownJpe);
			
			//floatRolldownBdo.setFloatDays(floatCtr);
			//floatRolldownBdo.setPostDate(postDateReq);
			//update(floatRolldownBdo);
			
			Map<String, Object> f = new HashMap<>();
			f.put("floatDays", floatCtr);
			f.put("tranDate", JaxbDatetimeAdapter.parseDate(dataObject.getTranDate()));
			f.put("recordIdList", listSeqNo);
						
			dataService.bulkUpdateWithNamedQuery(DepJpeConstants.FLOATROLLDOWN_JPE_BY_SEQ_NO, f, FloatRolldownJpe.class);
		}
		
		TranHistPk pk = new TranHistPk(dataObject.getSeqNo(), JaxbDatetimeAdapter.parseDate(dataObject.getTranDate()));
		TranHistJpe tranHistJpe = dataService.find(TranHistJpe.class, pk);
		
		if(tranHistJpe != null){			
			Map<String, Object> p = new HashMap<>();
			p.put("floatDays", floatCtr);
			p.put("postDate", JaxbDatetimeAdapter.parseDate(postDateReq));
			p.put("tranDate", JaxbDatetimeAdapter.parseDate(dataObject.getTranDate()));
			p.put("recordIdList", listSeqNo);
						
			dataService.bulkUpdateWithNamedQuery(DepJpeConstants.TRANHIST_JPE_BY_SEQ_NO, p, TranHistJpe.class);
		}

		//TranHistPk pk2 = new TranHistPk(dataObject.getSeqNo(), JaxbDatetimeAdapter.parseDate(dataObject.getTranDate()));
		//TranHistJpe tranHistJpe2 = dataService.find(TranHistJpe.class, pk2);
		//dataObject.setFloatDays(floatCtr);
		//dataObject.setPostDate(postDateReq);
		
		return dataObject;
	}
	
	@Override
	public FloatAdjustmentBranch processFloatAdj(FloatAdjustmentBranch dataObject) {
		TranHist tranHistBdo = null;
		
		String customQuery = "SELECT th"
				+ " FROM FloatRolldownJpe fr"
				+ " INNER JOIN TranHistJpe th ON (fr.seqNo = th.seqNo AND fr.tranDate = th.tranDate)"
				+ " WHERE fr.branch = :branch"
				+ " AND th.ccy = :ccy"
				+ " AND fr.floatDays = :floatDays";
		
		Map<String, Object> params = new HashMap<String, Object>();
		params.put("branch", dataObject.getBranch());
		params.put("ccy", dataObject.getCcy());
		params.put("floatDays", dataObject.getFloatDays());		
		List<TranHistJpe> jpeList = dataService.findWithQuery(customQuery, TranHistJpe.class, params, null);
		if (jpeList != null && jpeList.size() > 0) {
			for (TranHistJpe jpe : jpeList) {
				tranHistBdo = jaxbSdoHelper.wrap(jpe, TranHist.class);
				tranHistBdo.setPostDate(dataObject.getPostDate());
				tranHistBdo = updTranHist(tranHistBdo);
			}
		}
		
		dataObject.setFloatDays(tranHistBdo.getFloatDays());
		
		return dataObject;
	}

	@Override
	public TranHist customValidate(TranHist dataObject) {
		long diffInMil;
		int floatDays;
		int floatCtr = 0;
		Date postDate;
		String postDateReq = dataObject.getPostDate();
		
		if (JaxbDatetimeAdapter.parseDate(dataObject.getEffectDate()).compareTo(dateTimeHelper.getRunDate()) > 0) {
			diffInMil = JaxbDatetimeAdapter.parseDate(dataObject.getEffectDate()).getTime() - dateTimeHelper.getRunDate().getTime();
		} else {
			diffInMil = JaxbDatetimeAdapter.parseDate(dataObject.getPostDate()).getTime() - dateTimeHelper.getRunDate().getTime();
		}
		
		floatDays = Math.abs((int) TimeUnit.DAYS.convert(diffInMil, TimeUnit.MILLISECONDS));
		
		FloatRolldownPk floatPk = new FloatRolldownPk(dataObject.getSeqNo(), JaxbDatetimeAdapter.parseDate(dataObject.getTranDate()));
		FloatRolldownJpe floatRolldownJpe = dataService.find(FloatRolldownJpe.class, floatPk);
		
		FloatRolldown floatRolldownBdo = jaxbSdoHelper.wrap(floatRolldownJpe, FloatRolldown.class);
		
		TranHist bdoTmp = dataObject;
		
		if (floatDays != 0) {
			postDate = dateTimeHelper.getRunDate();
			while (floatDays > 0) {
				postDate = dateTimeHelper.addDays(postDate, 1);
				bdoTmp.setPostDate(dateTimeHelper.getXmlDateTime(postDate));
				DateHelperDataHolder holder = dateHelperUtil.createGeneralDateDataHolder(bdoTmp.getType().getName(), "postDate", bdoTmp);
				if (!dateHelperUtil.checkHoliday(holder)) {
					floatCtr++;
				}
				floatDays--;
			}
		}
		
		floatRolldownBdo.setFloatDays(floatCtr);
		floatRolldownBdo.setPostDate(postDateReq);
		super.validateUpdateRequest(floatRolldownBdo);

		dataObject.setFloatDays(floatCtr);
		dataObject.setPostDate(postDateReq);
		
		return dataObject;
	}

}