package com.silverlakesymmetri.cbs.dep.svc;

import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation;
import com.silverlakesymmetri.cbs.commons.svc.BusinessService;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.FeeInquiryHdr;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.FeeInquiryHdrJpe;

import java.util.List;
import java.util.Map;

public interface DepositsFeeWrapperService extends BusinessService<FeeInquiryHdr, FeeInquiryHdrJpe> {

    String SVC_OP_NAME_DEPOSITSFEEWRAPPERSERVICE_QUERY = "DepositsFeeWrapperService.query";

    @ServiceOperation(name = SVC_OP_NAME_DEPOSITSFEEWRAPPERSERVICE_QUERY)
    List<FeeInquiryHdr> query(int offset, int resultLimit, String groupBy, String order, Map<String, Object> filters);

}
