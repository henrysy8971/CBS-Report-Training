package com.silverlakesymmetri.cbs.dep.svc.mapper;

import java.util.Map;

import org.mapstruct.Context;
import org.mapstruct.DecoratedWith;
import org.mapstruct.InheritConfiguration;
import org.mapstruct.InheritInverseConfiguration;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingTarget;
import org.mapstruct.Mappings;

import com.silverlakesymmetri.cbs.commons.jpa.util.DateTimeHelper;
import com.silverlakesymmetri.cbs.commons.xmlapi.enums.CbsXmlApiOperation;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.OnlineScCollectionJpe;
import com.silverlakesymmetri.cbs.dep.svc.mapper.decorator.OnlineScCollectionServiceDecorator;
import com.silverlakesymmetri.cbs.dep.svc.mapper.mapping.OnlineScCollectionToDEPFEEONLINESETTLEAPITypeMapper;
import com.silverlakesymmetri.cbs.dep.xmlapi.DEPFEEONLINESETTLEAPIType;

@Mapper(config=OnlineScCollectionToDEPFEEONLINESETTLEAPITypeMapper.class, uses={ DateTimeHelper.class})
@DecoratedWith(OnlineScCollectionServiceDecorator.class)
public interface OnlineScCollectionServiceMapper{
	
	@Mappings({
		 @Mapping(expression = "java(oper != null ? oper.getOperation() : null)", target="OPERATION")
	 })
	@InheritConfiguration
	public DEPFEEONLINESETTLEAPIType mapToApi(OnlineScCollectionJpe jpe, @Context CbsXmlApiOperation oper, @Context Map otherInfo);
	
	
	@InheritInverseConfiguration(name = "mapOnlineScCollectionToDEPFEEONLINESETTLEAPIType")
//	@Mapping(source = "EFFECTDATE", target="trfDate", qualifiedByName = {"DateTimeHelper","convertCbsApiDateToString"})
	public OnlineScCollectionJpe mapToJpe(DEPFEEONLINESETTLEAPIType api, @MappingTarget OnlineScCollectionJpe jpe);
	
}
