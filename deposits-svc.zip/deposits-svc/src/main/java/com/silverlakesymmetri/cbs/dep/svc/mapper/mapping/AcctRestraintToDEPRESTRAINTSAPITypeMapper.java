package com.silverlakesymmetri.cbs.dep.svc.mapper.mapping;

import org.mapstruct.MapperConfig;
import org.mapstruct.Mapping;
import org.mapstruct.Mappings;

import com.silverlakesymmetri.cbs.commons.jpa.util.DateTimeHelper;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.AcctRestraintJpe;
import com.silverlakesymmetri.cbs.dep.xmlapi.DEPRESTRAINTSAPIType;

@MapperConfig(uses= {DateTimeHelper.class, AcctRestraintToDEPRESTRAINTSAPITypeMapper.class})
public interface AcctRestraintToDEPRESTRAINTSAPITypeMapper {

	@Mappings({
		@Mapping(source = "acctNo", target="ACCTNO"),
		@Mapping(source = "certificateNo", target = "CERTIFICATENO"),
		@Mapping(source = "startDate", target = "STARTDATE", qualifiedByName = {"DateTimeHelper","convertDateToCbsXmlApiDate"}),
		@Mapping(source = "endDate", target = "ENDDATE", qualifiedByName = {"DateTimeHelper","convertDateToCbsXmlApiDate"}),
		@Mapping(source = "restraintType", target = "RESTRAINTTYPE"),
		@Mapping(source = "pledgedAmt", target = "PLEDGEDAMT"),
		@Mapping(source = "startChequeNo", target = "STARTCHEQUENO"),
		@Mapping(source = "endChequeNo", target = "ENDCHEQUENO"),
		@Mapping(source = "lastChangeOfficer", target = "LASTCHANGEOFFICER"),
		@Mapping(source = "pledgedAcctType", target = "PLEDGEDACCTTYPE"),
		@Mapping(source = "narrative", target = "NARRATIVE"),
		@Mapping(source = "pledgedAcctNo", target = "PLEDGEDACCTNO"),
		@Mapping(source = "stlSeqNo", target = "STLSEQNO"),
		@Mapping(source = "forceFh", target = "FORCEFH"),
		@Mapping(source = "sourceModule", target = "SOURCEMODULE"),
		@Mapping(source = "referenceNo", target = "REFERENCENO"),
		@Mapping(source = "referenceType", target = "REFERENCETYPE"),
		@Mapping(source = "autoGenFee", target = "AUTOGENFEE"),
		@Mapping(source = "allowInd", target = "ALLOWIND"),
		@Mapping(source = "branch", target = "BRANCH"),
		@Mapping(source = "seqNo", target = "SEQNO"),
	})

	public DEPRESTRAINTSAPIType mapAcctRestrainttoDEPRESTRAINTSAPIType(AcctRestraintJpe jpe);

}
