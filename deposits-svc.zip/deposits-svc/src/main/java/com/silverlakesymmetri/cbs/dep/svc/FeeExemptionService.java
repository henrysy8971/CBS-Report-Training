package com.silverlakesymmetri.cbs.dep.svc;

import java.util.List;
import java.util.Map;

import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation;
import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation.ServiceOperationType;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.svc.BusinessService;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.FeeExemption;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.FeeExemptionJpe;

public interface FeeExemptionService extends BusinessService<FeeExemption, FeeExemptionJpe> {
	public static final String SVC_OP_NAME_FEEEXEMPTIONSERVICE_GET = "FeeExemptionService.get";
    public static final String SVC_OP_NAME_FEEEXEMPTIONSERVICE_QUERY = "FeeExemptionService.query";
    public static final String SVC_OP_NAME_FEEEXEMPTIONSERVICE_CREATE = "FeeExemptionService.create";
    public static final String SVC_OP_NAME_FEEEXEMPTIONSERVICE_UPDATE = "FeeExemptionService.update";
    public static final String SVC_OP_NAME_FEEEXEMPTIONSERVICE_DELETE = "FeeExemptionService.delete";
    public static final String SVC_OP_NAME_FEEEXEMPTIONSERVICE_FIND = "FeeExemptionService.find";
    
    @ServiceOperation(name = SVC_OP_NAME_FEEEXEMPTIONSERVICE_GET, type = ServiceOperationType.GET)
    public FeeExemption getByPk(String publicKey, FeeExemption reference);

    @ServiceOperation(name = SVC_OP_NAME_FEEEXEMPTIONSERVICE_CREATE)
    public FeeExemption create(FeeExemption dataObject);

    @ServiceOperation(name = SVC_OP_NAME_FEEEXEMPTIONSERVICE_UPDATE)
    public FeeExemption update(FeeExemption dataObject);

    @ServiceOperation(name = SVC_OP_NAME_FEEEXEMPTIONSERVICE_DELETE)
    public boolean delete(FeeExemption dataObject);

    @ServiceOperation(name = SVC_OP_NAME_FEEEXEMPTIONSERVICE_QUERY)
    public List<FeeExemption> query(int offset, int resultLimit, String groupBy, String order, Map<String, Object> filters);

    @ServiceOperation(name = SVC_OP_NAME_FEEEXEMPTIONSERVICE_FIND)
    public List<FeeExemption> find(FindCriteria findCriteria, CbsHeader cbsHeader);
}
