package com.silverlakesymmetri.cbs.dep.svc.mapper.decorator;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.mapstruct.Context;
import org.mapstruct.MappingTarget;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

import com.silverlakesymmetri.cbs.commons.xmlapi.enums.CbsXmlApiOperation;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.TdaPretermInqJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.TdaPymtDtlsInqJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.TdaVInqJpe;
import com.silverlakesymmetri.cbs.dep.svc.mapper.TdaVInqServiceMapper;
import com.silverlakesymmetri.cbs.dep.svc.mapper.mapping.TdaPretermInqToDEPTDHISTORYQRYAPITypeMapper;
import com.silverlakesymmetri.cbs.dep.svc.mapper.mapping.TdaPymtDtlsInqToDEPTDPAYMENTDETAILSTTypeMapper;
import com.silverlakesymmetri.cbs.dep.xmlapi.DEPTDHISTORYQRYAPIType;
import com.silverlakesymmetri.cbs.dep.xmlapi.DEPTDPAYMENTDETAILSTType;

public abstract class TdaVInqServiceDecorator implements TdaVInqServiceMapper {

	@Autowired
	@Qualifier("delegate")
	protected TdaVInqServiceMapper delegate;

	@Autowired
	TdaPretermInqToDEPTDHISTORYQRYAPITypeMapper tdaPretermInqMapper;

	@Autowired
	TdaPymtDtlsInqToDEPTDPAYMENTDETAILSTTypeMapper tdaPymtDtlsInqMapper;

	@Override
	public DEPTDHISTORYQRYAPIType mapToApi(TdaVInqJpe jpe, @Context CbsXmlApiOperation oper, Map otherInfo) {
		DEPTDHISTORYQRYAPIType req = delegate.mapToApi(jpe, oper, otherInfo);
		return req;
	}

	@Override
	public TdaVInqJpe mapToJpe(DEPTDHISTORYQRYAPIType api, @MappingTarget TdaVInqJpe jpe) {

		if (jpe == null) {
			jpe = new TdaVInqJpe();
		}

		if (api == null) {
			return jpe;
		}

		jpe = delegate.mapToJpe(api, jpe);

		if (api.getPRETERMAMT() != null || api.getPRETERMDATE() != null) {
			List<TdaPretermInqJpe> tdaPretermInqList = new ArrayList<TdaPretermInqJpe>();
			TdaPretermInqJpe tdaPretermInqJpe = tdaPretermInqMapper.mapDEPTDHISTORYQRYAPITypeToTdaPretermInq(api);
			tdaPretermInqList.add(tdaPretermInqJpe);
			jpe.setTdaPretermInqList(tdaPretermInqList);
		}

		if (api.getDEPTDPAYMENTDETAILS() == null || api.getDEPTDPAYMENTDETAILS().getDEPTDPAYMENTDETAILST() == null
				|| api.getDEPTDPAYMENTDETAILS().getDEPTDPAYMENTDETAILST().isEmpty()) {
			return jpe;
		} else {
			List<TdaPymtDtlsInqJpe> tdaPymtDtlsInqList = new ArrayList<TdaPymtDtlsInqJpe>();
			for (DEPTDPAYMENTDETAILSTType pymtDtlType : api.getDEPTDPAYMENTDETAILS().getDEPTDPAYMENTDETAILST()) {
				TdaPymtDtlsInqJpe tdaPymtDtlsInqJpe = tdaPymtDtlsInqMapper.mapDEPTDPAYMENTDETAILSTTypeToTdaPymtDtlsInq(pymtDtlType);
				tdaPymtDtlsInqList.add(tdaPymtDtlsInqJpe);
			}
			jpe.setTdaPymtDtlsInqList(tdaPymtDtlsInqList);
		}

		return jpe;

	}

}
