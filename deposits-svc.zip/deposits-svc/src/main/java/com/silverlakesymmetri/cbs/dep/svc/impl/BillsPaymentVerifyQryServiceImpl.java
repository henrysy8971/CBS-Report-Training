package com.silverlakesymmetri.cbs.dep.svc.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.mysema.query.types.EntityPath;
import com.silverlakesymmetri.cbs.commons.jpa.extension.JaxbSdoHelper;
import com.silverlakesymmetri.cbs.commons.svc.AbstractBusinessService;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.BillsPaymentOnlineVerify;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.BillsPaymentOnlineVerifyJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.QBillsPaymentOnlineVerifyJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.id.BillsPaymentOnlineVerifyPk;
import com.silverlakesymmetri.cbs.dep.svc.BillsPaymentVerifyQryService;

@Service
@Transactional
public class BillsPaymentVerifyQryServiceImpl extends
		AbstractBusinessService<BillsPaymentOnlineVerify, BillsPaymentOnlineVerifyJpe, BillsPaymentOnlineVerifyPk>
		implements BillsPaymentVerifyQryService {

	@Autowired
	protected JaxbSdoHelper jaxbSdoHelper;

	@Override
	protected BillsPaymentOnlineVerifyPk getIdFromDataObjectInstance(BillsPaymentOnlineVerify dataObject) {
		return new BillsPaymentOnlineVerifyPk(dataObject.getInstCode(), dataObject.getPaymentRef(),
				dataObject.getTranType());
	}

	@Override
	protected EntityPath<BillsPaymentOnlineVerifyJpe> getEntityPath() {
		return QBillsPaymentOnlineVerifyJpe.billsPaymentOnlineVerifyJpe;
	}

	@Override
	public BillsPaymentOnlineVerify verify(String instCode, String paymentRef, String tranType) {
		BillsPaymentOnlineVerify billsPaymentVerify = jaxbSdoHelper.createSdoInstance(BillsPaymentOnlineVerify.class);
		billsPaymentVerify.setInstCode(instCode);
		billsPaymentVerify.setPaymentRef(paymentRef);
		billsPaymentVerify.setTranType(tranType);
		billsPaymentVerify.setMinPayAmt(0d);
		billsPaymentVerify.setMaxPayAmt(0d);
		billsPaymentVerify.setAmtDue(0d);
		return billsPaymentVerify;
	}

}
