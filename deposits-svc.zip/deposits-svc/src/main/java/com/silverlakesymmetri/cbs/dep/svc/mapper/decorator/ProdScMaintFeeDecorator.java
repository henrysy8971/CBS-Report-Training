package com.silverlakesymmetri.cbs.dep.svc.mapper.decorator;

import java.util.Map;

import org.mapstruct.Context;
import org.mapstruct.MappingTarget;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

import com.silverlakesymmetri.cbs.commons.xmlapi.enums.CbsXmlApiOperation;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.ProdScMaintFeeJpe;
import com.silverlakesymmetri.cbs.dep.svc.mapper.ProdScMaintFeeMapper;
import com.silverlakesymmetri.cbs.dep.xmlapi.DEPPRODSCMAINTFEEAPIType;
                                                                    
public abstract class ProdScMaintFeeDecorator implements ProdScMaintFeeMapper{
	
	@Autowired
	@Qualifier("delegate")
	protected  ProdScMaintFeeMapper delegate;
	
//	@Autowired(required = true)
//    @Qualifier("cbsGenericDataService")
//    protected CbsGenericDataService dataService;
	
	public final static String PRODKEY = "prodKey";
	@Override
	public DEPPRODSCMAINTFEEAPIType mapToApi(ProdScMaintFeeJpe jpe, @Context CbsXmlApiOperation oper, @Context Map otherInfo){
				
		DEPPRODSCMAINTFEEAPIType req = (DEPPRODSCMAINTFEEAPIType)delegate.mapToApi(jpe, oper, otherInfo);
		if (otherInfo.containsKey(PRODKEY)){
			req.setPRODKEY(Double.parseDouble( (String) otherInfo.get(PRODKEY) ));
		}
		return  req;
	}
	
	@Override
	public ProdScMaintFeeJpe mapToJpe(DEPPRODSCMAINTFEEAPIType api, @MappingTarget ProdScMaintFeeJpe jpe){
		
		if (jpe == null){
			jpe = new ProdScMaintFeeJpe();
		}
		
		if (api == null){
			return jpe;
		}
		
		delegate.mapToJpe(api, jpe);
			
		return jpe;
	}
}


