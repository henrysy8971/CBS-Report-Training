package com.silverlakesymmetri.cbs.dep.svc;

import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation;
import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation.ServiceOperationType;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.svc.BusinessService;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.ExternalBranch;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.ExternalBranchJpe;

import java.util.List;
import java.util.Map;

public interface ExternalBranchService extends BusinessService<ExternalBranch, ExternalBranchJpe> {
	
	public static final String SVC_OP_NAME_EXTERNALBRANCH_GET = "ExternalBranchService.get";
    public static final String SVC_OP_NAME_EXTERNALBRANCH_QUERY = "ExternalBranchService.query";
    public static final String SVC_OP_NAME_EXTERNALBRANCH_CREATE = "ExternalBranchService.create";
    public static final String SVC_OP_NAME_EXTERNALBRANCH_UPDATE = "ExternalBranchService.update";
    public static final String SVC_OP_NAME_EXTERNALBRANCH_DELETE = "ExternalBranchService.delete";
    public static final String SVC_OP_NAME_EXTERNALBRANCH_FIND = "ExternalBranchService.find";
    public static final String SVC_OP_NAME_EXTERNALBRANCH_BULK_CREATE = "ExternalBranchService.bulkCreate";
    
    @ServiceOperation(name = SVC_OP_NAME_EXTERNALBRANCH_GET, type = ServiceOperationType.GET)
    public ExternalBranch getByPk(String publicKey, ExternalBranch reference);
    
    @ServiceOperation(name = SVC_OP_NAME_EXTERNALBRANCH_CREATE)
    public ExternalBranch create(ExternalBranch dataObject);

    @ServiceOperation(name = SVC_OP_NAME_EXTERNALBRANCH_UPDATE)
    public ExternalBranch update(ExternalBranch dataObject);

    @ServiceOperation(name = SVC_OP_NAME_EXTERNALBRANCH_QUERY)
    public List<ExternalBranch> query(int offset, int resultLimit, String groupBy, String order, Map<String, Object> filters);

    @ServiceOperation(name = SVC_OP_NAME_EXTERNALBRANCH_DELETE)
    public boolean delete(ExternalBranch dataObject);

    @ServiceOperation(name = SVC_OP_NAME_EXTERNALBRANCH_FIND)
    public List<ExternalBranch> find(FindCriteria findCriteria, CbsHeader cbsHeader);

    @ServiceOperation(name = SVC_OP_NAME_EXTERNALBRANCH_BULK_CREATE, type = ServiceOperationType.EXECUTE)
    public boolean bulkCreate(List<ExternalBranch> bdoList);

}
