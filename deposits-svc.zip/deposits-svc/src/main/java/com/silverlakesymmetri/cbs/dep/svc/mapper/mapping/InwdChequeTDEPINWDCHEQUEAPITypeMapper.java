package com.silverlakesymmetri.cbs.dep.svc.mapper.mapping;

import org.mapstruct.Context;
import org.mapstruct.InheritInverseConfiguration;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Mappings;

import com.silverlakesymmetri.cbs.commons.jpa.util.DateTimeHelper;
import com.silverlakesymmetri.cbs.commons.xmlapi.enums.CbsXmlApiOperation;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.InwdChequeJpe;
import com.silverlakesymmetri.cbs.dep.xmlapi.DEPINWDCHEQUEAPIType;

@Mapper(uses = { DateTimeHelper.class })
public interface InwdChequeTDEPINWDCHEQUEAPITypeMapper {
	
	@Mappings({
		@Mapping(target = "seqNo", source="SEQNO"),
		@Mapping(target = "status", source="STATUS"),
		@Mapping(target = "tranCode", source="TRANCODE"),
		@Mapping(target = "acctNo", source="ACCTNO"),
		//@Mapping(target = "acctDesc", source=
		@Mapping(target = "branch", source="BRANCH"),
		@Mapping(target = "chequeNo", source="CHEQUENO"),
		@Mapping(target = "tranAmt", source="TRANAMT"),
		@Mapping(target = "rejectCode", source="REJECTCODE"),
		//@Mapping(target = "rejectDesc", source=
		@Mapping(target = "orgBank", source="ORGBANK"),
		@Mapping(target = "orgBranch", source="ORGBRANCH"),
		@Mapping(target = "inwdType", source="INWDTYPE"),
		@Mapping(target = "tranDate", source="TRANDATE", qualifiedByName = {"DateTimeHelper","convertCbsApiDateToString"}),
		@Mapping(target = "orgAcctNo", source="ORGACCTNO"),
		@Mapping(target = "orgAcctName", source="ORGACCTNAME"),
		@Mapping(target = "remarks", source="REMARKS"),
		@Mapping(target = "errorNo", source="ERRORNO"),
		@Mapping(target = "sourceType", source="SOURCETYPE")
		//@Mapping(target = "totalChequeNo", source=

	})
	public InwdChequeJpe apiTypeToJpe(DEPINWDCHEQUEAPIType apiType);

	@InheritInverseConfiguration(name="apiTypeToJpe")
	@Mappings({
		@Mapping(source = "tranDate", target="TRANDATE", qualifiedByName = {"DateTimeHelper","convertDateToCbsXmlApiDate"}),
		@Mapping(expression = "java(oper != null ? oper.getOperation() : null)", target="OPERATION")
	})
	public DEPINWDCHEQUEAPIType jpeToApiType(InwdChequeJpe jpe, @Context CbsXmlApiOperation oper);

}
