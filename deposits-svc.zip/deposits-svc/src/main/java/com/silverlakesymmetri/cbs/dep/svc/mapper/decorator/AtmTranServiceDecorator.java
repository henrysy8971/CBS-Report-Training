package com.silverlakesymmetri.cbs.dep.svc.mapper.decorator;

import java.util.Map;

import com.silverlakesymmetri.cbs.dep.xmlapi.DEPATMAPIType;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

import com.silverlakesymmetri.cbs.commons.xmlapi.enums.CbsXmlApiOperation;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.DataElementsJpe;
import com.silverlakesymmetri.cbs.dep.svc.mapper.AtmTranServiceMapper;

public abstract class AtmTranServiceDecorator implements AtmTranServiceMapper{
	
	@Autowired
	@Qualifier("delegate")
	protected  AtmTranServiceMapper delegate;
		
	@Override
	public DEPATMAPIType mapToApi(DataElementsJpe jpe, CbsXmlApiOperation oper, Map otherInfo){
		DEPATMAPIType req = (DEPATMAPIType)delegate.mapToApi(jpe, oper, otherInfo);
		return  req;
	}
	
	@Override
	public DataElementsJpe mapToJpe(DEPATMAPIType api, DataElementsJpe jpe){
		if (jpe == null){
			jpe = new DataElementsJpe();
		}
		
		if (api == null){
			return jpe;
		}
		
		delegate.mapToJpe(api, jpe);
		return jpe;
	}
}
