package com.silverlakesymmetri.cbs.dep.svc;

import java.util.List;
import java.util.Map;

import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation;
import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation.ServiceOperationType;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.svc.BusinessService;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.InwdChequeHist;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.InwdChequeHistJpe;

public interface InwdChequeClearingOverrideService extends BusinessService<InwdChequeHist, InwdChequeHistJpe> {
	
	public static final String SVC_OP_NAME_INWDCHEQUE_CLEARING_OVERRIDE_GET 	= "InwdChequeClearingOverrideService.get";
    public static final String SVC_OP_NAME_INWDCHEQUE_CLEARING_OVERRIDE_QUERY 	= "InwdChequeClearingOverrideService.query";
    public static final String SVC_OP_NAME_INWDCHEQUE_CLEARING_OVERRIDE_CREATE 	= "InwdChequeClearingOverrideService.create";
    public static final String SVC_OP_NAME_INWDCHEQUE_CLEARING_OVERRIDE_UPDATE 	= "InwdChequeClearingOverrideService.update";
    public static final String SVC_OP_NAME_INWDCHEQUE_CLEARING_OVERRIDE_DELETE 	= "InwdChequeClearingOverrideService.delete";
    public static final String SVC_OP_NAME_INWDCHEQUE_CLEARING_OVERRIDE_FIND 	= "InwdChequeClearingOverrideService.find";
    
    @ServiceOperation(name = SVC_OP_NAME_INWDCHEQUE_CLEARING_OVERRIDE_GET, type = ServiceOperationType.GET)
    public InwdChequeHist getByPk(String publicKey, InwdChequeHist reference);
    
    @ServiceOperation(name = SVC_OP_NAME_INWDCHEQUE_CLEARING_OVERRIDE_UPDATE)
    public InwdChequeHist update(InwdChequeHist objectInstanceIdentifier);
    
    @ServiceOperation(name = SVC_OP_NAME_INWDCHEQUE_CLEARING_OVERRIDE_QUERY)
    public List<InwdChequeHist> query(int offset, int resultLimit, String groupBy, String order, Map<String, Object> filters);

    @ServiceOperation(name = SVC_OP_NAME_INWDCHEQUE_CLEARING_OVERRIDE_FIND)
    public List<InwdChequeHist> find(FindCriteria findCriteria, CbsHeader cbsHeader);

}
