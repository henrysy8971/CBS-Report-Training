package com.silverlakesymmetri.cbs.dep.svc.mapper.mapping;

import org.mapstruct.MapperConfig;
import org.mapstruct.Mapping;
import org.mapstruct.Mappings;

import com.silverlakesymmetri.cbs.commons.jpa.util.DateTimeHelper;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.CiRdRegJpe;
import com.silverlakesymmetri.cbs.dep.xmlapi.DEPCIRDAPIType;

@MapperConfig(uses={ DateTimeHelper.class})
public interface CiRdRegToDEPCIRDAPITypeMapper {
	
	@Mappings({
		@Mapping(target = "chequeRdKey", source="CHEQUERDKEY"), 
		@Mapping(target = "chequeType", source="CHEQUETYPE"),
		@Mapping(target = "ccy", source="CCY"),
		@Mapping(target = "branch", source="BRANCH"),
		@Mapping(target = "regDate", source="REGDATE", qualifiedByName = {"DateTimeHelper","convertCbsApiDateToString"}),
		@Mapping(target = "officerId", source="OFFICERID"),
		
	 })
	public CiRdRegJpe mapDEPCIRDAPITypeToCiRdRegJpe(DEPCIRDAPIType  api);	
	
}

