package com.silverlakesymmetri.cbs.dep.svc;

import java.util.List;
import java.util.Map;

import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation;
import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation.ServiceOperationType;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.svc.BusinessService;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.DepositClient;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.DepositClientJpe;

public interface DepositClientService extends BusinessService<DepositClient, DepositClientJpe> {

    public static final String SVC_OP_NAME_DEPOSITCLIENTSERVICE_GET = "DepositClientService.get"; 
    public static final String SVC_OP_NAME_DEPOSITCLIENTSERVICE_UPDATE = "DepositClientService.update";
    public static final String SVC_OP_NAME_DEPOSITCLIENTSERVICE_QUERY = "DepositClientService.query";
    public static final String SVC_OP_NAME_DEPOSITCLIENTSERVICE_FIND = "DepositClientService.find";
    public static final String SVC_OP_NAME_DEPOSITCLIENTSERVICE_CREATE = "DepositClientService.create";
    public static final String SVC_OP_NAME_DEPOSITCLIENTSERVICE_DELETE = "DepositClientService.delete";
    public static final String SVC_OP_NAME_DEPOSITCLIENTSERVICE_COUNT = "DepositClientService.count";

    @ServiceOperation(name = SVC_OP_NAME_DEPOSITCLIENTSERVICE_GET, type = ServiceOperationType.GET)
    public DepositClient getByPk(String publicKey, DepositClient reference);

    @ServiceOperation(name = SVC_OP_NAME_DEPOSITCLIENTSERVICE_UPDATE)
    public DepositClient update(DepositClient dataObject);
    
    @ServiceOperation(name = SVC_OP_NAME_DEPOSITCLIENTSERVICE_QUERY)
    public List<DepositClient> query(int offset, int resultLimit, String groupBy, String order, Map<String, Object> filters);

    @ServiceOperation(name = SVC_OP_NAME_DEPOSITCLIENTSERVICE_CREATE)
    public DepositClient create(DepositClient dataObject);

    @ServiceOperation(name = SVC_OP_NAME_DEPOSITCLIENTSERVICE_DELETE)
    public boolean delete(DepositClient dataObject);
    
    @ServiceOperation(name = SVC_OP_NAME_DEPOSITCLIENTSERVICE_FIND)
    public List<DepositClient> find(FindCriteria findCriteria, CbsHeader cbsHeader);

    @ServiceOperation(name = SVC_OP_NAME_DEPOSITCLIENTSERVICE_COUNT, type = ServiceOperation.ServiceOperationType.GET)
    public Long count(FindCriteria findCriteria, CbsHeader cbsHeader);

}
