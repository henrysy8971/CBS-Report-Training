package com.silverlakesymmetri.cbs.dep.svc.mapper;

import com.silverlakesymmetri.cbs.commons.jpa.util.DateTimeHelper;
import com.silverlakesymmetri.cbs.commons.xmlapi.enums.CbsXmlApiOperation;

import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.MiscManualEntriesJpe;
import com.silverlakesymmetri.cbs.dep.svc.mapper.mapping.MiscManualEntriesToDEPMISCHISTAPITypeMapper;
import com.silverlakesymmetri.cbs.dep.xmlapi.DEPMISCHISTAPIType;
import org.mapstruct.*;

@Mapper(config= MiscManualEntriesToDEPMISCHISTAPITypeMapper.class, uses = DateTimeHelper.class)
public interface MiscManualEntriesServiceMapper {

    @Mappings({
            @Mapping(expression = "java(oper != null ? oper.getOperation() : null)", target="OPERATION")
    })
    @InheritConfiguration()
    DEPMISCHISTAPIType mapToApi(MiscManualEntriesJpe jpe, @Context CbsXmlApiOperation oper, @MappingTarget DEPMISCHISTAPIType apiType);

    @InheritInverseConfiguration(name = "mapMiscManualEntriesToDEPMISCHISTAPITypeMapper")
    @Mappings({
            @Mapping(target = "tranDate", source="TRANDATE", qualifiedByName = {"DateTimeHelper","convertCbsApiDateToString"}),
            @Mapping(target = "effectDate", source="EFFECTDATE", qualifiedByName = {"DateTimeHelper","convertCbsApiDateToString"})
    })
    MiscManualEntriesJpe mapToJpe(DEPMISCHISTAPIType api, @MappingTarget MiscManualEntriesJpe jpe);
}
