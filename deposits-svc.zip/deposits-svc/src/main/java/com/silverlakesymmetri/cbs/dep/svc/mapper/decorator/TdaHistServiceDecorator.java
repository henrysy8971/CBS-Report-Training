package com.silverlakesymmetri.cbs.dep.svc.mapper.decorator;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.*;
import com.silverlakesymmetri.cbs.dep.xmlapi.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

import com.silverlakesymmetri.cbs.commons.jpa.entity.CbsVirtualAttributeJpe;
import com.silverlakesymmetri.cbs.commons.jpa.service.CbsGenericDataService;
import com.silverlakesymmetri.cbs.commons.xmlapi.enums.CbsXmlApiOperation;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.id.TdaVInqPk;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.util.DepJpeConstants;
import com.silverlakesymmetri.cbs.dep.svc.mapper.TdaHistServiceMapper;
import com.silverlakesymmetri.cbs.dep.svc.mapper.TranValidationFlagsMapper;

public abstract class TdaHistServiceDecorator extends FeeServiceDecorator implements TdaHistServiceMapper, TranValidationFlagsMapper {

	@Autowired(required = true)
	@Qualifier("cbsGenericDataService")
	protected CbsGenericDataService dataService;

	@Autowired
	@Qualifier("delegate")
	protected TdaHistServiceMapper delegate;

	@SuppressWarnings("rawtypes")
	@Override
	public DEPTDAPRETERMAPIType mapToApi(TdaHistJpe jpe, CbsXmlApiOperation oper, Map otherInfo) {

		DEPTDAPRETERMAPIType req = (DEPTDAPRETERMAPIType) delegate.mapToApi(jpe, oper, otherInfo);
		mapFeeToApi(jpe, req);

		Map<String, Object> params = new HashMap<String, Object>();
		params.put("acctNo", req.getACCTNO());
		AcctJpe acctJpe = dataService.getWithNamedQuery(DepJpeConstants.ACCT_JPE_FIND_BY_ACCTNO, params, AcctJpe.class);
		if (acctJpe != null) {
			req.setBRANCH(acctJpe.getBranch());
			req.setACCTTYPE(acctJpe.getAcctType());
			req.setCLIENTNO(acctJpe.getClientNo());
			req.setCCY(acctJpe.getCcy());
			Long internalKey = acctJpe.getInternalKey();
			TdaVInqJpe tdaVInqJpe = dataService.find(TdaVInqJpe.class, new TdaVInqPk(0L, internalKey));
			if (tdaVInqJpe != null) {
				req.setPRINCIPALAMT(tdaVInqJpe.getPrincipalAmt());
				req.setDEPTERMTYPE(tdaVInqJpe.getDepTermType());
				req.setDEPTERMPERIOD(tdaVInqJpe.getDepTermPeriod());
				req.setACCTLEVELINTRATE(tdaVInqJpe.getAcctLevelIntRate());
			}
		}

		req.setTRANVALIDATIONFLAGS(mapValidationFlags(jpe.getTdaPymtDtlsList().isEmpty() ? null
				: jpe.getTdaPymtDtlsList().get(0), "N", "N", "Y", "Y", "Y"));

		if (jpe.getTdaPymtDtlsList() != null && jpe.getTdaPymtDtlsList().size() > 0) {
			DEPTDATRANDTLCOLLType collection = new DEPTDATRANDTLCOLLType();
			List<TdaPymtDtlsJpe> jpeList = jpe.getTdaPymtDtlsList();
			int position = 0;
			for (TdaPymtDtlsJpe tdaPymtDtlsJpe : jpeList) {
				DEPTDATRANDTLTType tdaTranDtl = new DEPTDATRANDTLTType();
				tdaTranDtl.setPOSITION(++position);
				tdaTranDtl.setTRANCCY(tdaPymtDtlsJpe.getTranCcy());
				tdaTranDtl.setTRANTYPE(tdaPymtDtlsJpe.getTranType());
				tdaTranDtl.setTRANAMT(tdaPymtDtlsJpe.getTranAmt());
				tdaTranDtl.setTHIRDPARTYACCT(tdaPymtDtlsJpe.getCrThirdPartyAcct());
				tdaTranDtl.setEQUIVALENTAMT(tdaPymtDtlsJpe.getTranAmtTdCcy());
				tdaTranDtl.setAUTOGENFEE(tdaPymtDtlsJpe.getAutoGenFee() != null ? tdaPymtDtlsJpe.getAutoGenFee() : "N");
				// CBS9D-20277 - DR SC not handled by API.  For now just ignore debit fee charges
				tdaTranDtl.setDRSCAPPLYIN(mapFeeToApi(tdaPymtDtlsJpe.getDrDepFeeApplyList()));
				tdaTranDtl.setCRSCAPPLYIN(mapFeeToApi(tdaPymtDtlsJpe.getCrDepFeeApplyList()));
				collection.getDEPTDATRANDTLT().add(tdaTranDtl);
			}
			req.setRBTDATRANDTL(collection);
		}
		
		req.setAUTOGENFEE(jpe.getAutoGenFee() != null ? jpe.getAutoGenFee() : "N");
		req.setCOLLECTFRTHIRDPARTY(jpe.getCollectFromThirdParty() != null ? jpe.getCollectFromThirdParty() : "N");
		req.setMATRIXIND(jpe.getMatrixInd() != null ? jpe.getMatrixInd() : "N");
		req.setDEFERREDIND(jpe.getDeferredInd() != null ? jpe.getDeferredInd() : "N");
		
		return req;

	}

	private DEPFEEAPPLYINType mapFeesToApi(List<DepFeeApplyJpe> jpe) {
		DEPFEEAPPLYINType feeApplyIn = null;
		for (DepFeeApplyJpe depFeeApply : jpe) {
			if (feeApplyIn == null) {
				feeApplyIn = feeApplyMapper.mapDepFeeApplyToDEPFEEAPPLYIN(depFeeApply);
				feeApplyIn.setSCDETAILIN(new DEPFEEAPPLYDTLINCOLLType());
				feeApplyIn.setRBTRANOTHERDATAIN(new DEPTRANOTHERDATACOLLType());
			}
			feeApplyIn.getSCDETAILIN().getDEPFEEAPPLYDTLINT()
					.add(scDetailInMapper.mapScDetailInToDEPFEEAPPLYDTLIN(depFeeApply.getScDetailIn()));
			feeApplyIn.getRBTRANOTHERDATAIN().getDEPTRANOTHERDATAT().add(depTranOtherDataMapper
					.mapTranValidationFlagsToDEPTRANVALIDATIONFLAGST(depFeeApply.getRbTranOtherData()));
			feeApplyIn.setTRANVALIDATIONFLAGS(tranValidationFlagsMapper
					.mapTranValidationFlagsToDEPTRANVALIDATIONFLAGST(depFeeApply.getTranValidationFlags()));
		}
		return feeApplyIn;
	}

	@Override
	public TdaHistJpe mapToJpe(DEPTDAPRETERMAPIType api, TdaHistJpe jpe) {
		if (jpe == null) {
			jpe = new TdaHistJpe();
		}
		if (api == null) {
			return jpe;
		}
		delegate.mapToJpe(api, jpe);
//		final TdaHistJpe mainEntity = jpe;
		if (api.getTRANSFTRANDTLS() != null && !api.getTRANSFTRANDTLS().getDEPTRANSFTRANDTLST().isEmpty()) {
			for (int i = 0; i < api.getTRANSFTRANDTLS().getDEPTRANSFTRANDTLST().size(); i++) {
				DEPTRANSFTRANDTLSTType apiTransfer = api.getTRANSFTRANDTLS().getDEPTRANSFTRANDTLST().get(i);
				int position = apiTransfer.getPOSITION()-1;
				TdaPymtDtlsJpe jpeTransfer = jpe.getTdaPymtDtlsList().get(position);
				jpeTransfer.setSeqNo(apiTransfer.getDRTXNSEQNO());
				jpeTransfer.setTranSeqNo(apiTransfer.getCRTXNSEQNO());
				jpeTransfer.setDrAvailableBal(apiTransfer.getACCTAVAILBAL());
				jpeTransfer.setDrLedgerBal(apiTransfer.getACCTLEDGERBAL());
				jpeTransfer.setCrAvailableBal(apiTransfer.getTPACCTAVAILBAL());
				jpeTransfer.setCrLedgerBal(apiTransfer.getTPACCTLEDGERBAL());
				jpeTransfer.setCrDepFeeApplyList(mapTdaPymtFeeToJpe(apiTransfer, jpeTransfer));
			}
		}
		if (api.getWDRWLTRANDTLS() != null && !api.getWDRWLTRANDTLS().getDEPWDRWLTRANDTLST().isEmpty()) {
			for (int i = 0; i < api.getWDRWLTRANDTLS().getDEPWDRWLTRANDTLST().size(); i++) {
				DEPWDRWLTRANDTLSTType apiCasw = api.getWDRWLTRANDTLS().getDEPWDRWLTRANDTLST().get(i);
				int position = apiCasw.getPOSITION()-1;
				TdaPymtDtlsJpe jpeCasw = jpe.getTdaPymtDtlsList().get(position);
				jpeCasw.setSeqNo(apiCasw.getTRANSEQNO());
				jpeCasw.setTranSeqNo(apiCasw.getTRANSEQNO());
				jpeCasw.setDrAvailableBal(apiCasw.getACCTAVAILBAL());
				jpeCasw.setDrLedgerBal(apiCasw.getACCTLEDGERBAL());
			}
		}
//			List<TdaPymtDtlsJpe> tdaPymtDtlsJpeList = api.getWDRWLTRANDTLS().getDEPWDRWLTRANDTLST()
//					.stream().map(depwdrwltrandtlstType -> {
//						TdaPymtDtlsJpe tdaPymtDtlsJpe = new TdaPymtDtlsJpe();
//						//isn't this supposed to be just a sequence? will not touch this just in case, but set tranSeqNo appropriately
//						tdaPymtDtlsJpe.setSeqNo(depwdrwltrandtlstType.getTRANSEQNO());
//						tdaPymtDtlsJpe.setTranSeqNo(depwdrwltrandtlstType.getTRANSEQNO());
//						tdaPymtDtlsJpe.setDrAvailableBal(depwdrwltrandtlstType.getACCTAVAILBAL());
//						tdaPymtDtlsJpe.setDrLedgerBal(depwdrwltrandtlstType.getACCTLEDGERBAL());
//						if(mainEntity.getTdaPymtDtlsList() != null && mainEntity.getTdaPymtDtlsList().size() > 0){
//							for(TdaPymtDtlsJpe reqTdaPymt : mainEntity.getTdaPymtDtlsList()){
//								if(reqTdaPymt.getSeqNo().intValue() == depwdrwltrandtlstType.getPOSITION().intValue()){
//									tdaPymtDtlsJpe.setTranDate(reqTdaPymt.getTranDate());
//									tdaPymtDtlsJpe.setVirtualAttributeList(reqTdaPymt.getVirtualAttributeList());
//								}
//							}
//						}
//						return tdaPymtDtlsJpe;
//					}).collect(Collectors.toList());
//			jpe.setTdaPymtDtlsList(tdaPymtDtlsJpeList);
		return jpe;
	}

	protected DEPFEEAPPLYINType mapFeeToApi(List<DepFeeApplyJpe> list) {
		DEPFEEAPPLYINType feeApplyIn = null;
		for (DepFeeApplyJpe depFeeApply : list) {
			if (feeApplyIn == null) {
				feeApplyIn = feeApplyMapper.mapDepFeeApplyToDEPFEEAPPLYIN(depFeeApply);
				feeApplyIn.setSCDETAILIN(new DEPFEEAPPLYDTLINCOLLType());
				feeApplyIn.setRBTRANOTHERDATAIN(new DEPTRANOTHERDATACOLLType());
			}
			feeApplyIn.getSCDETAILIN().getDEPFEEAPPLYDTLINT()
					.add(scDetailInMapper.mapScDetailInToDEPFEEAPPLYDTLIN(depFeeApply.getScDetailIn()));
			feeApplyIn.getRBTRANOTHERDATAIN().getDEPTRANOTHERDATAT().add(depTranOtherDataMapper
					.mapTranValidationFlagsToDEPTRANVALIDATIONFLAGST(depFeeApply.getRbTranOtherData()));
			feeApplyIn.setTRANVALIDATIONFLAGS(tranValidationFlagsMapper
					.mapTranValidationFlagsToDEPTRANVALIDATIONFLAGST(depFeeApply.getTranValidationFlags()));
		}
		return feeApplyIn;
	}

	protected List<DepFeeApplyJpe> mapTdaPymtFeeToJpe(DEPTRANSFTRANDTLSTType api, TdaPymtDtlsJpe jpe) {

		//why? guard when API returns CR-SC for Transfers; but no CR Fee on actual jpe request
		//this should be a temp solution; comprehensive solution would be to finalize the API structure
		if (jpe.getCrDepFeeApplyList().isEmpty()){
			return jpe.getCrDepFeeApplyList();
		}
		if (api.getCRSCDETAILOUT() != null && api.getCRSCDETAILOUT().getDEPFEEAPPLYDTLOUTT().size() > 0 &&
			api.getCRSCDETAILOUT().getDEPFEEAPPLYDTLOUTT().size() == jpe.getCrDepFeeApplyList().size()) {
			for (int i = 0; i < api.getCRSCDETAILOUT().getDEPFEEAPPLYDTLOUTT().size(); i++) {
				DEPFEEAPPLYDTLOUTTType feeApplyOut = api.getCRSCDETAILOUT().getDEPFEEAPPLYDTLOUTT().get(i);
				ScDetailOutJpe scDetailOut = scDetailOutMapper.mapDEPFEEAPPLYDTLOUTTToScDetailOut(feeApplyOut);
				if (jpe.getCrDepFeeApplyList().get(i) != null) {
					jpe.getCrDepFeeApplyList().get(i).setScDetailOut(scDetailOut);
				}
			}
		}
		return jpe.getCrDepFeeApplyList();
	}
}
