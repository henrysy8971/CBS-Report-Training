package com.silverlakesymmetri.cbs.dep.svc.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.mysema.query.types.EntityPath;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.jpa.util.DateTimeHelper;
import com.silverlakesymmetri.cbs.commons.svc.AbstractBusinessService;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.SdbType;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.QSdbTypeJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.SdbTypeJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.id.SdbTypePk;
import com.silverlakesymmetri.cbs.dep.svc.SdbTypeService;

@Service
@Transactional
public class SdbTypeServiceImpl extends AbstractBusinessService<SdbType, SdbTypeJpe, SdbTypePk> implements SdbTypeService {
	
	@Autowired
	private DateTimeHelper dateTimeHelper;
	
	@Override
    public SdbType getByPk(String publicKey, SdbType reference) {
        return super.getByPk(publicKey, reference);
    }
	
	private static final String SDB_TYPE_LOV= "SELECT  NEW com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.SdbTypeJpe (rst.productCode, rst.duration, rst.durationType, MAX (rst.effectDate), rst.ccy) "
											+" FROM "
											+"  SdbTypeJpe rst "
											+" WHERE "
											+"      rst.branch LIKE :branch "
											+"  AND rst.productCode LIKE :productCode "
											+"  AND rst.ccy LIKE :ccy "
											+"  AND rst.boxType LIKE :boxType "
											+"  AND rst.effectDate <=  :runDate "
											+" GROUP BY rst.productCode, rst.duration, rst.durationType, rst.ccy";

	
    @Override
    public List<SdbType> query(int offset, int resultLimit, String groupBy, String order, Map<String, Object> filters) {
    	
    	if (filters == null){
    		filters = new HashMap<String, Object>();
    	}
    	
    	
    	if (!filters.containsKey("branch")){
    		filters.put("branch", "%");
    	}
    	
    	if (!filters.containsKey("ccy")){
    		filters.put("ccy", "%");
    	}
    	
    	if (!filters.containsKey("productCode")){
    		filters.put("productCode", "%");
    	}
    	
    	if (!filters.containsKey("boxType")){
    		filters.put("boxType", "%");
    	}
    	
    	if (!filters.containsKey("runDate")){
    		filters.put("runDate", dateTimeHelper.getRunDate());
    	}
    	else{
    		filters.put("runDate", dateTimeHelper.getDate((String)filters.get("runDate")));
    	}
   
    	List<SdbTypeJpe> jpeList = (List<SdbTypeJpe>) dataService.findWithQuery(SDB_TYPE_LOV, filters, offset, resultLimit, SdbTypeJpe.class);
    	        
        List<SdbType> retList = new ArrayList<>();
		if (jpeList != null && jpeList.size() > 0) {
			for(SdbTypeJpe jpe: jpeList){
				retList.add(jaxbSdoHelper.wrap(jpe, SdbType.class));				
			}
		}
		
		return retList;    	
    }

    @Override
    public List<SdbType> find(FindCriteria findCriteria, CbsHeader cbsHeader) {
        return super.find(findCriteria, cbsHeader);
    }


	@Override
	protected SdbTypePk getIdFromDataObjectInstance(SdbType dataObject) {
		// TODO Auto-generated method stub
		return new SdbTypePk(dataObject.getSdbTypeDtlRefNo());
	}

	@Override
	protected EntityPath<SdbTypeJpe> getEntityPath() {
		// TODO Auto-generated method stub
		return QSdbTypeJpe.sdbTypeJpe;
	}
	
}
