package com.silverlakesymmetri.cbs.dep.svc.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.mysema.query.types.EntityPath;
import com.silverlakesymmetri.cbs.commons.context.CbsSessionContext;
import com.silverlakesymmetri.cbs.commons.svc.AbstractXmlApiBusinessService;
import com.silverlakesymmetri.cbs.commons.xmlapi.enums.CbsXmlApiOperation;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.InwdCheque;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.AcctJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.ChqRejectCodeJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.InwdChequeJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.QInwdChequeJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.id.ChqRejectCodePk;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.id.InwdChequePk;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.util.DepJpeConstants;
import com.silverlakesymmetri.cbs.dep.svc.ClearingService;
import com.silverlakesymmetri.cbs.dep.svc.mapper.ClearingServiceMapper;
import com.silverlakesymmetri.cbs.dep.xmlapi.DEPINWDCLEARINGAPIType;

@Service
public class ClearingServiceImpl extends AbstractXmlApiBusinessService<InwdCheque, InwdChequeJpe, InwdChequePk, DEPINWDCLEARINGAPIType, DEPINWDCLEARINGAPIType> implements ClearingService {

	@Autowired
	@Qualifier("clearingServiceDecorator")
	private ClearingServiceMapper mapper;
	
	@Override
	protected Class<DEPINWDCLEARINGAPIType> getXmlApiResponseClass() {
		return DEPINWDCLEARINGAPIType.class;
	}

	@Override
	protected List<InwdCheque> processXmlApiListRs(InwdCheque arg0, DEPINWDCLEARINGAPIType apiType) {
		List<InwdChequeJpe> jpeList = mapper.mapToJpeList(apiType);
		List<InwdCheque> bdoList = new ArrayList<>(); 
		if (jpeList != null && jpeList.size() > 0) {
			Map<String, String> chqRejectCodeMap = new HashMap<>();
			Map<String, String[]> acctMap = new HashMap<>();
			for (InwdChequeJpe jpe : jpeList) {
				setTransientFields(jpe, chqRejectCodeMap, acctMap);
				InwdCheque bdo = jaxbSdoHelper.wrap(jpe, InwdCheque.class);
				bdo.setErrorDesc(getErrDesc(bdo.getErrorNo()));
				bdoList.add(bdo);
			}
		}
		return bdoList;
	}

	private void setTransientFields(InwdChequeJpe jpe, Map<String, String> chqRejectCodeMap, Map<String, String[]> acctMap) {
		if (jpe.getAcctNo() != null) {
			String[] transFields = acctMap.get(jpe.getAcctNo());
			if (transFields != null) {
				jpe.setAcctDesc(transFields[0]);
				jpe.setCcy(transFields[1]);
			} else {
				Map<String, Object> params = new HashMap<>();
				params.put("acctNo", jpe.getAcctNo());
				List<AcctJpe> acctJpeList = dataService.findWithNamedQuery(DepJpeConstants.ACCT_JPE_FIND_BY_ACCTNO, params, AcctJpe.class);
				if (acctJpeList != null && acctJpeList.size() > 0) {
					AcctJpe acctJpe = acctJpeList.get(0);
					jpe.setAcctDesc(acctJpe.getAcctDesc());
					jpe.setCcy(acctJpe.getCcy());
					acctMap.put(acctJpe.getAcctNo(), new String[] {acctJpe.getAcctDesc(), acctJpe.getCcy()});
				}
			}
		}
		
		if (jpe.getRejectCode() != null) {
			if (chqRejectCodeMap.get(jpe.getRejectCode()) != null) {
				jpe.setRejectDesc(chqRejectCodeMap.get(jpe.getRejectCode()));
			} else {
				ChqRejectCodeJpe chqRejectCodeJpe = dataService.find(ChqRejectCodeJpe.class, new ChqRejectCodePk(jpe.getRejectCode()));
				if (chqRejectCodeJpe != null) {
					jpe.setRejectDesc(chqRejectCodeJpe.getRejectDesc());
					chqRejectCodeMap.put(chqRejectCodeJpe.getRejectCode(), chqRejectCodeJpe.getRejectDesc());
				}	
			}
		}
	}

	@Override
	protected InwdCheque processXmlApiRs(InwdCheque arg0, DEPINWDCLEARINGAPIType arg1) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	protected DEPINWDCLEARINGAPIType transformBdoToXmlApiRqCreate(InwdCheque dataObject) {
		//return tranformToDEPINWDCLEARINGAPIType(dataObject, CbsXmlApiOperation.INSERT);
		return null;
	}

	@Override
	protected DEPINWDCLEARINGAPIType transformBdoToXmlApiRqDelete(InwdCheque arg0) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	protected DEPINWDCLEARINGAPIType transformBdoToXmlApiRqUpdate(InwdCheque dataObject) {
		return null;
	}

	@Override
	protected EntityPath<InwdChequeJpe> getEntityPath() {
		return QInwdChequeJpe.inwdChequeJpe;
	}

	@Override
	protected InwdChequePk getIdFromDataObjectInstance(InwdCheque arg0) {
		return new InwdChequePk(arg0.getSeqNo());
	}

	@Override
	public List<InwdCheque> queryInwdCheques(String inwdType, String tranCode, String branch) {
//		String branch = this.getUserBranch();
//		BooleanExpression expr1 = QInwdChequeJpe.inwdChequeJpe.branch.eq(branch);
//		BooleanExpression expr2 = QInwdChequeJpe.inwdChequeJpe.inwdType.eq(inwdType);
//		BooleanExpression expr3 = QInwdChequeJpe.inwdChequeJpe.tranCode.eq(tranCode);
//		BooleanExpression expr4 = QInwdChequeJpe.inwdChequeJpe.status.eq("N");
//		Predicate predicate = expr1.and(expr2).and(expr3).and(expr4);
//		List<OrderSpecifier<?>> orders = null;
//		return super.query(QInwdChequeJpe.inwdChequeJpe, 0, -1, predicate, orders);
		return process(inwdType, tranCode, branch, CbsXmlApiOperation.QUERY);
	}
	
	@Override
	public List<InwdCheque> processInwdCheques(String inwdType, String tranCode, String branch) {
		return process(inwdType, tranCode, branch, CbsXmlApiOperation.UPDATE);
	}

	private List<InwdCheque> process(String inwdType, String tranCode, String branch, CbsXmlApiOperation oper) {
		// String branch = this.getUserBranch();
		DEPINWDCLEARINGAPIType apiType = new DEPINWDCLEARINGAPIType();
		apiType.setINWDTYPE(inwdType);
		apiType.setTRANCODE(tranCode);
		apiType.setBRANCH(branch);
		apiType.setOPERATION(oper.getOperation());
		setTechColumns(apiType);
		DEPINWDCLEARINGAPIType resultApiType = queryXmlApiRs(apiType);
		List<InwdCheque> list = processXmlApiListRs(null, resultApiType);
		if (list != null) {
			for (InwdCheque bdo : list) {
				bdo.setErrorDesc(getErrDesc(bdo.getErrorNo()));
			}
		}
		return list;
	}
	
}
