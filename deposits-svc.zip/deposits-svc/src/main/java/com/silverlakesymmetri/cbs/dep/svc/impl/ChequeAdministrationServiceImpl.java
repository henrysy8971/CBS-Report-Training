package com.silverlakesymmetri.cbs.dep.svc.impl;

import com.mysema.query.types.EntityPath;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.helper.jpa.LinkTable;
import com.silverlakesymmetri.cbs.commons.helper.jpa.QueryCondition;
import com.silverlakesymmetri.cbs.commons.helper.jpa.QueryType;
import com.silverlakesymmetri.cbs.commons.jpa.entity.FindCriteriaJpe;
import com.silverlakesymmetri.cbs.commons.svc.AbstractXmlApiBusinessService;
import com.silverlakesymmetri.cbs.commons.svc.BusinessObjectValidationCapable;
import com.silverlakesymmetri.cbs.commons.xmlapi.enums.CbsXmlApiOperation;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.CiAdministration;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.CiAdministrationJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.CiTypeJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.QCiAdministrationJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.id.CiAdministrationPk;
import com.silverlakesymmetri.cbs.dep.svc.ChequeAdministrationService;
import com.silverlakesymmetri.cbs.dep.xmlapi.DEPCISTATUSUPDATEAPIType;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by Emerson.Sanchez on 22/3/2019.
 */
@Service
@Transactional
public class ChequeAdministrationServiceImpl extends AbstractXmlApiBusinessService<CiAdministration, CiAdministrationJpe,
        CiAdministrationPk, DEPCISTATUSUPDATEAPIType, DEPCISTATUSUPDATEAPIType> implements ChequeAdministrationService, BusinessObjectValidationCapable<CiAdministration> {
    private static LinkedHashMap<String, LinkTable> constructorMap;

    private static QueryCondition queryCondition;

    static {
        constructorMap = new LinkedHashMap<String, LinkTable>();
        constructorMap.put("seqNo", new LinkTable(CiAdministrationJpe.class));
        constructorMap.put("procType", new LinkTable(CiTypeJpe.class));
        constructorMap.put("denomination", new LinkTable(CiAdministrationJpe.class));
        constructorMap.put("prefix", new LinkTable(CiAdministrationJpe.class));
        constructorMap.put("chequeRefNo", new LinkTable(CiAdministrationJpe.class));
        constructorMap.put("branch", new LinkTable(CiAdministrationJpe.class));
        constructorMap.put("amount", new LinkTable(CiAdministrationJpe.class));
        constructorMap.put("chequeStatus", new LinkTable(CiAdministrationJpe.class));
        constructorMap.put("narrative", new LinkTable(CiAdministrationJpe.class));
        constructorMap.put("chequeType", new LinkTable(CiAdministrationJpe.class));
        constructorMap.put("ccy", new LinkTable(CiAdministrationJpe.class));
        constructorMap.put("bankCode", new LinkTable(CiAdministrationJpe.class));
        constructorMap.put("bankBranch", new LinkTable(CiAdministrationJpe.class));
        constructorMap.put("chequeNo", new LinkTable(CiAdministrationJpe.class));

        queryCondition = new QueryCondition();
        queryCondition.where("chequeType", QueryType.EQUALS, new LinkTable(CiTypeJpe.class, "chequeType"));
    }

    @Override
    protected DEPCISTATUSUPDATEAPIType transformBdoToXmlApiRqCreate(CiAdministration ciAdministration) {
        return transformCiAdministrationToDEPCISTATUSUPDATEAPIType(ciAdministration, CbsXmlApiOperation.INSERT);
    }

    @Override
    protected DEPCISTATUSUPDATEAPIType transformBdoToXmlApiRqUpdate(CiAdministration ciAdministration) {
        return transformCiAdministrationToDEPCISTATUSUPDATEAPIType(ciAdministration, CbsXmlApiOperation.UPDATE);
    }

    @Override
    protected DEPCISTATUSUPDATEAPIType transformBdoToXmlApiRqDelete(CiAdministration ciAdministration) {
        return transformCiAdministrationToDEPCISTATUSUPDATEAPIType(ciAdministration, CbsXmlApiOperation.DELETE);
    }

    private DEPCISTATUSUPDATEAPIType transformCiAdministrationToDEPCISTATUSUPDATEAPIType(
            CiAdministration dataObject, CbsXmlApiOperation operation) {

        DEPCISTATUSUPDATEAPIType apiType = new DEPCISTATUSUPDATEAPIType();
        super.setTechColsFromDataObject(dataObject, apiType);

        apiType.setOPERATION(operation.getOperation());
        apiType.setCHEQUESTATUS(dataObject.getChequeStatus());
        apiType.setNARRATIVE(dataObject.getNarrative());
        apiType.setSEQNO(dataObject.getSeqNo());
        return apiType;
    }

    @Override
    protected CiAdministration processXmlApiRs(CiAdministration ciAdministration,
                                               DEPCISTATUSUPDATEAPIType depcistatusupdateapiType) {
        return ciAdministration;
    }

    @Override
    protected List<CiAdministration> processXmlApiListRs(CiAdministration ciAdministration,
                                                         DEPCISTATUSUPDATEAPIType depcistatusupdateapiType) {
        return null;
    }

    @Override
    protected Class<DEPCISTATUSUPDATEAPIType> getXmlApiResponseClass() {
        return DEPCISTATUSUPDATEAPIType.class;
    }

    @Override
    protected CiAdministrationPk getIdFromDataObjectInstance(CiAdministration dataObject) {
        CiAdministrationJpe jpe = jaxbSdoHelper.unwrap(dataObject, CiAdministrationJpe.class);
        return new CiAdministrationPk(jpe.getSeqNo(), jpe.getChequeNo());
    }

    @Override
    protected EntityPath<CiAdministrationJpe> getEntityPath() {
        return QCiAdministrationJpe.ciAdministrationJpe;
    }

    @Override
    public List<CiAdministration> query(int offset, int resultLimit, String groupBy, String order,
                               Map<String, Object> filters) {
        return super.query(queryCondition, offset, resultLimit, groupBy, order, constructorMap);
    }

    @Override
    public List<CiAdministration> find(FindCriteria findCriteria, CbsHeader cbsHeader) {
        return super.find(findCriteria, cbsHeader, constructorMap, queryCondition);
    }

    @Override
    public CiAdministration update(CiAdministration dataObject) {
        return super.update(dataObject);
    }

    @Override
    public Long count(FindCriteria findCriteria, CbsHeader cbsHeader) {
        FindCriteriaJpe jpe = jaxbSdoHelper.unwrap(findCriteria, FindCriteriaJpe.class);
        return dataService.getRowCount(CiAdministrationJpe.class, jpe, constructorMap, queryCondition);
    }


}
