package com.silverlakesymmetri.cbs.dep.svc;

import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.svc.BusinessService;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.DepPurgeParam;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.DepPurgeParamJpe;

import java.util.List;
import java.util.Map;

/**
 * Created by Emerson.Sanchez on 16/5/2022.
 */
public interface DepPurgeParamService extends BusinessService<DepPurgeParam, DepPurgeParamJpe>{
    public static final String SVC_OP_NAME_DEP_PURGE_PARAM_SERVICE_GET = "DepPurgeParamService.get";
    public static final String SVC_OP_NAME_DEP_PURGE_PARAM_SERVICE_QUERY = "DepPurgeParamService.query";
    public static final String SVC_OP_NAME_DEP_PURGE_PARAM_SERVICE_CREATE = "DepPurgeParamService.create";
    public static final String SVC_OP_NAME_DEP_PURGE_PARAM_SERVICE_UPDATE = "DepPurgeParamService.update";
    public static final String SVC_OP_NAME_DEP_PURGE_PARAM_SERVICE_DELETE = "DepPurgeParamService.delete";
    public static final String SVC_OP_NAME_DEP_PURGE_PARAM_SERVICE_FIND = "DepPurgeParamService.find";

    @ServiceOperation(name = SVC_OP_NAME_DEP_PURGE_PARAM_SERVICE_CREATE)
    public DepPurgeParam create(DepPurgeParam dataObject);

    @ServiceOperation(name = SVC_OP_NAME_DEP_PURGE_PARAM_SERVICE_UPDATE)
    public DepPurgeParam update(DepPurgeParam dataObject);

    @ServiceOperation(name = SVC_OP_NAME_DEP_PURGE_PARAM_SERVICE_DELETE)
    public boolean delete(DepPurgeParam dataObject);

    @ServiceOperation(name = SVC_OP_NAME_DEP_PURGE_PARAM_SERVICE_QUERY)
    public List<DepPurgeParam> query(int offset, int resultLimit, String groupBy, String order,
                                 Map<String, Object> filters);

    @ServiceOperation(name = SVC_OP_NAME_DEP_PURGE_PARAM_SERVICE_FIND)
    public List<DepPurgeParam> find(FindCriteria findCriteria, CbsHeader cbsHeader);

    @ServiceOperation(name = SVC_OP_NAME_DEP_PURGE_PARAM_SERVICE_GET, type = ServiceOperation.ServiceOperationType.GET)
    public DepPurgeParam getByPk(String publicKey, DepPurgeParam reference);
}
