package com.silverlakesymmetri.cbs.dep.svc.mapper;

import org.mapstruct.Context;
import org.mapstruct.DecoratedWith;
import org.mapstruct.InheritConfiguration;
import org.mapstruct.InheritInverseConfiguration;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingTarget;
import org.mapstruct.Mappings;

import com.silverlakesymmetri.cbs.commons.jpa.util.DateTimeHelper;
import com.silverlakesymmetri.cbs.commons.xmlapi.enums.CbsXmlApiOperation;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.OdOvdAdHocJpe;
import com.silverlakesymmetri.cbs.dep.svc.mapper.decorator.OdOvdAdHocServiceDecorator;
import com.silverlakesymmetri.cbs.dep.svc.mapper.mapping.OdOvdAdHocToDEPODOVDAPITypeMapper;
import com.silverlakesymmetri.cbs.dep.xmlapi.DEPODOVDAPIType;

@Mapper(config = OdOvdAdHocToDEPODOVDAPITypeMapper.class, uses = { DateTimeHelper.class })
@DecoratedWith(OdOvdAdHocServiceDecorator.class)
public interface OdOvdAdHocServiceMapper {
	@Mappings({ @Mapping(expression = "java(oper != null ? oper.getOperation() : null)", target = "OPERATION") })
	@InheritConfiguration
	public DEPODOVDAPIType mapToApi(OdOvdAdHocJpe jpe, @Context CbsXmlApiOperation oper);
	@InheritInverseConfiguration(name = "mapOdOvdAdHocToDEPODOVDAPIType")
	@Mappings({
		@Mapping(target = "maturityDate", source = "MATURITYDATE", qualifiedByName = { "DateTimeHelper", "convertCbsApiDateToString" }),
		@Mapping(target = "tranDate", source = "TRANDATE", qualifiedByName = { "DateTimeHelper", "convertCbsApiDateToString" }),
		@Mapping(target = "effectDate", source = "EFFECTDATE", qualifiedByName = { "DateTimeHelper", "convertCbsApiDateToString" }),
		@Mapping(target = "startAmortizationDate", source = "STARTAMORTIZATIONDATE", qualifiedByName = { "DateTimeHelper", "convertCbsApiDateToString" }),
		@Mapping(target = "endAmortizationDate", source = "ENDAMORTIZATIONDATE", qualifiedByName = { "DateTimeHelper", "convertCbsApiDateToString" }),
		@Mapping(target = "rbTranDate", source = "RBTRANDATE", qualifiedByName = { "DateTimeHelper", "convertCbsApiDateToString" }),
		@Mapping(target = "scDate", source = "SCDATE", qualifiedByName = { "DateTimeHelper", "convertCbsApiDateToString" })
	})
	public OdOvdAdHocJpe mapToJpe(DEPODOVDAPIType api, @MappingTarget OdOvdAdHocJpe jpe);
}

