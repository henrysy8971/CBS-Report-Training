package com.silverlakesymmetri.cbs.dep.svc.impl;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.mysema.query.types.EntityPath;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.svc.AbstractBusinessService;
import com.silverlakesymmetri.cbs.commons.svc.BusinessObjectValidationCapable;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.AtmTerminal;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.AtmTerminalJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.QAtmTerminalJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.id.AtmTerminalPk;
import com.silverlakesymmetri.cbs.dep.svc.AtmTerminalService;

@Service
@Transactional
public class AtmTerminalServiceImpl extends AbstractBusinessService<AtmTerminal, AtmTerminalJpe, AtmTerminalPk>
		implements AtmTerminalService, BusinessObjectValidationCapable<AtmTerminal> {

	@Override
	protected EntityPath<AtmTerminalJpe> getEntityPath() {
		return QAtmTerminalJpe.atmTerminalJpe;
	}

	@Override
	protected AtmTerminalPk getIdFromDataObjectInstance(AtmTerminal dataObject) {
		return new AtmTerminalPk(dataObject.getBranch(), dataObject.getAcqTerminal());
	}

	@Override
	public AtmTerminal getByPk(String publicKey, AtmTerminal reference) {
		return super.getByPk(publicKey, reference);
	}

	@Override
	public AtmTerminal create(AtmTerminal objectInstanceIdentifier) {
		return super.create(objectInstanceIdentifier);
	}

	@Override
	public AtmTerminal update(AtmTerminal dataObject) {
		return super.update(dataObject);
	}

	@Override
	public boolean delete(AtmTerminal dataObject) {
		return super.delete(dataObject);
	}

	@Override
	public List<AtmTerminal> query(int offset, int resultLimit, String groupBy, String order,
			Map<String, Object> filters) {
		return super.query(offset, resultLimit, groupBy, order, filters);
	}

	@Override
	public List<AtmTerminal> find(FindCriteria findCriteria, CbsHeader cbsHeader) {
		return super.find(findCriteria, cbsHeader);
	}

}
