package com.silverlakesymmetri.cbs.dep.svc.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.mysema.query.types.EntityPath;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.svc.AbstractBusinessService;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.CiPrefix;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.CiPrefixHdr;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.CiPrefixHdrJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.CiPrefixJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.QCiPrefixHdrJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.id.CiPrefixHdrPk;
import com.silverlakesymmetri.cbs.dep.svc.CiPrefixService;

@Service
@Transactional
public class CiPrefixServiceImpl extends AbstractBusinessService<CiPrefixHdr, CiPrefixHdrJpe, CiPrefixHdrPk> implements CiPrefixService {

	@Override
	protected EntityPath<CiPrefixHdrJpe> getEntityPath() {
		return QCiPrefixHdrJpe.ciPrefixHdrJpe;
	}

	@Override
	protected CiPrefixHdrPk getIdFromDataObjectInstance(CiPrefixHdr dataObject) {
		return new CiPrefixHdrPk(dataObject.getChequeType(), dataObject.getDenomGroup());
	}

	@Override
	public CiPrefixHdr getByPk(String publicKey, CiPrefixHdr reference) {
		return super.getByPk(publicKey, reference);
	}

	@Override
	public CiPrefixHdr create(CiPrefixHdr dataObject) {
		return super.create(dataObject);
	}
	
	@Override
	public List<CiPrefixHdr> query(int offset, int resultLimit, String groupBy, String order, Map<String, Object> filters) {
		return super.query(offset, resultLimit, groupBy, order, filters);
	}

	@Override
	public CiPrefixHdr update(CiPrefixHdr dataObject) {
		return super.update(dataObject);
	}
	
	@Override
	public boolean delete(CiPrefixHdr dataObject) {
		return super.delete(dataObject);
	}

	@Override
	public List<CiPrefixHdr> find(FindCriteria findCriteria, CbsHeader cbsHeader) {
		return super.find(findCriteria, cbsHeader);
	}

	@Override
	public List<CiPrefix> findChildList(Map<String, Object> queryParams) {
		List<CiPrefix> list = new ArrayList<CiPrefix>();
		list = this.queryChildList(queryParams);
		
		return list;
	}
	
	private List<CiPrefix> queryChildList(Map<String, Object> params){
		List<CiPrefix> list = new ArrayList<CiPrefix>();
		String prefix = (String) params.get("prefix");
		String chequeType = (String) params.get("chequeType");
        int limit = params.get("limit") != null ? Integer.parseInt((String)params.get("limit")) : 10;
        int offset = params.get("offset") != null ? Integer.parseInt((String)params.get("offset")) : 0;
		String query = "Select a from CiPrefixJpe a where a.activeYn = true ";
		
		params.remove("limit");
		params.remove("offset");
		params.remove("groupBy");
		params.remove("order");
		
		
		if(params.get("denom") != null)
		{
			query = query + "AND a.denom = :denom ";
			params.put("denom", Double.valueOf((String) params.get("denom")));
		}
		
		if(prefix != null)
		{
			query = query + "AND a.prefix = :prefix ";
			params.put("prefix", prefix);
		}
		
		if(chequeType != null)
		{
			query = query + "AND a.chequeType = :chequeType ";
			params.put("chequeType", chequeType);
		}
		
		List<CiPrefixJpe> jpeList = dataService.findWithQuery(query, params, offset, limit, CiPrefixJpe.class);
		if(jpeList != null && !jpeList.isEmpty())
		{
			for(CiPrefixJpe jpe : jpeList) {
				list.add(jaxbSdoHelper.wrap(jpe, CiPrefix.class));
			}
		}
		return list;
	}
	
	

}
