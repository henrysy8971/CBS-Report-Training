package com.silverlakesymmetri.cbs.dep.svc.mapper.mapping;

import org.mapstruct.MapperConfig;
import org.mapstruct.Mapping;
import org.mapstruct.Mappings;

import com.silverlakesymmetri.cbs.commons.jpa.util.DateTimeHelper;
import com.silverlakesymmetri.cbs.csd.jpa.mapping.sdo.ProdScIndividualJpe;
import com.silverlakesymmetri.cbs.csd.xmlapi.CSDPRODSCINDIVIDUALAPIType;

@MapperConfig(uses={ DateTimeHelper.class})
public interface ProdScIndividualToCSDPRODSCINDIVIDUALAPITypeMapper {

	@Mappings({
		@Mapping(target = "PRODSCINDVLREFNO", source = "prodScIndvlRefNo"),
		@Mapping(target = "MODULEID", source = "moduleId"),
		@Mapping(target = "SUBTYPE", source = "subType"),
		@Mapping(target = "SCTYPE", source = "scType"),
		@Mapping(target = "SCRATETYPE", source = "scRateType"),
		@Mapping(target = "EFFECTFROMDATE", source = "effectFromDate", qualifiedByName = { "DateTimeHelper", "convertDateToCbsXmlApiDate" }),
		@Mapping(target = "EFFECTTODATE", source = "effectToDate", qualifiedByName = { "DateTimeHelper", "convertDateToCbsXmlApiDate" }),
		@Mapping(target = "REASONTYPE", source = "reasonType"),
		@Mapping(target = "REASONDESC", source = "reasonDesc"),
		@Mapping(target = "PERCSTANDARDSC", source = "percStandardSc"),
		@Mapping(target = "MINSCAMT", source = "minScAmt"),
		@Mapping(target = "MAXSCAMT", source = "maxScAmt"),
		@Mapping(target = "MAXDISCOUNTSCAMT", source = "maxDiscountScAmt"),
		@Mapping(target = "CCY", source = "ccy"),
	})

	public CSDPRODSCINDIVIDUALAPIType mapProdScIndividualToCSDPRODSCINDIVIDUALAPIType(ProdScIndividualJpe jpe);

	public ProdScIndividualJpe mapCSDPRODSCINDIVIDUALAPITypeToProdScIndividual(CSDPRODSCINDIVIDUALAPIType  api);

}
