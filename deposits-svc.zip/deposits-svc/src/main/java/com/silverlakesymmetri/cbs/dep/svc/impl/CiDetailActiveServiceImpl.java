package com.silverlakesymmetri.cbs.dep.svc.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.mysema.query.types.EntityPath;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.svc.AbstractBusinessService;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.CiDetailActive;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.CiDetailActiveJpe;
import com.silverlakesymmetri.cbs.dep.svc.CiDetailActiveService;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.QCiDetailActiveJpe;
import  com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.util.DepJpeConstants;

@Service
@Transactional
public class CiDetailActiveServiceImpl extends AbstractBusinessService<CiDetailActive, CiDetailActiveJpe, String> 
	implements CiDetailActiveService{

	@Override
	protected String getIdFromDataObjectInstance(CiDetailActive dataObject) {
		return dataObject.getSeqNo().toString();
	}

	@Override
	protected EntityPath<CiDetailActiveJpe> getEntityPath() {
		return QCiDetailActiveJpe.ciDetailActiveJpe;
	}
	
	@Override
	public List<CiDetailActive> find(FindCriteria findCriteria, CbsHeader cbsHeader){
		return super.find(findCriteria, cbsHeader);
	}
	
	@Override 
	public List<CiDetailActive> query(int offset, int resultLimit, String groupBy, String order,
			Map<String, Object> filters){
		return super.query(offset, resultLimit, groupBy, order, filters);
	}
	
	@Override
	public List<CiDetailActive> findStartChequeNo(Map<String, Object> queryParams){
		List<CiDetailActive> list = new ArrayList<CiDetailActive>();
		list = this.queryStartChequeNo(queryParams);
		return list;
	}

	@Override
	public List<CiDetailActive> findEndChequeNo(Map<String, Object> queryParams) {
		List<CiDetailActive> list = new ArrayList<CiDetailActive>();
		list = this.queryEndChequeNo(queryParams);
		return list;
	}
	
	
	private List<CiDetailActive> queryStartChequeNo(Map<String, Object> queryParams){
		List<CiDetailActive> list = new ArrayList<CiDetailActive>();
        String ccy = (String) queryParams.get("ccy");
        String chequeType = (String) queryParams.get("chequeType");
        String prefix = (String) queryParams.get("prefix");
        String branch = (String) queryParams.get("branch");
        String officerId = (String) queryParams.get("officerId");
        String transferMode = (String) queryParams.get("transferMode"); 
        int limit = queryParams.get("limit") != null ? Integer.parseInt((String)queryParams.get("limit")) : 10;
        int offset = queryParams.get("offset") != null ? Integer.parseInt((String)queryParams.get("offset")) : 0;
        
        final Map<String, Object> params = new HashMap<>();
        params.put("ccy", ccy);
        params.put("chequeType", chequeType);
        params.put("branch", branch);
		
        String query = "Select s from CiDetailActiveJpe s "
        		+ "where s.ccy = :ccy "
        		+ "and s.chequeType = :chequeType "
        		+ "and s.branch = :branch ";
        
        if (prefix != null) {
        	query = query + "and s.prefix = :prefix ";
            params.put("prefix", prefix);
        }
        
        if(transferMode.equals("CT")) {
        	query = query + "AND s.chequeStatus = 'DIS' ";
        }else {
        	query = query + "AND s.chequeStatus = 'ACT' "
        			+ "AND s.officerId = :officerId ";
        	params.put("officerId", officerId);
        }
        
        if(queryParams.get("denom") != null) {
        	query = query + "and s.denomination = :denomination ";
        	params.put("denomination", Long.valueOf((String) queryParams.get("denom")));
        }
        
        if(queryParams.get("seqNo") != null) {
    		query = query + "AND s.seqNo = :seqNo ";
    		params.put("seqNo", Long.valueOf((String) queryParams.get("seqNo")));
    	}
    	if(queryParams.get("chequeNo") != null) {
    		query = query + "AND s.chequeNo = :chequeNo ";
    		params.put("chequeNo", Long.valueOf((String) queryParams.get("chequeNo")));
    	}
        
    	List<CiDetailActiveJpe> jpeList = dataService.findWithQuery(query, params, offset, limit, CiDetailActiveJpe.class);
    	
    	if(jpeList != null && !jpeList.isEmpty())
		{
    		for(CiDetailActiveJpe jpe: jpeList) {
    			list.add(jaxbSdoHelper.wrap(jpe, CiDetailActive.class));
    		}
		}
        
		return list;
	}
	
	private List<CiDetailActive> queryEndChequeNo(Map<String, Object> queryParams){
		List<CiDetailActive> list = new ArrayList<CiDetailActive>();
        String ccy = (String) queryParams.get("ccy");
        String chequeType = (String) queryParams.get("chequeType");
        String prefix = (String) queryParams.get("prefix");
        String branch = (String) queryParams.get("branch");
        String officerId = (String) queryParams.get("officerId");
        Long chequeAssignNo = Long.valueOf(((String) queryParams.get("chequeAssignNo")).trim());
        String transferMode = (String) queryParams.get("transferMode");
        int limit = queryParams.get("limit") != null ? Integer.parseInt((String)queryParams.get("limit")) : 10;
        int offset = queryParams.get("offset") != null ? Integer.parseInt((String)queryParams.get("offset")) : 0;
        

        final Map<String, Object> params = new HashMap<>();
        params.put("ccy", ccy);
        params.put("chequeType", chequeType);
        params.put("branch", branch);
        params.put("chequeAssignNo", chequeAssignNo);
		
        String query = "Select s from CiDetailActiveJpe s "
        		+ "where s.ccy = :ccy "
        		+ "and s.chequeType = :chequeType "
        		+ "and s.branch = :branch "
        		+ "AND s.chequeNo >= :chequeAssignNo ";
        
        if(transferMode.equals("CT")) {
        	query = query + "AND s.chequeStatus = 'DIS' ";
        }else {
        	query = query + "AND s.chequeStatus = 'ACT' "
        			+ "AND s.officerId = :officerId ";
        	params.put("officerId", officerId);
        }
        
        if(queryParams.get("denom") != null) {
        	query = query + "and s.denomination = :denomination ";
        	params.put("denomination", Long.valueOf((String) queryParams.get("denom")));
        }
        
        if(prefix != null) {
        	query = query + "and s.prefix = :prefix ";
        	params.put("prefix", prefix);
        }
        
        if(queryParams.get("seqNo") != null) {
    		query = query + "AND s.seqNo = :seqNo ";
    		params.put("seqNo", Long.valueOf((String) queryParams.get("seqNo")));
    	}
    	if(queryParams.get("chequeNo") != null) {
    		query = query + "AND s.chequeNo = :chequeNo ";
    		params.put("chequeNo", Long.valueOf((String) queryParams.get("chequeNo")));
    	}
        
    	List<CiDetailActiveJpe> jpeList = dataService.findWithQuery(query, params, offset, limit, CiDetailActiveJpe.class);
    	
    	if(jpeList != null && !jpeList.isEmpty())
		{
    		for(CiDetailActiveJpe jpe: jpeList) {
    			list.add(jaxbSdoHelper.wrap(jpe, CiDetailActive.class));
    		}
		}
    	
        
		return list;
	}
}
