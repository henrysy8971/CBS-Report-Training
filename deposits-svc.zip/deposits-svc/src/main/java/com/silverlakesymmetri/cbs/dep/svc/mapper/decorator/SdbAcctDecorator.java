package com.silverlakesymmetri.cbs.dep.svc.mapper.decorator;

import java.util.Map;

import org.mapstruct.Context;
import org.mapstruct.MappingTarget;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

import com.silverlakesymmetri.cbs.commons.xmlapi.enums.CbsXmlApiOperation;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.SdbAcctJpe;
import com.silverlakesymmetri.cbs.dep.svc.mapper.SdbAcctMapper;
import com.silverlakesymmetri.cbs.dep.xmlapi.DEPSDBACCTAPIType;

public abstract class SdbAcctDecorator extends FeeServiceDecorator implements SdbAcctMapper{
	
	@Autowired
	@Qualifier("delegate")
	protected  SdbAcctMapper delegate;
	
	
	@Override
	public DEPSDBACCTAPIType mapToApi(SdbAcctJpe jpe, @Context CbsXmlApiOperation oper, @Context Map otherInfo){
		
		DEPSDBACCTAPIType req = (DEPSDBACCTAPIType)delegate.mapToApi(jpe, oper, otherInfo);
		mapFeeToApi(jpe, req);
		return  req;
	}
	
	@Override
	public SdbAcctJpe mapToJpe(DEPSDBACCTAPIType api, @MappingTarget SdbAcctJpe jpe){
				
		if (jpe == null) {
			jpe = new SdbAcctJpe();
		}
		if (api == null) {
			return jpe;
		}
		jpe = delegate.mapToJpe(api, jpe);
//		mapFeeToJpe(api, jpe);
		return jpe;		
	}
}


