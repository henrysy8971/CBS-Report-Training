package com.silverlakesymmetri.cbs.dep.svc.mapper.mapping;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Mappings;

import com.silverlakesymmetri.cbs.commons.jpa.util.DateTimeHelper;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.ScDetailInJpe;
import com.silverlakesymmetri.cbs.dep.xmlapi.DEPFEEAPPLYDTLINTType;

@Mapper(uses = { DateTimeHelper.class })
public interface ScDetailInToDEPFEEAPPLYDTLINTTypeMapper {

	@Mappings({
	    @Mapping(source = "position", target = "POSITION"),
	    @Mapping(source = "scEventType", target = "SCEVENTTYPE"),
	    @Mapping(source = "scEventSubType", target = "SCEVENTSUBTYPE"),
	    @Mapping(source = "input1", target = "INPUT1"),
	    @Mapping(source = "input2", target = "INPUT2"),
	    @Mapping(source = "input3", target = "INPUT3"),
	    @Mapping(source = "input4", target = "INPUT4"),
	    @Mapping(source = "input5", target = "INPUT5"),
	    @Mapping(source = "input6", target = "INPUT6"),
	    @Mapping(source = "input7", target = "INPUT7"),
	    @Mapping(source = "input8", target = "INPUT8"),
	    @Mapping(source = "scType", target = "SCTYPE"),
	    @Mapping(source = "scRateType", target = "SCRATETYPE"),
	    @Mapping(source = "calcBalType", target = "CALCBALTYPE"),
	    @Mapping(source = "calcBal", target = "CALCBAL"),
	    @Mapping(source = "calcBalCcy", target = "CALCBALCCY"),
	    @Mapping(source = "scMode", target = "SCMODE"),
	    @Mapping(source = "reasonType", target = "REASONTYPE"),
	    @Mapping(source = "reasonDesc", target = "REASONDESC"),
	    @Mapping(source = "scAmt", target = "SCAMT"),
	    @Mapping(source = "scTaxAmt", target = "SCTAXAMT"),
	    @Mapping(source = "scAmtStandard", target = "SCAMTSTANDARD"),
	    @Mapping(source = "scTaxAmtStandard", target = "SCTAXAMTSTANDARD"),
	    @Mapping(source = "incomeGLCode", target = "INCOMEGLCODE"),
	    @Mapping(source = "scPaymentMode", target = "SCPAYMENTMODE"),
	    @Mapping(source = "taxChargeInd", target = "TAXCHARGEIND")
	})
	public DEPFEEAPPLYDTLINTType mapScDetailInToDEPFEEAPPLYDTLIN(ScDetailInJpe jpe);
		
}

