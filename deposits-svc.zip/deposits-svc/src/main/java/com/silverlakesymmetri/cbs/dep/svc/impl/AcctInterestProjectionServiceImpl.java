package com.silverlakesymmetri.cbs.dep.svc.impl;

import com.mysema.query.types.EntityPath;
import com.silverlakesymmetri.cbs.commons.svc.AbstractXmlApiBusinessService;
import com.silverlakesymmetri.cbs.commons.xmlapi.enums.CbsXmlApiOperation;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.AcctInterestProjection;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.AcctInterestProjectionJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.QAcctInterestProjectionJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.id.AcctInterestProjectionPk;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.util.DepJpeConstants;
import com.silverlakesymmetri.cbs.dep.svc.AcctInterestProjectionService;
import com.silverlakesymmetri.cbs.dep.svc.mapper.AcctInterestProjectionServiceMapper;
import com.silverlakesymmetri.cbs.dep.xmlapi.DEPINTPROJECTIONAPIType;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class AcctInterestProjectionServiceImpl extends AbstractXmlApiBusinessService<AcctInterestProjection, AcctInterestProjectionJpe, AcctInterestProjectionPk, DEPINTPROJECTIONAPIType, DEPINTPROJECTIONAPIType>
        implements AcctInterestProjectionService {

    private static final String ACCT_NO = "acctNo";

    @Autowired
    private AcctInterestProjectionServiceMapper acctInterestProjectionServiceMapper;

    @Override
    protected AcctInterestProjectionPk getIdFromDataObjectInstance(AcctInterestProjection dataObject) {
        AcctInterestProjectionJpe jpe = jaxbSdoHelper.unwrap(dataObject);
        return new AcctInterestProjectionPk(jpe.getInternalKey());
    }

    @Override
    protected EntityPath<AcctInterestProjectionJpe> getEntityPath() {
        return QAcctInterestProjectionJpe.acctInterestProjectionJpe;
    }

    @Override
    protected DEPINTPROJECTIONAPIType transformBdoToXmlApiRqCreate(AcctInterestProjection dataObject) {
        return null;
    }

    @Override
    protected DEPINTPROJECTIONAPIType transformBdoToXmlApiRqUpdate(AcctInterestProjection dataObject) {
        return null;
    }

    @Override
    protected DEPINTPROJECTIONAPIType transformBdoToXmlApiRqDelete(AcctInterestProjection dataObject) {
        return null;
    }

    @Override
    protected AcctInterestProjection processXmlApiRs(AcctInterestProjection dataObject, DEPINTPROJECTIONAPIType apiType) {
        AcctInterestProjectionJpe jpe = acctInterestProjectionServiceMapper.mapToJpe(apiType);

        jpe.setAcctNo(getAcctNo(jpe.getInternalKey()));

        jpe.setCrIntProj((jpe.getIntEndDate() == null ? 0 : jpe.getCrIntProj()));
        jpe.setCrIntAdjProj((jpe.getIntEndDate() == null ? 0 : jpe.getCrIntAdjProj()));
        jpe.setDrIntProj((jpe.getIntEndDate() == null ? 0 : jpe.getDrIntProj()));
        jpe.setDrIntAdjProj((jpe.getIntEndDate() == null ? 0 : jpe.getDrIntAdjProj()));

        return jaxbSdoHelper.wrap(jpe);
    }

    @Override
    protected List<AcctInterestProjection> processXmlApiListRs(AcctInterestProjection dataObject, DEPINTPROJECTIONAPIType apiType) {
        return null;
    }

    @Override
    protected Class<DEPINTPROJECTIONAPIType> getXmlApiResponseClass() {
        return DEPINTPROJECTIONAPIType.class;
    }

    @Override
    public AcctInterestProjection getProjection(AcctInterestProjection dataObject) {
        return  queryDataObject(transformAcctInterestProjectionToDEPINTPROJECTIONAPIType(dataObject, CbsXmlApiOperation.QUERY));
    }

    @Override
    public AcctInterestProjection getByPk(String publicKey, AcctInterestProjection reference) {
        if(reference == null) {
            reference = jaxbSdoHelper.createSdoInstance(AcctInterestProjection.class);
        }
        reference.setAcctNo(publicKey);
        return getProjection(reference);
    }

    @Override
    public List<AcctInterestProjection> query(int offset, int resultLimit, String groupBy, String order,
                                             Map<String, Object> filters) {

        AcctInterestProjection reference = jaxbSdoHelper.createSdoInstance(AcctInterestProjection.class);
        if (filters.containsKey(ACCT_NO)) {
            reference.setAcctNo((String) filters.get(ACCT_NO));
        }

        AcctInterestProjection acctInterestProjection = getProjection(reference);
        if (acctInterestProjection == null) {
            return Collections.emptyList();
        }
        return Collections.singletonList(acctInterestProjection);
    }

    private DEPINTPROJECTIONAPIType transformAcctInterestProjectionToDEPINTPROJECTIONAPIType(AcctInterestProjection dataObject, CbsXmlApiOperation oper) {
        AcctInterestProjectionJpe jpe = jaxbSdoHelper.unwrap(dataObject);
        DEPINTPROJECTIONAPIType apiType = acctInterestProjectionServiceMapper.mapToApi(jpe, oper);

        apiType.setINTERNALKEY(getInternalKey(jpe.getAcctNo()).doubleValue());
        apiType.setINTENDDATE(dateTimeHelper.convertToCbsXmlApiDate(jpe.getIntEndDate()));
        apiType.setOPERATION(oper.getOperation());
        super.setTechColsFromDataObject(dataObject, apiType);

        return apiType;
    }

    private Long getInternalKey(String acctNo) {
        Map<String, Object> params = new HashMap<>();
        params.put("acctNo", acctNo);

        return dataService.getWithNamedQuery(DepJpeConstants.ACCT_JPE_FIND_INTERNAL_KEY_BY_ACCT_NO, params, Long.class);
    }

    private String getAcctNo(Long internalKey) {
        Map<String, Object> params = new HashMap<>();
        params.put("internalKey", internalKey);

        return dataService.getWithNamedQuery(DepJpeConstants.ACCT_JPE_FIND_ACCT_NO_BY_INTERNAL_KEY, params, String.class);
    }
}
