package com.silverlakesymmetri.cbs.dep.batch.reader;

import java.util.List;

import org.springframework.batch.core.StepExecution;

import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.MessageQJpe;
import com.silverlakesymmetri.cbs.xps.svc.batch.reader.AbstractMessageQueueGenAdviceReader;

public class DepAutoSendMessageReader extends AbstractMessageQueueGenAdviceReader<MessageQJpe> {

	@Override
	protected List<String> queryKeys(StepExecution stepExecution) {
		return super.queryKeys(stepExecution);
	}

	@Override
	protected List<MessageQJpe> getItemsBuffer(int startIdx) {
		return super.getItemsBuffer(startIdx);
	}
	
}
