package com.silverlakesymmetri.cbs.dep.svc.mapper.mapping;

import org.mapstruct.MapperConfig;
import org.mapstruct.Mapping;
import org.mapstruct.Mappings;

import com.silverlakesymmetri.cbs.commons.jpa.util.DateTimeHelper;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.ChequeCtrlJpe;
import com.silverlakesymmetri.cbs.dep.xmlapi.DEPCHQBKRQSTAPIType;

@MapperConfig(uses={ DateTimeHelper.class})
public interface ChequeCtrlToDEPCHQBKRQSTAPITypeMapper {

	@Mappings({
		@Mapping(source="seqNo", target ="SEQNO"),
		@Mapping(source="acctNo", target ="ACCTNO"),
		@Mapping(source="docType", target ="DOCTYPE"),
		//@Mapping(source="noOfLeaves", target ="NOOFLEAVES"),
		@Mapping(source="startNo", target ="STARTNO"),
		@Mapping(source="endNo", target ="ENDNO"),
		@Mapping(source="bookSize", target ="BOOKSIZE"),
		@Mapping(source="bookType", target ="BOOKTYPE"),
		@Mapping(source="printName", target ="PRINTNAMEIND"),
		@Mapping(source="collFromBranch", target ="COLLECTIONMETHOD"),
		@Mapping(source="collBranch", target ="COLLBRANCH"),
		@Mapping(source="chqbookCtrlNo", target ="CHQBKCTRLNO"),
		@Mapping(source="lastIssuedNo", target ="LASTISSUEDNO"),
		@Mapping(source="issueDate", target ="ISSUEDATE",  qualifiedByName = {"DateTimeHelper","convertDateToCbsXmlApiDate"}),
		@Mapping(source="deliveryChannel", target ="DELIVERYCHANNEL"),
		@Mapping(source="autoGenFee", target ="AUTOGENFEE")
	 })
	public DEPCHQBKRQSTAPIType mapChequeCtrlToDEPCHQBKRQSTAPIType(ChequeCtrlJpe  jpe);

}
