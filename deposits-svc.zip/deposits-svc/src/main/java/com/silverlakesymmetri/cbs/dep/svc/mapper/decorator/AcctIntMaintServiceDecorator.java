package com.silverlakesymmetri.cbs.dep.svc.mapper.decorator;

import java.util.Map;

import javax.inject.Inject;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

import com.silverlakesymmetri.cbs.commons.context.CbsRuntimeContextManager;
import com.silverlakesymmetri.cbs.commons.context.CbsSessionContext;
import com.silverlakesymmetri.cbs.commons.jpa.util.DateTimeHelper;
import com.silverlakesymmetri.cbs.commons.xmlapi.enums.CbsXmlApiOperation;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.AcctIntMaintJpe;
import com.silverlakesymmetri.cbs.dep.svc.mapper.AcctIntMaintServiceMapper;
import com.silverlakesymmetri.cbs.dep.xmlapi.DEPACCTINTMAINTAPIType;

public abstract class AcctIntMaintServiceDecorator implements AcctIntMaintServiceMapper{
	
	@Autowired
	@Qualifier("delegate")
	protected AcctIntMaintServiceMapper delegate;
	
    @Autowired
    private DateTimeHelper dateTimeHelper;

	@Inject
	protected CbsRuntimeContextManager _ctxMngr;

	@Override
	public DEPACCTINTMAINTAPIType mapToApi(AcctIntMaintJpe jpe, CbsXmlApiOperation oper, Map otherInfo){
		CbsSessionContext sessionCtx = _ctxMngr.getContext(CbsSessionContext.class);
		/*jpe.setEffectDate(dateTimeHelper.getRunDate());
		jpe.setOfficerId(sessionCtx.getUserCode());
		if(jpe.getAcctNo() != null){
			jpe.setClientName(jpe.getClientShort());
			jpe.setGlobalIdType(jpe.getAcctGlobalIdType());
			jpe.setGlobal(jpe.getAcctGlobalId());
		}*/
		DEPACCTINTMAINTAPIType req = (DEPACCTINTMAINTAPIType) delegate.mapToApi(jpe, oper, otherInfo);
		/*if(jpe.getFeeAmt() != null && jpe.getFeeAmt().doubleValue() > 0){
			req.setFEEIND("Y");
		} else {
			req.setFEEIND("N");
		}*/
		return  req;
	}
	
	@Override
	public AcctIntMaintJpe mapToJpe(DEPACCTINTMAINTAPIType api, AcctIntMaintJpe jpe){
		//Double seqNo = api.getFXMISCTRANSEQNO();
		//jpe.setMiscSeqNo(seqNo.longValue());
		return jpe;
	}
}


