package com.silverlakesymmetri.cbs.dep.svc.impl;

import java.util.*;

import com.silverlakesymmetri.cbs.commons.jpa.entity.FindCriteriaJpe;
import com.silverlakesymmetri.cbs.commons.jpa.entity.ViewCriteriaItemJpe;
import com.silverlakesymmetri.cbs.commons.jpa.entity.ViewCriteriaJpe;
import com.silverlakesymmetri.cbs.commons.jpa.entity.ViewCriteriaRowJpe;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;

import com.mysema.query.types.EntityPath;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.svc.AbstractXmlApiBusinessService;
import com.silverlakesymmetri.cbs.commons.svc.BusinessObjectValidationCapable;
import com.silverlakesymmetri.cbs.commons.xmlapi.enums.CbsXmlApiOperation;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.LockerReversalDtls;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.AcctJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.LockerReversalDtlsJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.QLockerReversalDtlsJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.TranHistJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.id.AcctPk;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.id.LockerReversalDtlsPk;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.id.TranHistPk;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.util.DepJpeConstants;
import com.silverlakesymmetri.cbs.dep.svc.LockerReversalDtlsService;
import com.silverlakesymmetri.cbs.dep.xmlapi.DEPSDBREVERSALAPIType;

@Service
public class LockerReversalDtlsServiceImpl extends
		AbstractXmlApiBusinessService<LockerReversalDtls, LockerReversalDtlsJpe, LockerReversalDtlsPk, DEPSDBREVERSALAPIType, DEPSDBREVERSALAPIType>
		implements LockerReversalDtlsService, BusinessObjectValidationCapable<LockerReversalDtls> {

	@Override
	protected EntityPath<LockerReversalDtlsJpe> getEntityPath() {
		return QLockerReversalDtlsJpe.lockerReversalDtlsJpe;
	}

	@Override
	protected LockerReversalDtlsPk getIdFromDataObjectInstance(LockerReversalDtls dataObject) {
		return new LockerReversalDtlsPk(dataObject.getScLocation(), dateTimeHelper.getDate(dataObject.getScDate()),
				dataObject.getScSeqNo());
	}

	@Override
	public LockerReversalDtls getByPk(String publicKey, LockerReversalDtls reference) {
		LockerReversalDtls lockerReversalDtls = super.getByPk(publicKey, reference);
		if (lockerReversalDtls.getRbInternalKey() != null) {
			AcctJpe acctJpe = dataService.find(AcctJpe.class, new AcctPk(lockerReversalDtls.getRbInternalKey()));
			if (acctJpe != null) {
				lockerReversalDtls.setAcctNo(acctJpe.getAcctNo());
			}
		}
		if (!StringUtils.isEmpty(lockerReversalDtls.getScDate()) && lockerReversalDtls.getScRbSeqNo() != null) {
			TranHistJpe tranHistJpe = dataService.find(TranHistJpe.class, new TranHistPk(
					lockerReversalDtls.getScRbSeqNo(), dateTimeHelper.getDate(lockerReversalDtls.getScDate())));
			if (tranHistJpe != null) {
				lockerReversalDtls.setTranDate(dateTimeHelper.getSDODateTime(tranHistJpe.getTranDate()));
				lockerReversalDtls.setEffectDate(dateTimeHelper.getSDODateTime(tranHistJpe.getEffectDate()));
				lockerReversalDtls.setReversalTranType(tranHistJpe.getReversalTranType());
			}
		}
		lockerReversalDtls.setSdbInternalKey(getSdbInternalKey(lockerReversalDtls.getContractNo()));
		lockerReversalDtls.setTaxRefNo(lockerReversalDtls.getTaxRbSeqNo());
		return lockerReversalDtls;
	}

	@Override
	public LockerReversalDtls update(LockerReversalDtls dataObject) {
		return super.update(dataObject);
	}

	@Override
	public boolean delete(LockerReversalDtls dataObject) {
		return super.delete(dataObject);
	}

	@Override
	public List<LockerReversalDtls> query(int offset, int resultLimit, String groupBy, String order,
			Map<String, Object> filters) {
		return super.query(offset, resultLimit, groupBy, order, filters);
	}

	@Override
	public List<LockerReversalDtls> find(FindCriteria findCriteria, CbsHeader cbsHeader) {
		FindCriteriaJpe fcJpe = updateFC(findCriteria);
		FindCriteria fcBdo = jaxbSdoHelper.wrap(fcJpe, FindCriteria.class);
		return super.find(fcBdo, cbsHeader);
	}

	private FindCriteriaJpe updateFC(FindCriteria findCriteria) {
		FindCriteriaJpe fc = null;
		if (findCriteria == null) {
			fc = new FindCriteriaJpe();
			ViewCriteriaJpe rootViewCriteria = new ViewCriteriaJpe();
			fc.setFilter(rootViewCriteria);
		} else {
			fc = jaxbSdoHelper.unwrap(findCriteria, true);
		}
		if (fc != null) {
			List<ViewCriteriaRowJpe> rowList = fc.getFilter().getGroup();
			for (ViewCriteriaRowJpe row : rowList) {
				List<ViewCriteriaItemJpe> itemList = row.getItem();

				for (int i = itemList.size() - 1; i >= 0; i--) {
					ViewCriteriaItemJpe vci = itemList.get(i);
					if ("scGrpStatus".equals(vci.getAttribute()) && vci.getValue().get(0) != null) {
						int len = vci.getValue().get(0).toString().length();
						List<Object> scGrpStatusList = new ArrayList<>();
						if (len > 1) {
							String[] val = vci.getValue().get(0).toString().split("");
							scGrpStatusList.addAll(Arrays.asList(val));
							vci.setOperator("IN");
							vci.setValue(scGrpStatusList);
						}
						break;
					}
				}

			}
		}
		return fc;
	}

	@Override
	protected List<LockerReversalDtls> processXmlApiListRs(LockerReversalDtls dataObject,
			DEPSDBREVERSALAPIType xmlApiRs) {
		return null;
	}

	@Override
	protected LockerReversalDtls processXmlApiRs(LockerReversalDtls dataObject, DEPSDBREVERSALAPIType xmlApiRs) {
		if (xmlApiRs != null && xmlApiRs.getSCLOCATION() != null && xmlApiRs.getSCDATE() != null
				&& xmlApiRs.getSCSEQNO() != null) {
			LockerReversalDtlsPk pk = new LockerReversalDtlsPk(xmlApiRs.getSCLOCATION(),
					dateTimeHelper.convertFromCbsXmlApiDate(xmlApiRs.getSCDATE()), xmlApiRs.getSCSEQNO());
			LockerReversalDtlsJpe jpe = dataService.find(LockerReversalDtlsJpe.class, pk);
			if (jpe != null) {
				dataObject = jaxbSdoHelper.wrap(jpe, LockerReversalDtls.class);
				dataObject.setTaxRefNo(dataObject.getTaxRbSeqNo());
				dataObject.setSdbInternalKey(getSdbInternalKey(dataObject.getContractNo()));
				if (dataObject.getRbInternalKey() != null) {
					AcctJpe acctJpe = dataService.find(AcctJpe.class, new AcctPk(dataObject.getRbInternalKey()));
					if (acctJpe != null) {
						dataObject.setAcctNo(acctJpe.getAcctNo());
					}
				}
				if (!StringUtils.isEmpty(dataObject.getScDate()) && dataObject.getScRbSeqNo() != null) {
					TranHistJpe tranHistJpe = dataService.find(TranHistJpe.class,
							new TranHistPk(dataObject.getScRbSeqNo(), dateTimeHelper.getDate(dataObject.getScDate())));
					if (tranHistJpe != null) {
						dataObject.setTranDate(dateTimeHelper.getSDODateTime(tranHistJpe.getTranDate()));
						dataObject.setEffectDate(dateTimeHelper.getSDODateTime(tranHistJpe.getEffectDate()));
						dataObject.setReversalTranType(tranHistJpe.getReversalTranType());
					}
				}
			}
		}
		return dataObject;
	}

	@Override
	protected DEPSDBREVERSALAPIType transformBdoToXmlApiRqCreate(LockerReversalDtls dataObject) {
		return null;
	}

	@Override
	protected DEPSDBREVERSALAPIType transformBdoToXmlApiRqDelete(LockerReversalDtls dataObject) {
		return transformLockerReversalDtlsToDEPSDBREVERSALAPIType(dataObject, CbsXmlApiOperation.DELETE);
	}

	@Override
	protected DEPSDBREVERSALAPIType transformBdoToXmlApiRqUpdate(LockerReversalDtls dataObject) {
		return transformLockerReversalDtlsToDEPSDBREVERSALAPIType(dataObject, CbsXmlApiOperation.UPDATE);
	}

	@Override
	protected Class<DEPSDBREVERSALAPIType> getXmlApiResponseClass() {
		return DEPSDBREVERSALAPIType.class;
	}

	private DEPSDBREVERSALAPIType transformLockerReversalDtlsToDEPSDBREVERSALAPIType(LockerReversalDtls dataObject,
			CbsXmlApiOperation oper) {
		DEPSDBREVERSALAPIType apiType = new DEPSDBREVERSALAPIType();
		super.setTechColsFromDataObject(dataObject, apiType);
		apiType.setOPERATION(oper.getOperation());
		apiType.setACCTNO(dataObject.getAcctNo());
		apiType.setINTERNALKEY(dataObject.getRbInternalKey());
		if (oper.getOperation().equalsIgnoreCase(CbsXmlApiOperation.DELETE.toString())) {
			apiType.setACTIONINDICATOR("DELETE");
		} else {
			apiType.setACTIONINDICATOR(dataObject.getActionInd());
		}
		apiType.setREFUNDPURPOSECODE(dataObject.getPurposeCode());
		apiType.setSTATUS(dataObject.getStatus());
		apiType.setSCLOCATION(dataObject.getScLocation());
		apiType.setSCDATE(dateTimeHelper.convertToCbsXmlApiDate(dataObject.getScDate()));
		apiType.setSCSEQNO(dataObject.getScSeqNo());
		apiType.setSCTYPE(dataObject.getScType());
		apiType.setRBINTERNALKEY(dataObject.getRbInternalKey());
		apiType.setSCRBSEQNO(dataObject.getScRbSeqNo());
		apiType.setTAXRBSEQNO(dataObject.getTaxRbSeqNo());
		apiType.setREASONTYPE(dataObject.getReasonType());
		apiType.setREASONDESC(dataObject.getReasonDesc());
		apiType.setSDBINTERNALKEY(getSdbInternalKey(dataObject.getContractNo()));
		return apiType;
	}

	private Long getSdbInternalKey(String contractNo) {
		if (contractNo == null) return null;
		Map<String, Object> params = new HashMap<String, Object>();
		params.put("contractNo", contractNo);
		Long sdbInternalKey = dataService.getWithNamedQuery(
				DepJpeConstants.SDB_ACCT_JPE_GET_SDB_INTERNAL_KEY_BY_CONTRACT_NO, params, Long.class);
		return sdbInternalKey;
	}

}
