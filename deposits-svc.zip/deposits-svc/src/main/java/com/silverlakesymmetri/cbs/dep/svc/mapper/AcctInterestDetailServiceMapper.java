package com.silverlakesymmetri.cbs.dep.svc.mapper;

import com.silverlakesymmetri.cbs.commons.xmlapi.enums.CbsXmlApiOperation;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.AcctInterestDetailQryJpe;
import com.silverlakesymmetri.cbs.dep.svc.mapper.mapping.AcctInterestDetailQryToDEPINTDETAILQRYAPITypeMapper;
import com.silverlakesymmetri.cbs.dep.xmlapi.DEPINTDETAILQRYAPIType;
import org.mapstruct.*;

@Mapper(config= AcctInterestDetailQryToDEPINTDETAILQRYAPITypeMapper.class)
public interface AcctInterestDetailServiceMapper {

    @Mappings({
            @Mapping(expression = "java(oper != null ? oper.getOperation() : null)", target="OPERATION")
    })
    @InheritConfiguration
    DEPINTDETAILQRYAPIType mapToApi(AcctInterestDetailQryJpe jpe, CbsXmlApiOperation oper);

    @InheritInverseConfiguration(name = "mapAcctInterestDetailQryToDEPINTDETAILQRYAPITypeMapper")
    @Mappings({
            @Mapping(target ="crIntType", source = "INTERESTDETAILREC.CRINTTYPE"),
            @Mapping(target ="crAcctLevelIntRate", source = "INTERESTDETAILREC.CRACCTLEVELINTRATE"),
            @Mapping(target ="crSpreadRate", source = "INTERESTDETAILREC.CRSPREADRATE"),
            @Mapping(target ="crIntPosted", source = "INTERESTDETAILREC.CRINTPOSTED"),
            @Mapping(target ="crIntAdjPosted", source = "INTERESTDETAILREC.CRINTADJPOSTED"),
            @Mapping(target ="crIntPaidYtd", source = "INTERESTDETAILREC.CRINTPAIDYTD"),
            @Mapping(target ="crIntAdjYtd", source = "INTERESTDETAILREC.CRINTADJYTD"),
            @Mapping(target ="crTdIntPayout", source = "INTERESTDETAILREC.CRTDINTPAYOUT"),
            @Mapping(target ="crFundType", source = "INTERESTDETAILREC.CRFUNDTYPE"),
            @Mapping(target ="crCofLiqPremia", source = "INTERESTDETAILREC.CRCOFLIQPREMIA"),
            @Mapping(target ="crCofAppType", source = "INTERESTDETAILREC.CRCOFAPPTYPE"),
            @Mapping(target ="crCofRate", source = "INTERESTDETAILREC.CRCOFRATE"),
            @Mapping(target ="crAccruedFund", source = "INTERESTDETAILREC.CRACCRUEDFUND"),
            @Mapping(target ="drIntType", source = "INTERESTDETAILREC.DRINTTYPE"),
            @Mapping(target ="drAcctLevelIntRate", source = "INTERESTDETAILREC.DRACCTLEVELINTRATE"),
            @Mapping(target ="drSpreadRate", source = "INTERESTDETAILREC.DRSPREADRATE"),
            @Mapping(target ="drIntPosted", source = "INTERESTDETAILREC.DRINTPOSTED"),
            @Mapping(target ="drIntAdjPosted", source = "INTERESTDETAILREC.DRINTADJPOSTED"),
            @Mapping(target ="drIntCollYtd", source = "INTERESTDETAILREC.DRINTCOLLYTD"),
            @Mapping(target ="drIntAdjYtd", source = "INTERESTDETAILREC.DRINTADJYTD"),
            @Mapping(target ="drFundType", source = "INTERESTDETAILREC.DRFUNDTYPE"),
            @Mapping(target ="drCofLiqPremia", source = "INTERESTDETAILREC.DRCOFLIQPREMIA"),
            @Mapping(target ="drCofAppType", source = "INTERESTDETAILREC.DRCOFAPPTYPE"),
            @Mapping(target ="drCofRate", source = "INTERESTDETAILREC.DRCOFRATE"),
            @Mapping(target ="drAccruedFund", source = "INTERESTDETAILREC.DRACCRUEDFUND"),
            @Mapping(target ="crAuthIntCtdPosted", source = "INTERESTDETAILREC.CRAUTHINTCTDPOSTED"),
            @Mapping(target ="crEoyAuthIntCtdPosted", source = "INTERESTDETAILREC.CREOYAUTHINTCTDPOSTED"),
            @Mapping(target ="crAuthAdjPosted", source = "INTERESTDETAILREC.CRAUTHADJPOSTED"),
            @Mapping(target ="crEoyAuthAdjPosted", source = "INTERESTDETAILREC.CREOYAUTHADJPOSTED"),
            @Mapping(target ="crUnauthIntCtdPosted", source = "INTERESTDETAILREC.CRUNAUTHINTCTDPOSTED"),
            @Mapping(target ="crEoyUnauthIntCtdPosted", source = "INTERESTDETAILREC.CREOYUNAUTHINTCTDPOSTED"),
            @Mapping(target ="crUnauthAdjPosted", source = "INTERESTDETAILREC.CRUNAUTHADJPOSTED"),
            @Mapping(target ="crEoyUnauthAdjPosted", source = "INTERESTDETAILREC.CREOYUNAUTHADJPOSTED"),
            @Mapping(target ="drAuthIntCtdPosted", source = "INTERESTDETAILREC.DRAUTHINTCTDPOSTED"),
            @Mapping(target ="drEoyAuthIntCtdPosted", source = "INTERESTDETAILREC.DREOYAUTHINTCTDPOSTED"),
            @Mapping(target ="drAuthAdjPosted", source = "INTERESTDETAILREC.DRAUTHADJPOSTED"),
            @Mapping(target ="drEoyAuthAdjPosted", source = "INTERESTDETAILREC.DREOYAUTHADJPOSTED"),
            @Mapping(target ="drUnauthIntCtdPosted", source = "INTERESTDETAILREC.DRUNAUTHINTCTDPOSTED"),
            @Mapping(target ="drEoyUnauthIntCtdPosted", source = "INTERESTDETAILREC.DREOYUNAUTHINTCTDPOSTED"),
            @Mapping(target ="drUnauthAdjPosted", source = "INTERESTDETAILREC.DRUNAUTHADJPOSTED"),
            @Mapping(target ="drEoyUnauthAdjPosted", source = "INTERESTDETAILREC.DREOYUNAUTHADJPOSTED"),
            @Mapping(target ="crIntAccrued", source = "INTERESTDETAILREC.CRINTACCRUED"),
            @Mapping(target ="crIntAccruedCtd", source = "INTERESTDETAILREC.CRINTACCRUEDCTD"),
            @Mapping(target ="crAuthIntAccruedCtd", source = "INTERESTDETAILREC.CRAUTHINTACCRUEDCTD"),
            @Mapping(target ="crIntAdj", source = "INTERESTDETAILREC.CRINTADJ"),
            @Mapping(target ="crUnpaidIntAccrued", source = "INTERESTDETAILREC.CRUNPAIDINTACCRUED"),
            @Mapping(target ="crUnpaidSince", source = "INTERESTDETAILREC.CRUNPAIDSINCE", qualifiedByName = {"DateTimeHelper","convertCbsApiDateToString"}),
            @Mapping(target ="crLastCycleDate", source = "INTERESTDETAILREC.CRLASTCYCLEDATE", qualifiedByName = {"DateTimeHelper","convertCbsApiDateToString"}),
            @Mapping(target ="drLastCycleDate", source = "INTERESTDETAILREC.DRLASTCYCLEDATE", qualifiedByName = {"DateTimeHelper","convertCbsApiDateToString"}),
    })
    AcctInterestDetailQryJpe mapToJpe(DEPINTDETAILQRYAPIType api);
}