package com.silverlakesymmetri.cbs.dep.svc.mapper.decorator;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

import com.silverlakesymmetri.cbs.commons.jpa.service.CbsGenericDataService;
import com.silverlakesymmetri.cbs.commons.jpa.util.JpaEntityChangeTracker;
import com.silverlakesymmetri.cbs.commons.xmlapi.enums.CbsXmlApiOperation;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.CiRdBunchRegJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.CiRdRegJpe;
import com.silverlakesymmetri.cbs.dep.svc.mapper.ChequeRegistrationServiceMapper;
import com.silverlakesymmetri.cbs.dep.svc.mapper.mapping.CiRdBunchRegToDEPCIRDBUNCHAPITypeMapper;
import com.silverlakesymmetri.cbs.dep.xmlapi.DEPCIRDAPIType;
import com.silverlakesymmetri.cbs.dep.xmlapi.DEPCIRDBUNCHCOLLType;
import com.silverlakesymmetri.cbs.dep.xmlapi.DEPCIRDBUNCHTType;
                                                                    
public abstract class ChequeRegistrationServiceDecorator implements ChequeRegistrationServiceMapper{
	
	@Autowired
	@Qualifier("delegate")
	protected  ChequeRegistrationServiceMapper delegate;
	
	@Autowired
	protected CiRdBunchRegToDEPCIRDBUNCHAPITypeMapper bunchMapper;
	
	@Autowired(required = true)
    @Qualifier("cbsGenericDataService")
    protected CbsGenericDataService dataService;
	
	@Override
	public DEPCIRDAPIType mapToApi(CiRdRegJpe jpe, CbsXmlApiOperation oper, Map otherInfo){
		
//		if (otherInfo.containsKey(BRANCH)){
//		req.setBRANCH((String) otherInfo.get(BRANCH));
//	}		
		DEPCIRDBUNCHCOLLType collection = getDEPCIRDBUNCHCOLL(jpe, oper, otherInfo);
		DEPCIRDAPIType req = null;
//		if (collection != null && collection.getDEPCIRDBUNCHAPI() != null && !collection.getDEPCIRDBUNCHAPI().isEmpty() && CbsXmlApiOperation.UPDATE.equals(oper)){
//			req = (DEPCIRDAPIType)delegate.mapToApi(jpe, CbsXmlApiOperation.DELETE, otherInfo);
//		}
//		else{
//			req = (DEPCIRDAPIType)delegate.mapToApi(jpe, oper, otherInfo);
//		}
		req = (DEPCIRDAPIType)delegate.mapToApi(jpe, oper, otherInfo);
		req.setCIRDBUNCHLIST(collection);
		
		return  req;
	}
	
	@Override
	public CiRdRegJpe mapToJpe(DEPCIRDAPIType api, CiRdRegJpe jpe){
		
		if (jpe == null){
			jpe = new CiRdRegJpe();
		}
		
		if (api == null){
			return jpe;
		}
		
		delegate.mapToJpe(api, jpe);
		
		if (api.getCIRDBUNCHLIST() == null || 
			api.getCIRDBUNCHLIST().getDEPCIRDBUNCHT() == null ||
			api.getCIRDBUNCHLIST().getDEPCIRDBUNCHT().isEmpty()){
			return jpe;
		}
		
		List <CiRdBunchRegJpe> arr = new ArrayList<CiRdBunchRegJpe>();
		for (DEPCIRDBUNCHTType ba:  api.getCIRDBUNCHLIST().getDEPCIRDBUNCHT()){
			CiRdBunchRegJpe p = bunchMapper.mapDEPCIRDBUNCHAPITypeToCiRdBunchReg(ba);
			arr.add(p);
		}
		jpe.setCiRdBunchRegList(arr);
		
		return jpe;
	}
	
	private DEPCIRDBUNCHCOLLType getDEPCIRDBUNCHCOLL(CiRdRegJpe jpe, CbsXmlApiOperation oper, Map otherInfo){
		
		DEPCIRDBUNCHCOLLType request = new DEPCIRDBUNCHCOLLType();
		
		List<DEPCIRDBUNCHTType> list = new ArrayList<DEPCIRDBUNCHTType>();
		
		if (CbsXmlApiOperation.INSERT.equals(oper)) {			
			if (jpe.getCiRdBunchRegList() != null && !jpe.getCiRdBunchRegList().isEmpty()){
				for (CiRdBunchRegJpe bunch: jpe.getCiRdBunchRegList()){
					DEPCIRDBUNCHTType ba = bunchMapper.mapCiRdBunchRegToDEPCIRDBUNCHAPIType(bunch);
					list.add(ba);
				}
				request.getDEPCIRDBUNCHT().addAll(list);
			}
			return request;
		}
		
		JpaEntityChangeTracker ct = dataService.getJpaEntityChangeTracker(jpe);
		List<CiRdBunchRegJpe> delCiRdBunchRegList = ct.getDeletedObjects("ciRdBunchRegList", CiRdBunchRegJpe.class);
		
		if (delCiRdBunchRegList != null && !delCiRdBunchRegList.isEmpty()){
			for (CiRdBunchRegJpe deleted: delCiRdBunchRegList){
				DEPCIRDBUNCHTType ba = bunchMapper.mapCiRdBunchRegToDEPCIRDBUNCHAPIType(deleted);
				list.add(ba);
			}
		}
				
		if (CbsXmlApiOperation.DELETE.equals(oper)){
			if (list!=null && !list.isEmpty()){
				request.getDEPCIRDBUNCHT().addAll(list);
			}
			return request;
		}
		
		//No update on Ci Registration
//		if (CbsXmlApiOperation.UPDATE.equals(oper)){
//			if (jpe.getCiRdBunchRegList()!= null && !jpe.getCiRdBunchRegList().isEmpty()){
//				for (CiRdBunchRegJpe bunch: jpe.getCiRdBunchRegList()){
//					JpaEntityChangeTracker track = dataService.getJpaEntityChangeTracker(bunch);
//					DEPCIRDBUNCHAPIType ba = bunchMapper.mapCiRdBunchRegToDEPCIRDBUNCHAPIType(bunch);
//					if (track.isUpdated()) {
//						ba.setOPERATION(CbsXmlApiOperation.UPDATE.getOperation());
//					}
//					else if (track.isNew() || track.isCreated()) {
//						ba.setOPERATION(CbsXmlApiOperation.INSERT.getOperation());
//					}
//				}
//			}
//		}
		
//		if (list!=null && !list.isEmpty()){
//			request.getDEPCIRDBUNCHAPI().addAll(list);
//		}
		
		return request;
	}
}


