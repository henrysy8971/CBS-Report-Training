 package com.silverlakesymmetri.cbs.dep.svc;

import java.util.List;
import java.util.Map;

import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation;
import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation.ServiceOperationType;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.svc.BusinessService;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.CiPreparation;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.CommonDepObject;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.CiPreparationJpe;
//import com.silverlakesymmetri.cbs.dep.util.CommonDepObject;


public interface CiPreparationService extends BusinessService<CiPreparation, CiPreparationJpe> {
	
	public static final String SVC_OP_NAME_CIPREPARATION_GET 	= "CiPreparationService.get";
    public static final String SVC_OP_NAME_CIPREPARATION_APPROVE = "CiPreparationService.approve";
    public static final String SVC_OP_NAME_CIPREPARATION_QUERY = "CiPreparationService.query";
    public static final String SVC_OP_NAME_CIPREPARATION_FIND = "CiPreparationService.find";
    public static final String SVC_OP_NAME_CIPREPARATION_GETTOTALS = "CiPreparationService.getTotals";
    
    @ServiceOperation(name = SVC_OP_NAME_CIPREPARATION_GET, type = ServiceOperationType.GET)
    public CiPreparation getByPk(String publicKey, CiPreparation reference);

    @ServiceOperation(name = SVC_OP_NAME_CIPREPARATION_APPROVE, type = ServiceOperationType.EXECUTE,
            useMethodForBpmApproval = true)
    public void approve(CommonDepObject objectInstanceIdentifier);
      
    @ServiceOperation(name = SVC_OP_NAME_CIPREPARATION_QUERY)
    public List<CiPreparation> query(int offset, int resultLimit, String groupBy, String order, Map<String, Object> filters);

    @ServiceOperation(name = SVC_OP_NAME_CIPREPARATION_FIND)
    public List<CiPreparation> find(FindCriteria findCriteria, CbsHeader cbsHeader);
    
    @ServiceOperation(name = SVC_OP_NAME_CIPREPARATION_GETTOTALS)
    public List<CiPreparation> getTotals(FindCriteria findCriteria, CbsHeader cbsHeader);
}
