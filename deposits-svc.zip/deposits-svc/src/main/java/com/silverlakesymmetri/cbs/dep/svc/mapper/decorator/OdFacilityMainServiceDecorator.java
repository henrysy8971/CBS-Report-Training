package com.silverlakesymmetri.cbs.dep.svc.mapper.decorator;

import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

import com.silverlakesymmetri.cbs.commons.xmlapi.enums.CbsXmlApiOperation;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.OdFacilityMainJpe;
import com.silverlakesymmetri.cbs.dep.svc.mapper.OdFacilityMainServiceMapper;
import com.silverlakesymmetri.cbs.dep.xmlapi.DEPODFACILITYAPIType;

public abstract class OdFacilityMainServiceDecorator extends FeeServiceDecorator implements OdFacilityMainServiceMapper {

	@Autowired
	@Qualifier("delegate")
	protected OdFacilityMainServiceMapper delegate;

	@SuppressWarnings("rawtypes")
	@Override
	public DEPODFACILITYAPIType mapToApi(OdFacilityMainJpe jpe, CbsXmlApiOperation oper, Map otherInfo) {
		DEPODFACILITYAPIType req = (DEPODFACILITYAPIType) delegate.mapToApi(jpe, oper, otherInfo);
		if (jpe.getOdGracePeriodPaymt() != null) {
			if (jpe.getOdGracePeriodPaymt().compareTo(0) == 0) {
				req.setODGRACEPERIODPAYMT(null);
			} else {
				req.setODGRACEPERIODPAYMT(jpe.getOdGracePeriodPaymt());
			}
		}
		if (jpe.getOdGracePeriodFee() != null) {
			if (jpe.getOdGracePeriodFee().compareTo(0) == 0) {
				req.setODGRACEPERIODFEE(null);
			} else {
				req.setODGRACEPERIODFEE(jpe.getOdGracePeriodFee());
			}
		}
		if (oper.compareTo(CbsXmlApiOperation.INSERT) == 0) {
			if (jpe.getStatus().equalsIgnoreCase("U") && jpe.getSeqNo().compareTo(0L) == 0) {
				req.setPURPOSE("C");
			}
		} else if (oper.compareTo(CbsXmlApiOperation.UPDATE) == 0) {
			req.setPURPOSE("U");
			if (StringUtils.isNotBlank(req.getODDELREASON())) {
				req.setPURPOSE("C");
			}
		} else if (oper.compareTo(CbsXmlApiOperation.DELETE) == 0) {
			req.setPURPOSE("C");
		}
		mapFeeToApi(jpe, req);
		return req;
	}

	@Override
	public OdFacilityMainJpe mapToJpe(DEPODFACILITYAPIType api, OdFacilityMainJpe jpe) {
		if (jpe == null) {
			jpe = new OdFacilityMainJpe();
		}
		if (api == null) {
			return jpe;
		}
		delegate.mapToJpe(api, jpe);
		return jpe;
	}

}
