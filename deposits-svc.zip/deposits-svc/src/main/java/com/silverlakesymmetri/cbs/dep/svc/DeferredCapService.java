package com.silverlakesymmetri.cbs.dep.svc;

import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.svc.BusinessService;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.DeferredCap;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.DeferredCapJpe;

import java.util.List;
import java.util.Map;

/**
 * Created by Emerson.Sanchez on 11/2/2021.
 */
public interface DeferredCapService extends BusinessService<DeferredCap, DeferredCapJpe> {
    public static final String SVC_OP_NAME_DEFERRED_CAP_SERVICE_QUERY = "DeferredCapService.query";
    public static final String SVC_OP_NAME_DEFERRED_CAP_SERVICE_FIND = "DeferredCapService.find";
    public static final String SVC_OP_NAME_DEFERRED_CAP_SERVICE_COUNT = "DeferredCapService.count";

    @ServiceOperation(name = SVC_OP_NAME_DEFERRED_CAP_SERVICE_QUERY)
    public List<DeferredCap> query(int offset, int resultLimit, String groupBy, String order, Map<String, Object> filters);

    @ServiceOperation(name = SVC_OP_NAME_DEFERRED_CAP_SERVICE_FIND)
    public List<DeferredCap> find(FindCriteria findCriteria, CbsHeader cbsHeader);

    @ServiceOperation(name = SVC_OP_NAME_DEFERRED_CAP_SERVICE_COUNT, type = ServiceOperation.ServiceOperationType.GET)
    public Long count(FindCriteria findCriteria, CbsHeader cbsHeader);
}
