package com.silverlakesymmetri.cbs.dep.svc.impl;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.mysema.query.types.EntityPath;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.svc.AbstractBusinessService;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.InstCode;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.InstCodeJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.QInstCodeJpe;
import com.silverlakesymmetri.cbs.dep.svc.InstCodeService;

@Service
@Transactional
public class InstCodeServiceImpl extends AbstractBusinessService<InstCode, InstCodeJpe, String>
		implements InstCodeService {

	@Override
	protected EntityPath<InstCodeJpe> getEntityPath() {
		return QInstCodeJpe.instCodeJpe;
	}

	@Override
	protected String getIdFromDataObjectInstance(InstCode dataObject) {
		return dataObject.getInstCode();
	}

	@Override
	public InstCode getByPk(String publicKey, InstCode reference) {
		return super.getByPk(publicKey, reference);
	}

	@Override
	public InstCode create(InstCode dataObject) {
		return super.create(dataObject);
	}

	@Override
	public InstCode update(InstCode dataObject) {
		return super.update(dataObject);
	}

	@Override
	public List<InstCode> query(int offset, int resultLimit, String groupBy, String order,
			Map<String, Object> filters) {
		return super.query(offset, resultLimit, groupBy, order, filters);
	}

	@Override
	public boolean delete(InstCode dataObject) {
		return super.delete(dataObject);
	}

	@Override
	public List<InstCode> find(FindCriteria findCriteria, CbsHeader cbsHeader) {
		return super.find(findCriteria, cbsHeader);
	}

}
