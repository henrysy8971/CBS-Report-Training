package com.silverlakesymmetri.cbs.dep.svc;

import java.util.List;
import java.util.Map;

import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation;
import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation.ServiceOperationType;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.svc.BusinessService;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.InwdChequeManualCapture;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.InwdChequeManualCaptureJpe;

public interface InwdChequeManualCaptureService
		extends BusinessService<InwdChequeManualCapture, InwdChequeManualCaptureJpe> {

	public static final String SVC_OP_NAME_INWDCHEQUEMANUALCAPTURE_GET = "InwdChequeManualCaptureService.get";
	public static final String SVC_OP_NAME_INWDCHEQUEMANUALCAPTURE_QUERY = "InwdChequeManualCaptureService.query";
	public static final String SVC_OP_NAME_INWDCHEQUEMANUALCAPTURE_CREATE = "InwdChequeManualCaptureService.create";
	public static final String SVC_OP_NAME_INWDCHEQUEMANUALCAPTURE_UPDATE = "InwdChequeManualCaptureService.update";
	public static final String SVC_OP_NAME_INWDCHEQUEMANUALCAPTURE_DELETE = "InwdChequeManualCaptureService.delete";
	public static final String SVC_OP_NAME_INWDCHEQUEMANUALCAPTURE_FIND = "InwdChequeManualCaptureService.find";

	@ServiceOperation(name = SVC_OP_NAME_INWDCHEQUEMANUALCAPTURE_GET, type = ServiceOperationType.GET)
	public InwdChequeManualCapture getByPk(String publicKey, InwdChequeManualCapture reference);

	@ServiceOperation(name = SVC_OP_NAME_INWDCHEQUEMANUALCAPTURE_QUERY)
	public List<InwdChequeManualCapture> query(int offset, int resultLimit, String groupBy, String order,
			Map<String, Object> filters);

	@ServiceOperation(name = SVC_OP_NAME_INWDCHEQUEMANUALCAPTURE_FIND)
	public List<InwdChequeManualCapture> find(FindCriteria findCriteria, CbsHeader cbsHeader);

	@ServiceOperation(name = SVC_OP_NAME_INWDCHEQUEMANUALCAPTURE_CREATE)
	public InwdChequeManualCapture create(InwdChequeManualCapture dataObject);

	@ServiceOperation(name = SVC_OP_NAME_INWDCHEQUEMANUALCAPTURE_UPDATE)
	public InwdChequeManualCapture update(InwdChequeManualCapture dataObject);

	@ServiceOperation(name = SVC_OP_NAME_INWDCHEQUEMANUALCAPTURE_DELETE)
	public boolean delete(InwdChequeManualCapture dataObject);

}
