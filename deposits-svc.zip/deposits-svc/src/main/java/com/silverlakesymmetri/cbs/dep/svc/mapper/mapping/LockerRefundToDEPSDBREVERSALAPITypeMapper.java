package com.silverlakesymmetri.cbs.dep.svc.mapper.mapping;

import org.mapstruct.InheritInverseConfiguration;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Mappings;

import com.silverlakesymmetri.cbs.commons.jpa.util.DateTimeHelper;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.LockerRefundJpe;
import com.silverlakesymmetri.cbs.dep.xmlapi.DEPSDBREVERSALAPIType;

@Mapper(uses={ DateTimeHelper.class})
public interface LockerRefundToDEPSDBREVERSALAPITypeMapper {

	@Mappings({ 
		@Mapping(source = "acctNo", target="ACCTNO"),
		@Mapping(source = "internalKey", target="INTERNALKEY"),
		//@Mapping(source = "ddKey", target="ACTIONINDICATOR"),
		@Mapping(source = "purposeCode", target="REFUNDPURPOSECODE"),
		@Mapping(source = "status", target="STATUS"),
		@Mapping(source = "scLocation", target="SCLOCATION"),
		@Mapping(source = "tranDate", target="SCDATE", qualifiedByName = {"DateTimeHelper","convertDateToCbsXmlApiDate"}),
		@Mapping(source = "scSeqNo", target="SCSEQNO"),
		@Mapping(source = "scType", target="SCTYPE"),
		//@Mapping(source = "feeNo", target="RBINTERNALKEY"),
		@Mapping(source = "scRbSeqNo", target="SCRBSEQNO"),
		@Mapping(source = "taxRbSeqNo", target="TAXRBSEQNO"),
		@Mapping(source = "reasonDesc", target="REASONDESC"),
		@Mapping(source = "sdbInternalKey", target="SDBINTERNALKEY")
	})
	public DEPSDBREVERSALAPIType mapLockerRefundToDEPSDBREVERSALAPIType(LockerRefundJpe jpe);
	
	@InheritInverseConfiguration(name="mapLockerRefundToDEPSDBREVERSALAPIType")
	@Mapping(target = "tranDate", source="SCDATE", qualifiedByName = {"DateTimeHelper","convertCbsApiDateToString"})
	public LockerRefundJpe mapDEPSDBREVERSALAPITypeToLockerRefund(DEPSDBREVERSALAPIType apiType);
	
}
