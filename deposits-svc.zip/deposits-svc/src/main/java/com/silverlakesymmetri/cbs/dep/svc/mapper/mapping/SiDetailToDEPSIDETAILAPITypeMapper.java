package com.silverlakesymmetri.cbs.dep.svc.mapper.mapping;

import org.mapstruct.MapperConfig;
import org.mapstruct.Mapping;
import org.mapstruct.Mappings;

import com.silverlakesymmetri.cbs.commons.jpa.util.DateTimeHelper;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.SiDetailJpe;
import com.silverlakesymmetri.cbs.dep.xmlapi.DEPSIDETAILAPIType;

@MapperConfig(uses={ DateTimeHelper.class})
public interface SiDetailToDEPSIDETAILAPITypeMapper {
	
	@Mappings({
		@Mapping(source = "INTERNALKEY",		target="internalKey"), 
		@Mapping(source = "SEQNO",				target="seqNo"), 
		@Mapping(source = "SIKEY",				target="siKey"), 
		@Mapping(source = "SIEFFECTFROMDATE",	target="siEffectFromDate", qualifiedByName = {"DateTimeHelper","convertCbsApiDateToString"}), 
		@Mapping(source = "SIEFFECTTODATE",		target="siEffectToDate",   qualifiedByName = {"DateTimeHelper","convertCbsApiDateToString"}), 
		@Mapping(source = "TRANAMT",			target="tranAmt"), 
		@Mapping(source = "PERIODFREQ",			target="periodFreq"), 
		@Mapping(source = "FREQDAY",			target="freqDay"), 
		@Mapping(source = "LASTPAYTODATE",		target="lastPaytoDate",  qualifiedByName = {"DateTimeHelper","convertCbsApiDateToString"}), 
		@Mapping(source = "NEXTPAYTODATE",		target="nextPaytoDate",  qualifiedByName = {"DateTimeHelper","convertCbsApiDateToString"}), 
		@Mapping(source = "REJECTSEQNO",		target="rejectSeqNo"), 
		@Mapping(source = "PRIORITYNO",			target="priorityNo"), 
		@Mapping(source = "STATUS",				target="status"), 
//		@Mapping(target = "LASTCHANGEOFFICER", source="CHECKDESC"), 
	 })
	public SiDetailJpe mapDEPSIDETAILAPITypeToSiDetailJpe(DEPSIDETAILAPIType api);	
	
}


