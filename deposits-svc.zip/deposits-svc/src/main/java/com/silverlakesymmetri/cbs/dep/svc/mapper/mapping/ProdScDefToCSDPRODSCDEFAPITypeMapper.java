package com.silverlakesymmetri.cbs.dep.svc.mapper.mapping;

import org.mapstruct.MapperConfig;
import org.mapstruct.Mapping;
import org.mapstruct.Mappings;

import com.silverlakesymmetri.cbs.commons.jpa.util.DateTimeHelper;
import com.silverlakesymmetri.cbs.csd.jpa.mapping.sdo.ProdScDefJpe;
import com.silverlakesymmetri.cbs.csd.xmlapi.CSDPRODSCDEFAPIType;

@MapperConfig(uses={ DateTimeHelper.class})
public interface ProdScDefToCSDPRODSCDEFAPITypeMapper {

	@Mappings({
		@Mapping(target="PRODNO",       		source="prodNo"), 
		@Mapping(target="PRODKEY",     			source="prodKey"), 
		@Mapping(target="MODULEID",     		source="moduleId"), 
		@Mapping(target="SUBTYPE",     		source="subType"), 
		@Mapping(target="STOPSC",     		source="stopSc"), 
		@Mapping(target="THIRDPARTYKEY",     		source="thirdPartyKey"), 
		@Mapping(target="SCEXCEPTION",     		source="scException"), 
		@Mapping(target="SCGROUPCODE",     		source="scGroupCode"), 
		@Mapping(target="SCPACKTYPE",     		source="scPackType"), 
		@Mapping(target="FWELIGIBLE",     		source="fwEligible"), 
		@Mapping(target="FWSTATUS",     		source="fwStatus"), 
//		@Mapping(target="TAXFILER",     		source="taxFiler"),
	 })
	public CSDPRODSCDEFAPIType mapProdScDefToCSDPRODSCDEFAPIType(ProdScDefJpe jpe);
	
	public ProdScDefJpe mapCSDPRODSCDEFAPITypeToProdScDef(CSDPRODSCDEFAPIType  api);	
}
