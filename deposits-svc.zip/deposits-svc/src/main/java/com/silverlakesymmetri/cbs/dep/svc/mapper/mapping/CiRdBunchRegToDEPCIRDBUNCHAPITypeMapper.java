package com.silverlakesymmetri.cbs.dep.svc.mapper.mapping;

import org.mapstruct.InheritInverseConfiguration;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Mappings;

import com.silverlakesymmetri.cbs.commons.jpa.util.DateTimeHelper;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.CiRdBunchRegJpe;
import com.silverlakesymmetri.cbs.dep.xmlapi.DEPCIRDBUNCHTType;

@Mapper(uses={ DateTimeHelper.class})
public interface CiRdBunchRegToDEPCIRDBUNCHAPITypeMapper {
	
	@Mappings({ 
		@Mapping(source = "chequeRdKey", target="CHEQUERDKEY"),
		@Mapping(source = "chequeType", target="CHEQUETYPE"),
		@Mapping(source = "denomination", target="DENOMINATION"),
		@Mapping(source = "quantity", target="QUANTITY"),
		@Mapping(source = "prefix", target="PREFIX"),
		@Mapping(source = "startNo", target="STARTNO"),
		@Mapping(source = "endNo", target="ENDNO"),
		@Mapping(source = "ccy", target="CCY"),
		@Mapping(source = "branch", target="BRANCH")
	 })
	public DEPCIRDBUNCHTType mapCiRdBunchRegToDEPCIRDBUNCHAPIType(CiRdBunchRegJpe jpe);	
	
	@InheritInverseConfiguration(name="mapCiRdBunchRegToDEPCIRDBUNCHAPIType")
	public CiRdBunchRegJpe mapDEPCIRDBUNCHAPITypeToCiRdBunchReg(DEPCIRDBUNCHTType api);
}

