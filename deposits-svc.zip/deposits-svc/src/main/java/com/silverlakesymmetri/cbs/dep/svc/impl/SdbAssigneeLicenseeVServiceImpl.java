package com.silverlakesymmetri.cbs.dep.svc.impl;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.mysema.query.types.EntityPath;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.svc.AbstractBusinessService;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.SdbAssigneeLicenseeV;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.QSdbAssigneeLicenseeVJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.SdbAssigneeLicenseeVJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.id.SdbAssigneeLicenseeVPk;
import com.silverlakesymmetri.cbs.dep.svc.SdbAssigneeLicenseeVService;

@Service
@Transactional
public class SdbAssigneeLicenseeVServiceImpl extends AbstractBusinessService<SdbAssigneeLicenseeV, SdbAssigneeLicenseeVJpe, SdbAssigneeLicenseeVPk> implements SdbAssigneeLicenseeVService {

	@Override
	protected SdbAssigneeLicenseeVPk getIdFromDataObjectInstance(SdbAssigneeLicenseeV arg0) {
		return new SdbAssigneeLicenseeVPk(arg0.getSdbInternalKey(), arg0.getContractNo(), arg0.getClientNo());
	}
	
	@Override
	protected EntityPath<SdbAssigneeLicenseeVJpe> getEntityPath() {
		return QSdbAssigneeLicenseeVJpe.sdbAssigneeLicenseeVJpe;
	}

	@Override
	public SdbAssigneeLicenseeV get(SdbAssigneeLicenseeV arg0) {
		return super.get(arg0);
	}

	@Override
	public List<SdbAssigneeLicenseeV> query(int offset, int resultLimit, String groupBy, String order,
			Map<String, Object> filters) {
		return super.query(offset, resultLimit, groupBy, order, filters);
	}

	@Override
	public SdbAssigneeLicenseeV getByPk(String publicKey, SdbAssigneeLicenseeV reference) {
		return super.getByPk(publicKey, reference);
	}

	@Override
	public List<SdbAssigneeLicenseeV> find(FindCriteria findCriteria, CbsHeader cbsHeader) {
		return super.find(findCriteria, cbsHeader);
	}

}