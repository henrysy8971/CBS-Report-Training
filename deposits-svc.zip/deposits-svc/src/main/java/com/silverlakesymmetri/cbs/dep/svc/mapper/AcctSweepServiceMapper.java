package com.silverlakesymmetri.cbs.dep.svc.mapper;

import java.util.Map;

import org.mapstruct.Context;
import org.mapstruct.DecoratedWith;
import org.mapstruct.InheritConfiguration;
import org.mapstruct.InheritInverseConfiguration;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingTarget;
import org.mapstruct.Mappings;

import com.silverlakesymmetri.cbs.commons.xmlapi.enums.CbsXmlApiOperation;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.AcctSweepJpe;
import com.silverlakesymmetri.cbs.dep.svc.mapper.decorator.AcctSweepServiceDecorator;
import com.silverlakesymmetri.cbs.dep.svc.mapper.mapping.AcctSweepToDEPACCTSWEEPAPITypeMapper;
import com.silverlakesymmetri.cbs.dep.xmlapi.DEPACCTSWEEPAPIType;

@Mapper(config=AcctSweepToDEPACCTSWEEPAPITypeMapper.class)
@DecoratedWith(AcctSweepServiceDecorator.class)
public interface AcctSweepServiceMapper {

	@Mappings({
		 @Mapping(expression = "java(oper != null ? oper.getOperation() : null)", target="OPERATION")
	 })
	@InheritConfiguration
	public DEPACCTSWEEPAPIType mapToApi(AcctSweepJpe jpe, @Context CbsXmlApiOperation oper, @Context Map otherInfo);
	
	@InheritInverseConfiguration(name = "mapAcctSweepToDEPACCTSWEEPAPIType")
	@Mappings({
		@Mapping(target = "effectFromDate", source="EFFECTFROMDATE", qualifiedByName = {"DateTimeHelper","convertCbsApiDateToString"}),
		@Mapping(target = "effectToDate", source="EFFECTTODATE", qualifiedByName = {"DateTimeHelper","convertCbsApiDateToString"}),
		@Mapping(target = "nextSweepDate", source="NEXTSWEEPDATE", qualifiedByName = {"DateTimeHelper","convertCbsApiDateToString"})
	})
	public AcctSweepJpe mapToJpe(DEPACCTSWEEPAPIType api, @MappingTarget AcctSweepJpe jpe);
}
