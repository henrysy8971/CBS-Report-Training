package com.silverlakesymmetri.cbs.dep.svc.impl;

import com.google.common.collect.Lists;
import com.mysema.query.types.EntityPath;
import com.silverlakesymmetri.cbs.commons.svc.AbstractXmlApiBusinessService;
import com.silverlakesymmetri.cbs.commons.xmlapi.enums.CbsXmlApiOperation;
import com.silverlakesymmetri.cbs.core.constants.CoreConstants;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.AcctCloseOnlineIntCap;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.AcctClosure;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.AcctClosureCheck;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.DepFeeApply;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.AcctClosureJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.QAcctClosureJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.util.DepJpeConstants;
import com.silverlakesymmetri.cbs.dep.svc.AcctClosureQueryService;
import com.silverlakesymmetri.cbs.dep.svc.AcctClosureService;
import com.silverlakesymmetri.cbs.dep.svc.mapper.AcctClosureQueryServiceMapper;
import com.silverlakesymmetri.cbs.dep.svc.mapper.AcctClosureServiceMapper;
import com.silverlakesymmetri.cbs.dep.svc.util.AcctHelper;
import com.silverlakesymmetri.cbs.dep.xmlapi.DEPACCTCLOSUREAPIType;
import com.silverlakesymmetri.cbs.pim.jpa.mapping.sdo.MasterAccountJpe;
import com.silverlakesymmetri.cbs.pim.jpa.mapping.sdo.util.JpeConstants;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class AcctClosureQueryServiceImpl extends AbstractXmlApiBusinessService<AcctClosure, AcctClosureJpe, String,
		DEPACCTCLOSUREAPIType, DEPACCTCLOSUREAPIType> implements AcctClosureQueryService {

	private static final String ACCT_NO_KEY = "acctNo";
	private static final String INT_PAYMENT_OPTION_KEY = "intPaymentOption";
	private static final String QUERY_BALANCE = "QUERY_BALANCE";

	@Autowired
	private AcctClosureQueryServiceMapper mapper;

	@Autowired
	private AcctHelper acctHelper;
	
	@Override
	protected DEPACCTCLOSUREAPIType transformBdoToXmlApiRqCreate(AcctClosure dataObject) {
		return null;
	}

	@Override
	protected DEPACCTCLOSUREAPIType transformBdoToXmlApiRqUpdate(AcctClosure dataObject) {
		return null;
	}

	@Override
	protected DEPACCTCLOSUREAPIType transformBdoToXmlApiRqDelete(AcctClosure dataObject) {
		return null;
	}

	@Override
	protected Class<DEPACCTCLOSUREAPIType> getXmlApiResponseClass() {
		return DEPACCTCLOSUREAPIType.class;
	}

	@Override
	protected String getIdFromDataObjectInstance(AcctClosure dataObject) {
		return dataObject.getAcctNo();
	}

	@Override
	protected EntityPath<AcctClosureJpe> getEntityPath() {
		return QAcctClosureJpe.acctClosureJpe;
	}
	
	
	private DEPACCTCLOSUREAPIType mapToDEPACCTCLOSUREAPIType(AcctClosure bdo){
	   AcctClosureJpe jpe = jaxbSdoHelper.unwrap(bdo);
	   DEPACCTCLOSUREAPIType apiType = mapper.mapToApi(jpe);
	   super.setTechColsFromDataObject(bdo, apiType);
	   return apiType;
	}

	@Override
	public List<AcctClosure> query(int offset, int resultLimit, String groupBy, String order, Map<String, Object> filters) {
		AcctClosure bdo = jaxbSdoHelper.createSdoInstance(AcctClosure.class);
		if (filters.containsKey(ACCT_NO_KEY)) {
			String acctNo = (String) filters.get(ACCT_NO_KEY);
			if (acctHelper.getInternalKeyByAcctNo(acctNo) == null) {
				return Collections.emptyList();
			}
			bdo.setAcctNo(acctNo);
			bdo.setAcctCloseOnlineIntCapRec(jaxbSdoHelper.createSdoInstance(AcctCloseOnlineIntCap.class));
			bdo.getAcctCloseOnlineIntCapRec().setAcctNo(acctNo);
		}
		if (filters.containsKey(INT_PAYMENT_OPTION_KEY)) {
			if (bdo.getAcctCloseOnlineIntCapRec() == null) {
				bdo.setAcctCloseOnlineIntCapRec(jaxbSdoHelper.createSdoInstance(AcctCloseOnlineIntCap.class));
			}
			bdo.getAcctCloseOnlineIntCapRec().setIntPaymentOption((String) filters.get(INT_PAYMENT_OPTION_KEY));
		}
		bdo.setQueryType(QUERY_BALANCE);
		return super.queryDataObjects(mapToDEPACCTCLOSUREAPIType(bdo));
	}
    
    @Override
	protected AcctClosure processXmlApiRs(AcctClosure dataObject, DEPACCTCLOSUREAPIType xmlApiRs) {
		return null;
	}

	@Override
	protected List<AcctClosure> processXmlApiListRs(AcctClosure dataObject, DEPACCTCLOSUREAPIType xmlApiRs) {
		if (dataObject == null){
			dataObject = jaxbSdoHelper.createSdoInstance(AcctClosure.class);
		}
		AcctClosureJpe jpe = jaxbSdoHelper.unwrap(dataObject);
		AcctClosure bdo = jaxbSdoHelper.wrap(mapper.mapToJpe(xmlApiRs, jpe));
		return Lists.newArrayList(bdo);
	}
}
