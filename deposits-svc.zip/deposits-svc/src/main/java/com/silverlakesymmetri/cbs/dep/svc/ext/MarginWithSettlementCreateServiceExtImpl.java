package com.silverlakesymmetri.cbs.dep.svc.ext;

import org.springframework.stereotype.Service;

import com.silverlakesymmetri.cbs.commons.logging.CbsAppLogger;
import com.silverlakesymmetri.cbs.commons.logging.CbsAppLoggerFactory;
import com.silverlakesymmetri.cbs.xps.svc.util.ReleaseAcctRestraintCapable;

@Service
public class MarginWithSettlementCreateServiceExtImpl extends AbstractXpsAcctRestraintServiceExtImpl implements ReleaseAcctRestraintCapable{

	private static CbsAppLogger logger = CbsAppLoggerFactory.getLogger(MarginWithSettlementCreateServiceExtImpl.class.getName());
	
	@Override
	public String[] getExtendedBdoNames() {
		return new String[] { "MarginWithSettlement" };
	}

	@Override
	public String[] getExtendedServiceNames() {
		return new String[] {"MarginWithSettlementService.create"};
	}

	@Override
	protected CbsAppLogger getLogger() {
		return logger;
	}

}
