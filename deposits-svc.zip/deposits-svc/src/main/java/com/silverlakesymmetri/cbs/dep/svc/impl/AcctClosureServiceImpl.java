package com.silverlakesymmetri.cbs.dep.svc.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mysema.query.types.EntityPath;
import com.silverlakesymmetri.cbs.commons.svc.AbstractXmlApiBusinessService;
import com.silverlakesymmetri.cbs.commons.xmlapi.enums.CbsXmlApiOperation;
import com.silverlakesymmetri.cbs.core.constants.CoreConstants;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.AcctClosure;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.DepFeeApply;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.SdbAcct;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.AcctClosureJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.DepFeeApplyJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.QAcctClosureJpe;
import com.silverlakesymmetri.cbs.dep.svc.AcctClosureService;
import com.silverlakesymmetri.cbs.dep.svc.mapper.AcctClosureServiceMapper;
import com.silverlakesymmetri.cbs.dep.xmlapi.DEPACCTCLOSUREAPIType;
import com.silverlakesymmetri.cbs.pim.jpa.mapping.sdo.MasterAccountJpe;
import com.silverlakesymmetri.cbs.pim.jpa.mapping.sdo.util.JpeConstants;

@Service
public class AcctClosureServiceImpl extends AbstractXmlApiBusinessService<AcctClosure, AcctClosureJpe, String,  DEPACCTCLOSUREAPIType, DEPACCTCLOSUREAPIType> implements AcctClosureService{
		
	@Autowired
	AcctClosureServiceMapper mapper;
	
	@Override
	protected DEPACCTCLOSUREAPIType transformBdoToXmlApiRqCreate(AcctClosure dataObject) {
		// TODO Auto-generated method stub
		return mapToDEPACCTCLOSUREAPIType(dataObject, CbsXmlApiOperation.UPDATE);
	}

	@Override
	protected DEPACCTCLOSUREAPIType transformBdoToXmlApiRqUpdate(AcctClosure dataObject) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	protected DEPACCTCLOSUREAPIType transformBdoToXmlApiRqDelete(AcctClosure dataObject) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	protected Class<DEPACCTCLOSUREAPIType> getXmlApiResponseClass() {
		// TODO Auto-generated method stub
		return DEPACCTCLOSUREAPIType.class;
	}

	@Override
	protected String getIdFromDataObjectInstance(AcctClosure dataObject) {
		return dataObject.getAcctNo();
	}

	@Override
	protected EntityPath<AcctClosureJpe> getEntityPath() {
		// TODO Auto-generated method stub
		return QAcctClosureJpe.acctClosureJpe;
	}

	public AcctClosure get(AcctClosure acctClosure) {
		return acctClosure;
//		return super.queryDataObject(mapToDEPACCTCLOSUREAPIType(acctClosure, CbsXmlApiOperation.VALIDATE_UPDATE));
	}
	
	
	private DEPACCTCLOSUREAPIType mapToDEPACCTCLOSUREAPIType(AcctClosure bdo, CbsXmlApiOperation oper){
			   
	   AcctClosureJpe jpe = jaxbSdoHelper.unwrap(bdo);
	   DEPACCTCLOSUREAPIType apiType =   mapper.mapToApi(jpe, oper);
	   super.setTechColsFromDataObject(bdo, apiType);	   
	   
	   return apiType;
	}
	
	private MasterAccountJpe getMasterAccount( String accountNo) {
        final Map<String, Object> param = new HashMap<String, Object>();
        param.put(CoreConstants.ATTR_ACCOUNT_DOMAIN, "DEPOSIT");
        param.put(CoreConstants.ATTR_ACCOUNT_NO, accountNo);
        MasterAccountJpe masterAccountRec = dataService.getWithNamedQuery(JpeConstants.MASTER_ACCOUNT_JPE_GET_ACCOUNT_BY_DOMAIN_ACCOUNT_NO,
                param, MasterAccountJpe.class);
        return masterAccountRec;
    }
	
	@Override
	protected AcctClosure preCreateValidation(AcctClosure acctClosure) {
		
		AcctClosureJpe jpe = jaxbSdoHelper.unwrap(acctClosure);
		
		MasterAccountJpe master = getMasterAccount(acctClosure.getAcctNo());
		jpe.setInternalKey(master.getAccountId());
		
		//why? params during fee posting should be changed accordingly
		for (DepFeeApplyJpe df : jpe.getDepFeeApplyList()){
			df.setAcctNo(acctClosure.getAcctNo());
			df.setProdNo(acctClosure.getAcctNo());
			df.setProdSubType("A");
		}
		return jaxbSdoHelper.wrap(jpe);
	}

    public AcctClosure closeAccount(AcctClosure acctClosure){
    	
    	
    	AcctClosure closed = executeStoredProcedure(acctClosure, shouldPerformValidate(acctClosure));		
    	return closed;
	}
    
    @Override
	protected AcctClosure processXmlApiRs(AcctClosure dataObject, DEPACCTCLOSUREAPIType xmlApiRs) {
		
    	if (dataObject == null){
    		dataObject = jaxbSdoHelper.createSdoInstance(AcctClosure.class);
    	}
    	AcctClosureJpe jpe = jaxbSdoHelper.unwrap(dataObject);
		mapper.mapToJpe(xmlApiRs, jpe);
		return jaxbSdoHelper.wrap(jpe);
	}

	@Override
	protected List<AcctClosure> processXmlApiListRs(AcctClosure dataObject, DEPACCTCLOSUREAPIType xmlApiRs) {
		// TODO Auto-generated method stub
		return null;
	}

}
