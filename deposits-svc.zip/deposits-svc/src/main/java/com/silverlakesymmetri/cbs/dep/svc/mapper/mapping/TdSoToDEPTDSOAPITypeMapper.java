package com.silverlakesymmetri.cbs.dep.svc.mapper.mapping;

import org.mapstruct.MapperConfig;
import org.mapstruct.Mapping;
import org.mapstruct.Mappings;

import com.silverlakesymmetri.cbs.commons.jpa.util.DateTimeHelper;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.TdSoJpe;
import com.silverlakesymmetri.cbs.dep.xmlapi.DEPTDSOAPIType;

@MapperConfig(uses={ DateTimeHelper.class})
public interface TdSoToDEPTDSOAPITypeMapper {
	

	@Mappings({
		@Mapping(constant="N", target ="HOSTCHECKFLAG"), 
		@Mapping(source="seqNo", target ="SEQNO"), 
		@Mapping(source="acctNo", target ="ACCTNO"), 
		@Mapping(source="counterpartyAcctNo", target ="COUNTERPARTYACCT"), 
		@Mapping(source="plannedWdrawal", target ="PLANNEDWDRAWAL"	), 
		@Mapping(source="plannedDeposit", target ="PLANNEDDEPOSIT"	), 
		@Mapping(source="tdLimit", target ="TDLIMIT"), 
		@Mapping(source="counterpartyLimit", target ="COUNTERPARTYLIMIT"), 
		@Mapping(source="repeatWdraw", target ="REPEATWDRAW"), 
		@Mapping(source="repeatDeposit", target ="REPEATDEPOSIT"), 
		@Mapping(source="cancel", target ="CANCEL"), 

//		@Mapping( 	source="trfDate", qualifiedByName = {"DateTimeHelper","convertDateToCbsXmlApiDate"}, target ="EFFECTDATE"), 
	 })
	public DEPTDSOAPIType mapTdSoToDEPTDSOAPIType(TdSoJpe  jpe);
	
}

