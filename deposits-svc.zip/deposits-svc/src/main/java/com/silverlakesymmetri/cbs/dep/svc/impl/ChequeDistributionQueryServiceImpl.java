package com.silverlakesymmetri.cbs.dep.svc.impl;

import com.mysema.query.types.EntityPath;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.svc.AbstractBusinessService;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.CiRdBunchDistQry;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.CiRdBunchDistQryJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.QCiRdBunchDistQryJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.id.CiRdBunchDistQryPk;
import com.silverlakesymmetri.cbs.dep.svc.ChequeDistributionQueryService;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;

@Service
public class ChequeDistributionQueryServiceImpl extends AbstractBusinessService<CiRdBunchDistQry, CiRdBunchDistQryJpe, CiRdBunchDistQryPk>
									implements ChequeDistributionQueryService {

	@Override
	protected CiRdBunchDistQryPk getIdFromDataObjectInstance(CiRdBunchDistQry dataObject) {
		// TODO Auto-generated method stub
		CiRdBunchDistQryJpe jpe = jaxbSdoHelper.unwrap(dataObject);
		return new CiRdBunchDistQryPk(jpe.getChequeRdKey(), jpe.getDenomination(), jpe.getCcy(), jpe.getStartNo(), jpe.getEndNo());
	}

	@Override
	protected EntityPath<CiRdBunchDistQryJpe> getEntityPath() {
		// TODO Auto-generated method stub
		return QCiRdBunchDistQryJpe.ciRdBunchDistQryJpe;
	}

	@Override
	public CiRdBunchDistQry getByPk(String publicKey, CiRdBunchDistQry reference) {
		// TODO Auto-generated method stub
		return super.getByPk(publicKey, reference);
	}

	@Override
	public List<CiRdBunchDistQry> query(int offset, int resultLimit, String groupBy, String order,
			Map<String, Object> filters) {
		// TODO Auto-generated method stub
		return super.query(offset, resultLimit, groupBy, order, filters);
	}

	@Override
	public List<CiRdBunchDistQry> find(FindCriteria findCriteria, CbsHeader cbsHeader) {
		// TODO Auto-generated method stub
		return super.find(findCriteria, cbsHeader);
	}
}
