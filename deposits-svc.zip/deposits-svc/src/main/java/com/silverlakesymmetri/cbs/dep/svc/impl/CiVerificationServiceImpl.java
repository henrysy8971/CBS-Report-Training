package com.silverlakesymmetri.cbs.dep.svc.impl;

import com.mysema.query.types.EntityPath;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.context.CbsSessionContext;
import com.silverlakesymmetri.cbs.commons.exception.base.CbsServiceProcessException;
import com.silverlakesymmetri.cbs.commons.jpa.entity.FindCriteriaJpe;
import com.silverlakesymmetri.cbs.commons.jpa.util.DateTimeHelper;
import com.silverlakesymmetri.cbs.commons.svc.AbstractBusinessService;
import com.silverlakesymmetri.cbs.commons.svc.ref.ReferenceNumberGeneratorService;
import com.silverlakesymmetri.cbs.commons.util.MessageUtils;
import com.silverlakesymmetri.cbs.csd.gla.jpa.mapping.sdo.ChartAccountJpe;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.CiVerificationQry;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.CiVerificationSummaryQry;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.*;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.id.CiDdArrangeDefPk;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.util.DepJpeConstants;
import com.silverlakesymmetri.cbs.dep.svc.CiVerificationService;
import com.silverlakesymmetri.cbs.gla.jpa.mapping.sdo.GlAccountJpe;
import com.silverlakesymmetri.cbs.gla.jpa.mapping.sdo.util.GlaJpeConstants;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.*;

@Service
@Transactional
public class CiVerificationServiceImpl extends AbstractBusinessService<CiVerificationQry, CiVerificationQryJpe, Long> implements CiVerificationService {

	private static final String INVALID_CHEQUE_TYPE = "CBS.B.DEP.CI_VERIFICATION_SERVICE.0001";
	private static final String SETTLEMENT_NOT_REQUIRED = "CBS.B.DEP.CI_VERIFICATION_SERVICE.0002";
	private static final String NO_DD_ARRANGEMENT = "CBS.B.DEP.CI_VERIFICATION_SERVICE.0003";
	private static final String NO_DD_ARRANGEMENT_OR_CI_GL = "CBS.B.DEP.CI_VERIFICATION_SERVICE.0004";
	private static final String NOT_SETTLED_AGAINST_NOSTRO = "CBS.B.DEP.CI_VERIFICATION_SERVICE.0005";
	private static final String NOT_SETTLED_AGAINST_SAME_NOSTRO = "CBS.B.DEP.CI_VERIFICATION_SERVICE.0006";
	private static final String MISSING_NOSTRO_BANK_NO = "CBS.B.DEP.CI_VERIFICATION_SERVICE.0007";
	private static final String NO_CI_DD_ARRANGE_OBJ = "CBS.B.DEP.CI_VERIFICATION_SERVICE.0008";
	private static final String NO_UNIQUE_NOS_GL_ACCT = "CBS.B.DEP.CI_VERIFICATION_SERVICE.0010";
    private static final String COL_PROC_TYPE = "COL";
    private static final String DFT_PROC_TYPE = "DFT";
    private static final String TCH_PROC_TYPE = "TCH";
    private static final String I_DRAFT_TYPE = "I";
    private static final String D_DRAFT_TYPE = "D";
    private static final String PPS_STATUS = "PPS";
    private static final String PPB_STATUS = "PPB";

	@Autowired
    private DateTimeHelper dateTimeHelper;

    @Autowired(required = true)
    protected MessageUtils messageUtils;

	@Autowired
	private ReferenceNumberGeneratorService referenceNumberGeneratorService;
	
    @Override
    public List<CiVerificationQry> query(int offset, int resultLimit, String groupBy, String order, Map<String, Object> filters) {
        return super.query(offset, resultLimit, groupBy, order, filters);
    }

    @Override
    public List<CiVerificationQry> find(FindCriteria findCriteria, CbsHeader cbsHeader) {
        return super.find(findCriteria, cbsHeader);
    }
    
    @Override
    public CiVerificationQry validateExecuteRequest(CiVerificationQry dataObject, String methodName) {
		return dataObject;
    }


	@Override
	public String verify(CiVerificationSummaryQry summary) {
		Long nostroInternalKey = null;
		String settleRefNo = generateSettleRefNo();
		
		List<CiVerificationQry> listForApproval = summary.getCiVerificationList();
		if (listForApproval == null || listForApproval.isEmpty()){
			return null;
		}
		
		CiVerificationSummaryQryJpe summaryJpe = jaxbSdoHelper.unwrap(summary, CiVerificationSummaryQryJpe.class);
		nostroInternalKey = validateNostroBankNo(summaryJpe);
		
		validateSettlementData(summaryJpe);
		
		List<String> chequeStatusList = new ArrayList<String>(Arrays.asList(new String[]{PPB_STATUS, PPS_STATUS}));
		List<Long> recordIdList = new ArrayList<Long>();
		for (CiVerificationQry item : listForApproval){
			recordIdList.add(item.getSeqNo());
		}
		Map<String, Object> params = new HashMap<>();
		params.put("chequeStatusList", chequeStatusList);
		params.put("recordIdList", recordIdList);
		List<CiDetailActiveJpe> result = dataService.findWithNamedQuery(DepJpeConstants.CIDETAILACTIVE_JPE_FIND_BY_SEQNO, params, CiDetailActiveJpe.class);

		if (result == null || result.isEmpty()){
			return null;
		}
		
		Map<String, List<Long>> mapSeqNo = new HashMap<String, List<Long>>();
		for (CiDetailActiveJpe detail: result){										 
			List<Long> listSeqNo = !mapSeqNo.containsKey(detail.getChequeStatus()) ? 
												 new ArrayList<Long>() : mapSeqNo.get(detail.getChequeStatus());			 
			listSeqNo.add(detail.getSeqNo());
			mapSeqNo.put(detail.getChequeStatus(), listSeqNo);
		}
		
		CbsSessionContext sessionCtx = cbsRuntimeContextManager.getContext(CbsSessionContext.class);
		
		for (String key: mapSeqNo.keySet()){
			List<Long> listSeqNo = mapSeqNo.get(key);
			
			Map<String, Object> p = new HashMap<>();
			p.put("prevChequeStatus", key);
			p.put("chequeStatus", "PPB".equals(key)?"REB":"RES");
			p.put("verifyDate", dateTimeHelper.getRunDate());
			p.put("nosInternalKey", nostroInternalKey);
			p.put("settleRefNo", settleRefNo);
			p.put("lastChangeDate", dateTimeHelper.getRunDate());
			p.put("lastChangeOfficer", sessionCtx.getUserCode());
			p.put("recordIdList", listSeqNo);
			
			dataService.bulkUpdateWithNamedQuery(DepJpeConstants.CIDETAILACTIVE_JPE_VERIFY_BY_SEQNO, p, CiDetailActiveJpe.class);
		}
		
		return settleRefNo;
	}

	@Override
	protected Long getIdFromDataObjectInstance(CiVerificationQry dataObject) {
		return dataObject.getSeqNo();
	}

	@Override
	protected EntityPath<CiVerificationQryJpe> getEntityPath() {
		return QCiVerificationQryJpe.ciVerificationQryJpe;
	}
	
	private Long validateNostroBankNo(CiVerificationSummaryQryJpe summaryJpe) {
		Long internalKey = null;
		if (summaryJpe.getNostroBankNo() != null) {
			Map<String, Object> params = new HashMap<>();
			params.put("nostroBankNo", Integer.parseInt(summaryJpe.getNostroBankNo()));
			params.put("ccy", summaryJpe.getCcy());
			List<GlAccountJpe> result = dataService.findWithNamedQuery(GlaJpeConstants.GL_ACCOUNT_CI_VERIFICATION, params, GlAccountJpe.class);
			
			if (result != null && result.size() != 1) {
				String msg = messageUtils.getMessage(NO_UNIQUE_NOS_GL_ACCT, new String[] { summaryJpe.getNostroBankNo() }, "");
	            CbsServiceProcessException exec = new CbsServiceProcessException(NO_UNIQUE_NOS_GL_ACCT, msg);
	            throw exec;
			}
			
			internalKey = result.get(0).getInternalKey();
		} else {
			internalKey = null;
		}
		
		return internalKey;
	}
	
	private void validateSettlementData(CiVerificationSummaryQryJpe summaryJpe){
		String prevGlType = null;
		String prevSettleGlCode = null;
		
		List<CiVerificationQryJpe> settlementList = summaryJpe.getCiVerificationList();
		
		for(CiVerificationQryJpe jpe : settlementList){
	        String arrangeType = null;
	        String settleGlCode = null;
	        String glType = null;
	        
	        CiTypeJpe chequeType = dataService.find(CiTypeJpe.class, jpe.getChequeType());
	        CiDdArrangeDefJpe ciDdArrangeDef = null;
	        ChartAccountJpe chartAccount = null;
	        if(chequeType == null){
	            String msg = messageUtils.getMessage(INVALID_CHEQUE_TYPE, new String[] { jpe.getChequeType() }, "Message for INVALID_CHEQUE_TYPE");
	            CbsServiceProcessException exec = new CbsServiceProcessException(INVALID_CHEQUE_TYPE, msg);
	            throw exec;
	        } else {
	        	if(DFT_PROC_TYPE.equals(jpe.getProcType())){
	        		if(I_DRAFT_TYPE.equals(chequeType.getDraftType())){
	        			if(PPS_STATUS.equals(jpe.getChequeStatus())){
	        				arrangeType = "ODDI";
	        			} else {
	        				arrangeType = "IDDI";
	        			}
	        		} else {
	        			if(PPS_STATUS.equals(jpe.getChequeStatus())){
	        				arrangeType = "ODDL";
	        			} else {
	        				arrangeType = "IDDL";
	        			}
	        		}
	        		if(!I_DRAFT_TYPE.equals(chequeType.getDraftType()) && !D_DRAFT_TYPE.equals(chequeType.getDraftType())){
	                    String msg = messageUtils.getMessage(SETTLEMENT_NOT_REQUIRED, new String[] { jpe.getChequeType(), jpe.getChequeNo().toString() }, "Message for SETTLEMENT_NOT_REQUIRED");
	                    CbsServiceProcessException exec = new CbsServiceProcessException(SETTLEMENT_NOT_REQUIRED, msg);
	                    throw exec;
	        		} else {
	        			CiDdArrangeDefPk pk = new CiDdArrangeDefPk(arrangeType, jpe.getChequeType(), jpe.getBankCode(), jpe.getBankBranch(), jpe.getCcy());
	        			ciDdArrangeDef = dataService.find(CiDdArrangeDefJpe.class, pk);
	        			if(ciDdArrangeDef == null){
		                    String msg = messageUtils.getMessage(NO_CI_DD_ARRANGE_OBJ, new String[] { arrangeType, jpe.getChequeType(), jpe.getBankCode(), jpe.getBankBranch(), jpe.getCcy() }, "Message for NO_CI_DD_ARRANGE_OBJ");
		                    CbsServiceProcessException exec = new CbsServiceProcessException(NO_CI_DD_ARRANGE_OBJ, msg);
		                    throw exec;
	        			} else {
	        				if(I_DRAFT_TYPE.equals(chequeType.getDraftType())){
	        					if(ciDdArrangeDef.getSettleGlCode() == null){
	        			            String msg = messageUtils.getMessage(NO_DD_ARRANGEMENT, new String[] { jpe.getChequeType(), jpe.getChequeNo().toString() }, "Message for NO_DD_ARRANGEMENT");
	        			            CbsServiceProcessException exec = new CbsServiceProcessException(NO_DD_ARRANGEMENT, msg);
	        			            throw exec;
	        					} else {
	        						settleGlCode = ciDdArrangeDef.getSettleGlCode();
	        					}
	        				} else {
	        					if(ciDdArrangeDef.getSettleGlCode() == null){
	        						settleGlCode = chequeType.getGlCode();
	        						if(settleGlCode == null){
	        				            String msg = messageUtils.getMessage(NO_DD_ARRANGEMENT_OR_CI_GL, new String[] { jpe.getChequeType(), jpe.getChequeNo().toString() }, "Message for NO_DD_ARRANGEMENT_OR_CI_GL");
	        				            CbsServiceProcessException exec = new CbsServiceProcessException(NO_DD_ARRANGEMENT_OR_CI_GL, msg);
	        				            throw exec;
	        						}
	        					} else {
	        						settleGlCode = ciDdArrangeDef.getSettleGlCode();
	        					}
	        				}
	        			}
	        		}
	        		if(settleGlCode != null) chartAccount = dataService.find(ChartAccountJpe.class, settleGlCode);
	        		if(prevGlType != null && chartAccount != null && !prevGlType.equals(chartAccount.getGlType())){
			            String msg = messageUtils.getMessage(NOT_SETTLED_AGAINST_NOSTRO, new String[] { jpe.getChequeType(), jpe.getChequeNo().toString() }, "Message for NOT_SETTLED_AGAINST_NOSTRO");
			            CbsServiceProcessException exec = new CbsServiceProcessException(NOT_SETTLED_AGAINST_NOSTRO, msg);
			            throw exec;
	        		}
	        		if(prevSettleGlCode != null && !prevSettleGlCode.equals(settleGlCode)){
			            String msg = messageUtils.getMessage(NOT_SETTLED_AGAINST_SAME_NOSTRO, new String[] { jpe.getChequeType(), jpe.getChequeNo().toString() }, "Message for NOT_SETTLED_AGAINST_SAME_NOSTRO");
			            CbsServiceProcessException exec = new CbsServiceProcessException(NOT_SETTLED_AGAINST_SAME_NOSTRO, msg);
			            throw exec;
	        		}
	        		if(chartAccount != null && "N".equals(chartAccount.getGlType()) && summaryJpe.getNostroBankNo() == null){
			            String msg = messageUtils.getMessage(MISSING_NOSTRO_BANK_NO, new String[] { jpe.getChequeType(), jpe.getChequeNo().toString() }, "Message for MISSING_NOSTRO_BANK_NO");
			            CbsServiceProcessException exec = new CbsServiceProcessException(MISSING_NOSTRO_BANK_NO, msg);
			            throw exec;
	        		}
	        		prevSettleGlCode = settleGlCode;
	        		if(chartAccount != null) prevGlType = chartAccount.getGlType();
	        	} else if(COL_PROC_TYPE.equals(jpe.getProcType())){
	        		if(summaryJpe.getNostroBankNo() == null || summaryJpe.getNostroBankNo().length() == 0){
	        			if(chequeType.getGlCode() != null){
		        			chartAccount = dataService.find(ChartAccountJpe.class, chequeType.getGlCode());
	        			}
	        			if(chartAccount != null) glType = chartAccount.getGlType();
	        		} else {
	        			glType = "N";
	        		}
	        		settleGlCode = chequeType.getGlCode();
	        		if(prevGlType != null && !prevGlType.equals(glType)){
			            String msg = messageUtils.getMessage(NOT_SETTLED_AGAINST_NOSTRO, new String[] { jpe.getChequeType(), jpe.getChequeNo().toString() }, "Message for NOT_SETTLED_AGAINST_NOSTRO");
			            CbsServiceProcessException exec = new CbsServiceProcessException(NOT_SETTLED_AGAINST_NOSTRO, msg);
			            throw exec;
	        		}
	        		if(prevSettleGlCode != null && !prevSettleGlCode.equals(settleGlCode)){
			            String msg = messageUtils.getMessage(NOT_SETTLED_AGAINST_SAME_NOSTRO, new String[] { jpe.getChequeType(), jpe.getChequeNo().toString() }, "Message for NOT_SETTLED_AGAINST_SAME_NOSTRO");
			            CbsServiceProcessException exec = new CbsServiceProcessException(NOT_SETTLED_AGAINST_SAME_NOSTRO, msg);
			            throw exec;
	        		}
	        		if("N".equals(glType) && summaryJpe.getNostroBankNo() == null){
			            String msg = messageUtils.getMessage(MISSING_NOSTRO_BANK_NO, new String[] { jpe.getChequeType(), jpe.getChequeNo().toString() }, "Message for MISSING_NOSTRO_BANK_NO");
			            CbsServiceProcessException exec = new CbsServiceProcessException(MISSING_NOSTRO_BANK_NO, msg);
			            throw exec;
	        		}
	        		prevSettleGlCode = settleGlCode;
	        		prevGlType = glType;
	        	} else if(TCH_PROC_TYPE.equals(jpe.getProcType())){
	        		if(summaryJpe.getNostroBankNo() == null || summaryJpe.getNostroBankNo().length() == 0){
	        			if(chequeType.getSettleGlCode() != null){
		        			chartAccount = dataService.find(ChartAccountJpe.class, chequeType.getSettleGlCode());
	        			}
	        			if(chartAccount != null) glType = chartAccount.getGlType();
	        		} else {
	        			glType = "N";
	        		}
	        		settleGlCode = chequeType.getSettleGlCode();
	        		if(prevGlType != null && !prevGlType.equals(glType)){
			            String msg = messageUtils.getMessage(NOT_SETTLED_AGAINST_NOSTRO, new String[] { jpe.getChequeType(), jpe.getChequeNo().toString() }, "Message for NOT_SETTLED_AGAINST_NOSTRO");
			            CbsServiceProcessException exec = new CbsServiceProcessException(NOT_SETTLED_AGAINST_NOSTRO, msg);
			            throw exec;
	        		}
	        		if(prevSettleGlCode != null && !prevSettleGlCode.equals(settleGlCode)){
			            String msg = messageUtils.getMessage(NOT_SETTLED_AGAINST_SAME_NOSTRO, new String[] { jpe.getChequeType(), jpe.getChequeNo().toString() }, "Message for NOT_SETTLED_AGAINST_SAME_NOSTRO");
			            CbsServiceProcessException exec = new CbsServiceProcessException(NOT_SETTLED_AGAINST_SAME_NOSTRO, msg);
			            throw exec;
	        		}
	        		if("N".equals(glType) && summaryJpe.getNostroBankNo() == null){
			            String msg = messageUtils.getMessage(MISSING_NOSTRO_BANK_NO, new String[] { jpe.getChequeType(), jpe.getChequeNo().toString() }, "Message for MISSING_NOSTRO_BANK_NO");
			            CbsServiceProcessException exec = new CbsServiceProcessException(MISSING_NOSTRO_BANK_NO, msg);
			            throw exec;
	        		}
	        		prevSettleGlCode = settleGlCode;
	        		prevGlType = glType;
	        	}
	        }
		}
	}

	@Override
	public List<CiVerificationSummaryQry> getTotal(FindCriteria findCriteria, CbsHeader cbsHeader) {
		List<CiVerificationQry> resultSet = null;
		
		FindCriteriaJpe fc =jaxbSdoHelper.unwrap(findCriteria, FindCriteriaJpe.class);
		long sum = dataService.getRowCount(CiVerificationQryJpe.class, fc);
		
		if (sum <= 0){
			CiVerificationSummaryQryJpe summary = new CiVerificationSummaryQryJpe();
			summary.setTotalAmt(new Double(0));
			summary.setTotalRecordNo(new Integer(0));
			List<CiVerificationSummaryQry> list = new ArrayList<CiVerificationSummaryQry>();
			list.add(jaxbSdoHelper.wrap(summary, CiVerificationSummaryQry.class));
	        return list;
		}
		
		if (findCriteria == null){
			resultSet = super.query(0, new Integer(String.valueOf(sum)), null, null, new HashMap());
		} else {
			findCriteria.setFetchSize(new Integer(String.valueOf(sum)));
			resultSet = super.find(findCriteria, cbsHeader);
		}
				
		Double total = new Double(0);
		for (CiVerificationQry item: resultSet){
			total = total + item.getAmount(); 
		}
		
		CiVerificationSummaryQryJpe result = new CiVerificationSummaryQryJpe();
		result.setTotalAmt(total);
		result.setTotalRecordNo(new Integer(String.valueOf(sum)));
		List<CiVerificationSummaryQry> list = new ArrayList<CiVerificationSummaryQry>();
		list.add(jaxbSdoHelper.wrap(result, CiVerificationSummaryQry.class));
        return list;
	}
	
	private String generateSettleRefNo(){
		CiVerificationSummaryQry cvsq = jaxbSdoHelper.createSdoInstance(CiVerificationSummaryQry.class);
		referenceNumberGeneratorService.getNewRefNo(cvsq, "settleRefNo");
		return cvsq.getSettleRefNo();
	}

}
