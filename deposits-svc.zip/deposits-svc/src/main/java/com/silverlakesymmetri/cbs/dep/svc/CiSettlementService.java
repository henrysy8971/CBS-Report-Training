 package com.silverlakesymmetri.cbs.dep.svc;

import java.util.List;
import java.util.Map;

import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation;
import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation.ServiceOperationType;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.svc.BusinessService;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.CiSettlementSummary;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.CiSettlementSummaryJpe;


public interface CiSettlementService extends BusinessService<CiSettlementSummary, CiSettlementSummaryJpe> {
	
	public static final String SVC_OP_NAME_CISETTLEMENT_GET 	= "CiSettlementService.get";
    public static final String SVC_OP_NAME_CISETTLEMENT_SETTLE = "CiSettlementService.settle";
    public static final String SVC_OP_NAME_CISETTLEMENT_QUERY = "CiSettlementService.query";
    public static final String SVC_OP_NAME_CISETTLEMENT_FIND = "CiSettlementService.find";
//    public static final String SVC_OP_NAME_CISETTLEMENT_GETTOTALS = "CiSettlementService.getTotals";
    
    @ServiceOperation(name = SVC_OP_NAME_CISETTLEMENT_GET, type = ServiceOperationType.GET)
    public CiSettlementSummary getByPk(String publicKey, CiSettlementSummary reference);

    @ServiceOperation(name = SVC_OP_NAME_CISETTLEMENT_SETTLE, type = ServiceOperationType.EXECUTE)
    public CiSettlementSummary settle(CiSettlementSummary dataObject);
      
    @ServiceOperation(name = SVC_OP_NAME_CISETTLEMENT_QUERY)
    public List<CiSettlementSummary> query(int offset, int resultLimit, String groupBy, String order, Map<String, Object> filters);

    @ServiceOperation(name = SVC_OP_NAME_CISETTLEMENT_FIND)
    public List<CiSettlementSummary> find(FindCriteria findCriteria, CbsHeader cbsHeader);
    
//    @ServiceOperation(name = SVC_OP_NAME_CISETTLEMENT_GETTOTALS)
//    public List<CiSettlementSummary> getTotals(FindCriteria findCriteria, CbsHeader cbsHeader);
}
