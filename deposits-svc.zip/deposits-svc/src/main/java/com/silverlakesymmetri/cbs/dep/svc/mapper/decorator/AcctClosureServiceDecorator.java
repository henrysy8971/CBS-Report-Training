package com.silverlakesymmetri.cbs.dep.svc.mapper.decorator;

import org.mapstruct.Context;
import org.mapstruct.MappingTarget;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

import com.silverlakesymmetri.cbs.commons.jpa.util.DateTimeHelper;
import com.silverlakesymmetri.cbs.commons.xmlapi.enums.CbsXmlApiOperation;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.AcctClosureJpe;
import com.silverlakesymmetri.cbs.dep.svc.mapper.AcctClosureServiceMapper;
import com.silverlakesymmetri.cbs.dep.xmlapi.DEPACCTCLOSUREAPIType;

public abstract class AcctClosureServiceDecorator extends FeeServiceDecorator implements AcctClosureServiceMapper{
	
	@Autowired
	@Qualifier("delegate")
	protected  AcctClosureServiceMapper delegate;
	
	@Autowired
    protected DateTimeHelper dateTimeHelper;
	
	@Override
	public DEPACCTCLOSUREAPIType mapToApi(AcctClosureJpe jpe, @Context CbsXmlApiOperation oper ){
		
		//why? to be able to qualify query operation into two (QUERY_BALANCE / QUERY_FACILITY )
		//consider VALIDATE_UPDATE as dummy it is not intended to perform as a validate api
		CbsXmlApiOperation passThisOper = oper;
		if (CbsXmlApiOperation.VALIDATE_UPDATE.getOperation().equals(passThisOper.getOperation())){
			passThisOper = CbsXmlApiOperation.QUERY;
		}
		
		DEPACCTCLOSUREAPIType req = (DEPACCTCLOSUREAPIType)delegate.mapToApi(jpe, passThisOper);
		
		if (CbsXmlApiOperation.UPDATE.getOperation().equals(oper.getOperation())){
			if (jpe.getAutoGenFee() != null) {
				req.setAUTOGENFEE(jpe.getAutoGenFee());
			} else {
				req.setAUTOGENFEE("N");
			}
			
			mapFeeToApi(jpe, req);
//			req.setACCTSTATUS(value);
//			Date runDate = dateTimeHelper.getRunDate();
//			req.setACCTCLOSEDATE(dateTimeHelper.convertToCbsXmlApiDate(dateTimeHelper.getSDODateTime(runDate)));
//			req.setTRANDATE(dateTimeHelper.convertToCbsXmlApiDate(dateTimeHelper.getSDODateTime(runDate)));
		}
//		else if (CbsXmlApiOperation.VALIDATE_UPDATE.getOperation().equals(oper.getOperation())){
//			req.setQUERYTYPE("QUERY_BALANCE");
//		}
		else if (CbsXmlApiOperation.QUERY.getOperation().equals(oper.getOperation())){
			req.setQUERYTYPE("QUERY_FACILITY");
		}

		return  req;
	}
	
	@Override
	public AcctClosureJpe mapToJpe(DEPACCTCLOSUREAPIType api, @MappingTarget AcctClosureJpe jpe){
		
		delegate.mapToJpe(api, jpe);
		//Other things to do
		return jpe;
	}
}


