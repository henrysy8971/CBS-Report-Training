package com.silverlakesymmetri.cbs.dep.svc.mapper.mapping;

import com.silverlakesymmetri.cbs.commons.jpa.util.DateTimeHelper;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.AcctReactivationJpe;
import com.silverlakesymmetri.cbs.dep.xmlapi.DEPACCTACTIVATEAPIType;
import org.mapstruct.InheritInverseConfiguration;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingTarget;
import org.mapstruct.Mappings;

/**
 *
 * @author luis.talag
 */
@Mapper
public interface AcctReactivationToDEPACCTACTIVATEAPITypeMapper {
    
    @Mappings({
        @Mapping(source="acctNo", target="ACCTNO"),
        @Mapping(source="internalKey", target="INTERNALKEY"),
        @Mapping(source="acctStatus", target="PREVACCTSTATUS"),
        @Mapping(source="newStatusInd", target="NEWSTATUSINDICATOR"),
    })
    public DEPACCTACTIVATEAPIType mapToApi(AcctReactivationJpe jpe);
    
    @InheritInverseConfiguration(name = "mapToApi")
    public AcctReactivationJpe mapToJpe(DEPACCTACTIVATEAPIType api, @MappingTarget AcctReactivationJpe jpe);

}
