package com.silverlakesymmetri.cbs.dep.svc;

import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation;
import com.silverlakesymmetri.cbs.commons.svc.BusinessService;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.AcctInterestProjection;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.AcctInterestProjectionJpe;

import java.util.List;
import java.util.Map;


public interface AcctInterestProjectionService extends BusinessService<AcctInterestProjection, AcctInterestProjectionJpe> {

    public static final String SVC_OP_NAME_ACCTINTERESTPROJECTIONSERVICE_GETPROJECTION = "AcctInterestProjectionService.getProjection";
    public static final String SVC_OP_NAME_ACCTINTERESTPROJECTIONSERVICE_QUERY = "AcctInterestProjectionService.query";
    public static final String SVC_OP_NAME_ACCTINTERESTPROJECTIONSERVICE_GETBYPK = "AcctInterestProjectionService.getByPk";

    @ServiceOperation(name = SVC_OP_NAME_ACCTINTERESTPROJECTIONSERVICE_GETPROJECTION, type = ServiceOperation.ServiceOperationType.EXECUTE)
    public AcctInterestProjection getProjection(AcctInterestProjection dataObject);

    @ServiceOperation(name = SVC_OP_NAME_ACCTINTERESTPROJECTIONSERVICE_QUERY)
    public List<AcctInterestProjection> query(int offset, int resultLimit, String groupBy, String order, Map<String, Object> filters);

    @ServiceOperation(name = SVC_OP_NAME_ACCTINTERESTPROJECTIONSERVICE_GETBYPK, type = ServiceOperation.ServiceOperationType.GET)
    public AcctInterestProjection getByPk(String publicKey, AcctInterestProjection reference);

}
