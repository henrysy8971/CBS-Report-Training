package com.silverlakesymmetri.cbs.dep.svc;

import java.util.List;
import java.util.Map;

import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.bdo.sdo.User;
import com.silverlakesymmetri.cbs.commons.jpa.mapping.sdo.UserJpe;
import com.silverlakesymmetri.cbs.commons.svc.BusinessService;

public interface ChequeUserCodeToFromService extends BusinessService<User, UserJpe> {
	
	public static final String SVC_OP_NAME_CHEQUEUSERCODETOFROMSERVICE_QUERY = "ChequeUserCodeToFromService.query";
	public static final String SVC_OP_NAME_CHEQUEUSERCODETOFROMSERVICE_FIND = "ChequeUserCodeToFromService.find";
	
	@ServiceOperation(name = SVC_OP_NAME_CHEQUEUSERCODETOFROMSERVICE_QUERY)
	public List<User> query(int offset, int resultLimit, String groupBy, String order, Map<String, Object> filters);
	
	@ServiceOperation(name = SVC_OP_NAME_CHEQUEUSERCODETOFROMSERVICE_FIND)
	public List<User> find(FindCriteria findCriteria, CbsHeader cbsHeader);
}
