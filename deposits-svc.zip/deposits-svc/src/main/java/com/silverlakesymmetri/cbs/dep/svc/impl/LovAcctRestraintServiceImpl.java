package com.silverlakesymmetri.cbs.dep.svc.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.mysema.query.types.EntityPath;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.svc.AbstractBusinessService;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.RestraintType;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.RestraintTypeJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.util.DepJpeConstants;
import com.silverlakesymmetri.cbs.dep.svc.LovAcctRestraintService;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.QRestraintTypeJpe;

@Transactional
@Service
public class LovAcctRestraintServiceImpl extends AbstractBusinessService<RestraintType, RestraintTypeJpe, String> implements LovAcctRestraintService {

	@Override
	protected String getIdFromDataObjectInstance(RestraintType dataObject) {
		return dataObject.getRestraintType();
	}

	@Override
	protected EntityPath<RestraintTypeJpe> getEntityPath() {
		return QRestraintTypeJpe.restraintTypeJpe;
	}
	
	@Override
	public List<RestraintType> find(FindCriteria findCriteria, CbsHeader cbsHeader) {
		return super.find(findCriteria, cbsHeader);
	}

	
	@Override
	public List<RestraintType> query(int offset, int resultLimit, String groupBy, String order,
			Map<String, Object> filters) {
		
		List<RestraintType> list = new ArrayList<>();
		list = (List<RestraintType>) this.LovForAcctRestraint(offset, resultLimit, filters);
		
		return list;
	}
	
	private List<RestraintType> LovForAcctRestraint(int offset, int resultLimit, Map<String, Object> filters){
		List<RestraintType> list = new ArrayList<>();
		String restraintType = (String) filters.get("restraintType");
		String restraintClass = (String) filters.get("restraintClass");
		String restraintDesc = (String) filters.get("restraintDesc");
		Map<String, Object> params = new HashMap<>();
		String nativeQuery = DepJpeConstants.ACCT_RESTRAINT_LOV_FILTER_QUERY;

		if(restraintType != null) {
			nativeQuery = nativeQuery + " AND a.restraint_type LIKE ?restraintType";
			params.put("restraintType", "%" + restraintType + "%");
		}
		
		if(restraintClass != null) {
			nativeQuery = nativeQuery + " AND a.restraint_class LIKE ?restraintClass";
			params.put("restraintClass", "%" + restraintClass + "%");
		}
		
		if(restraintDesc != null) {
			nativeQuery = nativeQuery + " AND a.restraint_desc LIKE ?restraintDesc";
			params.put("restraintDesc", "%" + restraintDesc + "%");
		}
		
		nativeQuery = nativeQuery + " ORDER BY a.restraint_type ASC";

		List<RestraintTypeJpe> jpeList = dataService.findWithNativeQuery(nativeQuery, params, offset, resultLimit, RestraintTypeJpe.class);
		
		if(jpeList != null && !jpeList.isEmpty())
		{
			for(RestraintTypeJpe jpe : jpeList) {
				list.add(jaxbSdoHelper.wrap(jpe, RestraintType.class));
			}
			
		}
		return list;
		
	}
}
