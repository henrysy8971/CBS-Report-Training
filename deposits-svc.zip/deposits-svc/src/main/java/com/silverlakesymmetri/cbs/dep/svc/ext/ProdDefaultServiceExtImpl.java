package com.silverlakesymmetri.cbs.dep.svc.ext;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.silverlakesymmetri.cbs.commons.ext.ServiceExtensionPoint;
import com.silverlakesymmetri.cbs.commons.jpa.service.CbsGenericDataService;
import com.silverlakesymmetri.cbs.csd.jpa.validation.business.ProdDefaultServiceExt;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.ProdDefaultJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.util.DepJpeConstants;

@Service
public class ProdDefaultServiceExtImpl implements ProdDefaultServiceExt,
	ServiceExtensionPoint {
	
	@Autowired(required = true)
    @Qualifier("cbsGenericDataService")
    protected CbsGenericDataService dataService;

	@Override
	public boolean getCrCapOption(String intType) {
		Map <String, Object> param = new HashMap<>();
		param.put("intType", intType);
		List<ProdDefaultJpe> jpe = dataService.findWithNamedQuery(DepJpeConstants.PROD_DEFAULT_JPE_FIND_BY_CR_INT_TYPE, param, ProdDefaultJpe.class);
		
		if(!jpe.isEmpty()) {
			return true;
		}else {
			return false;
		}
	}

	@Override
	public String[] getExtendedBdoNames() {
		return new String[] { INT_RATE_BDO_NAME };
	}

	@Override
	public String[] getExtendedServiceNames() {
		return new String[] { SERVICE_NAME };
	}

	@Override
	public void beforeService(Object[] serviceParameters) {
		
	}

	@Override
	public Object afterService(Object result, Object[] serviceParameters) {
		return null;
	}

	@Override
	public void beforeQuery(Object[] serviceParameters) {
		
	}

	@Override
	public Object afterQuery(Object result, Object[] serviceParameters) {
		return null;
	}

	@Override
	public Object afterValidationBeforeMainService(Object result) {
		return null;
	}

}