package com.silverlakesymmetri.cbs.dep.svc.impl;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.mysema.query.types.EntityPath;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.svc.AbstractBusinessService;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.CiDenomination;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.CiDenominationJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.QCiDenominationJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.id.CiDenominationPk;
import com.silverlakesymmetri.cbs.dep.svc.CiDenominationService;


@Service
@Transactional
public class CiDenominationServiceImpl extends AbstractBusinessService<CiDenomination, CiDenominationJpe, CiDenominationPk> implements CiDenominationService {

    @Override
    protected CiDenominationPk getIdFromDataObjectInstance(CiDenomination dataObject) {
        return new CiDenominationPk(dataObject.getDenomGroup(), dataObject.getDenomination());
    }

    @Override
    protected EntityPath<CiDenominationJpe> getEntityPath() {
        return QCiDenominationJpe.ciDenominationJpe;
    }
    
    @Override
    public CiDenomination get(CiDenomination objectInstanceIdentifier) {
        return super.get(objectInstanceIdentifier);
    }
    
    @Override
    public CiDenomination create(CiDenomination objectInstanceIdentifier) {
        return null;
    }
    
    @Override
    public CiDenomination update(CiDenomination objectInstanceIdentifier) {
        return null;
    }
    
    @Override
    public boolean delete(CiDenomination objectInstanceIdentifier) {
        return false;
    }

    @Override
    public List<CiDenomination> query(int offset, int resultLimit, String groupBy, String order, Map<String, Object> filters) {
        return super.query(offset, resultLimit, groupBy, order, filters);
    }

    @Override
    public List<CiDenomination> find(FindCriteria findCriteria, CbsHeader cbsHeader) {
        return super.find(findCriteria, cbsHeader);
    }

    @Override
    public CiDenomination getByPk(String publicKey, CiDenomination reference) {
        return super.getByPk(publicKey, reference);
    }
}
