package com.silverlakesymmetri.cbs.dep.svc;

import java.util.List;
import java.util.Map;

import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation;
import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation.ServiceOperationType;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.svc.BusinessService;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.AcctSignatoryInfo;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.AcctSignatoryInfoJpe;
import com.silverlakesymmetri.cbs.mcl.bdo.sdo.Client;


public interface AcctSignatoryInfoService extends BusinessService<AcctSignatoryInfo, AcctSignatoryInfoJpe> {

    public static final String SVC_OP_NAME_ACCTSIGNATORYINFOGROUP_GET = "AcctSignatoryInfoService.get";
    public static final String SVC_OP_NAME_ACCTSIGNATORYINFOGROUP_CREATE = "AcctSignatoryInfoService.create";
    public static final String SVC_OP_NAME_ACCTSIGNATORYINFOGROUP_UPDATE = "AcctSignatoryInfoService.update";
    public static final String SVC_OP_NAME_ACCTSIGNATORYINFOGROUP_DELETE = "AcctSignatoryInfoService.delete";
    public static final String SVC_OP_NAME_ACCTSIGNATORYINFOGROUP_QUERY = "AcctSignatoryInfoService.query";
    public static final String SVC_OP_NAME_ACCTSIGNATORYINFOGROUP_FIND = "AcctSignatoryInfoService.find";
    public static final String SVC_OP_NAME_ACCTSIGNATORYINFOGROUP_BULKDELETE = "AcctSignatoryInfoService.bulkdelete";
    public static final String SVC_OP_NAME_ACCTSIGNATORYINFOGROUP_CLIENTQRY = "AcctSignatoryInfoService.getClientsForAcct";
    public static final String SVC_OP_NAME_ACCTSIGNATORYINFOGROUP_COUNT = "AcctSignatoryInfoService.count";

    @ServiceOperation(name = SVC_OP_NAME_ACCTSIGNATORYINFOGROUP_GET, type = ServiceOperationType.GET)
    public AcctSignatoryInfo getByPk(String publicKey, AcctSignatoryInfo reference);
    
    @ServiceOperation(name = SVC_OP_NAME_ACCTSIGNATORYINFOGROUP_CREATE)
    public AcctSignatoryInfo create(AcctSignatoryInfo objectInstanceIdentifier);
    
    @ServiceOperation(name = SVC_OP_NAME_ACCTSIGNATORYINFOGROUP_UPDATE)
    public AcctSignatoryInfo update(AcctSignatoryInfo objectInstanceIdentifier);
    
    @ServiceOperation(name = SVC_OP_NAME_ACCTSIGNATORYINFOGROUP_DELETE)
    public boolean delete(AcctSignatoryInfo objectInstanceIdentifier);
    
    @ServiceOperation(name = SVC_OP_NAME_ACCTSIGNATORYINFOGROUP_QUERY)
    public List<AcctSignatoryInfo> query(int offset, int resultLimit, String groupBy, String order, Map<String, Object> filters);

    @ServiceOperation(name = SVC_OP_NAME_ACCTSIGNATORYINFOGROUP_FIND)
    public List<AcctSignatoryInfo> find(FindCriteria findCriteria, CbsHeader cbsHeader);

    @ServiceOperation(name = SVC_OP_NAME_ACCTSIGNATORYINFOGROUP_BULKDELETE, type = ServiceOperationType.BULKDELETE, passParamAsMap = true)
    public int bulkDelete(Map<String, Object> filters);

    @ServiceOperation(name = SVC_OP_NAME_ACCTSIGNATORYINFOGROUP_CLIENTQRY, type = ServiceOperationType.READ, passParamAsMap = true)
    public List<Client> getClientsForAcct(Map<String, Object> filters);

    @ServiceOperation(name = SVC_OP_NAME_ACCTSIGNATORYINFOGROUP_COUNT, type = ServiceOperation.ServiceOperationType.GET)
    public Long count(FindCriteria findCriteria, CbsHeader cbsHeader);

}
