package com.silverlakesymmetri.cbs.dep.svc.impl;

import com.mysema.query.types.EntityPath;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.helper.jpa.LinkTable;
import com.silverlakesymmetri.cbs.commons.helper.jpa.QueryCondition;
import com.silverlakesymmetri.cbs.commons.helper.jpa.QueryType;
import com.silverlakesymmetri.cbs.commons.jpa.entity.FindCriteriaJpe;
import com.silverlakesymmetri.cbs.commons.svc.AbstractBusinessService;
import com.silverlakesymmetri.cbs.commons.svc.BusinessObjectValidationCapable;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.CiDetailQry;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.CiDetailQryJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.CiTypeJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.QCiDetailQryJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.id.CiDetailQryPk;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.util.DepJpeConstants;
import com.silverlakesymmetri.cbs.dep.svc.CiDetailQryService;
import org.springframework.stereotype.Service;

import java.util.*;

@Service
public class CiDetailQryServiceImpl extends AbstractBusinessService<CiDetailQry, CiDetailQryJpe, CiDetailQryPk>
        implements CiDetailQryService, BusinessObjectValidationCapable<CiDetailQry> {

    private static LinkedHashMap<String, LinkTable> constructorMap;
    private static QueryCondition queryCondition;
    
    static {
        constructorMap = new LinkedHashMap<String, LinkTable>();
        constructorMap.put("chequeNo", new LinkTable(CiDetailQryJpe.class));
        constructorMap.put("procType", new LinkTable(CiTypeJpe.class));
        constructorMap.put("chequeType", new LinkTable(CiDetailQryJpe.class));
        constructorMap.put("chequeStatus", new LinkTable(CiDetailQryJpe.class));
        constructorMap.put("branch", new LinkTable(CiDetailQryJpe.class));
        constructorMap.put("denomination", new LinkTable(CiDetailQryJpe.class));
        constructorMap.put("ccy", new LinkTable(CiDetailQryJpe.class));
        constructorMap.put("amount", new LinkTable(CiDetailQryJpe.class));
        constructorMap.put("prefix", new LinkTable(CiDetailQryJpe.class));
        constructorMap.put("grpCiSeqNoSell", new LinkTable(CiDetailQryJpe.class));
        constructorMap.put("grpCiSeqNoBuy", new LinkTable(CiDetailQryJpe.class));
        constructorMap.put("bankCode", new LinkTable(CiDetailQryJpe.class));
        constructorMap.put("bankBranch", new LinkTable(CiDetailQryJpe.class));
        constructorMap.put("officerId", new LinkTable(CiDetailQryJpe.class));
        constructorMap.put("settleRefNo", new LinkTable(CiDetailQryJpe.class));
        constructorMap.put("batchNo", new LinkTable(CiDetailQryJpe.class));
        constructorMap.put("ftMsgRefNo", new LinkTable(CiDetailQryJpe.class));
        constructorMap.put("seqNo", new LinkTable(CiDetailQryJpe.class));

        queryCondition = new QueryCondition();
        queryCondition.where("chequeType", QueryType.EQUALS, new LinkTable(CiTypeJpe.class, "chequeType"));
    }

    @Override
    protected CiDetailQryPk getIdFromDataObjectInstance(CiDetailQry dataObject) {
        return new CiDetailQryPk(dataObject.getSeqNo());
    }

    @Override
    protected EntityPath<CiDetailQryJpe> getEntityPath() {
        return QCiDetailQryJpe.ciDetailQryJpe;
    }

    @Override
    public CiDetailQry getByPk(String publicKey, CiDetailQry reference) {
        return super.getByPk(publicKey, reference);
    }

    @Override
    public List<CiDetailQry> query(int offset, int resultLimit, String groupBy, String order, Map<String, Object> filters) {
        return super.query(offset, resultLimit, groupBy, order, filters);
    }

    @Override
    public List<CiDetailQry> find(FindCriteria findCriteria, CbsHeader cbsHeader) {
    	return super.find(findCriteria, cbsHeader, constructorMap, queryCondition);
    }
    
    @Override
    public Long count(FindCriteria findCriteria, CbsHeader cbsHeader) {
        FindCriteriaJpe jpe = jaxbSdoHelper.unwrap(findCriteria, FindCriteriaJpe.class);
        return dataService.getRowCount(CiDetailQryJpe.class, jpe, constructorMap, queryCondition);
    }

    @Override
    public List<CiDetailQry> getAttachedCiDetailOfTranHist(Map<String, Object> params){
        if (params == null || params.isEmpty() || !params.containsKey("tranHistSeqNo")){
            return null;
        }
        Map filters = new HashMap();
        filters.put("tranHistSeqNo", Long.valueOf((String)params.get("tranHistSeqNo")));
        List<Long> grpCiSeqNoList = dataService.findWithNamedQuery(DepJpeConstants.CITRANBUYQRY_JPE_FIND_BY_TRANHIST_SEQNO, filters, Long.class);

        if (grpCiSeqNoList == null || grpCiSeqNoList.isEmpty()){
            return null;
        }
        filters = new HashMap<>();
        filters.put("grpCiSeqNoList", grpCiSeqNoList);
        int offset = params.containsKey("offset") ?  Integer.parseInt((String)params.get("offset")): 0;
        int resultLimit =  params.containsKey("limit") ?  Integer.parseInt((String)params.get("limit")): -1;
        List<CiDetailQryJpe> list = dataService.findWithNamedQuery(DepJpeConstants.CIDETAILQRY_JPE_FIND_BY_GRPCISEQNOLIST, filters, offset, resultLimit, CiDetailQryJpe.class);
        if (list == null || list.isEmpty()){
            return null;
        }
        List <CiDetailQry> retlist = new ArrayList<>();
        for (CiDetailQryJpe data: list){
            retlist.add(jaxbSdoHelper.wrap(data, CiDetailQry.class));
        }
        return retlist;
    }
}
