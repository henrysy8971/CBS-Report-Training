package com.silverlakesymmetri.cbs.dep.svc;

import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation;
import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation.ServiceOperationType;
import com.silverlakesymmetri.cbs.commons.svc.BusinessService;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.AcctClosure;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.AcctClosureJpe;

public interface AcctClosureService extends BusinessService<AcctClosure, AcctClosureJpe> {
	public static final String SVC_OP_NAME_ACCTCLOSURESERVICE_GET = "AcctClosureService.get";
	public static final String SVC_OP_NAME_ACCTCLOSURESERVICE_CLOSEACCOUNT = "AcctClosureService.closeAccount";
	
	@ServiceOperation(name = SVC_OP_NAME_ACCTCLOSURESERVICE_GET, type = ServiceOperationType.GET)
    public AcctClosure get(AcctClosure acctClosure);
	
	@ServiceOperation(name = SVC_OP_NAME_ACCTCLOSURESERVICE_CLOSEACCOUNT, type = ServiceOperationType.CREATE)
    public AcctClosure closeAccount(AcctClosure acctClosure);
	
}
