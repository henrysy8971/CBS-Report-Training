package com.silverlakesymmetri.cbs.dep.svc;

import java.util.List;
import java.util.Map;

import com.silverlakesymmetri.cbs.dep.bdo.sdo.BillTranHist;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.DepositTransaction;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.FeeManualCharges;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.FxBuySell;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.TdDepositTransaction;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.TdTransferTransaction;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.TdaHist;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.TranHist;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.TransferTransaction;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.AcctJpe;
import com.silverlakesymmetri.cbs.lmt.jpa.mapping.sdo.FacilityLinkageJpe;
import com.silverlakesymmetri.cbs.lmt.util.ExpEmkObjectHolder;

public interface DepositsExpEmkService {
	
    /* limits bpm workflow related */
    /**
     * method used by CbsLimitModel
     * method used to populate the child list dataExtensionList, with data needed in determining the approver
     *  
     * @param externalExpEmk ExternalExpEmk
     * @return ExternalExpEmk
     */
	
	public ExpEmkObjectHolder generateBusinessRoleDataExtList(ExpEmkObjectHolder expEmkObject, Map <String, Object> oldValues);
	
	/**
	 * method used by CbsLimitModel
	 * method used to determine the approving officer if needed
	 *  
	 * @param externalExpEmk ExternalExpEmk
	 * 
	 * @return Business Role
	 */
	public Map<String, Object> whoIsMyApprover(ExpEmkObjectHolder expEmkObject);
	
	/**
     * Method that persist the ExposureEarmarkProcess in the DataExtensionList by calling ExposureEarmarkProcessService createExpEmk
     * @param extExpEmk ExternalExpEmk
     */
    public void processDataExtensionList(ExpEmkObjectHolder expEmkObject);
    
    /**
     * Method to get valid linkages for the given product code, event and amount type 
     * @param productCode
     * @param eventName
     * @param amtType
     * @return List<FacilityLinkageJpe> 
     */
    public List<FacilityLinkageJpe> getFacilityLinkageSetup(String productCode, String eventName, String amtType);
    
    /**
     * Method to get default rate type from registry
     * @return String Deposit Default Rate Type
     */
    public String getDefaultRateType() ;
    
    /**
     * Method to get registry entry
     * @param registryName
     * @param entryName
     * @param valueType
     * @return value from CUT_REGISTRY
     */
    public <T> T getRegistryEntry(String registryName, String entryName, Class<T> valueType);
    
    /**
     * Method to process Limits for DepositTransaction
     * @param dataObject
     * @param acctJpe
     * @param eventType
     * @param amtType
     */
    @Deprecated
	public ExpEmkObjectHolder processLimits(DepositTransaction dataObject, AcctJpe acctJpe, String eventType, String amtType);

    public ExpEmkObjectHolder getLimitsDetails(DepositTransaction dataObject, AcctJpe acctJpe, String eventType, String amtType);
    /**
     * Method to process Limits for TransferTransaction
     * @param dataObject
     * @param eventType
     * @param amtType
     */
    @Deprecated
	public ExpEmkObjectHolder processLimits(TransferTransaction dataObject, String eventType, String amtType);

    public ExpEmkObjectHolder getLimitsDetails(TransferTransaction dataObject, String eventType, String amtType);
    /**
     * Method to process Limits for TdDepositTransaction
     * @param dataObject
     * @param acctJpe
     * @param eventType
     * @param amtType
     */
    @Deprecated
	public ExpEmkObjectHolder processLimits(TdDepositTransaction dataObject, AcctJpe acctJpe, String eventType, String amtType);

    public ExpEmkObjectHolder getLimitsDetails(TdDepositTransaction dataObject, AcctJpe acctJpe, String eventType, String amtType);
    /**
     * Method to process Limits for TdTransferTransaction
     * @param dataObject
     * @param eventType
     * @param amtType
     */
    @Deprecated
	public ExpEmkObjectHolder processLimits(TdTransferTransaction dataObject, String eventType, String amtType);

    public ExpEmkObjectHolder getLimitsDetails(TdTransferTransaction dataObject, String eventType, String amtType);

    /**
     * Method to process Limits for TdaHist
     * @param dataObject
     * @param eventType
     * @param amtType
     */
    @Deprecated
	public ExpEmkObjectHolder processLimits(TdaHist dataObject, String eventType, String amtType);

    public ExpEmkObjectHolder getLimitsDetails(TdaHist dataObject, String eventType, String amtType);

	/**
     * Method to process Limits for TransferTransaction
     * @param dataObject
     * @param eventType
     * @param amtType
     */
    @Deprecated
	public ExpEmkObjectHolder processLimits(TranHist dataObject, String eventType, String amtType);

    public ExpEmkObjectHolder getLimitsDetails(TranHist dataObject, String eventType, String amtType);

    /**
     * Method to process Limits for FxBuySell
     * @param dataObject
     * @param acctJpe
     * @param eventType
     * @param amtType
     */
    @Deprecated
	public ExpEmkObjectHolder processLimits(FxBuySell dataObject, AcctJpe acctJpe, String eventType, String amtType);

    public ExpEmkObjectHolder getLimitsDetails(FxBuySell dataObject, AcctJpe acctJpe, String eventType, String amtType);
    /**
     * Method to process Limits for BillTranHist
     * @param dataObject
     * @param acctJpe
     * @param eventType
     * @param amtType
     */
    @Deprecated
	public ExpEmkObjectHolder processLimits(BillTranHist dataObject, AcctJpe acctJpe, String eventType, String amtType);

    public ExpEmkObjectHolder getLimitsDetails(BillTranHist dataObject, AcctJpe acctJpe, String eventType, String amtType);

	/**
     * Method to process Limits for FeeManualCharges
     * @param dataObject
     * @param acctJpe
     * @param eventType
     * @param amtType
     */
    @Deprecated
	public	ExpEmkObjectHolder processLimits(FeeManualCharges dataObject, AcctJpe acctJpe, String eventType, String amtType);

    public	ExpEmkObjectHolder getLimitsDetails(FeeManualCharges dataObject, AcctJpe acctJpe, String eventType, String amtType);

}
