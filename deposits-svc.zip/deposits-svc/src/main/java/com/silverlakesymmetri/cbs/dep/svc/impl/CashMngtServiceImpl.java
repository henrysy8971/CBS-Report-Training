package com.silverlakesymmetri.cbs.dep.svc.impl;

import com.mysema.query.types.EntityPath;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.svc.AbstractXmlApiBusinessService;
import com.silverlakesymmetri.cbs.commons.xmlapi.enums.CbsXmlApiOperation;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.CashMngt;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.CashMngtJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.QCashMngtJpe;
import com.silverlakesymmetri.cbs.dep.svc.CashMngtService;
import com.silverlakesymmetri.cbs.dep.svc.mapper.CashMngtServiceMapper;
import com.silverlakesymmetri.cbs.dep.xmlapi.DEPCASHMNGTAPIType;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;

@Service
public class CashMngtServiceImpl extends AbstractXmlApiBusinessService<CashMngt, CashMngtJpe, Long, DEPCASHMNGTAPIType, DEPCASHMNGTAPIType> implements CashMngtService {

	private static final String TSO_TRAN_MODE = "TSO";
	private static final String DEP_TRAN_HIST_SEQ = "DEP_TRAN_HIST_S";

	@Autowired
	private CashMngtServiceMapper mapper;
		
	@Override
	protected EntityPath<CashMngtJpe> getEntityPath() {
		return QCashMngtJpe.cashMngtJpe;
	}

	@Override
	protected Long getIdFromDataObjectInstance(CashMngt dataObject) {
		return dataObject.getSeqNo();
	}

	@Override
	public CashMngt getByPk(String publicKey, CashMngt reference) {
		return super.getByPk(publicKey, reference);
	}

	@Override
	public List<CashMngt> find(FindCriteria findCriteria, CbsHeader cbsHeader) {
		return super.find(findCriteria, cbsHeader);
	}

	@Override
	public CashMngt create(CashMngt dataObject) {
		return super.create(dataObject);
	}

	@Override
	public List<CashMngt> query(int offset, int resultLimit, String groupBy, String order, Map<String, Object> filters){
		return super.query(offset, resultLimit, groupBy, order, filters);
	}

	@Override
	protected DEPCASHMNGTAPIType transformBdoToXmlApiRqCreate(CashMngt dataObject) {
		CashMngtJpe jpe = jaxbSdoHelper.unwrap(dataObject);
		DEPCASHMNGTAPIType apiType =  mapper.mapToApi(jpe, CbsXmlApiOperation.INSERT);
		super.setTechColsFromDataObject(dataObject, apiType);
		return apiType;
	}

	@Override
	protected DEPCASHMNGTAPIType transformBdoToXmlApiRqUpdate(CashMngt dataObject) {
		return null;
	}

	@Override
	protected DEPCASHMNGTAPIType transformBdoToXmlApiRqDelete(CashMngt dataObject) {
		return null;
	}

	@Override
	protected CashMngt processXmlApiRs(CashMngt dataObject, DEPCASHMNGTAPIType xmlApiRs) {
		CashMngtJpe jpe = jaxbSdoHelper.unwrap(dataObject);
		mapper.mapToJpe(xmlApiRs, jpe);
		dataObject = jaxbSdoHelper.wrap(jpe);
		return dataObject;
	}

	@Override
	protected Class<DEPCASHMNGTAPIType> getXmlApiResponseClass() {
		return DEPCASHMNGTAPIType.class;
	}

	@Override
	protected List<CashMngt> processXmlApiListRs(CashMngt dataObject,
			DEPCASHMNGTAPIType xmlApiRs) {
		return null;
	}

	@Override
	protected CashMngt preCreateValidation(CashMngt dataObject) {
		return super.preCreateValidation(setDefaults(dataObject));
	}

	private CashMngt setDefaults(CashMngt cashMngt) {
		cashMngt.setSeqNo(dataService.nextSequenceValue(DEP_TRAN_HIST_SEQ));
		if (cashMngt.getTranMode().equals(TSO_TRAN_MODE)) {
			cashMngt.setTransferBranch(null);
			cashMngt.setBaseEquivAmt(null);
		}
		return cashMngt;
	}
}
