package com.silverlakesymmetri.cbs.dep.svc.mapper;

import org.mapstruct.Context;
import org.mapstruct.DecoratedWith;
import org.mapstruct.InheritConfiguration;
import org.mapstruct.InheritInverseConfiguration;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingTarget;
import org.mapstruct.Mappings;

import com.silverlakesymmetri.cbs.commons.jpa.util.DateTimeHelper;
import com.silverlakesymmetri.cbs.commons.xmlapi.enums.CbsXmlApiOperation;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.InwdChequeManualCaptureJpe;
import com.silverlakesymmetri.cbs.dep.svc.mapper.decorator.InwdChequeManualCaptureServiceDecorator;
import com.silverlakesymmetri.cbs.dep.svc.mapper.mapping.InwdChequeManualCaptureToDEPINWDCHEQUEAPITypeMapper;
import com.silverlakesymmetri.cbs.dep.xmlapi.DEPINWDCHEQUEAPIType;

@Mapper(config = InwdChequeManualCaptureToDEPINWDCHEQUEAPITypeMapper.class, uses = { DateTimeHelper.class })
@DecoratedWith(InwdChequeManualCaptureServiceDecorator.class)
public interface InwdChequeManualCaptureServiceMapper {
	@Mappings({ @Mapping(expression = "java(oper != null ? oper.getOperation() : null)", target = "OPERATION") })
	@InheritConfiguration
	public DEPINWDCHEQUEAPIType mapToApi(InwdChequeManualCaptureJpe jpe, @Context CbsXmlApiOperation oper);
	@InheritInverseConfiguration(name = "mapInwdChequeManualCaptureToDEPINWDCHEQUEAPIType")
	@Mappings({
		@Mapping(target = "tranDate", source = "TRANDATE", qualifiedByName = { "DateTimeHelper", "convertCbsApiDateToString" })
	})
	public InwdChequeManualCaptureJpe mapToJpe(DEPINWDCHEQUEAPIType api, @MappingTarget InwdChequeManualCaptureJpe jpe);
}
