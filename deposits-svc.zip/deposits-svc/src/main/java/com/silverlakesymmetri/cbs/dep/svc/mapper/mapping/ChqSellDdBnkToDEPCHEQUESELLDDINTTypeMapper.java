package com.silverlakesymmetri.cbs.dep.svc.mapper.mapping;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Mappings;

import com.silverlakesymmetri.cbs.commons.jpa.util.DateTimeHelper;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.ChqSellDdBnkJpe;
import com.silverlakesymmetri.cbs.dep.xmlapi.DEPCHEQUESELLDDINTType;

@Mapper(uses = { DateTimeHelper.class })
public interface ChqSellDdBnkToDEPCHEQUESELLDDINTTypeMapper {
	
	@Mappings({
		@Mapping(source = "position", target = "POSITION"),
		@Mapping(source = "bank", target = "AGENTBANK"),
		@Mapping(source = "branch", target = "AGENTBRANCH"),
		@Mapping(source = "chequeAmount", target = "AMOUNT"),
		@Mapping(source = "prefix", target = "PREFIX"),
		@Mapping(source = "quantity", target = "QTY"),
		@Mapping(source = "startChequeNo", target = "STARTCHEQUE"),
		@Mapping(source = "endChequeNo", target = "ENDCHEQUE"),
		@Mapping(source = "amount", target = "TOTALVALUE")
	})
	public DEPCHEQUESELLDDINTType chqSellDdBankJpeToApiType(ChqSellDdBnkJpe jpe);
	
}
