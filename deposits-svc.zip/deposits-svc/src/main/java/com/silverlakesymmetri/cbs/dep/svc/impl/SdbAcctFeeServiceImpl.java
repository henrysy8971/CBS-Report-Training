package com.silverlakesymmetri.cbs.dep.svc.impl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.mysema.query.types.EntityPath;
import com.silverlakesymmetri.cbs.commons.svc.AbstractBusinessService;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.FeeInquiryHdr;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.FeeInquiryDtlsJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.FeeInquiryHdrJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.QFeeInquiryHdrJpe;
import com.silverlakesymmetri.cbs.dep.svc.DepositsFeeService;
import com.silverlakesymmetri.cbs.dep.svc.SdbAcctFeeService;
import com.silverlakesymmetri.cbs.dep.svc.mapper.DepositsFeeServiceMapper;

@Service
@Transactional
public class SdbAcctFeeServiceImpl extends AbstractBusinessService<FeeInquiryHdr, FeeInquiryHdrJpe, Long>
		implements SdbAcctFeeService {

	@Autowired
	DepositsFeeServiceMapper mapper;

	@Autowired
	DepositsFeeService feeService;

	@Override
	protected EntityPath<FeeInquiryHdrJpe> getEntityPath() {
		return QFeeInquiryHdrJpe.feeInquiryHdrJpe;
	}

	@Override
	protected Long getIdFromDataObjectInstance(FeeInquiryHdr dataObject) {
		return dataObject.getTranNo();
	}

	private final String RENTAL = "R";
	private final String KEYDEPOSIT = "K";
	private final String OTHER = "O";

	@Override
	public FeeInquiryHdr feeInquiry(FeeInquiryHdr dataObject) {

		FeeInquiryHdrJpe jpe = jaxbSdoHelper.unwrap(dataObject);
		List<FeeInquiryDtlsJpe> fees = new ArrayList<>();

		// inquire RENTAL fees
		dataObject.setInput4(RENTAL);
		FeeInquiryHdr rental = feeService.feeInquiry(dataObject);
		if (rental != null && rental.getFeeInquiryDtlsList() != null
				&& !rental.getFeeInquiryDtlsList().isEmpty()) {
			FeeInquiryHdrJpe rentalJpe = jaxbSdoHelper.unwrap(rental);
			for (FeeInquiryDtlsJpe dtl : rentalJpe.getFeeInquiryDtlsList()) {
				dtl.setCustomData(RENTAL);
			}
			fees.addAll(rentalJpe.getFeeInquiryDtlsList());
		}

		// inquire KEYDEPOSIT fees
		dataObject.setInput4(KEYDEPOSIT);
		FeeInquiryHdr keyDeposit = feeService.feeInquiry(dataObject);
		if (keyDeposit != null && keyDeposit.getFeeInquiryDtlsList() != null
				&& !keyDeposit.getFeeInquiryDtlsList().isEmpty()) {
			FeeInquiryHdrJpe keyDepositJpe = jaxbSdoHelper.unwrap(keyDeposit);
			for (FeeInquiryDtlsJpe dtl : keyDepositJpe.getFeeInquiryDtlsList()) {
				dtl.setCustomData(KEYDEPOSIT);
			}
			fees.addAll(keyDepositJpe.getFeeInquiryDtlsList());
		}

		// inquire OTHER fees
		dataObject.setInput4(OTHER);
		FeeInquiryHdr other = feeService.feeInquiry(dataObject);
		if (other != null && other.getFeeInquiryDtlsList() != null
				&& !other.getFeeInquiryDtlsList().isEmpty()) {
			FeeInquiryHdrJpe otherJpe = jaxbSdoHelper.unwrap(other);
			for (FeeInquiryDtlsJpe dtl : otherJpe.getFeeInquiryDtlsList()) {
				dtl.setCustomData(OTHER);
			}
			fees.addAll(otherJpe.getFeeInquiryDtlsList());
		}

		jpe.setFeeInquiryDtlsList(fees);
		return jaxbSdoHelper.wrap(jpe);

	}

}
