package com.silverlakesymmetri.cbs.dep.svc.impl;

import com.mysema.query.types.EntityPath;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.jpa.listener.Auditor;
import com.silverlakesymmetri.cbs.commons.svc.AbstractXmlApiBusinessService;
import com.silverlakesymmetri.cbs.commons.xmlapi.enums.CbsXmlApiOperation;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.CiPrintReprint;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.CiRdBunchReg;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.CiPrintReprint;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.CiDetailActiveJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.CiPrintReprintJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.CiPrintReprintJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.QCiPrintReprintJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.id.CiPrintReprintPk;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.util.DepJpeConstants;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.id.CiPrintReprintPk;
import com.silverlakesymmetri.cbs.dep.svc.ChequeRegistrationService;
import com.silverlakesymmetri.cbs.dep.svc.CiPrintReprintService;
import com.silverlakesymmetri.cbs.dep.svc.mapper.ChequeRegistrationServiceMapper;
import com.silverlakesymmetri.cbs.dep.svc.mapper.CiPrintReprintServiceMapper;
import com.silverlakesymmetri.cbs.dep.svc.mapper.mapping.CiPrintReprintToDEPCHQPRINTAPITypeMapper;
import com.silverlakesymmetri.cbs.dep.xmlapi.DEPCHQPRINTAPIType;
import com.silverlakesymmetri.cbs.dep.xmlapi.DEPCHQPRINTAPIType;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class CiPrintReprintServiceImpl extends AbstractXmlApiBusinessService<CiPrintReprint, CiPrintReprintJpe, 
		CiPrintReprintPk, DEPCHQPRINTAPIType, DEPCHQPRINTAPIType> implements CiPrintReprintService {
	
	private static final String INITIAL_PRINT = "02";
	
	@Autowired
	private CiPrintReprintServiceMapper mapper;
	
	@Override
	protected DEPCHQPRINTAPIType transformBdoToXmlApiRqCreate(CiPrintReprint dataObject) {
		 return null;
	}

	@Override
	protected DEPCHQPRINTAPIType transformBdoToXmlApiRqUpdate(CiPrintReprint dataObject) {
		CiPrintReprintJpe jpe = jaxbSdoHelper.unwrap(dataObject);
		DEPCHQPRINTAPIType api =  mapper.mapToApi(jpe);
		api.setOPERATION(CbsXmlApiOperation.UPDATE.getOperation());
		super.setTechColsFromDataObject(dataObject, api);
		return api;
	}

	@Override
	protected DEPCHQPRINTAPIType transformBdoToXmlApiRqDelete(CiPrintReprint dataObject) {
		return null;
	}

	@Override
	protected CiPrintReprint processXmlApiRs(CiPrintReprint dataObject, DEPCHQPRINTAPIType xmlApiRs) {
		CiPrintReprintJpe jpe = jaxbSdoHelper.unwrap(dataObject);
		jpe = mapper.mapToJpe(xmlApiRs, jpe);
		CiPrintReprint ciPrintReprint = jaxbSdoHelper.wrap(jpe);
		
		Map<String,Object> params = new HashMap<String, Object>();
		if (ciPrintReprint.getChequeRefNo() != null) {
	        params.put("seqNo", ciPrintReprint.getNewSeqNo());
	        List<CiDetailActiveJpe> ciDetailJpeList = dataService.findWithNamedQuery(DepJpeConstants.CIDETAILACTIVE_JPE_FIND_BY_SEQNO_QUERY, params, CiDetailActiveJpe.class);
	        if (jpe.getPrintReason() != INITIAL_PRINT && ciDetailJpeList.size() > 0) {
	        	ciPrintReprint.setNewChequeRefNo(ciDetailJpeList.get(0).getChequeRefNo());
	        }
		}
		
		return ciPrintReprint;
	}

	@Override
	protected List<CiPrintReprint> processXmlApiListRs(CiPrintReprint dataObject, DEPCHQPRINTAPIType xmlApiRs) {
		return null;
	}

	@Override
	protected Class<DEPCHQPRINTAPIType> getXmlApiResponseClass() {
		return DEPCHQPRINTAPIType.class;
	}

	@Override
	protected CiPrintReprintPk getIdFromDataObjectInstance(CiPrintReprint dataObject) {
		return new CiPrintReprintPk(dataObject.getSeqNo());
	}

	@Override
	protected EntityPath<CiPrintReprintJpe> getEntityPath() {
		return QCiPrintReprintJpe.ciPrintReprintJpe;
	}

	@Override
	public CiPrintReprint getByPk(String publicKey, CiPrintReprint reference) {
		//return super.getByPk(publicKey, reference);
		return null;
	}
	
	private void defaultValues(CiPrintReprint dataObject) {
		Map<String,Object> params = new HashMap<String, Object>();
		if (dataObject.getChequeRefNo() != null) {
	        params.put("chequeRefNo", dataObject.getChequeRefNo());
	        List<CiDetailActiveJpe> ciDetailJpeList = dataService.findWithNamedQuery(DepJpeConstants.CIDETAILACTIVE_JPE_FIND_BY_CHEQUEREFNO, params, CiDetailActiveJpe.class);
	        dataObject.setSeqNo(ciDetailJpeList.get(0).getSeqNo());
	        dataObject.setBizVersion(ciDetailJpeList.get(0).getBizVersion());
	        dataObject.setPrefix(ciDetailJpeList.get(0).getPrefix());
        	dataObject.setAmount(ciDetailJpeList.get(0).getDenomination().doubleValue());
		}
		
		if (dataObject.getSeqNo() != null) {
			params.clear();
	        params.put("seqNo", dataObject.getSeqNo());
	        List<CiDetailActiveJpe> ciDetailJpeList = dataService.findWithNamedQuery(DepJpeConstants.CIDETAILACTIVE_JPE_FIND_BY_SEQNO_QUERY, params, CiDetailActiveJpe.class);
	        if (ciDetailJpeList != null && ciDetailJpeList.size() > 0) {
	        	dataObject.setBizVersion(ciDetailJpeList.get(0).getBizVersion());
	        	dataObject.setPrefix(ciDetailJpeList.get(0).getPrefix());
	        	dataObject.setAmount(ciDetailJpeList.get(0).getDenomination().doubleValue());
	        }
		}
	}

	@Override
	protected CiPrintReprint preUpdateValidation(CiPrintReprint dataObject) {
		defaultValues(dataObject);
		return super.preUpdateValidation(dataObject);
	}

	@Override
	public CiPrintReprint update(CiPrintReprint dataObject) {
		return super.update(dataObject);
	}

	@Override
	public List<CiPrintReprint> query(int offset, int resultLimit, String groupBy, String order,
			Map<String, Object> filters) {
		return super.query(offset, resultLimit, groupBy, order, filters);
	}

	@Override
	public List<CiPrintReprint> find(FindCriteria findCriteria, CbsHeader cbsHeader) {
		return super.find(findCriteria, cbsHeader);
	}
}
