package com.silverlakesymmetri.cbs.dep.svc.mapper.mapping;

import com.silverlakesymmetri.cbs.dep.svc.util.MapperUtil;
import org.mapstruct.InheritInverseConfiguration;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Mappings;

import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.DepFeeApplyJpe;
import com.silverlakesymmetri.cbs.dep.xmlapi.DEPFEEAPPLYINType;

@Mapper(uses = { MapperUtil.class })
public interface DepFeeApplyToDEPFEEAPPLYINTypeMapper {

	@Mappings({
	    @Mapping(source = "evidence", target = "EVIDENCE"),
	    @Mapping(source = "forcedPost", target = "FORCEDPOST"),
	    @Mapping(source = "acctNo", target = "ACCTNO"),
	    @Mapping(source = "productClass", target = "PRODUCTCLASS"),
	    @Mapping(source = "scEventRefNo", target = "SCEVENTREFNO"),
	    @Mapping(source = "scCcy", target = "SCCCY"),
	    @Mapping(source = "prodNo", target = "PRODNO"),
	    @Mapping(source = "moduleID", target = "MODULEID"),
	    @Mapping(source = "prodSubType", target = "SUBTYPE"),
	    @Mapping(source = "bookBranch", target = "BOOKBRANCH"),
	    @Mapping(source = "paymentCcy", target = "PAYMENTCCY")
	})
	public DEPFEEAPPLYINType mapDepFeeApplyToDEPFEEAPPLYIN(DepFeeApplyJpe jpe);
	
	@InheritInverseConfiguration(name = "mapDepFeeApplyToDEPFEEAPPLYIN")
	public DepFeeApplyJpe mapDEPFEEAPPLYINToDepFeeApply(DEPFEEAPPLYINType api);
}
