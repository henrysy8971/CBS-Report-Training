package com.silverlakesymmetri.cbs.dep.svc;

import java.util.List;
import java.util.Map;

import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation;
import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation.ServiceOperationType;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.svc.BusinessService;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.ChequeCtrl;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.ChequeCtrlJpe;

public interface ChequeCtrlService extends BusinessService<ChequeCtrl, ChequeCtrlJpe>{
	
	public static final String SVC_OP_NAME_CHEQUECTRLSERVICE_GET= "ChequeCtrlService.get";
	public static final String SVC_OP_NAME_CHEQUECTRLSERVICE_QUERY= "ChequeCtrlService.query";
	public static final String SVC_OP_NAME_CHEQUECTRLSERVICE_CREATE= "ChequeCtrlService.create";
	public static final String SVC_OP_NAME_CHEQUECTRLSERVICE_UPDATE= "ChequeCtrlService.update";
	public static final String SVC_OP_NAME_CHEQUECTRLSERVICE_DELETE= "ChequeCtrlService.delete";
	public static final String SVC_OP_NAME_CHEQUECTRLSERVICE_FIND= "ChequeCtrlService.find";
	public static final String  SVC_OP_NAME_CHEQUECTRLSERVICE_COUNT = "ChequeCtrlService.count";
	
	@ServiceOperation(name = SVC_OP_NAME_CHEQUECTRLSERVICE_CREATE)
    public ChequeCtrl create(ChequeCtrl dataObject);

    @ServiceOperation(name = SVC_OP_NAME_CHEQUECTRLSERVICE_UPDATE)
    public ChequeCtrl update(ChequeCtrl dataObject);

    @ServiceOperation(name = SVC_OP_NAME_CHEQUECTRLSERVICE_DELETE)
    public boolean delete(ChequeCtrl dataObject);

    @ServiceOperation(name = SVC_OP_NAME_CHEQUECTRLSERVICE_QUERY)
    public List<ChequeCtrl> query(int offset, int resultLimit, String groupBy, String order, Map<String, Object> filters);

    @ServiceOperation(name = SVC_OP_NAME_CHEQUECTRLSERVICE_FIND)
    public List<ChequeCtrl> find(FindCriteria findCriteria, CbsHeader cbsHeader);

    @ServiceOperation(name = SVC_OP_NAME_CHEQUECTRLSERVICE_GET, type = ServiceOperationType.GET)
    public ChequeCtrl getByPk(String publicKey, ChequeCtrl reference);

	@ServiceOperation(name = SVC_OP_NAME_CHEQUECTRLSERVICE_COUNT, type = ServiceOperationType.GET)
	public Long count(FindCriteria findCriteria, CbsHeader cbsHeader);

}
