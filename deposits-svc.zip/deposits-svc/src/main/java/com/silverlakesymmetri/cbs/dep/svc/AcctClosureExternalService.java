package com.silverlakesymmetri.cbs.dep.svc;

import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation;
import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation.ServiceOperationType;
import com.silverlakesymmetri.cbs.commons.svc.BusinessService;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.AcctClosureExternal;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.AcctClosureExternalJpe;

public interface AcctClosureExternalService extends BusinessService<AcctClosureExternal, AcctClosureExternalJpe> {

    String SVC_OP_NAME_ACCTCLOSUREEXTERNALSERVICE_CREATE = "AcctClosureExternalService.create";

    @ServiceOperation(name = SVC_OP_NAME_ACCTCLOSUREEXTERNALSERVICE_CREATE,  type = ServiceOperationType.CREATE)
    AcctClosureExternal create(AcctClosureExternal dataObject);
}
