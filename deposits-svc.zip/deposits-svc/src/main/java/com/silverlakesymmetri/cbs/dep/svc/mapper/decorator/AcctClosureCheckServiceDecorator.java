package com.silverlakesymmetri.cbs.dep.svc.mapper.decorator;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.AcctClosureCheckJpe;
import com.silverlakesymmetri.cbs.dep.svc.mapper.AcctClosureCheckServiceMapper;
import com.silverlakesymmetri.cbs.dep.xmlapi.DEPACCTCLOSECHECKTType;

public abstract class AcctClosureCheckServiceDecorator implements AcctClosureCheckServiceMapper{
	
	@Autowired
	@Qualifier("delegate")
	protected  AcctClosureCheckServiceMapper delegate;
	

	@Override
	public List<AcctClosureCheckJpe> mapToJpe(List<DEPACCTCLOSECHECKTType> api){
		
		return delegate.mapToJpe(api);	
	}
}


