package com.silverlakesymmetri.cbs.dep.svc.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.mysema.query.types.EntityPath;
import com.mysema.query.types.OrderSpecifier;
import com.mysema.query.types.Predicate;
import com.mysema.query.types.expr.BooleanExpression;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.svc.AbstractBusinessService;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.CiDdArrangeDef;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.CiDdArrangeDefJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.ExternalBranchJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.QCiDdArrangeDefJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.id.CiDdArrangeDefPk;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.util.DepJpeConstants;
import com.silverlakesymmetri.cbs.dep.svc.CiDdArrangeDefService;

@Service
@Transactional
public class CiDdArrangeDefServiceImpl extends AbstractBusinessService<CiDdArrangeDef, CiDdArrangeDefJpe, CiDdArrangeDefPk> implements CiDdArrangeDefService {

	@Override
	protected EntityPath<CiDdArrangeDefJpe> getEntityPath() {
		return QCiDdArrangeDefJpe.ciDdArrangeDefJpe;
	}

	@Override
	protected CiDdArrangeDefPk getIdFromDataObjectInstance(CiDdArrangeDef dataObject) {
		return new CiDdArrangeDefPk(dataObject.getDdArrangeType(), dataObject.getChequeType(), dataObject.getAgentBank(), dataObject.getAgentBranch(), dataObject.getCcy());
	}

	@Override
	public CiDdArrangeDef getByPk(String publicKey, CiDdArrangeDef reference) {
		CiDdArrangeDef bdo = super.getByPk(publicKey, reference);
		Map<String,Object> param = new HashMap<String, Object>();
		param.put("bankCode", bdo.getAgentBank());
		param.put("branchCode", bdo.getAgentBranch());
		List<ExternalBranchJpe> list = dataService.findWithNamedQuery(DepJpeConstants.EXTERNAL_BRANCH_JPE_FIND_ACTIVE_BY_BANK_AND_BRANCH, param, ExternalBranchJpe.class);
		if (list != null && list.size() > 0) {
			bdo.setCountry(list.get(0).getCountry());			
			bdo.setState(list.get(0).getState());			
		}
		return bdo;
	}

	@Override
	public CiDdArrangeDef create(CiDdArrangeDef dataObject) {
		return super.create(dataObject);
	}

	@Override
	public CiDdArrangeDef update(CiDdArrangeDef dataObject) {
		return super.update(dataObject);
	}
	
	@Override
	public List<CiDdArrangeDef> query(int offset, int resultLimit, String groupBy, String order,
			Map<String, Object> filters) {
		if (resultLimit == 0) resultLimit = 10;
		final List<OrderSpecifier<?>> orders = getOrderSpecifier(QCiDdArrangeDefJpe.ciDdArrangeDefJpe, groupBy, order);
		Predicate predicate = convertMapToPredicate(filters);
		List<CiDdArrangeDef> list = super.query(QCiDdArrangeDefJpe.ciDdArrangeDefJpe, offset, resultLimit, predicate, orders);
		if (list == null) {
			list = new ArrayList<CiDdArrangeDef>();
		}
		Map<String,Object> param = new HashMap<String, Object>();
		for (CiDdArrangeDef bdo: list) {
			param.clear();
			param.put("bankCode", bdo.getAgentBank());
			param.put("branchCode", bdo.getAgentBranch());
			List<ExternalBranchJpe> list2 = dataService.findWithNamedQuery(DepJpeConstants.EXTERNAL_BRANCH_JPE_FIND_ACTIVE_BY_BANK_AND_BRANCH, param, ExternalBranchJpe.class);
			if (list2 != null && list2.size() > 0) {
				bdo.setCountry(list2.get(0).getCountry());
				bdo.setState(list2.get(0).getState());
			}
		}
		return list;
	}

	private Predicate convertMapToPredicate(Map<String, Object> filters) {
		String inOutInd = null;
		if (filters.containsKey("inOutInd")) {
			inOutInd = (String) filters.get("inOutInd");
			filters.remove("inOutInd");
		}
		Predicate predicate = convertMapToPredicate(QCiDdArrangeDefJpe.ciDdArrangeDefJpe, filters);
		List<String> ddArrangeTypeList = new ArrayList<>();
		if ("I".equals(inOutInd)) {
			ddArrangeTypeList.add("IDDI"); // Inward Draft - International
			ddArrangeTypeList.add("IDDL"); // Inward Draft - Local
		} else if ("O".equals(inOutInd)) {
			ddArrangeTypeList.add("ODDI"); // Outward Draft - International
			ddArrangeTypeList.add("ODDL"); // Outward Draft - Local
		}
		if (ddArrangeTypeList.size() > 0) {
			BooleanExpression booleanExpr = QCiDdArrangeDefJpe.ciDdArrangeDefJpe.ddArrangeType.in(ddArrangeTypeList);
			if (predicate != null) {
				predicate = ((BooleanExpression) predicate).and(booleanExpr);
			} else {
				predicate = booleanExpr;
			}
		}
		return predicate;
	}

	@Override
	public boolean delete(CiDdArrangeDef dataObject) {
		return super.delete(dataObject);
	}

	@Override
	public List<CiDdArrangeDef> find(FindCriteria findCriteria, CbsHeader cbsHeader) {
		return super.find(findCriteria, cbsHeader);
	}

}
