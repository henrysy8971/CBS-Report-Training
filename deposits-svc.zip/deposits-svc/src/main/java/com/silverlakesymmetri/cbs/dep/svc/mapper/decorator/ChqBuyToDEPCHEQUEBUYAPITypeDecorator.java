package com.silverlakesymmetri.cbs.dep.svc.mapper.decorator;

import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.*;
import com.silverlakesymmetri.cbs.dep.svc.mapper.TranValidationFlagsMapper;
import com.silverlakesymmetri.cbs.dep.svc.mapper.mapping.ChqBuyToDEPCHEQUEBUYAPITypeMapper;
import com.silverlakesymmetri.cbs.dep.xmlapi.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by Emerson.Sanchez on 21/11/2019.
 */
public abstract class ChqBuyToDEPCHEQUEBUYAPITypeDecorator implements ChqBuyToDEPCHEQUEBUYAPITypeMapper, TranValidationFlagsMapper {

    @Autowired
    @Qualifier("delegate")
    protected ChqBuyToDEPCHEQUEBUYAPITypeMapper delegate;

    @Override
    public DEPCHEQUEBUYAPIType jpeToApiType(ChqBuyJpe jpe) {
        DEPCHEQUEBUYAPIType apiType = delegate.jpeToApiType(jpe);

        apiType.setTRANVALIDATIONFLAGS(mapValidationFlags(jpe.getChqBuyTranList().isEmpty() ? null
                : jpe.getChqBuyTranList().get(0), "N", "N", "N", "Y", "Y"));

        DEPCHQBUYBENEFINTType bene = delegate.jpeToBeneficiaryApiType(jpe.getChqBuyBeneficiaryDetailsRec());
        
        if (jpe.getChqBuyBeneficiaryDetailsRec() != null && "N".equals(jpe.getChqBuyBeneficiaryDetailsRec().getExistingClient())){
        	bene.setBENEFCONTACTREFNO(jpe.getChqBuyBeneficiaryDetailsRec().getBeneficiaryContactType());
        }
        
        if(apiType.getDEPCHQBUYBENEFINDTLS() == null){
            apiType.setDEPCHQBUYBENEFINDTLS(new DEPCHQBUYBENEFINCOLLType());
        }
        apiType.getDEPCHQBUYBENEFINDTLS().getDEPCHQBUYBENEFINT().add(bene);

        List<DEPCHQBUYDDINTType> list = new ArrayList<>();
        for(ChqBuyDdBnkJpe ddBnkJpe: jpe.getChqBuyDdBnkList()) {
            DEPCHQBUYDDINTType chqBuyDdInt = jpeToDdIntType(ddBnkJpe, jpe);
            list.add(chqBuyDdInt);
        }

        if(apiType.getDEPCHQBUYDDINDTLS() == null){
            apiType.setDEPCHQBUYDDINDTLS(new DEPCHQBUYDDINCOLLType());
        }
        apiType.getDEPCHQBUYDDINDTLS().getDEPCHQBUYDDINT().addAll(list);

        return apiType;
    }

    @Override
    public DEPCHQBUYBENEFINTType jpeToBeneficiaryApiType(ChqBuyBeneficiaryDetailsJpe jpe) {
        return delegate.jpeToBeneficiaryApiType(jpe);
    }

    private DEPCHQBUYDDINTType jpeToDdIntType(ChqBuyDdBnkJpe jpe, ChqBuyJpe mainJpe) {
        DEPCHQBUYDDINTType apiType = delegate.jpeToDdIntType(jpe);
        if (("TCH").equals(mainJpe.getProcType())) {
            apiType.setAMOUNT(Double.parseDouble(jpe.getDenomination()));
        } else {
            apiType.setAMOUNT(jpe.getChequeAmount());
        }

        if (jpe.getStartChequeNo() != null) {
            apiType.setSTARTNO(jpe.getStartChequeNo());
            if (jpe.getEndChequeNo() != null) {
                apiType.setENDNO(jpe.getEndChequeNo());
            } else {
                apiType.setENDNO(jpe.getStartChequeNo());
            }
            apiType.setQTY(valueIfNull(apiType.getENDNO() - apiType.getSTARTNO()) + 1);
        }
        return apiType;
    }

    @Override
    public DEPCHQBUYSELLPYMTINTType jpeToSellPaymentType(ChqBuyTranJpe jpe) {
        DEPCHQBUYSELLPYMTINTType apiType = delegate.jpeToSellPaymentType(jpe);
        apiType.setFROMRATEFLAG("S");
        apiType.setFROMID("D");
        apiType.setTOID("I");
        apiType.setTORATEFLAG("B");
        return apiType;
    }

    @Override
    public DEPCHQBUYDDINTType jpeToDdIntType (ChqBuyDdBnkJpe jpe) {
        return delegate.jpeToDdIntType(jpe);
    }

    private Long valueIfNull(Long var) {
        Long xVar = 0L;

        if (var != null) {
            return var;
        }
        return xVar;
    }
}
