package com.silverlakesymmetri.cbs.dep.svc.impl;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.NoSuchMessageException;
import org.springframework.stereotype.Service;

import com.mysema.query.types.EntityPath;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.exception.base.dto.ValidationDto;
import com.silverlakesymmetri.cbs.commons.exception.base.helper.ExceptionHelper;
import com.silverlakesymmetri.cbs.commons.svc.AbstractXmlApiBusinessService;
import com.silverlakesymmetri.cbs.commons.util.MessageUtils;
import com.silverlakesymmetri.cbs.commons.xmlapi.enums.CbsXmlApiOperation;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.InwdChequeHist;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.InwdChequeHistJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.QInwdChequeHistJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.TdSoJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.id.InwdChequeHistPk;
import com.silverlakesymmetri.cbs.dep.svc.InwdChequeClearingOverrideService;
import com.silverlakesymmetri.cbs.dep.svc.mapper.InwdChequeClearingOverrideServiceMapper;
import com.silverlakesymmetri.cbs.dep.xmlapi.DEPINWDCCOVERRIDEAPIType;


@Service
public class InwdChequeClearingOverrideServiceImpl extends 
									AbstractXmlApiBusinessService<InwdChequeHist, InwdChequeHistJpe, InwdChequeHistPk,  DEPINWDCCOVERRIDEAPIType, DEPINWDCCOVERRIDEAPIType>  
									implements InwdChequeClearingOverrideService{
	
	@Autowired
	InwdChequeClearingOverrideServiceMapper mapper;
	
	@Autowired
    protected MessageUtils messageUtils;
	
	@Override
	protected DEPINWDCCOVERRIDEAPIType transformBdoToXmlApiRqCreate(InwdChequeHist dataObject) {
		// TODO Auto-generated method stub
		 return transformInwdChequeHistToDEPINWDCCOVERRIDEAPIType( dataObject, CbsXmlApiOperation.INSERT);
	}

	@Override
	protected DEPINWDCCOVERRIDEAPIType transformBdoToXmlApiRqUpdate(InwdChequeHist dataObject) {
		// TODO Auto-generated method stub
		return transformInwdChequeHistToDEPINWDCCOVERRIDEAPIType( dataObject, CbsXmlApiOperation.UPDATE );
	}

	@Override
	protected DEPINWDCCOVERRIDEAPIType transformBdoToXmlApiRqDelete(InwdChequeHist dataObject) {
		// TODO Auto-generated method stub
		return transformInwdChequeHistToDEPINWDCCOVERRIDEAPIType( dataObject, CbsXmlApiOperation.DELETE);
	}

	@Override
	protected InwdChequeHist processXmlApiRs(InwdChequeHist dataObject, DEPINWDCCOVERRIDEAPIType xmlApiRs) {
		// TODO Auto-generated method stub
		InwdChequeHistJpe jpe = jaxbSdoHelper.unwrap(dataObject);
		jpe = mapper.mapToJpe(xmlApiRs, jpe);
		InwdChequeHist bdo = jaxbSdoHelper.wrap(jpe);
		if (bdo != null) {
			bdo.setErrorDesc(getErrDesc(bdo.getErrorNo()));
		}
		return bdo;
	}

	@Override
	protected List<InwdChequeHist> processXmlApiListRs(InwdChequeHist dataObject, DEPINWDCCOVERRIDEAPIType xmlApiRs) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	protected Class<DEPINWDCCOVERRIDEAPIType> getXmlApiResponseClass() {
		// TODO Auto-generated method stub
		return DEPINWDCCOVERRIDEAPIType.class;
	}

	@Override
	protected InwdChequeHistPk getIdFromDataObjectInstance(InwdChequeHist dataObject) {
		// TODO Auto-generated method stub
		TdSoJpe jpe = jaxbSdoHelper.unwrap(dataObject);
		return new InwdChequeHistPk(jpe.getSeqNo());
	}

	@Override
	protected EntityPath<InwdChequeHistJpe> getEntityPath() {
		// TODO Auto-generated method stub
		return QInwdChequeHistJpe.inwdChequeHistJpe; 
	}

	@Override
	public InwdChequeHist getByPk(String publicKey, InwdChequeHist reference) {
		// TODO Auto-generated method stub
		InwdChequeHist bdo = super.getByPk(publicKey, reference);
		if (bdo != null) {
			bdo.setErrorDesc(getErrDesc(bdo.getErrorNo()));
		}
		return bdo;
	}

	@Override
	public InwdChequeHist create(InwdChequeHist tdSo) {
		// TODO Auto-generated method stub
		InwdChequeHist bdo = super.create(tdSo);
		if (bdo != null) {
			bdo.setErrorDesc(getErrDesc(bdo.getErrorNo()));
		}
		return bdo;
	}

	private void generateException(String errorCode){
		Collection<ValidationDto> validators = new ArrayList<ValidationDto>();
		ValidationDto dto =  new ValidationDto();
		dto.setCode(errorCode);
		try {
			dto.setMessage(messageUtils.getMessage(dto.getCode()));
		} catch (NoSuchMessageException e) {}
		validators.add(dto);
		ExceptionHelper.generateExceptions(validators, null, true, null, null);
	}

	@Override
	public InwdChequeHist update(InwdChequeHist tdSo) {
		// TODO Auto-generated method stub
		tdSo = super.update(tdSo);
		int code = new Double(tdSo.getErrorNo()).intValue();
		if (code > 0){
			generateException(new StringBuilder("CBS.B.DEP.").append(Integer.toString(code)).toString());
		}
		if (tdSo != null) {
			tdSo.setErrorDesc(getErrDesc(tdSo.getErrorNo()));
		}
		return tdSo;
	}

	@Override
	public boolean delete(InwdChequeHist tdSo) {
		// TODO Auto-generated method stub
		return super.delete(tdSo);
	}

	@Override
	public List<InwdChequeHist> query(int offset, int resultLimit, String groupBy, String order,
			Map<String, Object> filters) {
		// TODO Auto-generated method stub
		List<InwdChequeHist> list = super.query(offset, resultLimit, groupBy, order, filters);
		if (list != null) {
			for (InwdChequeHist bdo : list) {
				bdo.setErrorDesc(getErrDesc(bdo.getErrorNo()));
			}
		}
		return list;
	}

	@Override
	public List<InwdChequeHist> find(FindCriteria findCriteria, CbsHeader cbsHeader) {
		// TODO Auto-generated method stub
		List<InwdChequeHist> list = super.find(findCriteria, cbsHeader);
		if (list != null) {
			for (InwdChequeHist bdo : list) {
				bdo.setErrorDesc(getErrDesc(bdo.getErrorNo()));
			}
		}
		return list;
	}
		
	private DEPINWDCCOVERRIDEAPIType transformInwdChequeHistToDEPINWDCCOVERRIDEAPIType(InwdChequeHist dataObject, CbsXmlApiOperation oper){
		
//		Map map = new HashMap();
//		CbsSessionContext sessionCtx = _ctxMngr.getContext(CbsSessionContext.class);
//		map.put(mapper.BRANCH, super.getUserBranch(sessionCtx.getUserCode()));
		
		InwdChequeHistJpe jpe = jaxbSdoHelper.unwrap(dataObject);
		DEPINWDCCOVERRIDEAPIType api =  mapper.mapToApi(jpe, oper, new HashMap());
		super.setTechColsFromDataObject(dataObject, api);

		return api;
	}
	
}
