package com.silverlakesymmetri.cbs.dep.svc.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mysema.query.types.EntityPath;
import com.silverlakesymmetri.cbs.commons.svc.AbstractXmlApiBusinessService;
import com.silverlakesymmetri.cbs.commons.xmlapi.enums.CbsXmlApiOperation;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.OnlineIntCap;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.OnlineIntCapJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.OnlineScCollectionJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.QOnlineIntCapJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.id.OnlineIntCapPk;
import com.silverlakesymmetri.cbs.dep.svc.OnlineIntCapService;
import com.silverlakesymmetri.cbs.dep.svc.mapper.OnlineIntCapServiceMapper;
import com.silverlakesymmetri.cbs.dep.xmlapi.DEPACCTINTCAPAPIType;

@Service
public class OnlineIntCapServiceImpl extends AbstractXmlApiBusinessService<OnlineIntCap, OnlineIntCapJpe, OnlineIntCapPk,  DEPACCTINTCAPAPIType, DEPACCTINTCAPAPIType> implements OnlineIntCapService{
		
	@Autowired
	OnlineIntCapServiceMapper mapper;
	
	@Override
	protected DEPACCTINTCAPAPIType transformBdoToXmlApiRqCreate(OnlineIntCap dataObject) {
		// TODO Auto-generated method stub
		return mapToDEPACCTINTCAPAPIType(dataObject, CbsXmlApiOperation.INSERT);
	}

	@Override
	protected DEPACCTINTCAPAPIType transformBdoToXmlApiRqUpdate(OnlineIntCap dataObject) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	protected DEPACCTINTCAPAPIType transformBdoToXmlApiRqDelete(OnlineIntCap dataObject) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	protected Class<DEPACCTINTCAPAPIType> getXmlApiResponseClass() {
		// TODO Auto-generated method stub
		return DEPACCTINTCAPAPIType.class;
	}

	@Override
	protected OnlineIntCapPk getIdFromDataObjectInstance(OnlineIntCap dataObject) {
		OnlineIntCapPk id = new OnlineIntCapPk();
		return id;
	}

	@Override
	protected EntityPath<OnlineIntCapJpe> getEntityPath() {
		// TODO Auto-generated method stub
		return QOnlineIntCapJpe.onlineIntCapJpe;
	}
	
	@Override
	public OnlineIntCap getByPk(String publicKey, OnlineIntCap dataObject) {
		if (dataObject == null){
			dataObject = jaxbSdoHelper.createSdoInstance(OnlineIntCap.class);
		}
		
		OnlineIntCapJpe jpe = jaxbSdoHelper.unwrap(dataObject);
		
		jpe.setAcctNo(publicKey);
		jpe.setPublicKey(publicKey);
		return dataObject;
	}
	
	@Override
	public List<OnlineIntCap> query(int offset, int resultLimit, String groupBy, String order, Map<String, Object> filters) {
		
		// TODO Auto-generated method stub
		if (filters.isEmpty() ){
			return null;
		}
		
		if (!filters.containsKey("acctNo") || !filters.containsKey("paymentOption")){
			return null;
		}
		
		OnlineIntCap dataObject = jaxbSdoHelper.createSdoInstance(OnlineIntCap.class);
		dataObject.setAcctNo((String)filters.get("acctNo"));
		dataObject.setPaymentOption((String)filters.get("paymentOption"));
		
		OnlineIntCap bdo = queryDataObject(mapToDEPACCTINTCAPAPIType(dataObject, CbsXmlApiOperation.QUERY));
		
		List<OnlineIntCap> list = new ArrayList<OnlineIntCap>();
		list.add(bdo);
		
		return list;
	}
	
	private DEPACCTINTCAPAPIType mapToDEPACCTINTCAPAPIType(OnlineIntCap bdo, CbsXmlApiOperation oper){
			   
		OnlineIntCapJpe jpe = jaxbSdoHelper.unwrap(bdo);
		DEPACCTINTCAPAPIType apiType =   mapper.mapToApi(jpe, oper, new HashMap());
		super.setTechColsFromDataObject(bdo, apiType);	   
	   
	   return apiType;
	}
	
    public OnlineIntCap create(OnlineIntCap onlineIntCap){
    	return super.create(onlineIntCap);
	}
	
	@Override
	protected List<OnlineIntCap> processXmlApiListRs(OnlineIntCap dataObject,
			DEPACCTINTCAPAPIType xmlApiRs) {
		// TODO Auto-generated method stub
		return null;
	}
    
    @Override
	protected OnlineIntCap processXmlApiRs(OnlineIntCap dataObject, DEPACCTINTCAPAPIType xmlApiRs) {
		
    	if (dataObject == null){
    		dataObject = jaxbSdoHelper.createSdoInstance(OnlineIntCap.class);
    	}
    	OnlineIntCapJpe jpe = jaxbSdoHelper.unwrap(dataObject);
		mapper.mapToJpe(xmlApiRs, jpe);
		return jaxbSdoHelper.wrap(jpe);
	}

//	private MasterAccountJpe getMasterAccount( String accountNo) {
//  final Map<String, Object> param = new HashMap<String, Object>();
//  param.put(CoreConstants.ATTR_ACCOUNT_DOMAIN, "DEPOSIT");
//  param.put(CoreConstants.ATTR_ACCOUNT_NO, accountNo);
//  MasterAccountJpe masterAccountRec = dataService.getWithNamedQuery(JpeConstants.MASTER_ACCOUNT_JPE_GET_ACCOUNT_BY_DOMAIN_ACCOUNT_NO,
//          param, MasterAccountJpe.class);
//  return masterAccountRec;
//}

}
