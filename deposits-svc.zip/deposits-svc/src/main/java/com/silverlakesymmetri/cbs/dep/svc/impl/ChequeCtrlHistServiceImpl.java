package com.silverlakesymmetri.cbs.dep.svc.impl;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.mysema.query.types.EntityPath;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.svc.AbstractBusinessService;
import com.silverlakesymmetri.cbs.commons.svc.BusinessObjectValidationCapable;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.ChequeCtrlHist;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.ChequeCtrlHistJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.QChequeCtrlHistJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.id.ChequeCtrlHistPk;
import com.silverlakesymmetri.cbs.dep.svc.ChequeCtrlHistService;

@Service
@Transactional
public class ChequeCtrlHistServiceImpl extends AbstractBusinessService<ChequeCtrlHist, ChequeCtrlHistJpe, ChequeCtrlHistPk>
implements ChequeCtrlHistService, BusinessObjectValidationCapable<ChequeCtrlHist> {

	@Override
	protected ChequeCtrlHistPk getIdFromDataObjectInstance(ChequeCtrlHist dataObject) {
		return new ChequeCtrlHistPk(dataObject.getSeqNo());
	}

	@Override
	protected EntityPath<ChequeCtrlHistJpe> getEntityPath() {
		return QChequeCtrlHistJpe.chequeCtrlHistJpe;
	}

	@Override
	public List<ChequeCtrlHist> query(int offset, int resultLimit, String groupBy, String order,
			Map<String, Object> filters) {
		return super.query(offset, resultLimit, groupBy, order, filters);
	}

	@Override
	public ChequeCtrlHist getByPk(String publicKey, ChequeCtrlHist reference) {
		return super.getByPk(publicKey, reference);
	}
	
}
