package com.silverlakesymmetri.cbs.dep.svc.mapper.decorator;

import com.silverlakesymmetri.cbs.commons.xmlapi.enums.CbsXmlApiOperation;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.AcctTypeChangeJpe;
import com.silverlakesymmetri.cbs.dep.svc.mapper.AcctTypeTransferServiceMapper;
import com.silverlakesymmetri.cbs.dep.xmlapi.DEPACCTTYPETFRAPIType;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

import java.util.Map;

/**
 * Created by Emerson.Sanchez on 14/10/2019.
 */
public abstract class AcctTypeTransferServiceDecorator extends FeeServiceDecorator implements AcctTypeTransferServiceMapper{

    @Autowired
    @Qualifier("delegate")
    protected AcctTypeTransferServiceMapper delegate;

    @Override
    public DEPACCTTYPETFRAPIType mapToApi(AcctTypeChangeJpe jpe, CbsXmlApiOperation oper){

        DEPACCTTYPETFRAPIType req = (DEPACCTTYPETFRAPIType)delegate.mapToApi(jpe, oper);
        mapFeeToApi(jpe, req);
        return  req;
    }

    @Override
    public AcctTypeChangeJpe mapToJpe(DEPACCTTYPETFRAPIType api, AcctTypeChangeJpe jpe){

        if (jpe == null){
            jpe = new AcctTypeChangeJpe();
        }

        if (api == null){
            return jpe;
        }

        delegate.mapToJpe(api, jpe);

        return jpe;
    }
}
