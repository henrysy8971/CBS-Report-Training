package com.silverlakesymmetri.cbs.dep.svc;

import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation;
import com.silverlakesymmetri.cbs.commons.svc.BusinessService;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.CashGlBalance;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.CashGlBalanceJpe;

import java.util.List;
import java.util.Map;

public interface CashGlBalanceService extends BusinessService<CashGlBalance, CashGlBalanceJpe> {

    String SVC_OP_NAME_CASHGLBALANCESERVICE_QUERY = "CashGlBalanceService.query";

    @ServiceOperation(name = SVC_OP_NAME_CASHGLBALANCESERVICE_QUERY)
    List<CashGlBalance> query(int offset, int resultLimit, String groupBy, String order, Map<String, Object> filters);
}
