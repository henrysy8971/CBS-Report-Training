package com.silverlakesymmetri.cbs.dep.svc;

import java.util.List;
import java.util.Map;

import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation;
import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation.ServiceOperationType;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.svc.BusinessService;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.FloatAdjustmentBranch;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.FloatRolldown;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.TranHist;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.FloatRolldownJpe;

public interface FloatRolldownService extends BusinessService<FloatRolldown, FloatRolldownJpe>{
	
    public static final String SVC_OP_NAME_FLOATROLLDOWN_GET = "FloatRolldownService.get";
    public static final String SVC_OP_NAME_FLOATROLLDOWN_QUERY = "FloatRolldownService.query";
    public static final String SVC_OP_NAME_FLOATROLLDOWN_CREATE = "FloatRolldownService.create";
    public static final String SVC_OP_NAME_FLOATROLLDOWN_UPDATE = "FloatRolldownService.update";
    // public static final String SVC_OP_NAME_FLOATROLLDOWN_DELETE = "FloatRolldownService.delete";
    public static final String SVC_OP_NAME_FLOATROLLDOWN_FIND = "FloatRolldownService.find";
    public static final String SVC_OP_NAME_FLOATROLLDOWN_UPDATE_TRANHIST = "FloatRolldownService.updTranHist";
    public static final String SVC_OP_NAME_FLOATROLLDOWN_PROCESS_FLOAT_ADJ = "FloatRolldownService.processFloatAdj";
    
    @ServiceOperation(name = SVC_OP_NAME_FLOATROLLDOWN_GET, type = ServiceOperationType.GET)
    public FloatRolldown getByPk(String publicKey, FloatRolldown reference);

    @ServiceOperation(name = SVC_OP_NAME_FLOATROLLDOWN_CREATE)
    public FloatRolldown create(FloatRolldown dataObject);

    @ServiceOperation(name = SVC_OP_NAME_FLOATROLLDOWN_UPDATE)
    public FloatRolldown update(FloatRolldown dataObject);

    @ServiceOperation(name = SVC_OP_NAME_FLOATROLLDOWN_QUERY)
    public List<FloatRolldown> query(int offset, int resultLimit, String groupBy, String order, Map<String, Object> filters);

    // @ServiceOperation(name = SVC_OP_NAME_FLOATROLLDOWN_DELETE)
    // public boolean delete(FloatRolldown dataObject);

    @ServiceOperation(name = SVC_OP_NAME_FLOATROLLDOWN_FIND)
    public List<FloatRolldown> find(FindCriteria findCriteria, CbsHeader cbsHeader);

    @ServiceOperation(name = SVC_OP_NAME_FLOATROLLDOWN_UPDATE_TRANHIST, type = ServiceOperationType.EXECUTE)
    public TranHist updTranHist(TranHist dataObject);
    
    @ServiceOperation(name = SVC_OP_NAME_FLOATROLLDOWN_PROCESS_FLOAT_ADJ, type = ServiceOperationType.EXECUTE)
    public FloatAdjustmentBranch processFloatAdj(FloatAdjustmentBranch dataObject);
}