package com.silverlakesymmetri.cbs.dep.svc.ext;

import java.util.*;

import javax.validation.ConstraintValidatorContext;
import javax.validation.ConstraintViolation;
import javax.validation.Path;
import javax.validation.metadata.ConstraintDescriptor;

import com.silverlakesymmetri.cbs.commons.ext.impl.AbstractServiceExtPointImpl;
import com.silverlakesymmetri.cbs.csd.jpa.mapping.sdo.ServRateTypeQryJpe;
import com.silverlakesymmetri.cbs.csd.jpa.mapping.sdo.ServTypeQryJpe;
import com.silverlakesymmetri.cbs.csd.jpa.mapping.sdo.util.CsdJpeConstants;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.*;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mysema.query.types.Predicate;
import com.silverlakesymmetri.cbs.commons.enums.DatatypeEnum;
import com.silverlakesymmetri.cbs.commons.ext.ServiceExtensionPoint;
import com.silverlakesymmetri.cbs.commons.jpa.mapping.sdo.MetadataAttrJpe;
import com.silverlakesymmetri.cbs.commons.jpa.mapping.sdo.MetadataValue;
import com.silverlakesymmetri.cbs.commons.jpa.mapping.sdo.RegistryJpe;
import com.silverlakesymmetri.cbs.commons.jpa.mapping.sdo.util.JpeConstants;
import com.silverlakesymmetri.cbs.commons.jpa.repository.RegistryRepository;
import com.silverlakesymmetri.cbs.commons.jpa.service.CbsGenericDataService;
import com.silverlakesymmetri.cbs.commons.jpa.util.DateTimeHelper;
import com.silverlakesymmetri.cbs.commons.jpa.util.JpaEntityChangeTracker;
import com.silverlakesymmetri.cbs.commons.jpa.validation.business.DepositsRegistryServiceExt;
import com.silverlakesymmetri.cbs.commons.util.MessageUtils;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.util.DepJpeConstants;

/**
 * implements DepositsRegistryServiceExt defined in Commons
 * used to validate the deposits registry entries that would need information from deposits 
 * currently being used by RegistryPersistValidator
 * 
 * @author jeffrey.villanueva
 *
 */
@Service
public class DepositsRegistryServiceExtImpl extends AbstractServiceExtPointImpl implements ServiceExtensionPoint, DepositsRegistryServiceExt {
	
	private static final String UPDATE_NOT_ALLOWED = "{CBS.B.DEP.DEPOSITS_REGISTRY_EXT_SERVICE.0001}";
	private static final String PRIORITY_MUST_BE_UNIQUE = "{CBS.B.DEP.DEPOSITS_REGISTRY_EXT_SERVICE.0002}";
	private static final String MUST_NOT_BE_EQUAL_TO = "{CBS.B.DEP.DEPOSITS_REGISTRY_EXT_SERVICE.0003}";
	private static final String CANNOT_BE_NULL_WHEN_ANOTHER_FIELD_IS_NOT = "{CBS.B.DEP.DEPOSITS_REGISTRY_EXT_SERVICE.0004}";
	private static final String DATE_CANNOT_BE_LESS_THAN_RUN_DATE = "{CBS.B.DEP.DEPOSITS_REGISTRY_EXT_SERVICE.0005}";
	private static final String INVALID_IT_DR_TRAN_TYPE = "{CBS.B.DEP.DEPOSITS_REGISTRY_EXT_SERVICE.0006}";
	private static final String INVALID_IT_CR_TRAN_TYPE = "{CBS.B.DEP.DEPOSITS_REGISTRY_EXT_SERVICE.0007}";
	private static final String INVALID_SC_TYPE_LATE_PAYMT = "{CBS.B.DEP.DEPOSITS_REGISTRY_EXT_SERVICE.0008}";
	private static final String INVALID_SC_RATE_TYPE_LATE_PAYMT = "{CBS.B.DEP.DEPOSITS_REGISTRY_EXT_SERVICE.0009}";

	@Autowired
	protected MessageUtils messageUtils;
	
	@Autowired
	private RegistryRepository registryRepository;
	
	@Autowired
    protected DateTimeHelper dateTimeHelper;

	private static final String PRINCIPAL_PRIORITY = "principalPriority";
	private static final String INSURANCE_PRIORITY = "insurancePriority";
	private static final String FEE_PRIORITY = "feePriority";
	private static final String RESTRAINT_TYPE = "restraintType";
	private static final String INACTIVE_RESTRAINT = "inactiveRestraint";
	private static final String FT_RESTRAINT_TYPE = "ftRestraintType";
	private static final String TFR_DEP_TRAN_TYPE = "tfrDepTranType";
	private static final String TFR_WDL_TRAN_TYPE = "tfrWdlTranType";
	private static final String NEXT_STMT_DATE = "nextStmtDate";
	private static final String OD_RESTRAINT_SW = "odRestraintSw";
	private static final String UNAUTH_DR_INT_RESTRAINT_TYPE = "unauthDrIntRestraintType";
	private static final String CLIENT_BLOCK_RESTRAINT = "clientBlockRestraint";
	private static final String INTEREST_PRIORITY = "interestPriority";
	private static final String ATTRIBUTE_CODE = "attributeCode";
	private static final String META_TYPE2 = "metaType";
	private static final String META_CODE = "metaCode";
	private static final String STATUS_A = "A";
	private static final String VALUE_S = "valueS";
	private static final String FUNDS_TRANSFER_REGISTRY = "FUNDS_TRANSFER_REGISTRY";
	private static final String META_TYPE = "REGISTRY";
	private static final String IT_DR_TRAN_TYPE = "atscDrTfrTranType";
	private static final String IT_CR_TRAN_TYPE = "atscCrTfrTranType";

	
	private static final String ATTR_CODES_FOR_VALIDATION1 = "inactiveRestraint|dormantRestraint|escheatRestraint|suspendMailRestraintType|deferralDocRestraintType";
	private static final String RESTRAINT_CLASS1 = "AS|SW|SD|IN|SC";
	private static final String ATTR_CODES_FOR_VALIDATION2 = "scRestraintType|chqIssueSc";
	private static final String RESTRAINT_CLASS2 = "SC";
	private static final String ATTR_CODES_FOR_VALIDATION3 = "fhRestraintType";
	private static final String RESTRAINT_CLASS3 = "FH";
	private static final String ATTR_CODES_FOR_VALIDATION4 = "interestPriority|feePriority|insurancePriority|principalPriority";
	private static final String ATTR_CODES_FOR_VALIDATION5 = "interestDrTrf|feeDrTrf|insuranceDrTrf|principalDrTrf|repaySweepDrTrf";
	private static final String ATTR_CODES_FOR_VALIDATION6 = "interestCrTrf|feeCrTrf|insuranceCrTrf|principalCrTrf|repaySweepCrTrf";
	private static final String ATTR_CODES_FOR_VALIDATION7 = "capStmtPeriodFreq|nextStmtDate";
	private static final String ATTR_CODES_FOR_VALIDATION8 = "atscDrTfrTranType|atscCrTfrTranType";
	private static final String ATTR_CODES_FOR_VALIDATION9 = "scTypeLatePaymt";
	private static final String ATTR_CODES_FOR_VALIDATION10 = "scRateTypeLatePaymt";



	@Autowired
    private CbsGenericDataService dataService;
	
	@Override
	public boolean isValid(RegistryJpe registryJpe, ConstraintValidatorContext context, Map<String, String[]> messageParam) {
		boolean result = true;
		JpaEntityChangeTracker ct = dataService.getJpaEntityChangeTracker(registryJpe);		
		if (registryJpe != null && META_TYPE.equals(registryJpe.getMetaType()) && DEPOSITS_REGISTRY.equals(registryJpe.getMetaCode())
			&& registryJpe.getAttributeCode() != null) {
			if (registryJpe.getAttributeCode().matches(ATTR_CODES_FOR_VALIDATION1)) {
//					DEPOSITS_REGISTRY.inactiveRestraint, DEPOSITS_REGISTRY.dormantRestraint, DEPOSITS_REGISTRY.escheatRestraint, DEPOSITS_REGISTRY.suspendMailRestraintType & DEPOSITS_REGISTRY.deferralDocRestraintType
//					Valid value from DEP_RESTRAINT_TYPE where
//					restraint_class in('AS','SW','SD','IN')
//					update/delete is not allowed if there are active restraints of this type (check if there are records in Restraints where status = A)
				result = validateRestraintTypeChanged(context, messageParam, ct, registryJpe, RESTRAINT_CLASS1);
			} else if (registryJpe.getAttributeCode().matches(ATTR_CODES_FOR_VALIDATION2)) {
//					DEPOSITS_REGISTRY.scRestraintType & DEPOSITS_REGISTRY.chqIssueSc
//					Valid value from DEP_RESTRAINT_TYPE where
//					restraint_class in('SC') --> already defined for metaCheck=RestraintType.restraintType[SC]
//					update/delete is not allowed if there are active restraints of this type (check if there are records in Restraints where status = A)
				result = validateRestraintTypeChanged(context, messageParam, ct, registryJpe, RESTRAINT_CLASS2);
			} else if (registryJpe.getAttributeCode().matches(ATTR_CODES_FOR_VALIDATION3)) {
//					DEPOSITS_REGISTRY.fhRestraintType
//					Valid value from DEP_RESTRAINT_TYPE where
//					restraint_class in('FH') --> already defined for metaCheck=RestraintType.restraintType[FH]
//					update/delete is not allowed if there are active restraints of this type (check if there are records in Restraints where status = A)
				result = validateRestraintTypeChanged(context, messageParam, ct, registryJpe, RESTRAINT_CLASS3);
			} else if (registryJpe.getAttributeCode().matches(ATTR_CODES_FOR_VALIDATION5)) {
				RegistryJpe tfrWdlTranTypeJpe = registryRepository.find(DEPOSITS_REGISTRY, TFR_WDL_TRAN_TYPE);
				result = validateRegistryMustNotMatchRegistryValue(context, messageParam, ct, registryJpe, tfrWdlTranTypeJpe);
			} else if (registryJpe.getAttributeCode().matches(ATTR_CODES_FOR_VALIDATION6)) {
				RegistryJpe tfrDepTranTypeJpe = registryRepository.find(DEPOSITS_REGISTRY, TFR_DEP_TRAN_TYPE);
				result = validateRegistryMustNotMatchRegistryValue(context, messageParam, ct, registryJpe, tfrDepTranTypeJpe);
			} else if (CLIENT_BLOCK_RESTRAINT.equals(registryJpe.getAttributeCode())) {
				result = validateHasActiveRestraint(context, messageParam, ct, registryJpe);
			} else if (UNAUTH_DR_INT_RESTRAINT_TYPE.equals(registryJpe.getAttributeCode())) {
				RegistryJpe ftRestraintTypeJpe = findOtherRegistry(FUNDS_TRANSFER_REGISTRY, FT_RESTRAINT_TYPE);
				result = validateRegistryMustNotMatchRegistryValue(context, messageParam, ct, registryJpe, ftRestraintTypeJpe);
			} else if (OD_RESTRAINT_SW.equals(registryJpe.getAttributeCode())) {
				RegistryJpe inactiveRestraintJpe = registryRepository.find(DEPOSITS_REGISTRY, INACTIVE_RESTRAINT);
				result = validateRegistryMustNotMatchRegistryValue(context, messageParam, ct, registryJpe, inactiveRestraintJpe);
			} else if (NEXT_STMT_DATE.equals(registryJpe.getAttributeCode())) {
				result = validateDateFieldNotLessThanRunDate(context, messageParam, ct, registryJpe);
			}  else if(registryJpe.getAttributeCode().matches(ATTR_CODES_FOR_VALIDATION8)) {
				result = validateItTranTypeValue(context, messageParam, ct, registryJpe);
			} else if (ATTR_CODES_FOR_VALIDATION9.equalsIgnoreCase(registryJpe.getAttributeCode())) {
				result = validateScTypeLatePayment(context,messageParam,ct,registryJpe);
			} else if (ATTR_CODES_FOR_VALIDATION10.equalsIgnoreCase(registryJpe.getAttributeCode())) {
				result = validateScRateTypeLatePayment(context,messageParam,ct,registryJpe);
			}
		}
		
		return result;
	}

	/**
	 * Used to retrieve registry value from another module
	 * If the registry value being checked is from another module, error should not be thrown if setup is not found, should just return null
	 * @param metaCode String
	 * @param attributeCode String
	 * @return RegistryJpe
	 */
	private RegistryJpe findOtherRegistry(String metaCode, String attributeCode) {
		final Map<String, Object> namedQueryParameters = new HashMap<String, Object>();
		namedQueryParameters.put("metaCode", metaCode);
		namedQueryParameters.put("attributeCode", attributeCode);
		List<RegistryJpe> list = dataService.findWithNamedQuery(
		        JpeConstants.REGISTRY_JPE__FIND_REGISTRY, namedQueryParameters,
				RegistryJpe.class);
		if (list == null || list.isEmpty()) {
			return null;
		}
		return list.get(0); 
	}
	
	private boolean validateDateFieldNotLessThanRunDate(ConstraintValidatorContext context,
			Map<String, String[]> messageParam, JpaEntityChangeTracker ct, RegistryJpe registryJpe) {
		boolean result = true;
		
		Date runDate = dateTimeHelper.getRunDate();
		if (registryJpe.getValueDt() != null && dateTimeHelper.compareDates(registryJpe.getValueDt(), runDate) < 0) {
			MetadataAttrJpe metadataAttrJpe = getRegistryMetadataAttr(registryJpe);
			messageParam.put(DATE_CANNOT_BE_LESS_THAN_RUN_DATE, new String[] { metadataAttrJpe.getAttributeLabel() });
			context.buildConstraintViolationWithTemplate(DATE_CANNOT_BE_LESS_THAN_RUN_DATE).addConstraintViolation();
			result = false;
		}
		
		return result;
	}

	private boolean validateHasActiveRestraint(ConstraintValidatorContext context, Map<String, String[]> messageParam,
			JpaEntityChangeTracker ct, RegistryJpe registryJpe) {
		boolean result = true;
		
		if (ct.getAttributeOldValue(VALUE_S) != null) {
			String oldValue = (String) ct.getAttributeOldValue(VALUE_S);
			Map<String, Object> param = new HashMap<>();
			param.put(RESTRAINT_TYPE, oldValue);
			List<AcctRestraintJpe> list = dataService.findWithNamedQuery(DepJpeConstants.ACCT_RESTRAINT_JPE_FIND_ACTIVE_RESTRAINT_TYPE, param, AcctRestraintJpe.class);
			if (list != null && !list.isEmpty()) {
				MetadataAttrJpe metadataAttrJpe = getRegistryMetadataAttr(registryJpe);
				messageParam.put(UPDATE_NOT_ALLOWED, new String[] { metadataAttrJpe.getAttributeLabel() });
				context.buildConstraintViolationWithTemplate(UPDATE_NOT_ALLOWED).addConstraintViolation();
				result = false;
			}
		}
		
		return result;
	}

	private boolean validateRestraintTypeChanged(ConstraintValidatorContext context, Map<String, String[]> messageParam,
			JpaEntityChangeTracker ct, RegistryJpe registryJpe, String validRestraintClass) {
		boolean result = true;
		MetadataAttrJpe metadataAttrJpe = getRegistryMetadataAttr(registryJpe);
		if (DatatypeEnum.STRING.getDatatypeRefCode().equals(metadataAttrJpe.getDatatype())) {
			if (validRestraintClass != null && ct.getChangedAttributeNames().contains(VALUE_S) && ct.getAttributeOldValue(VALUE_S) != null) {
				String oldValue = (String) ct.getAttributeOldValue(VALUE_S);
				if (restraintTypeValid(oldValue, validRestraintClass)) {
					Predicate predicate = QAcctRestraintJpe.acctRestraintJpe.restraintType.eq(oldValue).and(
							QAcctRestraintJpe.acctRestraintJpe.status.eq(STATUS_A));
					List<AcctRestraintJpe> list = dataService.query(QAcctRestraintJpe.acctRestraintJpe, predicate);
					if (list != null && list.size() > 0) {
						messageParam.put(UPDATE_NOT_ALLOWED, new String[] { metadataAttrJpe.getAttributeLabel() });
						context.buildConstraintViolationWithTemplate(UPDATE_NOT_ALLOWED).addConstraintViolation();
						result = false;
					}
				}
			}
		}
		return result;
	}

	private boolean restraintTypeValid(String oldValue, String restraintClasses) {
		Predicate restraintTypeExpr = QRestraintTypeJpe.restraintTypeJpe.restraintClass.in(restraintClasses.split("\\|")).and(
				QRestraintTypeJpe.restraintTypeJpe.restraintType.eq(oldValue));
		List<RestraintTypeJpe> list = dataService.query(QRestraintTypeJpe.restraintTypeJpe, restraintTypeExpr);
		return list != null && list.size() > 0;
	}
	
	@Override
	public String[] getExtendedBdoNames() {
		return new String[] {DEPOSITS_REGISTRY};
	}
	
	@Override
	public String[] getExtendedServiceNames() {
		return new String[] {DEPOSITS_REGISTRY_SERVICE_EXT_VALIDATE};
	}
	
	@Override
	public Object afterQuery(Object arg0, Object[] arg1) {
		return null;
	}

    @Override
	public Object afterService(Object arg0, Object[] arg1) {
		return null;
	}

	@Override
	public void beforeQuery(Object[] arg0) {

	}

	@Override
	public void beforeService(Object[] arg0) {

	}
	
	private MetadataAttrJpe getRegistryMetadataAttr(MetadataValue registryJpe) {
		Map<String, Object> param = new HashMap<>();
		param.put(META_CODE, registryJpe.getMetaCode());
		param.put(META_TYPE2, registryJpe.getMetaType());
		param.put(ATTRIBUTE_CODE, registryJpe.getAttributeCode());
		List<MetadataAttrJpe> list = dataService.findWithNamedQuery(JpeConstants.METADATA_ATTR_JPE__FIND_METADATA_ATTR, param, MetadataAttrJpe.class);
		if (list != null && list.size() > 0) {
			return list.get(0);
		} else {
			return null;
		}
    }
	
	public Set<ConstraintViolation<RegistryJpe>> validateList(List<RegistryJpe> registryList) {
		final Set<ConstraintViolation<RegistryJpe>> constraintViolations = new HashSet<>();
		if (registryList != null && registryList.size() > 0) {
			Map<String, Number> priorityMap = new HashMap<>();
			Map<String, RegistryJpe> periodFreqMap = new HashMap<>();
			for (RegistryJpe registryJpe : registryList) {
				if (registryJpe != null && META_TYPE.equals(registryJpe.getMetaType()) && DEPOSITS_REGISTRY.equals(registryJpe.getMetaCode())
						&& registryJpe.getAttributeCode() != null) {
					if (registryJpe.getAttributeCode().matches(ATTR_CODES_FOR_VALIDATION4)) {
						priorityMap.put(registryJpe.getAttributeCode(), registryJpe.getValueN());
					} else if (registryJpe.getAttributeCode().matches(ATTR_CODES_FOR_VALIDATION7)) {
						periodFreqMap.put(registryJpe.getAttributeCode(), registryJpe);
					}
				}		
			}
			
			validatePriorityFieldsUniqueness(constraintViolations, priorityMap);
			validatePeriodFreqFields(constraintViolations, periodFreqMap);
		}
		return constraintViolations;
	}

	private void validatePeriodFreqFields(Set<ConstraintViolation<RegistryJpe>> constraintViolations,
			Map<String, RegistryJpe> periodFreqMap) {
		
		RegistryJpe capStmtPeriodFreqJpe = periodFreqMap.get("capStmtPeriodFreq");
		if (capStmtPeriodFreqJpe == null) {
			capStmtPeriodFreqJpe = registryRepository.find(DEPOSITS_REGISTRY, "capStmtPeriodFreq");
		}
		
		RegistryJpe nextStmtDateJpe = periodFreqMap.get(NEXT_STMT_DATE);
		if (nextStmtDateJpe == null) {
			nextStmtDateJpe = registryRepository.find(DEPOSITS_REGISTRY, NEXT_STMT_DATE);
		}
		
		MetadataAttrJpe metadataAttrJpe1 = getRegistryMetadataAttr(capStmtPeriodFreqJpe.getMetaCode(), capStmtPeriodFreqJpe.getAttributeCode());
		MetadataAttrJpe metadataAttrJpe2 = getRegistryMetadataAttr(nextStmtDateJpe.getMetaCode(), nextStmtDateJpe.getAttributeCode());
		if (StringUtils.isNotBlank(capStmtPeriodFreqJpe.getValueS()) && nextStmtDateJpe.getValueDt() == null) {
			constraintViolations.add(createConstraintViolation(capStmtPeriodFreqJpe.getValueS(), CANNOT_BE_NULL_WHEN_ANOTHER_FIELD_IS_NOT,
					new Object[] { metadataAttrJpe1.getAttributeLabel(), metadataAttrJpe2.getAttributeLabel() }));
		}
		
		if (StringUtils.isBlank(capStmtPeriodFreqJpe.getValueS()) && nextStmtDateJpe.getValueDt() != null) {
			constraintViolations.add(createConstraintViolation(nextStmtDateJpe.getValueDt(), CANNOT_BE_NULL_WHEN_ANOTHER_FIELD_IS_NOT,
					new Object[] { metadataAttrJpe2.getAttributeLabel(), metadataAttrJpe1.getAttributeLabel() }));
		}
		
	}

	private boolean validateRegistryMustNotMatchRegistryValue(ConstraintValidatorContext context, Map<String, String[]> messageParam,
			JpaEntityChangeTracker ct, RegistryJpe jpe, RegistryJpe jpe2) {
		boolean result = true;
		if (jpe != null && jpe2 != null && StringUtils.isNotBlank(jpe.getValueS()) && jpe.getValueS().equals(jpe2.getValueS())) {
			MetadataAttrJpe metadataAttrJpe1 = getRegistryMetadataAttr(jpe.getMetaCode(), jpe.getAttributeCode());
			MetadataAttrJpe metadataAttrJpe2 = getRegistryMetadataAttr(jpe2.getMetaCode(), jpe2.getAttributeCode());
			messageParam.put(MUST_NOT_BE_EQUAL_TO, new String[] { metadataAttrJpe1.getAttributeLabel(), metadataAttrJpe2.getAttributeLabel(), jpe2.getMetaCode() });
			context.buildConstraintViolationWithTemplate(MUST_NOT_BE_EQUAL_TO).addConstraintViolation();
			result = false;
		}
		return result;
	}

	private void validatePriorityFieldsUniqueness(final Set<ConstraintViolation<RegistryJpe>> constraintViolations,
			Map<String, Number> priorityMap) {
		boolean interestPriorityExist = priorityMap.containsKey(INTEREST_PRIORITY);
		boolean feePriorityExist = priorityMap.containsKey(FEE_PRIORITY);
		boolean insurancePriorityExist = priorityMap.containsKey(INSURANCE_PRIORITY);
		boolean principalPriorityExist = priorityMap.containsKey(PRINCIPAL_PRIORITY);
		if (!interestPriorityExist) {
			RegistryJpe jpe = registryRepository.find(DEPOSITS_REGISTRY, INTEREST_PRIORITY);
			priorityMap.put(INTEREST_PRIORITY, jpe.getValueN());
		}
		if (!feePriorityExist) {
			RegistryJpe jpe = registryRepository.find(DEPOSITS_REGISTRY, FEE_PRIORITY);
			priorityMap.put(FEE_PRIORITY, jpe.getValueN());
		}
		if (!insurancePriorityExist) {
			RegistryJpe jpe = registryRepository.find(DEPOSITS_REGISTRY, INSURANCE_PRIORITY);
			priorityMap.put(INSURANCE_PRIORITY, jpe.getValueN());
		}
		if (!principalPriorityExist) {
			RegistryJpe jpe = registryRepository.find(DEPOSITS_REGISTRY, PRINCIPAL_PRIORITY);
			priorityMap.put(PRINCIPAL_PRIORITY, jpe.getValueN());
		}
		
		Set<Number> unique = new HashSet<Number>();
		for (String key : priorityMap.keySet()) {
			Number num = priorityMap.get(key);
			if (num != null) {
				if (unique.contains(num)) {
					MetadataAttrJpe metadataAttrJpe1 = getRegistryMetadataAttr(DEPOSITS_REGISTRY, INTEREST_PRIORITY);
					MetadataAttrJpe metadataAttrJpe2 = getRegistryMetadataAttr(DEPOSITS_REGISTRY, FEE_PRIORITY);
					MetadataAttrJpe metadataAttrJpe3 = getRegistryMetadataAttr(DEPOSITS_REGISTRY, INSURANCE_PRIORITY);
					MetadataAttrJpe metadataAttrJpe4 = getRegistryMetadataAttr(DEPOSITS_REGISTRY, PRINCIPAL_PRIORITY);
					constraintViolations.add(createConstraintViolation(num, PRIORITY_MUST_BE_UNIQUE,
							new Object[] { metadataAttrJpe1.getAttributeLabel(), metadataAttrJpe2.getAttributeLabel(),
									metadataAttrJpe3.getAttributeLabel(), metadataAttrJpe4.getAttributeLabel() }));
					break;
				} else {
					unique.add(num);
				}
			}
		}
	}

	private boolean validateItTranTypeValue(ConstraintValidatorContext context, Map<String, String[]> messageParam, JpaEntityChangeTracker ct, RegistryJpe registryJpe) {
		boolean isValid = true;
		List<TranDefJpe> tranDefJpeList = new ArrayList<>();

		if(registryJpe != null && IT_DR_TRAN_TYPE.equals(registryJpe.getAttributeCode())) {
			Map<String, Object> param = new HashMap<>();
			param.put("tranCode", "3122");
			param.put("crDrMaintInd", "D");
			param.put("tranType", registryJpe.getValueS());
			tranDefJpeList = dataService.findWithNamedQuery(DepJpeConstants.TRAN_DEF_JPE_LOV_FOR_FEE_SVC_CHARGE_VALIDATION, param, TranDefJpe.class);
		}

		if(registryJpe != null && IT_CR_TRAN_TYPE.equals(registryJpe.getAttributeCode())){
			Map<String, Object> param = new HashMap<>();
			param.put("tranCode", "3121");
			param.put("crDrMaintInd", "C");
			param.put("tranType", registryJpe.getValueS());
			tranDefJpeList = dataService.findWithNamedQuery(DepJpeConstants.TRAN_DEF_JPE_LOV_FOR_FEE_SVC_CHARGE_VALIDATION, param, TranDefJpe.class);
		}

		if(tranDefJpeList != null && tranDefJpeList.size() > 0) {
			isValid = true;
		} else {
			if(registryJpe != null && IT_CR_TRAN_TYPE.equals(registryJpe.getAttributeCode())) {
				isValid = false;
				messageParam.put(INVALID_IT_CR_TRAN_TYPE, new String[] { registryJpe.getAttributeCode() });
				context.buildConstraintViolationWithTemplate(INVALID_IT_CR_TRAN_TYPE).addConstraintViolation();
			} else if(registryJpe != null && IT_DR_TRAN_TYPE.equals(registryJpe.getAttributeCode())) {
				isValid = false;
				messageParam.put(INVALID_IT_DR_TRAN_TYPE, new String[] { registryJpe.getAttributeCode() });
				context.buildConstraintViolationWithTemplate(INVALID_IT_DR_TRAN_TYPE).addConstraintViolation();
			}
		}
		return isValid;
	}

	private boolean validateScTypeLatePayment(ConstraintValidatorContext context, Map<String, String[]> messageParam, JpaEntityChangeTracker ct, RegistryJpe registryJpe) {
		boolean isValid = true;
		List<ServTypeQryJpe> servTypeQryJpeList = new ArrayList<>();

		if(registryJpe != null && ATTR_CODES_FOR_VALIDATION9.equals(registryJpe.getAttributeCode()) && registryJpe.getValueS() != null) {
			Map<String, Object> param = new HashMap<>();
			param.put("scType", registryJpe.getValueS());
			servTypeQryJpeList = dataService.findWithNamedQuery(CsdJpeConstants.SERV_TYPE_QRY_JPE_SC_TYPE_LATE_PAYMENT_VALIDATION, param, ServTypeQryJpe.class);
			if(servTypeQryJpeList != null && servTypeQryJpeList.size() > 0) {
				isValid = true;
			} else {
				isValid = false;
				messageParam.put(ATTR_CODES_FOR_VALIDATION9, new String[]{registryJpe.getAttributeCode()});
				context.buildConstraintViolationWithTemplate(INVALID_SC_TYPE_LATE_PAYMT).addConstraintViolation();

			}
		}

		return isValid;
	}

	private boolean validateScRateTypeLatePayment(ConstraintValidatorContext context, Map<String, String[]> messageParam, JpaEntityChangeTracker ct, RegistryJpe registryJpe) {
		boolean isValid = true;
		List<ServRateTypeQryJpe> servRateTypeQryJpeList = new ArrayList<>();

		RegistryJpe jpe = registryRepository.find(DEPOSITS_REGISTRY, ATTR_CODES_FOR_VALIDATION9);
		Map<String, Object> params = new HashMap<>();
		params.put("scType", jpe.getValueS());

		if(registryJpe != null && ATTR_CODES_FOR_VALIDATION10.equals(registryJpe.getAttributeCode()) && registryJpe.getValueS() != null) {
			params.put("scRateType", registryJpe.getValueS());
			servRateTypeQryJpeList = dataService.findWithNamedQuery(CsdJpeConstants.SERV_RATE_TYPE_QRY_SC_RATE_TYPE_LATE_PAYMENT_VALIDATION, params, ServRateTypeQryJpe.class);
			if(servRateTypeQryJpeList != null && servRateTypeQryJpeList.size() > 0) {
				isValid = true;
			} else {
				isValid = false;
				messageParam.put(ATTR_CODES_FOR_VALIDATION10, new String[]{registryJpe.getAttributeCode()});
				context.buildConstraintViolationWithTemplate(INVALID_SC_RATE_TYPE_LATE_PAYMT).addConstraintViolation();
			}
		}

		return isValid;
	}

	private MetadataAttrJpe getRegistryMetadataAttr(String metaCode, String attrCode) {
		Map<String, Object> param = new HashMap<>();
		param.put(META_CODE, metaCode);
		param.put(META_TYPE2, META_TYPE);
		param.put(ATTRIBUTE_CODE, attrCode);
		List<MetadataAttrJpe> list = dataService.findWithNamedQuery(JpeConstants.METADATA_ATTR_JPE__FIND_METADATA_ATTR, param, MetadataAttrJpe.class);
		if (list != null && !list.isEmpty()) {
			return list.get(0);
		} else {
			return null;
		}
    }
	
	private ConstraintViolation<RegistryJpe> createConstraintViolation(final Object value, String errMessage, Object[] messageParams) {
		final String messageTempalte = errMessage.replaceAll("[\\{\\}]", "");
		final String message = messageUtils.getMessage(messageTempalte, messageParams);
		final ConstraintViolation<RegistryJpe> violation = new ConstraintViolation<RegistryJpe>() {
			@Override
			public String getMessage() {
				return message;
			}

			@Override
			public String getMessageTemplate() {
				return messageTempalte;
			}

			@Override
			public RegistryJpe getRootBean() {
				return null;
			}

			@Override
			public Class<RegistryJpe> getRootBeanClass() {
				return RegistryJpe.class;
			}

			@Override
			public Object getLeafBean() {
				return null;
			}

			@Override
			public Path getPropertyPath() {
				return null;
			}

			@Override
			public Object getInvalidValue() {
				return value;
			}

			@Override
			public ConstraintDescriptor<?> getConstraintDescriptor() {
				return null;
			}

			@Override
			public Object[] getExecutableParameters() {
				return null;
			}

			@Override
			public Object getExecutableReturnValue() {
				return null;
			}

			@Override
			public <U> U unwrap(Class<U> arg0) {
				return null;
			}
		};
		return violation;
	}
}
