package com.silverlakesymmetri.cbs.dep.svc.impl;

import com.mysema.query.types.EntityPath;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.svc.AbstractBusinessService;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.*;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.QTransferTransactionWrapperJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.TransferTransactionJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.TransferTransactionWrapperJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.id.TransferTransactionWrapperPk;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.util.DepJpeConstants;
import com.silverlakesymmetri.cbs.dep.svc.TdTransferTransactionService;
import com.silverlakesymmetri.cbs.dep.svc.TransferTransactionService;
import com.silverlakesymmetri.cbs.dep.svc.TransferTransactionWrapperService;
import com.silverlakesymmetri.cbs.dep.svc.mapper.mapping.TransferTransactionWrapperServiceMapper;
import org.odata4j.core.ImmutableMap;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class TransferTransactionWrapperServiceImpl extends
		AbstractBusinessService<TransferTransactionWrapper, TransferTransactionWrapperJpe, TransferTransactionWrapperPk>
		implements TransferTransactionWrapperService {

	private static final String T_DEPOSIT_TYPE = "T";
	private static final String TRAN_HIST_SEQ = "DEP_TRAN_HIST_S";

	@Autowired
	private TransferTransactionWrapperServiceMapper mapper;

	@Autowired
	private TransferTransactionService transferTransactionService;

	@Autowired
	private TdTransferTransactionService tdTransferTransactionService;

	@Override
	protected TransferTransactionWrapperPk getIdFromDataObjectInstance(TransferTransactionWrapper dataObject) {
		return new TransferTransactionWrapperPk(dataObject.getSeqNo());
	}

	@Override
	protected EntityPath<TransferTransactionWrapperJpe> getEntityPath() {
		return QTransferTransactionWrapperJpe.transferTransactionWrapperJpe;
	}

	@Override
	public TransferTransactionWrapper create(TransferTransactionWrapper dataObject) {
		TransferTransactionWrapperJpe jpe = jaxbSdoHelper.unwrap(dataObject);
		List<TransferTransaction> transferTransactionList = new ArrayList<>();
		for (TransferTransaction tfrList: dataObject.getTfrList()) {
			TransferTransactionJpe tfrJpe = jaxbSdoHelper.unwrap(tfrList);
			TransferTransaction transferTransaction = transferTransactionService.create(jaxbSdoHelper.wrap(tfrJpe));
			transferTransactionList.add(jaxbSdoHelper.wrap(jaxbSdoHelper.unwrap(transferTransaction)));
		}
		dataObject.setTfrList(transferTransactionList);
		return dataObject;
	}

	private boolean isTdAcct(List<String> acctNos) {
		List<String> depTypes = dataService.findWithNamedQuery(DepJpeConstants.ACCT_JPE_FIND_DEPOSIT_TYPE_WITH_ACCT_NO_IN,
				ImmutableMap.of("acctNos", acctNos), String.class);

		return depTypes.stream().anyMatch(depType -> depType.equals(T_DEPOSIT_TYPE));
	}

	public TransferTransactionWrapper preCreateValidation(TransferTransactionWrapper dataObject) {
		dataObject.setSeqNo(dataService.nextSequenceValue(TRAN_HIST_SEQ).longValue());
		int i = 0;
		for (TransferTransaction tfrRec: dataObject.getTfrList()) {
			if (i == 0) {
				tfrRec.setSeqNo(dataObject.getSeqNo());
			} else {
				tfrRec.setSeqNo(dataService.nextSequenceValue(TRAN_HIST_SEQ).longValue());
			}
			for (TransferTransactionDetail tfrDtlRec: tfrRec.getTfrDetailList()) {
				tfrDtlRec.setSeqNo(tfrRec.getSeqNo());
				tfrDtlRec.setCrSeqNo(dataService.nextSequenceValue(TRAN_HIST_SEQ).longValue());
			}
			i++;
		}
		return super.preCreateValidation(dataObject);
	}
}
