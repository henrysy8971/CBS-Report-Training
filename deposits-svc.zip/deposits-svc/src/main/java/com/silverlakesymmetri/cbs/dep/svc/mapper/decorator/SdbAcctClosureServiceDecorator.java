package com.silverlakesymmetri.cbs.dep.svc.mapper.decorator;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

import com.silverlakesymmetri.cbs.commons.xmlapi.enums.CbsXmlApiOperation;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.SdbAcctJpe;
import com.silverlakesymmetri.cbs.dep.svc.mapper.SdbAcctClosureServiceMapper;
import com.silverlakesymmetri.cbs.dep.xmlapi.DEPSDBCLOSUREAPIType;

public abstract class SdbAcctClosureServiceDecorator implements SdbAcctClosureServiceMapper {

	@Autowired
	@Qualifier("delegate")
	protected  SdbAcctClosureServiceMapper delegate;
	
	@Override
	public DEPSDBCLOSUREAPIType mapToApi(SdbAcctJpe jpe, CbsXmlApiOperation oper, Map otherInfo) {
		DEPSDBCLOSUREAPIType req = (DEPSDBCLOSUREAPIType)delegate.mapToApi(jpe, oper, otherInfo);
		return  req;
	}

	@Override
	public SdbAcctJpe mapToJpe(DEPSDBCLOSUREAPIType api, SdbAcctJpe jpe) {
		if (jpe == null){
			jpe = new SdbAcctJpe();
		}
		
		if (api == null){
			return jpe;
		}
		
		delegate.mapToJpe(api, jpe);
		return jpe;
	}
}
