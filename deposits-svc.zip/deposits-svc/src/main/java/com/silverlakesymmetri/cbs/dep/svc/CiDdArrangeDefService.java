package com.silverlakesymmetri.cbs.dep.svc;

import java.util.List;
import java.util.Map;

import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation;
import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation.ServiceOperationType;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.svc.BusinessService;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.CiDdArrangeDef;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.CiDdArrangeDefJpe;

public interface CiDdArrangeDefService extends BusinessService<CiDdArrangeDef, CiDdArrangeDefJpe> {

    public static final String SVC_OP_NAME_CIDDARRANGEDEFSERVICE_GET = "CiDdArrangeDefService.get";
    public static final String SVC_OP_NAME_CIDDARRANGEDEFSERVICE_QUERY = "CiDdArrangeDefService.query";
    public static final String SVC_OP_NAME_CIDDARRANGEDEFSERVICE_CREATE = "CiDdArrangeDefService.create";
    public static final String SVC_OP_NAME_CIDDARRANGEDEFSERVICE_UPDATE = "CiDdArrangeDefService.update";
    public static final String SVC_OP_NAME_CIDDARRANGEDEFSERVICE_DELETE = "CiDdArrangeDefService.delete";
    public static final String SVC_OP_NAME_CIDDARRANGEDEFSERVICE_FIND = "CiDdArrangeDefService.find";

    @ServiceOperation(name = SVC_OP_NAME_CIDDARRANGEDEFSERVICE_GET, type = ServiceOperationType.GET)
    public CiDdArrangeDef getByPk(String publicKey, CiDdArrangeDef reference);

    @ServiceOperation(name = SVC_OP_NAME_CIDDARRANGEDEFSERVICE_CREATE)
    public CiDdArrangeDef create(CiDdArrangeDef dataObject);

    @ServiceOperation(name = SVC_OP_NAME_CIDDARRANGEDEFSERVICE_UPDATE)
    public CiDdArrangeDef update(CiDdArrangeDef dataObject);

    @ServiceOperation(name = SVC_OP_NAME_CIDDARRANGEDEFSERVICE_QUERY)
    public List<CiDdArrangeDef> query(int offset, int resultLimit, String groupBy, String order, Map<String, Object> filters);

    @ServiceOperation(name = SVC_OP_NAME_CIDDARRANGEDEFSERVICE_DELETE)
    public boolean delete(CiDdArrangeDef dataObject);

    @ServiceOperation(name = SVC_OP_NAME_CIDDARRANGEDEFSERVICE_FIND)
    public List<CiDdArrangeDef> find(FindCriteria findCriteria, CbsHeader cbsHeader);

}
