package com.silverlakesymmetri.cbs.dep.svc.ext;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.silverlakesymmetri.cbs.col.bdo.sdo.Asset;
import com.silverlakesymmetri.cbs.col.bdo.sdo.Deposit;
import com.silverlakesymmetri.cbs.col.jpa.mapping.sdo.AssetCategorySetupJpe;
import com.silverlakesymmetri.cbs.col.jpa.mapping.sdo.AssetJpe;
import com.silverlakesymmetri.cbs.col.jpa.mapping.sdo.util.ColJpeConstants;
import com.silverlakesymmetri.cbs.commons.ext.impl.AbstractServiceExtPointImpl;
import com.silverlakesymmetri.cbs.commons.jpa.extension.JaxbSdoHelper;
import com.silverlakesymmetri.cbs.commons.jpa.service.CbsGenericDataService;
import com.silverlakesymmetri.cbs.commons.logging.CbsAppLogger;
import com.silverlakesymmetri.cbs.commons.logging.CbsAppLoggerFactory;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.AcctRestraint;
import com.silverlakesymmetri.cbs.dep.svc.AcctRestraintService;

@Service
public class DepAssetAcctRestraintUpdateServiceExtImpl extends AbstractServiceExtPointImpl {
	
	private CbsAppLogger logger = CbsAppLoggerFactory.getLogger(DepAssetAcctRestraintUpdateServiceExtImpl.class.getName());
	
	@Autowired
	private AcctRestraintService acctRestraintService;
	
	@Autowired
    protected JaxbSdoHelper jaxbSdoHelper;

	@Autowired
    protected CbsGenericDataService cbsGenericDataService;

	@Override
	public String[] getExtendedBdoNames() {
		return new String[] { "Asset" };
	}

	@Override
	public String[] getExtendedServiceNames() {
		return new String[] { "AssetService.update" };
	}

	@Override
	public Object afterService(Object result, Object[] serviceParameters) {
		if (result != null && result instanceof Asset) {
			updateAssetRestraint((Asset) result);
		}
		return result;
	}

	private void updateAssetRestraint(Asset bdo) {
		if (isAssetCategoryDeposit(bdo)) {
			Deposit d = bdo.getDepositRec();
			Map<String, Object> filters = new HashMap<>();
			filters.put("referenceNo", bdo.getAssetRefNo());
			filters.put("acctNo", d.getAccountNo());
			filters.put("pledgedAcctNo", d.getAccountNo());
			filters.put("sourceModule", "COL");
			filters.put("status", "A");
			List<AcctRestraint> arList = acctRestraintService.query(0, 1, null, null, filters);
			if (arList != null && !arList.isEmpty()) {
				AcctRestraint arBdo = arList.get(0);
				if ("DEL".equals(bdo.getStatus())) {
					acctRestraintService.delete(arBdo);
				} else {
					arBdo.getChangeSummary().beginLogging();
					arBdo.setPledgedAmt(bdo.getAssetAmt());
					arBdo.setEndDate(bdo.getEndDt());
					if (StringUtils.isBlank(arBdo.getEndDate())) {
						arBdo.setEndDate("2999-01-01");	
					}
					arBdo.getChangeSummary().endLogging();
					acctRestraintService.update(arBdo);	
				}
			} else {
				logger.warn("No Restraint to Update.");
			}
		}
	}

	private boolean isAssetCategoryDeposit(Asset bdo) {
		if (StringUtils.isNotBlank(bdo.getAssetType()) && bdo.getDepositRec() != null) {
			Map<String, Object> params = new HashMap<>();
			params.put("assetType", bdo.getAssetType());
			AssetCategorySetupJpe acJpe = cbsGenericDataService.getWithNamedQuery(ColJpeConstants.ASSET_CATEGORY_SETUP_JPE_FIND_ASSET_CATEGORY_BY_ASSET_TYPE, params, AssetCategorySetupJpe.class);
			if ("D".equals(acJpe.getAssetCategory()) && StringUtils.isNotBlank(bdo.getDepositRec().getAccountNo())) {
				return true;
			}
		}
		return false;
	}
}
;