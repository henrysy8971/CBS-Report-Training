package com.silverlakesymmetri.cbs.dep.svc.mapper.decorator;

import java.util.Map;

import org.mapstruct.Context;
import org.mapstruct.MappingTarget;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

import com.silverlakesymmetri.cbs.commons.xmlapi.enums.CbsXmlApiOperation;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.OnlineScCollectionJpe;
import com.silverlakesymmetri.cbs.dep.svc.mapper.OnlineScCollectionServiceMapper;
import com.silverlakesymmetri.cbs.dep.xmlapi.DEPFEEONLINESETTLEAPIType;

public abstract class OnlineScCollectionServiceDecorator implements OnlineScCollectionServiceMapper{
	
	@Autowired
	@Qualifier("delegate")
	protected  OnlineScCollectionServiceMapper delegate;
	
	
	@Override
	public DEPFEEONLINESETTLEAPIType mapToApi(OnlineScCollectionJpe jpe, @Context CbsXmlApiOperation oper, @Context Map otherInfo){
		
		DEPFEEONLINESETTLEAPIType req = (DEPFEEONLINESETTLEAPIType)delegate.mapToApi(jpe, oper, otherInfo);
		
		if (jpe.isPostScBatchSumYn() && jpe.isPostScUncollYn()){
			req.setFEEONLINESETTLETYPE("ALL_SC");
			return req;
		}
		
		if (jpe.isPostScBatchSumYn()){
			req.setFEEONLINESETTLETYPE("BATCH_SC");
		}
		else  if (jpe.isPostScUncollYn()){
			req.setFEEONLINESETTLETYPE("UNCOLL_SC");
		}
		return  req;
	}
	
	@Override
	public OnlineScCollectionJpe mapToJpe(DEPFEEONLINESETTLEAPIType api, @MappingTarget OnlineScCollectionJpe jpe){
				
		if (jpe == null) {
			jpe = new OnlineScCollectionJpe();
		}
		if (api == null) {
			return jpe;
		}
		jpe = delegate.mapToJpe(api, jpe);
		return jpe;		
	}
}


