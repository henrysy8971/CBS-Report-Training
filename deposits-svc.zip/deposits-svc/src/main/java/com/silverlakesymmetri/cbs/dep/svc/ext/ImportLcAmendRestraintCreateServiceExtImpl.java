package com.silverlakesymmetri.cbs.dep.svc.ext;

import com.silverlakesymmetri.cbs.commons.logging.CbsAppLogger;
import com.silverlakesymmetri.cbs.commons.logging.CbsAppLoggerFactory;
import com.silverlakesymmetri.cbs.xps.svc.util.ReleaseAcctRestraintCapable;
import org.springframework.stereotype.Service;

@Service
public class ImportLcAmendRestraintCreateServiceExtImpl extends AbstractTfnAcctRestraintServiceExtImpl implements ReleaseAcctRestraintCapable {

	private static CbsAppLogger logger = CbsAppLoggerFactory.getLogger(ImportLcAmendRestraintCreateServiceExtImpl.class.getName());
	
    @Override
    public String[] getExtendedBdoNames() {
        return new String[] { "ImportLcAmend" };
    }

    @Override
    public String[] getExtendedServiceNames() {
        return new String[] {"ImportLcAmendService.create"};
    }

    protected CbsAppLogger getLogger() {
    	return logger;
    }
}
