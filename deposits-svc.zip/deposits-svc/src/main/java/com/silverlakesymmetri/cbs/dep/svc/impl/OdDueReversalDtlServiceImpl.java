package com.silverlakesymmetri.cbs.dep.svc.impl;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mysema.query.types.EntityPath;
import com.mysema.query.types.OrderSpecifier;
import com.mysema.query.types.Predicate;
import com.mysema.query.types.expr.BooleanExpression;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.jpa.entity.ConjunctionEnumJpe;
import com.silverlakesymmetri.cbs.commons.jpa.entity.FindCriteriaJpe;
import com.silverlakesymmetri.cbs.commons.jpa.entity.ViewCriteriaItemJpe;
import com.silverlakesymmetri.cbs.commons.jpa.entity.ViewCriteriaJpe;
import com.silverlakesymmetri.cbs.commons.jpa.entity.ViewCriteriaRowJpe;
import com.silverlakesymmetri.cbs.commons.svc.AbstractXmlApiBusinessService;
import com.silverlakesymmetri.cbs.commons.svc.BusinessObjectValidationCapable;
import com.silverlakesymmetri.cbs.commons.xmlapi.enums.CbsXmlApiOperation;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.OdDueReversalDtl;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.OdRepositoryPaymt;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.AcctJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.OdDueReversalDtlJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.OdDueTypeQryJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.QOdDueReversalDtlJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.QOdDueTypeQryJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.id.OdDueReversalDtlPk;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.util.DepJpeConstants;
import com.silverlakesymmetri.cbs.dep.svc.OdDueReversalDtlService;
import com.silverlakesymmetri.cbs.dep.svc.mapper.mapping.OdDueReversalDtlToDEPODUNPDDUEREVERSALAPITypeMapper;
import com.silverlakesymmetri.cbs.dep.xmlapi.DEPODUNPDDUEREVERSALAPIType;

@Service
public class OdDueReversalDtlServiceImpl extends AbstractXmlApiBusinessService<OdDueReversalDtl, OdDueReversalDtlJpe, OdDueReversalDtlPk, DEPODUNPDDUEREVERSALAPIType, DEPODUNPDDUEREVERSALAPIType> implements OdDueReversalDtlService, BusinessObjectValidationCapable<OdDueReversalDtl> {

	@Autowired
	private OdDueReversalDtlToDEPODUNPDDUEREVERSALAPITypeMapper mapper;
	
	@Override
	public Long count(FindCriteria findCriteria, CbsHeader cbsHeader) {
		FindCriteriaJpe fcJpe = customFind(findCriteria);
		return dataService.getRowCount(OdDueReversalDtlJpe.class, fcJpe);
	}

//	@Override
//	public OdDueReversalDtl create(OdDueReversalDtl arg0) {
//		// TODO Auto-generated method stub
//		return super.create(arg0);
//	}

//	@Override
//	public boolean delete(OdDueReversalDtl arg0) {
//		// TODO Auto-generated method stub
//		return super.delete(arg0);
//	}

	private List<OdDueReversalDtl> updateBalanceDue(List<OdDueReversalDtl> list) {
		if (list != null && list.size() > 0) {
			String ccy = null;
			for (OdDueReversalDtl bdo : list) {
				if (ccy != null) {
					bdo.setCcy(ccy);
				}
				computeBalanceDue(bdo);
				if (ccy == null) {
					ccy = bdo.getCcy();
				}
			}
		}
		return list;
	}

	private AcctJpe getAcct(String acctNo) {
		AcctJpe acctJpe = null;
		if (acctNo != null) {
			Map<String, Object> param = new HashMap<String, Object>();
			param.put("acctNo", acctNo);
			acctJpe = dataService.getWithNamedQuery(DepJpeConstants.ACCT_JPE_FIND_BY_ACCTNO, param, AcctJpe.class);
		}
		return acctJpe;
	}

	private void computeBalanceDue(OdDueReversalDtl bdo) {
		Double dueAmt = bdo.getDueAmt();
		if (dueAmt == null) {
			dueAmt = 0d;
		}
		Double paidAmt = bdo.getPaidAmt();
		if (paidAmt == null) {
			paidAmt = 0d;
		}
		Double balanceDue = dueAmt - paidAmt;
		bdo.setBalanceDue(balanceDue);
		if (bdo.getCcy() == null) {
			AcctJpe acctJpe = getAcct(bdo.getAcctNo());
			bdo.setCcy(acctJpe.getCcy());
		}
	}
	
	private void computeTotalTranAmt(OdDueReversalDtl bdo) {
		Double totalTranAmt = 0d;
		if (bdo.getOdRepositoryPaymtList() != null && bdo.getOdRepositoryPaymtList().size() > 0) {
			for (OdRepositoryPaymt paymtBdo : bdo.getOdRepositoryPaymtList()) {
				if (paymtBdo.getTranAmt() != null) {
					totalTranAmt += paymtBdo.getTranAmt(); 
				}
				paymtBdo.setCcy(bdo.getCcy());
			}
		}
		bdo.setTotalTranAmt(totalTranAmt);
	}
	
	@Override
	public List<OdDueReversalDtl> find(FindCriteria fc, CbsHeader arg1) {
		FindCriteriaJpe fcJpe = customFind(fc);
		FindCriteria fcBdo = jaxbSdoHelper.wrap(fcJpe, FindCriteria.class);
		return updateBalanceDue(super.find(fcBdo, arg1));
	}

	private FindCriteriaJpe customFind(FindCriteria findCriteria) {
		FindCriteriaJpe fc = null;
		if (findCriteria == null) {
			fc = new FindCriteriaJpe();
	        ViewCriteriaJpe rootViewCriteria = new ViewCriteriaJpe();
	        fc.setFilter(rootViewCriteria);
		} else {
			fc = jaxbSdoHelper.unwrap(findCriteria, true);
		}
		if (fc != null) {
			if (fc.getFilter() == null) {
				fc.setFilter(new ViewCriteriaJpe());
				fc.getFilter().setConjunction(ConjunctionEnumJpe.AND);
			}
			
			List<Object> dueTypeList = new ArrayList<Object>();
			dueTypeList.addAll(retrieveDueTypeForReversalList());
			
			ViewCriteriaItemJpe vci1 = new ViewCriteriaItemJpe();
			vci1.setAttribute("dueType");
	        vci1.setOperator("IN");
	        vci1.setValue(dueTypeList);
	        vci1.setConjunction(ConjunctionEnumJpe.AND);
	        vci1.setUpperCaseCompareYn(false);
	        
	        ViewCriteriaItemJpe vci2 = new ViewCriteriaItemJpe();
			vci2.setAttribute("writeoffInd");
	        vci2.setOperator("!=");
	        vci2.setValue(Arrays.asList((Object) "Y"));
	        vci2.setConjunction(ConjunctionEnumJpe.AND);
	        vci2.setUpperCaseCompareYn(false);
	        
	        ViewCriteriaItemJpe vci3 = new ViewCriteriaItemJpe();
	        vci3.setAttribute("status");
	        vci3.setOperator("=");
	        vci3.setValue(Arrays.asList((Object) "N"));
	        vci3.setConjunction(ConjunctionEnumJpe.AND);
	        vci3.setUpperCaseCompareYn(false);
	        
			List<ViewCriteriaRowJpe> rowList = fc.getFilter().getGroup();
			if (rowList.isEmpty()) {
				ViewCriteriaRowJpe vcrJpe = new ViewCriteriaRowJpe();
				vcrJpe.getItem().add(vci1);
				vcrJpe.getItem().add(vci2);
				vcrJpe.getItem().add(vci3);
				rowList.add(vcrJpe);
			} else {
				rowList.get(0).getItem().add(vci1);
				rowList.get(0).getItem().add(vci2);
				rowList.get(0).getItem().add(vci3);
			}
		}
		return fc;
	}

	@Override
	public OdDueReversalDtl getByPk(String publicKey, OdDueReversalDtl reference) {
		OdDueReversalDtl bdo = super.getByPk(publicKey, reference);
		computeBalanceDue(bdo);
		computeTotalTranAmt(bdo);
		return bdo;
	}

	@Override
	protected EntityPath<OdDueReversalDtlJpe> getEntityPath() {
		// TODO Auto-generated method stub
		return QOdDueReversalDtlJpe.odDueReversalDtlJpe;
	}

	@Override
	protected OdDueReversalDtlPk getIdFromDataObjectInstance(OdDueReversalDtl arg0) {
		OdDueReversalDtlJpe jpe = jaxbSdoHelper.unwrap(arg0);
		return new OdDueReversalDtlPk(jpe.getDueDate(), jpe.getSeqNo());
	}

	@Override
	public List<OdDueReversalDtl> query(int offset, int resultLimit, String groupBy, String order,
			Map<String, Object> filters) {
		final List<OrderSpecifier<?>> orders = getOrderSpecifier(QOdDueReversalDtlJpe.odDueReversalDtlJpe, null, order);
		Predicate predicate = convertMapToPredicateForReversal(filters);
		return updateBalanceDue(super.query(QOdDueReversalDtlJpe.odDueReversalDtlJpe, offset, resultLimit, predicate, orders));
	}
	
	private Predicate convertMapToPredicateForReversal(Map<String, Object> filters) {
		Predicate predicate = convertMapToPredicate(QOdDueReversalDtlJpe.odDueReversalDtlJpe, filters);
		List<String> dueTypeList = retrieveDueTypeForReversalList();
		
		BooleanExpression booleanExpr1 = QOdDueReversalDtlJpe.odDueReversalDtlJpe.writeoffInd.ne("Y");
		BooleanExpression booleanExpr2 = QOdDueReversalDtlJpe.odDueReversalDtlJpe.status.eq("N");
		BooleanExpression booleanExpr3 = QOdDueReversalDtlJpe.odDueReversalDtlJpe.dueType.in(dueTypeList);
		BooleanExpression booleanExpr = booleanExpr1.and(booleanExpr2).and(booleanExpr3);
		
		if (predicate != null) {
			predicate = ((BooleanExpression) predicate).and(booleanExpr);	
		} else {
			predicate = booleanExpr;
		}
		return predicate;
	}
	
	private List<String> retrieveDueTypeForReversalList() {
		List<String> resultList = new ArrayList<>();
		Predicate p = QOdDueTypeQryJpe.odDueTypeQryJpe.allowReversal.eq("Y");
		List<OdDueTypeQryJpe> jpeList =  dataService.query(QOdDueTypeQryJpe.odDueTypeQryJpe, p);
		if (jpeList != null && jpeList.size() > 0) {
			for (OdDueTypeQryJpe jpe : jpeList) {
				resultList.add(jpe.getDueType());
			}
		}
		return resultList;
	}

	@Override
	public OdDueReversalDtl update(OdDueReversalDtl arg0) {
		// TODO Auto-generated method stub
		return super.update(arg0);
	}

	@Override
	protected Class<DEPODUNPDDUEREVERSALAPIType> getXmlApiResponseClass() {
		return DEPODUNPDDUEREVERSALAPIType.class;
	}

	@Override
	protected List<OdDueReversalDtl> processXmlApiListRs(OdDueReversalDtl arg0, DEPODUNPDDUEREVERSALAPIType arg1) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	protected OdDueReversalDtl processXmlApiRs(OdDueReversalDtl dataObject, DEPODUNPDDUEREVERSALAPIType xmlApiRs) {
		if (xmlApiRs != null && xmlApiRs.getDUEDATE() != null && xmlApiRs.getSEQNO() != null) {
			OdDueReversalDtlJpe jpe = mapper.apiTypeToJpe(xmlApiRs);
			OdDueReversalDtlPk pk = new OdDueReversalDtlPk(jpe.getDueDate(), jpe.getSeqNo());
			OdDueReversalDtlJpe updatedJpe = dataService.find(OdDueReversalDtlJpe.class, pk);
			OdDueReversalDtl resultBdo = jaxbSdoHelper.wrap(updatedJpe, OdDueReversalDtl.class);
			computeBalanceDue(resultBdo);
			computeTotalTranAmt(resultBdo);
			return jaxbSdoHelper.wrap(updatedJpe, OdDueReversalDtl.class);
		}

		return dataObject;
	}

	@Override
	protected DEPODUNPDDUEREVERSALAPIType transformBdoToXmlApiRqCreate(OdDueReversalDtl dataObject) {
		return transformOdDueReversalDtlToDEPODUNPDDUEREVERSALAPIType(dataObject, CbsXmlApiOperation.INSERT);
	}

	private DEPODUNPDDUEREVERSALAPIType transformOdDueReversalDtlToDEPODUNPDDUEREVERSALAPIType(
			OdDueReversalDtl dataObject, CbsXmlApiOperation oper) {
		OdDueReversalDtlJpe jpe = jaxbSdoHelper.unwrap(dataObject, OdDueReversalDtlJpe.class);
		DEPODUNPDDUEREVERSALAPIType xmlApiRq = mapper.jpeToApiType(jpe);
		xmlApiRq.setREVWRITEOFFIND("R");
		xmlApiRq.setOPERATION(oper.getOperation());
		super.setTechColsFromDataObject(dataObject, xmlApiRq);
		return xmlApiRq;
	}

	@Override
	protected DEPODUNPDDUEREVERSALAPIType transformBdoToXmlApiRqDelete(OdDueReversalDtl dataObject) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	protected DEPODUNPDDUEREVERSALAPIType transformBdoToXmlApiRqUpdate(OdDueReversalDtl dataObject) {
		return transformBdoToXmlApiRqCreate(dataObject);
	}

	
}
