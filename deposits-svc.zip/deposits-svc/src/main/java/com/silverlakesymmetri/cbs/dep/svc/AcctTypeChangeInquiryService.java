package com.silverlakesymmetri.cbs.dep.svc;

import java.util.List;
import java.util.Map;

import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.svc.BusinessService;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.AcctTypeChangeInquiry;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.AcctTypeChangeInquiryJpe;

public interface AcctTypeChangeInquiryService extends BusinessService<AcctTypeChangeInquiry, AcctTypeChangeInquiryJpe> {

	public static final String SVC_OP_NAME_ACCTTYPECHANGEINQUIRYSERVICE_GET = "AcctTypeChangeInquiryService.get";
	public static final String SVC_OP_NAME_ACCTTYPECHANGEINQUIRYSERVICE_FIND = "AcctTypeChangeInquiryService.find";
	public static final String SVC_OP_NAME_ACCTTYPECHANGEINQUIRYSERVICE_QUERY = "AcctTypeChangeInquiryService.query";

	@ServiceOperation(name = SVC_OP_NAME_ACCTTYPECHANGEINQUIRYSERVICE_GET, type = ServiceOperation.ServiceOperationType.GET)
	public AcctTypeChangeInquiry getByPk(String publicKey, AcctTypeChangeInquiry reference);

	@ServiceOperation(name = SVC_OP_NAME_ACCTTYPECHANGEINQUIRYSERVICE_QUERY)
	public List<AcctTypeChangeInquiry> query(int offset, int resultLimit, String groupBy, String order,
			Map<String, Object> filters);

	@ServiceOperation(name = SVC_OP_NAME_ACCTTYPECHANGEINQUIRYSERVICE_FIND)
	public List<AcctTypeChangeInquiry> find(FindCriteria findCriteria, CbsHeader cbsHeader);

}
