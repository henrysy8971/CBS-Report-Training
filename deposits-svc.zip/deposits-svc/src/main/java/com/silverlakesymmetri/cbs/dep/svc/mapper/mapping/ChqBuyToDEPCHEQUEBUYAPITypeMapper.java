package com.silverlakesymmetri.cbs.dep.svc.mapper.mapping;

import com.silverlakesymmetri.cbs.commons.jpa.util.DateTimeHelper;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.ChqBuyBeneficiaryDetailsJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.ChqBuyDdBnkJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.ChqBuyJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.ChqBuyTranJpe;
import com.silverlakesymmetri.cbs.dep.svc.mapper.decorator.ChqBuyToDEPCHEQUEBUYAPITypeDecorator;
import com.silverlakesymmetri.cbs.dep.xmlapi.DEPCHEQUEBUYAPIType;
import com.silverlakesymmetri.cbs.dep.xmlapi.DEPCHQBUYBENEFINTType;
import com.silverlakesymmetri.cbs.dep.xmlapi.DEPCHQBUYDDINTType;
import com.silverlakesymmetri.cbs.dep.xmlapi.DEPCHQBUYSELLPYMTINTType;
import org.mapstruct.*;

/**
 * Created by Emerson.Sanchez on 20/11/2019.
 */
@Mapper(uses = { DateTimeHelper.class })
@DecoratedWith(ChqBuyToDEPCHEQUEBUYAPITypeDecorator.class)
public interface ChqBuyToDEPCHEQUEBUYAPITypeMapper {

    @Mappings({
            @Mapping(source = "grpCiSeqNoBuy", target = "GRPCISEQNO"),
            @Mapping(source = "chequeType", target = "CHEQUETYPE"),
            @Mapping(source = "procType", target = "PROCTYPE"),
            @Mapping(source = "ccy", target = "CCY"),
            @Mapping(source = "denomGrp", target = "DENOMGROUP"),
            @Mapping(source = "narrative", target = "NARRATIVE"),
            @Mapping(source = "narrative", target = "REMARKS"),
            @Mapping(source = "branch", target = "TRANBRANCH"),
            @Mapping(source = "chqBuyTranList", target = "DEPCHQBUYPYMTINDTLS.DEPCHQBUYSELLPYMTINT")
    })
    DEPCHEQUEBUYAPIType jpeToApiType(ChqBuyJpe jpe);

    @Mappings({
            @Mapping(source = "beneficiaryName", target = "BENEFNAME"),
            @Mapping(source = "beneficiaryAddress", target = "BENEFADDRESS"),
            @Mapping(source = "beneficiaryCity", target = "BENEFCITY"),
            @Mapping(source = "beneficiaryContactDtl", target = "BENEFCONTACTDTL"),
            @Mapping(source = "beneficiaryContactRefNo", target = "BENEFCONTACTREFNO"),
            @Mapping(source = "beneficiaryCountry", target = "BENEFCOUNTRY"),
            @Mapping(source = "beneficiaryPostalCode", target = "BENEFPOSTALCODE"),
            @Mapping(source = "beneficiaryState", target = "BENEFSTATE")
    })
    DEPCHQBUYBENEFINTType  jpeToBeneficiaryApiType (ChqBuyBeneficiaryDetailsJpe jpe);

    @Mappings({
            @Mapping(source = "bank", target = "AGENTBANK"),
            @Mapping(source = "branch", target = "AGENTBRANCH"),
            @Mapping(source = "prefix", target = "PREFIX"),
            @Mapping(source = "refund", target = "REFUNDIND"),
            @Mapping(source = "startChequeNo", target = "STARTNO"),
            @Mapping(source = "endChequeNo", target = "ENDNO")
    })
    DEPCHQBUYDDINTType jpeToDdIntType (ChqBuyDdBnkJpe jpe);

    @Mappings({
            @Mapping(source = "acctNo", target = "ACCTNO"),
            @Mapping(source = "reference", target = "CHEQUENO"),
            @Mapping(source = "crossRate", target = "CROSSRATE"),
            @Mapping(source = "crossRate", target = "OVCROSSRATE"),
            @Mapping(source = "equivAmt", target = "EQUIVAMT"),
            @Mapping(source = "pymtMode", target = "PYMTMODE"),
            @Mapping(source = "tranAmt", target = "TRANAMT"),
            @Mapping(source = "ccy", target = "TRANCCY"),
            @Mapping(source = "tranType", target = "TRANTYPE"),
            @Mapping(source = "settleCcy", target = "ACCTCCY")
    })
    DEPCHQBUYSELLPYMTINTType jpeToSellPaymentType (ChqBuyTranJpe jpe);
}
