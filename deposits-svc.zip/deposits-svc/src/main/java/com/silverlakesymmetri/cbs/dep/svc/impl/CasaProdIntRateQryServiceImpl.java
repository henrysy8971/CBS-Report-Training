package com.silverlakesymmetri.cbs.dep.svc.impl;

import com.mysema.query.types.EntityPath;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.svc.AbstractBusinessService;
import com.silverlakesymmetri.cbs.csd.jpa.mapping.sdo.CurrencyJpe;
import com.silverlakesymmetri.cbs.csd.jpa.mapping.sdo.util.CsdJpeConstants;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.CasaProdIntRateQry;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.CasaProdIntRateQryJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.QCasaProdIntRateQryJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.id.CasaProdIntRateQryPk;
import com.silverlakesymmetri.cbs.dep.svc.CasaProdIntRateQryService;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;


@Service
@Transactional
public class CasaProdIntRateQryServiceImpl extends AbstractBusinessService<CasaProdIntRateQry, CasaProdIntRateQryJpe, CasaProdIntRateQryPk> implements CasaProdIntRateQryService {

    @Override
    protected CasaProdIntRateQryPk getIdFromDataObjectInstance(CasaProdIntRateQry dataObject) {
        return new CasaProdIntRateQryPk(dataObject.getAcctType(), dataObject.getCcy(), dataObject.getCrIntType(), dataObject.getIntBal());
    }

    @Override
    protected EntityPath<CasaProdIntRateQryJpe> getEntityPath() {
        return QCasaProdIntRateQryJpe.casaProdIntRateQryJpe;
    }

    @Override
    public CasaProdIntRateQry get(CasaProdIntRateQry objectInstanceIdentifier) {
        return super.get(objectInstanceIdentifier);
    }

    @Override
    public CasaProdIntRateQry create(CasaProdIntRateQry objectInstanceIdentifier) {
        return super.create(objectInstanceIdentifier);
    }

    @Override
    public CasaProdIntRateQry update(CasaProdIntRateQry objectInstanceIdentifier) {
        return super.update(objectInstanceIdentifier);
    }

    @Override
    public boolean delete(CasaProdIntRateQry objectInstanceIdentifier) {
        return super.delete(objectInstanceIdentifier);
    }

    @Override
    public List<CasaProdIntRateQry> query(int offset, int resultLimit, String groupBy, String order, Map<String, Object> filters) {
        List<CasaProdIntRateQry> qryList = super.query(offset, resultLimit, groupBy, order, filters);

        if(qryList != null) {
            List<CasaProdIntRateQry> prodIntRateQries = qryList.stream().map(qryObj -> {
                Map<String, Object> ccyParam = new HashMap<String, Object>();
                ccyParam.put("ccy", qryObj.getCcy());
                CurrencyJpe currency = dataService
                        .getWithNamedQuery(CsdJpeConstants.CURRENCY_JPE_FIND_CURRENCY_BY_CCY, ccyParam, CurrencyJpe.class);
                if (currency != null) {
                    qryObj.setDeciPlaces(currency.getDeciPlaces());
                }
                return qryObj;
            }).collect(Collectors.toList());

            return prodIntRateQries;
        }
        return null;
    }

    @Override
    public List<CasaProdIntRateQry> find(FindCriteria findCriteria, CbsHeader cbsHeader) {
        return super.find(findCriteria, cbsHeader);
    }

    @Override
    public CasaProdIntRateQry getByPk(String publicKey, CasaProdIntRateQry reference) {
        return super.getByPk(publicKey, reference);
    }
}
