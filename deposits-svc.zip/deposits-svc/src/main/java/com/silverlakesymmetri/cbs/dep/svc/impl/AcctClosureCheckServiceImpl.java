package com.silverlakesymmetri.cbs.dep.svc.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.mysema.query.types.EntityPath;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.svc.AbstractXmlApiBusinessService;
import com.silverlakesymmetri.cbs.commons.xmlapi.enums.CbsXmlApiOperation;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.AcctClosure;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.AcctClosureCheck;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.AcctClosureCheckJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.AcctClosureJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.QAcctClosureCheckJpe;
import com.silverlakesymmetri.cbs.dep.svc.AcctClosureCheckService;
import com.silverlakesymmetri.cbs.dep.svc.mapper.AcctClosureCheckServiceMapper;
import com.silverlakesymmetri.cbs.dep.svc.mapper.AcctClosureServiceMapper;
import com.silverlakesymmetri.cbs.dep.svc.util.AcctHelper;
import com.silverlakesymmetri.cbs.dep.xmlapi.DEPACCTCLOSUREAPIType;
import java.util.Collections;

@Service
public class AcctClosureCheckServiceImpl extends AbstractXmlApiBusinessService<AcctClosureCheck, AcctClosureCheckJpe, String, DEPACCTCLOSUREAPIType, DEPACCTCLOSUREAPIType> implements AcctClosureCheckService {

    private static final String ACCT_NO = "acctNo";
    private static final String QUERY_TYPE = "queryType";
    
    @Autowired
    AcctClosureCheckServiceMapper rsMapper;

    @Autowired
    AcctClosureServiceMapper rqMapper;
    
    @Autowired
    private AcctHelper acctHelper;
    
    @Override
    public List<AcctClosureCheck> query(int offset, int resultLimit, String groupBy, String order, Map<String, Object> filters) {
        Long internalKey = null;
        String acctNo = null;
        String queryType = null;
        
        if (filters.containsKey(ACCT_NO)) {
            acctNo = (String) filters.get(ACCT_NO);
            internalKey = acctHelper.getInternalKeyByAcctNo(acctNo);
        }
        if (filters.containsKey(QUERY_TYPE)) {
            queryType = (String) filters.get(QUERY_TYPE);
        }
        if (acctNo == null || internalKey == null) {
            return Collections.emptyList();
        }
        return super.queryDataObjects(queryAcctClosureCheck(acctNo, internalKey, queryType)); 
    }
    
    private DEPACCTCLOSUREAPIType queryAcctClosureCheck(String acctNo, Long internalKey, String queryType) {
        AcctClosure dataObject = jaxbSdoHelper.createSdoInstance(AcctClosure.class);
        dataObject.setAcctNo(acctNo);
        dataObject.setInternalKey(internalKey);
        
        AcctClosureJpe jpe = jaxbSdoHelper.unwrap(dataObject);
        DEPACCTCLOSUREAPIType apiType = rqMapper.mapToApi(jpe, CbsXmlApiOperation.QUERY);
        super.setTechColsFromDataObject(dataObject, apiType);
        apiType.setQUERYTYPE(queryType);
        return apiType;
    }
    
    @Override
    protected DEPACCTCLOSUREAPIType transformBdoToXmlApiRqCreate(AcctClosureCheck dataObject) {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    protected DEPACCTCLOSUREAPIType transformBdoToXmlApiRqUpdate(AcctClosureCheck dataObject) {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    protected DEPACCTCLOSUREAPIType transformBdoToXmlApiRqDelete(AcctClosureCheck dataObject) {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    protected AcctClosureCheck processXmlApiRs(AcctClosureCheck dataObject, DEPACCTCLOSUREAPIType xmlApiRs) {
//		AcctClosureCheck rs = jaxbSdoHelper.createSdoInstance(AcctClosureCheck.class);
        return null;
    }

    @Override
    protected Class<DEPACCTCLOSUREAPIType> getXmlApiResponseClass() {
        return DEPACCTCLOSUREAPIType.class;
    }

    @Override
    protected String getIdFromDataObjectInstance(AcctClosureCheck dataObject) {
        return dataObject.getRelationCheckDtls();
    }

    @Override
    protected EntityPath<AcctClosureCheckJpe> getEntityPath() {
        // TODO Auto-generated method stub
        return QAcctClosureCheckJpe.acctClosureCheckJpe;
    }

    public List<AcctClosureCheck> findAll(String acctNo, CbsHeader cbsHeader) {
        return super.queryDataObjects(mapToDEPACCTCLOSUREAPIType(acctNo));
    }

    private DEPACCTCLOSUREAPIType mapToDEPACCTCLOSUREAPIType(String acctNo) {

        AcctClosure bdo = jaxbSdoHelper.createSdoInstance(AcctClosure.class);
        bdo.setAcctNo(acctNo);
        if (StringUtils.isNotBlank(acctNo)){
        	bdo.setInternalKey(acctHelper.getInternalKeyByAcctNo(acctNo));
        }
        AcctClosureJpe jpe = jaxbSdoHelper.unwrap(bdo);
        DEPACCTCLOSUREAPIType apiType = rqMapper.mapToApi(jpe, CbsXmlApiOperation.QUERY);
        super.setTechColsFromDataObject(bdo, apiType);
        return apiType;
    }

    @Override
    protected List<AcctClosureCheck> processXmlApiListRs(AcctClosureCheck dataObject, DEPACCTCLOSUREAPIType xmlApiRs) {

        if (xmlApiRs.getDEPACCTCLOSECHECKLIST() == null
                || xmlApiRs.getDEPACCTCLOSECHECKLIST().getDEPACCTCLOSECHECKT() == null
                || xmlApiRs.getDEPACCTCLOSECHECKLIST().getDEPACCTCLOSECHECKT().isEmpty()) {
            return null;
        }

        List<AcctClosureCheckJpe> list = rsMapper.mapToJpe(xmlApiRs.getDEPACCTCLOSECHECKLIST().getDEPACCTCLOSECHECKT());
        List<AcctClosureCheck> rs = new ArrayList<AcctClosureCheck>();
        for (AcctClosureCheckJpe jpe : list) {
            rs.add((AcctClosureCheck) jaxbSdoHelper.wrap(jpe));
        }
        return rs;
    }
}
