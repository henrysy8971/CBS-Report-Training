package com.silverlakesymmetri.cbs.dep.svc.mapper.decorator;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

import com.silverlakesymmetri.cbs.commons.xmlapi.enums.CbsXmlApiOperation;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.OdTmpLimitJpe;
import com.silverlakesymmetri.cbs.dep.svc.mapper.OdTmpLimitServiceMapper;
import com.silverlakesymmetri.cbs.dep.xmlapi.DEPODTMPLIMITAPIType;

public abstract class OdTmpLimitServiceDecorator implements OdTmpLimitServiceMapper {

	@Autowired
	@Qualifier("delegate")
	protected OdTmpLimitServiceMapper delegate;

	@SuppressWarnings("rawtypes")
	@Override
	public DEPODTMPLIMITAPIType mapToApi(OdTmpLimitJpe jpe, CbsXmlApiOperation oper, Map otherInfo) {
		DEPODTMPLIMITAPIType req = (DEPODTMPLIMITAPIType) delegate.mapToApi(jpe, oper, otherInfo);
		return req;
	}

	@Override
	public OdTmpLimitJpe mapToJpe(DEPODTMPLIMITAPIType api, OdTmpLimitJpe jpe) {
		if (jpe == null) {
			jpe = new OdTmpLimitJpe();
		}
		if (api == null) {
			return jpe;
		}
		delegate.mapToJpe(api, jpe);
		return jpe;
	}

}
