package com.silverlakesymmetri.cbs.dep.svc;

import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.svc.BusinessService;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.FinTranMsgsQry;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.FinTranMsgsQryJpe;

import java.util.List;
import java.util.Map;

public interface FinTranMsgsQryService extends BusinessService<FinTranMsgsQry, FinTranMsgsQryJpe> {

    public static final String SVC_OP_NAME_FINTRANMSGSQRYSERVICE_GET = "FinTranMsgsQryService.get";
    public static final String SVC_OP_NAME_FINTRANMSGSQRYSERVICE_FIND = "FinTranMsgsQryService.find";
    public static final String SVC_OP_NAME_FINTRANMSGSQRYSERVICE_QUERY = "FinTranMsgsQryService.query";
    public static final String SVC_OP_NAME_FINTRANMSGSQRYSERVICE_EXECUTE = "FinTranMsgsQryService.findFinTranRestraintsQry";

    @ServiceOperation(name = SVC_OP_NAME_FINTRANMSGSQRYSERVICE_GET, type = ServiceOperation.ServiceOperationType.GET)
    public FinTranMsgsQry getByPk(String publicKey, FinTranMsgsQry reference);

    @ServiceOperation(name = SVC_OP_NAME_FINTRANMSGSQRYSERVICE_FIND)
    public List<FinTranMsgsQry> find(FindCriteria findCriteria, CbsHeader cbsHeader);

    @ServiceOperation(name = SVC_OP_NAME_FINTRANMSGSQRYSERVICE_QUERY)
    public List<FinTranMsgsQry> query(int offset, int resultLimit, String groupBy, String order, Map<String, Object> filters);

    @ServiceOperation(name = SVC_OP_NAME_FINTRANMSGSQRYSERVICE_EXECUTE, type = ServiceOperation.ServiceOperationType.EXECUTE)
    public FinTranMsgsQry findFinTranRestraintsQry(FinTranMsgsQry reference);
}
