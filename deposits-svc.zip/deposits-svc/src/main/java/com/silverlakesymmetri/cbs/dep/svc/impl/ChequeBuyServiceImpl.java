package com.silverlakesymmetri.cbs.dep.svc.impl;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mysema.query.types.EntityPath;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.context.CbsSessionContext;
import com.silverlakesymmetri.cbs.commons.exception.CbsRuntimeException;
import com.silverlakesymmetri.cbs.commons.exception.base.CbsServiceProcessException;
import com.silverlakesymmetri.cbs.commons.exception.base.helper.ExceptionHelper;
import com.silverlakesymmetri.cbs.commons.jpa.entity.FindCriteriaJpe;
import com.silverlakesymmetri.cbs.commons.logging.CbsAppLogger;
import com.silverlakesymmetri.cbs.commons.logging.CbsAppLoggerFactory;
import com.silverlakesymmetri.cbs.commons.svc.AbstractXmlApiBusinessService;
import com.silverlakesymmetri.cbs.commons.xmlapi.enums.CbsXmlApiOperation;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.Acct;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.ChqBuy;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.ChqBuyTran;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.AcctJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.ChqBuyDdBnkJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.ChqBuyJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.ChqBuyTranJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.DepFeeApplyJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.id.ChqBuyPk;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.QChqBuyJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.util.DepJpeConstants;
import com.silverlakesymmetri.cbs.dep.svc.AcctService;
import com.silverlakesymmetri.cbs.dep.svc.ChequeBuyService;
import com.silverlakesymmetri.cbs.dep.svc.DepUtilityService;
import com.silverlakesymmetri.cbs.dep.svc.mapper.mapping.ChqBuyToDEPCHEQUEBUYAPITypeMapper;
import com.silverlakesymmetri.cbs.dep.svc.mapper.mapping.DEPCHQBUYSELLPYMTOUTTTypeToChqBuyTranMapper;
import com.silverlakesymmetri.cbs.dep.svc.mapper.mapping.DepFeeApplyToDEPFEEAPPLYINTypeMapper;
import com.silverlakesymmetri.cbs.dep.svc.mapper.mapping.DepTranOtherDataToDEPTRANOTHERDATATTypeMapper;
import com.silverlakesymmetri.cbs.dep.svc.mapper.mapping.ScDetailInToDEPFEEAPPLYDTLINTTypeMapper;
import com.silverlakesymmetri.cbs.dep.svc.mapper.mapping.TranValidationFlagsToDEPTRANVALIDATIONFLAGSTTypeMapper;
import com.silverlakesymmetri.cbs.dep.xmlapi.DEPCHEQUEBUYAPIType;
import com.silverlakesymmetri.cbs.dep.xmlapi.DEPCHQBUYBENEFINTType;
import com.silverlakesymmetri.cbs.dep.xmlapi.DEPCHQBUYDDINTType;
import com.silverlakesymmetri.cbs.dep.xmlapi.DEPCHQBUYSELLOUTTType;
import com.silverlakesymmetri.cbs.dep.xmlapi.DEPCHQBUYSELLPYMTINTType;
import com.silverlakesymmetri.cbs.dep.xmlapi.DEPCHQBUYSELLPYMTOUTTType;
import com.silverlakesymmetri.cbs.dep.xmlapi.DEPFEEAPPLYDTLINCOLLType;
import com.silverlakesymmetri.cbs.dep.xmlapi.DEPFEEAPPLYINType;
import com.silverlakesymmetri.cbs.dep.xmlapi.DEPTRANOTHERDATACOLLType;
import com.silverlakesymmetri.cbs.mcl.jpa.mapping.sdo.util.MclJpeConstants;

@Service
public class ChequeBuyServiceImpl extends AbstractXmlApiBusinessService<ChqBuy, ChqBuyJpe, ChqBuyPk, DEPCHEQUEBUYAPIType, DEPCHEQUEBUYAPIType> implements ChequeBuyService {
	
	private static final String CBS_CHANNEL_SOURCE = "HTTP-UI";
	private static final String DEP_CI_GRP_SEQ_NO = "DEP_CI_GRP_SEQ_NO_S";
	
	private static CbsAppLogger logger = CbsAppLoggerFactory.getLogger(ChequeBuyServiceImpl.class.getName());
	
	@Autowired
	DepUtilityService depUtilService;
	
	@Autowired
	protected DepFeeApplyToDEPFEEAPPLYINTypeMapper feeApplyMapper;
	
	@Autowired
	protected ScDetailInToDEPFEEAPPLYDTLINTTypeMapper scDetailInMapper;
	
	@Autowired
	protected DepTranOtherDataToDEPTRANOTHERDATATTypeMapper depTranOtherDataMapper;

	@Autowired
	protected TranValidationFlagsToDEPTRANVALIDATIONFLAGSTTypeMapper tranValidationFlagsMapper;

    @Autowired
    private ChqBuyToDEPCHEQUEBUYAPITypeMapper mapper;

	@Autowired
	private DEPCHQBUYSELLPYMTOUTTTypeToChqBuyTranMapper buyTranMapper;
	
	@Autowired
	private AcctService acctService;

    @Override
	public ChqBuy getByPk(String publicKey, ChqBuy reference) {
		return super.getByPk(publicKey, reference);
	}
	
	@Override
	protected EntityPath<ChqBuyJpe> getEntityPath() {
		return QChqBuyJpe.chqBuyJpe;
	}
	
	@Override
	protected ChqBuyPk getIdFromDataObjectInstance(ChqBuy dataObject) {
		return new ChqBuyPk(dataObject.getGrpCiSeqNoBuy());
	}
	
	@Override
	public List<ChqBuy> query(int offset, int resultLimit, String groupBy, String order,
			Map<String, Object> filters) {
		
	    return super.query(offset, resultLimit, groupBy, order, filters);
	}
	
	@Override
	public ChqBuy create(ChqBuy dataObject) {
		return super.create(dataObject);
	}

	@Override
	protected ChqBuy preCreateValidation(ChqBuy dataObject) {
		long mainSeqNo = dataService.nextSequenceValue(DEP_CI_GRP_SEQ_NO).longValue();
		dataObject.setGrpCiSeqNoBuy(mainSeqNo);
		
		Collection<Throwable> exceptions = new ArrayList<Throwable>();
		if(dataObject.getChqBuyTranList() != null && dataObject.getChqBuyTranList().size() > 1){
			List<String> acctNoList = new ArrayList<String>();
			for(ChqBuyTran chqBuyTran: dataObject.getChqBuyTranList()){
				Map<String, Object> param = new HashMap<String, Object>();
				param.put("acctNo", chqBuyTran.getAcctNo());
				List<AcctJpe> acctList = dataService.findWithNamedQuery(DepJpeConstants.ACCT_JPE_FIND_BY_ACCT_NO_CASA, param, AcctJpe.class);
				if(acctList == null || acctList.size() == 0){
					String msg = messageUtils.getMessage("CBS.DEP.B.CHQ_BUY_SERVICE.0003", new String[] {});
					CbsServiceProcessException exec = new CbsServiceProcessException("CBS.DEP.B.CHQ_BUY_SERVICE.0003", msg);
					exceptions.add(exec);
				}
				if(chqBuyTran.getAcctNo() != null && acctNoList.contains(chqBuyTran.getAcctNo())){
					String msg = messageUtils.getMessage("CBS.DEP.B.CHQ_BUY_SERVICE.0002", new String[] {});
					CbsServiceProcessException exec = new CbsServiceProcessException("CBS.DEP.B.CHQ_BUY_SERVICE.0002", msg);
					exceptions.add(exec);
					break;
				}
				acctNoList.add(chqBuyTran.getAcctNo());
			}
		}
		if(exceptions.size() > 0){
			ExceptionHelper.createAndThrowAggregateException(exceptions);
		}
		return super.preCreateValidation(dataObject);
	}

	@Override
	public Long count(FindCriteria findCriteria, CbsHeader cbsHeader) {
		return dataService.getRowCount(ChqBuyJpe.class, new FindCriteriaJpe());
	}
	
	@Override
	protected Class<DEPCHEQUEBUYAPIType> getXmlApiResponseClass() {
		return DEPCHEQUEBUYAPIType.class;
	}
	
	@Override
	protected List<ChqBuy> processXmlApiListRs(ChqBuy dataObject, DEPCHEQUEBUYAPIType xmlApiRs) {
		return null;
	}
	
	@Override
	protected ChqBuy processXmlApiRs(ChqBuy dataObject, DEPCHEQUEBUYAPIType xmlApiRs) {
		long seqNo = xmlApiRs.getGRPCISEQNO();
		dataObject.setGrpCiSeqNoBuy(seqNo);

		ChqBuyJpe jpe = jaxbSdoHelper.unwrap(dataObject);
		List<ChqBuyTranJpe> origChqBuyTranList = jpe.getChqBuyTranList();
		jpe.setChqBuyTranList(new ArrayList<>());

		for (DEPCHQBUYSELLOUTTType chqbuysellrec: xmlApiRs.getDEPCHQBUYOUTDTLS().getDEPCHQBUYSELLOUTT()) {
			for (ChqBuyDdBnkJpe chqBuyDdBnkRec: jpe.getChqBuyDdBnkList()) {
				if (chqbuysellrec.getPOSITION() == chqBuyDdBnkRec.getPosition().doubleValue()) {
					chqBuyDdBnkRec.setStartChequeNo(new Double(chqbuysellrec.getSTARTCHEQUE()).longValue());
					chqBuyDdBnkRec.setEndChequeNo(new Double(chqbuysellrec.getENDCHEQUE()).longValue());
					chqBuyDdBnkRec.setStartSeq(new Double(chqbuysellrec.getSTARTSEQ()).longValue());
					chqBuyDdBnkRec.setEndSeq(new Double(chqbuysellrec.getENDSEQ()).longValue());
				}
			}
		}

		for (DEPCHQBUYSELLPYMTOUTTType xmlApiRec: xmlApiRs.getDEPCHQBUYPYMTOUTDTLS().getDEPCHQBUYSELLPYMTOUTT()) {
			ChqBuyTranJpe chqBuyTranRs = buyTranMapper.apiTypeToJpe(xmlApiRec);
			if(chqBuyTranRs.getTranSeqNo() != null && chqBuyTranRs.getTranSeqNo().longValue() > 0){
				if(origChqBuyTranList != null && origChqBuyTranList.size() > 0){
					for(ChqBuyTranJpe chqBuyTranRq : origChqBuyTranList){
	                    if (chqBuyTranRq.getAcctNo() != null) {
							if (chqBuyTranRq.getAcctNo().equals(chqBuyTranRs.getAcctNo())) {
								chqBuyTranRs.setVirtualAttributeList(chqBuyTranRq.getVirtualAttributeList());
								break;
							}
						}
					}
				}
				jpe.getChqBuyTranList().add(chqBuyTranRs);				
			}
		}

		return jaxbSdoHelper.wrap(jpe);
	}
	
	@Override
	protected DEPCHEQUEBUYAPIType transformBdoToXmlApiRqCreate(ChqBuy dataObject) {
		return transformChqBuyToDEPCHEQUEBUYAPIType(dataObject, CbsXmlApiOperation.INSERT);
	}

	@Override
	protected DEPCHEQUEBUYAPIType transformBdoToXmlApiRqDelete(ChqBuy dataObject) {
	    return transformChqBuyToDEPCHEQUEBUYAPIType(dataObject, CbsXmlApiOperation.UPDATE);
	}

	@Override
	protected DEPCHEQUEBUYAPIType transformBdoToXmlApiRqUpdate(ChqBuy dataObject) {
	    return transformChqBuyToDEPCHEQUEBUYAPIType(dataObject, CbsXmlApiOperation.DELETE);
	}
	
	private DEPCHEQUEBUYAPIType transformChqBuyToDEPCHEQUEBUYAPIType(ChqBuy dataObject, CbsXmlApiOperation oper){
		ChqBuyJpe jpe = jaxbSdoHelper.unwrap(dataObject);
		DEPCHEQUEBUYAPIType apiType = mapper.jpeToApiType(jpe);
		super.setTechColsFromDataObject(dataObject, apiType);
		double vTotalAmt = 0.00;
		Long vTotalQty = 0L;

	    CbsSessionContext sessionCtx = cbsRuntimeContextManager.getContext(CbsSessionContext.class);
	    String branch = sessionCtx.getBranch();
	    
	    if (sessionCtx.getChannelSource().equals(CBS_CHANNEL_SOURCE)) {
	    	apiType.setTRANBRANCH((String) branch);
		} else {
			apiType.setTRANBRANCH(jpe.getBranch());
		}
	    
		if (apiType.getDEPCHQBUYBENEFINDTLS() != null) {
			for (DEPCHQBUYBENEFINTType chqBen : apiType.getDEPCHQBUYBENEFINDTLS().getDEPCHQBUYBENEFINT()) {
				if (jpe.getChqBuyBeneficiaryDetailsRec().getBeneficiaryClientNo() != null) {
					Map<String, Object> params = new HashMap<String, Object>();
			        params.put("clientNo", jpe.getChqBuyBeneficiaryDetailsRec().getBeneficiaryClientNo());
			        Long clientId = dataService.getWithNamedQuery(MclJpeConstants.CLIENT_JPE_FIND_CLIENT_ID_USING_CLIENT_NO, params, Long.class);
					chqBen.setBENEFCLIENTNO(clientId);
				}
			}
		}
		
        if(apiType.getDEPCHQBUYDDINDTLS() != null) {
            for (DEPCHQBUYDDINTType chqBuyDdBnk : apiType.getDEPCHQBUYDDINDTLS().getDEPCHQBUYDDINT()) {
                vTotalQty = vTotalQty + valueIfNull(chqBuyDdBnk.getQTY());
                vTotalAmt = vTotalAmt + (valueIfNull(chqBuyDdBnk.getAMOUNT()) * chqBuyDdBnk.getQTY());
            }
        }

        if (apiType.getDEPCHQBUYPYMTINDTLS() != null) {
            for (DEPCHQBUYSELLPYMTINTType chqBuyTran : apiType.getDEPCHQBUYPYMTINDTLS().getDEPCHQBUYSELLPYMTINT()) {
            	if (chqBuyTran.getPYMTMODE().equalsIgnoreCase("A")) {
	                AcctJpe acctJpe = getAccount(chqBuyTran.getACCTNO());
	                chqBuyTran.setACCTCCY(acctJpe.getCcy());
	                chqBuyTran.setDEPOSITTYPE(acctJpe.getDepositType());
            	}
                chqBuyTran.setEFFECTDATE(dateTimeHelper.convertToCbsXmlApiDate(dateTimeHelper.getRunDate()));
                chqBuyTran.setOVERRIDEOFFICER(sessionCtx.getUserCode());
                chqBuyTran.setTRANDATE(dateTimeHelper.convertToCbsXmlApiDate(dateTimeHelper.getRunDate()));
            }
        }

		DEPFEEAPPLYINType feeApplyIn = null;
		if (jpe.getChqBuyScDtlsRec() != null) {
			for (DepFeeApplyJpe depFeeApply : jpe.getChqBuyScDtlsRec().getDepFeeApplyList()) {
				if (feeApplyIn == null) {
					feeApplyIn = feeApplyMapper.mapDepFeeApplyToDEPFEEAPPLYIN(depFeeApply);
					feeApplyIn.setSCDETAILIN(new DEPFEEAPPLYDTLINCOLLType());
					feeApplyIn.setRBTRANOTHERDATAIN(new DEPTRANOTHERDATACOLLType());
				}
				feeApplyIn.getSCDETAILIN().getDEPFEEAPPLYDTLINT()
						.add(scDetailInMapper.mapScDetailInToDEPFEEAPPLYDTLIN(depFeeApply.getScDetailIn()));
				feeApplyIn.getRBTRANOTHERDATAIN().getDEPTRANOTHERDATAT().add(depTranOtherDataMapper
						.mapTranValidationFlagsToDEPTRANVALIDATIONFLAGST(depFeeApply.getRbTranOtherData()));
				feeApplyIn.setTRANVALIDATIONFLAGS(tranValidationFlagsMapper
						.mapTranValidationFlagsToDEPTRANVALIDATIONFLAGST(depFeeApply.getTranValidationFlags()));
			}
		}
		
		apiType.setSCAPPLYIN(feeApplyIn);
		apiType.setOPERATION(oper.getOperation());
        apiType.setTOTALQTY(vTotalQty);
        apiType.setTOTALAMOUNT(vTotalAmt);
		
		return apiType;
	}
	
	@Override
	public void validateApiRequest(ChqBuy dataObject, DEPCHEQUEBUYAPIType xmlApiRq) {
        try {
            String xmlApiReq = removeModifiedByAndModifiedDt(convertXmlApiRqToString(xmlApiRq));
            String xmlHeaderIn = convertXmlApiRqToString(createHeaderFromDataObject(dataObject));
            validate(dataObject, xmlApiReq, xmlHeaderIn);
        } catch (CbsRuntimeException cre) {
            throw cre;
        } catch (Exception e) {
            logger.error("Unhandled error encountered: {}", e.getMessage(), e);
            throw new RuntimeException(e);
        }
    }

    private AcctJpe getAccount(String acctNo){
        AcctJpe acctJpe = null;
        Map<String,Object> param = new HashMap<String, Object>();
        param.put("acctNo", acctNo);
        List<AcctJpe> acctJpeList = dataService.findWithNamedQuery(DepJpeConstants.ACCT_JPE_FIND_BY_ACCTNO, param, AcctJpe.class);
        if (acctJpeList!=null && acctJpeList.size()>0){
            acctJpe = acctJpeList.get(0);
        }
        return acctJpe;
    }
    private Long valueIfNull(Long var) {
        Long xVar = 0L;
        
        if (var != null) {
            return var;
        }
        return xVar;
    }
    private Double valueIfNull(Double var) {
        Double xVar = 0d;
        
        if (var != null) {
            return var;
        }
        return xVar;
    }


}
