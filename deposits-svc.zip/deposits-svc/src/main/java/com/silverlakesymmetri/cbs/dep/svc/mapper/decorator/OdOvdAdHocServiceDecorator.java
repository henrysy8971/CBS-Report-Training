package com.silverlakesymmetri.cbs.dep.svc.mapper.decorator;

import org.mapstruct.Context;
import org.mapstruct.MappingTarget;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

import com.silverlakesymmetri.cbs.commons.xmlapi.enums.CbsXmlApiOperation;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.OdOvdAdHocJpe;
import com.silverlakesymmetri.cbs.dep.svc.mapper.OdOvdAdHocServiceMapper;
import com.silverlakesymmetri.cbs.dep.xmlapi.DEPODOVDAPIType;

public abstract class OdOvdAdHocServiceDecorator implements OdOvdAdHocServiceMapper {

	@Autowired
	@Qualifier("delegate")
	protected OdOvdAdHocServiceMapper delegate;

	@Override
	public DEPODOVDAPIType mapToApi(OdOvdAdHocJpe jpe, @Context CbsXmlApiOperation oper) {
		DEPODOVDAPIType req = (DEPODOVDAPIType) delegate.mapToApi(jpe, oper);
		return req;
	}

	@Override
	public OdOvdAdHocJpe mapToJpe(DEPODOVDAPIType api, @MappingTarget OdOvdAdHocJpe jpe) {
		if (jpe == null) {
			jpe = new OdOvdAdHocJpe();
		}
		if (api == null) {
			return jpe;
		}
		jpe = delegate.mapToJpe(api, jpe);
		return jpe;
	}

}
