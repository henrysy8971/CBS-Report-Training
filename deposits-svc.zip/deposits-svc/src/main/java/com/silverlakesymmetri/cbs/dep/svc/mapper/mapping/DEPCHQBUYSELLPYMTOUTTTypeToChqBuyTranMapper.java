package com.silverlakesymmetri.cbs.dep.svc.mapper.mapping;

import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.ChqBuyTranJpe;
import com.silverlakesymmetri.cbs.dep.xmlapi.DEPCHQBUYSELLPYMTOUTTType;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Mappings;

@Mapper
public interface DEPCHQBUYSELLPYMTOUTTTypeToChqBuyTranMapper {
	
	@Mappings({
		@Mapping(source = "POSITION", target = "position"),
		@Mapping(source = "ACCTNO", target = "acctNo"),
		@Mapping(source = "AVAILBAL", target = "availBal"),
		@Mapping(source = "LEDGERBAL", target = "ledgerBal"),
		@Mapping(source = "TRANSEQNO", target = "tranSeqNo"),
		@Mapping(source = "GRPCISEQNO", target = "grpCiSeqNoBuy")
	})
	ChqBuyTranJpe apiTypeToJpe(DEPCHQBUYSELLPYMTOUTTType apiType);
}
