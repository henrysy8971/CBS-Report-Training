package com.silverlakesymmetri.cbs.dep.svc.impl;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.mysema.query.types.EntityPath;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.svc.AbstractBusinessService;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.SdbVisitDtls;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.QSdbVisitDtlsJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.SdbVisitDtlsJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.id.SdbVisitDtlsPk;

@Service
@Transactional
public class SdbVisitDtlsServiceImpl extends AbstractBusinessService<SdbVisitDtls, SdbVisitDtlsJpe, SdbVisitDtlsPk>{

	@Override
	protected SdbVisitDtlsPk getIdFromDataObjectInstance(SdbVisitDtls dataObject) {
		SdbVisitDtlsPk pk = new SdbVisitDtlsPk(dataObject.getSeqNo(), Long.parseLong(dataObject.getClientNo()));
		return pk;
	}

	@Override
	protected EntityPath<SdbVisitDtlsJpe> getEntityPath() {
		return QSdbVisitDtlsJpe.sdbVisitDtlsJpe;
	}
	
	@Override
    public SdbVisitDtls getByPk(String publicKey, SdbVisitDtls reference) {
        return super.getByPk(publicKey, reference);
    }
	
	@Override
	public SdbVisitDtls create(SdbVisitDtls dataObject) {
		return super.create(dataObject);
	}
	
	@Override
	public SdbVisitDtls get(SdbVisitDtls objectInstanceIdentifier) {
		return super.get(objectInstanceIdentifier);
	}

	@Override
	public List<SdbVisitDtls> query(int offset, int resultLimit, String groupBy, String order,
			Map<String, Object> filters) {
		return super.query(offset, resultLimit, groupBy, order, filters);
	}

	@Override
	public SdbVisitDtls update(SdbVisitDtls dataObject) {
		return super.update(dataObject);
	}

	@Override
	public boolean delete(SdbVisitDtls dataObject) {
		return super.delete(dataObject);
	}

	@Override
	public List<SdbVisitDtls> find(FindCriteria findCriteria, CbsHeader cbsHeader) {
		return super.find(findCriteria, cbsHeader);
	}


}
