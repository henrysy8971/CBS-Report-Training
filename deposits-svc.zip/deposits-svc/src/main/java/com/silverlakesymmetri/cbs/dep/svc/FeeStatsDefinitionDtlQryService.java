package com.silverlakesymmetri.cbs.dep.svc;

import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.svc.BusinessService;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.FeeStatsDefinitionDtl;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.FeeStatsDefinitionDtlJpe;

import java.util.List;
import java.util.Map;

public interface FeeStatsDefinitionDtlQryService extends BusinessService<FeeStatsDefinitionDtl, FeeStatsDefinitionDtlJpe> {
	String SVC_OP_NAME_FEESTATSDEFNQRYQRYSERVICE_GET = "FeeStatsDefinitionDtlQry.get";
	String SVC_OP_NAME_FEESTATSDEFNQRYQRYSERVICE_QUERY = "FeeStatsDefinitionDtlQry.query";
	String SVC_OP_NAME_FEESTATSDEFNQRYQRYSERVICE_FIND = "FeeStatsDefinitionDtlQry.find";

	@ServiceOperation(name = SVC_OP_NAME_FEESTATSDEFNQRYQRYSERVICE_GET, type = ServiceOperation.ServiceOperationType.GET)
	FeeStatsDefinitionDtl getByPk(String publicKey, FeeStatsDefinitionDtl reference);

	@ServiceOperation(name = SVC_OP_NAME_FEESTATSDEFNQRYQRYSERVICE_QUERY)
	List<FeeStatsDefinitionDtl> query(int offset, int resultLimit, String groupBy, String order,
                                  Map<String, Object> filters);

	@ServiceOperation(name = SVC_OP_NAME_FEESTATSDEFNQRYQRYSERVICE_FIND)
	List<FeeStatsDefinitionDtl> find(FindCriteria findCriteria, CbsHeader cbsHeader);
}
