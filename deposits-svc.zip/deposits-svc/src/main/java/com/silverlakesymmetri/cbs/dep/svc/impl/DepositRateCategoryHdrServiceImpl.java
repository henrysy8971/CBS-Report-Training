package com.silverlakesymmetri.cbs.dep.svc.impl;

import com.mysema.query.types.EntityPath;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.jpa.entity.FindCriteriaJpe;
import com.silverlakesymmetri.cbs.commons.jpa.util.DateTimeHelper;
import com.silverlakesymmetri.cbs.commons.svc.AbstractBusinessService;
import com.silverlakesymmetri.cbs.commons.svc.BusinessObjectValidationCapable;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.DepositRateCategoryHdr;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.DepositRateCategoryHdrJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.QDepositRateCategoryHdrJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.id.DepositRateCategoryHdrPk;
import com.silverlakesymmetri.cbs.dep.svc.DepositRateCategoryHdrService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Date;
import java.util.List;
import java.util.Map;

/**
 * Created by Emerson.Sanchez on 12/4/2019.
 */
@Service
@Transactional
public class DepositRateCategoryHdrServiceImpl extends AbstractBusinessService<DepositRateCategoryHdr,
        DepositRateCategoryHdrJpe, DepositRateCategoryHdrPk> implements DepositRateCategoryHdrService,
        BusinessObjectValidationCapable<DepositRateCategoryHdr> {

    @Autowired
    private DateTimeHelper dateHelper;

    @Override
    protected DepositRateCategoryHdrPk getIdFromDataObjectInstance(DepositRateCategoryHdr dataObject) {
        DepositRateCategoryHdrJpe jpe = jaxbSdoHelper.unwrap(dataObject, DepositRateCategoryHdrJpe.class);
        return new DepositRateCategoryHdrPk(jpe.getRateCategory());
    }

    @Override
    protected EntityPath<DepositRateCategoryHdrJpe> getEntityPath() {
        return QDepositRateCategoryHdrJpe.depositRateCategoryHdrJpe;
    }

    @Override
    public Long count(FindCriteria findCriteria, CbsHeader cbsHeader) {
        FindCriteriaJpe jpe = jaxbSdoHelper.unwrap(findCriteria, FindCriteriaJpe.class);
        return dataService.getRowCount(DepositRateCategoryHdrJpe.class, jpe);
    }

    @Override
    public List<DepositRateCategoryHdr> query(int offset, int resultLimit, String groupBy, String order,
                                        Map<String, Object> filters) {
        return super.query(offset, resultLimit, groupBy, order, filters);
    }

    @Override
    public List<DepositRateCategoryHdr> find(FindCriteria findCriteria, CbsHeader cbsHeader) {
        return super.find(findCriteria, cbsHeader);
    }

    @Override
    public DepositRateCategoryHdr update(DepositRateCategoryHdr dataObject) {
        return super.update(dataObject);
    }

    @Override
    protected DepositRateCategoryHdr preCreateValidation(DepositRateCategoryHdr dataObject) {
        DepositRateCategoryHdrJpe depositRateCategoryHdrJpe = jaxbSdoHelper.unwrap(dataObject);
        performDefaulting(depositRateCategoryHdrJpe);
        return super.preCreateValidation(jaxbSdoHelper.wrap(depositRateCategoryHdrJpe, DepositRateCategoryHdr.class));
    }

    private void performDefaulting(DepositRateCategoryHdrJpe depositRateCategoryHdrJpe) {
        depositRateCategoryHdrJpe.setUsedYn(false);
        if (null != depositRateCategoryHdrJpe) {
            Date now = new Date();
            if(dateHelper.compareDates(depositRateCategoryHdrJpe.getStartDt(),now) >= 0 &&
                    dateHelper.compareDates(depositRateCategoryHdrJpe.getEndDt(),now) <= 0){
                depositRateCategoryHdrJpe.setActiveYn(true);
            }
        }
    }
}
