package com.silverlakesymmetri.cbs.dep.svc.impl;

import java.io.Serializable;
import java.util.Map;

import org.springframework.beans.factory.config.ConfigurableBeanFactory;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.silverlakesymmetri.cbs.commons.bdo.CbsBusinessDataObject;
import com.silverlakesymmetri.cbs.commons.jpa.entity.CbsBusinessDataObjectJpe;
import com.silverlakesymmetri.cbs.commons.svc.AbstractXmlApiBusinessService;
import com.silverlakesymmetri.cbs.commons.svc.alert.AlertDataHolder;
import com.silverlakesymmetri.cbs.commons.svc.alert.AlertDataHolderEnumStatus;
import com.silverlakesymmetri.cbs.commons.svc.util.AbstractAsyncTaskServiceImpl;
import com.silverlakesymmetri.cbs.dep.svc.DepMessageQueueAsyncGenerationService;

@Service("DepMessageQueueAsyncGenerationService")
@Scope(value = ConfigurableBeanFactory.SCOPE_PROTOTYPE)
public class DepMessageQueueAsyncGenerationServiceImpl<B extends CbsBusinessDataObject, E extends CbsBusinessDataObjectJpe, ID extends Serializable, XmlApiRq, XmlApiRs> 
	extends AbstractAsyncTaskServiceImpl<B> implements DepMessageQueueAsyncGenerationService<B, E, ID, XmlApiRq, XmlApiRs> {
	
	private AbstractXmlApiBusinessService<B, E, ID, XmlApiRq, XmlApiRs> service;
	private B bdo;
	private Map<String, Object> customParams;
	
	@Override
	public void initialize(AbstractXmlApiBusinessService<B, E, ID, XmlApiRq, XmlApiRs> generationService, B bdoObject, Map<String, Object> params) {
		this.service = generationService;
		this.bdo = bdoObject;
		this.customParams = params;
	}

	@Override
	public String getTaskName() {
		return "DEP MessageQueue Generation Request";
	}

	@Override
	@Transactional(propagation=Propagation.REQUIRES_NEW)
	protected B process() {
		this.service.asyncGenerateMessageQueue(this.bdo, this.customParams);
		return this.bdo;
	}

	@Override
	protected AlertDataHolder createAlertDataHolder(B bdoResult, AlertDataHolderEnumStatus status) {
		AlertDataHolder dataHolder = new AlertDataHolder();
		return dataHolder;
	}

}
