package com.silverlakesymmetri.cbs.dep.svc.impl;

import com.mysema.query.types.EntityPath;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.svc.AbstractBusinessService;
import com.silverlakesymmetri.cbs.commons.svc.BusinessObjectValidationCapable;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.ProfitTypeNoRateQry;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.ProfitTypeNoRateQryJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.QProfitTypeNoRateQryJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.id.ProfitTypeNoRateQryPk;
import com.silverlakesymmetri.cbs.dep.svc.ProfitTypeNoRateQryService;
import org.springframework.stereotype.Service;

import java.util.*;

@Service
public class ProfitTypeNoRateQryServiceImpl extends AbstractBusinessService<ProfitTypeNoRateQry, ProfitTypeNoRateQryJpe, ProfitTypeNoRateQryPk>
		implements ProfitTypeNoRateQryService, BusinessObjectValidationCapable<ProfitTypeNoRateQry> {

	@Override
	protected ProfitTypeNoRateQryPk getIdFromDataObjectInstance(ProfitTypeNoRateQry dataObject) {
		return new ProfitTypeNoRateQryPk(
				dataObject.getIntType(),
				dataObject.getCcy());
	}

	@Override
	protected EntityPath<ProfitTypeNoRateQryJpe> getEntityPath() {
		return QProfitTypeNoRateQryJpe.profitTypeNoRateQryJpe;
	}

	@Override
	public ProfitTypeNoRateQry getByPk(String publicKey, ProfitTypeNoRateQry reference) {
		return super.getByPk(publicKey, reference);
	}

	@Override
	public List<ProfitTypeNoRateQry> find(FindCriteria fc, CbsHeader cbsHeader) {
		return super.find(fc, cbsHeader);
	}

	@Override
	public List<ProfitTypeNoRateQry> query(int offset, int resultLimit, String groupBy, String order,
			Map<String, Object> filters) {
        String query = "SELECT p.intType, p.ccy, p.effectDate FROM ProfitTypeNoRateQryJpe p";
        final Map<String, Object> parameters = new HashMap<>();
        List<ProfitTypeNoRateQry> result = new ArrayList<>();
        /**
         * We explicitly passed ProfitTypeNoRateQry as the entityClass parameter so that we will receive a list of object array instead.
         * This is because the JPE only have the intType and ccy as the ID, and the view can contain values like below
         *
         * INT TYPE     |CCY       |EFFECT DATE
         * TM1           USD        04/01/2021
         * TM1           USD        05/01/2021
         *
         * This returns below data after pulling from the database
         *
         * INT TYPE     |CCY       |EFFECT DATE
         * TM1           USD        04/01/2021
         * TM1           USD        04/01/2021
         *
         * Since the ID is intType and ccy the result is duplicate since the entityManager can only distinguish uniqueness using the ID.
         * We cannot mark the effectDate as ID since it can be null. This is why we mapped it here instead after pulling the records
         */
        List list = dataService.findWithQuery(query, parameters, offset, resultLimit,
                ProfitTypeNoRateQry.class);
        if(list != null){
            for(Object obj: list) {
                Object[] values = (Object[]) obj;
                /**
                 * Used a JPE instead of BDO due to a weird error (NPE) when calling setEffectDate of the BDO. Even though the BDO is not null
                 */
                ProfitTypeNoRateQryJpe jpe = new ProfitTypeNoRateQryJpe();
                jpe.setIntType((String) values[0]);
                jpe.setCcy((String) values[1]);
                if(values.length > 2 && values[2] != null) {
                    jpe.setEffectDate((Date) values[2]);
                }
                ProfitTypeNoRateQry bdo = jaxbSdoHelper.wrap(jpe);
                result.add(bdo);
            }
        }
        //return super.query(offset, resultLimit, groupBy, order, filters);
        return result;
    }

}
