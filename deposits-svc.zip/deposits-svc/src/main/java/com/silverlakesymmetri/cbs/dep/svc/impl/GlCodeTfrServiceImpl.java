package com.silverlakesymmetri.cbs.dep.svc.impl;

import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.mysema.query.types.EntityPath;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.svc.AbstractBusinessService;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.GlCodeTfr;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.GlCodeTfrJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.QGlCodeTfrJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.id.GlCodeTfrPk;
import com.silverlakesymmetri.cbs.dep.svc.GlCodeTfrService;

@Service
@Transactional
public class GlCodeTfrServiceImpl extends AbstractBusinessService<GlCodeTfr, GlCodeTfrJpe, GlCodeTfrPk>
		implements GlCodeTfrService {

	@Override
	protected EntityPath<GlCodeTfrJpe> getEntityPath() {
		return QGlCodeTfrJpe.glCodeTfrJpe;
	}

	@Override
	protected GlCodeTfrPk getIdFromDataObjectInstance(GlCodeTfr dataObject) {
		return new GlCodeTfrPk(dataObject.getTfrSeqNo());
	}

	@Override
	public GlCodeTfr getByPk(String publicKey, GlCodeTfr reference) {
		return super.getByPk(publicKey, reference);
	}

	@Override
	public GlCodeTfr create(GlCodeTfr dataObject) {
		return super.create(dataObject);
	}

	@Override
	public GlCodeTfr update(GlCodeTfr dataObject) {
		return super.update(dataObject);
	}

	@Override
	public List<GlCodeTfr> query(int offset, int resultLimit, String groupBy, String order,
			Map<String, Object> filters) {
		return super.query(offset, resultLimit, groupBy, order, filters);
	}

	@Override
	public boolean delete(GlCodeTfr dataObject) {
		return super.delete(dataObject);
	}

	@Override
	public List<GlCodeTfr> find(FindCriteria findCriteria, CbsHeader cbsHeader) {
		return super.find(findCriteria, cbsHeader);
	}

	@Override
	protected GlCodeTfr preCreateValidation(GlCodeTfr dataObject) {
		GlCodeTfrJpe glCodeTfrJpe = jaxbSdoHelper.unwrap(dataObject);
		performDefaulting(glCodeTfrJpe);
		return super.preCreateValidation(jaxbSdoHelper.wrap(glCodeTfrJpe, GlCodeTfr.class));
	}

	@Override
	protected GlCodeTfr preUpdateValidation(GlCodeTfr dataObject) {
		GlCodeTfrJpe glCodeTfrJpe = jaxbSdoHelper.unwrap(dataObject);
		performDefaulting(glCodeTfrJpe);
		return super.preCreateValidation(jaxbSdoHelper.wrap(glCodeTfrJpe, GlCodeTfr.class));
	}

	private void performDefaulting(GlCodeTfrJpe glCodeTfrJpe) {
		if (glCodeTfrJpe != null && (glCodeTfrJpe.getTfrSeqNo() == null || glCodeTfrJpe.getTfrSeqNo() == 0)) {
			glCodeTfrJpe.setTfrSeqNo(dataService.nextSequenceValue("DEP_GL_CODE_TFR_S"));
		}
		if (StringUtils.isEmpty(glCodeTfrJpe.getOldGlCodeI())) {
			glCodeTfrJpe.setOldGlCodeI(null);
		}
		if (StringUtils.isEmpty(glCodeTfrJpe.getNewGlCodeI())) {
			glCodeTfrJpe.setNewGlCodeI(null);
		}
		if (StringUtils.isEmpty(glCodeTfrJpe.getOldGlCodeI2())) {
			glCodeTfrJpe.setOldGlCodeI2(null);
		}
		if (StringUtils.isEmpty(glCodeTfrJpe.getNewGlCodeI2())) {
			glCodeTfrJpe.setNewGlCodeI2(null);
		}
		if (StringUtils.isEmpty(glCodeTfrJpe.getOldGlCodeE())) {
			glCodeTfrJpe.setOldGlCodeE(null);
		}
		if (StringUtils.isEmpty(glCodeTfrJpe.getNewGlCodeE())) {
			glCodeTfrJpe.setNewGlCodeE(null);
		}
		if (StringUtils.isEmpty(glCodeTfrJpe.getOldGlCodeE2())) {
			glCodeTfrJpe.setOldGlCodeE2(null);
		}
		if (StringUtils.isEmpty(glCodeTfrJpe.getNewGlCodeE2())) {
			glCodeTfrJpe.setNewGlCodeE2(null);
		}
		if (StringUtils.isEmpty(glCodeTfrJpe.getOldGlCodeL())) {
			glCodeTfrJpe.setOldGlCodeL(null);
		}
		if (StringUtils.isEmpty(glCodeTfrJpe.getNewGlCodeL())) {
			glCodeTfrJpe.setNewGlCodeL(null);
		}
		if (StringUtils.isEmpty(glCodeTfrJpe.getOldGlCodeL2())) {
			glCodeTfrJpe.setOldGlCodeL2(null);
		}
		if (StringUtils.isEmpty(glCodeTfrJpe.getNewGlCodeL2())) {
			glCodeTfrJpe.setNewGlCodeL2(null);
		}
		if (StringUtils.isEmpty(glCodeTfrJpe.getOldGlCodeA())) {
			glCodeTfrJpe.setOldGlCodeA(null);
		}
		if (StringUtils.isEmpty(glCodeTfrJpe.getNewGlCodeA())) {
			glCodeTfrJpe.setNewGlCodeA(null);
		}
		if (StringUtils.isEmpty(glCodeTfrJpe.getOldGlCodeA2())) {
			glCodeTfrJpe.setOldGlCodeA2(null);
		}
		if (StringUtils.isEmpty(glCodeTfrJpe.getNewGlCodeA2())) {
			glCodeTfrJpe.setNewGlCodeA2(null);
		}
		if (StringUtils.isEmpty(glCodeTfrJpe.getOldGlCodeAip())) {
			glCodeTfrJpe.setOldGlCodeAip(null);
		}
		if (StringUtils.isEmpty(glCodeTfrJpe.getNewGlCodeAip())) {
			glCodeTfrJpe.setNewGlCodeAip(null);
		}
		if (StringUtils.isEmpty(glCodeTfrJpe.getOldGlCodeAip2())) {
			glCodeTfrJpe.setOldGlCodeAip2(null);
		}
		if (StringUtils.isEmpty(glCodeTfrJpe.getNewGlCodeAip2())) {
			glCodeTfrJpe.setNewGlCodeAip2(null);
		}
		if (StringUtils.isEmpty(glCodeTfrJpe.getOldGlCodeAir())) {
			glCodeTfrJpe.setOldGlCodeAir(null);
		}
		if (StringUtils.isEmpty(glCodeTfrJpe.getNewGlCodeAir())) {
			glCodeTfrJpe.setNewGlCodeAir(null);
		}
		if (StringUtils.isEmpty(glCodeTfrJpe.getOldGlCodeAir2())) {
			glCodeTfrJpe.setOldGlCodeAir2(null);
		}
		if (StringUtils.isEmpty(glCodeTfrJpe.getNewGlCodeAir2())) {
			glCodeTfrJpe.setNewGlCodeAir2(null);
		}
		if (StringUtils.isEmpty(glCodeTfrJpe.getOldGlCodeAii())) {
			glCodeTfrJpe.setOldGlCodeAii(null);
		}
		if (StringUtils.isEmpty(glCodeTfrJpe.getNewGlCodeAii())) {
			glCodeTfrJpe.setNewGlCodeAii(null);
		}
		if (StringUtils.isEmpty(glCodeTfrJpe.getOldGlCodeAii2())) {
			glCodeTfrJpe.setOldGlCodeAii2(null);
		}
		if (StringUtils.isEmpty(glCodeTfrJpe.getNewGlCodeAii2())) {
			glCodeTfrJpe.setNewGlCodeAii2(null);
		}
		if (StringUtils.isEmpty(glCodeTfrJpe.getOldGlCodeAii())) {
			glCodeTfrJpe.setOldGlCodeAii(null);
		}
		if (StringUtils.isEmpty(glCodeTfrJpe.getNewGlCodeAii())) {
			glCodeTfrJpe.setNewGlCodeAii(null);
		}
		if (StringUtils.isEmpty(glCodeTfrJpe.getOldGlCodeAii2())) {
			glCodeTfrJpe.setOldGlCodeAii2(null);
		}
		if (StringUtils.isEmpty(glCodeTfrJpe.getNewGlCodeAii2())) {
			glCodeTfrJpe.setNewGlCodeAii2(null);
		}
		if (StringUtils.isEmpty(glCodeTfrJpe.getOldGlCodeMur())) {
			glCodeTfrJpe.setOldGlCodeMur(null);
		}
		if (StringUtils.isEmpty(glCodeTfrJpe.getNewGlCodeMur())) {
			glCodeTfrJpe.setNewGlCodeMur(null);
		}
		if (StringUtils.isEmpty(glCodeTfrJpe.getOldGlCodeMur2())) {
			glCodeTfrJpe.setOldGlCodeMur2(null);
		}
		if (StringUtils.isEmpty(glCodeTfrJpe.getNewGlCodeMur2())) {
			glCodeTfrJpe.setNewGlCodeMur2(null);
		}
		if (StringUtils.isEmpty(glCodeTfrJpe.getOldGlCodeRi())) {
			glCodeTfrJpe.setOldGlCodeRi(null);
		}
		if (StringUtils.isEmpty(glCodeTfrJpe.getNewGlCodeRi())) {
			glCodeTfrJpe.setNewGlCodeRi(null);
		}
		if (StringUtils.isEmpty(glCodeTfrJpe.getOldGlCodeRi2())) {
			glCodeTfrJpe.setOldGlCodeRi2(null);
		}
		if (StringUtils.isEmpty(glCodeTfrJpe.getNewGlCodeRi2())) {
			glCodeTfrJpe.setNewGlCodeRi2(null);
		}
		if (StringUtils.isEmpty(glCodeTfrJpe.getOldGlCodeCfAccr())) {
			glCodeTfrJpe.setOldGlCodeCfAccr(null);
		}
		if (StringUtils.isEmpty(glCodeTfrJpe.getNewGlCodeCfAccr())) {
			glCodeTfrJpe.setNewGlCodeCfAccr(null);
		}
		if (StringUtils.isEmpty(glCodeTfrJpe.getOldGlCodeCfInc())) {
			glCodeTfrJpe.setOldGlCodeCfInc(null);
		}
		if (StringUtils.isEmpty(glCodeTfrJpe.getNewGlCodeCfInc())) {
			glCodeTfrJpe.setNewGlCodeCfInc(null);
		}
		if (StringUtils.isEmpty(glCodeTfrJpe.getOldGlCodeOrfEir())) {
			glCodeTfrJpe.setOldGlCodeOrfEir(null);
		}
		if (StringUtils.isEmpty(glCodeTfrJpe.getNewGlCodeOrfEir())) {
			glCodeTfrJpe.setNewGlCodeOrfEir(null);
		}
		if (StringUtils.isEmpty(glCodeTfrJpe.getOldGlCodeOrfInc())) {
			glCodeTfrJpe.setOldGlCodeOrfInc(null);
		}
		if (StringUtils.isEmpty(glCodeTfrJpe.getNewGlCodeOrfInc())) {
			glCodeTfrJpe.setNewGlCodeOrfInc(null);
		}
		if (StringUtils.isEmpty(glCodeTfrJpe.getOldGlCodeTcEir())) {
			glCodeTfrJpe.setOldGlCodeTcEir(null);
		}
		if (StringUtils.isEmpty(glCodeTfrJpe.getNewGlCodeTcEir())) {
			glCodeTfrJpe.setNewGlCodeTcEir(null);
		}
		if (StringUtils.isEmpty(glCodeTfrJpe.getOldGlCodeTcInc())) {
			glCodeTfrJpe.setOldGlCodeTcInc(null);
		}
		if (StringUtils.isEmpty(glCodeTfrJpe.getNewGlCodeTcInc())) {
			glCodeTfrJpe.setNewGlCodeTcInc(null);
		}
	}

}
