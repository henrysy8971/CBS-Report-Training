package com.silverlakesymmetri.cbs.dep.svc.mapper.decorator;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.silverlakesymmetri.cbs.commons.xmlapi.enums.CbsXmlApiOperation;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.InwdChequeJpe;
import com.silverlakesymmetri.cbs.dep.svc.mapper.ClearingServiceMapper;
import com.silverlakesymmetri.cbs.dep.svc.mapper.mapping.InwdChequeTDEPINWDCHEQUEAPITypeMapper;
import com.silverlakesymmetri.cbs.dep.xmlapi.DEPINWDCHEQUEAPIType;
import com.silverlakesymmetri.cbs.dep.xmlapi.DEPINWDCHEQUESCOLLType;
import com.silverlakesymmetri.cbs.dep.xmlapi.DEPINWDCLEARINGAPIType;

@Component
public class ClearingServiceDecorator implements ClearingServiceMapper {

	@Autowired
	protected InwdChequeTDEPINWDCHEQUEAPITypeMapper inwdChequeTDEPINWDCHEQUEAPITypeMapper;
	
	@Override
	public DEPINWDCLEARINGAPIType mapToApi(List<InwdChequeJpe> jpeList, CbsXmlApiOperation oper) {
		DEPINWDCLEARINGAPIType apiType = new DEPINWDCLEARINGAPIType();
		
		if (jpeList != null && jpeList.size() > 0) {
			String branch = null;
			apiType.setCHEQUES(new DEPINWDCHEQUESCOLLType());
			for (InwdChequeJpe jpe : jpeList) {
				DEPINWDCHEQUEAPIType chequeApiType = inwdChequeTDEPINWDCHEQUEAPITypeMapper.jpeToApiType(jpe, oper);
				apiType.getCHEQUES().getDEPINWDCHEQUEAPI().add(chequeApiType);
				if (branch == null) {
					branch = chequeApiType.getBRANCH();
				}
			}
			apiType.setBRANCH(branch);
		}
		
		return apiType;
	}

	@Override
	public List<InwdChequeJpe> mapToJpeList(DEPINWDCLEARINGAPIType apiType) {
		List<InwdChequeJpe> jpeList = new ArrayList<>();
		if (apiType != null && apiType.getCHEQUES() != null && apiType.getCHEQUES().getDEPINWDCHEQUEAPI().size() > 0) {
			for (DEPINWDCHEQUEAPIType chequeApiType : apiType.getCHEQUES().getDEPINWDCHEQUEAPI()) {
				InwdChequeJpe jpe = inwdChequeTDEPINWDCHEQUEAPITypeMapper.apiTypeToJpe(chequeApiType);
				jpeList.add(jpe);
			}
		}
		return jpeList;
	}
	

}
