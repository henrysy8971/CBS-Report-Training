package com.silverlakesymmetri.cbs.dep.svc.mapper.mapping;

import com.silverlakesymmetri.cbs.commons.jpa.util.DateTimeHelper;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.ChqSellTranJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.CiPrintReprintJpe;
import com.silverlakesymmetri.cbs.dep.xmlapi.DEPCHQBUYSELLPYMTINTType;
import com.silverlakesymmetri.cbs.dep.xmlapi.DEPCHQPRINTAPIType;
import org.mapstruct.*;

@MapperConfig(uses = { DateTimeHelper.class })
public interface CiPrintReprintToDEPCHQPRINTAPITypeMapper {
	
	@Mappings({
		@Mapping(source = "chequeType", target = "CHEQUETYPE"),
		@Mapping(source = "seqNo", target = "SEQNO"),
		@Mapping(source = "newSeqNo", target = "NEWSEQNO"),
		@Mapping(source = "ccy", target = "CCY"),
		@Mapping(source = "prefix", target = "PREFIX"),
		@Mapping(source = "chequeNo", target = "CHEQUENO"),
		@Mapping(source = "newChequeNo", target = "NEWCHEQUENO"),
		@Mapping(source = "bankCode", target = "AGENTBANK"),
		@Mapping(source = "bankBranch", target = "AGENTBRANCH"),
		@Mapping(source = "amount", target = "AMOUNT"),
		@Mapping(source = "narrative", target = "NARRATIVE"),
		@Mapping(source = "branch", target = "BRANCH"),
		@Mapping(source = "printReason", target = "PRINTREASON"),
		@Mapping(source = "officerId", target = "OFFICERID"),
		@Mapping(source = "autoGenFee", target = "AUTOGENFEE")
	})
	DEPCHQPRINTAPIType mapCiPrintReprintToDEPCHQPRINTAPIType(CiPrintReprintJpe jpe);

}
