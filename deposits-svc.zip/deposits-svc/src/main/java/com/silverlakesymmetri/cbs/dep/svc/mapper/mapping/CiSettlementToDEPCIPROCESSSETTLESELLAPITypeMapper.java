package com.silverlakesymmetri.cbs.dep.svc.mapper.mapping;

import org.mapstruct.MapperConfig;
import org.mapstruct.Mapping;
import org.mapstruct.Mappings;

import com.silverlakesymmetri.cbs.commons.jpa.util.DateTimeHelper;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.CiSettlementJpe;
import com.silverlakesymmetri.cbs.dep.xmlapi.DEPCIPROCESSSETTLESELLAPIType;

@MapperConfig(uses={ DateTimeHelper.class})
public interface CiSettlementToDEPCIPROCESSSETTLESELLAPITypeMapper {
	
	@Mappings({ 
		@Mapping(source = "branch", target="TRANBRANCH"),
		@Mapping(source = "seqNo", target="SEQNO"),
	 })
	public DEPCIPROCESSSETTLESELLAPIType mapCiSettlementToDEPCIPROCESSSETTLESELLAPIType(CiSettlementJpe jpe);	

}

