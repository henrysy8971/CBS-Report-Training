package com.silverlakesymmetri.cbs.dep.svc.impl;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.silverlakesymmetri.cbs.core.util.CcyConversionObject;
import com.silverlakesymmetri.cbs.dep.jpa.util.DepAcctOpenMaintHelper;
import com.silverlakesymmetri.cbs.dep.jpa.util.DepFxBuySellHelper;
import com.silverlakesymmetri.cbs.dep.jpa.util.DepHousekeepingHelper;
import com.silverlakesymmetri.cbs.dep.jpa.util.DepStorHelper;
import com.silverlakesymmetri.cbs.dep.jpa.util.DepTaxHelper;
import com.silverlakesymmetri.cbs.dep.svc.DepUtilityService;
import com.silverlakesymmetri.cbs.dep.util.ForexObject;
import com.silverlakesymmetri.cbs.dep.util.RecalcTaxObject;

/**
 * @author Ryan.Vargas
 */
@Service
public class DepUtilityServiceImpl implements DepUtilityService {

	@Autowired
	private DepStorHelper depStorHelper;
	
	@Autowired
	private DepTaxHelper depTaxHelper;

	@Autowired
	private DepAcctOpenMaintHelper depAcctOpenMaintHelper;
	
	@Autowired
	private DepFxBuySellHelper depFxBuySellHelper;

	@Autowired
	private DepHousekeepingHelper depHousekeepingHelper;
	
	@Override
	public String getRateType(String tranType, String clientNo) {
		return depStorHelper.getRateType(tranType, clientNo);
	}

	@Override
	public CcyConversionObject getEquivalentAmount(CcyConversionObject ccyConversionObject) {
		Map<String, Object> result = depStorHelper.getEquivalentAmount(ccyConversionObject.getTranType(), ccyConversionObject.getClientNo(), 
				ccyConversionObject.getBranch(), ccyConversionObject.getCrDrInd(), ccyConversionObject.getFromCcy(), ccyConversionObject.getFromAmt(), 
				ccyConversionObject.getToCcy(), ccyConversionObject.getToAmt(), ccyConversionObject.getTranDt(), ccyConversionObject.getCrossOper());
		if(result != null && !result.isEmpty()) {
			for (String key : result.keySet()) {
				switch (key) {
					case "branch":
						if (result.get(key) != null) ccyConversionObject.setBranch((String) result.get(key)); break;
					case "rateType":
						if (result.get(key) != null) ccyConversionObject.setxRateType((String) result.get(key)); break;
					case "effectDate":
						if (result.get(key) != null) ccyConversionObject.setTranDt((Date) result.get(key)); break;
					case "fromCcy":
						if (result.get(key) != null) ccyConversionObject.setFromCcy((String) result.get(key)); break;
					case "fromAmt":
						if (result.get(key) != null) ccyConversionObject.setFromAmt((Double) result.get(key)); break;
					case "toCcy":
						if (result.get(key) != null) ccyConversionObject.setToCcy((String) result.get(key)); break;
					case "toAmt":
						if (result.get(key) != null) ccyConversionObject.setToAmt((Double) result.get(key)); break;
					case "baseEquiv":
						if (result.get(key) != null) ccyConversionObject.setBaseEquiv((Double) result.get(key)); break;
					case "fromXrate":
						if (result.get(key) != null) ccyConversionObject.setFromXRate((Double) result.get(key)); break;
					case "toXrate":
						if (result.get(key) != null) ccyConversionObject.setToXRate((Double) result.get(key)); break;
					case "fromRateFlag":
						if (result.get(key) != null) ccyConversionObject.setFromXRateFlag((String) result.get(key)); break;
					case "toRateFlag":
						if (result.get(key) != null) ccyConversionObject.setToXRateFlag((String) result.get(key)); break;
					case "fromId":
						if (result.get(key) != null) ccyConversionObject.setFromOper((String) result.get(key)); break;
					case "toId":
						if (result.get(key) != null) ccyConversionObject.setToOper((String) result.get(key)); break;
					case "crossRate":
						if (result.get(key) != null) ccyConversionObject.setCrossXRate((Double) result.get(key)); break;
					case "crossId":
						if (result.get(key) != null) ccyConversionObject.setCrossOper((String) result.get(key)); break;
				}
			}
		}
		return ccyConversionObject;
	}

	@Override
	public ForexObject getCommissionEquivalent(ForexObject forexObject) {
		Map<String, Object> result = depFxBuySellHelper.getCommision(forexObject.getFromAmt(), forexObject.getFromCcy(), 
				forexObject.getCrossXrate(), forexObject.getCommTranType(), forexObject.getCommissionAmt(), 
				forexObject.getCaptureAmtType(), forexObject.getToCcy(), forexObject.getPaymentType(), forexObject.getTxnId());
		if(result != null && !result.isEmpty()) {
			for (String key : result.keySet()) {
				switch (key) {
					case "commTranType":
						if (result.get(key) != null) forexObject.setCommTranType((String) result.get(key)); break;
					case "commissionAmt":
						if (result.get(key) != null) forexObject.setCommissionAmt((Double) result.get(key)); break;
					case "toAmt":
						if (result.get(key) != null) forexObject.setToAmt((Double) result.get(key)); break;
					case "fromAmt":
						if (result.get(key) != null) forexObject.setFromAmt((Double) result.get(key)); break;
					case "txnId":
						if (result.get(key) != null) forexObject.setTxnId((String) result.get(key)); break;
					case "crossRate":
						if (result.get(key) != null) forexObject.setCrossXrate((Double) result.get(key)); break;
				}
			}
		}
		return forexObject;
	}

	@Override
	public ForexObject getForexEquivalent(ForexObject forexObject) {
		Map<String, Object> result = depFxBuySellHelper.getForex(forexObject.getTranType(), forexObject.getClientNo(), 
				forexObject.getBranch(), forexObject.getFromCcy(), forexObject.getFromAmt(), 
				forexObject.getToCcy(), forexObject.getToAmt(), forexObject.getCaptureAmtType(), forexObject.getTranDt());
		if(result != null && !result.isEmpty()) {
			for (String key : result.keySet()) {
				switch (key) {
					case "branch":
						if (result.get(key) != null) forexObject.setBranch((String) result.get(key)); break;
					case "rateType":
						if (result.get(key) != null) forexObject.setxRateType((String) result.get(key)); break;
					case "effectDate":
						if (result.get(key) != null) forexObject.setTranDt((Date) result.get(key)); break;
					case "fromCcy":
						if (result.get(key) != null) forexObject.setFromCcy((String) result.get(key)); break;
					case "fromAmt":
						if (result.get(key) != null) forexObject.setFromAmt((Double) result.get(key)); break;
					case "toCcy":
						if (result.get(key) != null) forexObject.setToCcy((String) result.get(key)); break;
					case "toAmt":
						if (result.get(key) != null) forexObject.setToAmt((Double) result.get(key)); break;
					case "baseEquiv":
						if (result.get(key) != null) forexObject.setBaseEquiv((Double) result.get(key)); break;
					case "fromXrate":
						if (result.get(key) != null) forexObject.setFromXrate((Double) result.get(key)); break;
					case "toXrate":
						if (result.get(key) != null) forexObject.setToXrate((Double) result.get(key)); break;
					case "fromRateFlag":
						if (result.get(key) != null) forexObject.setFromXrateFlag((String) result.get(key)); break;
					case "toRateFlag":
						if (result.get(key) != null) forexObject.setToXrateFlag((String) result.get(key)); break;
					case "fromId":
						if (result.get(key) != null) forexObject.setFromOper((String) result.get(key)); break;
					case "toId":
						if (result.get(key) != null) forexObject.setToOper((String) result.get(key)); break;
					case "captureAmtType":
						if (result.get(key) != null) forexObject.setCaptureAmtType((String) result.get(key)); break;
					case "tranType":
						if (result.get(key) != null) forexObject.setTranType((String) result.get(key)); break;
					case "crossRate":
						if (result.get(key) != null) forexObject.setCrossXrate(new Double(result.get(key).toString().trim())); break;
					case "crossId":
						if (result.get(key) != null) forexObject.setCrossOper((String) result.get(key)); break;
					case "baseCcyBaseAmount":
						if (result.get(key) != null) forexObject.setBaseCcyBaseAmount((Double) result.get(key)); break;
					case "txnId":
						if (result.get(key) != null) forexObject.setTxnId((String) result.get(key)); break;
				}
			}
		}
		return forexObject;
	}

	@Override
	public RecalcTaxObject getRecalcTax(RecalcTaxObject recalcTaxObject) {
		Map<String, Object> result = depTaxHelper.recalcTax(recalcTaxObject.getScType(), recalcTaxObject.getScAmt(), recalcTaxObject.getScTaxAmt(), 
				recalcTaxObject.getCcy(), recalcTaxObject.getAcctNo(), recalcTaxObject.getCertNo());
		
		if(result != null && !result.isEmpty()) {
			for (String key : result.keySet()) {
				switch (key) {
					case "scType":
						if (result.get(key) != null) recalcTaxObject.setScType((String) result.get(key)); break;
					case "scAmt":
						if (result.get(key) != null) recalcTaxObject.setScAmt((Double) result.get(key)); break;
					case "scTaxAmt":
						if (result.get(key) != null) recalcTaxObject.setScTaxAmt((Double) result.get(key)); break;
					case "ccy":
						if (result.get(key) != null) recalcTaxObject.setCcy((String) result.get(key)); break;
					case "acctNo":
						if (result.get(key) != null) recalcTaxObject.setAcctNo((String) result.get(key)); break;
					case "certNo":
						if (result.get(key) != null) recalcTaxObject.setCertNo((String) result.get(key)); break;
				}
			}
		}
		
		return recalcTaxObject;
	}

	@Override
	public CcyConversionObject getEquivalentAmountRate(CcyConversionObject ccyConversionObject) {
		Map<String, Object> result = new HashMap<String, Object>(); 
		if (ccyConversionObject.getCrossRate() != null && ccyConversionObject.getCrossRate() > 0) {
			result = depStorHelper.getMargin(ccyConversionObject.getMarginRate(), ccyConversionObject.getFromAmt(), ccyConversionObject.getCrossRate(), ccyConversionObject.getCrossOper(), 
					ccyConversionObject.getToCcy(), ccyConversionObject.getToAmt());
		} else {
			result = depStorHelper.getEquivalentAmount(ccyConversionObject.getTranType(), ccyConversionObject.getClientNo(), 
					ccyConversionObject.getBranch(), ccyConversionObject.getCrDrInd(), ccyConversionObject.getFromCcy(), ccyConversionObject.getFromAmt(), 
					ccyConversionObject.getToCcy(), ccyConversionObject.getToAmt(), ccyConversionObject.getTranDt(), ccyConversionObject.getCrossOper());
		}
		if(result != null && !result.isEmpty()) {
			for (String key : result.keySet()) {
				switch (key) {
					case "branch":
						if (result.get(key) != null) ccyConversionObject.setBranch((String) result.get(key)); break;
					case "rateType":
						if (result.get(key) != null) ccyConversionObject.setxRateType((String) result.get(key)); break;
					case "effectDate":
						if (result.get(key) != null) ccyConversionObject.setTranDt((Date) result.get(key)); break;
					case "fromCcy":
						if (result.get(key) != null) ccyConversionObject.setFromCcy((String) result.get(key)); break;
					case "fromAmt":
						if (result.get(key) != null) ccyConversionObject.setFromAmt((Double) result.get(key)); break;
					case "toCcy":
						if (result.get(key) != null) ccyConversionObject.setToCcy((String) result.get(key)); break;
					case "toAmt":
						if (result.get(key) != null) ccyConversionObject.setToAmt((Double) result.get(key)); break;
					case "baseEquiv":
						if (result.get(key) != null) ccyConversionObject.setBaseEquiv((Double) result.get(key)); break;
					case "fromXrate":
						if (result.get(key) != null) ccyConversionObject.setFromXRate((Double) result.get(key)); break;
					case "toXrate":
						if (result.get(key) != null) ccyConversionObject.setToXRate((Double) result.get(key)); break;
					case "fromRateFlag":
						if (result.get(key) != null) ccyConversionObject.setFromXRateFlag((String) result.get(key)); break;
					case "toRateFlag":
						if (result.get(key) != null) ccyConversionObject.setToXRateFlag((String) result.get(key)); break;
					case "fromId":
						if (result.get(key) != null) ccyConversionObject.setFromOper((String) result.get(key)); break;
					case "toId":
						if (result.get(key) != null) ccyConversionObject.setToOper((String) result.get(key)); break;
					case "crossRate":
						if (result.get(key) != null) ccyConversionObject.setCrossXRate((Double) result.get(key)); break;
					case "crossId":
						if (result.get(key) != null) ccyConversionObject.setCrossOper((String) result.get(key)); break;
					case "marginRate":
						if (result.get(key) != null) ccyConversionObject.setMarginRate((Double) result.get(key)); break;
				}
			}
		}
		return ccyConversionObject;
	}
	
	@Override
	public RecalcTaxObject getRecalcTaxExt(String scType, Double scAmt, Double scTaxAmt, String ccy, String acctNo, String certNo) {
		RecalcTaxObject recalcTaxObject = new RecalcTaxObject();
		recalcTaxObject.setScType(scType);
		recalcTaxObject.setScAmt(scAmt);
		recalcTaxObject.setScTaxAmt(scTaxAmt);
		recalcTaxObject.setCcy(ccy);
		recalcTaxObject.setAcctNo(acctNo);
		recalcTaxObject.setCertNo(certNo);
		return getRecalcTax(recalcTaxObject);
	}
	
	@Override
	public String calcCasaIntRate(String intType, String crDrInd, String ccy, Double acctLevelIntRate, Double spreadRate) {
		return depAcctOpenMaintHelper.calcCasaIntRate(intType, crDrInd, ccy, acctLevelIntRate, spreadRate);
	}

	@Override
	public String calcTdIntRate(String acctType, String intType, Date effectDate, String ccy,
			Double balAmt, Integer depTermPeriod, String depTermType, Double acctLevelIntRate, Double spreadRate) {
		return depAcctOpenMaintHelper.calcTdIntRate(acctType, intType, effectDate, ccy, balAmt,
				depTermPeriod, depTermType, acctLevelIntRate, spreadRate);
	}

	@Override
	public Long moveFinalRates(String intType, String ccy, Date effectDate) {
		Long errorNo = null;
		Map<String, Object> resultMap = depHousekeepingHelper.moveFinalRates(intType, ccy, effectDate, errorNo);

		if (resultMap != null && !resultMap.isEmpty()) {
			Long retVal = (Long) resultMap.get("errorNo");
			return retVal;
		}

		return null;
	}
}
