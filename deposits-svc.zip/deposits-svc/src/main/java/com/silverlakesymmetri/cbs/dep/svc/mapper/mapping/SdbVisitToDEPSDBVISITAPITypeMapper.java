package com.silverlakesymmetri.cbs.dep.svc.mapper.mapping;

import java.util.List;

import org.mapstruct.MapperConfig;
import org.mapstruct.Mapping;
import org.mapstruct.Mappings;

import com.silverlakesymmetri.cbs.commons.jpa.util.DateTimeHelper;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.SdbVisitJpe;
import com.silverlakesymmetri.cbs.dep.xmlapi.DEPSDBVISITAPIType;

@MapperConfig(uses={ DateTimeHelper.class})
public interface SdbVisitToDEPSDBVISITAPITypeMapper {

	@Mappings({
		@Mapping(target="SEQNO",       			source="seqNo"), 
		@Mapping(target="SDBINTERNALKEY",     	source="sdbInternalKey"), 
		@Mapping(target="VISITDATE",       		source="visitDate", qualifiedByName = {"DateTimeHelper","convertDateToCbsXmlApiDate"}), 
		@Mapping(target="TERMINALID",       	source="terminalId"), 
		@Mapping(target="BRANCH",       		source="branch"), 
		@Mapping(target="OFFICERID",       		source="officerId"), 
		@Mapping(target="TIMEIN",       		source="timeIn", qualifiedByName = {"DateTimeHelper","convertDateToCbsXmlApiDate"}), 
		@Mapping(target="TIMEOUT",       		source="timeOut", qualifiedByName = {"DateTimeHelper","convertDateToCbsXmlApiDate"}), 
		@Mapping(target="TIMEOUTFLAG",   		source="timeInFlag"), 
		@Mapping(target="OVERRIDEOFFICER",      source="overrideOfficer"), 

	 })
	public DEPSDBVISITAPIType mapSdbVisitToDEPSDBVISITAPIType(SdbVisitJpe jpe);
	
	public List<SdbVisitJpe> mapDEPSDBVISITAPITypeListToSdbVisitJpeList(List<DEPSDBVISITAPIType>  api);	
}
