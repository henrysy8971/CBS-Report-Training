package com.silverlakesymmetri.cbs.dep.svc;

import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.svc.BusinessService;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.ChqRejectCode;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.ChqRejectCodeJpe;

import java.util.List;
import java.util.Map;

/**
 * Created by Emerson.Sanchez on 3/5/2019.
 */
public interface ChqRejectCodeService  extends BusinessService<ChqRejectCode, ChqRejectCodeJpe> {
    public static final String SVC_OP_NAME_CHQREJECTCODESERVICE_GET = "ChqRejectCodeService.get";
    public static final String SVC_OP_NAME_CHQREJECTCODESERVICE_QUERY = "ChqRejectCodeService.query";
    public static final String SVC_OP_NAME_CHQREJECTCODESERVICE_CREATE = "ChqRejectCodeService.create";
    public static final String SVC_OP_NAME_CHQREJECTCODESERVICE_UPDATE = "ChqRejectCodeService.update";
    public static final String SVC_OP_NAME_CHQREJECTCODESERVICE_DELETE = "ChqRejectCodeService.delete";
    public static final String SVC_OP_NAME_CHQREJECTCODESERVICE_FIND = "ChqRejectCodeService.find";
    public static final String SVC_OP_NAME_CHQREJECTCODESERVICE_COUNT = "ChqRejectCodeService.count";

    @ServiceOperation(name = SVC_OP_NAME_CHQREJECTCODESERVICE_GET, type = ServiceOperation.ServiceOperationType.GET)
    public ChqRejectCode getByPk(String publicKey, ChqRejectCode reference);

    @ServiceOperation(name = SVC_OP_NAME_CHQREJECTCODESERVICE_CREATE)
    public ChqRejectCode create(ChqRejectCode dataObject);

    @ServiceOperation(name = SVC_OP_NAME_CHQREJECTCODESERVICE_UPDATE)
    public ChqRejectCode update(ChqRejectCode dataObject);

    @ServiceOperation(name = SVC_OP_NAME_CHQREJECTCODESERVICE_QUERY)
    public List<ChqRejectCode> query(int offset, int resultLimit, String groupBy, String order,
                                              Map<String, Object> filters);

    @ServiceOperation(name = SVC_OP_NAME_CHQREJECTCODESERVICE_DELETE)
    public boolean delete(ChqRejectCode dataObject);

    @ServiceOperation(name = SVC_OP_NAME_CHQREJECTCODESERVICE_FIND)
    public List<ChqRejectCode> find(FindCriteria findCriteria, CbsHeader cbsHeader);

    @ServiceOperation(name = SVC_OP_NAME_CHQREJECTCODESERVICE_COUNT, type = ServiceOperation.ServiceOperationType.GET)
    public Long count(FindCriteria findCriteria, CbsHeader cbsHeader);
}
