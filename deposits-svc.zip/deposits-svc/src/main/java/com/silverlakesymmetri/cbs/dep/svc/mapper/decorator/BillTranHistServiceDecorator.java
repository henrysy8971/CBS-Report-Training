package com.silverlakesymmetri.cbs.dep.svc.mapper.decorator;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

import com.silverlakesymmetri.cbs.commons.jpa.service.CbsGenericDataService;
import com.silverlakesymmetri.cbs.commons.xmlapi.enums.CbsXmlApiOperation;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.BillTranHistJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.DepFeeApplyJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.ScDetailOutJpe;
import com.silverlakesymmetri.cbs.dep.svc.mapper.BillTranHistServiceMapper;
import com.silverlakesymmetri.cbs.dep.xmlapi.DEPFEEAPPLYDTLOUTTType;
import com.silverlakesymmetri.cbs.dep.xmlapi.DEPPAYBILLSAPIType;
import com.silverlakesymmetri.cbs.dep.xmlapi.DEPTRANVALIDATIONFLAGSTType;

public abstract class BillTranHistServiceDecorator extends FeeServiceDecorator implements BillTranHistServiceMapper {

	@Autowired
	@Qualifier("delegate")
	protected BillTranHistServiceMapper delegate;

	@Autowired(required = true)
	@Qualifier("cbsGenericDataService")
	protected CbsGenericDataService dataService;

	private final static String DEP_TRAN_HIST_SEQ = "DEP_TRAN_HIST_S";

	@Override
	public DEPPAYBILLSAPIType mapToApi(BillTranHistJpe jpe, CbsXmlApiOperation oper, Map otherInfo) {
		long tranSeqNo = dataService.nextSequenceValue(DEP_TRAN_HIST_SEQ).longValue();
		jpe.setTranSeqNo(tranSeqNo);
		DEPPAYBILLSAPIType req = (DEPPAYBILLSAPIType) delegate.mapToApi(jpe, oper, otherInfo);
		mapFeeToApi(jpe, req);
		
		req.setTRANVALIDATIONFLAGS(new DEPTRANVALIDATIONFLAGSTType());
		req.getTRANVALIDATIONFLAGS().setCHKEFFDATE(jpe.getCheckEffdate() == null ? "N" : jpe.getCheckEffdate());
		req.getTRANVALIDATIONFLAGS().setCHKOVERRIDE(jpe.getCheckOverride() == null ? "N" : jpe.getCheckOverride());
		req.getTRANVALIDATIONFLAGS().setCHKTELLERLIMIT(jpe.getCheckTellerLimit() == null ? "N" : jpe.getCheckTellerLimit());
		req.getTRANVALIDATIONFLAGS().setIGNAVAILBAL(jpe.getIgnoreAvailbal() == null ? "N" : jpe.getIgnoreAvailbal());
		req.getTRANVALIDATIONFLAGS().setIGNRESTRAINT(jpe.getIgnoreRestraint() == null ? "N" : jpe.getIgnoreRestraint());
		
		return req;
	}

	@Override
	public BillTranHistJpe mapToJpe(DEPPAYBILLSAPIType api, BillTranHistJpe jpe) {
		if (jpe == null) {
			jpe = new BillTranHistJpe();
		}
		if (api == null) {
			return jpe;
		}
		delegate.mapToJpe(api, jpe);
		//mapFeeToJpe(api, jpe);
		if (api.getSCDETAILOUT() != null && api.getSCDETAILOUT().getDEPFEEAPPLYDTLOUTT().size() > 0) {
			for (int i = 0; i < api.getSCDETAILOUT().getDEPFEEAPPLYDTLOUTT().size(); i++) {
				DEPFEEAPPLYDTLOUTTType feeApplyOut = api.getSCDETAILOUT().getDEPFEEAPPLYDTLOUTT().get(i);
				ScDetailOutJpe scDetailOut = scDetailOutMapper.mapDEPFEEAPPLYDTLOUTTToScDetailOut(feeApplyOut);
				jpe.getDepFeeApplyList().add(feeApplyMapper.mapDEPFEEAPPLYINToDepFeeApply(api.getSCAPPLYIN()));
				jpe.getDepFeeApplyList().get(i).setScDetailOut(scDetailOut);
			}
		}
		return jpe;
	}

}
