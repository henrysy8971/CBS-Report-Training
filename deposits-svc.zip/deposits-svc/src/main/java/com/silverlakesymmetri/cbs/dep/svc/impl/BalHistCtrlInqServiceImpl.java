package com.silverlakesymmetri.cbs.dep.svc.impl;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mysema.query.types.EntityPath;
import com.silverlakesymmetri.cbs.commons.svc.AbstractXmlApiBusinessService;
import com.silverlakesymmetri.cbs.commons.svc.BusinessObjectValidationCapable;
import com.silverlakesymmetri.cbs.commons.xmlapi.enums.CbsXmlApiOperation;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.AcctClosure;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.BalHistCtrlInq;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.BalHistInq;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.BalStatsInq;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.AcctClosureJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.BalHistCtrlInqJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.BalHistInqJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.OdTmpLimitJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.QBalHistCtrlInqJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.id.BalHistCtrlInqPk;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.util.DepJpeConstants;
import com.silverlakesymmetri.cbs.dep.svc.BalHistCtrlInqService;
import com.silverlakesymmetri.cbs.dep.svc.mapper.AcctClosureServiceMapper;
import com.silverlakesymmetri.cbs.dep.svc.mapper.BalHistCtrlInqServiceMapper;
import com.silverlakesymmetri.cbs.dep.xmlapi.DEPACCTBALHISTQRYAPIType;
import com.silverlakesymmetri.cbs.dep.xmlapi.DEPACCTBALHISTQRYTType;
import com.silverlakesymmetri.cbs.dep.xmlapi.DEPODTMPLIMITAPIType;

@Service
public class BalHistCtrlInqServiceImpl extends AbstractXmlApiBusinessService<BalHistCtrlInq, BalHistCtrlInqJpe, BalHistCtrlInqPk, DEPACCTBALHISTQRYAPIType, DEPACCTBALHISTQRYAPIType> 
	implements BalHistCtrlInqService, BusinessObjectValidationCapable<BalHistCtrlInq> {

	@Autowired
	BalHistCtrlInqServiceMapper mapper;
	
	@Override
	protected EntityPath<BalHistCtrlInqJpe> getEntityPath() {
		return QBalHistCtrlInqJpe.balHistCtrlInqJpe;
	}

	@Override
	protected BalHistCtrlInqPk getIdFromDataObjectInstance(BalHistCtrlInq dataObject) {
		return new BalHistCtrlInqPk(dataObject.getAcctNo(), dataObject.getMonth(), dataObject.getYear()); 
	}
	
	@Override
	protected Class<DEPACCTBALHISTQRYAPIType> getXmlApiResponseClass() {
		return DEPACCTBALHISTQRYAPIType.class;
	}

	@Override
	protected List<BalHistCtrlInq> processXmlApiListRs(BalHistCtrlInq dataObject, DEPACCTBALHISTQRYAPIType xmlApiRs) {
		return null;
	}

	@Override
	protected BalHistCtrlInq processXmlApiRs(BalHistCtrlInq dataObject, DEPACCTBALHISTQRYAPIType xmlApiRs) {
		BalHistCtrlInq bdo = jaxbSdoHelper.createSdoInstance(BalHistCtrlInq.class);
		
		BalHistCtrlInqJpe jpe = jaxbSdoHelper.unwrap(bdo);
		jpe = mapper.mapToJpe(xmlApiRs, jpe);
		
		return jaxbSdoHelper.wrap(jpe);
	}

	
	
	@Override
	public List<BalHistCtrlInq> query(int offset, int resultLimit, String groupBy, String order,
			Map<String, Object> filters) {
		//return super.query(offset, resultLimit, groupBy, order, filters);
		List<BalHistCtrlInq> balHistList = new ArrayList<BalHistCtrlInq>();
		String acctNo = null;
		String month = null;
		String year = null;
		
		if (filters != null) { 
			if (filters.get("acctNo") != null) {
				acctNo = filters.get("acctNo").toString();
				filters.remove("acctNo");
			}
			if (filters.get("month") != null) {
				month = filters.get("month").toString();
				filters.remove("month");
			}
			if (filters.get("year") != null) {
				year = filters.get("year").toString();
				filters.remove("year");
			}
		}
		
		BalHistCtrlInq bdo = jaxbSdoHelper.createSdoInstance(BalHistCtrlInq.class);
		bdo.setAcctNo(acctNo);
		bdo.setMonth(Integer.parseInt(month));
		bdo.setYear(Integer.parseInt(year));
		   
		BalHistCtrlInqJpe jpe = jaxbSdoHelper.unwrap(bdo);
		
		HashMap<String, Object> params = new HashMap<String, Object>();
		params.put("acctNo", jpe.getAcctNo());
		Long internalKey = dataService.getWithNamedQuery(DepJpeConstants.ACCT_JPE_FIND_INTERNAL_KEY_BY_ACCT_NO,
				params, Long.class);
		
		jpe.setInternalKey(internalKey);
		
		DEPACCTBALHISTQRYAPIType xmlApiRq = mapper.mapToApi(jpe, CbsXmlApiOperation.QUERY, new HashMap());
		super.setTechColsFromDataObject(bdo, xmlApiRq);
		balHistList.add(super.queryDataObject(xmlApiRq));
		return balHistList;
		
	}
	
	@Override
	protected BalHistCtrlInq queryDataObject(BalHistCtrlInq dataObject, DEPACCTBALHISTQRYAPIType xmlApiRq) {
		// TODO Auto-generated method stub
		return super.queryDataObject(dataObject, xmlApiRq);
	}

	@Override
	protected DEPACCTBALHISTQRYAPIType transformBdoToXmlApiRqCreate(BalHistCtrlInq arg0) {
		return null;
	}

	@Override
	protected DEPACCTBALHISTQRYAPIType transformBdoToXmlApiRqDelete(BalHistCtrlInq arg0) {
		return null;
	}

	@Override
	protected DEPACCTBALHISTQRYAPIType transformBdoToXmlApiRqUpdate(BalHistCtrlInq arg0) {
		return null;
	}
	
}
