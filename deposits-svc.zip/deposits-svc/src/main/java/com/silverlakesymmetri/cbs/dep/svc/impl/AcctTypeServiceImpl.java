package com.silverlakesymmetri.cbs.dep.svc.impl;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.google.common.collect.ImmutableMap;
import com.mysema.query.types.EntityPath;
import com.mysema.query.types.OrderSpecifier;
import com.mysema.query.types.Predicate;
import com.mysema.query.types.expr.BooleanExpression;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.context.CbsSessionContext;
import com.silverlakesymmetri.cbs.commons.exception.base.CbsServiceProcessException;
import com.silverlakesymmetri.cbs.commons.jpa.mapping.sdo.CbsServiceDataObjectBaseJpe;
import com.silverlakesymmetri.cbs.commons.jpa.util.DateTimeHelper;
import com.silverlakesymmetri.cbs.commons.jpa.util.JpaEntityChangeTracker;
import com.silverlakesymmetri.cbs.commons.svc.AbstractBusinessService;
import com.silverlakesymmetri.cbs.constants.CommonsConstants;
import com.silverlakesymmetri.cbs.csd.jpa.mapping.sdo.IntTypeJpe;
import com.silverlakesymmetri.cbs.csd.jpa.mapping.sdo.util.CsdJpeConstants;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.AcctStatus;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.AcctType;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.ProdOdUtil;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.AcctJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.AcctTypeJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.ProdDefaultJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.QAcctTypeJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.util.DepJpeConstants;
import com.silverlakesymmetri.cbs.dep.jpa.util.DepStorHelper;
import com.silverlakesymmetri.cbs.dep.svc.AcctTypeService;
import com.silverlakesymmetri.cbs.mcl.jpa.mapping.sdo.CategoryHdrJpe;
import com.silverlakesymmetri.cbs.mcl.jpa.mapping.sdo.util.MclJpeConstants;
import com.silverlakesymmetri.cbs.pdm.jpa.mapping.sdo.ContractTypeJpe;
import com.silverlakesymmetri.cbs.pdm.jpa.mapping.sdo.util.ProfitDistributionJpeConstants;
import com.silverlakesymmetri.cbs.pim.jpa.mapping.sdo.ProductCatalogHdrJpe;
import com.silverlakesymmetri.cbs.pim.svc.ProductCatalogHdrService;

import commonj.sdo.ChangeSummary;

@Service
@Transactional
public class AcctTypeServiceImpl extends AbstractBusinessService<AcctType, AcctTypeJpe, String>
		implements AcctTypeService {

	private Map<String, String> statusDescMap;

	@Autowired
	private DateTimeHelper _dtHelper;

	@Autowired
	private DepStorHelper depStorHelper;

	@Autowired
	private ProductCatalogHdrService productCatalogHdrService;

	@Override
	protected EntityPath<AcctTypeJpe> getEntityPath() {
		return QAcctTypeJpe.acctTypeJpe;
	}

	@Override
	protected String getIdFromDataObjectInstance(AcctType dataObject) {
		return dataObject.getAcctType();
	}

	@Override
	public AcctType getByPk(String publicKey, AcctType reference) {
		AcctType result = super.getByPk(publicKey, reference);
		statusDescMap = new HashMap<String, String>();
		statusDescMap.put("I", "Inactive");
		statusDescMap.put("D", "Dormant");
		statusDescMap.put("E", "Escheated");
		if (result.getAcctStatusList() != null) {
			for (AcctStatus status : result.getAcctStatusList()) {
				status.setAcctStatusDesc(statusDescMap.get(status.getAcctStatus()));
			}
		}
		if (result.getProdOdUtilList() != null && result.getProdOdUtilList().size() > 0) {
			Map<String, String> catDescMap = new HashMap<String, String>();
			Map<String, String> intDescMap = new HashMap<String, String>();
			List<String> categoryTypes = new ArrayList<String>();
			List<String> intTypes = new ArrayList<String>();
			Set<String> categoryTypeSet = new HashSet<String>();
			Set<String> intTypeSet = new HashSet<String>();
			for (ProdOdUtil od : result.getProdOdUtilList()) {
				categoryTypeSet.add(od.getCategoryType());
				intTypeSet.add(od.getIntType());
			}
			categoryTypes.addAll(categoryTypeSet);
			intTypes.addAll(intTypeSet);
			Map<String, Object> categoryParams = new HashMap<String, Object>();
			categoryParams.put("categoryTypes", categoryTypes);
			Map<String, Object> intParams = new HashMap<String, Object>();
			intParams.put("intTypes", intTypes);
			List<CategoryHdrJpe> categoryHdrList = dataService.findWithNamedQuery(MclJpeConstants.CATEGORY_HDR_JPE_LIST,
					categoryParams, CategoryHdrJpe.class);
			List<IntTypeJpe> intTypeList = dataService.findWithNamedQuery(CsdJpeConstants.INT_TYPE_JPE_LIST, intParams,
					IntTypeJpe.class);
			if (categoryHdrList != null && categoryHdrList.size() > 0) {
				for (CategoryHdrJpe cat : categoryHdrList) {
					catDescMap.put(cat.getCategoryType(), cat.getCategoryDesc());
				}
			}
			if (intTypeList != null && intTypeList.size() > 0) {
				for (IntTypeJpe iType : intTypeList) {
					intDescMap.put(iType.getIntType(), iType.getIntTypeDesc());
				}
			}
			for (ProdOdUtil od : result.getProdOdUtilList()) {
				od.setCategoryTypeDesc(catDescMap.get(od.getCategoryType()));
				od.setIntTypeDesc(intDescMap.get(od.getIntType()));
			}
		}
		return result;
	}

	@Override
	public AcctType create(AcctType dataObject) {
		ChangeSummary cs = dataObject.getChangeSummary();
		processProductCatalogHdr(dataObject, cs, true, false, false);
		return super.create(dataObject);
	}

	@Override
	public AcctType update(AcctType dataObject) {
		ChangeSummary cs = dataObject.getChangeSummary();
		processProductCatalogHdr(dataObject, cs, false, true, false);
		return super.update(dataObject);
	}

	final String[] acctTypeColumns = { "acctType", "acctTypeDesc", "internalAcctType", "depositType", "reclass",
			"reclassGroup", "callDeposit", "activeYn" };

	@Override
	public List<AcctType> query(int offset, int resultLimit, String groupBy, String order,
			Map<String, Object> filters) {
		List<AcctType> listAcctType = new ArrayList<AcctType>();

		Map<String, Object> acctTypefilters = new HashMap<String, Object>();
		Map<String, Object> prodDefaultfilters = new HashMap<String, Object>();
		Boolean isCasa = null;
		Boolean filterByProdDefault = false;

		if (filters != null && filters.get("isCasa") != null) {
			isCasa = Boolean.parseBoolean(filters.get("isCasa").toString());
			filters.remove("isCasa");
		}

		if (filters != null && filters.get("filterByProdDefault") != null) {
			filterByProdDefault = Boolean.parseBoolean(filters.get("filterByProdDefault").toString());
			filters.remove("filterByProdDefault");
		}

		if (filters != null && filters.size() > 0) {
			for (Map.Entry<String, Object> currFilter : filters.entrySet()) {
				Boolean acctTypeColumn = false;
				acctTypeColumn = checkAcctTypeColumn(currFilter.getKey(), acctTypeColumn);
				if (acctTypeColumn) {
					acctTypefilters.put(currFilter.getKey(), currFilter.getValue());
				} else {
					prodDefaultfilters.put(currFilter.getKey(), currFilter.getValue());
				}
			}
		}

		if (isCasa != null) {
			final List<OrderSpecifier<?>> orders = getOrderSpecifier(QAcctTypeJpe.acctTypeJpe, groupBy, order);
			Predicate predicate = convertMapToPredicate(acctTypefilters, isCasa);
			listAcctType = super.query(QAcctTypeJpe.acctTypeJpe, offset, resultLimit, predicate, orders);
		} else {
			listAcctType = super.query(offset, resultLimit, groupBy, order, acctTypefilters);
		}

		listAcctType = filterByProdDefault(prodDefaultfilters, listAcctType, filterByProdDefault);

		return listAcctType;
	}

	private List<AcctType> filterByProdDefault(Map<String, Object> filters, List<AcctType> listAcctType,
			Boolean filterByProdDefault) {

		List<AcctType> tmpListAcctType = new ArrayList<AcctType>();

		if (filterByProdDefault) {

			if (listAcctType != null && listAcctType.size() > 0) {

				if (filterByProdDefault) {

					StringBuffer customQuery = new StringBuffer(DepJpeConstants.PROD_DEFAULT_JPE_ACCT_TYPE_JPE_QUERY);

					for (Map.Entry<String, Object> filterEntry : filters.entrySet()) {

						final String filterProperty = filterEntry.getKey();
						String parseTab = "b.";
						Boolean acctTypeColumn = false;
						acctTypeColumn = checkAcctTypeColumn(filterProperty, acctTypeColumn);

						if (!acctTypeColumn) {
							customQuery.append(" AND ");
							customQuery.append(parseTab);
							customQuery.append(filterProperty);
							customQuery.append(" = :");
							customQuery.append(filterProperty);
						}

					}

					List<ProdDefaultJpe> listProdDefaultJpe = dataService.findWithQuery(customQuery.toString(),
							ProdDefaultJpe.class, filters, null);
					tmpListAcctType.clear();
					final Map<String, String> acctTypeMap = new HashMap<String, String>();

					if (listProdDefaultJpe != null) {
						for (ProdDefaultJpe prodDefaultJpe : listProdDefaultJpe) {
							acctTypeMap.put(prodDefaultJpe.getAcctType(), prodDefaultJpe.getAcctType());
						}
						if (!acctTypeMap.isEmpty() && acctTypeMap.size() > 0) {
							for (AcctType acctType : listAcctType) {
								if (acctTypeMap.containsValue(acctType.getAcctType())) {
									tmpListAcctType.add(acctType);
								}
							}
						}
					}

					acctTypeMap.clear();

				}

			}

			return tmpListAcctType;

		} else {

			return listAcctType;
		}

	}

	private Boolean checkAcctTypeColumn(final String filterProperty, Boolean acctTypeColumn) {
		for (String elem : acctTypeColumns) {
			if (elem.equals(filterProperty)) {
				acctTypeColumn = true;
				break;
			}
		}
		return acctTypeColumn;
	}

	private Predicate convertMapToPredicate(Map<String, Object> filters, boolean isCasa) {
		Predicate predicate = convertMapToPredicate(QAcctTypeJpe.acctTypeJpe, filters);
		BooleanExpression booleanExpr = null;
		if (isCasa) {
			booleanExpr = QAcctTypeJpe.acctTypeJpe.depositType.in(Arrays.asList("S", "C"));
		} else {
			booleanExpr = QAcctTypeJpe.acctTypeJpe.depositType.eq("T");
		}
		if (predicate != null) {
			predicate = ((BooleanExpression) predicate).and(booleanExpr);
		} else {
			predicate = booleanExpr;
		}
		return predicate;
	}

	@Override
	public boolean delete(AcctType dataObject) {
		ChangeSummary cs = dataObject.getChangeSummary();
		processProductCatalogHdr(dataObject, cs, false, false, true);
		return super.delete(dataObject);
	}

	@Override
	public List<AcctType> find(FindCriteria findCriteria, CbsHeader cbsHeader) {
		return super.find(findCriteria, cbsHeader);
	}

	private void processProductCatalogHdr(AcctType acctType, ChangeSummary cs, boolean isCreated, boolean isUpdated,
			boolean isDeleted) {
		ProductCatalogHdrJpe productCatalogHdrJpe = new ProductCatalogHdrJpe();
		String dataOwner = this.getRegistryValue("ownerCodeOur");

		if (isCreated) {
			String productCategoryCode = (acctType.getDepositType().equals("S")) ? "SAVINGS"
					: (acctType.getDepositType().equals("T")) ? "TERM_DEPOSIT" : "CURRENT";
			productCatalogHdrJpe = new ProductCatalogHdrJpe();
			productCatalogHdrJpe.setDomain(DepJpeConstants.STRING_DEP_DOMAIN);
			productCatalogHdrJpe.setDataOwnerCode(dataOwner);
			productCatalogHdrJpe.setProductTypeCode(acctType.getAcctType());
			productCatalogHdrJpe.setProductCategoryCode(productCategoryCode);
			productCatalogHdrJpe.setProductCode(acctType.getAcctType());
			productCatalogHdrJpe.setProductDesc(acctType.getAcctTypeDesc());
			productCatalogHdrJpe.setStartDt(_dtHelper.getDate(acctType.getStartDt()));
			if (acctType.getEndDt() != null && !(acctType.getEndDt().isEmpty())) {
				productCatalogHdrJpe.setEndDt(_dtHelper.getDate(acctType.getEndDt()));
			} else {
				productCatalogHdrJpe.setEndDt(null);
			}

			if (_dtHelper.getDate(acctType.getStartDt()).compareTo(_dtHelper.getRunDate()) <= 0
					&& (acctType.getEndDt() == null
							|| _dtHelper.getDate(acctType.getEndDt()).compareTo(_dtHelper.getRunDate()) > 0)) {
				productCatalogHdrJpe.setActiveYn(true);
			} else {
				productCatalogHdrJpe.setActiveYn(false);
			}
			productCatalogHdrJpe.setUsedYn(acctType.getUsedYn());
			if (acctType.getInternalAcctType() != null && !(acctType.getInternalAcctType().isEmpty())
					&& "Y".equals(acctType.getInternalAcctType())) {
				productCatalogHdrJpe.setInternalProductTypeYn(true);
			} else {
				productCatalogHdrJpe.setInternalProductTypeYn(false);
			}

			dataService.create(productCatalogHdrJpe);

		} else if (isUpdated) {
			@SuppressWarnings("unchecked")
			List<ChangeSummary.Setting> changedAttrs = cs.getOldValues(acctType);
			Boolean updateYn = false;
			for (ChangeSummary.Setting changeProp : changedAttrs) {
				switch (changeProp.getProperty().getName()) {
				case "acctTypeDesc":
					updateYn = true;
					break;
				case "startDt":
					updateYn = true;
					break;
				case "endDt":
					updateYn = true;
					break;
				default:
				}
			}
			if (updateYn) {
				ProductCatalogHdrJpe prodCatalogHdrJpe = dataService.find(ProductCatalogHdrJpe.class,
						acctType.getAcctType());
				prodCatalogHdrJpe.setProductDesc(acctType.getAcctTypeDesc());
				if (acctType.getEndDt() != null && !(acctType.getEndDt().isEmpty())) {
					prodCatalogHdrJpe.setEndDt(_dtHelper.getDate(acctType.getEndDt()));
				} else {
					prodCatalogHdrJpe.setEndDt(null);
				}
				if (_dtHelper.getDate(acctType.getStartDt()).compareTo(_dtHelper.getRunDate()) <= 1
						&& (acctType.getEndDt() == null
								|| _dtHelper.getDate(acctType.getEndDt()).compareTo(_dtHelper.getRunDate()) > 1)) {
					prodCatalogHdrJpe.setActiveYn(true);
				} else {
					prodCatalogHdrJpe.setActiveYn(false);
				}
				if (prodCatalogHdrJpe.getProductCode() != null) {
					dataService.update(prodCatalogHdrJpe);
				}

			}
		} else if (isDeleted) {
			String productCode = acctType.getAcctType();
			if (acctType.getUsedYn()) {
				productCatalogHdrService.deleteOrDeactivate(productCode, false);
			} else {
				productCatalogHdrService.deleteOrDeactivate(productCode, true);
			}
		}
	}

	private String getRegistryValue(String attr) {
		String result = cbsRuntimeContextManager.getBestAvailableContext()
				.getRegistryEntry(CommonsConstants.CUT_REGISTRY, attr, String.class);
		return result;
	}

	@Override
	public List<AcctType> findToAcctType(Map<String, Object> queryParams) {
		String acctType = (String) queryParams.get("acctType");
		String fromAcctType = (String) queryParams.get("fromAcctType");
		String acctTypeDesc = (String) queryParams.get("acctTypeDesc");
		int limit = queryParams.get("limit") != null ? Integer.parseInt((String) queryParams.get("limit")) : 10;
		int offset = queryParams.get("offset") != null ? Integer.parseInt((String) queryParams.get("offset")) : 0;

		String query = "SELECT a.acctType, a.acctTypeDesc FROM AcctTypeJpe a, ProdDefaultJpe p "
				+ "WHERE a.depositType != 'T' AND a.depositType = (SELECT d.depositType FROM AcctTypeJpe d "
				+ "WHERE d.acctType = :fromAcctType) AND a.acctType != :fromAcctType AND a.acctType = p.acctType "
				+ "AND (((SELECT b.docType FROM ProdDefaultJpe b WHERE b.acctType = :fromAcctType) IS NOT NULL "
				+ "AND p.docType IS NOT NULL) OR (SELECT b.docType FROM ProdDefaultJpe b "
				+ "WHERE b.acctType = :fromAcctType) IS NULL)";

		List<AcctType> result = new ArrayList<AcctType>();
		final Map<String, Object> parameters = new HashMap<>();
		parameters.put("fromAcctType", fromAcctType);

		if (acctType != null) {
			query = query + " AND UPPER(a.acctType) like :acctType";
			parameters.put("acctType", acctType.toUpperCase());
		}

		if (acctTypeDesc != null) {
			query = query + " AND UPPER(a.acctTypeDesc) like :acctTypeDesc";
			parameters.put("acctTypeDesc", acctTypeDesc.toUpperCase());
		}

		query = query + " ORDER BY a.acctType";

		List<AcctType> acctTypes = dataService.findWithQuery(query, parameters, offset, limit, AcctType.class);

		for (Object o : acctTypes) {
			Object[] values = (Object[]) o;
			AcctType acctTypeBdo = jaxbSdoHelper.createSdoInstance(AcctType.class);
			acctTypeBdo.setAcctType((String) values[0]);
			acctTypeBdo.setAcctTypeDesc((String) values[1]);
			result.add(acctTypeBdo);
		}
		return result;
	}

	@Override
	public List<AcctType> findNewAcctTypeForAcctTypeTransfer(Map<String, Object> queryParams) {
		List<AcctType> result = new ArrayList<AcctType>();
		final Map<String, Object> parameters = new HashMap<>();
		String acctNo = (String) queryParams.get("acctNo");
		String acctType = (String) queryParams.get("acctType");
		String acctTypeDesc = (String) queryParams.get("acctTypeDesc");
		int limit = queryParams.get("limit") != null ? Integer.parseInt((String) queryParams.get("limit")) : 10;
		int offset = queryParams.get("offset") != null ? Integer.parseInt((String) queryParams.get("offset")) : 0;

		String query = DepJpeConstants.ACCT_TYPE_CHANGE_NEW_ACCT_TYPE_QUERY;

		Map<String, Object> params = new ImmutableMap.Builder<String, Object>().put("acctNo", acctNo).build();
		AcctJpe acct = dataService.getWithNamedQuery(DepJpeConstants.ACCT_JPE_FIND_BY_ACCTNO, params, AcctJpe.class);
		Date runDate = _dtHelper.getRunDate();

		parameters.put("depAcctDepositType", acct.getDepositType());
		parameters.put("depAcctAcctType", acct.getAcctType());
		parameters.put("depAcctDocType", acct.getDocType());
		parameters.put("depAcctCcy", acct.getCcy());
		parameters.put("runDate", runDate);

		if (acctType != null) {
			query = query + " AND UPPER(a.acctType) like :acctType";
			parameters.put("acctType", acctType.toUpperCase());
		}

		if (acctTypeDesc != null) {
			query = query + " AND UPPER(a.acctTypeDesc) like :acctTypeDesc";
			parameters.put("acctTypeDesc", acctTypeDesc.toUpperCase());
		}

		query = query + " ORDER BY a.acctType";

		List<AcctType> acctTypes = dataService.findWithQuery(query, parameters, offset, limit, AcctType.class);

		for (Object o : acctTypes) {
			Object[] values = (Object[]) o;
			AcctType acctTypeBdo = jaxbSdoHelper.createSdoInstance(AcctType.class);
			acctTypeBdo.setAcctType((String) values[0]);
			acctTypeBdo.setAcctTypeDesc((String) values[1]);
			result.add(acctTypeBdo);
		}
		return result;
	}

	@Override
	protected AcctType preCreateValidation(AcctType dataObject) {

		if (StringUtils.isEmpty(dataObject.getInternalAcctType())) {
			dataObject.setInternalAcctType("N");
		}
		if (StringUtils.isEmpty(dataObject.getReclass())) {
			dataObject.setReclass("N");
		}
		if (StringUtils.isEmpty(dataObject.getCallDeposit())) {
			dataObject.setCallDeposit("N");
		}
		if (StringUtils.isEmpty(dataObject.getIslamicIndicator())) {
			dataObject.setIslamicIndicator("N");
		}

		if (dataObject.getProdDefaultRec() != null) {
			if (StringUtils.isEmpty(dataObject.getProdDefaultRec().getIntInd())) {
				dataObject.getProdDefaultRec().setIntInd("N");
			}
			if (StringUtils.isEmpty(dataObject.getProdDefaultRec().getCheckBalInd())) {
				dataObject.getProdDefaultRec().setCheckBalInd("N");
			}
			if (StringUtils.isEmpty(dataObject.getProdDefaultRec().getCheckOdInd())) {
				dataObject.getProdDefaultRec().setCheckOdInd("N");
			}
			if (StringUtils.isEmpty(dataObject.getProdDefaultRec().getExceedRfLimit())) {
				dataObject.getProdDefaultRec().setExceedRfLimit("N");
			}
			if (StringUtils.isEmpty(dataObject.getProdDefaultRec().getPbEligible())) {
				dataObject.getProdDefaultRec().setPbEligible("N");
			}
			if (StringUtils.isEmpty(dataObject.getProdDefaultRec().getHoldRenew())) {
				dataObject.getProdDefaultRec().setHoldRenew("N");
			}
			if (StringUtils.isEmpty(dataObject.getProdDefaultRec().getHoldRollover())) {
				dataObject.getProdDefaultRec().setHoldRollover("N");
			}
			if (StringUtils.isEmpty(dataObject.getProdDefaultRec().getTdInterestBonf())) {
				dataObject.getProdDefaultRec().setTdInterestBonf("N");
			}
			if (StringUtils.isEmpty(dataObject.getProdDefaultRec().getTdCapOnDec31())) {
				dataObject.getProdDefaultRec().setTdCapOnDec31("N");
			}
			if (StringUtils.isEmpty(dataObject.getProdDefaultRec().getTdCasaRelation())) {
				dataObject.getProdDefaultRec().setTdCasaRelation("N");
			}
			if (StringUtils.isEmpty(dataObject.getProdDefaultRec().getCrossCcySettle())) {
				dataObject.getProdDefaultRec().setCrossCcySettle("N");
			}
			if (StringUtils.isEmpty(dataObject.getProdDefaultRec().getOnMaturityStmt())) {
				dataObject.getProdDefaultRec().setOnMaturityStmt("N");
			}
			if (dataObject.getProdDefaultRec().getPayOthBankIndYn() == null) {
				dataObject.getProdDefaultRec().setPayOthBankIndYn(false);
			}
			if (dataObject.getProdDefaultRec().getCrThirdPartyAllowUpdYn() == null) {
				dataObject.getProdDefaultRec().setCrThirdPartyAllowUpdYn(false);
			}
			if (dataObject.getProdDefaultRec().getPayOthBankIndYn() == false || "T".compareTo(dataObject.getDepositType()) != 0) {
				if (dataObject.getProdIntAcctList() != null) {
					dataObject.getProdIntAcctList().clear();
				}
			}
		}

		AcctTypeJpe jpe = jaxbSdoHelper.unwrap(dataObject);
		prePersistValidation(jpe);

		if (StringUtils.isEmpty(jpe.getContractType())) {
			return super.preCreateValidation(wrap(jpe));
		}

		Map<String, Object> params = new ImmutableMap.Builder<String, Object>()
				.put("contractType", jpe.getContractType()).build();
		ContractTypeJpe ct = dataService.getWithNamedQuery(
				ProfitDistributionJpeConstants.CONTRACT_TYPE_JPE_FIND_BY_CONTRACT_TYPE, params, ContractTypeJpe.class);
		if (ct != null) {
			jpe.setIslamicIndicator(ct.getIslamicInd());
		}

		return super.preCreateValidation(wrap(jpe));
	}

	@Override
	protected AcctType preUpdateValidation(AcctType dataObject) {

		if (StringUtils.isEmpty(dataObject.getInternalAcctType())) {
			dataObject.setInternalAcctType("N");
		}
		if (StringUtils.isEmpty(dataObject.getReclass())) {
			dataObject.setReclass("N");
		}
		if (StringUtils.isEmpty(dataObject.getCallDeposit())) {
			dataObject.setCallDeposit("N");
		}
		if (StringUtils.isEmpty(dataObject.getIslamicIndicator())) {
			dataObject.setIslamicIndicator("N");
		}

		if (dataObject.getProdDefaultRec() != null) {
			if (StringUtils.isEmpty(dataObject.getProdDefaultRec().getIntInd())) {
				dataObject.getProdDefaultRec().setIntInd("N");
			}
			if (StringUtils.isEmpty(dataObject.getProdDefaultRec().getCheckBalInd())) {
				dataObject.getProdDefaultRec().setCheckBalInd("N");
			}
			if (StringUtils.isEmpty(dataObject.getProdDefaultRec().getCheckOdInd())) {
				dataObject.getProdDefaultRec().setCheckOdInd("N");
			}
			if (StringUtils.isEmpty(dataObject.getProdDefaultRec().getExceedRfLimit())) {
				dataObject.getProdDefaultRec().setExceedRfLimit("N");
			}
			if (StringUtils.isEmpty(dataObject.getProdDefaultRec().getPbEligible())) {
				dataObject.getProdDefaultRec().setPbEligible("N");
			}
			if (StringUtils.isEmpty(dataObject.getProdDefaultRec().getHoldRenew())) {
				dataObject.getProdDefaultRec().setHoldRenew("N");
			}
			if (StringUtils.isEmpty(dataObject.getProdDefaultRec().getHoldRollover())) {
				dataObject.getProdDefaultRec().setHoldRollover("N");
			}
			if (StringUtils.isEmpty(dataObject.getProdDefaultRec().getTdInterestBonf())) {
				dataObject.getProdDefaultRec().setTdInterestBonf("N");
			}
			if (StringUtils.isEmpty(dataObject.getProdDefaultRec().getTdCapOnDec31())) {
				dataObject.getProdDefaultRec().setTdCapOnDec31("N");
			}
			if (StringUtils.isEmpty(dataObject.getProdDefaultRec().getTdCasaRelation())) {
				dataObject.getProdDefaultRec().setTdCasaRelation("N");
			}
			if (StringUtils.isEmpty(dataObject.getProdDefaultRec().getCrossCcySettle())) {
				dataObject.getProdDefaultRec().setCrossCcySettle("N");
			}
			if (StringUtils.isEmpty(dataObject.getProdDefaultRec().getOnMaturityStmt())) {
				dataObject.getProdDefaultRec().setOnMaturityStmt("N");
			}
			if (dataObject.getProdDefaultRec().getPayOthBankIndYn() == null) {
				dataObject.getProdDefaultRec().setPayOthBankIndYn(false);
			}
			if (dataObject.getProdDefaultRec().getCrThirdPartyAllowUpdYn() == null) {
				dataObject.getProdDefaultRec().setCrThirdPartyAllowUpdYn(false);
			}
			if (dataObject.getProdDefaultRec().getPayOthBankIndYn() == false || "T".compareTo(dataObject.getDepositType()) != 0) {
				if (dataObject.getProdIntAcctList() != null) {
					dataObject.getProdIntAcctList().clear();
				}
			}
		}

		AcctTypeJpe jpe = jaxbSdoHelper.unwrap(dataObject);
		prePersistValidation(jpe);

		return super.preUpdateValidation(wrap(jpe));
	}

	private void prePersistValidation(AcctTypeJpe jpe) {
		ProdDefaultJpe prodDflt = jpe.getProdDefaultRec();
		JpaEntityChangeTracker prodDfltChangeTracker = dataService
				.getJpaEntityChangeTracker((CbsServiceDataObjectBaseJpe) jpe.getProdDefaultRec());
		Collection<String> changedAttributeNames = prodDfltChangeTracker.getChangedAttributeNames();
		if (prodDflt.getCrActualCapDate() != null && changedAttributeNames != null
				&& changedAttributeNames.contains("crActualCapDate")) {
			Date oldCrNextCycleDate = (Date) prodDfltChangeTracker.getAttributeOldValue("crNextCycleDate");
			String userBranch = cbsRuntimeContextManager.getContext(CbsSessionContext.class).getBranch();
			Long indicator = depStorHelper.validateAcctTypeActualCap(userBranch, jpe.getDepositType(),
					jpe.getAcctType(), prodDflt.getCrIntType(), prodDflt.getCrCapOption(), prodDflt.getCrIntFreq(),
					prodDflt.getCrActualCapDate(), prodDflt.getCrNextCycleDate(), oldCrNextCycleDate);
			if (indicator != null && indicator.longValue() > 0) {
				String msg = messageUtils.getMessage("CBS.B.DEP." + indicator.toString(), new String[] { "" },
						"Invalid Actual capitalisation date");
				CbsServiceProcessException exec = new CbsServiceProcessException("CBS.B.DEP." + indicator.toString(),
						msg);
				throw exec;
			}
		}
	}

}
