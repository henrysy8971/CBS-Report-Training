package com.silverlakesymmetri.cbs.dep.svc.mapper.mapping;

import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.AcctTypeChangeJpe;
import com.silverlakesymmetri.cbs.dep.xmlapi.DEPACCTTYPETFRAPIType;
import org.mapstruct.InheritInverseConfiguration;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Mappings;

/**
 * Created by Emerson.Sanchez on 28/5/2019.
 */
@Mapper
public interface AcctTypeTransferToDEPACCTTYPETFRAPITypeMapper {
    @Mappings({
            @Mapping(target = "oldProfitCentre", source = "OLDPROFITCENTRE"),
            @Mapping(target = "oldTaxType", source = "OLDTAXTYPE"),
            @Mapping(target = "oldAcctType", source = "OLDACCTTYPE"),
            @Mapping(target = "newProfitCentre", source = "NEWPROFITCENTRE"),
            @Mapping(target = "newTaxType", source = "NEWTAXTYPE"),
            @Mapping(target = "newAcctType", source = "NEWACCTTYPE"),
            @Mapping(target = "acctNo", source = "ACCTNO"),
            @Mapping(target = "glNarrative", source ="GLNARRATIVE"),
            @Mapping(target = "autoGenFee", source ="AUTOGENFEE"),
            @Mapping(target = "effectDate", source="EFFECTDATE", qualifiedByName = { "DateTimeHelper", "convertCbsApiDateToString" }),
            @Mapping(target = "seqNo", source ="SEQNO")
            
    })
    public AcctTypeChangeJpe apiTypeToJpe(DEPACCTTYPETFRAPIType apiType);

    @Mappings({
            @Mapping(target = "OLDPROFITCENTRE", source = "oldProfitCentre"),
            @Mapping(target = "OLDTAXTYPE", source = "oldTaxType"),
            @Mapping(target = "OLDACCTTYPE", source = "oldAcctType"),
            @Mapping(target = "NEWPROFITCENTRE", source = "newProfitCentre"),
            @Mapping(target = "NEWTAXTYPE", source = "newTaxType"),
            @Mapping(target = "NEWACCTTYPE", source = "newAcctType"),
            @Mapping(target = "ACCTNO", source = "acctNo"),
            @Mapping(target = "GLNARRATIVE", source ="glNarrative"),
            @Mapping(target = "AUTOGENFEE", source = "autoGenFee"),
            // Cannot map. effectDate is a transient field
            // @Mapping(target = "EFFECTDATE", source = "effectDate", qualifiedByName = {"DateTimeHelper","convertDateToCbsXmlApiDate"}),
            @Mapping(target = "SEQNO", source = "seqNo")
    })
    public DEPACCTTYPETFRAPIType jpeToApiType(AcctTypeChangeJpe jpe);
}
