package com.silverlakesymmetri.cbs.dep.svc.mapper.decorator;


import org.springframework.beans.factory.annotation.Qualifier;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;

import com.silverlakesymmetri.cbs.commons.xmlapi.enums.CbsXmlApiOperation;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.AcctSweepJpe;
import com.silverlakesymmetri.cbs.dep.svc.mapper.AcctSweepServiceMapper;
import com.silverlakesymmetri.cbs.dep.xmlapi.DEPACCTSWEEPAPIType;

public abstract class AcctSweepServiceDecorator extends FeeServiceDecorator implements AcctSweepServiceMapper {
		
		@Autowired
		@Qualifier("delegate")
		protected AcctSweepServiceMapper delegate;
		
		@Override
		public DEPACCTSWEEPAPIType mapToApi(AcctSweepJpe jpe, CbsXmlApiOperation oper, Map otherInfo) {
			DEPACCTSWEEPAPIType req = (DEPACCTSWEEPAPIType)delegate.mapToApi(jpe, oper, otherInfo);
			mapFeeToApi(jpe, req);
			return req;
		}
		
		@Override
		public AcctSweepJpe mapToJpe(DEPACCTSWEEPAPIType api, AcctSweepJpe jpe) {
			if (jpe == null) {
				jpe = new AcctSweepJpe();
			}
			if (api == null) {
				return jpe;
			}
			jpe = delegate.mapToJpe(api, jpe);
			mapFeeToJpe(api, jpe);
			return jpe;
		}
		
}
