package com.silverlakesymmetri.cbs.dep.svc.impl;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Service;

import com.mysema.query.types.EntityPath;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.jpa.entity.FindCriteriaJpe;
import com.silverlakesymmetri.cbs.commons.jpa.util.JaxbDatetimeAdapter;
import com.silverlakesymmetri.cbs.commons.svc.AbstractBusinessService;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.InterModuleTran;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.InterModuleTranJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.QInterModuleTranJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.id.InterModuleTranPk;
import com.silverlakesymmetri.cbs.dep.svc.InterModuleTranService;

@Service
public class InterModuleTranServiceImpl
		extends AbstractBusinessService<InterModuleTran, InterModuleTranJpe, InterModuleTranPk>
		implements InterModuleTranService {

	@Override
	protected EntityPath<InterModuleTranJpe> getEntityPath() {
		return QInterModuleTranJpe.interModuleTranJpe;
	}

	@Override
	protected InterModuleTranPk getIdFromDataObjectInstance(InterModuleTran dataObject) {
		return new InterModuleTranPk(dataObject.getSeqNo(), JaxbDatetimeAdapter.parseDate(dataObject.getEffectDate()));
	}

	@Override
	public InterModuleTran getByPk(String publicKey, InterModuleTran reference) {
		return super.getByPk(publicKey, reference);
	}

	@Override
	public List<InterModuleTran> query(int offset, int resultLimit, String groupBy, String order,
			Map<String, Object> filters) {
		return super.query(offset, resultLimit, groupBy, order, filters);
	}

	@Override
	public List<InterModuleTran> find(FindCriteria findCriteria, CbsHeader cbsHeader) {
		return super.find(findCriteria, cbsHeader);
	}

	@Override
	public Long count(FindCriteria findCriteria, CbsHeader cbsHeader) {
		FindCriteriaJpe fcJpe = jaxbSdoHelper.unwrap(findCriteria, FindCriteriaJpe.class);
		return dataService.getRowCount(InterModuleTranJpe.class, fcJpe);
	}

}
