package com.silverlakesymmetri.cbs.dep.svc.mapper.mapping;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Mappings;

import com.silverlakesymmetri.cbs.commons.jpa.util.DateTimeHelper;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.DepTranOtherDataJpe;
import com.silverlakesymmetri.cbs.dep.xmlapi.DEPTRANOTHERDATATType;

@Mapper(uses = { DateTimeHelper.class })
public interface DepTranOtherDataToDEPTRANOTHERDATATTypeMapper {

	@Mappings({
	    @Mapping(source = "position", target = "POSITION"),
	    @Mapping(source = "fieldName", target = "FIELDNAME"),
	    @Mapping(source = "fieldValue", target = "FIELDVALUE")
	})
	public DEPTRANOTHERDATATType mapTranValidationFlagsToDEPTRANVALIDATIONFLAGST(DepTranOtherDataJpe jpe);
		
}
