package com.silverlakesymmetri.cbs.dep.svc.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.mysema.query.types.EntityPath;
import com.silverlakesymmetri.cbs.commons.svc.AbstractBusinessService;
import com.silverlakesymmetri.cbs.commons.svc.BusinessObjectValidationCapable;
import com.silverlakesymmetri.cbs.commons.svc.ref.ReferenceNumberGeneratorService;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.PretermProfitTypeDtl;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.PretermProfitTypeHdr;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.PretermProfitTypeHdrJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.QPretermProfitTypeHdrJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.id.PretermProfitTypeHdrPk;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.util.DepJpeConstants;
import com.silverlakesymmetri.cbs.dep.svc.PretermProfitTypeHdrService;

@Service
@Transactional
public class PretermProfitTypeHdrServiceImpl extends AbstractBusinessService<PretermProfitTypeHdr, PretermProfitTypeHdrJpe, PretermProfitTypeHdrPk>
	implements PretermProfitTypeHdrService, BusinessObjectValidationCapable<PretermProfitTypeHdr> {

	@Autowired
    private ReferenceNumberGeneratorService referenceNumberGeneratorService;
	
	@Override
	protected EntityPath<PretermProfitTypeHdrJpe> getEntityPath() {
		return QPretermProfitTypeHdrJpe.pretermProfitTypeHdrJpe;
	}

	@Override
	protected PretermProfitTypeHdrPk getIdFromDataObjectInstance(PretermProfitTypeHdr dataObject) {
		Map<String, Object> params = new HashMap<String, Object>();
		params.put("pretermProductGrp", dataObject.getPretermProductGrp());
		params.put("ccy", dataObject.getCcy());
		params.put("effectDate", dataObject.getEffectDate());
		String result = dataService.getWithNamedQuery(DepJpeConstants.PRETERMPROFITTYPEJPE_FIND_REF_NO_BY_PRETERMPRODUCTGRP, params,
			String.class);
		return new PretermProfitTypeHdrPk(result);
	}

	@Override
	public PretermProfitTypeHdr getByPk(String publicKey, PretermProfitTypeHdr reference) {
		return super.getByPk(publicKey, reference);
	}

	@Override
	public List<PretermProfitTypeHdr> query(int offset, int resultLimit, String groupBy, String order,
			Map<String, Object> filters) {
		return super.query(offset, resultLimit, groupBy, order, filters);
	}

	@Override
	public PretermProfitTypeHdr create(PretermProfitTypeHdr arg0) {
		return super.create(arg0);
	}

	@Override
	public PretermProfitTypeHdr update(PretermProfitTypeHdr arg0) {
		return super.update(arg0);
	}

	@Override
	protected PretermProfitTypeHdr preCreateValidation(PretermProfitTypeHdr dataObject) {
		if (dataObject.getPretermProfitTypeHdrRefNo() == null) {
			referenceNumberGeneratorService.getNewRefNo(dataObject, "pretermProfitTypeHdrRefNo");
		}
		
		for (PretermProfitTypeDtl rec: dataObject.getPretermProfitTypeDtlList()) {
			rec.setPretermProfitTypeDtlRefNo(dataObject.getPretermProfitTypeHdrRefNo());
		}
		
		return super.preCreateValidation(dataObject);
	}

	@Override
	protected PretermProfitTypeHdr preUpdateValidation(PretermProfitTypeHdr dataObject) {
		if (dataObject.getPretermProfitTypeHdrRefNo() == null) {
			referenceNumberGeneratorService.getNewRefNo(dataObject, "pretermProfitTypeHdrRefNo");
		}
		
		for (PretermProfitTypeDtl rec: dataObject.getPretermProfitTypeDtlList()) {
			if (rec.getPretermProfitTypeDtlRefNo() == null) {
				rec.setPretermProfitTypeDtlRefNo(dataObject.getPretermProfitTypeHdrRefNo());
			}
		}
		
		return super.preUpdateValidation(dataObject);
	}

	@Override
	public boolean delete(PretermProfitTypeHdr dataObject) {
		return super.delete(dataObject);
	}
	
}
