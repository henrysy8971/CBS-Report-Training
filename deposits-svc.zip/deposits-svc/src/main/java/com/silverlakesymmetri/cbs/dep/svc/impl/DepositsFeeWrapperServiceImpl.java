package com.silverlakesymmetri.cbs.dep.svc.impl;

import com.google.common.collect.ImmutableMap;
import com.mysema.query.types.EntityPath;
import com.silverlakesymmetri.cbs.commons.svc.AbstractBusinessService;
import com.silverlakesymmetri.cbs.csd.jpa.mapping.sdo.ProdScDefJpe;
import com.silverlakesymmetri.cbs.csd.svc.ProdScDefService;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.DepositClient;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.FeeInquiryHdr;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.SdbAcct;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.*;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.util.DepJpeConstants;
import com.silverlakesymmetri.cbs.dep.svc.DepositClientService;
import com.silverlakesymmetri.cbs.dep.svc.DepositsFeeService;
import com.silverlakesymmetri.cbs.dep.svc.DepositsFeeWrapperService;
import com.silverlakesymmetri.cbs.dep.svc.SdbAcctMaintenanceService;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Map;

@Service
public class DepositsFeeWrapperServiceImpl extends AbstractBusinessService<FeeInquiryHdr, FeeInquiryHdrJpe, Long>
        implements DepositsFeeWrapperService {

    private static final String ACCT_NO = "acctNo";
    private static final String TRAN_TYPE = "tranType";
    private static final String ACCT_CCY = "acctCcy";
    private static final String ACCT_TYPE = "acctType";
    private static final String DEPOSIT_TYPE = "depositType";
    private static final String CALC_BAL_TYPE1 = "calcBalType1";
    private static final String CALC_BAL_TYPE2 = "calcBalType2";
    private static final String CALC_BAL1 = "calcBal1";
    private static final String CALC_BAL2 = "calcBal2";
    private static final String PROD_NO = "prodNo";
    private static final String MODULE_ID = "moduleId";
    private static final String SUB_TYPE = "subType";
    private static final String S_PROD_SUB_TYPE = "S";
    private static final String DEP_MODULE = "DEP";
    private static final String A_SUB_TYPE = "A";

    @Autowired
    private DepositsFeeService depositsFeeService;

    @Autowired
    private DepositClientService depositClientService;

    @Autowired
    private SdbAcctMaintenanceService sdbAcctMaintenanceService;

    @Override
    protected EntityPath<FeeInquiryHdrJpe> getEntityPath() {
        return QFeeInquiryHdrJpe.feeInquiryHdrJpe;
    }

    @Override
    protected Long getIdFromDataObjectInstance(FeeInquiryHdr dataObject) {
        return dataObject.getTranNo();
    }

    @Override
    public List<FeeInquiryHdr> query(int offset, int resultLimit, String groupBy, String order, Map<String, Object> filters) {
        FeeInquiryHdr bdo = mapToBdo(filters);
        setProdSubType(bdo);

        EventType eventType = EventType.fromString(bdo.getScEventType());
        if (!(eventType == null || eventType.isNotNeededToDefault())) {
            setAcctFields(bdo);
            setTranFields(bdo);
            setCalcFields(bdo);
            setScFields(bdo);
        }

        if (eventType == EventType.CHQS || eventType == EventType.CHQB) {
            if (bdo.getCalcBal1() == null) {
                if (bdo.getCalcBal2() != null && StringUtils.isNotBlank(bdo.getInput2())) {
                    bdo.setCalcBal1(bdo.getCalcBal2() * Double.parseDouble(bdo.getInput2()));
                }
            }
        }
        return Collections.singletonList(depositsFeeService.feeInquiry(bdo));
    }

    private void setProdSubType(FeeInquiryHdr bdo) {
        EventType eventType = EventType.fromString(bdo.getScEventType());
        if (eventType != null) {
            bdo.setProdSubType(eventType.getProdSubType());
        }
    }

    private void setAcctFields(FeeInquiryHdr bdo) {
        if (S_PROD_SUB_TYPE.equals(bdo.getProdSubType())) {
            return;
        }

        EventType eventType = EventType.fromString(bdo.getScEventType());
        if (eventType == null || !eventType.hasAccountFields()) {
            return;
        }

        Map<String, Object> params = ImmutableMap.of(ACCT_NO, bdo.getProdNo());
        List<AcctJpe> acctJpeList = dataService.findWithNamedQuery(DepJpeConstants.ACCT_JPE_FIND_BY_ACCTNO,
                params, AcctJpe.class);
        if (!(acctJpeList == null || acctJpeList.isEmpty())) {
            AcctJpe acctJpe = acctJpeList.get(0);
            Map<String, String> defaultValues = ImmutableMap.of(
                    ACCT_CCY, acctJpe.getCcy(),
                    ACCT_TYPE, acctJpe.getAcctType(),
                    DEPOSIT_TYPE, acctJpe.getDepositType()
            );

            defaultValues.keySet().forEach(key ->
                    eventType.getAcctFieldsMapping().get(key).forEach(field ->
                            bdo.set(field, defaultValues.get(key))));
        }
    }

    private void setTranFields(FeeInquiryHdr bdo) {
        if (StringUtils.isBlank(bdo.getTranType())) {
            return;
        }

        Map<String, Object> params = ImmutableMap.of(TRAN_TYPE, bdo.getTranType());
        List<TranDefJpe> tranDefJpeList = dataService.find(params, TranDefJpe.class);
        if (!(tranDefJpeList == null || tranDefJpeList.isEmpty())) {
            TranDefJpe tranDefJpe = tranDefJpeList.get(0);
            if (StringUtils.isBlank(bdo.getCrDrMaint())) {
                bdo.setCrDrMaint(tranDefJpe.getCrDrMaintInd());
            }

            EventType eventType = EventType.fromString(bdo.getScEventType());
            if (eventType != null && eventType.hasTranClass() && StringUtils.isBlank(bdo.getInput1())) {
                bdo.setInput1(tranDefJpe.getTranClass());
            }
        }
    }

    private void setCalcFields(FeeInquiryHdr bdo) {
        EventType eventType = EventType.fromString(bdo.getScEventType());
        if (eventType == null || eventType.getCalcFieldsDefaultValue().isEmpty()) {
            return;
        }

        eventType.getCalcFieldsDefaultValue().forEach(bdo::set);
    }

    private void setScFields(FeeInquiryHdr bdo) {
        EventType eventType = EventType.fromString(bdo.getScEventType());
        if (eventType == null) {
            return;
        }

        if (eventType.isUsingAcctNo()) {
            Map<String, Object> params = ImmutableMap.of(
                    PROD_NO, bdo.getProdNo(),
                    MODULE_ID, DEP_MODULE,
                    SUB_TYPE, A_SUB_TYPE
            );

            List<ProdScDefJpe> prodScDefJpeList = dataService.find(params, ProdScDefJpe.class);
            if (!(prodScDefJpeList == null || prodScDefJpeList.isEmpty())) {
                ProdScDefJpe prodScDefJpe = prodScDefJpeList.get(0);
                bdo.setInput3(prodScDefJpe.getScGroupCode());
            }
        } else if (eventType.isUsingClientNo()) {
            DepositClient depositClient = depositClientService.getByPk(bdo.getProdNo(), null);
            if (depositClient != null) {
                bdo.setInput2(depositClient.getScGroup());
                bdo.setInput3(depositClient.getScPackType());
            }
        } else if (eventType.isUsingContractNo()) {
            SdbAcct sdbAcct = sdbAcctMaintenanceService.getByPk(bdo.getProdNo(), null);
            if (sdbAcct != null) {
                DepositClient depositClient = depositClientService.getByPk(sdbAcct.getClientNo(), null);
                if (depositClient != null) {
                    bdo.setInput2(depositClient.getScGroup());
                    bdo.setInput3(depositClient.getScPackType());
                }
            }
        }
    }

    private FeeInquiryHdr mapToBdo(Map<String, Object> map) {
        FeeInquiryHdr bdo = jaxbSdoHelper.createSdoInstance(FeeInquiryHdr.class);
        map.forEach(bdo::set);
        return bdo;
    }

    private enum EventType {
        ACCL("A",
                ImmutableMap.of(
                        ACCT_CCY, Collections.singletonList("tranCcy"),
                        DEPOSIT_TYPE, Collections.singletonList("input1"),
                        ACCT_TYPE, Collections.singletonList("input2")
                )) {
            @Override
            public Map<String, Object> getCalcFieldsDefaultValue() {
                return ImmutableMap.of(
                        CALC_BAL_TYPE1, "CO",
                        CALC_BAL1, 1.0
                );
            }
        },
        CHQI("A",
                ImmutableMap.of(
                        ACCT_CCY, Collections.singletonList("tranCcy"),
                        DEPOSIT_TYPE, Collections.singletonList("input1"),
                        ACCT_TYPE, Collections.singletonList("input2")
                )) {
            @Override
            public Map<String, Object> getCalcFieldsDefaultValue() {
                return ImmutableMap.of(
                        CALC_BAL_TYPE1, "CO"
                );
            }
        },
        CHQP("~") {
            @Override
            public Map<String, Object> getCalcFieldsDefaultValue() {
                return ImmutableMap.of(
                        CALC_BAL_TYPE1, "TA",
                        CALC_BAL_TYPE2, "CO",
                        CALC_BAL2, 1.0
                );
            }
        },
        CHQU("~") {
            @Override
            public Map<String, Object> getCalcFieldsDefaultValue() {
                return ImmutableMap.of(
                        CALC_BAL_TYPE1, "TA",
                        CALC_BAL_TYPE2, "CO",
                        CALC_BAL2, 1.0
                );
            }
        },
        CHQB("~") {
            @Override
            public Map<String, Object> getCalcFieldsDefaultValue() {
                return ImmutableMap.of(
                        CALC_BAL_TYPE1, "TA",
                        CALC_BAL_TYPE2, "CO"
                );
            }
        },
        CHQS("~") {
            @Override
            public Map<String, Object> getCalcFieldsDefaultValue() {
                return ImmutableMap.of(
                        CALC_BAL_TYPE1, "TA",
                        CALC_BAL_TYPE2, "CO"
                );
            }
        },
        FNTR(null),
        MSTR(null) {
            @Override
            public Map<String, Object> getCalcFieldsDefaultValue() {
                return ImmutableMap.of(
                        CALC_BAL_TYPE1, "CO",
                        CALC_BAL1, 1.0,
                        CALC_BAL_TYPE2, "TA"
                );
            }
        },
        SDBB("S") {
            @Override
            public Map<String, Object> getCalcFieldsDefaultValue() {
                return ImmutableMap.of(
                        CALC_BAL_TYPE1, "CO",
                        CALC_BAL1, 1.0
                );
            }
        },
        SDBF("~") {
            @Override
            public Map<String, Object> getCalcFieldsDefaultValue() {
                return ImmutableMap.of(
                        CALC_BAL_TYPE1, "CO",
                        CALC_BAL1, 1.0
                );
            }
        },
        SOPC("A",
                ImmutableMap.of(
                        ACCT_CCY, Arrays.asList("tranCcy", "calcBalCcy2"),
                        DEPOSIT_TYPE, Collections.singletonList("input1"),
                        ACCT_TYPE, Collections.singletonList("input2")
                )) {
            @Override
            public Map<String, Object> getCalcFieldsDefaultValue() {
                return ImmutableMap.of(
                        CALC_BAL_TYPE1, "CO",
                        CALC_BAL1, 1.0,
                        CALC_BAL_TYPE2, "TA"
                );
            }
        },
        SOPM("A",
                ImmutableMap.of(
                        ACCT_CCY, Arrays.asList("tranCcy", "calcBalCcy2"),
                        DEPOSIT_TYPE, Collections.singletonList("input1"),
                        ACCT_TYPE, Collections.singletonList("input2")
                )) {
            @Override
            public Map<String, Object> getCalcFieldsDefaultValue() {
                return ImmutableMap.of(
                        CALC_BAL_TYPE1, "CO",
                        CALC_BAL1, 1.0,
                        CALC_BAL_TYPE2, "TA"
                );
            }
        },
        SOPO("A",
                ImmutableMap.of(
                        ACCT_CCY, Arrays.asList("tranCcy", "calcBalCcy2"),
                        DEPOSIT_TYPE, Collections.singletonList("input1"),
                        ACCT_TYPE, Collections.singletonList("input2")
                )) {
            @Override
            public Map<String, Object> getCalcFieldsDefaultValue() {
                return ImmutableMap.of(
                        CALC_BAL_TYPE1, "CO",
                        CALC_BAL1, 1.0,
                        CALC_BAL_TYPE2, "TA"
                );
            }
        },
        TDPR("~",
                ImmutableMap.of(
                        ACCT_CCY, Arrays.asList("tranCcy", "calcBalCcy1"),
                        DEPOSIT_TYPE, Collections.singletonList("input1"),
                        ACCT_TYPE, Collections.singletonList("input2")
                )) {
            @Override
            public Map<String, Object> getCalcFieldsDefaultValue() {
                return ImmutableMap.of(
                        CALC_BAL_TYPE1, "TA"
                );
            }
        };

        private String prodSubType;
        private Map<String, List<String>> acctFieldsMapping;

        EventType(String prodSubType, Map<String, List<String>> acctFieldsMapping) {
            this.prodSubType = prodSubType;
            this.acctFieldsMapping = acctFieldsMapping;
        }

        EventType(String prodSubType) {
            this(prodSubType, Collections.emptyMap());
        }

        public String getProdSubType() {
            return prodSubType;
        }

        public boolean isNotNeededToDefault() {
            return this == FNTR;
        }

        public boolean hasAccountFields() {
            return Arrays.asList(ACCL, SOPC, SOPM, SOPO, TDPR).contains(this);
        }

        public boolean hasTranClass() {
            return this == MSTR;
        }

        public boolean isUsingAcctNo() {
            return hasAccountFields();
        }

        public boolean isUsingClientNo() {
            return this == SDBF;
        }

        public boolean isUsingContractNo() {
            return this == SDBB;
        }

        public Map<String, List<String>> getAcctFieldsMapping() {
            return acctFieldsMapping;
        }

        public Map<String, Object> getCalcFieldsDefaultValue() {
            return Collections.emptyMap();
        }

        public static EventType fromString(String eventType) {
            for (EventType e : EventType.values()) {
                if (e.name().equals(eventType)) {
                    return e;
                }
            }
            return null;
        }
    }
}
