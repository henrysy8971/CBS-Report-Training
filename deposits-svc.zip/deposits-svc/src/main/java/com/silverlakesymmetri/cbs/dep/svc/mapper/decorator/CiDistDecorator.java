package com.silverlakesymmetri.cbs.dep.svc.mapper.decorator;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

import com.silverlakesymmetri.cbs.commons.xmlapi.enums.CbsXmlApiOperation;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.CiRdBunchCaptureJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.CiRdRegJpe;
import com.silverlakesymmetri.cbs.dep.svc.mapper.CiDistMapper;
import com.silverlakesymmetri.cbs.dep.svc.mapper.mapping.CiRdBunchCaptureToDEPCIRDBUNCHAPITypeMapper;
import com.silverlakesymmetri.cbs.dep.xmlapi.DEPCIRDAPIType;
import com.silverlakesymmetri.cbs.dep.xmlapi.DEPCIRDBUNCHCOLLType;
import com.silverlakesymmetri.cbs.dep.xmlapi.DEPCIRDBUNCHTType;

public abstract class CiDistDecorator implements CiDistMapper{
	
	@Autowired
	@Qualifier("delegate")
	protected  CiDistMapper delegate;
	
	@Autowired
	protected CiRdBunchCaptureToDEPCIRDBUNCHAPITypeMapper mapper;
	
	@Override
	public DEPCIRDAPIType mapToApi(CiRdRegJpe jpe, CbsXmlApiOperation oper, Map otherInfo){
		
		DEPCIRDAPIType req = (DEPCIRDAPIType)delegate.mapToApi(jpe, oper, otherInfo);
		req.setCIRDBUNCHLIST(getDEPCIRDBUNCHCOLLType(  oper,  otherInfo));
			
		return  req;
	}
	
	private DEPCIRDBUNCHCOLLType getDEPCIRDBUNCHCOLLType( CbsXmlApiOperation oper, Map otherInfo){
		
		if (otherInfo == null || otherInfo.isEmpty() || !otherInfo.containsKey("CiRdBunchCaptureJpeList")){
			return null;
		}
		
		List<CiRdBunchCaptureJpe> list = (ArrayList<CiRdBunchCaptureJpe>)otherInfo.get("CiRdBunchCaptureJpeList");
		List<DEPCIRDBUNCHTType> coll = new ArrayList<DEPCIRDBUNCHTType>();
		for (CiRdBunchCaptureJpe item : list ){
			coll.add(mapper.mapCiRdBunchRegToDEPCIRDBUNCHAPIType(item, oper));
		}
		
		DEPCIRDBUNCHCOLLType wrap = new DEPCIRDBUNCHCOLLType();
		wrap.getDEPCIRDBUNCHT().addAll(coll);
		return wrap;
	}

}


