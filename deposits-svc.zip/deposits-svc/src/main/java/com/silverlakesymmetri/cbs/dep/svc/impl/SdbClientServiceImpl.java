package com.silverlakesymmetri.cbs.dep.svc.impl;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.mysema.query.types.EntityPath;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.helper.jpa.LinkTable;
import com.silverlakesymmetri.cbs.commons.helper.jpa.QueryCondition;
import com.silverlakesymmetri.cbs.commons.helper.jpa.QueryType;
import com.silverlakesymmetri.cbs.commons.svc.AbstractBusinessService;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.DepositClient;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.SdbAcctJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.SdbAssigneeJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.SdbLicenseeJpe;
import com.silverlakesymmetri.cbs.dep.svc.SdbClientService;
import com.silverlakesymmetri.cbs.mcl.bdo.sdo.Client;
import com.silverlakesymmetri.cbs.mcl.jpa.mapping.sdo.ClientJpe;
import com.silverlakesymmetri.cbs.mcl.jpa.mapping.sdo.QClientJpe;

@Service
@Transactional
public class SdbClientServiceImpl extends AbstractBusinessService<Client, ClientJpe, String> implements SdbClientService{
   
	@Override
	protected String getIdFromDataObjectInstance(Client dataObject) {
		return dataObject.getClientNo();
	}

	@Override
	protected EntityPath<ClientJpe> getEntityPath() {
		return QClientJpe.clientJpe;
	}
	
	@Override
	public List<Client> find(FindCriteria findCriteria, CbsHeader cbsHeader) {
		return super.find(findCriteria, cbsHeader);
	}
	
	@Override
	public List<Client> query(int offset, int resultLimit, String groupBy, String order,
			Map<String, Object> filters) {
		
		List<Client> list = new ArrayList<>();
			
		if (filters != null && filters.containsKey("listType")) {
			
			String listType = filters.remove("listType").toString();
			
			if (listType.toUpperCase().matches("SDBAUTHORIZED")) {
				String sdbInternalKey = filters.remove("sdbInternalKey").toString();								
				filters.put("sdbInternalKey", Long.parseLong(sdbInternalKey));
				list = (List<Client>) this.getSdbVisitAuthorize(offset, resultLimit, filters);
			}
			
		} else {
			list = super.query(offset, resultLimit, groupBy, order, filters);
		}
		
		return list;
	}
	
	private List<Client> getSdbVisitAuthorize(int offset, int resultLimit, Map<String, Object> filters) {
		List<Client> sdbAuthList = new ArrayList<>();
		String querySdbAcct = "SELECT fc"
				+ " FROM SdbAcctJpe ra, ClientJpe fc" 
				+ " WHERE ra.sdbInternalKey = :sdbInternalKey" 
				+ " AND ra.clientId = fc.clientId";
		String queryLicensee = " UNION"
				+ " SELECT fc"
				+ " FROM SdbLicenseeJpe rsl, ClientJpe fc"
				+ " WHERE rsl.sdbInternalKey = :sdbInternalKey"
				+ " AND rsl.clientId = fc.clientId";
		String queryAssignee = " UNION"
				+ " SELECT fc"
				+ " FROM SdbAssigneeJpe rsa, ClientJpe fc"
				+ " WHERE rsa.sdbInternalKey = :sdbInternalKey"
				+ " AND rsa.clientId = fc.clientId";
		
		StringBuilder criteria = new StringBuilder(querySdbAcct);
			
		if (filters.containsKey("clientNo")){
    		filters.put("clientNo", filters.get("clientNo"));
    		criteria.append(" AND fc.clientNo = :clientNo");
    		criteria.append(queryLicensee);
    		criteria.append(" AND fc.clientNo = :clientNo");
    		criteria.append(queryAssignee);
    		criteria.append(" AND fc.clientNo = :clientNo");
    	} else {
    		criteria.append(queryLicensee);
    		criteria.append(queryAssignee);
    	}
				
		List<ClientJpe> jpeList = (List<ClientJpe>) dataService.findWithQuery(criteria.toString(), filters, offset, resultLimit, ClientJpe.class);
		if (jpeList != null && jpeList.size() > 0) {
			for (ClientJpe jpe : jpeList) {
				sdbAuthList.add(jaxbSdoHelper.wrap(jpe, Client.class));	
			}
		}
		
		return sdbAuthList;
	}

}
