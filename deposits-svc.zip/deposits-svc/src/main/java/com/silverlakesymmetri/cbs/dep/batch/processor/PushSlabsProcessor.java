package com.silverlakesymmetri.cbs.dep.batch.processor;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.beans.factory.annotation.Autowired;
import com.silverlakesymmetri.cbs.commons.jpa.service.CbsBatchGenericDataService;
import com.silverlakesymmetri.cbs.pdm.jpa.mapping.sdo.ContractTypeJpe;
import com.silverlakesymmetri.cbs.pdm.bdo.sdo.DummyBdo;
import com.silverlakesymmetri.cbs.pdm.svc.PoolService;

public class PushSlabsProcessor implements ItemProcessor<ContractTypeJpe, ContractTypeJpe> {

    @Autowired
    private PoolService poolService;

    @Autowired
    private CbsBatchGenericDataService batchDataService;

    @Override
    public ContractTypeJpe process(ContractTypeJpe contractTypes) {

        int limit = 999999999;
        int offset = 0;
        System.out.println("Loading Contract Type Slabs " + contractTypes.getContractType());

        if (contractTypes.getContractType().equals("MUD")) {
            String query = "SELECT  a.intMatrixDtlRefNo, a.intType, a.ccy, a.effectDate, a.balance, a.termType, a.termPeriod FROM IntMatrixDtlJpe a ";
            final Map<String, Object> parameters = new HashMap<>();
            List<DummyBdo> data = batchDataService.findWithQuery(query, parameters, offset, limit, DummyBdo.class);
            poolService.loadSlabs(data, "TD");
            data.clear();
            query = "SELECT  a.intRateDtlRefNo, a.intType, a.ccy, a.effectDate, a.balance FROM IntRateDtlJpe a "
                    + " INNER JOIN IntTypeJpe b ON (a.intType = b.intType) "
                    + "WHERE b.crDrInd='C'";

            data = batchDataService.findWithQuery(query, parameters, offset, limit, DummyBdo.class);
            poolService.loadSlabs(data, "CS");
        }
        return contractTypes;
    }

}
