package com.silverlakesymmetri.cbs.dep.batch.listener;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.batch.core.ItemProcessListener;
import org.springframework.batch.core.StepExecution;

import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.MessageQJpe;
import com.silverlakesymmetri.cbs.xps.svc.batch.listener.AbstractMessageQueueProcessorListener;

public class DepAutoSendMessageProcessorListener extends AbstractMessageQueueProcessorListener<MessageQJpe, MessageQJpe>
		implements ItemProcessListener<MessageQJpe, MessageQJpe> {

	@Override
	public void beforeStep(StepExecution stepExecution) {
		super.beforeStep(stepExecution);

		// add MessageQueueListItemProcessor field values for binding
		//this.stepExecution.getExecutionContext().put(MessageQueueListItemProcessor.SWIFT_FILE_NAME_ATTR, getSwiftSpoolFileName());
	}

}
