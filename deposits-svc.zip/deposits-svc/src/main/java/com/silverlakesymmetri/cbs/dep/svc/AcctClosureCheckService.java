package com.silverlakesymmetri.cbs.dep.svc;

import java.util.List;
import java.util.Map;
import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation;
import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation.ServiceOperationType;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.svc.BusinessService;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.AcctClosureCheck;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.AcctClosureCheckJpe;

public interface AcctClosureCheckService extends BusinessService<AcctClosureCheck, AcctClosureCheckJpe> {

    public static final String SVC_OP_NAME_ACCTCLOSURECHECKSERVICE_FINDALL = "AcctClosureCheckService.findAll";
    public static final String SVC_OP_NAME_ACCTCLOSURECHECKSERVICE_GET = "AcctClosureCheckService.get";
    public static final String SVC_OP_NAME_ACCTCLOSURECHECKSERVICE_QUERY = "AcctClosureCheckService.query";

    @ServiceOperation(name = SVC_OP_NAME_ACCTCLOSURECHECKSERVICE_FINDALL, type = ServiceOperationType.GET)
    public List<AcctClosureCheck> findAll(String acctNo, CbsHeader cbsHeader);

    @ServiceOperation(name = SVC_OP_NAME_ACCTCLOSURECHECKSERVICE_GET, type = ServiceOperationType.GET)
    public AcctClosureCheck getByPk(String acct, AcctClosureCheck acctClosureCheck);

    @ServiceOperation(name = SVC_OP_NAME_ACCTCLOSURECHECKSERVICE_QUERY, type = ServiceOperationType.GET)
    public List<AcctClosureCheck> query(int offset, int resultLimit, String groupBy, String order, Map<String, Object> filters);
    
}
