package com.silverlakesymmetri.cbs.dep.svc.impl;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.mysema.query.types.EntityPath;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.bdo.ViewCriteriaItem;
import com.silverlakesymmetri.cbs.commons.bdo.ViewCriteriaRow;
import com.silverlakesymmetri.cbs.commons.helper.jpa.LinkTable;
import com.silverlakesymmetri.cbs.commons.helper.jpa.QueryCondition;
import com.silverlakesymmetri.cbs.commons.helper.jpa.QueryType;
import com.silverlakesymmetri.cbs.commons.jpa.entity.ConjunctionEnumJpe;
import com.silverlakesymmetri.cbs.commons.jpa.entity.FindCriteriaJpe;
import com.silverlakesymmetri.cbs.commons.jpa.entity.ViewCriteriaItemJpe;
import com.silverlakesymmetri.cbs.commons.jpa.entity.ViewCriteriaJpe;
import com.silverlakesymmetri.cbs.commons.jpa.entity.ViewCriteriaRowJpe;
import com.silverlakesymmetri.cbs.commons.jpa.service.impl.BusinessDataObjectJpaQueryComponentImpl;
import com.silverlakesymmetri.cbs.commons.jpa.util.DateTimeHelper;
import com.silverlakesymmetri.cbs.commons.svc.AbstractBusinessService;
import com.silverlakesymmetri.cbs.commons.svc.util.InMemoryQueryExecutor;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.AcctSignatoryInfo;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.TranDef;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.AcctJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.AcctSignatoryInfoJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.JointAcctJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.QAcctSignatoryInfoJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.SdbAcctJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.SdbAssigneeJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.id.AcctSignatoryInfoPk;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.util.DepJpeConstants;
import com.silverlakesymmetri.cbs.dep.svc.AcctSignatoryInfoService;
import com.silverlakesymmetri.cbs.mcl.bdo.sdo.Client;
import com.silverlakesymmetri.cbs.mcl.bdo.sdo.ClientSignatory;
import com.silverlakesymmetri.cbs.mcl.jpa.mapping.sdo.ClientJpe;
import com.silverlakesymmetri.cbs.mcl.jpa.mapping.sdo.ClientSignatoryJpe;
import com.silverlakesymmetri.cbs.mcl.jpa.mapping.sdo.util.MclJpeConstants;
import com.silverlakesymmetri.cbs.mcl.svc.ClientService;
import com.silverlakesymmetri.cbs.mcl.svc.ClientSignatoryService;

@Service
@Transactional
public class AcctSignatoryInfoServiceImpl extends AbstractBusinessService<AcctSignatoryInfo, AcctSignatoryInfoJpe, AcctSignatoryInfoPk> implements AcctSignatoryInfoService {
	
	private static final String ACCT = "Acct";
	private static final String SDBACCT = "SdbAcct";

	@Autowired
	ClientSignatoryService clientSignatoryService;

	@Autowired
	ClientService clientService;

	@Autowired
	DateTimeHelper dateTimeHelper;
	
	private static LinkedHashMap<String, LinkTable> constructorMap;
    private static QueryCondition condition;

    static {
        constructorMap = new LinkedHashMap<String, LinkTable>();
        constructorMap.put("refObjectType", new LinkTable(AcctSignatoryInfoJpe.class));
        constructorMap.put("refObjectKey", new LinkTable(AcctSignatoryInfoJpe.class));
        constructorMap.put("clientId", new LinkTable(AcctSignatoryInfoJpe.class));
        constructorMap.put("clientNo", new LinkTable(ClientJpe.class));
        constructorMap.put("signatoryNo", new LinkTable(AcctSignatoryInfoJpe.class));
        constructorMap.put("signatoryName", new LinkTable(ClientSignatoryJpe.class));
        constructorMap.put("mandatoryYn", new LinkTable(AcctSignatoryInfoJpe.class));
        constructorMap.put("startDt", new LinkTable(AcctSignatoryInfoJpe.class));
        constructorMap.put("endDt", new LinkTable(AcctSignatoryInfoJpe.class));
        constructorMap.put("bizVersion", new LinkTable(AcctSignatoryInfoJpe.class));
        constructorMap.put("limitAmt", new LinkTable(AcctSignatoryInfoJpe.class));
        constructorMap.put("remark", new LinkTable(AcctSignatoryInfoJpe.class));
        
        condition = new QueryCondition();
        condition.where("clientId", QueryType.EQUALS, new LinkTable(ClientSignatoryJpe.class, "clientId"))
                .and("signatoryNo", QueryType.EQUALS, new LinkTable(ClientSignatoryJpe.class, "signatoryNo"))
        		.and("clientId", QueryType.EQUALS, new LinkTable(ClientJpe.class, "clientId"));
    }

	@Override
	protected EntityPath<AcctSignatoryInfoJpe> getEntityPath() {
		return QAcctSignatoryInfoJpe.acctSignatoryInfoJpe;
	}

	@Override
	protected AcctSignatoryInfoPk getIdFromDataObjectInstance(AcctSignatoryInfo dataObject) {
		AcctSignatoryInfoJpe jpe = jaxbSdoHelper.unwrap(dataObject, AcctSignatoryInfoJpe.class);
		return new AcctSignatoryInfoPk(dataObject.getRefObjectType(), dataObject.getRefObjectKey(), jpe.getClientId(), dataObject.getSignatoryNo());
	}

	@Override
	public AcctSignatoryInfo getByPk(String publicKey, AcctSignatoryInfo reference) {
		AcctSignatoryInfo bdo = super.getByPk(publicKey, reference);
		ClientSignatory sig = clientSignatoryService.getByPk(bdo.getClientSignatoryRec().getPublicKey(), bdo.getClientSignatoryRec());
		bdo.setClientSignatoryRec(sig);
		return bdo;
	}
	
	@Override
	public AcctSignatoryInfo preCreateValidation(AcctSignatoryInfo dataObject) {
		dataObject.setClientSignatoryRec(null);
		if(dataObject.getEndDt() == null){
			dataObject.setEndDt("2999-12-31T00:00:00.000Z");
		}
		return super.preCreateValidation(dataObject);
	}

	@Override
	public AcctSignatoryInfo create(AcctSignatoryInfo dataObject) {
		AcctSignatoryInfo result = super.create(dataObject);
		ClientSignatory sig = clientSignatoryService.getByPk(result.getClientNo()+"~"+result.getSignatoryNo(), null);
		if(sig != null){
			sig.getChangeSummary().beginLogging();
			sig.setUsedYn(true);
			clientSignatoryService.update(sig);
		}
		return result;
	}
	
	@Override
	public List<AcctSignatoryInfo> query(int offset, int resultLimit, String groupBy, String order, Map<String, Object> filters) {
        QueryCondition newCondition = convertFilters(condition, filters, constructorMap);
        return super.query(newCondition, offset, resultLimit,  groupBy, order, constructorMap);
	}

	@Override
	public AcctSignatoryInfo update(AcctSignatoryInfo dataObject) {
		if(dataObject.getEndDt() == null){
			dataObject.setEndDt(dataObject.getStartDt());
		}
		return super.update(dataObject);
	}
	
	@Override
	public boolean delete(AcctSignatoryInfo dataObject) {
		return super.delete(dataObject);
	}

	@Override
	public List<AcctSignatoryInfo> find(FindCriteria findCriteria, CbsHeader cbsHeader) {
		return super.find(findCriteria, cbsHeader, constructorMap, condition);
	}

	@Override
	public int bulkDelete(Map<String, Object> filters) {
		int deleteCount = 0;

		if (filters == null || filters.isEmpty()) {
			return deleteCount;
		}

		List<AcctSignatoryInfo> bdoList = query(0, -1, null, null, filters);
		if (bdoList == null || bdoList.isEmpty()) {
			return deleteCount;
		}

		for (AcctSignatoryInfo bdo: bdoList) {
			super.delete(bdo);
			deleteCount ++;
		}

		return deleteCount;
	}

	@Override
	public List<Client> getClientsForAcct(Map<String, Object> filters) {
		String refObjectType = filters.get("refObjectType") != null ? filters.get("refObjectType").toString() : null;
		String refObjectKey = filters.get("refObjectKey") != null ? filters.get("refObjectKey").toString() : null;
		String groupBy = filters.get("groupBy") != null ? filters.get("groupBy").toString() : null;
		String order = filters.get("order") != null ? filters.get("order").toString() : null;
		int resultLimit = 10;
		if(filters.get("limit") != null){
			try {
				resultLimit = Integer.parseInt(filters.get("limit").toString());
			} catch (NumberFormatException e) {}
		}
		int offset = 0;
		if(filters.get("limit") != null){
			try {
				resultLimit = Integer.parseInt(filters.get("offset").toString());
			} catch (NumberFormatException e) {}
		}
		
		FindCriteriaJpe findCriteria = BusinessDataObjectJpaQueryComponentImpl.buildFindCriteria(offset, resultLimit, groupBy, order, null);
		if (findCriteria == null) {
			findCriteria = new FindCriteriaJpe();
		}
		if(findCriteria.getFilter() == null){
			ViewCriteriaJpe rootViewCriteria = new ViewCriteriaJpe();
			findCriteria.setFilter(rootViewCriteria);
		}
		if(findCriteria.getFilter().getGroup() == null){
			findCriteria.getFilter().setGroup(new ArrayList<ViewCriteriaRowJpe>());
		}
		List<String> attributes = new ArrayList<String>();
		attributes.add("clientNo");
		attributes.add("clientName");
		findCriteria.setFindAttribute(attributes);
		findCriteria.setExcludeAttributeYn(false);
		
		List<ViewCriteriaRowJpe> rowList = findCriteria.getFilter().getGroup();
		ViewCriteriaRowJpe row = new ViewCriteriaRowJpe();
		row.setItem(new ArrayList<ViewCriteriaItemJpe>());
		ViewCriteriaItemJpe vci = new ViewCriteriaItemJpe();
		row.getItem().add(vci);
		rowList.add(row);

		List<Object> clientNoList = new ArrayList<Object>();
		if(refObjectKey != null){
			Map<String, Object> param = new HashMap<String, Object>();
			if (ACCT.equals(refObjectType)) {
				param.put("acctNo", refObjectKey);
				AcctJpe acctJpe = null;
	    		try {
	    			acctJpe = dataService.getWithNamedQuery(DepJpeConstants.ACCT_JPE_FIND_BY_ACCTNO, param, AcctJpe.class);
				} catch (Exception e) {
					//did not find any acct with the given acctNo
				}
	    		if(acctJpe != null){
					clientNoList.add(acctJpe.getClientNo());
    				if(acctJpe.getJointAcctList() != null && acctJpe.getJointAcctList().size() > 0){
    					for(JointAcctJpe jointAcct : acctJpe.getJointAcctList()){
    						clientNoList.add(jointAcct.getClientNo());
    					}
    				}
	    		}
			} else if (SDBACCT.equals(refObjectType)) {
	    		param.put("contractNo", refObjectKey);
	    		SdbAcctJpe sdbAcctJpe = null;
	    		try {
	    			sdbAcctJpe = dataService.getWithNamedQuery(DepJpeConstants.SDB_ACCT_JPE_GET_SDBACCT_BY_CONTRACT_NO, param, SdbAcctJpe.class);
				} catch (Exception e) {
					//did not find any sdb acct with the given contractNo
				}
	    		if(sdbAcctJpe != null){
	    			clientNoList.add(sdbAcctJpe.getClientNo());
    				if(sdbAcctJpe.getSdbAssigneeList() != null && sdbAcctJpe.getSdbAssigneeList().size() > 0){
    					for(SdbAssigneeJpe assignee : sdbAcctJpe.getSdbAssigneeList()){
    						clientNoList.add(assignee.getClientNo());
    					}
    				}
	    		}
			}

			vci.setAttribute("clientNo");
			vci.setOperator("IN");
			vci.setValue(clientNoList);
			vci.setConjunction(ConjunctionEnumJpe.AND);

			if(filters.get("clientNo") != null){
				ViewCriteriaItemJpe vci2 = new ViewCriteriaItemJpe();
				row.getItem().add(vci2);
				List<Object> clientNoFilterList = new ArrayList<Object>();
				clientNoFilterList.add(filters.get("clientNo").toString());
				vci2.setAttribute("clientNo");
				vci2.setOperator("=");
				vci2.setValue(clientNoFilterList);
				vci2.setConjunction(ConjunctionEnumJpe.AND);
			}
		}

		FindCriteria fc = jaxbSdoHelper.wrap(findCriteria, FindCriteria.class);
		return clientService.find(fc, null);
	}

	@Override
	public Long count(FindCriteria findCriteria, CbsHeader cbsHeader) {
		FindCriteriaJpe jpe = jaxbSdoHelper.unwrap(findCriteria, FindCriteriaJpe.class);
        return dataService.getRowCount(AcctSignatoryInfoJpe.class, jpe, constructorMap, condition);
	}

}
