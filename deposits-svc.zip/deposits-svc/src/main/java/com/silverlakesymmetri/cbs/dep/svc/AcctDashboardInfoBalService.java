package com.silverlakesymmetri.cbs.dep.svc;

import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation;
import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation.ServiceOperationType;
import com.silverlakesymmetri.cbs.commons.svc.BusinessService;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.AcctDashboardInfoBal;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.AcctDashboardInfoBalJpe;

public interface AcctDashboardInfoBalService extends BusinessService<AcctDashboardInfoBal, AcctDashboardInfoBalJpe> {


    public static final String SVC_OP_NAME_ACCTDASHBOARDINFOBAL_GET= "AcctDashboardInfoBalService.get";

    @ServiceOperation(name = SVC_OP_NAME_ACCTDASHBOARDINFOBAL_GET, type = ServiceOperationType.GET)
    public AcctDashboardInfoBal getByPk(String publicKey, AcctDashboardInfoBal reference);
        
}
