package com.silverlakesymmetri.cbs.dep.svc;

import java.util.List;

import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation;
import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation.ServiceOperationType;
import com.silverlakesymmetri.cbs.commons.svc.BusinessService;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.InwdCheque;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.InwdChequeJpe;

public interface ClearingService extends BusinessService<InwdCheque, InwdChequeJpe> {

    public static final String SVC_OP_NAME_CLEARINGSERVICE_GET = "ClearingService.get";
//    public static final String SVC_OP_NAME_CLEARINGSERVICE_QUERY = "ClearingService.query";
//    public static final String SVC_OP_NAME_CLEARINGSERVICE_CREATE = "ClearingService.create";
//    public static final String SVC_OP_NAME_CLEARINGSERVICE_UPDATE = "ClearingService.update";
//    public static final String SVC_OP_NAME_CLEARINGSERVICE_FIND = "ClearingService.find";

    @ServiceOperation(name = SVC_OP_NAME_CLEARINGSERVICE_GET, type = ServiceOperationType.GET)
    public InwdCheque getByPk(String publicKey, InwdCheque reference);

//    @ServiceOperation(name = SVC_OP_NAME_CLEARINGSERVICE_CREATE)
//    public InwdCheque create(InwdCheque dataObject);

//    @ServiceOperation(name = SVC_OP_NAME_CLEARINGSERVICE_UPDATE)
//    public InwdCheque update(InwdCheque dataObject);

//    @ServiceOperation(name = SVC_OP_NAME_CLEARINGSERVICE_QUERY)
//    public List<InwdCheque> query(int offset, int resultLimit, String groupBy, String order, Map<String, Object> filters);

//    @ServiceOperation(name = SVC_OP_NAME_CLEARINGSERVICE_FIND)
//    public List<InwdCheque> find(FindCriteria findCriteria, CbsHeader cbsHeader);

	
	public static final String SVC_OP_NAME_CLEARINGSERVICE_QUERYINWDCHEQUES = "ClearingService.queryInwdCheques";
	public static final String SVC_OP_NAME_CLEARINGSERVICE_PROCESSINWDCHEQUES = "ClearingService.processInwdCheques";
	
    @ServiceOperation(name = SVC_OP_NAME_CLEARINGSERVICE_QUERYINWDCHEQUES, type = ServiceOperationType.READ)
	public List<InwdCheque> queryInwdCheques(String inwdType, String tranCode, String branch);
    
    @ServiceOperation(name = SVC_OP_NAME_CLEARINGSERVICE_PROCESSINWDCHEQUES, type = ServiceOperationType.EXECUTE, useMethodForBpmApproval = true)
	public List<InwdCheque> processInwdCheques(String inwdType, String tranCode, String branch);
    
}
