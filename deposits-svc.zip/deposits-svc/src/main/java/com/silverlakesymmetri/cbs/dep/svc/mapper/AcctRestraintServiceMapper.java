package com.silverlakesymmetri.cbs.dep.svc.mapper;

import java.util.Map;

import org.mapstruct.Context;
import org.mapstruct.DecoratedWith;
import org.mapstruct.InheritConfiguration;
import org.mapstruct.InheritInverseConfiguration;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingTarget;
import org.mapstruct.Mappings;

import com.silverlakesymmetri.cbs.commons.xmlapi.enums.CbsXmlApiOperation;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.AcctRestraintJpe;
import com.silverlakesymmetri.cbs.dep.svc.mapper.decorator.AcctRestraintServiceDecorator;
import com.silverlakesymmetri.cbs.dep.svc.mapper.mapping.AcctRestraintToDEPRESTRAINTSAPITypeMapper;
import com.silverlakesymmetri.cbs.dep.xmlapi.DEPRESTRAINTSAPIType;

@Mapper(config=AcctRestraintToDEPRESTRAINTSAPITypeMapper.class)
@DecoratedWith(AcctRestraintServiceDecorator.class)
public interface AcctRestraintServiceMapper {
	
	@Mappings({
		 @Mapping(expression = "java(oper != null ? oper.getOperation() : null)", target="OPERATION")
	 })
	@InheritConfiguration
	public DEPRESTRAINTSAPIType mapToApi(AcctRestraintJpe jpe,  @Context CbsXmlApiOperation oper, @Context Map otherInfo);
	
	@InheritInverseConfiguration(name = "mapAcctRestrainttoDEPRESTRAINTSAPIType")
	@Mappings({
		 @Mapping(target = "startDate", source="STARTDATE", qualifiedByName = {"DateTimeHelper","convertCbsApiDateToString"}),
		  @Mapping(target = "endDate", source="ENDDATE", qualifiedByName = {"DateTimeHelper","convertCbsApiDateToString"}),
	})
	public AcctRestraintJpe mapToJpe(DEPRESTRAINTSAPIType api, @MappingTarget AcctRestraintJpe jpe);
}
