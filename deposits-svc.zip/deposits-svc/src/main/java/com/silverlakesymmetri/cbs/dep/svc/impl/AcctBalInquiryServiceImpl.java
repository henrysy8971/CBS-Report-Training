package com.silverlakesymmetri.cbs.dep.svc.impl;

import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.mysema.query.types.EntityPath;
import com.mysema.query.types.Predicate;
import com.silverlakesymmetri.cbs.commons.svc.AbstractBusinessService;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.AcctBalInquiry;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.AcctBalInquiryJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.AcctJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.AcctStatsJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.QAcctBalInquiryJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.QAcctStatsJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.util.DepJpeConstants;
import com.silverlakesymmetri.cbs.dep.jpa.util.DepStorHelper;
import com.silverlakesymmetri.cbs.dep.jpa.util.DepUtil;
import com.silverlakesymmetri.cbs.dep.svc.AcctBalInquiryService;
import com.silverlakesymmetri.cbs.dep.svc.util.AcctHelper;
import com.silverlakesymmetri.cbs.gla.jpa.mapping.sdo.GlAccountJpe;
import com.silverlakesymmetri.cbs.gla.jpa.mapping.sdo.util.GlaJpeConstants;

@Service
@Transactional
public class AcctBalInquiryServiceImpl extends AbstractBusinessService<AcctBalInquiry, AcctBalInquiryJpe, String> implements AcctBalInquiryService {

	private static final String INTERNAL_KEY = "internalKey";
	private static final String ACCT_NO = "acctNo";
	private static final String CERTIFICATE_NO = "certificateNo";
	private static final String AVAIL_BAL = "availBal";

	@Autowired
	DepUtil depUtil;

	@Autowired
	private AcctHelper acctHelper;

	@Autowired
	private DepStorHelper depStorHelper;

	@Override
	protected EntityPath<AcctBalInquiryJpe> getEntityPath() {
		return QAcctBalInquiryJpe.acctBalInquiryJpe;
	}

	@Override
	protected String getIdFromDataObjectInstance(AcctBalInquiry dataObject) {
		return dataObject.getAcctNo();
	}

	@Override
	public AcctBalInquiry getByPk(String publicKey, AcctBalInquiry dataObject) {
		AcctBalInquiry acctBalInquiry = super.getByPk(publicKey, dataObject);
        /**
         * For instances that the deposit account is not created yet (i.e. Deposit account is still for approval), acctBalInquiry
         * is still null. So this will result to NPE
         */
		if (acctBalInquiry == null) {
			return null;
		}
		return setDefaultAmounts(acctBalInquiry, getReferenceStats(acctBalInquiry.getAcctNo()));
    }

	@Override
	public List<AcctBalInquiry> query(int offset, int resultLimit, String groupBy, String order,
			Map<String, Object> filters) {

		Long internalKey = null;
		if (filters.containsKey(ACCT_NO)) {
			String acctNo = (String) filters.get(ACCT_NO);
			if (filters.containsKey(CERTIFICATE_NO)) {
				String certificateNo = (String) filters.get(CERTIFICATE_NO);
				internalKey = acctHelper.getInternalKeyByAcctNoAndCertificateNo(acctNo, certificateNo);
				filters.remove(CERTIFICATE_NO);
			} else {
				internalKey = acctHelper.getInternalKeyByAcctNo(acctNo);
			}
			filters.remove(ACCT_NO);
			filters.put(INTERNAL_KEY, internalKey);
		}

		List<AcctBalInquiry> acctBalInquiryList = super.query(offset, resultLimit, groupBy, order, filters);

		if (!(acctBalInquiryList == null || acctBalInquiryList.isEmpty() || internalKey == null)) {
			AcctBalInquiry acctBalInquiry = acctBalInquiryList.get(0);
			setAvailBal(acctBalInquiry, internalKey);
			return Collections.singletonList(setDefaultAmounts(acctBalInquiry, getReferenceStats(internalKey)));
		}
		if (acctBalInquiryList == null || acctBalInquiryList.isEmpty()) {
			return Collections.emptyList();
		}
		setAvailBalToList(acctBalInquiryList);
		return acctBalInquiryList;
	}

	private AcctStatsJpe getReferenceStats(String acctNo) {
		Long internalKey = acctHelper.getInternalKeyByAcctNo(acctNo);
		return getReferenceStats(internalKey);
	}

	private AcctStatsJpe getReferenceStats(Long internalKey) {
		if (internalKey == null) {
			return null;
		}

		Predicate predicate = QAcctStatsJpe.acctStatsJpe.internalKey.eq(internalKey);
		List<AcctStatsJpe> acctStatsJpeList = dataService.query(QAcctStatsJpe.acctStatsJpe, predicate);
		if (!(acctStatsJpeList == null || acctStatsJpeList.isEmpty())) {
			return acctStatsJpeList.get(0);
		}

		return null;
	}

	private AcctBalInquiry setDefaultAmounts(AcctBalInquiry acctBalInquiry, AcctStatsJpe acctStatsJpe) {
		acctBalInquiry.setAveBalLastMtd(0.0);
		acctBalInquiry.setAveBalLastQtd(0.0);
		acctBalInquiry.setAveBalLastStd(0.0);
		acctBalInquiry.setAveBalLastYtd(0.0);
		acctBalInquiry.setTotalAuthOd(0.0);
		acctBalInquiry.setTotalPledgedAmt(0.0);
		acctBalInquiry.setTotalFloatsAmt(0.0);
		acctBalInquiry.setToleranceAmt(0.0);
		acctBalInquiry.setCrIntAccruedCtd(0.0);
		acctBalInquiry.setDrIntAccruedCtd(0.0);
		acctBalInquiry.setLedgerBal(depUtil.getNegateOrDefault(acctBalInquiry.getLedgerBal(), 0.0));
		Long internalKey = acctStatsJpe.getInternalKey();
		setAvailBal(acctBalInquiry, internalKey);
		if (acctStatsJpe != null) {
			acctBalInquiry.setAveBalLastMtd(depUtil.getNegateOrDefault(acctStatsJpe.getAveBalLmtd(), 0.0));
			acctBalInquiry.setAveBalLastQtd(depUtil.getNegateOrDefault(acctStatsJpe.getAveBalLqtd(), 0.0));
			acctBalInquiry.setAveBalLastStd(depUtil.getNegateOrDefault(acctStatsJpe.getAveBalLstd(), 0.0));
			acctBalInquiry.setAveBalLastYtd(depUtil.getNegateOrDefault(acctStatsJpe.getAveBalLytd(), 0.0));
		}
		if (internalKey != null) {
			Map<String, Object> params = new HashMap<>();
			params.put("internalKey", internalKey);
			List<AcctJpe> acctList = dataService.findWithNamedQuery(DepJpeConstants.ACCT_JPE_FIND_BY_INTERNAL_KEY,
					params, AcctJpe.class);
			if (acctList != null && acctList.size() > 0) {
				acctBalInquiry.setTotalAuthOd(depUtil.getValueOrDefault(acctList.get(0).getTotalAuthOd(), 0.00));
				acctBalInquiry.setTotalPledgedAmt(depUtil.getValueOrDefault(acctList.get(0).getTotalPledgedAmt(), 0.00));
				acctBalInquiry.setTotalFloatsAmt(depUtil.getValueOrDefault(acctList.get(0).getTotalFloatsAmt(), 0.00));
				acctBalInquiry.setToleranceAmt(depUtil.getValueOrDefault(acctList.get(0).getToleranceAmt(), 0.00));
			}
			List<GlAccountJpe> glAccountList = dataService.findWithNamedQuery(
					GlaJpeConstants.GLA_ACCOUNT_JPE_FIND_BY_INTERNAL_KEY, params, GlAccountJpe.class);
			if (glAccountList != null && glAccountList.size() > 0) {
				acctBalInquiry.setCrIntAccruedCtd(depUtil.getValueOrDefault(glAccountList.get(0).getCrIntAccruedCtd(), 0.00));
				acctBalInquiry.setDrIntAccruedCtd(depUtil.getValueOrDefault(glAccountList.get(0).getDrIntAccruedCtd(), 0.00));
			}
		}
		return acctBalInquiry;
	}

	private void setAvailBal(AcctBalInquiry acctBalInquiry, Long internalKey) {
		Map<String, Object> availBalMap = depStorHelper.calcAvailBal(internalKey, acctBalInquiry.getAvailBal(), acctBalInquiry.getLedgerBal());
		acctBalInquiry.setAvailBal((Double) availBalMap.get(AVAIL_BAL));
	}

	private void setAvailBalToList(List<AcctBalInquiry> acctBalInquiryList) {
		for (AcctBalInquiry acctBalInquiry : acctBalInquiryList) {
			AcctBalInquiryJpe jpe = jaxbSdoHelper.unwrap(acctBalInquiry, AcctBalInquiryJpe.class);
			Map<String, Object> availBalMap = depStorHelper.calcAvailBal(jpe.getInternalKey(), acctBalInquiry.getAvailBal(), acctBalInquiry.getLedgerBal());
			acctBalInquiry.setAvailBal((Double) availBalMap.get(AVAIL_BAL));
		}
	}

}
