package com.silverlakesymmetri.cbs.dep.svc.mapper;

import java.util.Map;

import org.mapstruct.Context;
import org.mapstruct.DecoratedWith;
import org.mapstruct.InheritConfiguration;
import org.mapstruct.InheritInverseConfiguration;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingTarget;
import org.mapstruct.Mappings;

import com.silverlakesymmetri.cbs.commons.xmlapi.enums.CbsXmlApiOperation;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.BalHistCtrlInqJpe;
import com.silverlakesymmetri.cbs.dep.svc.mapper.decorator.BalHistCtrlInqServiceDecorator;
import com.silverlakesymmetri.cbs.dep.svc.mapper.mapping.BalHistCtrlInqToDEPACCTBALHISTQRYAPITypeMapper;
import com.silverlakesymmetri.cbs.dep.xmlapi.DEPACCTBALHISTQRYAPIType;

@Mapper(config=BalHistCtrlInqToDEPACCTBALHISTQRYAPITypeMapper.class)
@DecoratedWith(BalHistCtrlInqServiceDecorator.class)
public interface BalHistCtrlInqServiceMapper {

	@Mappings({
		 @Mapping(expression = "java(oper != null ? oper.getOperation() : null)", target="OPERATION")
	 })
	@InheritConfiguration
	public DEPACCTBALHISTQRYAPIType mapToApi(BalHistCtrlInqJpe jpe, @Context CbsXmlApiOperation oper, @Context Map otherInfo);
	
	@Mappings({
		@Mapping(source="MONTH", target ="month"),
		@Mapping(source="YEAR", target ="year")
	 })
	@InheritInverseConfiguration(name = "mapBalHistCtrlInqToDEPACCTBALHISTQRYAPIType")
	public BalHistCtrlInqJpe mapToJpe(DEPACCTBALHISTQRYAPIType api, @MappingTarget BalHistCtrlInqJpe jpe);
	
}
