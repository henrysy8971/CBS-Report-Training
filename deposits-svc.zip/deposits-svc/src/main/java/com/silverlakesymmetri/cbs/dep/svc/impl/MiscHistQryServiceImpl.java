package com.silverlakesymmetri.cbs.dep.svc.impl;

import com.mysema.query.types.EntityPath;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.svc.AbstractBusinessService;
import com.silverlakesymmetri.cbs.commons.svc.BusinessObjectValidationCapable;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.MiscHistQry;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.MiscHistQryJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.QMiscHistQryJpe;
import com.silverlakesymmetri.cbs.dep.svc.MiscHistQryService;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;

@Service
public class MiscHistQryServiceImpl extends AbstractBusinessService<MiscHistQry, MiscHistQryJpe, String>
        implements MiscHistQryService, BusinessObjectValidationCapable<MiscHistQry> {
    @Override
    protected String getIdFromDataObjectInstance(MiscHistQry dataObject) {
        return null;
    }

    @Override
    protected EntityPath<MiscHistQryJpe> getEntityPath() {
        return QMiscHistQryJpe.miscHistQryJpe;
    }

    @Override
    public MiscHistQry getByPk(String publicKey, MiscHistQry reference) {
        return super.getByPk(publicKey, reference);
    }

    @Override
    public List<MiscHistQry> query(int offset, int resultLimit, String groupBy, String order,
                                   Map<String, Object> filters) {
        return super.query(offset, resultLimit, groupBy, order, filters);
    }

    @Override
    public List<MiscHistQry> find(FindCriteria findCriteria, CbsHeader cbsHeader) {
        return super.find(findCriteria, cbsHeader);
    }
}
