package com.silverlakesymmetri.cbs.dep.svc;

import java.util.List;
import java.util.Map;

import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation;
import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation.ServiceOperationType;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.svc.BusinessService;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.AcctStats;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.AcctStatsJpe;

public interface AcctStatsService extends BusinessService<AcctStats, AcctStatsJpe> {
	public static final String SVC_OP_NAME_ACCTSTATSSERVICE_GET= "AcctStatsService.get";
	public static final String SVC_OP_NAME_ACCTSTATSSERVICE_QUERY= "AcctStatsService.query";
	public static final String SVC_OP_NAME_ACCTSTATSSERVICE_FIND= "AcctStatsService.find";
	
    @ServiceOperation(name = SVC_OP_NAME_ACCTSTATSSERVICE_QUERY)
    public List<AcctStats> query(int offset, int resultLimit, String groupBy, String order, Map<String, Object> filters);

    @ServiceOperation(name = SVC_OP_NAME_ACCTSTATSSERVICE_FIND)
    public List<AcctStats> find(FindCriteria findCriteria, CbsHeader cbsHeader);

    @ServiceOperation(name = SVC_OP_NAME_ACCTSTATSSERVICE_GET, type = ServiceOperationType.GET)
    public AcctStats getByPk(String publicKey, AcctStats reference);


}
