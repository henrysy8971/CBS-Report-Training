package com.silverlakesymmetri.cbs.dep.svc.mapper.mapping;

import org.mapstruct.MapperConfig;
import org.mapstruct.Mapping;
import org.mapstruct.Mappings;

import com.silverlakesymmetri.cbs.commons.jpa.util.DateTimeHelper;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.AcctIntMaintJpe;
import com.silverlakesymmetri.cbs.dep.xmlapi.DEPACCTINTMAINTAPIType;

@MapperConfig(uses={ DateTimeHelper.class})
public interface AcctIntMaintToDEPACCTINTMAINTAPITypeMapper {

	@Mappings({
		@Mapping(source = "seqNo", target = "SEQNO"),
		@Mapping(source = "internalKey", target = "INTERNALKEY"),
		@Mapping(source = "effectiveDate", target = "EFFECTIVEDATE", qualifiedByName = {"DateTimeHelper","convertDateToCbsXmlApiDate"}),
		@Mapping(source = "changeType", target = "CHANGETYPE"),
		@Mapping(source = "intType", target = "INTTYPE"),
		@Mapping(source = "acctLevelIntRate", target = "ACCTLEVELINTRATE"),
		@Mapping(source = "spreadRate", target = "SPREADRATE"),
		@Mapping(source = "authIntType", target = "AUTHINTTYPE"),
		@Mapping(source = "authAcctLevelIntRate", target = "AUTHACCTLEVELINTRATE"),
		@Mapping(source = "authSpreadRate", target = "AUTHSPREADRATE"),
		@Mapping(source = "penaltyMarginRate", target = "PENALTYMARGINRATE"),
		//@Mapping(source = "lastChangeDate", target = "GLOBALID"),
		@Mapping(source = "lastChangeOfficer", target = "LASTCHANGEOFFICER"),
		@Mapping(source = "applied", target = "APPLIED"),
		@Mapping(source = "repricingInd", target = "REPRICINGIND"),
	})
	public DEPACCTINTMAINTAPIType mapAcctIntMaintToDEPACCTINTMAINTAPIType(AcctIntMaintJpe jpe);
		
}




