package com.silverlakesymmetri.cbs.dep.svc;

import java.util.List;
import java.util.Map;

import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.svc.BusinessService;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.GlCashPositionQry;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.GlCashPositionQryJpe;

public interface GlCashPositionQryService extends BusinessService<GlCashPositionQry, GlCashPositionQryJpe> {
	String SVC_OP_NAME_GLCASHPOSITIONQRYSERVICE_GET = "GlCashPositionQryService.get";
	String SVC_OP_NAME_GLCASHPOSITIONQRYSERVICE_QUERY = "GlCashPositionQryService.query";
	String SVC_OP_NAME_GLCASHPOSITIONQRYSERVICE_FIND = "GlCashPositionQryService.find";

	@ServiceOperation(name = SVC_OP_NAME_GLCASHPOSITIONQRYSERVICE_GET, type = ServiceOperation.ServiceOperationType.GET)
	GlCashPositionQry getByPk(String publicKey, GlCashPositionQry reference);

	@ServiceOperation(name = SVC_OP_NAME_GLCASHPOSITIONQRYSERVICE_QUERY)
	List<GlCashPositionQry> query(int offset, int resultLimit, String groupBy, String order,
			Map<String, Object> filters);

	@ServiceOperation(name = SVC_OP_NAME_GLCASHPOSITIONQRYSERVICE_FIND)
	List<GlCashPositionQry> find(FindCriteria findCriteria, CbsHeader cbsHeader);
}
