package com.silverlakesymmetri.cbs.dep.svc.impl;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.mysema.query.types.EntityPath;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.svc.AbstractBusinessService;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.OdRepositoryDtl;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.OdRepositoryPaymt;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.OdRepositoryDtlJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.QOdRepositoryDtlJpe;
import com.silverlakesymmetri.cbs.dep.svc.OdRepositoryDtlService;

@Service
@Transactional
public class OdRepositoryDtlServiceImpl extends AbstractBusinessService<OdRepositoryDtl, OdRepositoryDtlJpe, String>
		implements OdRepositoryDtlService {

	@Override
	protected EntityPath<OdRepositoryDtlJpe> getEntityPath() {
		return QOdRepositoryDtlJpe.odRepositoryDtlJpe;
	}

	@Override
	protected String getIdFromDataObjectInstance(OdRepositoryDtl dataObject) {
		return dataObject.getPublicKey();
	}

	@Override
	public OdRepositoryDtl getByPk(String publicKey, OdRepositoryDtl reference) {
		OdRepositoryDtl retVal = super.getByPk(publicKey, reference);
		if (retVal != null) {
			retVal.setBalanceDue(computeDueAmt(retVal));
			retVal.setTotalTranAmt(computeTotalTransAmt(retVal));
		}
		return retVal;
	}

	@Override
	public List<OdRepositoryDtl> query(int offset, int resultLimit, String groupBy, String order,
			Map<String, Object> filters) {
		List<OdRepositoryDtl> list = super.query(offset, resultLimit, groupBy, order, filters);
		if (list != null) {
			for (OdRepositoryDtl item : list) {
				item.setBalanceDue(computeDueAmt(item));
				item.setTotalTranAmt(computeTotalTransAmt(item));
			}
		}
		return list;
	}

	@Override
	public List<OdRepositoryDtl> find(FindCriteria findCriteria, CbsHeader cbsHeader) {
		List<OdRepositoryDtl> list = super.find(findCriteria, cbsHeader);
		if (list != null) {
			for (OdRepositoryDtl item : list) {
				item.setBalanceDue(computeDueAmt(item));
				double paidAmt = item.getPaidAmt() == null ? 0 : item.getPaidAmt().doubleValue();
				double writeOffAmt = item.getWriteoffAmt() == null ? 0 : item.getWriteoffAmt().doubleValue();
				item.setPaidAmt(paidAmt - writeOffAmt);
				item.setTotalTranAmt(computeTotalTransAmt(item));
			}
		}
		return list;
	}

	private double computeDueAmt(OdRepositoryDtl sdo) {
		double dueAmt = sdo.getDueAmt() == null ? 0 : sdo.getDueAmt().doubleValue();
		double paidAmt = sdo.getPaidAmt() == null ? 0 : sdo.getPaidAmt().doubleValue();
		// double writeOffAmt = sdo.getWriteoffAmt() == null ? 0 : sdo.getWriteoffAmt().doubleValue();
		// double scAmt = sdo.getScAmt() == null ? 0 : sdo.getScAmt().doubleValue();
		// double scPaidAmt = sdo.getScPaidAmt() == null ? 0 : sdo.getScPaidAmt().doubleValue();
		// double taxAmt = sdo.getTaxAmt() == null ? 0 : sdo.getTaxAmt().doubleValue();
		// double taxPaidAmt = sdo.getTaxPaidAmt() == null ? 0 : sdo.getTaxPaidAmt().doubleValue();
		// return dueAmt - paidAmt - writeOffAmt;
		// return dueAmt + scAmt + taxAmt - paidAmt - writeOffAmt - scPaidAmt - taxPaidAmt;
		return dueAmt - paidAmt;
	}

	private double computeTotalTransAmt(OdRepositoryDtl sdo) {
		double totTransAmt = 0;
		List<OdRepositoryPaymt> list = sdo.getOdRepositoryPaymtList();
		if (list != null) {
			for (OdRepositoryPaymt item : list) {
				if (item.getTranAmt() != null) {
					totTransAmt += item.getTranAmt().doubleValue();
				}
			}
		}
		return totTransAmt;
	}

}
