package com.silverlakesymmetri.cbs.dep.svc;

import java.util.List;
import java.util.Map;

import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation;
import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation.ServiceOperationType;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.svc.BusinessService;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.CiPrefix;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.CiPrefixHdr;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.CiPrefixHdrJpe;

public interface CiPrefixService extends BusinessService<CiPrefixHdr, CiPrefixHdrJpe> {

    public static final String SVC_OP_NAME_CIPREFIXSERVICE_GET = "CiPrefixService.get";
    public static final String SVC_OP_NAME_CIPREFIXSERVICE_QUERY = "CiPrefixService.query";
    public static final String SVC_OP_NAME_CIPREFIXSERVICE_CREATE = "CiPrefixService.create";
    public static final String SVC_OP_NAME_CIPREFIXSERVICE_UPDATE = "CiPrefixService.update";
    public static final String SVC_OP_NAME_CIPREFIXSERVICE_DELETE = "CiPrefixService.delete";
    public static final String SVC_OP_NAME_CIPREFIXSERVICE_FIND = "CiPrefixService.find";
    public static final String SVC_OP_NAME_CIPREFIXSERVICE_FIND_CHILD_LIST = "CiPrefixService.findChildList";

    @ServiceOperation(name = SVC_OP_NAME_CIPREFIXSERVICE_GET, type = ServiceOperationType.GET)
    public CiPrefixHdr getByPk(String publicKey, CiPrefixHdr reference);

    @ServiceOperation(name = SVC_OP_NAME_CIPREFIXSERVICE_CREATE)
    public CiPrefixHdr create(CiPrefixHdr dataObject);

    @ServiceOperation(name = SVC_OP_NAME_CIPREFIXSERVICE_UPDATE)
    public CiPrefixHdr update(CiPrefixHdr dataObject);

    @ServiceOperation(name = SVC_OP_NAME_CIPREFIXSERVICE_QUERY)
    public List<CiPrefixHdr> query(int offset, int resultLimit, String groupBy, String order, Map<String, Object> filters);

    @ServiceOperation(name = SVC_OP_NAME_CIPREFIXSERVICE_DELETE)
    public boolean delete(CiPrefixHdr dataObject);

    @ServiceOperation(name = SVC_OP_NAME_CIPREFIXSERVICE_FIND)
    public List<CiPrefixHdr> find(FindCriteria findCriteria, CbsHeader cbsHeader);
    
    @ServiceOperation(name = SVC_OP_NAME_CIPREFIXSERVICE_FIND_CHILD_LIST, type = ServiceOperationType.READ, passParamAsMap = true)
    public List<CiPrefix> findChildList(Map<String, Object> queryParams);

}
