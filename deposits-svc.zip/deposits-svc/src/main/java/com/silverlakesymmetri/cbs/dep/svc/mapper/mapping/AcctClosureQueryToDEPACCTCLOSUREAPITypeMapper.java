package com.silverlakesymmetri.cbs.dep.svc.mapper.mapping;

import com.silverlakesymmetri.cbs.commons.jpa.util.DateTimeHelper;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.AcctClosureJpe;
import com.silverlakesymmetri.cbs.dep.xmlapi.DEPACCTCLOSUREAPIType;
import org.mapstruct.MapperConfig;
import org.mapstruct.Mapping;
import org.mapstruct.Mappings;

@MapperConfig(uses={ DateTimeHelper.class})
public interface AcctClosureQueryToDEPACCTCLOSUREAPITypeMapper {

	@Mappings({ 
		@Mapping(source = "acctNo", target="ACCTNO"),
		@Mapping(source = "internalKey", target="INTERNALKEY"),
		@Mapping(target = "AUTOGENFEE", constant = "N"),
		@Mapping(source = "queryType", target="QUERYTYPE"),
		@Mapping(source = "acctClosureOfficer", target="OFFICERID"),
		@Mapping(source = "acctClosureReasonDesc", target="ACCTCLOSEREASON"),
		@Mapping(source = "ledgerBal", target="LEDGERBAL"),
		@Mapping(source = "batchSc", target="BATCHSC"),
		@Mapping(source = "closureSc", target="CLOSURESC"),
		@Mapping(source = "uncollSc", target="UNCOLLSC"),
		@Mapping(source = "acctCloseOnlineIntCapRec.acctNo", target="DEPACCTINTCAPAPIREC.ACCTNO"),
		@Mapping(source = "acctCloseOnlineIntCapRec.intPaymentOption", target="DEPACCTINTCAPAPIREC.PAYMENTOPTION"),
		@Mapping(source = "acctCloseOnlineIntCapRec.crIntAccrual", target="DEPACCTINTCAPAPIREC.CRINTACCRUED"),
		@Mapping(source = "acctCloseOnlineIntCapRec.witholdTaxAccrual", target="DEPACCTINTCAPAPIREC.CRINTACCRUEDWTAX"),
		@Mapping(source = "acctCloseOnlineIntCapRec.crIntAdj", target="DEPACCTINTCAPAPIREC.CRINTADJ"),
		@Mapping(source = "acctCloseOnlineIntCapRec.witholdTaxAdj", target="DEPACCTINTCAPAPIREC.CRINTADJWTAX"),
		@Mapping(source = "acctCloseOnlineIntCapRec.drIntAuthAccrual", target="DEPACCTINTCAPAPIREC.DRINTACCRUED"),
		@Mapping(source = "acctCloseOnlineIntCapRec.drIntUnauthAccrual", target="DEPACCTINTCAPAPIREC.DRINTUNAUTHACCRUED"),
		@Mapping(source = "acctCloseOnlineIntCapRec.drIntAuthAdj", target="DEPACCTINTCAPAPIREC.DRINTAUTHADJ"),
		@Mapping(source = "acctCloseOnlineIntCapRec.drIntUnauthAdj", target="DEPACCTINTCAPAPIREC.DRINTUNAUTHADJ"),
		@Mapping(target = "OPERATION", constant = "QUERY"),
		@Mapping(target = "DEPACCTINTCAPAPIREC.OPERATION", constant = "QUERY")
	 })
	DEPACCTCLOSUREAPIType mapAcctClosureQueryToDEPACCTCLOSUREAPIType(AcctClosureJpe api);
	
}

