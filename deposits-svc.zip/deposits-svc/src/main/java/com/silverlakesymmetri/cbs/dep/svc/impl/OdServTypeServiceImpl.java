package com.silverlakesymmetri.cbs.dep.svc.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.mysema.query.types.EntityPath;
import com.silverlakesymmetri.cbs.commons.svc.AbstractBusinessService;
import com.silverlakesymmetri.cbs.csd.bdo.sdo.ServType;
import com.silverlakesymmetri.cbs.csd.jpa.mapping.sdo.QServTypeJpe;
import com.silverlakesymmetri.cbs.csd.jpa.mapping.sdo.ServTypeJpe;
import com.silverlakesymmetri.cbs.dep.svc.OdServTypeService;

@Service
@Transactional
public class OdServTypeServiceImpl extends AbstractBusinessService<ServType, ServTypeJpe, String>
		implements OdServTypeService {

	@Override
	protected EntityPath<ServTypeJpe> getEntityPath() {
		return QServTypeJpe.servTypeJpe;
	}

	@Override
	protected String getIdFromDataObjectInstance(ServType dataObject) {
		return dataObject.getScType();
	}

	@Override
	public List<ServType> query(int offset, int resultLimit, String groupBy, String order,
			Map<String, Object> filters) {

		List<ServType> bdoList = new ArrayList<ServType>();

		if (filters != null && filters.get("listType") != null) {

			String listType = filters.remove("listType").toString();
			String customQuery = null;
			
			switch (listType.toUpperCase()) {
			  case "OVERDRAFT":
				  customQuery = "SELECT DISTINCT a.scType, a.scTypeDesc"
							+ " FROM ServTypeJpe a"
							+ " INNER JOIN ServTypeDtlJpe b ON (b.scType = a.scType)"
							+ " INNER JOIN TranDefJpe c ON (c.tranType = b.scTranType)"
							+ " AND b.batchOnline = 'O'"
							+ " AND b.scTypeStatus = 'A'"
							+ " AND c.reversalTranFlag = 'N'"
							+ " AND c.ovdInd = 'Y'";
			    break;
			  case "ISOFEETYPE":
			    customQuery = "SELECT DISTINCT a "
			    		+ " FROM ServTypeJpe a "
			    		+ " INNER JOIN ScEventJpe b ON a.scType = b.scType "
			    		+ " WHERE b.scEventType IN ('MSTR','FNTR','ABIN','MSIN') ";
			    break;
			  default:
				customQuery = null;
			    break;
			}
						
			if (customQuery != null) {
				StringBuilder criteria = new StringBuilder(customQuery);
				
				if (filters.containsKey("scType")){
		    		filters.put("scType", filters.get("scType"));
		    		criteria.append("  AND a.scType = :scType");
		    	}
								
				List<ServTypeJpe> jpeList =  (List<ServTypeJpe>) dataService.findWithQuery(criteria.toString(), filters, offset, resultLimit, ServTypeJpe.class);
				if (jpeList != null && jpeList.size() > 0) {
					for (ServTypeJpe jpe : jpeList) {
						bdoList.add(jaxbSdoHelper.wrap(jpe, ServType.class));	
					}
				}

			} else {
				bdoList = super.query(offset, resultLimit, groupBy, order, filters);
			}
		}

		return bdoList;

	}

}
