package com.silverlakesymmetri.cbs.dep.svc;

import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation;
import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation.ServiceOperationType;
import com.silverlakesymmetri.cbs.commons.svc.BusinessService;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.FeeManualCharges;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.FeeManualChargesJpe;

public interface FeeManualChargesService extends BusinessService<FeeManualCharges, FeeManualChargesJpe> {

	public static final String SVC_OP_NAME_FEEMANUALCHARGESSERVICE_CREATE = "FeeManualChargesService.create";
	public static final String SVC_OP_NAME_FEEMANUALCHARGESSERVICE_CALCSCAMT = "FeeManualChargesService.calcScAmt";
	public static final String SVC_OP_NAME_FEEMANUALCHARGESSERVICE_GET = "FeeManualChargesService.get";

	@ServiceOperation(name = SVC_OP_NAME_FEEMANUALCHARGESSERVICE_CREATE)
	public FeeManualCharges create(FeeManualCharges dataObject);

	@ServiceOperation(name = SVC_OP_NAME_FEEMANUALCHARGESSERVICE_CALCSCAMT, type = ServiceOperationType.EXECUTE)
	public FeeManualCharges calcScAmt(FeeManualCharges dataObject);
	
	@ServiceOperation(name = SVC_OP_NAME_FEEMANUALCHARGESSERVICE_GET, type = ServiceOperationType.GET)
    public FeeManualCharges getByPk(String publicKey, FeeManualCharges reference);


}
