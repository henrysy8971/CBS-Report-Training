package com.silverlakesymmetri.cbs.dep.svc;

import java.util.List;
import java.util.Map;

import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation;
import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation.ServiceOperationType;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.svc.BusinessService;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.InstCode;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.InstCodeJpe;

public interface InstCodeService extends BusinessService<InstCode, InstCodeJpe> {
	public static final String SVC_OP_NAME_INSTCODESERVICE_GET = "InstCodeService.get";
	public static final String SVC_OP_NAME_INSTCODESERVICE_QUERY = "InstCodeService.query";
	public static final String SVC_OP_NAME_INSTCODESERVICE_CREATE = "InstCodeService.create";
	public static final String SVC_OP_NAME_INSTCODESERVICE_UPDATE = "InstCodeService.update";
	public static final String SVC_OP_NAME_INSTCODESERVICE_DELETE = "InstCodeService.delete";
	public static final String SVC_OP_NAME_INSTCODESERVICE_FIND = "InstCodeService.find";

	@ServiceOperation(name = SVC_OP_NAME_INSTCODESERVICE_CREATE)
	public InstCode create(InstCode dataObject);

	@ServiceOperation(name = SVC_OP_NAME_INSTCODESERVICE_UPDATE)
	public InstCode update(InstCode dataObject);

	@ServiceOperation(name = SVC_OP_NAME_INSTCODESERVICE_DELETE)
	public boolean delete(InstCode dataObject);

	@ServiceOperation(name = SVC_OP_NAME_INSTCODESERVICE_QUERY)
	public List<InstCode> query(int offset, int resultLimit, String groupBy, String order, Map<String, Object> filters);

	@ServiceOperation(name = SVC_OP_NAME_INSTCODESERVICE_FIND)
	public List<InstCode> find(FindCriteria findCriteria, CbsHeader cbsHeader);

	@ServiceOperation(name = SVC_OP_NAME_INSTCODESERVICE_GET, type = ServiceOperationType.GET)
	public InstCode getByPk(String publicKey, InstCode reference);

}
