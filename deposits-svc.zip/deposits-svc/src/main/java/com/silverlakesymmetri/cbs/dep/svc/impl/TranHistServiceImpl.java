package com.silverlakesymmetri.cbs.dep.svc.impl;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mysema.query.types.EntityPath;
import com.mysema.query.types.OrderSpecifier;
import com.mysema.query.types.expr.BooleanExpression;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.CbsVirtualAttribute;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.jpa.service.impl.BusinessDataObjectJpaQueryComponentImpl;
import com.silverlakesymmetri.cbs.commons.jpa.util.JaxbDatetimeAdapter;
import com.silverlakesymmetri.cbs.commons.svc.AbstractBusinessService;
import com.silverlakesymmetri.cbs.commons.svc.util.InMemoryQueryExecutor;
import com.silverlakesymmetri.cbs.commons.util.CbsStringUtil;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.ChqBuyTran;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.ChqSellTran;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.DepositTransaction;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.TdDepositTransaction;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.TdTransferTransaction;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.TdaPymtDtls;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.TranHist;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.TransferTransactionDetail;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.AcctTypeJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.ChqBuyTranJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.ChqSellTranJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.DepositTransactionJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.QTranHistJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.TdDepositTransactionJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.TdTransferTransactionJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.TdaPymtDtlsJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.TranHistJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.TransferTransactionDetailJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.id.TranHistPk;
import com.silverlakesymmetri.cbs.dep.svc.TranHistService;
import com.silverlakesymmetri.cbs.dep.svc.util.AcctHelper;

@Service
public class TranHistServiceImpl extends AbstractBusinessService<TranHist, TranHistJpe, TranHistPk> implements TranHistService {

	private static final String INTERNAL_KEY = "internalKey";
	private static final String ACCT_NO = "acctNo";
	private static final String CERTIFICATE_NO = "certificateNo";
	private static final String START_DT = "startDt";
	private static final String END_DT = "endDt";

	@Autowired
	private AcctHelper acctHelper;																	

	@Override
	public TranHist getByPk(String publicKey, TranHist reference) {
		TranHist bdo = super.getByPk(publicKey, reference);
		if (bdo != null) bdo.setTerminalId(CbsStringUtil.maskIpAddr(bdo.getTerminalId()));
		return bdo;
	}
	
	@Override
    public long getCount(Map<String, Object> filters) {		
		if (filters.size() == 0) {
			return super.getRowCount(filters);
		} else {
			List<TranHist> tranList = query(0, -1, null, null,	filters);
	        return tranList.size();
		}
    }
	
	@Override
	public List<Long> countList(Map<String, Object> filters) {
		List<Long> list = new ArrayList<Long>();
		list.add(this.getCount(filters));
		return list;
	}

	@Override
	public List<TranHist> query(int offset, int resultLimit, String groupBy, String order,
								Map<String, Object> filters) {

		if (filters.containsKey(ACCT_NO)) {
			Long internalKey;
			String acctNo = (String) filters.get(ACCT_NO);
			if (filters.containsKey(CERTIFICATE_NO)) {
				String certificateNo = (String) filters.get(CERTIFICATE_NO);
				internalKey = acctHelper.getInternalKeyByAcctNoAndCertificateNo(acctNo, certificateNo);
				filters.remove(CERTIFICATE_NO);
			} else {
				internalKey = acctHelper.getInternalKeyByAcctNo(acctNo);
			}
			filters.remove(ACCT_NO);
			if (internalKey == null) {
				internalKey = 0L;
			}
			filters.put(INTERNAL_KEY, internalKey);
		}

		if (filters.containsKey(START_DT) || filters.containsKey(END_DT)) {
			List<TranHist> bdoList = new ArrayList<>();
			BooleanExpression booleanExpression = null;
			if (filters.containsKey(START_DT)) {
				booleanExpression = QTranHistJpe.tranHistJpe.tranDate.goe(dateTimeHelper.getDate((String) filters.get(START_DT)));
				filters.remove(START_DT);
			}

			if (filters.containsKey(END_DT)) {
				BooleanExpression endDtBooleanExpression = QTranHistJpe.tranHistJpe.tranDate.loe(dateTimeHelper.getDate((String) filters.get(END_DT)));
				if (booleanExpression == null) {
					booleanExpression = endDtBooleanExpression;
				} else {
					booleanExpression = booleanExpression.and(endDtBooleanExpression);
				}
				filters.remove(END_DT);
			}

			if (filters.containsKey(INTERNAL_KEY)) {
				booleanExpression = booleanExpression.and(QTranHistJpe.tranHistJpe.internalKey.eq((Long) filters.get(INTERNAL_KEY)));
				filters.remove(INTERNAL_KEY);
			}
			OrderSpecifier<?> trandateOrder = QTranHistJpe.tranHistJpe.seqNo.desc();
			List<OrderSpecifier<?>> orders = new ArrayList<OrderSpecifier<?>>();
			orders.add(trandateOrder);

			List<TranHistJpe> jpeList = dataService.query(QTranHistJpe.tranHistJpe, booleanExpression, orders);
			if (jpeList != null) {
				if (jpeList.size() > 0) {
					for (TranHistJpe jpe : jpeList) {
						TranHist bdo = jaxbSdoHelper.wrap(jpe, TranHist.class);
						bdoList.add(bdo);
					}
					FindCriteria fc = jaxbSdoHelper.wrap(BusinessDataObjectJpaQueryComponentImpl
							.buildFindCriteria(offset, resultLimit, groupBy, order, filters));
					InMemoryQueryExecutor<TranHist> inMemQry = new InMemoryQueryExecutor<>(bdoList);
					List<TranHist> list = inMemQry.executeFilter(fc);
					if (list != null) {
						for (TranHist bdo : list) {
							bdo.setTerminalId(CbsStringUtil.maskIpAddr(bdo.getTerminalId()));
						}
					}
					return list;
				} else {
					return Collections.emptyList();
				}
			} else {
				return Collections.emptyList();
			}
		}

		List<TranHist> list = super.query(offset, resultLimit, groupBy, order, filters);
		if (list != null) {
			for (TranHist bdo : list) {
				bdo.setTerminalId(CbsStringUtil.maskIpAddr(bdo.getTerminalId()));
			}
		}
		return list;
	}

	@Override
	public List<TranHist> find(FindCriteria findCriteria, CbsHeader cbsHeader) {
		List<TranHist> list = super.find(findCriteria, cbsHeader);
		if (list != null) {
			for (TranHist bdo : list) {
				bdo.setTerminalId(CbsStringUtil.maskIpAddr(bdo.getTerminalId()));
			}
		}
		return list;
	}

	@Override
	protected TranHistPk getIdFromDataObjectInstance(TranHist dataObject) {
		return new TranHistPk(dataObject.getSeqNo(), JaxbDatetimeAdapter.parseDate(dataObject.getTranDate()));
	}

	@Override
	protected EntityPath<TranHistJpe> getEntityPath() {
		return QTranHistJpe.tranHistJpe;
	}

	@Override
	public TranHist getWithAssociatedVA(String publicKey) {
		TranHist result = super.getByPk(publicKey, null);
		if (result == null) return result;
		AcctTypeJpe acctType = acctHelper.getAcctTypeByAcctNo(result.getAcctNo());
		List<CbsVirtualAttribute> virtualAttributeList = new ArrayList<CbsVirtualAttribute>();
		TranHistJpe jpe = jaxbSdoHelper.unwrap(result);
		if(acctType != null){
			if(acctType.getDepositType().equals("T")){
				TdDepositTransactionJpe depTranEntity = new TdDepositTransactionJpe();
				depTranEntity.setSeqNo(jpe.getSeqNo());
				depTranEntity.setTranDate(jpe.getTranDate());
				dataService.attachVirtualAttributes(depTranEntity);
				TdDepositTransaction depTranBdo = jaxbSdoHelper.wrap(depTranEntity);
				if(depTranBdo.getVirtualAttributeList() != null && depTranBdo.getVirtualAttributeList().size() > 0){
					virtualAttributeList = depTranBdo.getVirtualAttributeList();	
				}
				
				if(virtualAttributeList.size() == 0){
					TdTransferTransactionJpe depTrfrTranEntity = new TdTransferTransactionJpe();
					depTrfrTranEntity.setSeqNo(jpe.getSeqNo());
					depTrfrTranEntity.setTranDate(jpe.getTranDate());
					dataService.attachVirtualAttributes(depTrfrTranEntity);
					TdTransferTransaction depTrfrTranBdo = jaxbSdoHelper.wrap(depTrfrTranEntity);
					if(depTrfrTranBdo.getVirtualAttributeList() != null && depTrfrTranBdo.getVirtualAttributeList().size() > 0){
						virtualAttributeList = depTrfrTranBdo.getVirtualAttributeList();	
					}
				}

				if(virtualAttributeList.size() == 0){
					TdaPymtDtlsJpe tdaTranEntity = new TdaPymtDtlsJpe();
					tdaTranEntity.setTranSeqNo(jpe.getSeqNo());
					tdaTranEntity.setTranDate(jpe.getTranDate());
					dataService.attachVirtualAttributes(tdaTranEntity);
					TdaPymtDtls tdaTranBdo = jaxbSdoHelper.wrap(tdaTranEntity);
					if(tdaTranBdo.getVirtualAttributeList() != null && tdaTranBdo.getVirtualAttributeList().size() > 0){
						virtualAttributeList = tdaTranBdo.getVirtualAttributeList();	
					}
				}
			} else {
				DepositTransactionJpe depTranEntity = new DepositTransactionJpe();
				depTranEntity.setSeqNo(jpe.getSeqNo());
				depTranEntity.setTranDate(jpe.getTranDate());
				dataService.attachVirtualAttributes(depTranEntity);
				DepositTransaction depTranBdo = jaxbSdoHelper.wrap(depTranEntity);
				if(depTranBdo.getVirtualAttributeList() != null && depTranBdo.getVirtualAttributeList().size() > 0){
					virtualAttributeList = depTranBdo.getVirtualAttributeList();	
				}
				
				if(virtualAttributeList.size() == 0){
					TransferTransactionDetailJpe depTrfrTranEntity = new TransferTransactionDetailJpe();
					depTrfrTranEntity.setSeqNo(jpe.getSeqNo());
					depTrfrTranEntity.setTranDate(jpe.getTranDate());
					dataService.attachVirtualAttributes(depTrfrTranEntity);
					TransferTransactionDetail depTrfrTranBdo = jaxbSdoHelper.wrap(depTrfrTranEntity);
					if(depTrfrTranBdo.getVirtualAttributeList() != null && depTrfrTranBdo.getVirtualAttributeList().size() > 0){
						virtualAttributeList = depTrfrTranBdo.getVirtualAttributeList();
					}
				}
			}
		}
		if(virtualAttributeList.size() == 0){
			ChqSellTranJpe entity = new ChqSellTranJpe();
			entity.setTranSeqNo(result.getSeqNo());
			dataService.attachVirtualAttributes(entity);
			ChqSellTran bdo = jaxbSdoHelper.wrap(entity);
			if(bdo.getVirtualAttributeList() != null && bdo.getVirtualAttributeList().size() > 0){
				virtualAttributeList = bdo.getVirtualAttributeList();	
			}
		}
		if(virtualAttributeList.size() == 0){
			ChqBuyTranJpe entity = new ChqBuyTranJpe();
			entity.setTranSeqNo(result.getSeqNo());
			dataService.attachVirtualAttributes(entity);
			ChqBuyTran bdo = jaxbSdoHelper.wrap(entity);
			if(bdo.getVirtualAttributeList() != null && bdo.getVirtualAttributeList().size() > 0){
				virtualAttributeList = bdo.getVirtualAttributeList();	
			}
		}
		
		if(result.getVirtualAttributeList() == null){
			result.setVirtualAttributeList(virtualAttributeList);
		} else {
			result.getVirtualAttributeList().addAll(virtualAttributeList);
		}
		result.setTerminalId(CbsStringUtil.maskIpAddr(result.getTerminalId()));
		return result;
	}

}
