package com.silverlakesymmetri.cbs.dep.svc.impl;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.mysema.query.types.EntityPath;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.enums.ChangeOperation;
import com.silverlakesymmetri.cbs.commons.jpa.entity.CbsBpmInfoJpe;
import com.silverlakesymmetri.cbs.commons.jpa.entity.CbsServiceMessageJpe;
import com.silverlakesymmetri.cbs.commons.jpa.util.DateTimeHelper;
import com.silverlakesymmetri.cbs.commons.jpa.util.JaxbDatetimeAdapter;
import com.silverlakesymmetri.cbs.commons.logging.CbsAppLogger;
import com.silverlakesymmetri.cbs.commons.logging.annotation.Logger;
import com.silverlakesymmetri.cbs.commons.svc.AbstractBusinessService;
import com.silverlakesymmetri.cbs.commons.svc.CbsFileUploadCapable;
import com.silverlakesymmetri.cbs.commons.svc.ref.ReferenceNumberGeneratorService;
import com.silverlakesymmetri.cbs.commons.svc.util.FileUploadUtilImpl;
import com.silverlakesymmetri.cbs.csd.bdo.sdo.IntType;
import com.silverlakesymmetri.cbs.csd.jpa.mapping.sdo.IntTypeJpe;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.IntMatrix;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.IntMatrixDtl;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.IntMatrixDtlJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.IntMatrixJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.QIntMatrixJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.id.IntMatrixPk;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.util.DepJpeConstants;
import com.silverlakesymmetri.cbs.dep.jpa.util.DepHousekeepingHelper;
import com.silverlakesymmetri.cbs.dep.svc.IntMatrixService;
import com.silverlakesymmetri.cbs.pdm.svc.PoolService;

@Service
@Transactional
public class IntMatrixServiceImpl extends AbstractBusinessService<IntMatrix, IntMatrixJpe, IntMatrixPk>
		implements IntMatrixService, CbsFileUploadCapable<IntMatrix> {

	private static final String OVERRIDE_MESSAGE = "User is setting Final Rate";

	@Logger
	CbsAppLogger logger;

	@SuppressWarnings("rawtypes")
	@Autowired
	private FileUploadUtilImpl fileUploadUtility;

	@Autowired
	private PoolService poolService;
	Map<String, Object> updateParam = new HashMap<>();

	@Autowired
	private DateTimeHelper dateTimeHelper;

	@Autowired
	private ReferenceNumberGeneratorService referenceNumberGeneratorService;

	@Autowired
	private DepHousekeepingHelper depHousekeepingHelper;

	@Override
	protected EntityPath<IntMatrixJpe> getEntityPath() {
		return QIntMatrixJpe.intMatrixJpe;
	}

	@Override
	protected IntMatrixPk getIdFromDataObjectInstance(IntMatrix dataObject) {
		return new IntMatrixPk(dataObject.getIntType(), dataObject.getCcy(),
				JaxbDatetimeAdapter.parseDate(dataObject.getEffectDate()));
	}

	@Override
	public IntMatrix getByPk(String publicKey, IntMatrix reference) {
		return super.getByPk(publicKey, reference);
	}

	@Override
	public IntMatrix create(IntMatrix dataObject) {
		IntMatrix postProcessedDataObject = super.create(dataObject);
		// will be handled by batch
		// this.checkForExpiredRates(postProcessedDataObject);
		this.findAndMarkHistoricalRates(postProcessedDataObject);
		if (dataObject.isApprovalFinalRateYn() && dataObject.getHeader().getBpmInfo().getProcessInstanceId() != 0) {
			IntMatrixJpe jpe = jaxbSdoHelper.unwrap(dataObject, IntMatrixJpe.class);
			String errorMsgParam = null;
			depHousekeepingHelper.approveFinalRate(jpe.getIntType(), jpe.getCcy(), jpe.getEffectDate(), errorMsgParam);
		}
		return postProcessedDataObject;
	}

	/*
	private void checkForExpiredRates(IntMatrix postProcessedDataObject) {
		if (postProcessedDataObject != null) {
			String query = DepJpeConstants.INT_MATRIX_DTL_FIND_EXPIRED_ENTRIES_QUERY;
			StringBuffer buffer = new StringBuffer();
			for (IntMatrixDtl detail : postProcessedDataObject.getIntMatrixDtlList()) {
				if (buffer.length() > 0) {
					buffer.append(", ");
				}
				buffer.append(detail.getBalance());
			}
			query = query.replaceFirst(":intType", "'" + postProcessedDataObject.getIntType() + "'");
			query = query.replaceFirst(":ccy", "'" + postProcessedDataObject.getCcy() + "'");
			query = query.replaceFirst(":balance", buffer.toString());

			List<IntMatrixDtlJpe> intMatrixDtlList = dataService.findWithQuery(query, IntMatrixDtlJpe.class);
			for (IntMatrixDtlJpe intMatrixDtl : intMatrixDtlList) {
				if (dateTimeHelper.isBefore(intMatrixDtl.getEffectDate(),
						dateService.convertStringTMZToDate(postProcessedDataObject.getEffectDate()))) {
					intMatrixDtl.setHistoryYn(true);
					intMatrixDtl.setHistoryDt(dateService.getRunDt());
				}
				cbsGenericDataService.update(intMatrixDtl, true);
			}
		}
	}
	 */

	@Override
	public IntMatrix update(IntMatrix dataObject) {
		IntMatrix postProcessedDataObject = super.update(dataObject);
		// will be handled by batch
		// this.checkForExpiredRates(postProcessedDataObject);
		if (dataObject.isApprovalFinalRateYn() && dataObject.getHeader().getBpmInfo().getProcessInstanceId() != 0) {
			IntMatrixJpe jpe = jaxbSdoHelper.unwrap(dataObject, IntMatrixJpe.class);
			String errorMsgParam = null;
			depHousekeepingHelper.approveFinalRate(jpe.getIntType(), jpe.getCcy(), jpe.getEffectDate(), errorMsgParam);
		}
		return postProcessedDataObject;
	}

	@Override
	public List<IntMatrix> query(int offset, int resultLimit, String groupBy, String order,
			Map<String, Object> filters) {
		return super.query(offset, resultLimit, groupBy, order, filters);
	}

	@Override
	public boolean delete(IntMatrix dataObject) {
		return super.delete(dataObject);
	}

	@Override
	public List<IntMatrix> find(FindCriteria findCriteria, CbsHeader cbsHeader) {
		return super.find(findCriteria, cbsHeader);
	}

	@Override
	public IntMatrix getHistoryByPk(String intType, String ccy, boolean finalYn) {
		IntMatrixJpe jpeInstance = new IntMatrixJpe();
		jpeInstance.setIntType(intType);
		jpeInstance.setCcy(ccy);
		String query = DepJpeConstants.INT_MATRIX_DTL_FIND_EXPIRED_ENTRIES;
		if (finalYn) {
			query = DepJpeConstants.INT_MATRIX_DTL_FINAL_FIND_EXPIRED_ENTRIES;
		}
		Map<String, Object> filter = new HashMap<>();
		filter.put("intType", intType);
		filter.put("ccy", ccy);

		List<IntMatrixDtlJpe> intMatrixDtlJpeList = dataService.findWithNamedQuery(query, filter,
				IntMatrixDtlJpe.class);
		jpeInstance.setIntMatrixDtlList(intMatrixDtlJpeList);
		IntMatrix reference = jaxbSdoHelper.wrap(jpeInstance, IntMatrix.class);
		return reference;
	}

	@Override
	public List<IntType> findCrIntForTdAcct(Map<String, Object> queryParams) {

		Date runDate = dateTimeHelper.getRunDate();
		String intType = (String) queryParams.get("intType");
		String intTypeDesc = (String) queryParams.get("intTypeDesc");
		String ccy = (String) queryParams.get("ccy");
		String asOfDate = (String) queryParams.get("asOfDate");
		if (asOfDate != null) {
			if (dateTimeHelper.getDate(asOfDate) != null) {
				runDate = dateTimeHelper.getDate(asOfDate);
			}
		}
		String groupBy = (String) queryParams.get("groupBy") == null ? "intType" : (String) queryParams.get("groupBy");
		String order = (String) queryParams.get("order") == null ? "ASC" : (String) queryParams.get("order");
		int limit = queryParams.get("limit") != null ? Integer.parseInt((String) queryParams.get("limit")) : 10;
		int offset = queryParams.get("offset") != null ? Integer.parseInt((String) queryParams.get("offset")) : 0;

		String query = DepJpeConstants.FIND_CR_INT_TYPE_FOR_TD_ACCT_QUERY;
		List<IntType> result = new ArrayList<IntType>();

		final Map<String, Object> parameters = new HashMap<>();
		parameters.put("runDate", runDate);
		parameters.put("ccy", ccy);

		if (!StringUtils.isBlank(intType)) {
			query = query + " AND UPPER(a.intType) like :intType";
			parameters.put("intType", "%" + intType.trim().toUpperCase() + "%");
		}

		if (!StringUtils.isBlank(intTypeDesc)) {
			query = query + " AND UPPER(a.intTypeDesc) like :intTypeDesc";
			parameters.put("intTypeDesc", "%" + intTypeDesc.trim().toUpperCase() + "%");
		}

		query = query + String.format(" ORDER BY a.%s %s", groupBy, order);

		List<IntTypeJpe> jpeList = dataService.findWithQuery(query, parameters, offset, limit, IntTypeJpe.class);

		if (jpeList != null && !jpeList.isEmpty()) {
			for (IntTypeJpe jpe : jpeList) {
				result.add(jaxbSdoHelper.wrap(jpe, IntType.class));
			}
		}

		return result;
	}

	@Override
	public IntMatrix getbyinttypeccyeffdt(String intType, String ccy, Date asOfDate) {
		Map<String, Object> param = new HashMap<>();
		param.put("intType", intType);
		param.put("ccy", ccy);
		param.put("asOfDate", asOfDate);
		List<IntMatrixJpe> jpelist = dataService.findWithNamedQuery(
				DepJpeConstants.INT_MATRIX_JPE_BY_INT_TYPE_CCY_AND_AS_OF_DATE, param, IntMatrixJpe.class);
		if (jpelist != null && jpelist.size() > 0) {
			IntMatrix bdo = jaxbSdoHelper.wrap(jpelist.get(0), IntMatrix.class);
			return bdo;
		}
		return null;
	}

	@Override
	public IntMatrix preCreateValidation(IntMatrix intMatrix) {
		if (intMatrix != null) {
			String lastChangeRunDate = dateTimeHelper.getSDODateTime(dateTimeHelper.getRunDate());
			if (intMatrix.getUsedYn() == null) {
				intMatrix.setUsedYn(false);
			}
			if (intMatrix.getHistoryYn() == null) {
				intMatrix.setHistoryYn(false);
			}
			if (intMatrix.getEffectiveFinalRateYn() == null) {
				intMatrix.setEffectiveFinalRateYn(false);
			}
			if (intMatrix.getApprovalFinalRateYn() == null) {
				intMatrix.setApprovalFinalRateYn(false);
			}
			for (IntMatrixDtl dtl : intMatrix.getIntMatrixDtlList()) {
				if (StringUtils.isBlank(dtl.getIntMatrixDtlRefNo())) {
					referenceNumberGeneratorService.getNewRefNo(dtl, "intMatrixDtlRefNo");
				}
				if (dtl.getHistoryYn() == null) {
					dtl.setHistoryYn(false);
				}
				dtl.setLastChangeRunDate(lastChangeRunDate);
				dtl.setFinalYn(true);
			}
			for (IntMatrixDtl dtl : intMatrix.getIntMatrixDtlDraftList()) {
				if (StringUtils.isBlank(dtl.getIntMatrixDtlRefNo())) {
					referenceNumberGeneratorService.getNewRefNo(dtl, "intMatrixDtlRefNo");
				}
				if (dtl.getHistoryYn() == null) {
					dtl.setHistoryYn(false);
				}
				dtl.setLastChangeRunDate(lastChangeRunDate);
				dtl.setFinalYn(false);
			}
		}
		return super.preCreateValidation(intMatrix);
		// return intMatrix;
	}

	@Override
	public IntMatrix preUpdateValidation(IntMatrix intMatrix) {
		for (IntMatrixDtl dtl : intMatrix.getIntMatrixDtlList()) {
			dtl.setFinalYn(true);
		}
		for (IntMatrixDtl dtl : intMatrix.getIntMatrixDtlDraftList()) {
			dtl.setFinalYn(false);
		}
		return super.preUpdateValidation(intMatrix);
	}

	@Override
	public String loadPoolRates() {

		for (Object o : poolService.loadPoolRatesMatrix()) {
			Object[] values = (Object[]) o;
			if (!Double.valueOf((Double) values[1]).equals(0.0)) {
				updateParam.put("intMatrixDtlRefNo", (String) values[0]);
				updateParam.put("intRate", (Double) values[1]);
				try {
					System.out.println("Pooling rates(M): " + (String) values[0] + " " + (Double) values[1]);
					dataService.bulkUpdateWithNamedQuery(DepJpeConstants.UPDATE_INT_MATRIX_NAME, updateParam,
							IntMatrixDtlJpe.class);
				} catch (Exception e) {
					System.out.println("Error Update IntMatrixDtlJpe " + e.getMessage());
					e.printStackTrace();
				}
			}
		}

		return "Updated";
		// return Pc.getCasa();
	}

	@Override
	public CbsBpmInfoJpe doValidateOverrideCheck(IntMatrix dataObject) {
		CbsBpmInfoJpe result = null;
		if (dataObject.isApprovalFinalRateYn()) {
			result = jaxbSdoHelper.unwrap(dataObject.getHeader().getBpmInfo());
			CbsServiceMessageJpe message = new CbsServiceMessageJpe();
			message.setMessage(OVERRIDE_MESSAGE);
			result.getServiceMessageList().add(message);
		}
		return result;
	}

	/**
	 * Set which fields are required to check for BPM duplicate request checking
	 * 
	 * @return
	 */
	@Override
	public List<String> getDataObjectUniqueFieldsForBpm() {
		return Arrays.asList("intType", "ccy", "effectDate");
	}

	@Override
	public List<IntType> findForCasaAcctCrIntType(Map<String, Object> queryParams) {
		String intType = (String) queryParams.get("intType");
		String intTypeDesc = (String) queryParams.get("intTypeDesc");
		String groupBy = (String) queryParams.get("groupBy") == null ? "intType" : (String) queryParams.get("groupBy");
		String order = (String) queryParams.get("order") == null ? "ASC" : (String) queryParams.get("order");
		int limit = queryParams.get("limit") != null ? Integer.parseInt((String) queryParams.get("limit")) : 10;
		int offset = queryParams.get("offset") != null ? Integer.parseInt((String) queryParams.get("offset")) : 0;

		String query = "SELECT it FROM IntTypeJpe it"
				+ " WHERE it.crDrInd = 'C'"
				+ " AND it.gapType IS NULL"
				+ " AND it.activeYn = true"
				+ " AND it.intType NOT IN (SELECT pptd.pretermProfitType FROM PretermProfitTypeDtlJpe pptd WHERE pptd.savingsTier IS NOT NULL)";

		final Map<String, Object> parameters = new HashMap<>();

		if (!StringUtils.isBlank(intType)) {
			query = query + " AND UPPER(it.intType) like :intType";
			parameters.put("intType", "%" + intType.trim().toUpperCase() + "%");
		}

		if (!StringUtils.isBlank(intTypeDesc)) {
			query = query + " AND UPPER(it.intTypeDesc) like :intTypeDesc";
			parameters.put("intTypeDesc", "%" + intTypeDesc.trim().toUpperCase() + "%");
		}

		query = query + String.format(" ORDER BY it.%s %s", groupBy, order);

		List<IntType> list = dataService.findWithQuery(query, parameters, offset, limit, IntType.class);

		return list;
	}
/*
	@Override
	public List<IntType> findForTdAcctCrIntType(Map<String, Object> queryParams) {
		String intType = (String) queryParams.get("intType");
		String intTypeDesc = (String) queryParams.get("intTypeDesc");
		int limit = queryParams.get("limit") != null ? Integer.parseInt((String) queryParams.get("limit")) : 10;
		int offset = queryParams.get("offset") != null ? Integer.parseInt((String) queryParams.get("offset")) : 0;

		String query = "SELECT it FROM IntTypeJpe it" + " WHERE it.crDrInd = 'C'" + " AND it.rateLadder = 'M'"
				+ " AND it.activeYn = true";

		final Map<String, Object> parameters = new HashMap<>();

		if (intType != null) {
			query = query + " AND UPPER(it.intType) like :intType";
			parameters.put("intType", "%" + intType.toUpperCase() + "%");
		}

		if (intTypeDesc != null) {
			query = query + " AND UPPER(it.intTypeDesc) like :intTypeDesc";
			parameters.put("intTypeDesc", "%" + intTypeDesc.toUpperCase() + "%");
		}

		query = query + " ORDER BY it.intType";

		List<IntType> list = dataService.findWithQuery(query, parameters, offset, limit, IntType.class);

		return list;
	}
	 */
	@Override
	public List<IntType> findPretermProfitType(Map<String, Object> queryParams) {
		String intType = (String) queryParams.get("intType");
		String intTypeDesc = (String) queryParams.get("intTypeDesc");
		String crDrInd = (String) queryParams.get("crDrInd");
		String groupBy = (String) queryParams.get("groupBy") == null ? "intType" : (String) queryParams.get("groupBy");
		String order = (String) queryParams.get("order") == null ? "ASC" : (String) queryParams.get("order");
		int limit = queryParams.get("limit") != null ? Integer.parseInt((String) queryParams.get("limit")) : 10;
		int offset = queryParams.get("offset") != null ? Integer.parseInt((String) queryParams.get("offset")) : 0;

		String query = "SELECT DISTINCT it "
				+ " FROM IntTypeJpe it "
				+ " WHERE it.rateLadder IN ('F','T','M')"
				+ " AND it.intType NOT IN (SELECT pd.crIntType FROM ProdDefaultJpe pd, AcctTypeJpe at WHERE pd.acctType = at.acctType AND pd.crIntType IS NOT NULL AND at.depositType <> 'T')"
				+ " AND it.activeYn = true";

		final Map<String, Object> parameters = new HashMap<>();

		if (!StringUtils.isBlank(intType)) {
			query = query + " AND UPPER(it.intType) like :intType";
			parameters.put("intType", "%" + intType.trim().toUpperCase() + "%");
		}

		if (!StringUtils.isBlank(intTypeDesc)) {
			query = query + " AND UPPER(it.intTypeDesc) like :intTypeDesc";
			parameters.put("intTypeDesc", "%" + intTypeDesc.trim().toUpperCase() + "%");
		}

		if (!StringUtils.isBlank(crDrInd)) {
			query = query + " AND it.crDrInd = :crDrInd";
			parameters.put("crDrInd", crDrInd);
		}

		query = query + String.format(" ORDER BY it.%s %s", groupBy, order);

		List<IntType> list = dataService.findWithQuery(query, parameters, offset, limit, IntType.class);

		return list;
	}

	@Override
	public boolean bulkCreate(List<IntMatrix> bdoList) {
		validateBulkCreateList(bdoList);

		for (IntMatrix bdo : bdoList) {
			try {
				fileUploadUtility.validateConstraints(bdo, ChangeOperation.Create);
				this.create(bdo);
			} catch (Exception e) {
				logger.error("Error encountered while processing jpe: {}", jaxbSdoHelper.unwrap(bdo), e);
				throw e;
			}
		}

		return true;
	}

	@SuppressWarnings("unchecked")
	private void validateBulkCreateList(List<IntMatrix> bdoList) {
		isDuplicatesOnList(Arrays.asList("intType", "ccy", "effectDate"), bdoList);
		for (IntMatrix intMatrix : bdoList) {
			if (intMatrix.getIntMatrixDtlList() != null && intMatrix.getIntMatrixDtlList().size() > 0) {
				List<String> uniqueChildKeyString = Arrays.asList("intType", "ccy", "effectDate", "balance", "termType", "termPeriod", "lastChangeRunDate", "historyYn", "finalYn");
				fileUploadUtility.isDuplicateOnChildLst(uniqueChildKeyString, intMatrix.getIntMatrixDtlList(), IntMatrixDtl.class);
			}
		}
	}

	@SuppressWarnings("unchecked")
	@Override
	public boolean isDuplicatesOnList(List<String> uniqueKeys, List<IntMatrix> bdoList) {
		return fileUploadUtility.isDuplicatesOnList(uniqueKeys, bdoList);
	}

	private void findAndMarkHistoricalRates(IntMatrix postCreatedDataObject) {

		if (postCreatedDataObject != null) {

			IntMatrixJpe newIntMatrixJpe = jaxbSdoHelper.unwrap(postCreatedDataObject, IntMatrixJpe.class);
			Date newIntMatrixEffDt = newIntMatrixJpe.getEffectDate();
			Date runDate = dateTimeHelper.getRunDate();

			/*
			 * Newly added record's effect date is on or before run date
			 */
			if (newIntMatrixEffDt.compareTo(runDate) <= 0) {

				Map<String, Object> params = new HashMap<>();
				params.put("intType", newIntMatrixJpe.getIntType());
				params.put("ccy", newIntMatrixJpe.getCcy());
				params.put("runDate", runDate);

				String query = "SELECT t FROM IntMatrixJpe t "
						+ " WHERE t.intType = :intType "
						+ " AND t.ccy = :ccy "
						+ " AND t.historyYn = false "
						+ " AND t.effectDate <= :runDate "
						+ " ORDER BY t.effectDate DESC";

				/*
				 * Get list of all non historical records in DEP_INT_MATRIX table
				 * that have effective date earlier than current run date
				 * and with same int_type and ccy as the newly created record
				 * sort by effect date in descending order
				 */
				List<IntMatrixJpe> nonHistIntMatrixList = dataService.findWithQuery(query, IntMatrixJpe.class, params, null);

				if (nonHistIntMatrixList != null && nonHistIntMatrixList.size() > 0) {

					Date existingEffDt = nonHistIntMatrixList.get(0).getEffectDate();

					/*
					 * Case 1:
					 * Run date – July 11
					 * Existing effect date – July 01 (active rate)
					 * New back date – June 01 (earlier than existing effect date)
					 *
					 * What system will do:
					 * 1) New back dated interest matrix record will be accepted but still to be marked as Hist
					 *    (as active record still latest)
					 * 2) Current interest matrix effect rate still prevail (Jul 01)
					 */
					if (newIntMatrixEffDt.compareTo(existingEffDt) < 0) {
						newIntMatrixJpe.setHistoryYn(true);
						newIntMatrixJpe.setHistoryDt(runDate);
						if (newIntMatrixJpe.getIntMatrixDtlList() != null) {
							for (IntMatrixDtlJpe intMatrixDtlJpe : newIntMatrixJpe.getIntMatrixDtlList()) {
								intMatrixDtlJpe.setHistoryYn(true);
								intMatrixDtlJpe.setHistoryDt(runDate);
							}
						}
						if (newIntMatrixJpe.getIntMatrixDtlDraftList() != null) {
							for (IntMatrixDtlJpe intMatrixDtlJpe : newIntMatrixJpe.getIntMatrixDtlDraftList()) {
								intMatrixDtlJpe.setHistoryYn(true);
								intMatrixDtlJpe.setHistoryDt(runDate);
							}
						}
						update(jaxbSdoHelper.wrap(newIntMatrixJpe, IntMatrix.class));
					}

					for (IntMatrixJpe nonHistIntMatrixJpe : nonHistIntMatrixList) {
						/*
						 * Case 2:
						 * Run date – July 11
						 * Existing effect date – July 01 (active rate)
						 * New back date – July 05 (later than existing effect date)
						 *
						 * What system will do:
						 * 1) All active interest matrix records with effective date before effect date
						 *    of newly inserted back dated record will be marked as HIST
						 * 2) New back date rate will take affect as active rate – July 05
						 */

						if (nonHistIntMatrixJpe.getEffectDate().compareTo(newIntMatrixEffDt) < 0) {
							nonHistIntMatrixJpe.setHistoryYn(true);
							nonHistIntMatrixJpe.setHistoryDt(runDate);
							if (nonHistIntMatrixJpe.getIntMatrixDtlList() != null) {
								for (IntMatrixDtlJpe intMatrixDtlJpe : nonHistIntMatrixJpe.getIntMatrixDtlList()) {
									intMatrixDtlJpe.setHistoryYn(true);
									intMatrixDtlJpe.setHistoryDt(runDate);
								}
							}
							if (nonHistIntMatrixJpe.getIntMatrixDtlDraftList() != null) {
								for (IntMatrixDtlJpe intMatrixDtlJpe : nonHistIntMatrixJpe.getIntMatrixDtlDraftList()) {
									intMatrixDtlJpe.setHistoryYn(true);
									intMatrixDtlJpe.setHistoryDt(runDate);
								}
							}
							update(jaxbSdoHelper.wrap(nonHistIntMatrixJpe, IntMatrix.class));
						}
					}

				}

			}

		}

	}

}
