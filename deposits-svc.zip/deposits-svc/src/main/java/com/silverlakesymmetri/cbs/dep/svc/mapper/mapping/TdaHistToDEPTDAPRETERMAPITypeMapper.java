package com.silverlakesymmetri.cbs.dep.svc.mapper.mapping;

import org.mapstruct.MapperConfig;
import org.mapstruct.Mapping;
import org.mapstruct.Mappings;

import com.silverlakesymmetri.cbs.commons.jpa.util.DateTimeHelper;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.TdaHistJpe;
import com.silverlakesymmetri.cbs.dep.xmlapi.DEPTDAPRETERMAPIType;

@MapperConfig(uses={ DateTimeHelper.class})
public interface TdaHistToDEPTDAPRETERMAPITypeMapper {

	@Mappings({
		@Mapping(source = "acctNo", target = "ACCTNO"),
		@Mapping(source = "certificateNo", target = "CERTIFICATENO"),
		@Mapping(source = "movtStatus", target = "MVMTSTATUS"),
		@Mapping(source = "pretermAmt", target = "AMTTOPRETERM"),
		@Mapping(source = "pretermIntRate", target = "PRETERMINTRATE"),
		@Mapping(source = "pretermIntAmt", target = "PRETERMINTAMT"),
		@Mapping(source = "taxAmt", target = "WITHHOLDINGTAX"),
		@Mapping(source = "intAdjAmt", target = "CRINTADJUSTMENT"),
		@Mapping(source = "amtWdrawn", target = "AMTTOWITHDRAWIND"),
		@Mapping(source = "pretermScAmt", target = "PRETERMSCAMT"),
		@Mapping(constant = "DEP", target = "SOURCEMODULE"),
		@Mapping(source = "acctOpenDate", target = "ACCTOPENDATE", qualifiedByName = {"DateTimeHelper","convertDateToCbsXmlApiDate"}),
		@Mapping(source = "maturityDate", target = "MATURITYDATE", qualifiedByName = {"DateTimeHelper","convertDateToCbsXmlApiDate"}),
		@Mapping(source = "accruedInt", target = "CRINTACCRUED"),
		@Mapping(source = "intAdjAmt", target = "CRINTADJ"),
		@Mapping(source = "netProceeds", target = "NETPROCEEDS"),
		@Mapping(source = "ledgerBal", target = "LEDGERBAL"),
		@Mapping(source = "fundsHeld", target = "FUNDSHELD"),
		@Mapping(source = "availBal", target = "AVAILBAL"),
		@Mapping(source = "remainBalInt", target = "REMAINBALINT"),
		@Mapping(source = "tdIntPayout", target = "CRTDINTPAYOUT"),
		@Mapping(source = "tdSaCrIntType", target = "TDSACRINTTYPE"),
		@Mapping(source = "newIntRate", target = "NEWINTRATE"),
		@Mapping(source = "actualIntDiff", target = "ACTUALINTDIFF"),
		@Mapping(source = "pretermIntAdj", target = "PRETERMINTADJ"),
		@Mapping(source = "autoGenFee", target = "AUTOGENFEE"),
		@Mapping(source = "collectFromThirdParty", target = "COLLECTFRTHIRDPARTY"),
		@Mapping(source = "matrixInd", target = "MATRIXIND"),
		@Mapping(source = "deferredInd", target = "DEFERREDIND"),
		@Mapping(source = "pretermProfitPayout", target = "PRETERMPROFITIND"),
		@Mapping(source = "uncollScAmt", target = "UNCOLLSCAMT"),
		@Mapping(source = "uncollFeeBGT", target = "UNCOLLFEEBGT")
	})
	public DEPTDAPRETERMAPIType mapTdaHistToDEPTDAPRETERMAPIType(TdaHistJpe jpe);

}
