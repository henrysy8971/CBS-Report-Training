package com.silverlakesymmetri.cbs.dep.svc.impl;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mysema.query.types.EntityPath;
import com.mysema.query.types.OrderSpecifier;
import com.mysema.query.types.Predicate;
import com.mysema.query.types.expr.BooleanExpression;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.exception.base.CbsServiceProcessException;
import com.silverlakesymmetri.cbs.commons.exception.base.helper.ExceptionHelper;
import com.silverlakesymmetri.cbs.commons.jpa.entity.FindCriteriaJpe;
import com.silverlakesymmetri.cbs.commons.jpa.entity.ViewCriteriaItemJpe;
import com.silverlakesymmetri.cbs.commons.jpa.entity.ViewCriteriaJpe;
import com.silverlakesymmetri.cbs.commons.jpa.entity.ViewCriteriaRowJpe;
import com.silverlakesymmetri.cbs.commons.jpa.mapping.sdo.RegistryJpe;
import com.silverlakesymmetri.cbs.commons.jpa.repository.RegistryRepository;
import com.silverlakesymmetri.cbs.commons.svc.AbstractXmlApiBusinessService;
import com.silverlakesymmetri.cbs.commons.svc.BusinessObjectValidationCapable;
import com.silverlakesymmetri.cbs.commons.xmlapi.enums.CbsXmlApiOperation;
import com.silverlakesymmetri.cbs.constants.CommonsConstants;
import com.silverlakesymmetri.cbs.csd.util.DateHelperDataHolder;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.ChequeCtrl;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.AcctJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.ChequeCtrlJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.IntMatrixDtlJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.QChequeCtrlJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.util.DepJpeConstants;
import com.silverlakesymmetri.cbs.dep.svc.ChequeCtrlService;
import com.silverlakesymmetri.cbs.dep.svc.mapper.ChequeCtrlServiceMapper;
import com.silverlakesymmetri.cbs.dep.xmlapi.DEPCHQBKRQSTAPIType;

@Service
public class ChequeCtrlServiceImpl
		extends AbstractXmlApiBusinessService<ChequeCtrl, ChequeCtrlJpe, Long, DEPCHQBKRQSTAPIType, DEPCHQBKRQSTAPIType>
		implements ChequeCtrlService, BusinessObjectValidationCapable<ChequeCtrl> {
	
	private static final String MAX_CHEQUE_NUMBER_LENGTH = "MAX_CHEQUE_NUMBER_LENGTH";
	private static final String CHEQUE_NO_MAINT = "chequeNoMaint";
	private static final String DEPOSITS_INT_REGISTRY = "DEP$_INTERNAL_REGISTRY";
	private static final String DEPOSITS_REGISTRY = "DEPOSITS_REGISTRY";
	private static final String ERROR_STARTNO_LENGTH_TOO_LARGE = "CBS.B.DEP.CHEQUE_CTRL_SERVICE.0001";
	private static final String ERROR_ENDNO_LENGTH_TOO_LARGE = "CBS.B.DEP.CHEQUE_CTRL_SERVICE.0002";
	private static final String ERROR_OVERLAP_DETECTED = "CBS.B.DEP.CHEQUE_CTRL_SERVICE.0003";
	
	@Autowired
	ChequeCtrlServiceMapper mapper;
	
	@Autowired
    RegistryRepository registryRepository;

	@Override
	protected EntityPath<ChequeCtrlJpe> getEntityPath() {
		return QChequeCtrlJpe.chequeCtrlJpe;
	}

	@Override
	protected Long getIdFromDataObjectInstance(ChequeCtrl dataObject) {
		return dataObject.getSeqNo();
	}

	@Override
	public ChequeCtrl getByPk(String publicKey, ChequeCtrl reference) {
		return super.getByPk(publicKey, reference);
	}

	@Override
	public ChequeCtrl create(ChequeCtrl dataObject) {
		return super.create(dataObject);
	}

	@Override
	public ChequeCtrl preCreateValidation(ChequeCtrl dataObject) {
		AcctJpe acctJpe = getAccount(dataObject.getAcctNo());
		dataObject.setInternalKey(acctJpe.getInternalKey());
		
		Collection<Throwable> exceptions = new ArrayList<Throwable>();
		
		RegistryJpe registry = registryRepository.find(DEPOSITS_INT_REGISTRY, MAX_CHEQUE_NUMBER_LENGTH);
		
		if (dataObject.getStartNo().toString().length() > registry.getValueN().intValue()) {
			String msg = messageUtils.getMessage(ERROR_STARTNO_LENGTH_TOO_LARGE, new String[] { dataObject.getStartNo().toString() });
            CbsServiceProcessException exec = new CbsServiceProcessException(ERROR_STARTNO_LENGTH_TOO_LARGE, msg);
            exceptions.add(exec);
		}
		
		if (dataObject.getEndNo().toString().length() > registry.getValueN().intValue()) {
			String msg = messageUtils.getMessage(ERROR_ENDNO_LENGTH_TOO_LARGE, new String[] { dataObject.getEndNo().toString() });
            CbsServiceProcessException exec = new CbsServiceProcessException(ERROR_ENDNO_LENGTH_TOO_LARGE, msg);
            exceptions.add(exec);
		}
		
		RegistryJpe chequeNoMaint = registryRepository.find(DEPOSITS_REGISTRY, CHEQUE_NO_MAINT);
		
		if (chequeNoMaint.getValueS().equalsIgnoreCase("B")) {
			Map<String, Object> param = new HashMap<String, Object>();
	        param.put("endNo", dataObject.getEndNo());
	        param.put("startNo", dataObject.getStartNo());
	        Long count = dataService.getWithNamedQuery(DepJpeConstants.GET_CHEQUE_CTRL_DUPLICATE, param, Long.class);
	        if (count > 0) {
	        	String msg = messageUtils.getMessage(ERROR_OVERLAP_DETECTED, new String[] { dataObject.getEndNo().toString() });
	            CbsServiceProcessException exec = new CbsServiceProcessException(ERROR_OVERLAP_DETECTED, msg);
	            exceptions.add(exec);
	        }
		} else if (chequeNoMaint.getValueS().equalsIgnoreCase("A")) {
			Map<String, Object> param = new HashMap<String, Object>();
			param.put("internalKey", dataObject.getInternalKey());
			param.put("endNo", dataObject.getEndNo());
	        param.put("startNo", dataObject.getStartNo());
	        Long count = dataService.getWithNamedQuery(DepJpeConstants.GET_CHEQUE_CTRL_DUPLICATE_BY_INTKEY, param, Long.class);
	        if (count > 0) {
	        	String msg = messageUtils.getMessage(ERROR_OVERLAP_DETECTED, new String[] { dataObject.getEndNo().toString() });
	            CbsServiceProcessException exec = new CbsServiceProcessException(ERROR_OVERLAP_DETECTED, msg);
	            exceptions.add(exec);
	        }
		}
		
		ExceptionHelper.createAndThrowAggregateException(exceptions);
		
		Long nextSeqNo = dataService.nextSequenceValue("DEP_CHEQUE_CTRL_S");
		dataObject.setSeqNo(nextSeqNo);
		return super.preCreateValidation(dataObject);
	}

	@Override
	public ChequeCtrl update(ChequeCtrl dataObject) {
		return super.update(dataObject);
	}

	@Override
	public boolean delete(ChequeCtrl dataObject) {
		return super.delete(dataObject);
	}

	@Override
	public List<ChequeCtrl> query(int offset, int resultLimit, String groupBy, String order,
			Map<String, Object> filters) {
		String acctNo = null;
		List<ChequeCtrl> chequeCtrlList = null;
		if (filters != null && filters.get("acctNo") != null) {
			acctNo = filters.get("acctNo").toString();
			filters.remove("acctNo");
		}
		if (acctNo != null) {
			chequeCtrlList = customQuery(offset, resultLimit, order, filters, acctNo);
		} else {
			chequeCtrlList = super.query(offset, resultLimit, groupBy, order, filters);
		}
		return chequeCtrlList;
	}

	@Override
	public List<ChequeCtrl> find(FindCriteria findCriteria, CbsHeader cbsHeader) {
		FindCriteriaJpe fcJpe = updateFC(findCriteria);
		FindCriteria fcBdo = jaxbSdoHelper.wrap(fcJpe, FindCriteria.class);
		return super.find(fcBdo, cbsHeader);
	}

	@Override
	public Long count(FindCriteria findCriteria, CbsHeader cbsHeader) {
		FindCriteriaJpe fcJpe = updateFC(findCriteria);
		return dataService.getRowCount(ChequeCtrlJpe.class, fcJpe);
	}

	private AcctJpe getAccount(String acctNo) {
		AcctJpe acctJpe = null;
		Map<String, Object> param = new HashMap<String, Object>();
		param.put("acctNo", acctNo);
		List<AcctJpe> acctJpeList = dataService.findWithNamedQuery(DepJpeConstants.ACCT_JPE_FIND_BY_ACCTNO, param,
				AcctJpe.class);
		if (acctJpeList != null && acctJpeList.size() > 0) {
			acctJpe = acctJpeList.get(0);
		}
		return acctJpe;
	}

	private List<ChequeCtrl> customQuery(int offset, int resultLimit, String order, Map<String, Object> filters,
			String acctNo) {
		final List<OrderSpecifier<?>> orders = getOrderSpecifier(QChequeCtrlJpe.chequeCtrlJpe, null, order);
		Predicate predicate = convertMapToPredicate(filters, acctNo);
		return super.query(QChequeCtrlJpe.chequeCtrlJpe, offset, resultLimit, predicate, orders);
	}

	private Predicate convertMapToPredicate(Map<String, Object> filters, String acctNo) {
		Predicate predicate = convertMapToPredicate(QChequeCtrlJpe.chequeCtrlJpe, filters);
		BooleanExpression booleanExpr = null;
		if (acctNo != null) {
			AcctJpe acctJpe = getAccount(acctNo);
			booleanExpr = QChequeCtrlJpe.chequeCtrlJpe.internalKey.eq(acctJpe.getInternalKey());
		}
		if (predicate != null) {
			predicate = ((BooleanExpression) predicate).and(booleanExpr);
		} else {
			predicate = booleanExpr;
		}
		return predicate;
	}

	private FindCriteriaJpe updateFC(FindCriteria findCriteria) {
		FindCriteriaJpe fc = null;
		String acctNo = null;
		if (findCriteria == null) {
			fc = new FindCriteriaJpe();
			ViewCriteriaJpe rootViewCriteria = new ViewCriteriaJpe();
			fc.setFilter(rootViewCriteria);
		} else {
			fc = jaxbSdoHelper.unwrap(findCriteria, true);
		}
		if (fc != null) {
			List<ViewCriteriaRowJpe> rowList = fc.getFilter().getGroup();
			for (ViewCriteriaRowJpe row : rowList) {
				List<ViewCriteriaItemJpe> itemList = row.getItem();

				for (int i = itemList.size() - 1; i >= 0; i--) {
					ViewCriteriaItemJpe vci = itemList.get(i);
					if ("acctNo".equals(vci.getAttribute()) && vci.getValue().get(0) != null) {
						acctNo = vci.getValue().get(0).toString();
						List<Object> datalist = new ArrayList<Object>();
						if (acctNo != null) {
							AcctJpe acctJpe = getAccount(acctNo);
							datalist.add(acctJpe.getInternalKey());
							vci.setAttribute("internalKey");
							vci.setOperator("=");
							vci.setValue(datalist);
							break;
						}
					}
				}
			}
		}
		return fc;
	}

	@Override
	protected DEPCHQBKRQSTAPIType transformBdoToXmlApiRqCreate(ChequeCtrl dataObject) {
		return transformChequeCtrlToDEPCHQBKRQSTAPIType(dataObject, CbsXmlApiOperation.INSERT);
	}

	@Override
	protected DEPCHQBKRQSTAPIType transformBdoToXmlApiRqUpdate(ChequeCtrl dataObject) {
		return null;
	}

	@Override
	protected DEPCHQBKRQSTAPIType transformBdoToXmlApiRqDelete(ChequeCtrl dataObject) {
		return null;
	}

	@Override
	protected ChequeCtrl processXmlApiRs(ChequeCtrl dataObject, DEPCHQBKRQSTAPIType xmlApiRs) {
		ChequeCtrlJpe jpe = jaxbSdoHelper.unwrap(dataObject);
		jpe = mapper.mapToJpe(xmlApiRs, jpe);
		return jaxbSdoHelper.wrap(jpe);
	}

	@Override
	protected Class<DEPCHQBKRQSTAPIType> getXmlApiResponseClass() {
		return DEPCHQBKRQSTAPIType.class;
	}

	private DEPCHQBKRQSTAPIType transformChequeCtrlToDEPCHQBKRQSTAPIType(ChequeCtrl dataObject,
			CbsXmlApiOperation oper) {
		ChequeCtrlJpe jpe = jaxbSdoHelper.unwrap(dataObject);
		@SuppressWarnings("rawtypes")
		DEPCHQBKRQSTAPIType apiType = mapper.mapToApi(jpe, oper, new HashMap());
		super.setTechColsFromDataObject(dataObject, apiType);
		return apiType;
	}

	@Override
	protected List<ChequeCtrl> processXmlApiListRs(ChequeCtrl dataObject, DEPCHQBKRQSTAPIType xmlApiRs) {
		return null;
	}

}
