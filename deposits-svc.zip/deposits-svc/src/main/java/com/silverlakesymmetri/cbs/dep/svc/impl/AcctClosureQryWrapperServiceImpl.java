package com.silverlakesymmetri.cbs.dep.svc.impl;

import com.mysema.query.types.EntityPath;
import com.silverlakesymmetri.cbs.col.bdo.sdo.Collateral;
import com.silverlakesymmetri.cbs.col.bdo.sdo.CollateralAssets;
import com.silverlakesymmetri.cbs.col.enums.ColGlobalConstants;
import com.silverlakesymmetri.cbs.commons.svc.AbstractBusinessService;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.Acct;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.AcctClosureQryWrapper;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.AcctClosureQryWrapperJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.AcctJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.QAcctClosureQryWrapperJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.id.AcctClosureQryWrapperPk;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.util.DepJpeConstants;
import com.silverlakesymmetri.cbs.dep.svc.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
@Transactional
public class AcctClosureQryWrapperServiceImpl extends AbstractBusinessService<AcctClosureQryWrapper, AcctClosureQryWrapperJpe, AcctClosureQryWrapperPk> implements AcctClosureQryWrapperService {

    private static final String ACCT_NO = "acctNo";
    private static final String QUERY_TYPE = "queryType";
    private static final String QUERY_BALANCE = "QUERY_BALANCE";
    private static final String INT_PAYMENT_OPTION_KEY = "intPaymentOption";

    @Autowired
    AcctService acctService;

    @Autowired
    AcctClosureQueryService acctClosureQueryService;

    @Autowired
    AcctBalInquiryService acctBalInquiryService;

    @Override
    protected AcctClosureQryWrapperPk getIdFromDataObjectInstance(AcctClosureQryWrapper dataObject) {
        return null;
    }

    @Override
    protected EntityPath<AcctClosureQryWrapperJpe> getEntityPath() {
        return QAcctClosureQryWrapperJpe.acctClosureQryWrapperJpe;
    }

    @Override
    public List<AcctClosureQryWrapper> query(int offset, int resultLimit, String groupBy, String order, Map<String, Object> filters) {
        List<AcctClosureQryWrapper> acctClosureQryWrapperList = new ArrayList<>();
        AcctClosureQryWrapper acctClosureQryWrapper = jaxbSdoHelper.createSdoInstance(AcctClosureQryWrapper.class);

        Map<String, Object> paramsMap = new HashMap<>();
        String acctNo = null;

        if (filters.containsKey(ACCT_NO)) {
            acctNo = (String) filters.get(ACCT_NO);
            paramsMap.put(ACCT_NO, acctNo);
        }
        if (filters.containsKey(INT_PAYMENT_OPTION_KEY)) {
            paramsMap.put(INT_PAYMENT_OPTION_KEY, (String) filters.get(INT_PAYMENT_OPTION_KEY));
        }
        paramsMap.put(QUERY_TYPE, QUERY_BALANCE);

        Map<String, Object> param = new HashMap<>();
        param.put("acctNo", acctNo);
        List<AcctJpe> acctJpeList = dataService.findWithNamedQuery(DepJpeConstants.ACCT_JPE_FIND_BY_ACCTNO, param, AcctJpe.class);
        Acct acct = jaxbSdoHelper.wrap(acctJpeList.get(0));
        acctClosureQryWrapper.setAcctRec(acct);
        acctClosureQryWrapper.setAcctNo(acctNo);

        acctClosureQryWrapper.setAcctClosureRec(acctClosureQueryService.query(offset, resultLimit, groupBy, order, paramsMap).get(0));
        acctClosureQryWrapper.getAcctClosureRec().setInternalKey(acctJpeList.get(0).getInternalKey());

        acctClosureQryWrapper.setAcctBalInqRec(acctBalInquiryService.getByPk(acctNo, null));

        acctClosureQryWrapperList.add(acctClosureQryWrapper);

        return acctClosureQryWrapperList;
    }

    @Override
    public AcctClosureQryWrapper getByPk(String publicKey, AcctClosureQryWrapper reference) {
        return null;
    }
}
