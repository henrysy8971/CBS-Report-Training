package com.silverlakesymmetri.cbs.dep.svc.impl;

import com.mysema.query.types.EntityPath;
import com.silverlakesymmetri.cbs.commons.svc.AbstractBusinessService;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.TdDepositTransaction;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.TdPlacementTran;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.TdTransferTransaction;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.QTdPlacementTranJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.TdPlacementTranJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.id.TdPlacementTranPk;
import com.silverlakesymmetri.cbs.dep.svc.TdDepositTransactionService;
import com.silverlakesymmetri.cbs.dep.svc.TdPlacementTranService;
import com.silverlakesymmetri.cbs.dep.svc.TdTransferTransactionService;
import com.silverlakesymmetri.cbs.dep.svc.util.AcctHelper;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class TdPlacementTranServiceImpl extends
		AbstractBusinessService<TdPlacementTran, TdPlacementTranJpe, TdPlacementTranPk>
		implements TdPlacementTranService {

	@Autowired
	private TdTransferTransactionService tdTransferTransactionService;

	@Autowired
	private TdDepositTransactionService tdDepositTransactionService;

	@Autowired
	private AcctHelper acctHelper;

	@Override
	protected TdPlacementTranPk getIdFromDataObjectInstance(TdPlacementTran dataObject) {
		Long internalKey = acctHelper.getInternalKeyByAcctNo(dataObject.getAcctNo());
		if (internalKey == null) {
			return null;
		}
		return new TdPlacementTranPk(internalKey);
	}

	@Override
	protected EntityPath<TdPlacementTranJpe> getEntityPath() {
		return QTdPlacementTranJpe.tdPlacementTranJpe;
	}

	@Override
	public TdPlacementTran create(TdPlacementTran dataObject) {
		if (dataObject.getTransferTran() != null) {
			TdTransferTransaction tdTransferTransaction = dataObject.getTransferTran();
			if (StringUtils.isBlank(tdTransferTransaction.getAcctNo())
					&& StringUtils.isNotBlank(dataObject.getAcctNo())) {
				tdTransferTransaction.setAcctNo(dataObject.getAcctNo());
			}
			if (StringUtils.isBlank(tdTransferTransaction.getCertificateNo())
					&& StringUtils.isNotBlank(dataObject.getCertificateNo())) {
				tdTransferTransaction.setCertificateNo(dataObject.getCertificateNo());
			}
			dataObject.setTransferTran(tdTransferTransactionService.create(tdTransferTransaction));
		} else {
			TdDepositTransaction tdDepositTransaction = dataObject.getDepositTran();
			if (StringUtils.isBlank(tdDepositTransaction.getAcctNo())
					&& StringUtils.isNotBlank(dataObject.getAcctNo())) {
				tdDepositTransaction.setAcctNo(dataObject.getAcctNo());
			}
			if (StringUtils.isBlank(tdDepositTransaction.getCertificateNo())
					&& StringUtils.isNotBlank(dataObject.getCertificateNo())) {
				tdDepositTransaction.setCertificateNo(dataObject.getCertificateNo());
			}
			dataObject.setDepositTran(tdDepositTransactionService.create(tdDepositTransaction));
		}
		return dataObject;
	}
}
