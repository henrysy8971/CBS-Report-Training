package com.silverlakesymmetri.cbs.dep.svc.mapper;

import java.util.Map;

import org.mapstruct.Context;
import org.mapstruct.DecoratedWith;
import org.mapstruct.InheritConfiguration;
import org.mapstruct.InheritInverseConfiguration;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingTarget;
import org.mapstruct.Mappings;

import com.silverlakesymmetri.cbs.commons.jpa.util.DateTimeHelper;
import com.silverlakesymmetri.cbs.commons.xmlapi.enums.CbsXmlApiOperation;
import com.silverlakesymmetri.cbs.csd.jpa.mapping.sdo.ProdScIndividualJpe;
import com.silverlakesymmetri.cbs.csd.xmlapi.CSDPRODSCINDIVIDUALAPIType;
import com.silverlakesymmetri.cbs.dep.svc.mapper.decorator.ProdScIndividualDecorator;
import com.silverlakesymmetri.cbs.dep.svc.mapper.mapping.ProdScIndividualToCSDPRODSCINDIVIDUALAPITypeMapper;

@Mapper(config=ProdScIndividualToCSDPRODSCINDIVIDUALAPITypeMapper.class, uses={ DateTimeHelper.class})
@DecoratedWith(ProdScIndividualDecorator.class)
public interface ProdScIndividualMapper{
	
	@Mappings({
	 @Mapping(expression = "java(oper != null ? oper.getOperation() : null)", target="OPERATION")
	 })
	@InheritConfiguration
	public CSDPRODSCINDIVIDUALAPIType mapToApi(ProdScIndividualJpe jpe, @Context CbsXmlApiOperation oper, @Context Map otherInfo);
	
	
	@Mappings({
		@Mapping(target = "effectFromDate", source="EFFECTFROMDATE", qualifiedByName = {"DateTimeHelper","convertCbsApiDateToString"}),
		@Mapping(target = "effectToDate", source="EFFECTTODATE", qualifiedByName = {"DateTimeHelper","convertCbsApiDateToString"}),
	})
	@InheritInverseConfiguration(name = "mapProdScIndividualToCSDPRODSCINDIVIDUALAPIType")
	public ProdScIndividualJpe mapToJpe(CSDPRODSCINDIVIDUALAPIType api, @MappingTarget ProdScIndividualJpe jpe);
	
}
