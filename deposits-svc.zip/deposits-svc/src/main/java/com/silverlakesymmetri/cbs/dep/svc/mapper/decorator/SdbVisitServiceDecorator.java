package com.silverlakesymmetri.cbs.dep.svc.mapper.decorator;

import org.mapstruct.Context;
import org.mapstruct.MappingTarget;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

import com.silverlakesymmetri.cbs.commons.xmlapi.enums.CbsXmlApiOperation;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.SdbVisitJpe;
import com.silverlakesymmetri.cbs.dep.svc.mapper.SdbVisitServiceMapper;
import com.silverlakesymmetri.cbs.dep.xmlapi.DEPSDBVISITAPIType;

public abstract class SdbVisitServiceDecorator implements SdbVisitServiceMapper{

	@Autowired
	@Qualifier("delegate")
	protected  SdbVisitServiceMapper delegate;
	
	@Override
	public DEPSDBVISITAPIType mapToApi(SdbVisitJpe jpe, @Context CbsXmlApiOperation oper) {
		DEPSDBVISITAPIType req = (DEPSDBVISITAPIType) delegate.mapToApi(jpe, oper);
		return req;
	}
	
	@Override
	public SdbVisitJpe mapToJpe(DEPSDBVISITAPIType api, @MappingTarget SdbVisitJpe jpe) {
		delegate.mapToJpe(api, jpe);
		return jpe;
	}
}
