package com.silverlakesymmetri.cbs.dep.svc.mapper;

import org.mapstruct.Context;
import org.mapstruct.DecoratedWith;
import org.mapstruct.InheritConfiguration;
import org.mapstruct.InheritInverseConfiguration;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingTarget;
import org.mapstruct.Mappings;

import com.silverlakesymmetri.cbs.commons.xmlapi.enums.CbsXmlApiOperation;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.AcctDashboardInfoBalJpe;
import com.silverlakesymmetri.cbs.dep.svc.mapper.decorator.AcctDashboardInfoBalServiceDecorator;
import com.silverlakesymmetri.cbs.dep.svc.mapper.mapping.AcctDashboardInfoBalToDEPACCTQRYAPITypeMapper;
import com.silverlakesymmetri.cbs.dep.xmlapi.DEPACCTQRYAPIType;

@Mapper(config=AcctDashboardInfoBalToDEPACCTQRYAPITypeMapper.class)
@DecoratedWith(AcctDashboardInfoBalServiceDecorator.class)
public interface AcctDashboardInfoBalServiceMapper{
	
	@Mappings({
		 @Mapping(expression = "java(oper != null ? oper.getOperation() : null)", target="OPERATION")
	 })
	@InheritConfiguration
	public DEPACCTQRYAPIType mapToApi(AcctDashboardInfoBalJpe jpe, @Context CbsXmlApiOperation oper);
	
	@InheritInverseConfiguration(name = "mapAcctDashboardInfoBalToDEPACCTQRYAPIType")
	public AcctDashboardInfoBalJpe mapToJpe(DEPACCTQRYAPIType api, @MappingTarget AcctDashboardInfoBalJpe jpe);
	
}
