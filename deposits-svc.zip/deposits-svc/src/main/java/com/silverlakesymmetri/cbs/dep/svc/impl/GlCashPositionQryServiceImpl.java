package com.silverlakesymmetri.cbs.dep.svc.impl;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Service;

import com.mysema.query.types.EntityPath;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.svc.AbstractBusinessService;
import com.silverlakesymmetri.cbs.commons.svc.BusinessObjectValidationCapable;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.GlCashPositionQry;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.GlCashPositionQryJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.QGlCashPositionQryJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.id.GlCashPositionQryPk;
import com.silverlakesymmetri.cbs.dep.svc.GlCashPositionQryService;

@Service
public class GlCashPositionQryServiceImpl extends AbstractBusinessService<GlCashPositionQry, GlCashPositionQryJpe, GlCashPositionQryPk>
        implements GlCashPositionQryService, BusinessObjectValidationCapable<GlCashPositionQry> {

	@Override
    protected GlCashPositionQryPk getIdFromDataObjectInstance(GlCashPositionQry dataObject) {
		if (dataObject != null) {
			return new GlCashPositionQryPk(dataObject.getBranch(), dataObject.getCcy(), dataObject.getGlCode());
		}
        return null;
    }

    @Override
    protected EntityPath<GlCashPositionQryJpe> getEntityPath() {
        return QGlCashPositionQryJpe.glCashPositionQryJpe;
    }

    @Override
    public GlCashPositionQry getByPk(String publicKey, GlCashPositionQry reference) {
        return super.getByPk(publicKey, reference);
    }

    @Override
    public List<GlCashPositionQry> query(int offset, int resultLimit, String groupBy, String order,
                                   Map<String, Object> filters) {
        return super.query(offset, resultLimit, groupBy, order, filters);
    }

    @Override
    public List<GlCashPositionQry> find(FindCriteria findCriteria, CbsHeader cbsHeader) {
        return super.find(findCriteria, cbsHeader);
    }
}
