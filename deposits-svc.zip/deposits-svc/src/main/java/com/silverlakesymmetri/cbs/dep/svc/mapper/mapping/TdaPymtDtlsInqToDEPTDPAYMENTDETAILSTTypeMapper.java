package com.silverlakesymmetri.cbs.dep.svc.mapper.mapping;

import org.mapstruct.InheritInverseConfiguration;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Mappings;

import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.TdaPymtDtlsInqJpe;
import com.silverlakesymmetri.cbs.dep.xmlapi.DEPTDPAYMENTDETAILSTType;

@Mapper()
public interface TdaPymtDtlsInqToDEPTDPAYMENTDETAILSTTypeMapper {

	@Mappings({
		@Mapping(source = "seqNo", target = "SEQNO"),
		@Mapping(source = "internalKey", target = "INTERNALKEY"),
		@Mapping(source = "batchSeqNo", target = "BATCHSEQNO"),
		@Mapping(source = "tranType", target = "TRANTYPE"),
		@Mapping(source = "tranAmt", target = "TRANAMT"),
		@Mapping(source = "crThirdPartyAcct", target = "CRTHIRDPARTYACCT")
	})
	public DEPTDPAYMENTDETAILSTType mapTdaPymtDtlsInqToDEPTDPAYMENTDETAILSTType(TdaPymtDtlsInqJpe jpe);

	@InheritInverseConfiguration(name = "mapTdaPymtDtlsInqToDEPTDPAYMENTDETAILSTType")
	public TdaPymtDtlsInqJpe mapDEPTDPAYMENTDETAILSTTypeToTdaPymtDtlsInq(DEPTDPAYMENTDETAILSTType api);

}
