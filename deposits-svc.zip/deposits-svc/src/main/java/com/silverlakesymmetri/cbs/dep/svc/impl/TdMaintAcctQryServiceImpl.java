package com.silverlakesymmetri.cbs.dep.svc.impl;

import com.mysema.query.types.EntityPath;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.svc.AbstractBusinessService;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.TdMaintAcctQry;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.QTdMaintAcctQryJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.TdMaintAcctQryJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.id.TdMaintAcctQryPk;
import com.silverlakesymmetri.cbs.dep.svc.TdMaintAcctQryService;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Map;

@Service
@Transactional
public class TdMaintAcctQryServiceImpl extends AbstractBusinessService<TdMaintAcctQry, TdMaintAcctQryJpe, TdMaintAcctQryPk> implements TdMaintAcctQryService {

	@Override
	protected EntityPath<TdMaintAcctQryJpe> getEntityPath() {
		return QTdMaintAcctQryJpe.tdMaintAcctQryJpe;
	}

	@Override
	protected TdMaintAcctQryPk getIdFromDataObjectInstance(TdMaintAcctQry dataObject) {
		Long internalKey = 0L;
		TdMaintAcctQryPk pk = new TdMaintAcctQryPk(internalKey);
		return pk;
	}

	@Override
	public TdMaintAcctQry getByPk(String publicKey, TdMaintAcctQry reference) {
		return super.getByPk(publicKey, reference);
	}


	@Override
	public List<TdMaintAcctQry> query(int offset, int resultLimit, String groupBy, String order,
			Map<String, Object> filters) {
		return super.query(offset, resultLimit, groupBy, order, filters);
	}

	@Override
	public List<TdMaintAcctQry> find(FindCriteria findCriteria, CbsHeader cbsHeader) {
		return super.find(findCriteria, cbsHeader);
	}

}
