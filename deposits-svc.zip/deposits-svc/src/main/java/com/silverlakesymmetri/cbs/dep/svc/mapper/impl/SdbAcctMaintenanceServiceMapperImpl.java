package com.silverlakesymmetri.cbs.dep.svc.mapper.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

import com.silverlakesymmetri.cbs.commons.jpa.service.CbsGenericDataService;
import com.silverlakesymmetri.cbs.commons.jpa.util.JpaEntityChangeTracker;
import com.silverlakesymmetri.cbs.commons.xmlapi.enums.CbsXmlApiOperation;
import com.silverlakesymmetri.cbs.csd.jpa.mapping.sdo.ProdScDefJpe;
import com.silverlakesymmetri.cbs.csd.jpa.mapping.sdo.ProdScIndividualJpe;
import com.silverlakesymmetri.cbs.csd.xmlapi.CSDPRODSCDEFAPIType;
import com.silverlakesymmetri.cbs.csd.xmlapi.CSDPRODSCINDIVIDUALAPIType;
import com.silverlakesymmetri.cbs.csd.xmlapi.CSDPRODSCINDIVIDUALCOLLType;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.ProdScMaintFeeJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.SdbAcctJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.SdbAssigneeJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.SdbLicenseeJpe;
import com.silverlakesymmetri.cbs.dep.svc.mapper.ProdScDefMapper;
import com.silverlakesymmetri.cbs.dep.svc.mapper.ProdScIndividualMapper;
import com.silverlakesymmetri.cbs.dep.svc.mapper.ProdScMaintFeeMapper;
import com.silverlakesymmetri.cbs.dep.svc.mapper.SdbAcctMaintenanceServiceMapper;
import com.silverlakesymmetri.cbs.dep.svc.mapper.SdbAcctMapper;
import com.silverlakesymmetri.cbs.dep.svc.mapper.SdbAssigneeMapper;
import com.silverlakesymmetri.cbs.dep.svc.mapper.SdbLicenseeMapper;
import com.silverlakesymmetri.cbs.dep.xmlapi.DEPPRODSCMAINTFEEAPIType;
import com.silverlakesymmetri.cbs.dep.xmlapi.DEPPRODSCMAINTFEECOLLType;
import com.silverlakesymmetri.cbs.dep.xmlapi.DEPSDBACCTAPIType;
import com.silverlakesymmetri.cbs.dep.xmlapi.DEPSDBASSIGNEEAPIType;
import com.silverlakesymmetri.cbs.dep.xmlapi.DEPSDBASSIGNEECOLLType;
import com.silverlakesymmetri.cbs.dep.xmlapi.DEPSDBLICENSEEAPIType;
import com.silverlakesymmetri.cbs.dep.xmlapi.DEPSDBLICENSEECOLLType;
import com.silverlakesymmetri.cbs.dep.xmlapi.DEPSDBWRAPPERAPIType;

@Component
public class SdbAcctMaintenanceServiceMapperImpl implements SdbAcctMaintenanceServiceMapper{
	
	@Autowired
	protected SdbAcctMapper sdbAcctMapper;
	
	@Autowired
	protected SdbAssigneeMapper sdbAssigneeMapper;
	
	@Autowired
	protected SdbLicenseeMapper sdbLicenseeMapper;
	
	@Autowired
	protected ProdScDefMapper prodScDefMapper;
	
	@Autowired
	protected ProdScIndividualMapper prodScIndividualMapper;
	
	@Autowired
	protected ProdScMaintFeeMapper prodScMaintFeeMapper;
	
	@Autowired(required = true)
    @Qualifier("cbsGenericDataService")
    protected CbsGenericDataService dataService;
	
	private static final String YES = "Y";
	private static final String NO = "N";
	private static final String PRODKEY = "prodKey";
	
	public DEPSDBWRAPPERAPIType mapToApi(SdbAcctJpe jpe, CbsXmlApiOperation oper){
		
		Map<String, Object> otherInfo = new HashMap<>();
				
		DEPSDBACCTAPIType acct = sdbAcctMapper.mapToApi(jpe, oper, otherInfo);
		
		DEPSDBWRAPPERAPIType  request = new DEPSDBWRAPPERAPIType();
		request.setDEPSDBACCTREC(acct);
		otherInfo.put("sdbMainClientId", jpe.getClientId().doubleValue());
		otherInfo.put("withLicensees", jpe.getWithLicensees());
		request.setDEPSDBASSIGNEEINDTLS(getDEPSDBASSIGNEEINDTLS( jpe, oper, otherInfo));
		request.setDEPSDBLICENSEEINDTLS( getDEPSDBLICENSEEINDTLS( jpe, oper, otherInfo));
		
		request.setCSDPRODSCDEFREC(getCSDPRODSCDEFAPIType( jpe, oper, otherInfo));
		request.setCSDPRODSCINDIVIDUALLIST(getCSDPRODSCINDIVIDUALCOLLType( jpe, oper, otherInfo));
		request.setDEPPRODSCMAINTFEELIST(getDEPPRODSCMAINTFEECOLLType( jpe, oper, otherInfo));
		
		request.setOPERATION(oper.getOperation());

		return request ;
	}
	
	private DEPSDBASSIGNEECOLLType getDEPSDBASSIGNEEINDTLS(SdbAcctJpe jpe, CbsXmlApiOperation oper, Map<String, Object> otherInfo){
		
		DEPSDBASSIGNEECOLLType request = new DEPSDBASSIGNEECOLLType();
		List<DEPSDBASSIGNEEAPIType> list = new ArrayList<DEPSDBASSIGNEEAPIType>();
		
		if (CbsXmlApiOperation.INSERT.equals(oper)) {
			if (!YES.equals(jpe.getWithAssignees())){
				return null;
			}
			
			if (jpe.getSdbAssigneeList() != null && !jpe.getSdbAssigneeList().isEmpty()){
				for (SdbAssigneeJpe assignee: jpe.getSdbAssigneeList()){
					assignee.setSdbInternalKey(jpe.getSdbInternalKey());
					list.add(sdbAssigneeMapper.mapToApi(assignee, oper, otherInfo));
				}
				request.getDEPSDBASSIGNEEAPI().addAll(list);
			}
			return request;
		}
		
		JpaEntityChangeTracker ct = dataService.getJpaEntityChangeTracker(jpe);
		List<SdbAssigneeJpe> delSdbAssigneeList= ct.getDeletedObjects("sdbAssigneeList", SdbAssigneeJpe.class);
		
		if (delSdbAssigneeList != null && !delSdbAssigneeList.isEmpty()){
			for (SdbAssigneeJpe deleted: delSdbAssigneeList){
				deleted.setSdbInternalKey(jpe.getSdbInternalKey());
				list.add(sdbAssigneeMapper.mapToApi(deleted, CbsXmlApiOperation.DELETE, otherInfo));
			}
		}
		
		if (CbsXmlApiOperation.DELETE.equals(oper)){
			if (list!=null && !list.isEmpty()){
				request.getDEPSDBASSIGNEEAPI().addAll(list);
			}
			return request;
		}
		
		if (CbsXmlApiOperation.UPDATE.equals(oper)){
			if (jpe.getSdbAssigneeList()!= null && !jpe.getSdbAssigneeList().isEmpty()){
				for (SdbAssigneeJpe assignee: jpe.getSdbAssigneeList()){
					assignee.setSdbInternalKey(jpe.getSdbInternalKey());
					JpaEntityChangeTracker track = dataService.getJpaEntityChangeTracker(assignee);
					if (track.isUpdated()) {
						list.add(sdbAssigneeMapper.mapToApi(assignee, CbsXmlApiOperation.UPDATE, otherInfo));
					}
					else if (track.isNew() || track.isCreated()) {
						list.add(sdbAssigneeMapper.mapToApi(assignee, CbsXmlApiOperation.INSERT, otherInfo));
					}
				}
			}
		}
		
		if (list!=null && !list.isEmpty()){
			request.getDEPSDBASSIGNEEAPI().addAll(list);
		}
		
		return request;
	}
	
	private DEPSDBLICENSEECOLLType getDEPSDBLICENSEEINDTLS(SdbAcctJpe jpe, CbsXmlApiOperation oper, Map<String, Object> otherInfo){
		
		DEPSDBLICENSEECOLLType request = new DEPSDBLICENSEECOLLType();
		List<DEPSDBLICENSEEAPIType> list = new ArrayList<DEPSDBLICENSEEAPIType>();
		
		if (CbsXmlApiOperation.INSERT.equals(oper)) {
			
			if (jpe.getSdbLicenseeList() != null && !jpe.getSdbLicenseeList().isEmpty()){
				for (SdbLicenseeJpe licensee: jpe.getSdbLicenseeList()){
					licensee.setSdbInternalKey(jpe.getSdbInternalKey());
					licensee.setMainLicenseeInd(YES.equals(licensee.getMainLicenseeInd())? YES: NO);
					list.add(sdbLicenseeMapper.mapToApi(licensee, oper, otherInfo));
				}
				request.getDEPSDBLICENSEEAPI().addAll(list);
			}
			return request;
		}
		
		JpaEntityChangeTracker ct = dataService.getJpaEntityChangeTracker(jpe);
		List<SdbLicenseeJpe> delSdbLicenseeList= ct.getDeletedObjects("sdbLicenseeList", SdbLicenseeJpe.class);
		
		if (delSdbLicenseeList != null && !delSdbLicenseeList.isEmpty()){
			for (SdbLicenseeJpe deleted: delSdbLicenseeList){
				deleted.setSdbInternalKey(jpe.getSdbInternalKey());
				list.add(sdbLicenseeMapper.mapToApi(deleted, CbsXmlApiOperation.DELETE, otherInfo));
			}
		}
		
		if (CbsXmlApiOperation.DELETE.equals(oper)){
			if (list!=null && !list.isEmpty()){
				request.getDEPSDBLICENSEEAPI().addAll(list);
			}
			return request;
		}
		
		if (CbsXmlApiOperation.UPDATE.equals(oper)){
			if (jpe.getSdbLicenseeList()!= null && !jpe.getSdbLicenseeList().isEmpty()){
				for (SdbLicenseeJpe licensee: jpe.getSdbLicenseeList()){
					licensee.setSdbInternalKey(jpe.getSdbInternalKey());
					JpaEntityChangeTracker track = dataService.getJpaEntityChangeTracker(licensee);
					if (track.isUpdated()) {
						list.add(sdbLicenseeMapper.mapToApi(licensee, CbsXmlApiOperation.UPDATE, otherInfo));
					}
					else if (track.isNew() || track.isCreated()) {
						licensee.setMainLicenseeInd(YES.equals(licensee.getMainLicenseeInd())? YES: NO);
						list.add(sdbLicenseeMapper.mapToApi(licensee, CbsXmlApiOperation.INSERT, otherInfo));
					}
				}
			}
		}
		
		if (list!=null && !list.isEmpty()){
			request.getDEPSDBLICENSEEAPI().addAll(list);
		}
		return request;
	}
	
	private CSDPRODSCDEFAPIType getCSDPRODSCDEFAPIType(SdbAcctJpe jpe, CbsXmlApiOperation oper, Map<String, Object> otherInfo){
		
		CSDPRODSCDEFAPIType api = null;
		if(jpe.getProdScDefRec() != null){
			JpaEntityChangeTracker track = dataService.getJpaEntityChangeTracker(jpe.getProdScDefRec());
			if (track.isUpdated()) {
				api =  prodScDefMapper.mapToApi(jpe.getProdScDefRec(), CbsXmlApiOperation.UPDATE, new HashMap());
			}
//			else if (track.isNew() || track.isCreated()) {
//				api =  prodScDefMapper.mapToApi(jpe.getProdScDefRec(), CbsXmlApiOperation.INSERT, new HashMap());
//			}
		}
		return api;
	}
	
	private CSDPRODSCINDIVIDUALCOLLType getCSDPRODSCINDIVIDUALCOLLType(SdbAcctJpe jpe, CbsXmlApiOperation oper, Map<String, Object> otherInfo){
		
		CSDPRODSCINDIVIDUALCOLLType api = null;
		if(jpe.getProdScIndividualList() != null && jpe.getProdScIndividualList().size() > 0){
			for(ProdScIndividualJpe scIndv : jpe.getProdScIndividualList()){
				JpaEntityChangeTracker scIndvCt = dataService.getJpaEntityChangeTracker(scIndv);
				boolean isNew = scIndvCt.isNew();
				boolean isUpdated = scIndvCt.isUpdated();
				boolean isDeleted = scIndvCt.isObjectDeleted("prodScIndividualList", ProdScIndividualJpe.class, scIndv.getPublicKey());
				
				if(isNew || isUpdated || isDeleted){
	
					CSDPRODSCINDIVIDUALAPIType scIndvApi = null;
				    otherInfo.put(PRODKEY, String.valueOf(jpe.getSdbInternalKey()));
					if(isUpdated){
					    scIndvApi = prodScIndividualMapper.mapToApi(scIndv, CbsXmlApiOperation.UPDATE, otherInfo);
					    scIndvApi.setPRODKEY(scIndv.getProdKey().doubleValue());
					} 
					else if(isNew){
						scIndvApi = prodScIndividualMapper.mapToApi(scIndv, CbsXmlApiOperation.INSERT, otherInfo);
					} 
					else {
						scIndvApi = prodScIndividualMapper.mapToApi(scIndv, CbsXmlApiOperation.DELETE, otherInfo);
					    scIndvApi.setPRODKEY(scIndv.getProdKey().doubleValue());
					}
					scIndvApi.setCCY(jpe.getCcy());
										
					if (api == null){
						api = new CSDPRODSCINDIVIDUALCOLLType();
					}
					api.getCSDPRODSCINDIVIDUALAPI().add(scIndvApi);
				}
			}
		}
		return api;
	}
	
	private DEPPRODSCMAINTFEECOLLType getDEPPRODSCMAINTFEECOLLType(SdbAcctJpe jpe, CbsXmlApiOperation oper, Map<String, Object> otherInfo){
		
		DEPPRODSCMAINTFEECOLLType api = null;
		if(jpe.getProdScMaintFeeList() != null && jpe.getProdScMaintFeeList().size() > 0){
			for(ProdScMaintFeeJpe scMaint : jpe.getProdScMaintFeeList()){
				JpaEntityChangeTracker scMaintCt = dataService.getJpaEntityChangeTracker(scMaint);
				boolean isNew = scMaintCt.isNew();
				boolean isUpdated = scMaintCt.isUpdated();
				boolean isDeleted = scMaintCt.isObjectDeleted("prodScMaintFeeList", ProdScMaintFeeJpe.class, scMaint.getPublicKey());
				if(isNew || isUpdated || isDeleted){
					
					DEPPRODSCMAINTFEEAPIType scMaintApi = null;
				    otherInfo.put(PRODKEY, String.valueOf(jpe.getSdbInternalKey()));
					if(isUpdated){
						scMaintApi = prodScMaintFeeMapper.mapToApi(scMaint, CbsXmlApiOperation.UPDATE, otherInfo);
						scMaintApi.setPRODKEY(scMaint.getProdKey().doubleValue());
					} 
					else if(isNew){
						scMaintApi = prodScMaintFeeMapper.mapToApi(scMaint, CbsXmlApiOperation.INSERT, otherInfo);
					} 
					else {
						scMaintApi = prodScMaintFeeMapper.mapToApi(scMaint, CbsXmlApiOperation.DELETE, otherInfo);
						scMaintApi.setPRODKEY(scMaint.getProdKey().doubleValue());
					}
										
					if (api == null){
						api = new DEPPRODSCMAINTFEECOLLType();
					}
					api.getDEPPRODSCMAINTFEEAPI().add(scMaintApi);
				}
			}
		}
		return api;
	}
	
	public SdbAcctJpe mapToJpe(DEPSDBWRAPPERAPIType api, SdbAcctJpe jpe) {

		if (jpe == null) {
			jpe = new SdbAcctJpe();
		}

		if (api != null) {

			sdbAcctMapper.mapToJpe(api.getDEPSDBACCTREC(), jpe);

			if (jpe.getSdbAssigneeList() == null) {
				jpe.setSdbAssigneeList(new ArrayList<SdbAssigneeJpe>());
			}
			if (api.getDEPSDBASSIGNEEINDTLS() != null && api.getDEPSDBASSIGNEEINDTLS().getDEPSDBASSIGNEEAPI() != null) {
				jpe.getSdbAssigneeList().clear();
				for (DEPSDBASSIGNEEAPIType sdbAssigneeApi : api.getDEPSDBASSIGNEEINDTLS().getDEPSDBASSIGNEEAPI()) {
					SdbAssigneeJpe sdbAssigneeJpe = new SdbAssigneeJpe();
					sdbAssigneeMapper.mapToJpe(sdbAssigneeApi, sdbAssigneeJpe);
					jpe.getSdbAssigneeList().add(sdbAssigneeJpe);
				}
			}

			if (jpe.getSdbLicenseeList() == null) {
				jpe.setSdbLicenseeList(new ArrayList<SdbLicenseeJpe>());
			}
			if (api.getDEPSDBLICENSEEINDTLS() != null && api.getDEPSDBLICENSEEINDTLS().getDEPSDBLICENSEEAPI() != null) {
				jpe.getSdbLicenseeList().clear();
				for (DEPSDBLICENSEEAPIType sdbLicenseeApi : api.getDEPSDBLICENSEEINDTLS().getDEPSDBLICENSEEAPI()) {
					SdbLicenseeJpe sdbLicenseeJpe = new SdbLicenseeJpe();
					sdbLicenseeMapper.mapToJpe(sdbLicenseeApi, sdbLicenseeJpe);
					jpe.getSdbLicenseeList().add(sdbLicenseeJpe);
				}
			}

			if (jpe.getProdScIndividualList() == null) {
				jpe.setProdScIndividualList(new ArrayList<ProdScIndividualJpe>());
			}
			if (api.getCSDPRODSCINDIVIDUALLIST() != null
					&& api.getCSDPRODSCINDIVIDUALLIST().getCSDPRODSCINDIVIDUALAPI() != null) {
				jpe.getProdScIndividualList().clear();
				for (CSDPRODSCINDIVIDUALAPIType prodScIndividualApi : api.getCSDPRODSCINDIVIDUALLIST()
						.getCSDPRODSCINDIVIDUALAPI()) {
					ProdScIndividualJpe prodScIndividualJpe = new ProdScIndividualJpe();
					prodScIndividualMapper.mapToJpe(prodScIndividualApi, prodScIndividualJpe);
					jpe.getProdScIndividualList().add(prodScIndividualJpe);
				}
			}

			if (jpe.getProdScMaintFeeList() == null) {
				jpe.setProdScMaintFeeList(new ArrayList<ProdScMaintFeeJpe>());
			}
			if (api.getDEPPRODSCMAINTFEELIST() != null
					&& api.getDEPPRODSCMAINTFEELIST().getDEPPRODSCMAINTFEEAPI() != null) {
				jpe.getProdScMaintFeeList().clear();
				for (DEPPRODSCMAINTFEEAPIType prodScMaintFeeApi : api.getDEPPRODSCMAINTFEELIST()
						.getDEPPRODSCMAINTFEEAPI()) {
					ProdScMaintFeeJpe prodScMaintFeeJpe = new ProdScMaintFeeJpe();
					prodScMaintFeeMapper.mapToJpe(prodScMaintFeeApi, prodScMaintFeeJpe);
					jpe.getProdScMaintFeeList().add(prodScMaintFeeJpe);
				}
			}

			if (api.getCSDPRODSCDEFREC() != null) {
				ProdScDefJpe prodScDefJpe = new ProdScDefJpe();
				prodScDefMapper.mapToJpe(api.getCSDPRODSCDEFREC(), prodScDefJpe);
				jpe.setProdScDefRec(prodScDefJpe);
			}

		}

		return jpe;

	}

}
