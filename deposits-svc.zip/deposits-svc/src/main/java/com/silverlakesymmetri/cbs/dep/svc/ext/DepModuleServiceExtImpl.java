package com.silverlakesymmetri.cbs.dep.svc.ext;

import java.lang.reflect.Method;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.silverlakesymmetri.cbs.commons.ext.impl.AbstractServiceExtPointImpl;
import com.silverlakesymmetri.cbs.commons.svc.QuickSearchFacilityService;
import com.silverlakesymmetri.cbs.commons.util.CbsReflectionUtils;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.Acct;
import com.silverlakesymmetri.cbs.dep.svc.AcctService;

@Service
public class DepModuleServiceExtImpl extends AbstractServiceExtPointImpl {

	@Autowired
	@Qualifier("acctCasaServiceImpl")
	private AcctService acctService;
	
	@Autowired
	private QuickSearchFacilityService quickSearchFacilityService;
	
	@Override
	public String[] getExtendedBdoNames() {
		return new String[] { "Loan" };
	}

	@Override
	public String[] getExtendedServiceNames() {
		return new String[] { "LoanService.create" };
	}

	@Override
	public Object afterService(Object result, Object[] serviceParameters) {

		if (result != null) {
			addIsiAcctToQSD(result);
			addSdAcctToQSD(result);
		}

		return result;
	}

	private void addIsiAcctToQSD(Object result) {
		String isiAcctNo = getValue(result, "isiAcctNo");
		String autoIsiAcct = getValue(result, "autoIsiAcct");
		if ("Y".equals(autoIsiAcct) && isiAcctNo != null) {
			Acct acct = acctService.getByPk(isiAcctNo, null);
			quickSearchFacilityService.populateQsData(acct);
		}
	}

	private void addSdAcctToQSD(Object result) {
		String sdAcctNo = getValue(result, "sdAcctNo");
		String autoSdAcct = getValue(result, "autoSdAcct");
		if ("Y".equals(autoSdAcct) && sdAcctNo != null) {
			Acct acct = acctService.getByPk(sdAcctNo, null);
			quickSearchFacilityService.populateQsData(acct);
		}
	}

	private String getValue(Object result, String methodName) {
		try {
			final Method method = CbsReflectionUtils.findGetMethod(result.getClass(), methodName);
			if (method == null) return null; 
			Object methodResponse = method.invoke(result);
			if (methodResponse == null) return null;
			return (String) methodResponse;
		} catch (Exception e) {
			// do nothing
		}
		return null;
	}
}
