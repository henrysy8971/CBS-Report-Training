package com.silverlakesymmetri.cbs.dep.svc.mapper.decorator;

import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

import com.silverlakesymmetri.cbs.commons.xmlapi.enums.CbsXmlApiOperation;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.DepFeeApplyJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.DepositTransactionJpe;
import com.silverlakesymmetri.cbs.dep.svc.mapper.CashDepositServiceMapper;
import com.silverlakesymmetri.cbs.dep.xmlapi.DEPTRANCTRLPARAMTType;
import com.silverlakesymmetri.cbs.dep.xmlapi.DEPTRANHISTINSAPIType;

public abstract class CashDepositServiceDecorator extends FeeServiceDecorator implements CashDepositServiceMapper{
	
	@Autowired
	@Qualifier("delegate")
	protected  CashDepositServiceMapper delegate;

	private static final String CBS_CHANNEL_SOURCE = "HTTP-UI";
	private static final String FORCE_POST = "Y";
	private static final String NOT_FORCE_POST = "N";
	
	@Override
	public DEPTRANHISTINSAPIType mapToApi(DepositTransactionJpe jpe, CbsXmlApiOperation oper, Map otherInfo){
		DEPTRANHISTINSAPIType req = (DEPTRANHISTINSAPIType)delegate.mapToApi(jpe, oper, otherInfo);
		if (otherInfo.containsKey(CHANNEL_SOURCE) && otherInfo.get(CHANNEL_SOURCE).equals(CBS_CHANNEL_SOURCE)) {
			if (otherInfo.containsKey(BRANCH)){
				req.setBRANCH((String) otherInfo.get(BRANCH));
			}
		} else {
			req.setBRANCH(jpe.getBranch());
		}
		
		DEPTRANCTRLPARAMTType ctrlParam = new DEPTRANCTRLPARAMTType();
		if (jpe.getHeader() != null && jpe.getHeader().getBpmInfo() != null && !StringUtils.isBlank(jpe.getHeader().getBpmInfo().getOfficerId())) {
			ctrlParam.setFORCEPOST(FORCE_POST);
			for (DepFeeApplyJpe feeJpe : jpe.getDepFeeApplyList()) {
				feeJpe.setForcedPost(FORCE_POST);
			}
		} else {
			ctrlParam.setFORCEPOST(NOT_FORCE_POST);
		}
		req.setCTRLPARAM(ctrlParam);
		
		mapFeeToApi(jpe, req);

		return  req;
	}
	
	@Override
	public DepositTransactionJpe mapToJpe(DEPTRANHISTINSAPIType api, DepositTransactionJpe jpe){
		jpe.setSeqNo(api.getTXNSEQNO());
		mapFeeToJpe(api, jpe);
		jpe.setAvailableBal(api.getAVAILBAL());
		jpe.setLedgerBal(api.getLEDGERBAL());
		
		return jpe;
	}
}


