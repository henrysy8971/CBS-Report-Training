package com.silverlakesymmetri.cbs.dep.svc;

import java.util.List;
import java.util.Map;

import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation;
import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation.ServiceOperationType;
import com.silverlakesymmetri.cbs.commons.svc.BusinessService;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.AcctBalInquiry;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.AcctBalInquiryJpe;

public interface AcctBalInquiryService extends BusinessService<AcctBalInquiry, AcctBalInquiryJpe> {

    public static final String SVC_OP_NAME_ACCTBALINQUIRYSERVICE_GET = "AcctBalInquiryService.get";
    public static final String SVC_OP_NAME_ACCTBALINQUIRYSERVICE_QUERY = "AcctBalInquiryService.query";

    @ServiceOperation(name = SVC_OP_NAME_ACCTBALINQUIRYSERVICE_GET, type = ServiceOperationType.GET)
    public AcctBalInquiry getByPk(String publicKey, AcctBalInquiry reference);

    @ServiceOperation(name = SVC_OP_NAME_ACCTBALINQUIRYSERVICE_QUERY)
    public List<AcctBalInquiry> query(int offset, int resultLimit, String groupBy, String order, Map<String, Object> filters);

}
