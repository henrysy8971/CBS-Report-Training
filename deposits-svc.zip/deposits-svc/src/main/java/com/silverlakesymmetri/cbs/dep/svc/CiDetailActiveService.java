package com.silverlakesymmetri.cbs.dep.svc;

import java.util.List;
import java.util.Map;

import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation;
import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation.ServiceOperationType;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.svc.BusinessService;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.CiDetailActive;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.CiDetailActiveJpe;

public interface CiDetailActiveService extends BusinessService<CiDetailActive, CiDetailActiveJpe>{
	public static final String SVC_OP_NAME_CIDETAILACTIVESERVICE_QUERY = "CiDetailActiveService.query";
	public static final String SVC_OP_NAME_CIDETAILACTIVESERVICE_FIND = "CiDetailActiveService.find";
	public static final String SVC_OP_NAME_CIDETAILACTIVESERVICE_FIND_START_CHEQUE_NO = "CiDetailActiveService.findStartChequeNo";
	public static final String SVC_OP_NAME_CIDETAILACTIVESERVICE_FIND_END_CHEQUE_NO = "CiDetailActiveService.findEndChequeNo";
	
	@ServiceOperation(name = SVC_OP_NAME_CIDETAILACTIVESERVICE_QUERY)
	public List<CiDetailActive> query(int offset, int resultLimit, String groupBy, String order, Map<String, Object> filters);
	
	@ServiceOperation(name = SVC_OP_NAME_CIDETAILACTIVESERVICE_FIND)
	public List<CiDetailActive> find(FindCriteria findCriteria, CbsHeader cbsHeader);
	
	 @ServiceOperation(name = SVC_OP_NAME_CIDETAILACTIVESERVICE_FIND_START_CHEQUE_NO ,
	            type = ServiceOperationType.READ, passParamAsMap = true)
	    public List<CiDetailActive> findStartChequeNo(Map<String, Object> queryParams);
	 
	 @ServiceOperation(name = SVC_OP_NAME_CIDETAILACTIVESERVICE_FIND_END_CHEQUE_NO ,
	            type = ServiceOperationType.READ, passParamAsMap = true)
	    public List<CiDetailActive> findEndChequeNo(Map<String, Object> queryParams);
}
