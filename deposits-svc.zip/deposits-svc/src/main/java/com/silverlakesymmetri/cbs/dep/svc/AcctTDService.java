package com.silverlakesymmetri.cbs.dep.svc;

import java.util.List;
import java.util.Map;

import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation;
import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation.ServiceOperationType;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.bdo.sdo.DmsFile;
import com.silverlakesymmetri.cbs.commons.svc.BusinessService;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.Acct;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.AcctJpe;
import com.silverlakesymmetri.cbs.xps.bdo.sdo.AdvicePreview;

public interface AcctTDService extends BusinessService<Acct, AcctJpe> {
	public static final String SVC_OP_NAME_ACCTTDSERVICE_GET= "AcctTDService.get";
	public static final String SVC_OP_NAME_ACCTTDSERVICE_QUERY= "AcctTDService.query";
	public static final String SVC_OP_NAME_ACCTTDSERVICE_CREATE= "AcctTDService.create";
	public static final String SVC_OP_NAME_ACCTTDSERVICE_UPDATE= "AcctTDService.update";
	public static final String SVC_OP_NAME_ACCTTDSERVICE_DELETE= "AcctTDService.delete";
	public static final String SVC_OP_NAME_ACCTTDSERVICE_FIND= "AcctTDService.find";
	public static final String SVC_OP_NAME_ACCTTDSERVICE_COUNT = "AcctTDService.count";
	public static final String SVC_OP_NAME_ACCTTDSERVICE_GEN_LETTEROFTHANKS = "AcctTDService.generateLetterOfThanks";
	public static final String SVC_OP_NAME_ACCTTDSERVICE_GEN_MATURITYNOTICE = "AcctTDService.generateMaturityNotice";
	public static final String SVC_OP_NAME_ACCTTDSERVICE_SEND_MATURITYNOTICE = "AcctTDService.sendMaturityNotice";
	public static final String SVC_OP_NAME_ACCTTDSERVICE_SEND_INTIMATIONLETTER = "AcctTDService.sendIntimationLetter";

	@ServiceOperation(name = SVC_OP_NAME_ACCTTDSERVICE_CREATE)
    public Acct create(Acct dataObject);

    @ServiceOperation(name = SVC_OP_NAME_ACCTTDSERVICE_UPDATE)
    public Acct update(Acct dataObject);

    @ServiceOperation(name = SVC_OP_NAME_ACCTTDSERVICE_DELETE)
    public boolean delete(Acct dataObject);

    @ServiceOperation(name = SVC_OP_NAME_ACCTTDSERVICE_QUERY)
    public List<Acct> query(int offset, int resultLimit, String groupBy, String order, Map<String, Object> filters);

    @ServiceOperation(name = SVC_OP_NAME_ACCTTDSERVICE_FIND)
    public List<Acct> find(FindCriteria findCriteria, CbsHeader cbsHeader);

    @ServiceOperation(name = SVC_OP_NAME_ACCTTDSERVICE_GET, type = ServiceOperationType.GET)
    public Acct getByPk(String publicKey, Acct reference);

	@ServiceOperation(name = SVC_OP_NAME_ACCTTDSERVICE_COUNT, type = ServiceOperationType.GET)
	public Long count(FindCriteria findCriteria, CbsHeader cbsHeader);

    @ServiceOperation(name = SVC_OP_NAME_ACCTTDSERVICE_GEN_LETTEROFTHANKS)
    public DmsFile generateLetterOfThanks(String acctNo, String locale);

    @ServiceOperation(name = SVC_OP_NAME_ACCTTDSERVICE_GEN_MATURITYNOTICE)
    public DmsFile generateMaturityNotice(String acctNo, String locale);
    
    @ServiceOperation(name = SVC_OP_NAME_ACCTTDSERVICE_SEND_MATURITYNOTICE)
    public AdvicePreview sendMaturityNotice(String acctNo, String locale, boolean isPreview);
    
    @ServiceOperation(name = SVC_OP_NAME_ACCTTDSERVICE_SEND_INTIMATIONLETTER)
    public AdvicePreview sendIntimationLetter(String acctNo, String locale, boolean isPreview);
}
