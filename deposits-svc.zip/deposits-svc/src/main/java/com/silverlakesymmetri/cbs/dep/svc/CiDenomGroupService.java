package com.silverlakesymmetri.cbs.dep.svc;

import java.util.List;
import java.util.Map;

import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation;
import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation.ServiceOperationType;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.svc.BusinessService;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.CiDenomGroup;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.CiDenomGroupJpe;


public interface CiDenomGroupService extends BusinessService<CiDenomGroup, CiDenomGroupJpe> {

    public static final String SVC_OP_NAME_CIDENOMGROUP_GET = "CiDenomGroupService.get";
    public static final String SVC_OP_NAME_CIDENOMGROUP_CREATE = "CiDenomGroupService.create";
    public static final String SVC_OP_NAME_CIDENOMGROUP_UPDATE = "CiDenomGroupService.update";
    public static final String SVC_OP_NAME_CIDENOMGROUP_DELETE = "CiDenomGroupService.delete";
    public static final String SVC_OP_NAME_CIDENOMGROUP_QUERY = "CiDenomGroupService.query";
    public static final String SVC_OP_NAME_CIDENOMGROUP_FIND = "CiDenomGroupService.find";

    @ServiceOperation(name = SVC_OP_NAME_CIDENOMGROUP_GET, type = ServiceOperationType.GET)
    public CiDenomGroup getByPk(String publicKey, CiDenomGroup reference);
    
    @ServiceOperation(name = SVC_OP_NAME_CIDENOMGROUP_CREATE)
    public CiDenomGroup create(CiDenomGroup objectInstanceIdentifier);
    
    @ServiceOperation(name = SVC_OP_NAME_CIDENOMGROUP_UPDATE)
    public CiDenomGroup update(CiDenomGroup objectInstanceIdentifier);
    
    @ServiceOperation(name = SVC_OP_NAME_CIDENOMGROUP_DELETE)
    public boolean delete(CiDenomGroup objectInstanceIdentifier);
    
    @ServiceOperation(name = SVC_OP_NAME_CIDENOMGROUP_QUERY)
    public List<CiDenomGroup> query(int offset, int resultLimit, String groupBy, String order, Map<String, Object> filters);

    @ServiceOperation(name = SVC_OP_NAME_CIDENOMGROUP_FIND)
    public List<CiDenomGroup> find(FindCriteria findCriteria, CbsHeader cbsHeader);


}
