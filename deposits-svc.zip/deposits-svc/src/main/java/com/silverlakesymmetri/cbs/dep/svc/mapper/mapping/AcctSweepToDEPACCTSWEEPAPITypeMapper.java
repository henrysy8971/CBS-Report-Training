package com.silverlakesymmetri.cbs.dep.svc.mapper.mapping;

import org.mapstruct.MapperConfig;
import org.mapstruct.Mapping;
import org.mapstruct.Mappings;

import com.silverlakesymmetri.cbs.commons.jpa.util.DateTimeHelper;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.AcctSweepJpe;
import com.silverlakesymmetri.cbs.dep.xmlapi.DEPACCTSWEEPAPIType;

@MapperConfig(uses = {DateTimeHelper.class, AcctSweepToDEPACCTSWEEPAPITypeMapper.class})
public interface AcctSweepToDEPACCTSWEEPAPITypeMapper {
	@Mappings({
		@Mapping(source = "acctNo", target="ACCTNO"),
		@Mapping(source = "effectFromDate", target="EFFECTFROMDATE", qualifiedByName = {"DateTimeHelper","convertDateToCbsXmlApiDate"}),
		@Mapping(source = "effectToDate", target="EFFECTTODATE", qualifiedByName = {"DateTimeHelper","convertDateToCbsXmlApiDate"}),
		@Mapping(source = "periodFreq", target="PERIODFREQ"),
		@Mapping(source = "freqDay", target="FREQDAY"),
		@Mapping(source = "nextSweepDate", target="NEXTSWEEPDATE", qualifiedByName = {"DateTimeHelper","convertDateToCbsXmlApiDate"}),
		@Mapping(source = "counterpartyAcctNo", target="COUNTERPARTYACCTNO"),
		@Mapping(source = "forcePost", target="FORCEPOST"),
		@Mapping(source = "type12Way", target="TYPE12WAY"),
		@Mapping(source = "sodType", target="SODTYPE"),
		@Mapping(source = "sodTargetBalance", target="SODTARGETBALANCE"),
		@Mapping(source = "sodForcePost", target="SODFORCEPOST"),
		@Mapping(source = "narrative", target="NARRATIVE"),
		@Mapping(source = "othReference", target="OTHREFERENCE"),
		@Mapping(source = "othPurposeCode", target="OTHPURPOSECODE"),
		@Mapping(source = "othSpecCode", target="OTHSPECCODE"),
		@Mapping(source = "othNarrative", target="OTHNARRATIVE"),
		@Mapping(source = "autoGenFee", target="AUTOGENFEE"),
		@Mapping(source = "eodType", target="EODTYPE"),
		@Mapping(source = "seqNo", target="SEQNO"),
		@Mapping(source = "status", target="STATUS"),
	})
	public DEPACCTSWEEPAPIType mapAcctSweepToDEPACCTSWEEPAPIType(AcctSweepJpe jpe);
}
