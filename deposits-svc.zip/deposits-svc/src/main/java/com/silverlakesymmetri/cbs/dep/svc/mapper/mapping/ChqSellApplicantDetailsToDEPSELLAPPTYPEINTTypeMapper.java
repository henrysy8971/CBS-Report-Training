package com.silverlakesymmetri.cbs.dep.svc.mapper.mapping;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Mappings;

import com.silverlakesymmetri.cbs.commons.jpa.util.DateTimeHelper;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.ChqSellApplicantDetailsJpe;
import com.silverlakesymmetri.cbs.dep.xmlapi.DEPSELLAPPLICANTINTType;

@Mapper(uses = { DateTimeHelper.class })
public interface ChqSellApplicantDetailsToDEPSELLAPPTYPEINTTypeMapper {
	
	@Mappings({
		@Mapping(source = "applicantIdType", target = "APPLIDTYPE"),
		@Mapping(source = "applicantIdNo", target = "APPLID"),
		@Mapping(source = "applicantName", target = "APPLNAME"),
		@Mapping(source = "applicantContactRefNo", target = "APPLCONTACTREFNO"),
		@Mapping(source = "applicantAddress", target = "APPLADDRESS"),
		@Mapping(source = "applicantCity", target = "APPLCITY"),
		@Mapping(source = "applicantState", target = "APPLSTATE"),
		@Mapping(source = "applicantCountry", target = "APPLCOUNTRY"),
		@Mapping(source = "applicantPostalCode", target = "APPLPOSTALCODE"),
		@Mapping(source = "applicantContactDtl", target = "APPLCONTACTDTL")
	})
	public DEPSELLAPPLICANTINTType jpeToApiType(ChqSellApplicantDetailsJpe jpe);
	
}
