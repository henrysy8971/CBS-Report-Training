package com.silverlakesymmetri.cbs.dep.svc.mapper.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

import com.silverlakesymmetri.cbs.commons.jpa.service.CbsGenericDataService;
import com.silverlakesymmetri.cbs.commons.jpa.util.JpaEntityChangeTracker;
import com.silverlakesymmetri.cbs.commons.xmlapi.enums.CbsXmlApiOperation;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.AcctJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.SiDetailJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.SiHeaderJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.util.DepJpeConstants;
import com.silverlakesymmetri.cbs.dep.svc.mapper.SiDetailMapper;
import com.silverlakesymmetri.cbs.dep.svc.mapper.SiHeaderMapper;
import com.silverlakesymmetri.cbs.dep.svc.mapper.StandingInstructionServiceMapper;
import com.silverlakesymmetri.cbs.dep.xmlapi.DEPSIDETAILAPIType;
import com.silverlakesymmetri.cbs.dep.xmlapi.DEPSIDETAILCOLLType;
import com.silverlakesymmetri.cbs.dep.xmlapi.DEPSIHEADERAPIType;
import com.silverlakesymmetri.cbs.dep.xmlapi.DEPSIWRAPPERAPIType;

@Component
public class StandingInstructionServiceMapperImpl implements StandingInstructionServiceMapper{
	
	@Autowired
	protected SiHeaderMapper siHeaderMapper;
	
	@Autowired
	protected SiDetailMapper siDetailMapper;
	
	@Autowired(required = true)
    @Qualifier("cbsGenericDataService")
    protected CbsGenericDataService dataService;
	
	private AcctJpe getAccount(String acctNo){
		AcctJpe acctJpe = null;
		Map<String,Object> param = new HashMap<String, Object>();
		param.put("acctNo", acctNo);
		List<AcctJpe> acctJpeList = dataService.findWithNamedQuery(DepJpeConstants.ACCT_JPE_FIND_BY_ACCTNO, param, AcctJpe.class);
		if (acctJpeList!=null && acctJpeList.size()>0){
			acctJpe = acctJpeList.get(0);
		}
		return acctJpe;
	}

	public DEPSIWRAPPERAPIType mapToApi(SiHeaderJpe jpe, CbsXmlApiOperation oper){
		
		Map otherInfo = new HashMap<>();
		
		AcctJpe acct =  getAccount(jpe.getAcctNo());
		if (acct != null){
			jpe.setInternalKey(acct.getInternalKey());
		}
		
		DEPSIHEADERAPIType header = siHeaderMapper.mapToApi(jpe, oper, otherInfo);
		
		DEPSIWRAPPERAPIType  request = new DEPSIWRAPPERAPIType();
		request.setDEPSIREC(header);
		request.setDEPSILIST(getDEPSILIST(jpe, oper, otherInfo));
		request.setOPERATION(oper.getOperation());
		return request ;
	}
	
	private DEPSIDETAILCOLLType getDEPSILIST(SiHeaderJpe jpe, CbsXmlApiOperation oper, Map otherInfo){
		
		DEPSIDETAILCOLLType request = new DEPSIDETAILCOLLType();
		List<DEPSIDETAILAPIType> list = new ArrayList<DEPSIDETAILAPIType>();
		
		if (CbsXmlApiOperation.INSERT.equals(oper)) {			
			if (jpe.getSiDetailList() != null && !jpe.getSiDetailList().isEmpty()){
				for (SiDetailJpe sd: jpe.getSiDetailList()){
					sd.setInternalKey(jpe.getInternalKey());
					list.add(siDetailMapper.mapToApi(sd, oper, otherInfo));
				}
				request.getDEPSIDETAILAPI().addAll(list);
			}
			return request;
		}
		
		JpaEntityChangeTracker ct = dataService.getJpaEntityChangeTracker(jpe);
		List<SiDetailJpe> delSiDetailJpeList = ct.getDeletedObjects("siDetailList", SiDetailJpe.class);
		
		if (delSiDetailJpeList != null && !delSiDetailJpeList.isEmpty()){
			for (SiDetailJpe deleted: delSiDetailJpeList){
				deleted.setInternalKey(jpe.getInternalKey());
				list.add(siDetailMapper.mapToApi(deleted, CbsXmlApiOperation.DELETE, otherInfo));
			}
		}
		
		if (CbsXmlApiOperation.DELETE.equals(oper)){
			if (list!=null && !list.isEmpty()){
				request.getDEPSIDETAILAPI().addAll(list);
			}
			return request;
		}
		
		if (CbsXmlApiOperation.UPDATE.equals(oper)){
			if (jpe.getSiDetailList()!= null && !jpe.getSiDetailList().isEmpty()){
				for (SiDetailJpe sd: jpe.getSiDetailList()){
					sd.setInternalKey(jpe.getInternalKey());
					JpaEntityChangeTracker track = dataService.getJpaEntityChangeTracker(sd);
					if (track.isUpdated()) {
						list.add(siDetailMapper.mapToApi(sd, CbsXmlApiOperation.UPDATE, otherInfo));
					}
					else if (track.isNew() || track.isCreated()) {
						list.add(siDetailMapper.mapToApi(sd, CbsXmlApiOperation.INSERT, otherInfo));
					}
				}
			}
		}
		
		if (list!=null && !list.isEmpty()){
			request.getDEPSIDETAILAPI().addAll(list);
		}
		
		return request;
	}
	
	public SiHeaderJpe mapToJpe(DEPSIWRAPPERAPIType api,  SiHeaderJpe jpe){
		
		if (jpe == null){
			jpe = new SiHeaderJpe();
		}
		
		jpe = siHeaderMapper.mapToJpe(api.getDEPSIREC(), jpe);
	
		if (api.getDEPSILIST() == null || api.getDEPSILIST().getDEPSIDETAILAPI() == null ||
			api.getDEPSILIST().getDEPSIDETAILAPI().isEmpty()){
			return jpe;
		}
			
		List <SiDetailJpe> arr = new ArrayList<SiDetailJpe>();
		for (DEPSIDETAILAPIType sd:  api.getDEPSILIST().getDEPSIDETAILAPI()){
			SiDetailJpe p = siDetailMapper.mapToJpe(sd, new SiDetailJpe());
			arr.add(p);
		}
		jpe.setSiDetailList(arr);
		
		return jpe;	
	}
	
}
	