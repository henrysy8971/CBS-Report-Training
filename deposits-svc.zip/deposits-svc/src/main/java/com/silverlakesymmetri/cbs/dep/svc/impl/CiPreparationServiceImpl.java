package com.silverlakesymmetri.cbs.dep.svc.impl;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.mysema.query.types.EntityPath;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.context.CbsSessionContext;
import com.silverlakesymmetri.cbs.commons.jpa.entity.FindCriteriaJpe;
import com.silverlakesymmetri.cbs.commons.jpa.util.DateTimeHelper;
import com.silverlakesymmetri.cbs.commons.svc.AbstractBusinessService;
import com.silverlakesymmetri.cbs.commons.svc.CustomValidationCapable;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.CiPreparation;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.CommonDepObject;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.CiDetailActiveJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.CiPreparationJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.QCiPreparationJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.id.CiPreparationPk;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.util.DepJpeConstants;
import com.silverlakesymmetri.cbs.dep.svc.CiPreparationService;
//import com.silverlakesymmetri.cbs.dep.util.CommonDepObject;

@Service
@Transactional
public class CiPreparationServiceImpl extends AbstractBusinessService<CiPreparation, CiPreparationJpe, CiPreparationPk> implements CiPreparationService, CustomValidationCapable<CommonDepObject> 
{

	@Autowired
    private DateTimeHelper dateTimeHelper;
	
	@Override
    public CiPreparation getByPk(String publicKey, CiPreparation reference) {
        return super.getByPk(publicKey, reference);
    }
	
    @Override
    public List<CiPreparation> query(int offset, int resultLimit, String groupBy, String order, Map<String, Object> filters) {
        return super.query(offset, resultLimit, groupBy, order, filters);
    }

    @Override
    public List<CiPreparation> find(FindCriteria findCriteria, CbsHeader cbsHeader) {
        return super.find(findCriteria, cbsHeader);
    }
    
    @Override
	public CommonDepObject customValidate(CommonDepObject summary) {
		//Do the validations here
    	summary.setSeqNo((long) 1);
		return summary;
	}


	@Override
	public void approve(CommonDepObject obj) {
		
		if (obj == null){
			return;
		}
		
		String listForApproval = obj.getPubKeyList();
		if (StringUtils.isEmpty(listForApproval)){
			return;
		}
		
		List<String> chequeStatusList = new ArrayList<String>(Arrays.asList(new String[]{"BOT","SOL"}));
//		List<String> chequeStatusList = new ArrayList<String>(Arrays.asList(new String[]{"REG","DIS"}));
		List<String> recordIdList = new ArrayList<String>(Arrays.asList(listForApproval.split(",")));
		Map<String, Object> params = new HashMap<>();
		params.put("chequeStatusList", chequeStatusList);
		params.put("recordIdList", recordIdList);
		List<CiDetailActiveJpe> result = dataService.findWithNamedQuery(DepJpeConstants.CIDETAILACTIVE_JPE_FIND_BY_SEQNO, params, CiDetailActiveJpe.class);

		if (result == null || result.isEmpty()){
			return;
		}
		
		Map<String, List<Long>> mapSeqNo = new HashMap<String, List<Long>>();
		for (CiDetailActiveJpe detail: result){										 
			List<Long> listSeqNo = !mapSeqNo.containsKey(detail.getChequeStatus()) ? 
												 new ArrayList<Long>() : mapSeqNo.get(detail.getChequeStatus());										 
			listSeqNo.add(detail.getSeqNo());
			mapSeqNo.put(detail.getChequeStatus(), listSeqNo);
		}
		
		CbsSessionContext sessionCtx = cbsRuntimeContextManager.getContext(CbsSessionContext.class);
		
		for (String key: mapSeqNo.keySet()){
			List<Long> listSeqNo = mapSeqNo.get(key);
			
			Map<String, Object> p = new HashMap<>();
			p.put("prevChequeStatus", key);
//			p.put("chequeStatus", "REG".equals(key)?"RXX":"DXX");
			p.put("chequeStatus", "BOT".equals(key)?"PPB":"PPS");
			p.put("prepDate",dateTimeHelper.getRunDate());
			p.put("lastChangeDate",dateTimeHelper.getRunDate());
			p.put("lastChangeOfficer",sessionCtx.getUserCode());
			p.put("recordIdList", listSeqNo);
			
			dataService.bulkUpdateWithNamedQuery(DepJpeConstants.CIDETAILACTIVE_JPE_APPROVE_BY_SEQNO, p, CiDetailActiveJpe.class);
		}
	}

	@Override
	protected CiPreparationPk getIdFromDataObjectInstance(CiPreparation dataObject) {
		// TODO Auto-generated method stub
		return new CiPreparationPk(dataObject.getSeqNo());
	}

	@Override
	protected EntityPath<CiPreparationJpe> getEntityPath() {
		// TODO Auto-generated method stub
		return QCiPreparationJpe.ciPreparationJpe;
	}
	
	public List<CiPreparation> getTotals(FindCriteria findCriteria, CbsHeader cbsHeader) {
		List<CiPreparation> rs = null;
		
		FindCriteriaJpe fc =jaxbSdoHelper.unwrap(findCriteria, FindCriteriaJpe.class);
		long sum = dataService.getRowCount(CiPreparationJpe.class, fc);
		
		if (sum <=0){
			CiPreparationJpe c= new CiPreparationJpe();
			c.setTotalAmt(new Double(0));
			c.setTotalRecordNo(new Integer(0));
			List<CiPreparation> list = new ArrayList<CiPreparation>();
			list.add(jaxbSdoHelper.wrap(c, CiPreparation.class));
	        return list;
		}
		
		if (findCriteria == null){
			rs = super.query(0, new Integer(String.valueOf(sum)), null, null, new HashMap());
		}
		else{
			findCriteria.setFetchSize(new Integer(String.valueOf(sum)));
			rs = super.find(findCriteria, cbsHeader);
		}
				
		Double total = new Double(0);
		for (CiPreparation item: rs){
			total = total + item.getAmount(); 
		}
		
		CiPreparationJpe c= new CiPreparationJpe();
		c.setTotalAmt(total);
		c.setTotalRecordNo(new Integer(String.valueOf(sum)));
		List<CiPreparation> list = new ArrayList<CiPreparation>();
		list.add(jaxbSdoHelper.wrap(c, CiPreparation.class));
        return list;
    }
}
