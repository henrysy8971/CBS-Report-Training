package com.silverlakesymmetri.cbs.dep.svc.impl;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mysema.query.types.EntityPath;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.exception.base.CbsServiceProcessException;
import com.silverlakesymmetri.cbs.commons.exception.base.helper.ExceptionHelper;
import com.silverlakesymmetri.cbs.commons.jpa.entity.FindCriteriaJpe;
import com.silverlakesymmetri.cbs.commons.jpa.entity.ViewCriteriaItemJpe;
import com.silverlakesymmetri.cbs.commons.jpa.entity.ViewCriteriaJpe;
import com.silverlakesymmetri.cbs.commons.jpa.entity.ViewCriteriaRowJpe;
import com.silverlakesymmetri.cbs.commons.svc.AbstractXmlApiBusinessService;
import com.silverlakesymmetri.cbs.commons.svc.BusinessObjectValidationCapable;
import com.silverlakesymmetri.cbs.commons.xmlapi.enums.CbsXmlApiOperation;
import com.silverlakesymmetri.cbs.csd.util.DateHelperDataHolder;
import com.silverlakesymmetri.cbs.csd.util.DateHelperUtil;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.AcctSweep;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.AcctTypeChange;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.TdTransferTransaction;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.AcctJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.AcctSweepJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.QAcctSweepJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.id.AcctSweepPk;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.util.DepJpeConstants;
import com.silverlakesymmetri.cbs.dep.svc.AcctSweepService;
import com.silverlakesymmetri.cbs.dep.svc.DepositsValidatorService;
import com.silverlakesymmetri.cbs.dep.svc.mapper.AcctSweepServiceMapper;
import com.silverlakesymmetri.cbs.dep.xmlapi.DEPACCTSWEEPAPIType;

/**
 * 
 * @author Jeffrey.Villanueva, Leoneil.Batulan
 *
 */
@Service
public class AcctSweepServiceImpl extends AbstractXmlApiBusinessService<AcctSweep, AcctSweepJpe, AcctSweepPk, DEPACCTSWEEPAPIType, DEPACCTSWEEPAPIType>
		implements AcctSweepService, BusinessObjectValidationCapable<AcctSweep> {

	private static final String ERROR_EFFECT_FROM_DATE_IS_HOLIDAY = "CBS.B.DEP.ACCT_SWEEP_SERVICE.0001";
	private static final String ERROR_EFFECT_TO_DATE_IS_HOLIDAY = "CBS.B.DEP.ACCT_SWEEP_SERVICE.0010";
	private static final String ERROR_NEXT_SWEEP_DATE_IS_HOLIDAY = "CBS.B.DEP.ACCT_SWEEP_SERVICE.0011";
	private static final String TARGET_BALANCE_FIX = "FIX";
	private static final String TARGET_BALANCE_MIN = "MIN";
	private static final String TARGET_BALANCE_MAX = "MAX";
	private static final String DEP_ACCT_SWEEP = "DEP_ACCT_SWEEP_S";
	
	@Autowired
	private DateHelperUtil dateHelperUtil;
	
	@Autowired
	AcctSweepServiceMapper mapper;
	
	@Autowired
    DepositsValidatorService depositsValidatorService;
	
	@Override
	protected EntityPath<AcctSweepJpe> getEntityPath() {
		return QAcctSweepJpe.acctSweepJpe;
	}

	@Override
	protected AcctSweepPk getIdFromDataObjectInstance(AcctSweep dataObject) {
		return new AcctSweepPk(dataObject.getSeqNo());
	}

	/* (non-Javadoc)
	 * @see com.silverlakesymmetri.cbs.commons.svc.AbstractBusinessService#preCreateValidation(com.silverlakesymmetri.cbs.commons.bdo.CbsBusinessDataObject)
	 */
	@Override
	protected AcctSweep preCreateValidation(AcctSweep dataObject) {
		
		validateDates(dataObject);
		dataObject.setStatus("C");

		Long seqNo = dataService.nextSequenceValue(DEP_ACCT_SWEEP).longValue();
		dataObject.setSeqNo(seqNo);

		return super.preCreateValidation(dataObject);
	}
	
	private void validateDates(AcctSweep dataObject) {
		Collection<Throwable> exceptions = new ArrayList<>();
		// Effect From Date cannot be a holiday

		if(dataObject.getCcy() == null && dataObject.getCounterpartyAcctNo() != null) {
			AcctJpe acctJpe = getAccount(dataObject.getCounterpartyAcctNo());
			if (acctJpe != null && acctJpe.getCcy() != null) {
				dataObject.setCcy(acctJpe.getCcy());
			}
		}

		if (dataObject.getEffectFromDate() != null) {
			DateHelperDataHolder holder = dateHelperUtil.createGeneralDateDataHolder(dataObject.getType().getName(), "effectFromDate", dataObject);
			if (dateHelperUtil.checkHoliday(holder)) {
				String msg = messageUtils.getMessage(ERROR_EFFECT_FROM_DATE_IS_HOLIDAY, new String[] { dataObject.getEffectFromDate() });
	            CbsServiceProcessException exec = new CbsServiceProcessException(ERROR_EFFECT_FROM_DATE_IS_HOLIDAY, msg);
	            exceptions.add(exec);
			}	
		}
		// Effect To Date cannot be a holiday
		if (dataObject.getEffectToDate() != null) {
			DateHelperDataHolder holder = dateHelperUtil.createGeneralDateDataHolder(dataObject.getType().getName(), "effectToDate", dataObject);
			if (dateHelperUtil.checkHoliday(holder)) {
				String msg = messageUtils.getMessage(ERROR_EFFECT_TO_DATE_IS_HOLIDAY, new String[] { dataObject.getEffectToDate() });
	            CbsServiceProcessException exec = new CbsServiceProcessException(ERROR_EFFECT_TO_DATE_IS_HOLIDAY, msg);
	            exceptions.add(exec);
			}	
		}
		// Next Sweep Date cannot be a holiday
		if (dataObject.getNextSweepDate() != null) {
			DateHelperDataHolder holder = dateHelperUtil.createGeneralDateDataHolder(dataObject.getType().getName(), "nextSweepDate", dataObject);
			if (dateHelperUtil.checkHoliday(holder)) {
				String msg = messageUtils.getMessage(ERROR_NEXT_SWEEP_DATE_IS_HOLIDAY, new String[] { dataObject.getNextSweepDate() });
	            CbsServiceProcessException exec = new CbsServiceProcessException(ERROR_NEXT_SWEEP_DATE_IS_HOLIDAY, msg);
	            exceptions.add(exec);
			}	
		}
		ExceptionHelper.createAndThrowAggregateException(exceptions);
	}

	/* (non-Javadoc)
	 * @see com.silverlakesymmetri.cbs.commons.svc.AbstractBusinessService#create(com.silverlakesymmetri.cbs.commons.bdo.CbsBusinessDataObject)
	 */
	@Override
	public AcctSweep create(AcctSweep dataObject) {
//		AcctJpe acctJpe = getAccount(dataObject.getAcctNo());
//		if (acctJpe!=null){
//			dataObject.setInternalKey(acctJpe.getInternalKey());
//		}		
		return super.create(dataObject);
	}

	/* (non-Javadoc)
	 * @see com.silverlakesymmetri.cbs.commons.svc.AbstractBusinessService#getByPk(java.lang.String, com.silverlakesymmetri.cbs.commons.bdo.CbsBusinessDataObject)
	 */
	@Override
	public AcctSweep getByPk(String publicKey, AcctSweep reference) {
		AcctSweep acctSweep = super.getByPk(publicKey, reference);
		processAcctSweepDetail(acctSweep);
		return acctSweep;
	}

	@Override
	public Long count(FindCriteria findCriteria, CbsHeader cbsHeader) {
		FindCriteriaJpe fcJpe = updateFC(findCriteria);
		return dataService.getRowCount(AcctSweepJpe.class, fcJpe);
	}
	
	@Override
	public boolean delete(AcctSweep dataObject) {
		return super.delete(dataObject);
	}

	@Override
	public List<AcctSweep> find(FindCriteria findCriteria, CbsHeader cbsHeader) {
		FindCriteriaJpe fcJpe = updateFC(findCriteria);
		FindCriteria fcBdo = jaxbSdoHelper.wrap(fcJpe, FindCriteria.class);
		List<AcctSweep> acctSweepList = super.find(fcBdo, cbsHeader);
		return acctSweepList;
	}

	@Override
	public List<AcctSweep> query(int offset, int resultLimit, String groupBy, String order, Map<String, Object> filters) {
		return super.query(offset, resultLimit, groupBy, order, filters);
	}

	@Override
	public AcctSweep update(AcctSweep dataObject) {
		return super.update(dataObject);
	}

	@Override
	protected DEPACCTSWEEPAPIType transformBdoToXmlApiRqCreate(AcctSweep dataObject) {
		return transformAcctSweepToDEPACCTSWEEPAPIType(dataObject, CbsXmlApiOperation.INSERT);
	}

	@Override
	protected DEPACCTSWEEPAPIType transformBdoToXmlApiRqUpdate(AcctSweep dataObject) {
		return transformAcctSweepToDEPACCTSWEEPAPIType(dataObject, CbsXmlApiOperation.UPDATE);
	}

	@Override
	protected DEPACCTSWEEPAPIType transformBdoToXmlApiRqDelete(AcctSweep dataObject) {
		return transformAcctSweepToDEPACCTSWEEPAPIType(dataObject, CbsXmlApiOperation.DELETE);
	}

	@Override
	protected AcctSweep processXmlApiRs(AcctSweep dataObject, DEPACCTSWEEPAPIType xmlApiRs) {
		AcctSweepJpe jpe = jaxbSdoHelper.unwrap(dataObject);
		
		Double segNo = xmlApiRs.getSEQNO();
		dataObject.setSeqNo(segNo.longValue());
		dataObject.setStatus(xmlApiRs.getSTATUS());
		mapper.mapToJpe(xmlApiRs, jpe);
		dataObject = jaxbSdoHelper.wrap(jpe);
		return dataObject;
	}

	@Override
	protected List<AcctSweep> processXmlApiListRs(AcctSweep dataObject, DEPACCTSWEEPAPIType xmlApiRs) {
		return new ArrayList<>();
	}

	@Override
	protected Class<DEPACCTSWEEPAPIType> getXmlApiResponseClass() {
		return DEPACCTSWEEPAPIType.class;
	}
	
	private DEPACCTSWEEPAPIType transformAcctSweepToDEPACCTSWEEPAPIType(AcctSweep dataObject, CbsXmlApiOperation oper){
		Map map = new HashMap();
		AcctSweepJpe jpe = jaxbSdoHelper.unwrap(dataObject);
		DEPACCTSWEEPAPIType apiType = mapper.mapToApi(jpe, oper, map);
		super.setTechColsFromDataObject(dataObject, apiType);		
//		apiType.setOPERATION(oper.getOperation());
		
		if (dataObject.getSeqNo()!=null){
			apiType.setSEQNO(dataObject.getSeqNo().doubleValue());
		}
		if (dataObject.getFreqDay()!=null){
			apiType.setFREQDAY(dataObject.getFreqDay().doubleValue());
		}
		if (dataObject.getSodTargetBalance()!=null){
			if (TARGET_BALANCE_FIX.equals(dataObject.getSodTargetBalance())){
				apiType.setSODAMT((dataObject.getSodFixAmt()!=null)?dataObject.getSodFixAmt().doubleValue():null);
			} else if (TARGET_BALANCE_MIN.equals(dataObject.getSodTargetBalance())){
				apiType.setSODAMT((dataObject.getSodMinAmt()!=null)?dataObject.getSodMinAmt().doubleValue():null);
			} else if (TARGET_BALANCE_MAX.equals(dataObject.getSodTargetBalance())){
				apiType.setSODAMT((dataObject.getSodMaxAmt()!=null)?dataObject.getSodMaxAmt().doubleValue():null);
			}
		}
		apiType.setTARGETBALANCE(dataObject.getEodTargetBalance());
		if (dataObject.getEodTargetBalance()!=null){
			if (TARGET_BALANCE_FIX.equals(dataObject.getEodTargetBalance())){
				apiType.setAMT((dataObject.getFixAmt()!=null)?dataObject.getFixAmt().doubleValue():null);
			} else if (TARGET_BALANCE_MIN.equals(dataObject.getEodTargetBalance())){
				apiType.setAMT((dataObject.getMinAmt()!=null)?dataObject.getMinAmt().doubleValue():null);
			} else if (TARGET_BALANCE_MAX.equals(dataObject.getEodTargetBalance())){
				apiType.setAMT((dataObject.getMaxAmt()!=null)?dataObject.getMaxAmt().doubleValue():null);
			}
		}
		
		return apiType;
	}
	
	private AcctJpe getAccount(String acctNo){
		AcctJpe acctJpe = null;
		Map<String,Object> param = new HashMap<>();
		param.put("acctNo", acctNo);
		List<AcctJpe> acctJpeList = dataService.findWithNamedQuery(DepJpeConstants.ACCT_JPE_FIND_BY_ACCTNO, param, AcctJpe.class);
		if (acctJpeList!=null && !acctJpeList.isEmpty()){
			acctJpe = acctJpeList.get(0);
		}
		return acctJpe;
	}
	
	private void processAcctSweepDetail(AcctSweep acctSweep){
		// populate EodTargetBalance
		if (acctSweep.getFixAmt()!=null){
			acctSweep.setEodTargetBalance(TARGET_BALANCE_FIX);
		} else if (acctSweep.getMinAmt()!=null){
			acctSweep.setEodTargetBalance(TARGET_BALANCE_MIN);
		} else if (acctSweep.getMaxAmt()!=null){
			acctSweep.setEodTargetBalance(TARGET_BALANCE_MAX);
		}
		
		// populate SodTargetBalance
		if (acctSweep.getSodFixAmt()!=null){
			acctSweep.setSodTargetBalance(TARGET_BALANCE_FIX);
		} else if (acctSweep.getSodMinAmt()!=null){
			acctSweep.setSodTargetBalance(TARGET_BALANCE_MIN);
		} else if (acctSweep.getSodMaxAmt()!=null){
			acctSweep.setSodTargetBalance(TARGET_BALANCE_MAX);
		}
	}
	
	private FindCriteriaJpe updateFC(FindCriteria findCriteria) {
		FindCriteriaJpe fc = null;
		String acctNo = null;
		if (findCriteria == null) {
			fc = new FindCriteriaJpe();
	        ViewCriteriaJpe rootViewCriteria = new ViewCriteriaJpe();
	        fc.setFilter(rootViewCriteria);
		} else {
			fc = jaxbSdoHelper.unwrap(findCriteria, true);
		}
		if (fc != null) {
			List<ViewCriteriaRowJpe> rowList = fc.getFilter().getGroup();
			for (ViewCriteriaRowJpe row : rowList) {
				List<ViewCriteriaItemJpe> itemList = row.getItem();

				for (int i = itemList.size() - 1; i >= 0; i--) {
					ViewCriteriaItemJpe vci = itemList.get(i);
					if ("acctNo".equals(vci.getAttribute()) && vci.getValue().get(0) != null) {
						acctNo = vci.getValue().get(0).toString();
						List<Object> datalist = new ArrayList<Object>();
						if (acctNo!=null){
							AcctJpe acctJpe = getAccount(acctNo);
							datalist.add(acctJpe.getInternalKey());
							vci.setAttribute("internalKey");
					        vci.setOperator("=");
					        vci.setValue(datalist);
							break;
						}
					}
				}
			}
		}
		return fc;
	}
	
	@Override
	public AcctSweep validateCreateRequest(AcctSweep dataObject) {
    	
		validateTransferAllowed(dataObject);
    	return super.validateCreateRequest(dataObject);
    }
	
	private void validateTransferAllowed(AcctSweep dataObject){
		
		String returnCode = depositsValidatorService.isFinancialTransferAllowedByAcctNos(dataObject.getCounterpartyAcctNo(), dataObject.getAcctNo());
	}
}
