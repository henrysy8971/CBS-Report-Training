package com.silverlakesymmetri.cbs.dep.svc.mapper.mapping;

import org.mapstruct.MapperConfig;
import org.mapstruct.Mapping;
import org.mapstruct.Mappings;

import com.silverlakesymmetri.cbs.commons.jpa.util.DateTimeHelper;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.TdaVInqJpe;
import com.silverlakesymmetri.cbs.dep.xmlapi.DEPTDHISTORYQRYAPIType;

@MapperConfig(uses = { DateTimeHelper.class, TdaVInqToDEPTDHISTORYQRYAPITypeMapper.class })
public interface TdaVInqToDEPTDHISTORYQRYAPITypeMapper {

	@Mappings({
		@Mapping(source = "seqNo", target = "SEQNO"),
		@Mapping(source = "internalKey", target = "INTERNALKEY"),
		@Mapping(source = "acctNo", target = "ACCTNO"),
		@Mapping(source = "certificateNo", target = "CERTIFICATENO"),
		@Mapping(source = "acctOpenDate", target = "ACCTOPENDATE", qualifiedByName = { "DateTimeHelper", "convertDateToCbsXmlApiDate" }),
		@Mapping(source = "movtStatus", target = "MOVTSTATUS"),
		@Mapping(source = "principalAmt", target = "PRINCIPALAMT"),
		@Mapping(source = "depTermPeriod", target = "DEPTERMPERIOD"),
		@Mapping(source = "depTermType", target = "DEPTERMTYPE"),
		@Mapping(source = "depTermDays", target = "DEPTERMDAYS"),
		@Mapping(source = "effectiveRate", target = "EFFECTRATE"),
		@Mapping(source = "maturityDate", target = "MATURITYDATE", qualifiedByName = { "DateTimeHelper", "convertDateToCbsXmlApiDate" }),
		@Mapping(source = "calcNetInterestAmt", target = "NETINTERESTAMT"),
		@Mapping(source = "autoRenewRollover", target = "AUTORENEWROLLOVER"),
		@Mapping(source = "acctMovtDate", target = "ACCTMOVTDATE", qualifiedByName = { "DateTimeHelper", "convertDateToCbsXmlApiDate" }),
		@Mapping(source = "addtlPrincipal", target = "ADDTLPRINCIPAL"),
		@Mapping(source = "tranHistSeqNo", target = "TDAHISTSEQNO"),
		@Mapping(source = "amtWdrawn", target = "AMTWITHDRAWN")
	})
	public DEPTDHISTORYQRYAPIType mapTdaVInqToDEPTDHISTORYQRYAPIType(TdaVInqJpe jpe);


}
