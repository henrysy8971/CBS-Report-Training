package com.silverlakesymmetri.cbs.dep.svc.impl;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.mysema.query.types.EntityPath;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.svc.AbstractBusinessService;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.CiDenomGroup;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.CiDenomGroupJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.QCiDenomGroupJpe;
import com.silverlakesymmetri.cbs.dep.svc.CiDenomGroupService;


@Service
@Transactional
public class CiDenomGroupServiceImpl extends AbstractBusinessService<CiDenomGroup, CiDenomGroupJpe, String> implements CiDenomGroupService {

    @Override
    protected String getIdFromDataObjectInstance(CiDenomGroup dataObject) {
        return dataObject.getDenomGroup();
    }

    @Override
    protected EntityPath<CiDenomGroupJpe> getEntityPath() {
        return QCiDenomGroupJpe.ciDenomGroupJpe;
    }
    
    @Override
    protected CiDenomGroup preCreateValidation(CiDenomGroup dataObject) {
    	CiDenomGroupJpe jpe = jaxbSdoHelper.unwrap(dataObject);
        if (null == jpe.isUsedYn()) {
        	jpe.setUsedYn(false);
        }
        if (null == jpe.isActiveYn()) {
        	jpe.setActiveYn(false);
        }
        
        dataObject = jaxbSdoHelper.wrap(jpe, CiDenomGroup.class);
        return super.preCreateValidation(dataObject);
    }
    
    @Override
    public CiDenomGroup get(CiDenomGroup objectInstanceIdentifier) {
        return super.get(objectInstanceIdentifier);
    }
    
    @Override
    public CiDenomGroup create(CiDenomGroup objectInstanceIdentifier) {
        return super.create(objectInstanceIdentifier);
    }
    
    @Override
    public CiDenomGroup update(CiDenomGroup objectInstanceIdentifier) {
        return super.update(objectInstanceIdentifier);
    }
    
    @Override
    public boolean delete(CiDenomGroup objectInstanceIdentifier) {
        return super.delete(objectInstanceIdentifier);
    }

    @Override
    public List<CiDenomGroup> query(int offset, int resultLimit, String groupBy, String order, Map<String, Object> filters) {
        return super.query(offset, resultLimit, groupBy, order, filters);
    }

    @Override
    public List<CiDenomGroup> find(FindCriteria findCriteria, CbsHeader cbsHeader) {
        return super.find(findCriteria, cbsHeader);
    }

    @Override
    public CiDenomGroup getByPk(String publicKey, CiDenomGroup reference) {
        return super.getByPk(publicKey, reference);
    }
}
