package com.silverlakesymmetri.cbs.dep.svc.impl;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.mysema.query.types.EntityPath;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.svc.AbstractBusinessService;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.CiType;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.CiTypeJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.QCiTypeJpe;
import com.silverlakesymmetri.cbs.dep.svc.CiTypeService;


@Service
@Transactional
public class CiTypeServiceImpl extends AbstractBusinessService<CiType, CiTypeJpe, String> implements CiTypeService {

    @Override
    protected String getIdFromDataObjectInstance(CiType dataObject) {
        return dataObject.getChequeType();
    }

    @Override
    protected EntityPath<CiTypeJpe> getEntityPath() {
        return QCiTypeJpe.ciTypeJpe;
    }
    
    @Override
    protected CiType preCreateValidation(CiType dataObject) {
    	CiTypeJpe jpe = jaxbSdoHelper.unwrap(dataObject);
        if (null == jpe.isUsedYn()) {
        	jpe.setUsedYn(false);
        }
        if (null == jpe.isActiveYn()) {
        	jpe.setActiveYn(false);
        }
        
        dataObject = jaxbSdoHelper.wrap(jpe, CiType.class);
        return super.preCreateValidation(dataObject);
    }
    
    @Override
    public CiType get(CiType objectInstanceIdentifier) {
        return super.get(objectInstanceIdentifier);
    }
    
    @Override
    public CiType create(CiType objectInstanceIdentifier) {
        return super.create(objectInstanceIdentifier);
    }
    
    @Override
    public CiType update(CiType objectInstanceIdentifier) {
        return super.update(objectInstanceIdentifier);
    }
    
    @Override
    public boolean delete(CiType objectInstanceIdentifier) {
        return super.delete(objectInstanceIdentifier);
    }

    @Override
    public List<CiType> query(int offset, int resultLimit, String groupBy, String order, Map<String, Object> filters) {
        return super.query(offset, resultLimit, groupBy, order, filters);
    }

    @Override
    public List<CiType> find(FindCriteria findCriteria, CbsHeader cbsHeader) {
        return super.find(findCriteria, cbsHeader);
    }

    @Override
    public CiType getByPk(String publicKey, CiType reference) {
        return super.getByPk(publicKey, reference);
    }
}
