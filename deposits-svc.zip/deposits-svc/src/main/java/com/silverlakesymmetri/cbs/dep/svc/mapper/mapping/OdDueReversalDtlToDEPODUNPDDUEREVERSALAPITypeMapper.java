package com.silverlakesymmetri.cbs.dep.svc.mapper.mapping;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Mappings;

import com.silverlakesymmetri.cbs.commons.jpa.util.DateTimeHelper;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.OdDueReversalDtlJpe;
import com.silverlakesymmetri.cbs.dep.xmlapi.DEPODUNPDDUEREVERSALAPIType;

@Mapper(uses = { DateTimeHelper.class })
public interface OdDueReversalDtlToDEPODUNPDDUEREVERSALAPITypeMapper {
	
	@Mappings({
		@Mapping(target = "acctNo", source = "ACCTNO"),
		@Mapping(target = "internalKey", source = "INTERNALKEY"),
		@Mapping(target = "seqNo", source = "SEQNO"),
		@Mapping(target = "dueDate", source = "DUEDATE", qualifiedByName = {"DateTimeHelper","convertCbsApiDateToString"}),
		@Mapping(target = "dueType", source = "DUETYPE"),
		@Mapping(target = "dueDesc", source = "DUEDESC"),
		@Mapping(target = "dueAmt", source = "DUEAMT"),
		@Mapping(target = "paidAmt", source = "PAIDAMT")
		//REVREASON
	})
	public OdDueReversalDtlJpe apiTypeToJpe(DEPODUNPDDUEREVERSALAPIType apiType);
	
	@Mappings({
		@Mapping(source = "acctNo", target = "ACCTNO"),
		@Mapping(source = "internalKey", target = "INTERNALKEY"),
		@Mapping(source = "seqNo", target = "SEQNO"),
		@Mapping(source = "dueDate", target = "DUEDATE", qualifiedByName = {"DateTimeHelper","convertDateToCbsXmlApiDate"}),
		@Mapping(source = "dueType", target = "DUETYPE"),
		@Mapping(source = "dueDesc", target = "DUEDESC"),
		@Mapping(source = "dueAmt", target = "DUEAMT"),
		@Mapping(source = "paidAmt", target = "PAIDAMT")
		//REVREASON
	})
	public DEPODUNPDDUEREVERSALAPIType jpeToApiType(OdDueReversalDtlJpe jpe);
	
}
