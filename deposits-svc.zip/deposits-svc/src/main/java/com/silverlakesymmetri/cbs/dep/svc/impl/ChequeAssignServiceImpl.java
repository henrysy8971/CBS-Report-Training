package com.silverlakesymmetri.cbs.dep.svc.impl;

import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.mysema.query.types.EntityPath;
import com.silverlakesymmetri.cbs.commons.context.CbsSessionContext;
import com.silverlakesymmetri.cbs.commons.svc.AbstractXmlApiBusinessService;
import com.silverlakesymmetri.cbs.commons.xmlapi.enums.CbsXmlApiOperation;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.ChequeAssign;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.ChequeAssignDetail;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.ChequeAssignJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.id.ChequeAssignPk;
import com.silverlakesymmetri.cbs.dep.svc.ChequeAssignService;
import com.silverlakesymmetri.cbs.dep.xmlapi.DEPCHQASSIGNAPIType;
import com.silverlakesymmetri.cbs.dep.xmlapi.DEPDENOMGRPDTLSCOLLType;
import com.silverlakesymmetri.cbs.dep.xmlapi.DEPDENOMGRPDTLSTType;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.QChequeAssignJpe;

@Service
@Transactional
public class ChequeAssignServiceImpl extends AbstractXmlApiBusinessService<ChequeAssign, ChequeAssignJpe, ChequeAssignPk, DEPCHQASSIGNAPIType, DEPCHQASSIGNAPIType> 
	implements ChequeAssignService{
	
	@Override
	protected ChequeAssignPk getIdFromDataObjectInstance(ChequeAssign dataObject) {
		ChequeAssignJpe jpe = jaxbSdoHelper.unwrap(dataObject);
		return new ChequeAssignPk(jpe.getTransferMode(),
				jpe.getUserCodeFrom(),
				jpe.getUserCodeTo(),
				jpe.getChequeType(),
				jpe.getCcy());
	}

	@Override
	protected EntityPath<ChequeAssignJpe> getEntityPath() {
		return QChequeAssignJpe.chequeAssignJpe;
	}
	
	@Override
	public ChequeAssign get(ChequeAssign chequeAssign) {
		return chequeAssign;
	}
	
	@Override
	public ChequeAssign create(ChequeAssign dataObject) {
		return super.create(dataObject);
	}
	
	@Override
	protected DEPCHQASSIGNAPIType transformBdoToXmlApiRqCreate(ChequeAssign dataObject) {
		return transformChequeAssignToDEPCHQASSIGNAPIType(dataObject, CbsXmlApiOperation.UPDATE);
	}

	@Override
	protected DEPCHQASSIGNAPIType transformBdoToXmlApiRqUpdate(ChequeAssign dataObject) {
		return null;
	}

	@Override
	protected DEPCHQASSIGNAPIType transformBdoToXmlApiRqDelete(ChequeAssign dataObject) {
		return null;
	}

	@Override
	protected ChequeAssign processXmlApiRs(ChequeAssign dataObject, DEPCHQASSIGNAPIType xmlApiRs) {
		if(dataObject == null) {
			dataObject = jaxbSdoHelper.createSdoInstance(ChequeAssign.class);
		}
		ChequeAssignJpe jpe = jaxbSdoHelper.unwrap(dataObject);
		dataObject = jaxbSdoHelper.wrap(jpe);
		return dataObject;
	}

	@Override
	protected List<ChequeAssign> processXmlApiListRs(ChequeAssign dataObject, DEPCHQASSIGNAPIType xmlApiRs) {
		return null;
	}

	@Override
	protected Class<DEPCHQASSIGNAPIType> getXmlApiResponseClass() {
		return DEPCHQASSIGNAPIType.class;
	}
	
	private DEPCHQASSIGNAPIType transformChequeAssignToDEPCHQASSIGNAPIType(ChequeAssign dataObject, CbsXmlApiOperation oper) {

		ChequeAssignJpe jpe = jaxbSdoHelper.unwrap(dataObject);
		DEPCHQASSIGNAPIType api = new DEPCHQASSIGNAPIType();
		CbsSessionContext sessionCtx = cbsRuntimeContextManager.getContext(CbsSessionContext.class);
		
		api.setASSIGNMODE(jpe.getTransferMode());
		api.setBRANCH(sessionCtx.getBranch());
		api.setCCY(jpe.getCcy());
		api.setCHEQUETYPE(jpe.getChequeType());
		api.setFROMOFFICERID(jpe.getUserCodeFrom());
		api.setTOOFFICERID(jpe.getUserCodeTo());
		api.setLASTCHANGEOFFICER(jpe.getUserCodeFrom());
		api.setOPERATION(oper.getOperation());
		
		super.setTechColsFromDataObject(dataObject, api);
		
		DEPDENOMGRPDTLSCOLLType detailColl = new DEPDENOMGRPDTLSCOLLType();
		
		for(ChequeAssignDetail detail: dataObject.getChequeAssignDetailList()) {
			DEPDENOMGRPDTLSTType chequeAssignDetail = new DEPDENOMGRPDTLSTType();
			if(detail.getDenomination() == null) {
				chequeAssignDetail.setDENOMINATION(0);
			}else {
				chequeAssignDetail.setDENOMINATION(Integer.parseInt(detail.getDenomination().trim()));
			}
			chequeAssignDetail.setPREFIX(detail.getPrefix());
			chequeAssignDetail.setSTARTCHEQUENO(detail.getStartChequeNo().intValue());
			chequeAssignDetail.setENDCHEQUENO(detail.getEndChequeNo().intValue());
			chequeAssignDetail.setQUANTITY(detail.getQuantity().intValue());
			detailColl.getDEPDENOMGRPDTLST().add(chequeAssignDetail);
		}
		api.setDEPDENOMGRPLIST(detailColl);
		
		return api;
	}
}
