package com.silverlakesymmetri.cbs.dep.svc.mapper;

import java.util.Map;

import org.mapstruct.Context;
import org.mapstruct.DecoratedWith;
import org.mapstruct.InheritConfiguration;
import org.mapstruct.InheritInverseConfiguration;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingTarget;
import org.mapstruct.Mappings;

import com.silverlakesymmetri.cbs.commons.jpa.util.DateTimeHelper;
import com.silverlakesymmetri.cbs.commons.xmlapi.enums.CbsXmlApiOperation;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.CiSettlementJpe;
import com.silverlakesymmetri.cbs.dep.svc.mapper.decorator.CiSettlementBuyServiceDecorator;
import com.silverlakesymmetri.cbs.dep.svc.mapper.mapping.CiSettlementToDEPCIPROCESSSETTLEBUYAPITypeMapper;
import com.silverlakesymmetri.cbs.dep.xmlapi.DEPCIPROCESSSETTLEBUYAPIType;

@Mapper(config=CiSettlementToDEPCIPROCESSSETTLEBUYAPITypeMapper.class, uses={ DateTimeHelper.class})
@DecoratedWith(CiSettlementBuyServiceDecorator.class)
public interface CiSettlementBuyServiceMapper{
	
	@Mappings({
		 @Mapping(expression = "java(oper != null ? oper.getOperation() : null)", target="OPERATION")
	 })
	@InheritConfiguration
	public DEPCIPROCESSSETTLEBUYAPIType mapToApi(CiSettlementJpe jpe, @Context CbsXmlApiOperation oper, @Context Map otherInfo);
	
	
	@InheritInverseConfiguration(name = "mapCiSettlementToDEPCIPROCESSSETTLEBUYAPIType")
//	@Mapping(source = "EFFECTDATE", target="trfDate", qualifiedByName = {"DateTimeHelper","convertCbsApiDateToString"})
	public CiSettlementJpe mapToJpe(DEPCIPROCESSSETTLEBUYAPIType api, @MappingTarget CiSettlementJpe jpe);
	
}
