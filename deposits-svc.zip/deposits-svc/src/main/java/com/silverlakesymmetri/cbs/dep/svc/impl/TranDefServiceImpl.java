package com.silverlakesymmetri.cbs.dep.svc.impl;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.mysema.query.types.EntityPath;
import com.mysema.query.types.OrderSpecifier;
import com.mysema.query.types.Predicate;
import com.mysema.query.types.expr.BooleanExpression;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.enums.ChangeOperation;
import com.silverlakesymmetri.cbs.commons.jpa.mapping.sdo.RegistryJpe;
import com.silverlakesymmetri.cbs.commons.jpa.mapping.sdo.util.JpeConstants;
import com.silverlakesymmetri.cbs.commons.jpa.service.CbsGenericDataService;
import com.silverlakesymmetri.cbs.commons.jpa.service.impl.BusinessDataObjectJpaQueryComponentImpl;
import com.silverlakesymmetri.cbs.commons.logging.CbsAppLogger;
import com.silverlakesymmetri.cbs.commons.logging.annotation.Logger;
import com.silverlakesymmetri.cbs.commons.svc.AbstractBusinessService;
import com.silverlakesymmetri.cbs.commons.svc.CbsFileUploadCapable;
import com.silverlakesymmetri.cbs.commons.svc.util.FileUploadUtilImpl;
import com.silverlakesymmetri.cbs.commons.svc.util.InMemoryQueryExecutor;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.MultiRvsTranType;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.TranDef;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.QTranDefJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.TranDefJpe;
import com.silverlakesymmetri.cbs.dep.svc.TranDefService;

@Service
@Transactional
public class TranDefServiceImpl extends AbstractBusinessService<TranDef, TranDefJpe, String>
		implements TranDefService, CbsFileUploadCapable<TranDef> {

	private static final String DEBITCREDIT = "DEBITCREDIT";
	private static final String NO = "N";
	private static final String YES = "Y";
	private static final String DEPOSIT_FILTER = "DEPOSIT";
	private static final String WITHDRAWAL_FILTER = "WITHDRAWAL";
	private static final String DEBIT_FILTER = "DEBIT";
	private static final String CREDIT_FILTER = "CREDIT";
	private static final String TD_FILTER = "TDPLACEMENT";
	private static final String RTL_ACCT_PYMNT_CREDIT = "RAPC"; //The transaction type to be used when crediting payments to the retail account
	private static final String CHEQUEBUY_FILTER = "CHEQUEBUY";
	private static final String CHEQUESELL_FILTER = "CHEQUESELL";
	private static final String CHEQUEBUYCOL_FILTER = "CHEQUEBUYCOL";
	private static final String BILLSPAYMENT_FILTER = "BILLSPAYMENT";
	private static final String TDPRETERM_FILTER = "TDPRETERM";

	private static final String META_CODE = "DEPOSITS_REGISTRY";
	private static final String META_TYPE = "REGISTRY";
	private static final String SYS_TFR_WDL = "tfrWdlTranType";
	private static final String SYS_TFR_DEP = "tfrDepTranType";

	@Logger
	CbsAppLogger logger;

	@SuppressWarnings("rawtypes")
	@Autowired
	private FileUploadUtilImpl fileUploadUtility;

	@Autowired
	CbsGenericDataService cbsGenericDataService;

	@Override
	protected EntityPath<TranDefJpe> getEntityPath() {
		return QTranDefJpe.tranDefJpe;
	}

	@Override
	protected String getIdFromDataObjectInstance(TranDef dataObject) {
		return dataObject.getTranType();
	}

	@Override
	public TranDef getByPk(String publicKey, TranDef reference) {
		return super.getByPk(publicKey, reference);
	}

	@Override
	public TranDef create(TranDef dataObject) {
		TranDef result = super.create(dataObject);

		return result;
	}

	@Override
	public TranDef preCreateValidation(TranDef dataObject) {
		if (dataObject == null) {
			return super.preCreateValidation(dataObject);
		}
		if (NO.equals(dataObject.getTaxable())) {
			dataObject.setTranTaxRec(null);
		}
		if (dataObject.getTranTaxRec() == null) {
			dataObject.setTaxable(NO);
		}
		if (NO.equals(dataObject.getMultiRvsTranTypeInd())) {
			dataObject.setMultiRvsTranTypeList(new ArrayList<MultiRvsTranType>());
		}
		if (dataObject.getMultiRvsTranTypeList() == null || dataObject.getMultiRvsTranTypeList().size() == 0) {
			dataObject.setMultiRvsTranTypeInd(NO);
		}
		if (dataObject.getMaxFutureDateDays() == null) {
			dataObject.setMaxFutureDateDays(0);
		}
		if (dataObject.getMaxBackDateDays() == null) {
			dataObject.setMaxBackDateDays(0);
		}
		if (dataObject.getFloatDays() == null) {
			dataObject.setFloatDays(0);
		}
		if (YES.equals(dataObject.getReversalTranFlag())) {
			dataObject.setReversalTranType(null);
		}
		if (dataObject.getOrfInd() == null) {
			dataObject.setOrfInd(NO);
		}
		if (dataObject.getOvdInd() == null) {
			dataObject.setOvdInd(NO);
		} else if (NO.equalsIgnoreCase(dataObject.getOvdInd())) {
			dataObject.setOrfInd(NO);
		}
		if (dataObject.getUpdItemCountAmt() == null) {
			dataObject.setUpdItemCountAmt(YES);
		}
		if (dataObject.getUpdOd() == null) {
			dataObject.setUpdOd(YES);
		}
		if (dataObject.getCheckRestraintInd() == null) {
			dataObject.setCheckRestraintInd(YES);
		}
		if (dataObject.getSortPriority() == null) {
			dataObject.setSortPriority(1);
		}
		if (YES.equalsIgnoreCase(dataObject.getMultiRvsTranTypeInd())) {
			dataObject.setReversalTranType(null);
		}
		if (dataObject.getCheckFundInd() == null) {
			dataObject.setCheckFundInd(YES);
		}
		if (dataObject.getActiveYn() == null) {
			dataObject.setActiveYn(false);
		}
		if (dataObject.getUsedYn() == null) {
			dataObject.setUsedYn(false);
		}
		return super.preCreateValidation(dataObject);
	}

	@Override
	public TranDef update(TranDef dataObject) {
		TranDef result = super.update(dataObject);
		return result;
	}

	@Override
	public List<TranDef> query(int offset, int resultLimit, String groupBy, String order,
			Map<String, Object> filters) {

		if (filters != null && filters.get("listType") != null) {

			List<TranDef> bdoList = new ArrayList<TranDef>();
			String listType = filters.remove("listType").toString();

			if (listType.equalsIgnoreCase("OVERDRAFT")) {
				String scType = null;
				String tranType = null;
				if (filters.get("scType") != null) {
					scType = filters.remove("scType").toString();
				}
				if (filters.get("tranType") != null) {
					tranType = filters.remove("tranType").toString();
				}
				Map<String, Object> params = new HashMap<String, Object>();
				StringBuilder sb = new StringBuilder();
				if (StringUtils.isEmpty(StringUtils.trim(scType))) {
					sb.append("SELECT t FROM TranDefJpe t WHERE t.ovdInd = 'Y' AND COALESCE(t.reversalTranFlag, 'N') = 'N'");
					sb.append(" AND COALESCE(t.orfInd, 'N') = 'N'");
					if (!StringUtils.isEmpty(StringUtils.trim(tranType))) {
						sb.append(" AND t.tranType = :tranType");
						params.put("tranType", tranType);
					}
				} else {
					sb.append("SELECT DISTINCT t FROM TranDefJpe t INNER JOIN ServTypeQryJpe s ON (s.scTranType = t.tranType)");
					sb.append(" AND s.scType = :scType");
					params.put("scType", scType);
				}
				List<TranDefJpe> jpeList = dataService.findWithQuery(sb.toString(), TranDefJpe.class, params, null);
				if (jpeList != null && jpeList.size() > 0) {
					for (TranDefJpe jpe : jpeList) {
						TranDef bdo = jaxbSdoHelper.wrap(jpe, TranDef.class);
						bdoList.add(bdo);
					}
					FindCriteria fc = jaxbSdoHelper.wrap(BusinessDataObjectJpaQueryComponentImpl
							.buildFindCriteria(offset, resultLimit, groupBy, order, null));
					InMemoryQueryExecutor<TranDef> inMemQry = new InMemoryQueryExecutor<>(bdoList);
					return inMemQry.executeFilter(fc);
				}
			}

			return bdoList;

		}

		boolean transferTransOnly = false;
		if (filters.get("transferTransOnly") != null) {
			transferTransOnly = Boolean.parseBoolean(filters.get("transferTransOnly").toString());
			filters.remove("transferTransOnly");
		}

		if (filters.get("tranTypeFilter") != null && filters.get("tranTypeFilter").toString().length() > 0) {
			String filterType = filters.get("tranTypeFilter").toString();
			filters.remove("tranTypeFilter");
			return customQuery(offset, resultLimit, groupBy, order, filters, filterType, transferTransOnly);
		}

		return super.query(offset, resultLimit, groupBy, order, filters);

	}

	@Override
	public boolean delete(TranDef dataObject) {
		boolean result = super.delete(dataObject);
		return result;
	}

	@Override
	public List<TranDef> find(FindCriteria findCriteria, CbsHeader cbsHeader) {
		return super.find(findCriteria, cbsHeader);
	}

	private List<TranDef> customQuery(int offset, int resultLimit, String groupBy, String order, Map<String, Object> filters, String filterType, boolean transferTransOnly) {
		final List<OrderSpecifier<?>> orders = getOrderSpecifier(QTranDefJpe.tranDefJpe, groupBy, order);
		Predicate predicate = convertMapToPredicate(filters, filterType, transferTransOnly);
		
		return super.query(QTranDefJpe.tranDefJpe, offset, resultLimit, predicate, orders);
	}

	private Predicate convertMapToPredicate(Map<String, Object> filters, String filterType, boolean transferTransOnly) {
		Predicate predicate = super.convertMapToPredicate(QTranDefJpe.tranDefJpe, filters);
		BooleanExpression booleanExpr = null;
		if (DEPOSIT_FILTER.equals(filterType)) {
			booleanExpr = QTranDefJpe.tranDefJpe.crDrMaintInd.equalsIgnoreCase("C");
			booleanExpr = booleanExpr.and(QTranDefJpe.tranDefJpe.ovdInd.notEqualsIgnoreCase("Y"));
			booleanExpr = booleanExpr.and(QTranDefJpe.tranDefJpe.sourceType.equalsIgnoreCase("MT"));
			booleanExpr = booleanExpr.and(QTranDefJpe.tranDefJpe.reversalTranFlag.equalsIgnoreCase("N").or(QTranDefJpe.tranDefJpe.reversalTranFlag.isNull()));
			booleanExpr = booleanExpr.and(QTranDefJpe.tranDefJpe.tranCode.notIn(Arrays.asList("3901","3903","3904","3905","3906","3911","3912","3913",
					"3914","3915","6010", "3143","3144","3121","3122","8101","8111","8121","8102","8122","8123","3104","4006","4007","8001","8002",
					"8003","8004","8005","8006","8007", "8117","8118","4020","3955","4018","8010","4023","4022","4008","3125","4019","3311","4016",
					"4015","4017","3951","3301","3322","3331")));
			//below is basically the same as above but this will change in the future where new conditions will be added
			BooleanExpression booleanExpr2 = QTranDefJpe.tranDefJpe.crDrMaintInd.equalsIgnoreCase("C");
			booleanExpr2 = booleanExpr2.and(QTranDefJpe.tranDefJpe.ovdInd.notEqualsIgnoreCase("Y"));
			booleanExpr2 = booleanExpr2.and(QTranDefJpe.tranDefJpe.sourceType.equalsIgnoreCase("MT"));
			booleanExpr2 = booleanExpr2.and(QTranDefJpe.tranDefJpe.tranCode.equalsIgnoreCase("4020"));
			booleanExpr2 = booleanExpr2.and(QTranDefJpe.tranDefJpe.reversalTranFlag.equalsIgnoreCase("N").or(QTranDefJpe.tranDefJpe.reversalTranFlag.isNull()));
			//booleanExpr2 = booleanExpr2.and(QTranDefJpe.tranDefJpe.sd.equalsIgnoreCase("N").or(QTranDefJpe.tranDefJpe.reversalTranFlag.isNull()));
			booleanExpr = booleanExpr.or(booleanExpr2);
		} else if (WITHDRAWAL_FILTER.equals(filterType)) {
			booleanExpr = QTranDefJpe.tranDefJpe.crDrMaintInd.equalsIgnoreCase("D");
			booleanExpr = booleanExpr.and(QTranDefJpe.tranDefJpe.ovdInd.notEqualsIgnoreCase("Y"));
			booleanExpr = booleanExpr.and(QTranDefJpe.tranDefJpe.sourceType.equalsIgnoreCase("MT"));
			booleanExpr = booleanExpr.and(QTranDefJpe.tranDefJpe.tranCode.notIn(Arrays.asList("3901","3903","3904","3905","3906","3911","3912","3913","3914",
					"3915","6010","3143","3144","3121","3122","8101","8111","8121","8102","8122","8123","4006","8001","8002","8003","8004","8005","8006",
					"8007","8118","8103","8117","3916","3951","4022","7121","3955","3301","3311","3322","3331","4015","4016","4017","4023")));
			booleanExpr = booleanExpr.and(QTranDefJpe.tranDefJpe.reversalTranFlag.equalsIgnoreCase("N").or(QTranDefJpe.tranDefJpe.reversalTranFlag.isNull()));
		} else if (DEBIT_FILTER.equals(filterType)) {
			booleanExpr = QTranDefJpe.tranDefJpe.tranCode.eq("3122");
			booleanExpr = booleanExpr.and(QTranDefJpe.tranDefJpe.crDrMaintInd.equalsIgnoreCase("D"));
			booleanExpr = booleanExpr.and(QTranDefJpe.tranDefJpe.ovdInd.notEqualsIgnoreCase("Y"));
			booleanExpr = booleanExpr.and(QTranDefJpe.tranDefJpe.sourceType.equalsIgnoreCase("MT"));
			booleanExpr = booleanExpr.and(QTranDefJpe.tranDefJpe.reversalTranFlag.equalsIgnoreCase("N").or(QTranDefJpe.tranDefJpe.reversalTranFlag.isNull()));
			booleanExpr = booleanExpr.and(QTranDefJpe.tranDefJpe.tranType.notIn(getSystemTranTypes()));
		} else if (CREDIT_FILTER.equals(filterType)) {
			booleanExpr = QTranDefJpe.tranDefJpe.tranCode.eq("3121");
			booleanExpr = booleanExpr.and(QTranDefJpe.tranDefJpe.crDrMaintInd.equalsIgnoreCase("C"));
			booleanExpr = booleanExpr.and(QTranDefJpe.tranDefJpe.sourceType.equalsIgnoreCase("MT"));
			booleanExpr = booleanExpr.and(QTranDefJpe.tranDefJpe.reversalTranFlag.equalsIgnoreCase("N").or(QTranDefJpe.tranDefJpe.reversalTranFlag.isNull()));
			booleanExpr = booleanExpr.and(QTranDefJpe.tranDefJpe.tranType.notIn(getSystemTranTypes()));
		} else if (DEBITCREDIT.equals(filterType)) {
			BooleanExpression debitBooleanExpr = QTranDefJpe.tranDefJpe.tranCode.eq("3122");
			debitBooleanExpr = debitBooleanExpr.and(QTranDefJpe.tranDefJpe.crDrMaintInd.equalsIgnoreCase("D"));
			debitBooleanExpr = debitBooleanExpr.and(QTranDefJpe.tranDefJpe.ovdInd.notEqualsIgnoreCase("Y"));
			debitBooleanExpr = debitBooleanExpr.and(QTranDefJpe.tranDefJpe.sourceType.equalsIgnoreCase("MT"));

			BooleanExpression creditBooleanExpr = QTranDefJpe.tranDefJpe.tranCode.eq("3121");
			creditBooleanExpr = creditBooleanExpr.and(QTranDefJpe.tranDefJpe.crDrMaintInd.equalsIgnoreCase("C"));
			creditBooleanExpr = creditBooleanExpr.and(QTranDefJpe.tranDefJpe.sourceType.equalsIgnoreCase("MT"));

			booleanExpr = debitBooleanExpr.or(creditBooleanExpr);
			booleanExpr = booleanExpr.and(QTranDefJpe.tranDefJpe.reversalTranFlag.equalsIgnoreCase("N").or(QTranDefJpe.tranDefJpe.reversalTranFlag.isNull()));
			booleanExpr = booleanExpr.and(QTranDefJpe.tranDefJpe.tranType.notIn(getSystemTranTypes()));
		} else if (TD_FILTER.equals(filterType)) {
			booleanExpr = QTranDefJpe.tranDefJpe.tranCode.eq("3121");
			booleanExpr = booleanExpr.and(QTranDefJpe.tranDefJpe.crDrMaintInd.equalsIgnoreCase("C"));
			booleanExpr = booleanExpr.and(QTranDefJpe.tranDefJpe.sourceType.equalsIgnoreCase("MT"));
			booleanExpr = booleanExpr.and(QTranDefJpe.tranDefJpe.reversalTranFlag.equalsIgnoreCase("N")
					.or(QTranDefJpe.tranDefJpe.reversalTranFlag.isNull()));
			if (!transferTransOnly) {
				BooleanExpression depositBooleanExpr = QTranDefJpe.tranDefJpe.tranCode.in(Arrays.asList("3101","3103","3111","4001","4005","4013"));
				depositBooleanExpr = depositBooleanExpr.and(QTranDefJpe.tranDefJpe.crDrMaintInd.equalsIgnoreCase("C"));
				depositBooleanExpr = depositBooleanExpr.and(QTranDefJpe.tranDefJpe.sourceType.equalsIgnoreCase("MT"));
				depositBooleanExpr = depositBooleanExpr.and(QTranDefJpe.tranDefJpe.reversalTranFlag.equalsIgnoreCase("N")
						.or(QTranDefJpe.tranDefJpe.reversalTranFlag.isNull()));
				booleanExpr = booleanExpr.or(depositBooleanExpr);
			}
			booleanExpr = booleanExpr.and(QTranDefJpe.tranDefJpe.tranType.notIn(getSystemTranTypes()));
		} else if (RTL_ACCT_PYMNT_CREDIT.equals(filterType)) {
			booleanExpr = QTranDefJpe.tranDefJpe.reversalTranFlag.equalsIgnoreCase("N").or(QTranDefJpe.tranDefJpe.reversalTranFlag.isNull());
			booleanExpr = booleanExpr.and(QTranDefJpe.tranDefJpe.tranCode.in(Arrays.asList("4003","4004","4015","4016","4017")));
			booleanExpr = booleanExpr.and(QTranDefJpe.tranDefJpe.activeYn.isTrue());
		} else if (CHEQUEBUY_FILTER.equals(filterType)) {			
			booleanExpr = QTranDefJpe.tranDefJpe.crDrMaintInd.equalsIgnoreCase("C");
			booleanExpr = booleanExpr.and(QTranDefJpe.tranDefJpe.tranCode.eq("8122"));
			booleanExpr = booleanExpr.and(QTranDefJpe.tranDefJpe.reversalTranFlag.equalsIgnoreCase("N"));
			booleanExpr = booleanExpr.and(QTranDefJpe.tranDefJpe.sourceType.equalsIgnoreCase("MT"));
			booleanExpr = booleanExpr.and(QTranDefJpe.tranDefJpe.cashTran.equalsIgnoreCase("N"));
		} else if (CHEQUEBUYCOL_FILTER.equals(filterType)) {
			booleanExpr = QTranDefJpe.tranDefJpe.tranCode.eq("8123");
			booleanExpr = booleanExpr.and(QTranDefJpe.tranDefJpe.reversalTranFlag.equalsIgnoreCase("N"));
			booleanExpr = booleanExpr.and(QTranDefJpe.tranDefJpe.sourceType.equalsIgnoreCase("MT"));
			booleanExpr = booleanExpr.and(QTranDefJpe.tranDefJpe.cashTran.equalsIgnoreCase("N"));
			booleanExpr = booleanExpr.and(QTranDefJpe.tranDefJpe.crDrMaintInd.equalsIgnoreCase("M"));
		} else if (CHEQUESELL_FILTER.equals(filterType)) {
			booleanExpr = QTranDefJpe.tranDefJpe.crDrMaintInd.equalsIgnoreCase("D");
			booleanExpr = booleanExpr.and(QTranDefJpe.tranDefJpe.tranCode.in(Arrays.asList("8121", "8111")));
			booleanExpr = booleanExpr.and(QTranDefJpe.tranDefJpe.reversalTranFlag.equalsIgnoreCase("N"));
			booleanExpr = booleanExpr.and(QTranDefJpe.tranDefJpe.sourceType.equalsIgnoreCase("MT"));
			booleanExpr = booleanExpr.and(QTranDefJpe.tranDefJpe.cashTran.equalsIgnoreCase("N"));
		} else if (BILLSPAYMENT_FILTER.equals(filterType)) {
			booleanExpr = QTranDefJpe.tranDefJpe.reversalTranFlag.equalsIgnoreCase("N");
			booleanExpr = booleanExpr.and(QTranDefJpe.tranDefJpe.tranCode.in(Arrays.asList("3301", "3311", "3322", "4015", "4016")));
			booleanExpr = booleanExpr.or(QTranDefJpe.tranDefJpe.tranCode.eq("4017").and(QTranDefJpe.tranDefJpe.crDrMaintInd.equalsIgnoreCase("D")));
			booleanExpr = booleanExpr.and(QTranDefJpe.tranDefJpe.activeYn.isTrue());
		} else if (TDPRETERM_FILTER.equals(filterType)) {
			booleanExpr = QTranDefJpe.tranDefJpe.tranCode.in(Arrays.asList("3102", "3122"));
			booleanExpr = booleanExpr.and(QTranDefJpe.tranDefJpe.crDrMaintInd.equalsIgnoreCase("D"));
			booleanExpr = booleanExpr.and(QTranDefJpe.tranDefJpe.activeYn.isTrue());
			booleanExpr = booleanExpr.and(QTranDefJpe.tranDefJpe.tranType.notIn(getSystemTranTypes()));
		}

		if (predicate != null) {
			predicate = ((BooleanExpression) predicate).and(booleanExpr);	
		} else {
			predicate = booleanExpr;
		}
		return predicate;
	}

	private List<String> getSystemTranTypes() {
		List<String> systemTranTypeList = new ArrayList<>();
		List<String> registryAttrStr = new ArrayList<String>();

		registryAttrStr.add(SYS_TFR_WDL);
		registryAttrStr.add(SYS_TFR_DEP);

		final Map<String, Object> registryNamedQueryParameters = new HashMap<String, Object>();
		registryNamedQueryParameters.put("metaCode", META_CODE);
		registryNamedQueryParameters.put("attributeCode", registryAttrStr);
		registryNamedQueryParameters.put("metaType", META_TYPE);

		List<RegistryJpe> registryList = cbsGenericDataService.findWithNamedQuery(JpeConstants.REGISTRY_JPE__FIND_ATTRIBUTE_CODE_LIST, registryNamedQueryParameters, RegistryJpe.class);

		for (RegistryJpe reg: registryList) {
			systemTranTypeList.add(reg.getValueS());
		}

		return systemTranTypeList;
	}

	/*
	@Override
	public List<com.silverlakesymmetri.cbs.dep.bdo.sdo.TranDef> queryDepositTranDef(int offset, int resultLimit,
			String groupBy, String order, Map<String, Object> filters) {
		return customQuery(offset, resultLimit, order, filters, DEPOSIT_FILTER);
	}

	@Override
	public List<com.silverlakesymmetri.cbs.dep.bdo.sdo.TranDef> queryWithdrawalTranDef(int offset, int resultLimit,
			String groupBy, String order, Map<String, Object> filters) {
		return customQuery(offset, resultLimit, order, filters, WITHDRAWAL_FILTER);
	}

	@Override
	public List<com.silverlakesymmetri.cbs.dep.bdo.sdo.TranDef> queryDebitTranDef(int offset, int resultLimit,
			String groupBy, String order, Map<String, Object> filters) {
		return customQuery(offset, resultLimit, order, filters, DEBIT_FILTER);
	}

	@Override
	public List<com.silverlakesymmetri.cbs.dep.bdo.sdo.TranDef> queryCreditTranDef(int offset, int resultLimit,
			String groupBy, String order, Map<String, Object> filters) {
		return customQuery(offset, resultLimit, order, filters, CREDIT_FILTER);
	}
	*/

	@Override
	public boolean bulkCreate(List<TranDef> bdoList) {
		validateBulkCreateList(bdoList);

		for (TranDef bdo : bdoList) {
			try {
				fileUploadUtility.validateConstraints(bdo, ChangeOperation.Create);
				this.create(bdo);
			} catch (Exception e) {
				logger.error("Error encountered while processing jpe: {}", jaxbSdoHelper.unwrap(bdo), e);
				throw e;
			}
		}

		return true;
	}

	@SuppressWarnings("unchecked")
	private void validateBulkCreateList(List<TranDef> bdoList) {
		isDuplicatesOnList(Arrays.asList("tranType"), bdoList);
		for (TranDef tranDef : bdoList) {
			if (tranDef.getMultiRvsTranTypeList() != null && tranDef.getMultiRvsTranTypeList().size() > 0) {
				List<String> uniqueChildKeyString = Arrays.asList("tranType", "reversalTranType");
				fileUploadUtility.isDuplicateOnChildLst(uniqueChildKeyString, tranDef.getMultiRvsTranTypeList(), MultiRvsTranType.class);
			}
		}
	}

	@SuppressWarnings("unchecked")
	@Override
	public boolean isDuplicatesOnList(List<String> uniqueKeys, List<TranDef> bdoList) {
		return fileUploadUtility.isDuplicatesOnList(uniqueKeys, bdoList);
	}

}
