package com.silverlakesymmetri.cbs.dep.svc.impl;

import com.mysema.query.types.EntityPath;
import com.silverlakesymmetri.cbs.commons.context.CbsSessionContext;
import com.silverlakesymmetri.cbs.commons.jpa.service.CbsEntityManagerAware;
import com.silverlakesymmetri.cbs.commons.svc.AbstractBusinessService;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.CashGlBalance;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.CashGlBalanceJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.QCashGlBalanceJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.util.DepJpeConstants;
import com.silverlakesymmetri.cbs.dep.svc.CashGlBalanceService;
import org.springframework.stereotype.Service;

import javax.persistence.Query;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

@Service
public class CashGlBalanceServiceImpl extends AbstractBusinessService<CashGlBalance, CashGlBalanceJpe, String>
        implements CashGlBalanceService {

    private static final String ORG_ID_KEY = "orgId";
    private static final String BRANCH_KEY = "branch";
    private static final String CCY_KEY = "ccy";

    @Override
    protected String getIdFromDataObjectInstance(CashGlBalance dataObject) {
        return null;
    }

    @Override
    protected EntityPath<CashGlBalanceJpe> getEntityPath() {
        return QCashGlBalanceJpe.cashGlBalanceJpe;
    }

    @Override
    @SuppressWarnings("unchecked")
    public List<CashGlBalance> query(int offset, int resultLimit, String groupBy, String order, Map<String, Object> filters) {
        filters.keySet().removeIf(key -> !Arrays.asList(BRANCH_KEY, CCY_KEY).contains(key));
        Long orgId = cbsRuntimeContextManager.getContext(CbsSessionContext.class).getOrgId();
        filters.put(ORG_ID_KEY, orgId);
        
        String nativeQry = DepJpeConstants.GET_CASH_GL_BALANCE_QUERY;
        
        if (filters.containsKey(BRANCH_KEY)) {
            nativeQry += " AND BRANCH = ?branch ";
        }
        if (filters.containsKey(CCY_KEY)) {
            nativeQry += " AND CCY = ?ccy ";
        }

        Query query = ((CbsEntityManagerAware) dataService).getMyEntityManager().createNativeQuery(nativeQry, DepJpeConstants.GET_CASH_GL_BALANCE);
        filters.forEach(query::setParameter);
        return query.getResultList();
    }
}
