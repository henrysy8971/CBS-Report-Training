package com.silverlakesymmetri.cbs.dep.svc;

import java.util.List;
import java.util.Map;

import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation;
import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation.ServiceOperationType;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.svc.BusinessService;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.InwdType;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.InwdTypeJpe;

public interface InwdTypeService extends BusinessService<InwdType, InwdTypeJpe> {

	public static final String SVC_OP_NAME_INWDTYPESERVICE_GET = "InwdTypeService.get";
	public static final String SVC_OP_NAME_INWDTYPESERVICE_QUERY = "InwdTypeService.query";
	public static final String SVC_OP_NAME_INWDTYPESERVICE_FIND = "InwdTypeService.find";
	public static final String SVC_OP_NAME_INWDTYPESERVICE_CREATE = "InwdTypeService.create";
	public static final String SVC_OP_NAME_INWDTYPESERVICE_UPDATE = "InwdTypeService.update";
	public static final String SVC_OP_NAME_INWDTYPESERVICE_DELETE = "InwdTypeService.delete";

	@ServiceOperation(name = SVC_OP_NAME_INWDTYPESERVICE_GET, type = ServiceOperationType.GET)
	public InwdType getByPk(String publicKey, InwdType reference);

	@ServiceOperation(name = SVC_OP_NAME_INWDTYPESERVICE_QUERY)
	public List<InwdType> query(int offset, int resultLimit, String groupBy, String order, Map<String, Object> filters);

	@ServiceOperation(name = SVC_OP_NAME_INWDTYPESERVICE_FIND)
	public List<InwdType> find(FindCriteria findCriteria, CbsHeader cbsHeader);

	@ServiceOperation(name = SVC_OP_NAME_INWDTYPESERVICE_CREATE)
	public InwdType create(InwdType dataObject);

	@ServiceOperation(name = SVC_OP_NAME_INWDTYPESERVICE_UPDATE)
	public InwdType update(InwdType dataObject);

	@ServiceOperation(name = SVC_OP_NAME_INWDTYPESERVICE_DELETE)
	public boolean delete(InwdType dataObject);

}
