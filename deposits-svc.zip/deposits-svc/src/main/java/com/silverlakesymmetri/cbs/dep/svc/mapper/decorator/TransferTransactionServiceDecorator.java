package com.silverlakesymmetri.cbs.dep.svc.mapper.decorator;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.mapstruct.Context;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

import com.silverlakesymmetri.cbs.commons.jpa.service.CbsGenericDataService;
import com.silverlakesymmetri.cbs.commons.jpa.util.DateTimeHelper;
import com.silverlakesymmetri.cbs.commons.xmlapi.enums.CbsXmlApiOperation;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.AcctJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.DepFeeApplyJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.TransferTransactionDetailJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.TransferTransactionJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.util.DepJpeConstants;
import com.silverlakesymmetri.cbs.dep.svc.mapper.TransferTransactionServiceMapper;
import com.silverlakesymmetri.cbs.dep.svc.mapper.mapping.DEPFEEAPPLYDTLOUTTTypeToScDetailOutMapper;
import com.silverlakesymmetri.cbs.dep.svc.mapper.mapping.DepFeeApplyToDEPFEEAPPLYINTypeMapper;
import com.silverlakesymmetri.cbs.dep.svc.mapper.mapping.DepTranOtherDataToDEPTRANOTHERDATATTypeMapper;
import com.silverlakesymmetri.cbs.dep.svc.mapper.mapping.ScDetailInToDEPFEEAPPLYDTLINTTypeMapper;
import com.silverlakesymmetri.cbs.dep.svc.mapper.mapping.TranValidationFlagsToDEPTRANVALIDATIONFLAGSTTypeMapper;
import com.silverlakesymmetri.cbs.dep.xmlapi.DEPFEEAPPLYDTLINCOLLType;
import com.silverlakesymmetri.cbs.dep.xmlapi.DEPFEEAPPLYINType;
import com.silverlakesymmetri.cbs.dep.xmlapi.DEPTRANOTHERDATACOLLType;
import com.silverlakesymmetri.cbs.dep.xmlapi.DEPTRANSFERINSAPIType;

public abstract class TransferTransactionServiceDecorator implements TransferTransactionServiceMapper{

	@Autowired
	@Qualifier("delegate")
	protected  TransferTransactionServiceMapper delegate;
	
	@Autowired
	protected DepFeeApplyToDEPFEEAPPLYINTypeMapper feeApplyMapper;

	@Autowired
	protected ScDetailInToDEPFEEAPPLYDTLINTTypeMapper scDetailInMapper;

	@Autowired
	protected DepTranOtherDataToDEPTRANOTHERDATATTypeMapper depTranOtherDataMapper;

	@Autowired
	protected TranValidationFlagsToDEPTRANVALIDATIONFLAGSTTypeMapper tranValidationFlagsMapper;

	@Autowired
	protected DEPFEEAPPLYDTLOUTTTypeToScDetailOutMapper scDetailOutMapper;
	
	@Autowired(required = true)
    @Qualifier("cbsGenericDataService")
    protected CbsGenericDataService dataService;
	
	@Autowired
    protected DateTimeHelper dateTimeHelper;
	
	@Override
	public DEPTRANSFERINSAPIType mapToApi(TransferTransactionJpe jpe, @Context CbsXmlApiOperation oper){
		
		DEPTRANSFERINSAPIType req = delegate.mapToApi(jpe, oper);
				
		if (jpe.getTfrDetailList().size() > 0) {
			//We only expect 1 Transfer Transaction Details
			TransferTransactionDetailJpe dtlBdo = jpe.getTfrDetailList().get(0);
			req.setDRSCAPPLYIN(mapFeeToApi(dtlBdo.getDrFeeApplyList()));
			req.setCRSCAPPLYIN(mapFeeToApi(dtlBdo.getCrFeeApplyList()));
			
			String transferMode = jpe.getTransferMode();
			
			mapAcctNoToApi(dtlBdo, req, transferMode);
						
			if (dtlBdo.isRemCcy() && "CR".equals(transferMode)) {
				req.setTRANCCY(dtlBdo.getCpartyAcctCcy());
			} else {
				req.setTRANCCY(getAcctCcy(jpe));
			}
			
			req.setTRANAMT(dtlBdo.getAmount());
			req.setSOURCEREFTYPE("MT");
			req.setSOURCEMODULE("DEP");
			if (dtlBdo.getEffectDate() != null) {
				req.setEFFECTDATE(dateTimeHelper.convertToCbsXmlApiDate(dtlBdo.getEffectDate()));
			}
			
			//req.setEXCHRATETYPE(null); // xratetype is handled in DEP_TRANSFER_INS_API body line: 323 - 328
			req.setORIGRATE(dtlBdo.getOrigCrossRate());
			req.setORIGAMT(dtlBdo.getAmount());
			req.setCROSSRATEREFNO(dtlBdo.getRateReferenceId());
			req.setCROSSRATE(dtlBdo.getCrossRate());
			req.setDRTRANDESC(dtlBdo.getDrNarrative());
			req.setCRTRANDESC(dtlBdo.getCrNarrative());
			req.setAUTOGENFEEDR("N");
			req.setAUTOGENFEECR("N");
			req.setTRANBRANCH(dtlBdo.getBranch());
			if (dtlBdo.getCrSeqNo() != null) {
				req.setCRTRANSEQNO(dtlBdo.getCrSeqNo().doubleValue());
			}
		}
				
		return  req;
	}
		
	private DEPFEEAPPLYINType mapFeeToApi(List<DepFeeApplyJpe> jpe) {
		DEPFEEAPPLYINType feeApplyIn = null;
		for (DepFeeApplyJpe depFeeApply : jpe) {
			if (feeApplyIn == null) {
				feeApplyIn = feeApplyMapper.mapDepFeeApplyToDEPFEEAPPLYIN(depFeeApply);
				feeApplyIn.setSCDETAILIN(new DEPFEEAPPLYDTLINCOLLType());
				feeApplyIn.setRBTRANOTHERDATAIN(new DEPTRANOTHERDATACOLLType());
			}
			feeApplyIn.getSCDETAILIN().getDEPFEEAPPLYDTLINT()
					.add(scDetailInMapper.mapScDetailInToDEPFEEAPPLYDTLIN(depFeeApply.getScDetailIn()));
			feeApplyIn.getRBTRANOTHERDATAIN().getDEPTRANOTHERDATAT().add(depTranOtherDataMapper
					.mapTranValidationFlagsToDEPTRANVALIDATIONFLAGST(depFeeApply.getRbTranOtherData()));
			feeApplyIn.setTRANVALIDATIONFLAGS(tranValidationFlagsMapper
					.mapTranValidationFlagsToDEPTRANVALIDATIONFLAGST(depFeeApply.getTranValidationFlags()));
		}			
		return feeApplyIn;
	}
	
	private DEPTRANSFERINSAPIType mapAcctNoToApi(TransferTransactionDetailJpe jpe, DEPTRANSFERINSAPIType req, String transferMode){
		if ("DR".equals(transferMode)) {
			// withdraw from
			req.setDRACCTNO(jpe.getAcctNo());
			// deposit to 
			req.setCRACCTNO(jpe.getCpartyAcctNo());
		} else if ("CR".equals(transferMode)) {
			//withdraw from 
			req.setDRACCTNO(jpe.getCpartyAcctNo());
			// deposit to 
			req.setCRACCTNO(jpe.getAcctNo());
		}
		return req;
	}
	
	private String getAcctCcy(TransferTransactionJpe jpe) {
		Map<String, Object> param = new HashMap<String, Object>();
		param.put("acctNo", jpe.getAcctNo());
		AcctJpe acctJpe = dataService.getWithNamedQuery(DepJpeConstants.ACCT_JPE_FIND_BY_ACCTNO, param, AcctJpe.class);
		return acctJpe.getCcy();
	}
	
}
