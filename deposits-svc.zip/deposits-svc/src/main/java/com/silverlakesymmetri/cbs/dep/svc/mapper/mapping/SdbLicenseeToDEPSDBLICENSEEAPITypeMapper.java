package com.silverlakesymmetri.cbs.dep.svc.mapper.mapping;

import org.mapstruct.MapperConfig;
import org.mapstruct.Mapping;
import org.mapstruct.Mappings;

import com.silverlakesymmetri.cbs.commons.jpa.util.DateTimeHelper;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.SdbLicenseeJpe;
import com.silverlakesymmetri.cbs.dep.xmlapi.DEPSDBLICENSEEAPIType;

@MapperConfig(uses={ DateTimeHelper.class})
public interface SdbLicenseeToDEPSDBLICENSEEAPITypeMapper {
	
	@Mappings({
		@Mapping(target="SDBINTERNALKEY",    	source="sdbInternalKey"), 
		@Mapping(target="CLIENTNO",				source="clientId"), 
		@Mapping(target="CLIENTNAME",			source="clientName"), 
		@Mapping(target="TOCONTACT",			source="toContact"), 
		@Mapping(target="CONTACTREFNO",			source="contactRefNo"), 
		@Mapping(target="MAINLICENSEEIND",		source="mainLicenseeInd"), 
		@Mapping(target="OLDCLIENTNO",  		source="oldClientId"), 
		@Mapping(target="BRANCH",  				source="branch"), 
		@Mapping(target="BOXNO",				source="boxNo"), 
	 })
	public DEPSDBLICENSEEAPIType mapSdbLicenseeJpeToDEPSDBLICENSEEAPIType(SdbLicenseeJpe  jpe);	
	

}



