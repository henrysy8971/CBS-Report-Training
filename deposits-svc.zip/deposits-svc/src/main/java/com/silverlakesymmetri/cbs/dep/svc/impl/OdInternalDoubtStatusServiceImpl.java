package com.silverlakesymmetri.cbs.dep.svc.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.mysema.query.types.EntityPath;
import com.silverlakesymmetri.cbs.commons.svc.AbstractBusinessService;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.OdInternalDoubtStatus;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.OdInternalDoubtStatusJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.QOdInternalDoubtStatusJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.id.OdInternalDoubtStatusPk;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.util.DepJpeConstants;
import com.silverlakesymmetri.cbs.dep.svc.OdInternalDoubtStatusService;

@Service
@Transactional
public class OdInternalDoubtStatusServiceImpl
		extends AbstractBusinessService<OdInternalDoubtStatus, OdInternalDoubtStatusJpe, OdInternalDoubtStatusPk>
		implements OdInternalDoubtStatusService {

	@Override
	protected EntityPath<OdInternalDoubtStatusJpe> getEntityPath() {
		return QOdInternalDoubtStatusJpe.odInternalDoubtStatusJpe;
	}

	@Override
	protected OdInternalDoubtStatusPk getIdFromDataObjectInstance(OdInternalDoubtStatus dataObject) {
		Map<String, Object> params = new HashMap<String, Object>();
		params.put("acctNo", dataObject.getAcctNo());
		List<Long> list = dataService.findWithNamedQuery(DepJpeConstants.ACCT_JPE_FIND_INTERNAL_KEY_BY_ACCT_NO, params,
				Long.class);
		if (list != null && list.size() > 0) {
			return new OdInternalDoubtStatusPk(list.get(0));
		}
		return null;
	}

	@Override
	public OdInternalDoubtStatus getByPk(String publicKey, OdInternalDoubtStatus reference) {
		return super.getByPk(publicKey, reference);
	}

	@Override
	public OdInternalDoubtStatus update(OdInternalDoubtStatus dataObject) {
		dataObject.setCurrentIntDoubtStatus(dataObject.getNewIntDoubtStatus());
		return super.update(dataObject);
	}

}
