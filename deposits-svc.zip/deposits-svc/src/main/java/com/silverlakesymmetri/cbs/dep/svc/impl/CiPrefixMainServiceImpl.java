package com.silverlakesymmetri.cbs.dep.svc.impl;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.mysema.query.types.EntityPath;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.svc.AbstractBusinessService;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.CiPrefix;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.CiPrefixJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.QCiPrefixJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.id.CiPrefixPk;
import com.silverlakesymmetri.cbs.dep.svc.CiPrefixMainService;

@Service
@Transactional
public class CiPrefixMainServiceImpl extends AbstractBusinessService<CiPrefix, CiPrefixJpe, CiPrefixPk> implements CiPrefixMainService {

	@Override
	protected EntityPath<CiPrefixJpe> getEntityPath() {
		return QCiPrefixJpe.ciPrefixJpe;
	}

	@Override
	protected CiPrefixPk getIdFromDataObjectInstance(CiPrefix dataObject) {
		return new CiPrefixPk(dataObject.getChequeType(), dataObject.getDenom(), dataObject.getPrefix());
	}

	@Override
	public CiPrefix getByPk(String publicKey, CiPrefix reference) {
		return super.getByPk(publicKey, reference);
	}

	@Override
	public CiPrefix create(CiPrefix dataObject) {
		return super.create(dataObject);
	}
	
	@Override
	public List<CiPrefix> query(int offset, int resultLimit, String groupBy, String order, Map<String, Object> filters) {
		return super.query(offset, resultLimit, groupBy, order, filters);
	}

	@Override
	public CiPrefix update(CiPrefix dataObject) {
		return super.update(dataObject);
	}
	
	@Override
	public boolean delete(CiPrefix dataObject) {
		return super.delete(dataObject);
	}

	@Override
	public List<CiPrefix> find(FindCriteria findCriteria, CbsHeader cbsHeader) {
		return super.find(findCriteria, cbsHeader);
	}

}
