package com.silverlakesymmetri.cbs.dep.svc;

import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation;
import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation.ServiceOperationType;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.svc.BusinessService;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.CasaProdIntRateQry;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.CasaProdIntRateQryJpe;

import java.util.List;
import java.util.Map;


public interface CasaProdIntRateQryService extends BusinessService<CasaProdIntRateQry, CasaProdIntRateQryJpe> {

    public static final String SVC_OP_NAME_CASAPRODINTRATE_GET = "CasaProdIntRateQryService.get";
    public static final String SVC_OP_NAME_CASAPRODINTRATE_CREATE = "CasaProdIntRateQryService.create";
    public static final String SVC_OP_NAME_CASAPRODINTRATE_UPDATE = "CasaProdIntRateQryService.update";
    public static final String SVC_OP_NAME_CASAPRODINTRATE_DELETE = "CasaProdIntRateQryService.delete";
    public static final String SVC_OP_NAME_CASAPRODINTRATE_QUERY = "CasaProdIntRateQryService.query";
    public static final String SVC_OP_NAME_CASAPRODINTRATE_FIND = "CasaProdIntRateQryService.find";

    @ServiceOperation(name = SVC_OP_NAME_CASAPRODINTRATE_GET, type = ServiceOperationType.GET)
    public CasaProdIntRateQry getByPk(String publicKey, CasaProdIntRateQry reference);
    
    @ServiceOperation(name = SVC_OP_NAME_CASAPRODINTRATE_CREATE)
    public CasaProdIntRateQry create(CasaProdIntRateQry objectInstanceIdentifier);
    
    @ServiceOperation(name = SVC_OP_NAME_CASAPRODINTRATE_UPDATE)
    public CasaProdIntRateQry update(CasaProdIntRateQry objectInstanceIdentifier);
    
    @ServiceOperation(name = SVC_OP_NAME_CASAPRODINTRATE_DELETE)
    public boolean delete(CasaProdIntRateQry objectInstanceIdentifier);
    
    @ServiceOperation(name = SVC_OP_NAME_CASAPRODINTRATE_QUERY)
    public List<CasaProdIntRateQry> query(int offset, int resultLimit, String groupBy, String order, Map<String, Object> filters);

    @ServiceOperation(name = SVC_OP_NAME_CASAPRODINTRATE_FIND)
    public List<CasaProdIntRateQry> find(FindCriteria findCriteria, CbsHeader cbsHeader);


}
