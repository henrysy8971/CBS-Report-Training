package com.silverlakesymmetri.cbs.dep.svc.mapper;

import java.util.Map;

import org.mapstruct.Context;
import org.mapstruct.DecoratedWith;
import org.mapstruct.InheritConfiguration;
import org.mapstruct.InheritInverseConfiguration;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingTarget;
import org.mapstruct.Mappings;

import com.silverlakesymmetri.cbs.commons.jpa.util.DateTimeHelper;
import com.silverlakesymmetri.cbs.commons.xmlapi.enums.CbsXmlApiOperation;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.OdFacilityMainJpe;
import com.silverlakesymmetri.cbs.dep.svc.mapper.decorator.OdFacilityMainServiceDecorator;
import com.silverlakesymmetri.cbs.dep.svc.mapper.mapping.OdFacilityMainToDEPODFACILITYAPITypeMapper;
import com.silverlakesymmetri.cbs.dep.xmlapi.DEPODFACILITYAPIType;

@Mapper(config = OdFacilityMainToDEPODFACILITYAPITypeMapper.class, uses = { DateTimeHelper.class })
@DecoratedWith(OdFacilityMainServiceDecorator.class)
public interface OdFacilityMainServiceMapper {

	@Mappings({
		@Mapping(expression = "java(oper != null ? oper.getOperation() : null)", target = "OPERATION")
	})

	@SuppressWarnings("rawtypes")
	@InheritConfiguration
	public DEPODFACILITYAPIType mapToApi(OdFacilityMainJpe jpe, @Context CbsXmlApiOperation oper, @Context Map otherInfo);

	@Mappings({
		@Mapping(source = "MATURITYDATE", target = "maturityDate", qualifiedByName = { "DateTimeHelper", "convertCbsApiDateToString" }),
		@Mapping(source = "EFFECTFROMDATE", target = "odEffectFromDate", qualifiedByName = { "DateTimeHelper", "convertCbsApiDateToString" }),
		@Mapping(source = "EFFECTTODATE", target = "odEffectToDate", qualifiedByName = { "DateTimeHelper", "convertCbsApiDateToString" }),
		@Mapping(source = "ODNEXTREVIEWDATE", target = "odNextReviewDate", qualifiedByName = { "DateTimeHelper", "convertCbsApiDateToString" }),
		@Mapping(source = "NEXTREPRICINGDATE", target = "nextRepricingDate", qualifiedByName = { "DateTimeHelper", "convertCbsApiDateToString" })
	})
	@InheritInverseConfiguration(name = "mapOdFacilityMainToDEPODFACILITYAPIType")
	public OdFacilityMainJpe mapToJpe(DEPODFACILITYAPIType api, @MappingTarget OdFacilityMainJpe jpe);

}
