package com.silverlakesymmetri.cbs.dep.svc.impl;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.mysema.query.types.EntityPath;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.jpa.util.DateTimeHelper;
import com.silverlakesymmetri.cbs.commons.jpa.util.JaxbDatetimeAdapter;
import com.silverlakesymmetri.cbs.commons.svc.AbstractBusinessService;
import com.silverlakesymmetri.cbs.commons.svc.ref.ReferenceNumberGeneratorService;
import com.silverlakesymmetri.cbs.csd.bdo.sdo.IntType;
import com.silverlakesymmetri.cbs.csd.jpa.mapping.sdo.IntTypeJpe;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.IntMatrixDtlExpected;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.IntMatrixExpected;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.IntMatrixDtlExpectedJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.IntMatrixExpectedJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.QIntMatrixExpectedJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.id.IntMatrixExpectedPk;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.util.DepJpeConstants;
import com.silverlakesymmetri.cbs.dep.svc.IntMatrixExpectedService;

@Service
@Transactional
public class IntMatrixExpectedServiceImpl extends AbstractBusinessService<IntMatrixExpected, IntMatrixExpectedJpe, IntMatrixExpectedPk>
		implements IntMatrixExpectedService {

	@Autowired
	private DateTimeHelper dateTimeHelper;

	@Autowired
    private ReferenceNumberGeneratorService referenceNumberGeneratorService;

	@Override
	protected EntityPath<IntMatrixExpectedJpe> getEntityPath() {
		return QIntMatrixExpectedJpe.intMatrixExpectedJpe;
	}

	@Override
	protected IntMatrixExpectedPk getIdFromDataObjectInstance(IntMatrixExpected dataObject) {
		return new IntMatrixExpectedPk(dataObject.getIntType(), dataObject.getCcy(),
				JaxbDatetimeAdapter.parseDate(dataObject.getEffectDate()));
	}

	@Override
	public IntMatrixExpected getByPk(String publicKey, IntMatrixExpected reference) {
		return super.getByPk(publicKey, reference);
	}

	@Override
	public IntMatrixExpected create(IntMatrixExpected dataObject) {
		IntMatrixExpected postProcessedDataObject = super.create(dataObject);
		// will be handled by batch
		// this.checkForExpiredRates(postProcessedDataObject);
		return postProcessedDataObject;
		//return super.create(dataObject);
	}

	@Override
	public IntMatrixExpected update(IntMatrixExpected dataObject) {
		return super.update(dataObject);
	}

	@Override
	public List<IntMatrixExpected> query(int offset, int resultLimit, String groupBy, String order,
			Map<String, Object> filters) {
		return super.query(offset, resultLimit, groupBy, order, filters);
	}

	@Override
	public boolean delete(IntMatrixExpected dataObject) {
		return super.delete(dataObject);
	}

	@Override
	public List<IntMatrixExpected> find(FindCriteria findCriteria, CbsHeader cbsHeader) {
		return super.find(findCriteria, cbsHeader);
	}

	@Override
	public IntMatrixExpected getHistoryByPk(String intType, String ccy) {
		IntMatrixExpectedJpe jpeInstance = new IntMatrixExpectedJpe();
		jpeInstance.setIntType(intType);
		jpeInstance.setCcy(ccy);

		Map<String, Object> filter = new HashMap<>();
		filter.put("intType", intType);
		filter.put("ccy", ccy);

		List<IntMatrixDtlExpectedJpe> intMatrixDtlExpectedJpeList = dataService
				.findWithNamedQuery(DepJpeConstants.INT_MATRIX_DTL_EXPECTED_FIND_EXPIRED_ENTRIES, filter, IntMatrixDtlExpectedJpe.class);
		jpeInstance.setIntMatrixDtlExpectedList(intMatrixDtlExpectedJpeList);

		IntMatrixExpected reference = jaxbSdoHelper.wrap(jpeInstance, IntMatrixExpected.class);
		return reference;
	}

	@Override
	public List<IntType> findCrIntForTdAcct(Map<String, Object> queryParams) {

		Date runDate = dateTimeHelper.getRunDate();
		String intType = (String) queryParams.get("intType");
		String intTypeDesc = (String) queryParams.get("intTypeDesc");
		String ccy = (String) queryParams.get("ccy");
		String asOfDate = (String) queryParams.get("asOfDate");
		if (asOfDate != null) {
			if (dateTimeHelper.getDate(asOfDate) != null) {
				runDate = dateTimeHelper.getDate(asOfDate);
			}
		}
		String groupBy = (String) queryParams.get("groupBy") == null ? "intType" : (String) queryParams.get("groupBy");
		String order = (String) queryParams.get("order") == null ? "ASC" : (String) queryParams.get("order");
		int limit = queryParams.get("limit") != null ? Integer.parseInt((String) queryParams.get("limit")) : 10;
		int offset = queryParams.get("offset") != null ? Integer.parseInt((String) queryParams.get("offset")) : 0;

		String query = DepJpeConstants.FIND_EXPECTED_CR_INT_TYPE_FOR_TD_ACCT_QUERY;
		List<IntType> result = new ArrayList<IntType>();

		final Map<String, Object> parameters = new HashMap<>();
		parameters.put("runDate", runDate);
		parameters.put("ccy", ccy);

		if (!StringUtils.isBlank(intType)) {
			query = query + " AND UPPER(a.intType) like :intType";
			parameters.put("intType", "%" + intType.trim().toUpperCase() + "%");
		}

		if (!StringUtils.isBlank(intTypeDesc)) {
			query = query + " AND UPPER(a.intTypeDesc) like :intTypeDesc";
			parameters.put("intTypeDesc", "%" + intTypeDesc.trim().toUpperCase() + "%");
		}

		query = query + String.format(" ORDER BY a.%s %s", groupBy, order);

		List<IntTypeJpe> jpeList = dataService.findWithQuery(query, parameters, offset, limit, IntTypeJpe.class);

		if (jpeList != null && !jpeList.isEmpty()) {
			for (IntTypeJpe jpe : jpeList) {
				result.add(jaxbSdoHelper.wrap(jpe, IntType.class));
			}
		}

		return result;
	}

	@Override
	public IntMatrixExpected getbyinttypeccyeffdt(String intType, String ccy, Date asOfDate) {
		Map<String,Object> param = new HashMap<>();
		param.put("intType", intType);
		param.put("ccy", ccy);
		param.put("asOfDate", asOfDate);
		List<IntMatrixExpectedJpe> jpelist = dataService.findWithNamedQuery(DepJpeConstants.INT_MATRIX_EXPECTED_JPE_BY_INT_TYPE_CCY_AND_AS_OF_DATE, param, IntMatrixExpectedJpe.class);
		if (jpelist != null && jpelist.size() > 0) {
			IntMatrixExpected bdo = jaxbSdoHelper.wrap(jpelist.get(0), IntMatrixExpected.class);
			return bdo;
		}
		return null;
	}

	@Override
	public IntMatrixExpected preCreateValidation(IntMatrixExpected dataObject) {
		if (dataObject != null) {
			if (dataObject.getHistoryYn() == null) {
				dataObject.setHistoryYn(false);
			}
			for (IntMatrixDtlExpected dtl : dataObject.getIntMatrixDtlExpectedList()) {
				if (StringUtils.isBlank(dtl.getIntMatrixDtlRefNo())) {
					referenceNumberGeneratorService.getNewRefNo(dtl, "intMatrixDtlRefNo");
				}
			}
		}
		return super.preCreateValidation(dataObject);
	}

}
