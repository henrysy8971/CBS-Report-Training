package com.silverlakesymmetri.cbs.dep.svc.impl;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.mysema.query.types.EntityPath;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.jpa.util.JpaEntityChangeTracker;
import com.silverlakesymmetri.cbs.commons.svc.AbstractBusinessService;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.OverdraftType;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.OverdraftTypeJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.QOverdraftTypeJpe;
import com.silverlakesymmetri.cbs.dep.svc.OverdraftTypeService;
import commonj.sdo.ChangeSummary;

@Service
@Transactional
public class OverdraftTypeServiceImpl extends AbstractBusinessService<OverdraftType, OverdraftTypeJpe, String> implements OverdraftTypeService {

    private JpaEntityChangeTracker _bizDataChanges;
    
	@Override
	protected EntityPath<OverdraftTypeJpe> getEntityPath() {
		return QOverdraftTypeJpe.overdraftTypeJpe;
	}

	@Override
	protected String getIdFromDataObjectInstance(OverdraftType dataObject) {
		return dataObject.getOdType();
	}

	@Override
	public OverdraftType getByPk(String publicKey, OverdraftType reference) {
		return super.getByPk(publicKey, reference);
	}

	@Override
	public OverdraftType create(OverdraftType dataObject) {
		return super.create(dataObject);
	}
	
	@Override
	protected OverdraftType preCreateValidation(OverdraftType dataObject) {
	    performMainDefaulting(dataObject);
		return super.preCreateValidation(dataObject);
	}
    private void performMainDefaulting(OverdraftType dataObject) {
        if (null != dataObject) {

            OverdraftTypeJpe overdraftTypeJpe = jaxbSdoHelper.unwrap(dataObject);
            _bizDataChanges = dataService.getJpaEntityChangeTracker(overdraftTypeJpe);
            
            boolean isNew = _bizDataChanges.isCreated() || _bizDataChanges.isNew();
            
            if (isNew) {
                if (dataObject.getUsedYn()==null) {
                    dataObject.setUsedYn(true);
                }

            }
            if (dataObject.getDfltDrIntFreq()==null || dataObject.getDfltDrIntFreq().isEmpty()) {
                dataObject.setDfltDrIntFreq("N");
            }
            
            if (dataObject.getDfltOdIntType()==null || dataObject.getDfltOdIntType().isEmpty()) {
                dataObject.setDfltOdIntType("N");
            }
            
            if (dataObject.getCollatRequired()==null || dataObject.getCollatRequired().isEmpty()) {
                dataObject.setCollatRequired("N");
            }
            
            if (dataObject.getRepricingInd()==null || dataObject.getRepricingInd().isEmpty()) {
                dataObject.setRepricingInd("N");
            }
            
            if (dataObject.getMarkAsDue()==null || dataObject.getMarkAsDue().isEmpty()) {
                dataObject.setMarkAsDue("N");
            }
            
            if (dataObject.getMarkDueExpiry()==null || dataObject.getMarkDueExpiry().isEmpty()) {
                dataObject.setMarkDueExpiry("N");
            }

            if (dataObject.getMarkDueTermination()==null || dataObject.getMarkDueTermination().isEmpty()) {
                dataObject.setMarkDueTermination("N");
            }
            
            if (dataObject.getGenRepayAcct()==null || dataObject.getGenRepayAcct().isEmpty()) {
                dataObject.setGenRepayAcct("N");
            }
            
            if (dataObject.getIntCalcBasisExpired()==null || dataObject.getIntCalcBasisExpired().isEmpty()) {
                dataObject.setIntCalcBasisExpired("B");
            }
            
            if (dataObject.getSelfHunting()==null || dataObject.getSelfHunting().isEmpty()) {
                dataObject.setSelfHunting("N");
            }            

            if (dataObject.getSdRestraintInd()==null || dataObject.getSdRestraintInd().isEmpty()) {
                dataObject.setSdRestraintInd("N");
            }     

            if (dataObject.getUseLpayfeeEvent()==null || dataObject.getUseLpayfeeEvent().isEmpty()) {
                dataObject.setUseLpayfeeEvent("N");
            } 
            
            if ("N".equals(dataObject.getDfltDrIntFreq())) {
                if (dataObject.getDfltOdIntType()!=null) {
                   dataObject.setDfltOdIntType(null); 
                }
            }
            if (dataObject.getFeePriority()!=null && dataObject.getFeePriority().compareTo(0)==0) {
                if (dataObject.getUseLpayfeeEvent()!=null) {
                    if ("Y".equals(dataObject.getUseLpayfeeEvent())){
                        dataObject.setUseLpayfeeEvent("N");
                    }
                }
                if (dataObject.getScRateTypeLatePaymt()!=null) {
                    dataObject.setScRateTypeLatePaymt(null); 
                }
                if (dataObject.getScTypeLatePaymt()!=null) {
                    dataObject.setScTypeLatePaymt(null); 
                }
            }
            
            if (dataObject.getMarkAsDue()!=null && !dataObject.getMarkAsDue().isEmpty() && "N".equals(dataObject.getMarkAsDue()) && "4".equals(dataObject.getOdClass())) {
                if (dataObject.getInterestPriority()==null || dataObject.getInsurancePriority()==null || dataObject.getFeePriority()==null || dataObject.getPrincipalPriority()==null) {
                    dataObject.setInterestPriority(1);
                    dataObject.setFeePriority(2);
                    dataObject.setInsurancePriority(3);
                    dataObject.setPrincipalPriority(4);                    
                }
            }else{
                if (dataObject.getInterestPriority()==null || dataObject.getFeePriority()==null || dataObject.getInsurancePriority()==null || dataObject.getPrincipalPriority()==null) {
                    dataObject.setInterestPriority(0);
                    dataObject.setFeePriority(0);
                    dataObject.setInsurancePriority(0);
                    dataObject.setPrincipalPriority(0);
                    
                }
            }
        }
    }
	@Override
	public OverdraftType update(OverdraftType dataObject) {
		return super.update(dataObject);
	}

	@Override
	public List<OverdraftType> query(int offset, int resultLimit, String groupBy, String order,
			Map<String, Object> filters) {
			return super.query(offset, resultLimit, groupBy, order, filters);	
	}

	
	@Override
	public boolean delete(OverdraftType dataObject) {
		return super.delete(dataObject);
	}

	@Override
	public List<OverdraftType> find(FindCriteria findCriteria, CbsHeader cbsHeader) {
		return super.find(findCriteria, cbsHeader);
	}

}
