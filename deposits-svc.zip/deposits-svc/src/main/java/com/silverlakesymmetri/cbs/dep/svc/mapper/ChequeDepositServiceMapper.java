package com.silverlakesymmetri.cbs.dep.svc.mapper;

import java.util.Map;

import org.mapstruct.Context;
import org.mapstruct.DecoratedWith;
import org.mapstruct.InheritConfiguration;
import org.mapstruct.InheritInverseConfiguration;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingTarget;
import org.mapstruct.Mappings;

import com.silverlakesymmetri.cbs.commons.jpa.util.DateTimeHelper;
import com.silverlakesymmetri.cbs.commons.xmlapi.enums.CbsXmlApiOperation;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.DepositTransactionJpe;
import com.silverlakesymmetri.cbs.dep.svc.mapper.decorator.ChequeDepositServiceDecorator;
import com.silverlakesymmetri.cbs.dep.svc.mapper.mapping.DepositTransactionToDEPTRANHISTINSAPITypeMapper;
import com.silverlakesymmetri.cbs.dep.xmlapi.DEPTRANHISTINSAPIType;

@Mapper(config=DepositTransactionToDEPTRANHISTINSAPITypeMapper.class, uses={ DateTimeHelper.class})
@DecoratedWith(ChequeDepositServiceDecorator.class)
public interface ChequeDepositServiceMapper{
	
	public  static final String BRANCH = "BRANCH";
	public  static final String CHANNEL_SOURCE = "CHANNEL_SOURCE";
	
	@Mappings({
		 @Mapping(expression = "java(oper != null ? oper.getOperation() : null)", target="OPERATION")
	 })
	@InheritConfiguration
	public DEPTRANHISTINSAPIType mapToApi(DepositTransactionJpe jpe, @Context CbsXmlApiOperation oper, @Context Map otherInfo);
	
	@InheritInverseConfiguration(name = "mapDepositTransactionToDEPTRANHISTINSAPIType")
	@Mapping(target = "effectDate", source="EFFECTDATE", qualifiedByName = {"DateTimeHelper","convertCbsApiDateToString"})
	public DepositTransactionJpe mapToJpe(DEPTRANHISTINSAPIType api, @MappingTarget DepositTransactionJpe jpe);
	
}
