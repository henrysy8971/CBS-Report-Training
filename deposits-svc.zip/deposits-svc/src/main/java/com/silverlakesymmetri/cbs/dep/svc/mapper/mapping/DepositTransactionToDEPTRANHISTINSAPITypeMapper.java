package com.silverlakesymmetri.cbs.dep.svc.mapper.mapping;

import org.mapstruct.MapperConfig;
import org.mapstruct.Mapping;
import org.mapstruct.Mappings;

import com.silverlakesymmetri.cbs.commons.jpa.util.DateTimeHelper;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.DepositTransactionJpe;
import com.silverlakesymmetri.cbs.dep.xmlapi.DEPTRANHISTINSAPIType;

@MapperConfig(uses={ DateTimeHelper.class})
public interface DepositTransactionToDEPTRANHISTINSAPITypeMapper {
	
	@Mappings({

		@Mapping(source = "seqNo", target="TXNSEQNO"),
		@Mapping(source = "acctNo", target="ACCOUNTNO"),
		@Mapping(source = "tranType", target="TRANTYPE"),
		@Mapping(source = "effectDate", target="EFFECTDATE", qualifiedByName = {"DateTimeHelper","convertDateToCbsXmlApiDate"}),
		@Mapping(source = "ccy", target="TRANCCY"),
		@Mapping(source = "amount", target="TRANAMT"),
		@Mapping(source = "equivAmount", target="NETAMOUNT"),
		@Mapping(source = "branch", target="BRANCH"),
		@Mapping(source = "narrative", target="TRANDESC"),

		@Mapping(source = "ignoreRestraint", target = "IGNRESTRAINT", defaultValue = "N"),
		@Mapping(source = "ignoreAvailbal", target = "IGNAVAILBAL", defaultValue = "N"),
		@Mapping(source = "checkOverride", target = "CHKOVERRIDE", defaultValue = "N"),
		@Mapping(source = "checkTellerLimit", target = "CHKTELLERLIMIT", defaultValue = "Y"),
		@Mapping(source = "checkEffdate", target = "CHKEFFDATE", defaultValue = "Y"),
		@Mapping(target = "AUTOGENFEE" , constant = "N"),
		@Mapping(target = "SOURCEMODULE" , constant = "DEP"),
		
		@Mapping(source = "rateOrigin", target="CROSSRATEORIGIN"),
		@Mapping(source = "crossRate", target="CROSSRATE"),
		@Mapping(source = "origCrossRate", target="ORIGRATE"),
//		@Mapping(source = "xRateType", target="EXCHRATETYPE"),
		@Mapping(source = "rateReferenceId", target="CROSSRATEREFNO"),
				
		@Mapping(source = "othGlCode", target="OTHGLCODE"),
		@Mapping(source = "sourceRefType", target="SOURCEREFTYPE"),
		@Mapping(source = "sourceRefNo", target="SOURCEREFNO"),
				
		@Mapping(source = "refBank", target="REFERENCEBANK"),
		@Mapping(source = "refBranch", target="REFERENCEBRANCH"),
		@Mapping(source = "issuerAcctNo", target="ISSUERACCTNO"),
		@Mapping(source = "reference", target="REFERENCE"),
		@Mapping(source = "floatDays", target="FLOATDAYS"),
		@Mapping(source = "clientName", target="CLIENTNAME"),
		@Mapping(source = "clientAddress", target="CLIENTADDR"),
		@Mapping(source = "idType", target="IDTYPE"),
		@Mapping(source = "idNumber", target="CLIENTID"),
		@Mapping(source = "residentFlag", target="RESIDENT"),
		@Mapping(source = "clientType", target="CLIENTTYPE"),
		@Mapping(source = "categoryType", target="CATEGORYTYPE"),
		@Mapping(source = "country", target="COUNTRY"),
		@Mapping(source = "domesticForeignFlag", target="DOMESTICFOREIGN"),
		@Mapping(source = "placeOfIssuance", target="PLACEOFISSUANCE"),
		@Mapping(source = "availableBal", target="AVAILBAL"),
		@Mapping(source = "ledgerBal", target="LEDGERBAL")
	 })
	//TODO: to be refactored should use the jpe class not the bdo
	public DEPTRANHISTINSAPIType mapDepositTransactionToDEPTRANHISTINSAPIType(DepositTransactionJpe jpe);
		
}




