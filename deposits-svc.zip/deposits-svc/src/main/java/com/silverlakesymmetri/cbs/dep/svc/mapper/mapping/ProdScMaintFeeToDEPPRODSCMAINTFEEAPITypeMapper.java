package com.silverlakesymmetri.cbs.dep.svc.mapper.mapping;

import org.mapstruct.MapperConfig;
import org.mapstruct.Mapping;
import org.mapstruct.Mappings;

import com.silverlakesymmetri.cbs.commons.jpa.util.DateTimeHelper;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.ProdScMaintFeeJpe;
import com.silverlakesymmetri.cbs.dep.xmlapi.DEPPRODSCMAINTFEEAPIType;

@MapperConfig(uses={ DateTimeHelper.class})
public interface ProdScMaintFeeToDEPPRODSCMAINTFEEAPITypeMapper {

	@Mappings({
//		@Mapping(target="PRODKEY",       			source="prodKey"), 
		@Mapping(target="MODULEID",     	source="moduleId"), 
		@Mapping(target="SUBTYPE",       	source="subType"), 
		@Mapping(target="SCTYPE",       	source="scType"), 
		@Mapping(target="SCRATETYPE",       source="scRateType"), 
		@Mapping(target="SCPERIODFREQ",     source="scPeriodFreq"), 
		@Mapping(target="SCNEXTDATE",       source="scNextDate", qualifiedByName = {"DateTimeHelper","convertDateToCbsXmlApiDate"}), 
		@Mapping(target="SCLASTDATE",       source="scLastDate", qualifiedByName = {"DateTimeHelper","convertDateToCbsXmlApiDate"}), 
		@Mapping(target="SCDAY",   			source="scDay"), 

	 })
	public DEPPRODSCMAINTFEEAPIType mapProdScMaintFeeToDEPPRODSCMAINTFEEAPIType(ProdScMaintFeeJpe jpe);
	
	public ProdScMaintFeeJpe mapDEPPRODSCMAINTFEEAPITypeToProdScMaintFee(DEPPRODSCMAINTFEEAPIType  api);	
}
