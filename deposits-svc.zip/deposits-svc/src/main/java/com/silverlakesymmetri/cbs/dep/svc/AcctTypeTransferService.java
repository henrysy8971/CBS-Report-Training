package com.silverlakesymmetri.cbs.dep.svc;

import java.util.List;
import java.util.Map;

import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation;
import com.silverlakesymmetri.cbs.commons.svc.BusinessService;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.AcctTypeChange;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.AcctTypeChangeJpe;

/**
 * Created by Emerson.Sanchez on 7/5/2019.
 */
public interface AcctTypeTransferService extends BusinessService<AcctTypeChange, AcctTypeChangeJpe> {
    public static final String SVC_OP_NAME_ACCTTYPETRANSFERSERVICE_GET = "AcctTypeTransferService.get";
    public static final String SVC_OP_NAME_ACCTTYPETRANSFERSERVICE_QUERY = "AcctTypeTransferService.query";
    public static final String SVC_OP_NAME_ACCTTYPETRANSFERSERVICE_CREATE = "AcctTypeTransferService.create";
    public static final String SVC_OP_NAME_ACCTTYPETRANSFERSERVICE_UPDATE = "AcctTypeTransferService.update";

    @ServiceOperation(name = SVC_OP_NAME_ACCTTYPETRANSFERSERVICE_GET, type = ServiceOperation.ServiceOperationType.GET)
    public AcctTypeChange getByPk(String publicKey, AcctTypeChange reference);
    
    @ServiceOperation(name = SVC_OP_NAME_ACCTTYPETRANSFERSERVICE_QUERY)
    public List<AcctTypeChange> query(int offset, int resultLimit, String groupBy, String order,
                                        Map<String, Object> filters);

    @ServiceOperation(name = SVC_OP_NAME_ACCTTYPETRANSFERSERVICE_UPDATE)
    public AcctTypeChange update(AcctTypeChange dataObject);

    @ServiceOperation(name = SVC_OP_NAME_ACCTTYPETRANSFERSERVICE_CREATE)
    public AcctTypeChange create(AcctTypeChange dataObject);

}
