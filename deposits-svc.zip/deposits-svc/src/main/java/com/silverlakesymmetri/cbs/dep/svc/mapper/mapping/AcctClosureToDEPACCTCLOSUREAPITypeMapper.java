package com.silverlakesymmetri.cbs.dep.svc.mapper.mapping;

import org.mapstruct.MapperConfig;
import org.mapstruct.Mapping;
import org.mapstruct.Mappings;

import com.silverlakesymmetri.cbs.commons.jpa.util.DateTimeHelper;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.AcctClosureJpe;
import com.silverlakesymmetri.cbs.dep.xmlapi.DEPACCTCLOSUREAPIType;

@MapperConfig(uses={ DateTimeHelper.class})
public interface AcctClosureToDEPACCTCLOSUREAPITypeMapper {
	
  
	
	@Mappings({ 
//		@Mapping(target="HOSTCHECKFLAG", constant = "N"), 
		@Mapping(source = "acctNo", target="ACCTNO"),
		@Mapping(source = "internalKey", target="INTERNALKEY"),
//		@Mapping(source = "availBalance", target="ACTUALBAL"),
//		@Mapping(source = "projCrIntAccrued", target="PROJCRINTACCR"),
//		@Mapping(source = "lastCrIntAccruedDate", target="CRLASTACCRDATE", qualifiedByName = {"DateTimeHelper","convertDateToCbsXmlApiDate"}),
//		@Mapping(source = "lastCrIntAccrued", target="CRINTLASTACCR"),
//		@Mapping(source = "crIntAccrued", target="CRINTACCR"),
//		@Mapping(source = "crIntAccruedAdj", target="CRINTADJ"),
//		@Mapping(source = "WTax", target="WITHHOLDINGTAX"),
//		@Mapping(source = "wtTaxForAdj", target="WITHHOLDINGTAXFORADJ"),
//		@Mapping(source = "drIntAccrued", target="DRINTACCR"),
//		@Mapping(source = "drIntAccruedAdj", target="DRINTADJ"),
//		@Mapping(source = "batchFee", target="BATCHFEES"),
//		@Mapping(source = "acctClosureFee", target="ACCTCLOSEFEE"),
//		@Mapping(source = "uncollFee", target="UNCOLLECTEDSC"),
//		@Mapping(source = "closingBal", target="CLOSINGBALANCE"),
//		@Mapping(target="AUTOGENFEE", constant = "N"),
		@Mapping(source = "acctClosureReasonDesc", target="ACCTCLOSEREASON"),
		@Mapping(source = "acctClosureOfficer", target="OFFICERID"),
//		@Mapping(target="CLOSURESCAPPLIED", constant = "Y"),
//		@Mapping(source = "acctOpenDate", target="ACCTOPENDATE", qualifiedByName = {"DateTimeHelper","convertDateToCbsXmlApiDate"})
//		@Mapping(source = "crIntPymtOption", target="CRPAYMENTOPTION"),
//		    "uncollFeeChargeInd",
		
	 })
	public DEPACCTCLOSUREAPIType mapAcctClosureToDEPACCTCLOSUREAPIType(AcctClosureJpe api);	
	
}

