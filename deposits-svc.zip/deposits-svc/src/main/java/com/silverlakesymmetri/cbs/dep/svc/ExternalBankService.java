package com.silverlakesymmetri.cbs.dep.svc;

import java.util.List;
import java.util.Map;

import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation;
import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation.ServiceOperationType;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.svc.BusinessService;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.ExternalBank;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.ExternalBankJpe;

public interface ExternalBankService extends BusinessService<ExternalBank, ExternalBankJpe> {
	
	public static final String SVC_OP_NAME_EXTERNALBANK_GET = "ExternalBankService.get";
    public static final String SVC_OP_NAME_EXTERNALBANK_QUERY = "ExternalBankService.query";
    public static final String SVC_OP_NAME_EXTERNALBANK_CREATE = "ExternalBankService.create";
    public static final String SVC_OP_NAME_EXTERNALBANK_UPDATE = "ExternalBankService.update";
    public static final String SVC_OP_NAME_EXTERNALBANK_DELETE = "ExternalBankService.delete";
    public static final String SVC_OP_NAME_EXTERNALBANK_FIND = "ExternalBankService.find";
    
    @ServiceOperation(name = SVC_OP_NAME_EXTERNALBANK_GET, type = ServiceOperationType.GET)
    public ExternalBank getByPk(String publicKey, ExternalBank reference);
    
    @ServiceOperation(name = SVC_OP_NAME_EXTERNALBANK_CREATE)
    public ExternalBank create(ExternalBank dataObject);

    @ServiceOperation(name = SVC_OP_NAME_EXTERNALBANK_UPDATE)
    public ExternalBank update(ExternalBank dataObject);

    @ServiceOperation(name = SVC_OP_NAME_EXTERNALBANK_QUERY)
    public List<ExternalBank> query(int offset, int resultLimit, String groupBy, String order, Map<String, Object> filters);

    @ServiceOperation(name = SVC_OP_NAME_EXTERNALBANK_DELETE)
    public boolean delete(ExternalBank dataObject);

    @ServiceOperation(name = SVC_OP_NAME_EXTERNALBANK_FIND)
    public List<ExternalBank> find(FindCriteria findCriteria, CbsHeader cbsHeader);

}
