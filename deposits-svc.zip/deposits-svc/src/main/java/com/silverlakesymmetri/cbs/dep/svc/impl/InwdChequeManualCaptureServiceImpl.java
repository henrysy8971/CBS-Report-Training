package com.silverlakesymmetri.cbs.dep.svc.impl;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mysema.query.types.EntityPath;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.svc.AbstractXmlApiBusinessService;
import com.silverlakesymmetri.cbs.commons.svc.BusinessObjectValidationCapable;
import com.silverlakesymmetri.cbs.commons.xmlapi.enums.CbsXmlApiOperation;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.InwdChequeManualCapture;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.InwdChequeManualCaptureJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.QInwdChequeManualCaptureJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.id.InwdChequeManualCapturePk;
import com.silverlakesymmetri.cbs.dep.svc.InwdChequeManualCaptureService;
import com.silverlakesymmetri.cbs.dep.svc.mapper.InwdChequeManualCaptureServiceMapper;
import com.silverlakesymmetri.cbs.dep.xmlapi.DEPINWDCHEQUEAPIType;

@Service
public class InwdChequeManualCaptureServiceImpl extends
		AbstractXmlApiBusinessService<InwdChequeManualCapture, InwdChequeManualCaptureJpe, InwdChequeManualCapturePk, DEPINWDCHEQUEAPIType, DEPINWDCHEQUEAPIType>
		implements InwdChequeManualCaptureService, BusinessObjectValidationCapable<InwdChequeManualCapture> {

	@Autowired
	InwdChequeManualCaptureServiceMapper mapper;

	@Override
	protected EntityPath<InwdChequeManualCaptureJpe> getEntityPath() {
		return QInwdChequeManualCaptureJpe.inwdChequeManualCaptureJpe;
	}

	@Override
	protected InwdChequeManualCapturePk getIdFromDataObjectInstance(InwdChequeManualCapture dataObject) {
		return new InwdChequeManualCapturePk(dataObject.getSeqNo());
	}

	@Override
	public InwdChequeManualCapture getByPk(String publicKey, InwdChequeManualCapture reference) {
		InwdChequeManualCapture bdo = super.getByPk(publicKey, reference);
		if (bdo != null) {
			bdo.setErrorDesc(getErrDesc(bdo.getErrorNo()));
		}
		return bdo;
	}

	@Override
	public List<InwdChequeManualCapture> query(int offset, int resultLimit, String groupBy, String order,
			Map<String, Object> filters) {
		List<InwdChequeManualCapture> list = super.query(offset, resultLimit, groupBy, order, filters);
		if (list != null) {
			for (InwdChequeManualCapture bdo : list) {
				bdo.setErrorDesc(getErrDesc(bdo.getErrorNo()));
			}
		}
		return list;
	}

	@Override
	public List<InwdChequeManualCapture> find(FindCriteria findCriteria, CbsHeader cbsHeader) {
		List<InwdChequeManualCapture> list = super.find(findCriteria, cbsHeader);
		if (list != null) {
			for (InwdChequeManualCapture bdo : list) {
				bdo.setErrorDesc(getErrDesc(bdo.getErrorNo()));
			}
		}
		return list;
	}

	@Override
	public InwdChequeManualCapture create(InwdChequeManualCapture dataObject) {
		InwdChequeManualCapture bdo = super.create(dataObject);
		if (bdo != null) {
			bdo.setErrorDesc(getErrDesc(bdo.getErrorNo()));
		}
		return bdo;
	}

	@Override
	public InwdChequeManualCapture update(InwdChequeManualCapture dataObject) {
		InwdChequeManualCapture bdo = super.update(dataObject);
		if (bdo != null) {
			bdo.setErrorDesc(getErrDesc(bdo.getErrorNo()));
		}
		return bdo;
	}

	@Override
	public boolean delete(InwdChequeManualCapture dataObject) {
		return super.delete(dataObject);
	}

	@Override
	protected Class<DEPINWDCHEQUEAPIType> getXmlApiResponseClass() {
		return DEPINWDCHEQUEAPIType.class;
	}

	@Override
	protected List<InwdChequeManualCapture> processXmlApiListRs(InwdChequeManualCapture dataObject,
			DEPINWDCHEQUEAPIType xmlApiRs) {
		return null;
	}

	@Override
	protected InwdChequeManualCapture processXmlApiRs(InwdChequeManualCapture dataObject,
			DEPINWDCHEQUEAPIType xmlApiRs) {
		InwdChequeManualCaptureJpe jpe = jaxbSdoHelper.unwrap(dataObject);
		InwdChequeManualCapture bdo = jaxbSdoHelper.wrap(mapper.mapToJpe(xmlApiRs, jpe));
		if (bdo != null) {
			bdo.setErrorDesc(getErrDesc(bdo.getErrorNo()));
		}
		return bdo;
	}

	@Override
	protected InwdChequeManualCapture preCreateValidation(InwdChequeManualCapture dataObject) {
		InwdChequeManualCaptureJpe jpe = jaxbSdoHelper.unwrap(dataObject, InwdChequeManualCaptureJpe.class);
		if (jpe.getSeqNo() == null || jpe.getSeqNo() == 0) {
			long seqNo = dataService.nextSequenceValue("DEP_INWD_CHEQUE_S").longValue();
			jpe.setSeqNo(seqNo);
			return super.preCreateValidation(jaxbSdoHelper.wrap(jpe, InwdChequeManualCapture.class));
		}
		return super.preCreateValidation(dataObject);
	}

	@Override
	protected DEPINWDCHEQUEAPIType transformBdoToXmlApiRqCreate(InwdChequeManualCapture dataObject) {
		return transformInwdChequeManualCaptureToDEPINWDCHEQUEAPIType(dataObject, CbsXmlApiOperation.INSERT);
	}

	@Override
	protected DEPINWDCHEQUEAPIType transformBdoToXmlApiRqUpdate(InwdChequeManualCapture dataObject) {
		return transformInwdChequeManualCaptureToDEPINWDCHEQUEAPIType(dataObject, CbsXmlApiOperation.UPDATE);
	}

	@Override
	protected DEPINWDCHEQUEAPIType transformBdoToXmlApiRqDelete(InwdChequeManualCapture dataObject) {
		return transformInwdChequeManualCaptureToDEPINWDCHEQUEAPIType(dataObject, CbsXmlApiOperation.DELETE);
	}

	private DEPINWDCHEQUEAPIType transformInwdChequeManualCaptureToDEPINWDCHEQUEAPIType(
			InwdChequeManualCapture dataObject, CbsXmlApiOperation oper) {
		InwdChequeManualCaptureJpe jpe = jaxbSdoHelper.unwrap(dataObject);
		if (jpe.getTranDate() == null) {
			jpe.setTranDate(dateTimeHelper.getRunDate());
		}
		DEPINWDCHEQUEAPIType api = mapper.mapToApi(jpe, oper);
		super.setTechColsFromDataObject(dataObject, api);
		return api;
	}

}
