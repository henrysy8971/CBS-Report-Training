package com.silverlakesymmetri.cbs.dep.svc.impl;

import com.google.common.collect.ImmutableMap;
import com.mysema.query.types.EntityPath;
import com.silverlakesymmetri.cbs.commons.svc.AbstractBusinessService;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.AcctClosureExternal;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.OnlineIntCap;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.OnlineScCollection;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.AcctClosureExternalJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.QAcctClosureExternalJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.util.DepJpeConstants;
import com.silverlakesymmetri.cbs.dep.svc.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class AcctClosureExternalServiceImpl extends AbstractBusinessService<AcctClosureExternal, AcctClosureExternalJpe, String>
		implements AcctClosureExternalService {

	private static final String TRAN_TYPE_KEY = "tranType";
	private static final String C_CR_DR_MAINT_IND = "C";
	private static final String TRANSFER_MODE_CREDIT = "CR";
	private static final String TRANSFER_MODE_DEBIT = "DR";

	@Autowired
	private CashDepositService cashDepositService;
	@Autowired
	private CashWithdrawalService cashWithdrawalService;
	@Autowired
	private TransferTransactionService transferTransactionService;
	@Autowired
	private AcctClosureService acctClosureService;
	@Autowired
	private OnlineIntCapService onlineIntCapService;
	@Autowired
	private OnlineScCollectionService onlineScCollectionService;

	@Override
	protected EntityPath<AcctClosureExternalJpe> getEntityPath() {
		return QAcctClosureExternalJpe.acctClosureExternalJpe;
	}

	@Override
	protected String getIdFromDataObjectInstance(AcctClosureExternal dataObject) {
		return dataObject.getAcctNo();
	}

	@Override
	public AcctClosureExternal create(AcctClosureExternal dataObject) {
		boolean transactionSuccess = false;

		// credit
		if (dataObject.getDepositTransaction() != null) {
			if (isTranTypeCredit(dataObject.getDepositTransaction().getTranType())) {
				dataObject.setDepositTransaction(cashDepositService.postTransaction(dataObject.getDepositTransaction()));
			}
			transactionSuccess = true;
		} else if (dataObject.getTransferTransaction() != null) {
			if (TRANSFER_MODE_CREDIT.equals(dataObject.getTransferTransaction().getTransferMode())
					&& dataObject.getAcctNo().equals(dataObject.getTransferTransaction().getAcctNo())) {
				dataObject.setTransferTransaction(transferTransactionService.create(dataObject.getTransferTransaction()));
			}
			transactionSuccess = true;
		} else {
			transactionSuccess = true;
		}

		if (transactionSuccess) {
			if (dataObject.getAcctClosure() != null && dataObject.getAcctClosure().getAcctCloseOnlineIntCapRec() != null &&
					dataObject.getAcctClosure().getAcctCloseOnlineIntCapRec().getIntPaymentOption() != null) {
				OnlineIntCap onlineIntCap = jaxbSdoHelper.createSdoInstance(OnlineIntCap.class);
				onlineIntCap.setAcctNo(dataObject.getAcctNo());
				onlineIntCap.setPaymentOption(dataObject.getAcctClosure().getAcctCloseOnlineIntCapRec().getIntPaymentOption());
				onlineIntCapService.create(onlineIntCap);
				transactionSuccess = true;
			}
		}

		if (transactionSuccess) {
			OnlineScCollection onlineScCollection = jaxbSdoHelper.createSdoInstance(OnlineScCollection.class);
			onlineScCollection.setAcctNo(dataObject.getAcctNo());
			onlineScCollection.setPostScBatchSumYn(true);
			onlineScCollection.setPostScUncollYn(true);
			onlineScCollectionService.create(onlineScCollection);
			transactionSuccess = true;
		}

		// debit
		if (dataObject.getDepositTransaction() != null) {
			if (!isTranTypeCredit(dataObject.getDepositTransaction().getTranType())) {
				dataObject.setDepositTransaction(cashWithdrawalService.postTransaction(dataObject.getDepositTransaction()));
			}
			transactionSuccess = true;
		} else if (dataObject.getTransferTransaction() != null) {
			if (TRANSFER_MODE_DEBIT.equals(dataObject.getTransferTransaction().getTransferMode())
					&& dataObject.getAcctNo().equals(dataObject.getTransferTransaction().getAcctNo())) {
				dataObject.setTransferTransaction(transferTransactionService.create(dataObject.getTransferTransaction()));
			}
			transactionSuccess = true;
		} else {
			transactionSuccess = true;
		}

		if (transactionSuccess) {
			dataObject.setAcctClosure(acctClosureService.closeAccount(dataObject.getAcctClosure()));
		}

		return dataObject;
	}

	private boolean isTranTypeCredit(String tranType) {
		String crDrMaintInt = dataService.getWithNamedQuery(DepJpeConstants.TRAN_DEF_JPE_FIND_CR_DR_MAINT_INT_BY_TRAN_TYPE,
				ImmutableMap.of(TRAN_TYPE_KEY, tranType), String.class);

		return crDrMaintInt.equals(C_CR_DR_MAINT_IND);
	}
}
