package com.silverlakesymmetri.cbs.dep.svc.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.mysema.query.types.EntityPath;
import com.silverlakesymmetri.cbs.commons.svc.AbstractXmlApiBusinessService;
import com.silverlakesymmetri.cbs.commons.xmlapi.enums.CbsXmlApiOperation;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.AcctRestraint;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.SdbBranchTransfer;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.AcctRestraintJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.QSdbBranchTransferJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.SdbBranchTransferJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.id.SdbBranchTransferPk;
import com.silverlakesymmetri.cbs.dep.svc.SdbBranchTransferService;
import com.silverlakesymmetri.cbs.dep.svc.mapper.SdbBranchTransferServiceMapper;
import com.silverlakesymmetri.cbs.dep.xmlapi.DEPRESTRAINTSAPIType;
import com.silverlakesymmetri.cbs.dep.xmlapi.DEPSDBTRANSFERAPIType;

@Service
@Transactional
public class SdbBranchTransferServiceImpl extends AbstractXmlApiBusinessService<SdbBranchTransfer, SdbBranchTransferJpe, SdbBranchTransferPk, DEPSDBTRANSFERAPIType, DEPSDBTRANSFERAPIType> 
implements SdbBranchTransferService {
	
	@Autowired
	SdbBranchTransferServiceMapper mapper;
	
	@Override
	protected Class<DEPSDBTRANSFERAPIType> getXmlApiResponseClass() {
		return DEPSDBTRANSFERAPIType.class;
	}

	@Override
	protected SdbBranchTransferPk getIdFromDataObjectInstance(SdbBranchTransfer dataObject) {
		return new SdbBranchTransferPk(dataObject.getOldLockerNo(), dataObject.getOldBranch());
	}

	@Override
	protected EntityPath<SdbBranchTransferJpe> getEntityPath() {
		return QSdbBranchTransferJpe.sdbBranchTransferJpe;
	}
	
	@Override
	public SdbBranchTransfer getByPk(String publicKey, SdbBranchTransfer reference) {
		return super.getByPk(publicKey, reference);
	}	

	@Override
	protected DEPSDBTRANSFERAPIType transformBdoToXmlApiRqCreate(SdbBranchTransfer dataObject) {
		return null;
	}

	@Override
	protected DEPSDBTRANSFERAPIType transformBdoToXmlApiRqUpdate(SdbBranchTransfer dataObject) {
		return transformSdbBranchTransferToDEPSDBTRANSFERAPIType(dataObject, CbsXmlApiOperation.UPDATE);
	}

	@Override
	protected DEPSDBTRANSFERAPIType transformBdoToXmlApiRqDelete(SdbBranchTransfer dataObject) {
		return null;
	}
	
	private DEPSDBTRANSFERAPIType transformSdbBranchTransferToDEPSDBTRANSFERAPIType(SdbBranchTransfer dataObject, CbsXmlApiOperation oper){
		SdbBranchTransferJpe jpe = jaxbSdoHelper.unwrap(dataObject);
		DEPSDBTRANSFERAPIType apiType = mapper.mapToApi(jpe, oper);
		
		super.setTechColsFromDataObject(dataObject, apiType);
		
		return apiType;
	}

	@Override
	protected SdbBranchTransfer processXmlApiRs(SdbBranchTransfer dataObject, DEPSDBTRANSFERAPIType xmlApiRs) {
		SdbBranchTransferJpe jpe = jaxbSdoHelper.unwrap(dataObject);
		mapper.mapToJpe(xmlApiRs, jpe);
		return jaxbSdoHelper.wrap(jpe);
	}

	@Override
	protected List<SdbBranchTransfer> processXmlApiListRs(SdbBranchTransfer dataObject,
			DEPSDBTRANSFERAPIType xmlApiRs) {
		return null;
	}
	
}
