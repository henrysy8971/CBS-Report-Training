package com.silverlakesymmetri.cbs.dep.svc.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mysema.query.types.EntityPath;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.svc.AbstractXmlApiBusinessService;
import com.silverlakesymmetri.cbs.commons.svc.BusinessObjectValidationCapable;
import com.silverlakesymmetri.cbs.commons.xmlapi.enums.CbsXmlApiOperation;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.OdOvdAdHoc;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.OdOvdAdHocJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.QOdOvdAdHocJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.id.OdOvdAdHocPk;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.util.DepJpeConstants;
import com.silverlakesymmetri.cbs.dep.svc.OdOvdAdHocService;
import com.silverlakesymmetri.cbs.dep.svc.mapper.OdOvdAdHocServiceMapper;
import com.silverlakesymmetri.cbs.dep.xmlapi.DEPODOVDAPIType;

@Service
public class OdOvdAdHocServiceImpl
		extends AbstractXmlApiBusinessService<OdOvdAdHoc, OdOvdAdHocJpe, OdOvdAdHocPk, DEPODOVDAPIType, DEPODOVDAPIType>
		implements OdOvdAdHocService, BusinessObjectValidationCapable<OdOvdAdHoc> {

	@Autowired
	OdOvdAdHocServiceMapper mapper;

	@Override
	protected EntityPath<OdOvdAdHocJpe> getEntityPath() {
		return QOdOvdAdHocJpe.odOvdAdHocJpe;
	}

	@Override
	protected OdOvdAdHocPk getIdFromDataObjectInstance(OdOvdAdHoc dataObject) {
		return new OdOvdAdHocPk(dataObject.getOvdSeqNo());
	}

	@Override
	public OdOvdAdHoc getByPk(String publicKey, OdOvdAdHoc reference) {
		//return super.getByPk(publicKey, reference);
		if (publicKey != null) {
			String [] keys = publicKey.split("~");
			if (keys != null && keys.length > 0) {
				try {
					Long ovdSeqNo = Long.parseLong(keys[0]);
					if (ovdSeqNo != null) {
						OdOvdAdHocPk odOvdAdHocPk = new OdOvdAdHocPk(Long.parseLong(keys[0]));
						OdOvdAdHocJpe jpe = this.dataService.find(OdOvdAdHocJpe.class, odOvdAdHocPk);
						return jaxbSdoHelper.wrap(jpe);
					}
				} catch (NumberFormatException e) {
				}
			}
		}
		return null;
	}

	@Override
	public OdOvdAdHoc create(OdOvdAdHoc dataObject) {
		return super.create(dataObject);
	}

	@Override
	public OdOvdAdHoc update(OdOvdAdHoc dataObject) {
		return super.update(dataObject);
	}

	@Override
	public boolean delete(OdOvdAdHoc dataObject) {
		return super.delete(dataObject);
	}

	@Override
	public List<OdOvdAdHoc> query(int offset, int resultLimit, String groupBy, String order,
			Map<String, Object> filters) {
		return super.query(offset, resultLimit, groupBy, order, filters);
	}

	@Override
	public List<OdOvdAdHoc> find(FindCriteria findCriteria, CbsHeader cbsHeader) {
		return super.find(findCriteria, cbsHeader);
	}

	@Override
	protected Class<DEPODOVDAPIType> getXmlApiResponseClass() {
		return DEPODOVDAPIType.class;
	}

	@Override
	protected List<OdOvdAdHoc> processXmlApiListRs(OdOvdAdHoc dataObject, DEPODOVDAPIType xmlApiRs) {
		return null;
	}

	@Override
	protected OdOvdAdHoc processXmlApiRs(OdOvdAdHoc dataObject, DEPODOVDAPIType xmlApiRs) {
		OdOvdAdHocJpe jpe = jaxbSdoHelper.unwrap(dataObject);
		return jaxbSdoHelper.wrap(mapper.mapToJpe(xmlApiRs, jpe));
	}

	@Override
	protected OdOvdAdHoc preCreateValidation(OdOvdAdHoc dataObject) {
		OdOvdAdHocJpe jpe = jaxbSdoHelper.unwrap(dataObject, OdOvdAdHocJpe.class);
		if (jpe.getOvdSeqNo() == null || jpe.getOvdSeqNo() == 0) {
			long seqNo = dataService.nextSequenceValue("DEP_OD_OVD_S").longValue();
			jpe.setOvdSeqNo(seqNo);
			return super.preCreateValidation(jaxbSdoHelper.wrap(jpe, OdOvdAdHoc.class));
		}
		return super.preCreateValidation(dataObject);
	}

	@Override
	protected DEPODOVDAPIType transformBdoToXmlApiRqCreate(OdOvdAdHoc dataObject) {
		return transformOdOvdAdHocToDEPODOVDAPIType(dataObject, CbsXmlApiOperation.INSERT);
	}

	@Override
	protected DEPODOVDAPIType transformBdoToXmlApiRqDelete(OdOvdAdHoc dataObject) {
		return transformOdOvdAdHocToDEPODOVDAPIType(dataObject, CbsXmlApiOperation.DELETE);
	}

	@Override
	protected DEPODOVDAPIType transformBdoToXmlApiRqUpdate(OdOvdAdHoc dataObject) {
		return transformOdOvdAdHocToDEPODOVDAPIType(dataObject, CbsXmlApiOperation.UPDATE);
	}

	private DEPODOVDAPIType transformOdOvdAdHocToDEPODOVDAPIType(OdOvdAdHoc dataObject, CbsXmlApiOperation oper) {
		HashMap<String, Object> params = new HashMap<String, Object>();
		params.put("acctNo", dataObject.getAcctNo());
		Long internalKey = dataService.getWithNamedQuery(DepJpeConstants.ACCT_JPE_FIND_INTERNAL_KEY_BY_ACCT_NO, params,
				Long.class);
		OdOvdAdHocJpe jpe = jaxbSdoHelper.unwrap(dataObject);
		jpe.setInternalKey(internalKey);
		DEPODOVDAPIType api = mapper.mapToApi(jpe, oper);
		super.setTechColsFromDataObject(dataObject, api);
		return api;
	}

}
