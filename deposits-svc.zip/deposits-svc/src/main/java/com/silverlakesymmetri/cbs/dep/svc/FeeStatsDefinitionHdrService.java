package com.silverlakesymmetri.cbs.dep.svc;

import java.util.List;
import java.util.Map;

import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation;
import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation.ServiceOperationType;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.svc.BusinessService;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.FeeStatsDefinitionHdr;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.FeeStatsDefinitionHdrJpe;

public interface FeeStatsDefinitionHdrService extends BusinessService<FeeStatsDefinitionHdr, FeeStatsDefinitionHdrJpe> {
	public static final String SVC_OP_NAME_FEESTATSDEFINITIONHDRSERVICE_GET = "FeeStatsDefinitionHdrService.get";
    public static final String SVC_OP_NAME_FEESTATSDEFINITIONHDRSERVICE_QUERY = "FeeStatsDefinitionHdrService.query";
    public static final String SVC_OP_NAME_FEESTATSDEFINITIONHDRSERVICE_CREATE = "FeeStatsDefinitionHdrService.create";
    public static final String SVC_OP_NAME_FEESTATSDEFINITIONHDRSERVICE_UPDATE = "FeeStatsDefinitionHdrService.update";
    public static final String SVC_OP_NAME_FEESTATSDEFINITIONHDRSERVICE_DELETE = "FeeStatsDefinitionHdrService.delete";
    public static final String SVC_OP_NAME_FEESTATSDEFINITIONHDRSERVICE_FIND = "FeeStatsDefinitionHdrService.find";
    
    @ServiceOperation(name = SVC_OP_NAME_FEESTATSDEFINITIONHDRSERVICE_GET, type = ServiceOperationType.GET)
    public FeeStatsDefinitionHdr getByPk(String publicKey, FeeStatsDefinitionHdr reference);

    @ServiceOperation(name = SVC_OP_NAME_FEESTATSDEFINITIONHDRSERVICE_CREATE)
    public FeeStatsDefinitionHdr create(FeeStatsDefinitionHdr dataObject);

    @ServiceOperation(name = SVC_OP_NAME_FEESTATSDEFINITIONHDRSERVICE_UPDATE)
    public FeeStatsDefinitionHdr update(FeeStatsDefinitionHdr dataObject);

    @ServiceOperation(name = SVC_OP_NAME_FEESTATSDEFINITIONHDRSERVICE_DELETE)
    public boolean delete(FeeStatsDefinitionHdr dataObject);

    @ServiceOperation(name = SVC_OP_NAME_FEESTATSDEFINITIONHDRSERVICE_QUERY)
    public List<FeeStatsDefinitionHdr> query(int offset, int resultLimit, String groupBy, String order, Map<String, Object> filters);

    @ServiceOperation(name = SVC_OP_NAME_FEESTATSDEFINITIONHDRSERVICE_FIND)
    public List<FeeStatsDefinitionHdr> find(FindCriteria findCriteria, CbsHeader cbsHeader);
}
