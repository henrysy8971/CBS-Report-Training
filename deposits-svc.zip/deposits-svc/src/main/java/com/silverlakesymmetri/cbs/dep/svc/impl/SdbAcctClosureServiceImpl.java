package com.silverlakesymmetri.cbs.dep.svc.impl;

import java.util.HashMap;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.mysema.query.types.EntityPath;
import com.silverlakesymmetri.cbs.commons.svc.AbstractXmlApiBusinessService;
import com.silverlakesymmetri.cbs.commons.xmlapi.enums.CbsXmlApiOperation;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.SdbAcct;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.QSdbAcctJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.SdbAcctJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.id.SdbAcctPk;
import com.silverlakesymmetri.cbs.dep.svc.SdbAcctClosureService;
import com.silverlakesymmetri.cbs.dep.svc.mapper.SdbAcctClosureServiceMapper;
import com.silverlakesymmetri.cbs.dep.xmlapi.DEPSDBCLOSUREAPIType;

@Service
@Transactional
public class SdbAcctClosureServiceImpl 
	extends AbstractXmlApiBusinessService<SdbAcct, SdbAcctJpe, SdbAcctPk,  DEPSDBCLOSUREAPIType, DEPSDBCLOSUREAPIType>
	implements SdbAcctClosureService {

	@Autowired
	SdbAcctClosureServiceMapper mapper;
	
	@Override
	public SdbAcct update(SdbAcct dataObject) {
		return super.update(dataObject);
	}

	@Override
	protected DEPSDBCLOSUREAPIType transformBdoToXmlApiRqCreate(SdbAcct dataObject) {
		return null;
	}

	@Override
	protected DEPSDBCLOSUREAPIType transformBdoToXmlApiRqUpdate(SdbAcct dataObject) {
		SdbAcctJpe jpe = jaxbSdoHelper.unwrap(dataObject);
		DEPSDBCLOSUREAPIType xmlApiRq = mapper.mapToApi(jpe, CbsXmlApiOperation.UPDATE, new HashMap());
		super.setTechColsFromDataObject(dataObject, xmlApiRq);
		
		return xmlApiRq;
	}

	@Override
	protected DEPSDBCLOSUREAPIType transformBdoToXmlApiRqDelete(SdbAcct dataObject) {
		return null;
	}

	@Override
	protected SdbAcct processXmlApiRs(SdbAcct dataObject, DEPSDBCLOSUREAPIType xmlApiRs) {
		SdbAcctJpe jpe = jaxbSdoHelper.unwrap(dataObject);
		jpe = mapper.mapToJpe(xmlApiRs, jpe);
		
		return jaxbSdoHelper.wrap(jpe);
	}

	@Override
	protected List<SdbAcct> processXmlApiListRs(SdbAcct dataObject, DEPSDBCLOSUREAPIType xmlApiRs) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	protected Class<DEPSDBCLOSUREAPIType> getXmlApiResponseClass() {
		return DEPSDBCLOSUREAPIType.class;
	}

	@Override
	protected SdbAcctPk getIdFromDataObjectInstance(SdbAcct dataObject) {
		SdbAcct jpe = jaxbSdoHelper.unwrap(dataObject);
		return new SdbAcctPk(jpe.getSdbInternalKey());
	}

	@Override
	protected EntityPath<SdbAcctJpe> getEntityPath() {
		return QSdbAcctJpe.sdbAcctJpe; 
	}
	

}
