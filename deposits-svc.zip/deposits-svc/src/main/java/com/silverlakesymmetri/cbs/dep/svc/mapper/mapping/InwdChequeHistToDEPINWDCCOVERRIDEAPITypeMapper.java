package com.silverlakesymmetri.cbs.dep.svc.mapper.mapping;

import org.mapstruct.MapperConfig;
import org.mapstruct.Mapping;
import org.mapstruct.Mappings;

import com.silverlakesymmetri.cbs.commons.jpa.util.DateTimeHelper;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.InwdChequeHistJpe;
import com.silverlakesymmetri.cbs.dep.xmlapi.DEPINWDCCOVERRIDEAPIType;

@MapperConfig(uses={ DateTimeHelper.class})
public interface InwdChequeHistToDEPINWDCCOVERRIDEAPITypeMapper {
	

	@Mappings({
		@Mapping(source="seqNo", target ="SEQNO"), 
		@Mapping(source="chequeNo", target ="CHEQUENO"), 
		@Mapping(source="acctNo", target ="ACCTNO"	), 
		@Mapping(source="remarks", target ="REMARKS"), 
		@Mapping(source="rejectCode", target ="REJECTCODE"), 
		@Mapping(source="errorNo", target ="ERRORNO"), 
		@Mapping(source="status", target ="STATUS"), 

	 })
	public DEPINWDCCOVERRIDEAPIType mapInwdChequeHistToDEPINWDCCOVERRIDEAPIType(InwdChequeHistJpe  jpe);
	
}

