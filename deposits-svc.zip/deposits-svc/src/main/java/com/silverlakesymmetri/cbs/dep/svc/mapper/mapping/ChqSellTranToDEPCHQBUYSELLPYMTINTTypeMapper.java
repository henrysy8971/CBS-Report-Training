package com.silverlakesymmetri.cbs.dep.svc.mapper.mapping;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Mappings;

import com.silverlakesymmetri.cbs.commons.jpa.util.DateTimeHelper;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.ChqSellTranJpe;
import com.silverlakesymmetri.cbs.dep.xmlapi.DEPCHQBUYSELLPYMTINTType;

@Mapper(uses = { DateTimeHelper.class })
public interface ChqSellTranToDEPCHQBUYSELLPYMTINTTypeMapper {
	
	@Mappings({
		@Mapping(source = "position", target = "POSITION"),
		@Mapping(source = "pymtMode", target = "PYMTMODE"),
		@Mapping(source = "tranType", target = "TRANTYPE"),
		@Mapping(source = "acctNo", target = "ACCTNO"),
		@Mapping(source = "ccy", target = "TRANCCY"),
		@Mapping(source = "tranAmt", target = "TRANAMT"),
		@Mapping(source = "reference", target = "CHEQUENO"),
		@Mapping(source = "settleCcy", target = "ACCTCCY"),
		@Mapping(source = "crossRate", target = "CROSSRATE"),
		@Mapping(source = "crossRate", target = "OVCROSSRATE"),
		@Mapping(source = "equivAmt", target = "EQUIVAMT"),

	})
	public DEPCHQBUYSELLPYMTINTType jpeToApiType(ChqSellTranJpe jpe);

}
