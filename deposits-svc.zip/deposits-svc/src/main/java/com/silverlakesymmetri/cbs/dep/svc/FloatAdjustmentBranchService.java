package com.silverlakesymmetri.cbs.dep.svc;

import java.util.List;
import java.util.Map;

import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation;
import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation.ServiceOperationType;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.svc.BusinessService;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.FloatAdjustmentBranch;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.FloatAdjustmentBranchJpe;

public interface FloatAdjustmentBranchService extends BusinessService<FloatAdjustmentBranch, FloatAdjustmentBranchJpe> {
	public static final String SVC_OP_NAME_FLOATADJUSTMENTBRANCH_GET = "FloatAdjustmentBranchService.get";
    public static final String SVC_OP_NAME_FLOATADJUSTMENTBRANCH_QUERY = "FloatAdjustmentBranchService.query";
    public static final String SVC_OP_NAME_FLOATADJUSTMENTBRANCH_CREATE = "FloatAdjustmentBranchService.create";
    public static final String SVC_OP_NAME_FLOATADJUSTMENTBRANCH_UPDATE = "FloatAdjustmentBranchService.update";
    public static final String SVC_OP_NAME_FLOATADJUSTMENTBRANCH_DELETE = "FloatAdjustmentBranchService.delete";
    public static final String SVC_OP_NAME_FLOATADJUSTMENTBRANCH_FIND = "FloatAdjustmentBranchService.find";
    public static final String SVC_OP_NAME_FLOATADJUSTMENTBRANCH_PROCESSFLOATADJ = "FloatAdjustmentBranchService.processFloatAdj";
    
    @ServiceOperation(name = SVC_OP_NAME_FLOATADJUSTMENTBRANCH_GET, type = ServiceOperationType.GET)
    public FloatAdjustmentBranch getByPk(String publicKey, FloatAdjustmentBranch reference);

    @ServiceOperation(name = SVC_OP_NAME_FLOATADJUSTMENTBRANCH_CREATE)
    public FloatAdjustmentBranch create(FloatAdjustmentBranch dataObject);

    @ServiceOperation(name = SVC_OP_NAME_FLOATADJUSTMENTBRANCH_UPDATE)
    public FloatAdjustmentBranch update(FloatAdjustmentBranch dataObject);

    @ServiceOperation(name = SVC_OP_NAME_FLOATADJUSTMENTBRANCH_QUERY)
    public List<FloatAdjustmentBranch> query(int offset, int resultLimit, String groupBy, String order, Map<String, Object> filters);

    @ServiceOperation(name = SVC_OP_NAME_FLOATADJUSTMENTBRANCH_DELETE)
    public boolean delete(FloatAdjustmentBranch dataObject);

    @ServiceOperation(name = SVC_OP_NAME_FLOATADJUSTMENTBRANCH_FIND)
    public List<FloatAdjustmentBranch> find(FindCriteria findCriteria, CbsHeader cbsHeader);
    
    @ServiceOperation(name = SVC_OP_NAME_FLOATADJUSTMENTBRANCH_PROCESSFLOATADJ, type = ServiceOperationType.EXECUTE)
    public FloatAdjustmentBranch processFloatAdj(FloatAdjustmentBranch dataObject);
}
