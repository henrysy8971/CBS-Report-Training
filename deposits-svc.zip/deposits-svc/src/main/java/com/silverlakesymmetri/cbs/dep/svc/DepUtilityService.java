package com.silverlakesymmetri.cbs.dep.svc;

import java.util.Date;

import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation;
import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation.ServiceOperationType;
import com.silverlakesymmetri.cbs.core.util.CcyConversionObject;
import com.silverlakesymmetri.cbs.dep.util.ForexObject;
import com.silverlakesymmetri.cbs.dep.util.RecalcTaxObject;

/**
 * @author Ryan.Vargas
 */
public interface DepUtilityService {

	public static final String SVC_OP_NAME_DEPUTILITYSERVICE_GET_RATE_TYPE = "DepUtilityService.getRateType";
	public static final String SVC_OP_NAME_DEPUTILITYSERVICE_GET_EQUIV_AMT = "DepUtilityService.getEquivalentAmount";
	public static final String SVC_OP_NAME_DEPUTILITYSERVICE_GET_EQUIV_FOREX = "DepUtilityService.getForexEquivalent";
	public static final String SVC_OP_NAME_DEPUTILITYSERVICE_GET_EQUIV_COMM = "DepUtilityService.getCommissionEquivalent";
	public static final String SVC_OP_NAME_DEPUTILITYSERVICE_GET_RECALC_TAX = "DepUtilityService.getRecalcTax";
	public static final String SVC_OP_NAME_DEPUTILITYSERVICE_GET_EQUIV_AMT_RATE = "DepUtilityService.getEquivalentAmountRate";
	public static final String SVC_OP_NAME_DEPUTILITYSERVICE_GET_RECALC_TAX_EXT = "DepUtilityService.getRecalcTaxExt";
	public static final String SVC_OP_NAME_DEPUTILITYSERVICE_CALC_CASA_INT_RATE = "DepUtilityService.calcCasaIntRate";
	public static final String SVC_OP_NAME_DEPUTILITYSERVICE_CALC_TD_INT_RATE = "DepUtilityService.calcTdIntRate";
	public static final String SVC_OP_NAME_DEPUTILITYSERVICE_MOVE_FINAL_RATES = "DepUtilityService.movefinalrates";
	
	@ServiceOperation(name = SVC_OP_NAME_DEPUTILITYSERVICE_GET_EQUIV_AMT, type = ServiceOperationType.EXECUTE)
    public CcyConversionObject getEquivalentAmount(CcyConversionObject ccyConversionObject);
	
	@ServiceOperation(name = SVC_OP_NAME_DEPUTILITYSERVICE_GET_EQUIV_FOREX, type = ServiceOperationType.EXECUTE)
    public ForexObject getForexEquivalent(ForexObject forexObject);
	
	@ServiceOperation(name = SVC_OP_NAME_DEPUTILITYSERVICE_GET_EQUIV_COMM, type = ServiceOperationType.EXECUTE)
    public ForexObject getCommissionEquivalent(ForexObject forexObject);

	@ServiceOperation(name = SVC_OP_NAME_DEPUTILITYSERVICE_GET_RATE_TYPE, type = ServiceOperationType.GET)
    public String getRateType(String tranType, String clientNo);
	
	@ServiceOperation(name = SVC_OP_NAME_DEPUTILITYSERVICE_GET_RECALC_TAX, type = ServiceOperationType.EXECUTE)
    public RecalcTaxObject getRecalcTax(RecalcTaxObject recalcTaxObject);
	
	@ServiceOperation(name = SVC_OP_NAME_DEPUTILITYSERVICE_GET_EQUIV_AMT_RATE, type = ServiceOperationType.EXECUTE)
	public CcyConversionObject getEquivalentAmountRate(CcyConversionObject ccyConversionObject);
	
	@ServiceOperation(name = SVC_OP_NAME_DEPUTILITYSERVICE_GET_RECALC_TAX_EXT, type = ServiceOperationType.GET)
    public RecalcTaxObject getRecalcTaxExt(String scType, Double scAmt, Double scTaxAmt, String ccy, String acctNo, String certNo);

	@ServiceOperation(name = SVC_OP_NAME_DEPUTILITYSERVICE_CALC_CASA_INT_RATE, type = ServiceOperationType.GET)
	public String calcCasaIntRate(String intType, String crDrInd, String ccy, Double acctLevelIntRate, Double spreadRate);

	@ServiceOperation(name = SVC_OP_NAME_DEPUTILITYSERVICE_CALC_TD_INT_RATE, type = ServiceOperationType.GET)
	public String calcTdIntRate(String acctType, String intType, Date effectDate, String ccy, Double balAmt,
			Integer depTermPeriod, String depTermType, Double acctLevelIntRate, Double spreadRate);
	
	@ServiceOperation(name = SVC_OP_NAME_DEPUTILITYSERVICE_MOVE_FINAL_RATES, type = ServiceOperationType.EXECUTE)
	public Long moveFinalRates(String intType, String ccy, Date effectDate);

}
