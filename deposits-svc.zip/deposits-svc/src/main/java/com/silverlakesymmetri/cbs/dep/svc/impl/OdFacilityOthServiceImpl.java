package com.silverlakesymmetri.cbs.dep.svc.impl;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.odata4j.core.ImmutableMap;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mysema.query.types.EntityPath;
import com.silverlakesymmetri.cbs.col.bdo.sdo.Product;
import com.silverlakesymmetri.cbs.col.enums.ColGlobalConstants;
import com.silverlakesymmetri.cbs.col.jpa.mapping.sdo.ProductCollateralJpe;
import com.silverlakesymmetri.cbs.col.jpa.mapping.sdo.ProductJpe;
import com.silverlakesymmetri.cbs.col.jpa.mapping.sdo.id.ProductPk;
import com.silverlakesymmetri.cbs.col.svc.ProductService;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.context.CbsSessionContext;
import com.silverlakesymmetri.cbs.commons.jpa.entity.CbsHeaderJpe;
import com.silverlakesymmetri.cbs.commons.jpa.types.StructureBasisTypeObject;
import com.silverlakesymmetri.cbs.commons.jpa.util.BdoHelper;
import com.silverlakesymmetri.cbs.commons.svc.AbstractXmlApiBusinessService;
import com.silverlakesymmetri.cbs.commons.svc.BusinessObjectValidationCapable;
import com.silverlakesymmetri.cbs.commons.svc.ref.ReferenceNumberGeneratorService;
import com.silverlakesymmetri.cbs.commons.xmlapi.enums.CbsXmlApiOperation;
import com.silverlakesymmetri.cbs.constants.CommonsConstants;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.Acct;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.OdFacilityOth;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.OdOvd;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.OdRepayAcct;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.OdStatus;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.OverdraftType;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.AcctJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.OdFacilityOthJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.OdOvdJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.OdRepayAcctJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.OdStatusJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.OverdraftTypeJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.QOdFacilityOthJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.id.OdFacilityOthPk;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.util.DepJpeConstants;
import com.silverlakesymmetri.cbs.dep.svc.OdFacilityOthService;
import com.silverlakesymmetri.cbs.dep.svc.mapper.OdFacilityOthServiceMapper;
import com.silverlakesymmetri.cbs.dep.xmlapi.DEPODFACILITYAPIType;
import com.silverlakesymmetri.cbs.dep.xmlapi.DEPODREPAYACCTAPIType;
import com.silverlakesymmetri.cbs.dep.xmlapi.DEPODREPAYACCTCOLLType;
import com.silverlakesymmetri.cbs.xps.bdo.sdo.DocDomainObjDefn;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.DocDomainObjDefnJpe;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.util.XpsJpeConstants;
import com.silverlakesymmetri.cbs.xps.svc.DocDomainObjDefnService;

@Service
public class OdFacilityOthServiceImpl extends
		AbstractXmlApiBusinessService<OdFacilityOth, OdFacilityOthJpe, Long, DEPODFACILITYAPIType, DEPODFACILITYAPIType>
		implements OdFacilityOthService, BusinessObjectValidationCapable<OdFacilityOth> {

	private static final String CBS_CHANNEL_CODE = "CBS";
	private static final String CBS_CHANNEL_SOURCE = "HTTP-UI";
	private static final String DEP_OD_FACILITY = "DEP_OD_FACILITY_S";

	@Autowired
	OdFacilityOthServiceMapper mapper;

	@Autowired
	private ReferenceNumberGeneratorService referenceNumberGeneratorService;

	@Autowired
	private DocDomainObjDefnService docDomainObjDefnService;
	
	@Autowired
	private ProductService productService;

	@Override
	protected EntityPath<OdFacilityOthJpe> getEntityPath() {
		return QOdFacilityOthJpe.odFacilityOthJpe;
	}

	@Override
	protected Long getIdFromDataObjectInstance(OdFacilityOth dataObject) {
		return dataObject.getSeqNo();
	}

	@Override
	public OdFacilityOth getByPk(String publicKey, OdFacilityOth reference) {
		OdFacilityOth odFacilityOth = super.getByPk(publicKey, reference);
		Long internalKey = getInternalKey(odFacilityOth.getAcctNo());
		odFacilityOth.setOdOvdList(getOdOvdList(internalKey, odFacilityOth.getSeqNo()));
		odFacilityOth.setOdStatusList(getOdStatusList(internalKey, odFacilityOth.getSeqNo()));
		odFacilityOth.setOdRepayAcctList(getOdRepayAcctList(internalKey));
		odFacilityOth.setDocDomainObjDefnList(getDocDomainObjDefnList(odFacilityOth));
		return odFacilityOth;
	}

	@Override
	protected OdFacilityOth preCreateValidation(OdFacilityOth dataObject) {
		if (dataObject.getOdFeesTcList() == null || dataObject.getOdFeesTcList().size() == 0) {
			dataObject.setTcInd("N");
		} else {
			dataObject.setTcInd("Y");
		}
		setDocDefaults(dataObject);

		Long seqNo = dataService.nextSequenceValue(DEP_OD_FACILITY).longValue();
		dataObject.setSeqNo(seqNo);

		return super.preCreateValidation(dataObject);
	}

	@Override
	protected OdFacilityOth preUpdateValidation(OdFacilityOth dataObject) {
		if (dataObject.getOdFeesTcList() == null || dataObject.getOdFeesTcList().size() == 0) {
			dataObject.setTcInd("N");
		} else {
			dataObject.setTcInd("Y");
		}
		setDocDefaults(dataObject);
		return super.preUpdateValidation(dataObject);
	}

	@Override
	public OdFacilityOth create(OdFacilityOth dataObject) {
		OdFacilityOth createdOdFacilityOth = super.create(dataObject);
		OdFacilityOthJpe odFacilityOthJpe = jaxbSdoHelper.unwrap(createdOdFacilityOth, OdFacilityOthJpe.class);
		delegateDocDomainObjDefnCreateOrUpdate(odFacilityOthJpe.getHeader(), dataObject.getDocDomainObjDefnList(),
				new ArrayList<DocDomainObjDefn>(), createdOdFacilityOth);
		String oldRefObjectKey = genRefObjectKey(dataObject);
		String newRefObjectKey = genRefObjectKey(createdOdFacilityOth);
		if (!StringUtils.equals(oldRefObjectKey, newRefObjectKey)) {
			Map<String, Object> map = new HashMap<String, Object>();
			map.put("newRefObjectKey", newRefObjectKey);
			map.put("oldRefObjectKey", oldRefObjectKey);
			dataService.bulkUpdateWithNamedQuery(XpsJpeConstants.DOC_DOMAIN_OBJ_DEFN_JPE_UPDATE_REF_OBJECT_KEY,
					map, DocDomainObjDefnJpe.class);
			for (DocDomainObjDefn docDomainObjDefn : createdOdFacilityOth.getDocDomainObjDefnList()) {
				docDomainObjDefn.setRefObjectKey(newRefObjectKey);
			}
		}
		return createdOdFacilityOth;
	}

	@Override
	public OdFacilityOth update(OdFacilityOth dataObject) {
		OdFacilityOth updatedOdFacilityOth = super.update(dataObject);
		OdFacilityOthJpe odFacilityOthJpe = jaxbSdoHelper.unwrap(updatedOdFacilityOth, OdFacilityOthJpe.class);
		delegateDocDomainObjDefnCreateOrUpdate(odFacilityOthJpe.getHeader(), dataObject.getDocDomainObjDefnList(),
				getDocDomainObjDefnList(dataObject), updatedOdFacilityOth);
		if ("R".equals(dataObject.getVerifyRejectInd())) {
			processCollateralRelease(updatedOdFacilityOth.getAcctNo(), updatedOdFacilityOth.getSeqNo());
		}
		return updatedOdFacilityOth;
	}
	
	private void processCollateralRelease(String acctNo, Long seqNo) {
		if (StringUtils.isNotBlank(acctNo) && seqNo != null) {
			ProductJpe productJpe = dataService.find(ProductJpe.class, new ProductPk("ODFacility", String.format("%d~%s", seqNo, acctNo)));
			if (productJpe != null) {
				boolean hasModifiedData = false;
				for (ProductCollateralJpe pcJpe : productJpe.getProductCollateralList()) {
					if (pcJpe.isHistoryYn() != null && !pcJpe.isHistoryYn().booleanValue()) {
						hasModifiedData = true;
						pcJpe.setHistoryYn(true);
						pcJpe.setUnassignReason(getReleaseReason());
						pcJpe.setUnassignRemark(String.format("Overdraft Rejected. (Account No: %s, Seq No: %d)", acctNo, seqNo));	
					}
				}
				if (hasModifiedData) {
					productService.update(jaxbSdoHelper.wrap(productJpe, Product.class));	
				}
			}
		}
		
		
	}
	
	private String getReleaseReason() {
        String releaseReason = cbsRuntimeContextManager.getBestAvailableContext().getRegistryEntry(ColGlobalConstants.COLLATERAL_REGISTRY,
                ColGlobalConstants.COLL_PROD_DEFAULT_RELEASE_STATUS_REASON, String.class);
        return releaseReason;
    }

	/*
	@Override
	public boolean delete(OdFacilityOth dataObject) {
		boolean deleted = super.delete(dataObject);

		if (deleted) {
			for (DocDomainObjDefn docDomainObjDefn : getDocDomainObjDefnList(dataObject)) {
				docDomainObjDefnService.delete(docDomainObjDefn);
			}
		}
		return super.delete(dataObject);
	}
	*/

	@Override
	public List<OdFacilityOth> query(int offset, int resultLimit, String groupBy, String order,
			Map<String, Object> filters) {
		return super.query(offset, resultLimit, groupBy, order, filters);
	}

	@Override
	public List<OdFacilityOth> find(FindCriteria findCriteria, CbsHeader cbsHeader) {
		return super.find(findCriteria, cbsHeader);
	}

	@Override
	protected List<OdFacilityOth> processXmlApiListRs(OdFacilityOth dataObject, DEPODFACILITYAPIType xmlApiRs) {
		return null;
	}

	@Override
	protected OdFacilityOth processXmlApiRs(OdFacilityOth dataObject, DEPODFACILITYAPIType xmlApiRs) {
		if (xmlApiRs != null && xmlApiRs.getSEQNO() != null && xmlApiRs.getACCTNO() != null) {
			Long internalKey = getInternalKey(xmlApiRs.getACCTNO());
			OdFacilityOthPk pk = new OdFacilityOthPk(internalKey, xmlApiRs.getSEQNO());
			OdFacilityOthJpe jpe = dataService.find(OdFacilityOthJpe.class, pk);
			if (jpe != null) {
				dataObject = jaxbSdoHelper.wrap(jpe, OdFacilityOth.class);
				dataObject.setPriorityNo(xmlApiRs.getPRIORITYNO());
				dataObject.setOdOvdList(getOdOvdList(internalKey, dataObject.getSeqNo()));
				dataObject.setOdStatusList(getOdStatusList(internalKey, dataObject.getSeqNo()));
				dataObject.setOdRepayAcctList(getOdRepayAcctList(internalKey));
				dataObject.setDocDomainObjDefnList(getDocDomainObjDefnList(dataObject));
			}
		}
		return dataObject;
	}

	@Override
	protected DEPODFACILITYAPIType transformBdoToXmlApiRqCreate(OdFacilityOth dataObject) {
		return transformOdFacilityOthToDEPODFACILITYAPIType(dataObject, CbsXmlApiOperation.INSERT);
	}

	@Override
	protected DEPODFACILITYAPIType transformBdoToXmlApiRqDelete(OdFacilityOth dataObject) {
		// return transformOdFacilityOthToDEPODFACILITYAPIType(dataObject, CbsXmlApiOperation.DELETE);
		return null;
	}

	@Override
	protected DEPODFACILITYAPIType transformBdoToXmlApiRqUpdate(OdFacilityOth dataObject) {
		return transformOdFacilityOthToDEPODFACILITYAPIType(dataObject, CbsXmlApiOperation.UPDATE);
	}

	@Override
	protected Class<DEPODFACILITYAPIType> getXmlApiResponseClass() {
		return DEPODFACILITYAPIType.class;
	}

	@SuppressWarnings("rawtypes")
	private DEPODFACILITYAPIType transformOdFacilityOthToDEPODFACILITYAPIType(OdFacilityOth dataObject,
			CbsXmlApiOperation oper) {

		OdFacilityOthJpe odFacilityOthJpe = jaxbSdoHelper.unwrap(dataObject);
		DEPODFACILITYAPIType xmlApiRq = mapper.mapToApi(odFacilityOthJpe, oper, new HashMap());
		super.setTechColsFromDataObject(dataObject, xmlApiRq);

		DEPODREPAYACCTCOLLType repayAcctCollType = new DEPODREPAYACCTCOLLType();

		OverdraftType overdraftType = getOverdraftType(dataObject.getOdType());
		int priority = 0;

		if (overdraftType != null) {

			List<String> repayAcctNoList = new ArrayList<String>();
			List<OdRepayAcct> list = dataObject.getOdRepayAcctList();

			if (list == null) {
				list = new ArrayList<OdRepayAcct>();
			}

			OdRepayAcct autoGenRepayAcct = null;

			for (OdRepayAcct odRepayAcct : list) {
				if (odRepayAcct != null && !odRepayAcct.getChangeSummary().isDeleted(odRepayAcct)) {
					if (StringUtils.equals("Y", odRepayAcct.getAutoGenerate())) {
						if (autoGenRepayAcct == null) {
							autoGenRepayAcct = odRepayAcct;
							break;
						}
					}
				}
			}

			/*
			if (StringUtils.equals("Y", overdraftType.getSelfHunting())) {
				String acctNo = dataObject.getAcctNo();
				Long repayInternalKey = getInternalKey(acctNo);
				if (repayInternalKey != null) {
					DEPODREPAYACCTAPIType odRepayAcctApiType = new DEPODREPAYACCTAPIType();
					super.setTechColsFromDataObject(dataObject, odRepayAcctApiType);
					odRepayAcctApiType.setACCTNO(acctNo);
					odRepayAcctApiType.setREPAYACCTNO(acctNo);
					odRepayAcctApiType.setREPAYINTERNALKEY(repayInternalKey);
					odRepayAcctApiType.setPRIORITY(++priority);
					odRepayAcctApiType.setOVERDRAFTTYPE(dataObject.getOdType());
					odRepayAcctApiType.setAUTOGENERATE("N");
					repayAcctCollType.getDEPODREPAYACCTAPI().add(odRepayAcctApiType);
					repayAcctNoList.add(odRepayAcctApiType.getREPAYACCTNO());
				}
			}
			*/

			if (StringUtils.equals("Y", overdraftType.getGenRepayAcct())) {
				String acctNo = null;
				String repayAcctNo = null;
				Long repayInternalKey = null;
				if (autoGenRepayAcct == null) {
					if (StringUtils.equals("V", xmlApiRq.getPURPOSE())) {
						Acct repayAcct = jaxbSdoHelper.wrap(new AcctJpe(), Acct.class);
						Acct acct = getAcct(dataObject.getAcctNo());
						if (acct != null) {
							repayAcct.setCcy(acct.getCcy());
							repayAcct.setBranch(acct.getBranch());
							repayAcct.setClientNo(acct.getClientNo());
							repayAcct.setAcctType(acct.getAcctType());
						}
						if (overdraftType.getRepayAcctType() != null) {
							repayAcct.setAcctType(overdraftType.getRepayAcctType());
						}
						referenceNumberGeneratorService.getNewRefNo(repayAcct, "acctNo", this.getStructObject(repayAcct));
						acctNo = dataObject.getAcctNo();
						repayAcctNo = repayAcct.getAcctNo();
						repayInternalKey = dataService.nextSequenceValue("PIM_MASTER_ACCOUNT_S");
					}
				} else {
					acctNo = autoGenRepayAcct.getAcctNo();
					repayAcctNo = autoGenRepayAcct.getRepayAcctNo();
					repayInternalKey = getInternalKey(repayAcctNo);
				}
				if (repayInternalKey != null && !repayAcctNoList.contains(acctNo)) {
					DEPODREPAYACCTAPIType odRepayAcctApiType = new DEPODREPAYACCTAPIType();
					priority = 1;
					super.setTechColsFromDataObject(dataObject, odRepayAcctApiType);
					odRepayAcctApiType.setACCTNO(acctNo);
					odRepayAcctApiType.setREPAYACCTNO(repayAcctNo);
					odRepayAcctApiType.setREPAYINTERNALKEY(repayInternalKey);
					odRepayAcctApiType.setPRIORITY(priority);
					odRepayAcctApiType.setOVERDRAFTTYPE(dataObject.getOdType());
					odRepayAcctApiType.setAUTOGENERATE("Y");
					repayAcctCollType.getDEPODREPAYACCTAPI().add(odRepayAcctApiType);
					repayAcctNoList.add(odRepayAcctApiType.getREPAYACCTNO());
				}
			}

			for (OdRepayAcct odRepayAcct : list) {
				if (odRepayAcct != null && !odRepayAcct.getChangeSummary().isDeleted(odRepayAcct)) {
					if (odRepayAcct.getRepayAcctNo() != null) {
						if (StringUtils.equals("Y", overdraftType.getSelfHunting())) {
							if (StringUtils.equals(odRepayAcct.getAcctNo(), odRepayAcct.getRepayAcctNo())) {
								continue;
							}
						}
						Long repayInternalKey = getInternalKey(odRepayAcct.getRepayAcctNo());
						if (repayInternalKey != null && !repayAcctNoList.contains(odRepayAcct.getRepayAcctNo())) {
							DEPODREPAYACCTAPIType odRepayAcctApiType = new DEPODREPAYACCTAPIType();
							super.setTechColsFromDataObject(dataObject, odRepayAcctApiType);
							odRepayAcctApiType.setACCTNO(odRepayAcct.getAcctNo());
							odRepayAcctApiType.setREPAYACCTNO(odRepayAcct.getRepayAcctNo());
							odRepayAcctApiType.setREPAYINTERNALKEY(repayInternalKey);
							odRepayAcctApiType.setPRIORITY(priority + odRepayAcct.getPriority().intValue());
							odRepayAcctApiType.setOVERDRAFTTYPE(dataObject.getOdType());
							odRepayAcctApiType.setAUTOGENERATE(
									odRepayAcct.getAutoGenerate() == null ? "N" : odRepayAcct.getAutoGenerate());
							repayAcctCollType.getDEPODREPAYACCTAPI().add(odRepayAcctApiType);
							repayAcctNoList.add(odRepayAcctApiType.getREPAYACCTNO());
						}
					}
				}
			}

		}

		xmlApiRq.setDEPODREPAYACCTDTLS(repayAcctCollType);
		return xmlApiRq;

	}

	private List<OdOvd> getOdOvdList(Long internalKey, Long seqNo) {
		Map<String, Object> params = new HashMap<String, Object>();
		params.put("internalKey", internalKey);
		params.put("odSeqNo", seqNo);
		List<OdOvdJpe> jpeList = dataService.findWithNamedQuery(DepJpeConstants.OD_OVD_LIST_BY_INTERNALKEY_ODSEQNO,
				params, OdOvdJpe.class);
		List<OdOvd> bdoList = new ArrayList<OdOvd>();
		if (jpeList != null && jpeList.size() > 0) {
			for (OdOvdJpe jpe : jpeList) {
				bdoList.add(jaxbSdoHelper.wrap(jpe, OdOvd.class));
			}
		}
		return bdoList;
	}

	private List<OdStatus> getOdStatusList(Long internalKey, Long seqNo) {
		Map<String, Object> params = new HashMap<String, Object>();
		params.put("internalKey", internalKey);
		params.put("seqNo", seqNo);
		List<OdStatusJpe> jpeList = dataService.findWithNamedQuery(DepJpeConstants.OD_STATUS_LIST_BY_INTERNALKEY_SEQNO,
				params, OdStatusJpe.class);
		List<OdStatus> bdoList = new ArrayList<OdStatus>();
		if (jpeList != null && jpeList.size() > 0) {
			for (OdStatusJpe jpe : jpeList) {
				bdoList.add(jaxbSdoHelper.wrap(jpe, OdStatus.class));
			}
		}
		return bdoList;
	}

	private List<OdRepayAcct> getOdRepayAcctList(Long internalKey) {
		Map<String, Object> params = new HashMap<String, Object>();
		params.put("internalKey", internalKey);
		List<OdRepayAcctJpe> jpeList = dataService.findWithNamedQuery(DepJpeConstants.OD_REPAY_ACCT_LIST_BY_INTERNALKEY,
				params, OdRepayAcctJpe.class);
		List<OdRepayAcct> bdoList = new ArrayList<OdRepayAcct>();
		if (jpeList != null && jpeList.size() > 0) {
			for (OdRepayAcctJpe jpe : jpeList) {
				bdoList.add(jaxbSdoHelper.wrap(jpe, OdRepayAcct.class));
			}
		}
		return bdoList;
	}

	private OverdraftType getOverdraftType(String odType) {
		Map<String, Object> params = new HashMap<String, Object>();
		params.put("odType", odType);
		OverdraftTypeJpe jpe = dataService.getWithNamedQuery(DepJpeConstants.OVERDRAFT_TYPE_JPE_FIND_BY_OD_TYPE, params,
				OverdraftTypeJpe.class);
		if (jpe != null) {
			return jaxbSdoHelper.wrap(jpe, OverdraftType.class);
		}
		return null;
	}

	private Long getInternalKey(String acctNo) {
		Long internalKey = null;
		if (acctNo != null) {
			Map<String, Object> params = new HashMap<String, Object>();
			params.put("acctNo", acctNo);
			internalKey = dataService.getWithNamedQuery(DepJpeConstants.ACCT_JPE_FIND_INTERNAL_KEY_BY_ACCT_NO, params,
					Long.class);
		}
		return internalKey;
	}

	@SuppressWarnings("unchecked")
	protected void delegateDocDomainObjDefnCreateOrUpdate(CbsHeaderJpe headerJpe, List<DocDomainObjDefn> sourceList,
			List<DocDomainObjDefn> targetList, OdFacilityOth dataObject) {
		List<Object> sourceObjectList = (List<Object>) (Object) sourceList;
		List<Object> targetObjectList = (List<Object>) (Object) targetList;
		BdoHelper.ListDiffResult listDiffResult = getBdoHelper().diffItems(sourceObjectList, targetObjectList,
				new String[] { "docDomainObjDefnList" }, headerJpe, new BdoHelper.MergeAllPolicy(), true, true);

		if (listDiffResult.getNewItems() != null) {
			for (Object newItem : listDiffResult.getNewItems()) {
				docDomainObjDefnService.create((DocDomainObjDefn) newItem);
			}
		}

		if (listDiffResult.getUpdatedItems() != null) {
			for (Object updatedItem : listDiffResult.getUpdatedItems()) {
				docDomainObjDefnService.update((DocDomainObjDefn) updatedItem);
			}
		}

		if (listDiffResult.isChanged()) {
			dataObject.getDocDomainObjDefnList().clear();
			dataObject.getDocDomainObjDefnList().addAll(targetList);
		}
	}

	/*
	private List<DocDomainObjDefn> getDocDomainObjDefnsByObjectKey(Map<String, Object> objectKeyParams) {
		List<DocDomainObjDefnJpe> jpeList = dataService.find(objectKeyParams, DocDomainObjDefnJpe.class);
		List<DocDomainObjDefn> bdoList = new ArrayList<>(jpeList.size());
		for (DocDomainObjDefnJpe jpe : jpeList) {
			bdoList.add(jaxbSdoHelper.wrap(jpe, DocDomainObjDefn.class));
		}

		return bdoList;
	}
	*/

	private OdFacilityOth setDocDefaults(OdFacilityOth odFacilityOth) {
		List<DocDomainObjDefn> updatedDocDomainObjDefn = new ArrayList<>();
		for (DocDomainObjDefn docDomainObjDefn : odFacilityOth.getDocDomainObjDefnList()) {
			docDomainObjDefn.setModuleRefDomain("DEP");
			docDomainObjDefn.setRefDomain("OverdraftAccount");
			docDomainObjDefn.setRefDomainKey(odFacilityOth.getOdType());
			docDomainObjDefn.setRefObjectKey(genRefObjectKey(odFacilityOth));
			docDomainObjDefn.setRefObjectType("OdFacility");
			updatedDocDomainObjDefn.add(docDomainObjDefn);
		}
		odFacilityOth.setDocDomainObjDefnList(updatedDocDomainObjDefn);
		return odFacilityOth;
	}

	private List<DocDomainObjDefn> getDocDomainObjDefnList(OdFacilityOth odFacilityOth) {
		Map<String, Object> params = ImmutableMap.<String, Object>of("refDomainKey", odFacilityOth.getOdType(),
				"refObjectKey", genRefObjectKey(odFacilityOth));
		List<DocDomainObjDefnJpe> jpeList = dataService.findWithNamedQuery(
				XpsJpeConstants.DOC_DOMAIN_OBJ_DEFN_JPE_FIND_BY_REF_DOMAIN_KEY_AND_REF_OBJECT_KEY, params,
				DocDomainObjDefnJpe.class);
		List<DocDomainObjDefn> bdoList = new ArrayList<>();
		if (jpeList != null && jpeList.size() > 0) {
			for (DocDomainObjDefnJpe jpe : jpeList) {
				bdoList.add(jaxbSdoHelper.wrap(jpe, DocDomainObjDefn.class));
			}
		}
		return bdoList;
	}

	private String genRefObjectKey(OdFacilityOth odFacilityOth) {
		if (odFacilityOth != null) {
			return StringUtils.join(odFacilityOth.getAcctNo(), "~", odFacilityOth.getOdType(), "~",
					odFacilityOth.getSeqNo() + "", "~", odFacilityOth.getPriorityNo() + "");
		}
		return null;
	}

	public StructureBasisTypeObject getStructObject(Acct bdo) {
		if (bdo == null) {
			return null;
		}
		CbsSessionContext sessionContext = cbsRuntimeContextManager.getContext(CbsSessionContext.class);
		boolean fromSystem = CBS_CHANNEL_CODE.equals(sessionContext.getChannelCode())
				&& CBS_CHANNEL_SOURCE.equals(sessionContext.getChannelSource());
		String progId = "DEPS531";
		String _structureType = null;                                               // STRUCTURE_TYPE - if null, RefNoGenJpe.structureType will be used
		String _branch = bdo.getBranch();                                           // BRANCH
		String _bank = null;                                                        // BANK
		String _country = null;                                                     // COUNTRY
		String _ccy = bdo.getCcy();                                                 // CCY
		String _prodType = bdo.getAcctType();                                       // PROD_TYPE
		String _clientNo = bdo.getClientNo();                                       // CLIENT_NO
		String _basicAcctNo = null;                                                 // BASIC_ACCT_NO
		String _userId = sessionContext.getUserCode();                              // USER_ID - if null, CbsSessionContext.getUserCode will be used
		String _programId = fromSystem ? progId : null;                             // PROGRAM_ID
		String _systemPhase = getRegistryValue(CommonsConstants.ATTR_SYSTEM_PHASE); // SYSTEM_PHASE - if null, registry value will be used
		String _stringValue = null;                                                 // STRING_VALUE
		Date _runDate = dateTimeHelper.getRunDate();                                // RUN_DATE - if null, run date will be used
		String _moduleId = "DEP";                                                   // MODULE_ID
		StructureBasisTypeObject structObj = new StructureBasisTypeObject(_structureType, _branch, _bank, _country,
				_ccy, _prodType, _clientNo, _basicAcctNo, _userId, _programId, _systemPhase, _stringValue, _runDate,
				_moduleId);
		return structObj;
	}

	private String getRegistryValue(String attr) {
		String result = cbsRuntimeContextManager.getBestAvailableContext()
				.getRegistryEntry(CommonsConstants.CUT_REGISTRY, attr, String.class);
		return result;
	}

	private Acct getAcct(String acctNo) {
		if (acctNo != null) {
			Map<String, Object> params = new HashMap<String, Object>();
			params.put("acctNo", acctNo);
			List<AcctJpe> jpeList = dataService.findWithNamedQuery(DepJpeConstants.ACCT_JPE_FIND_ACCT_BY_ACCT_NO, params,
					AcctJpe.class);
			if (jpeList != null && jpeList.size() > 0) {
				return jaxbSdoHelper.wrap(jpeList.get(0), Acct.class);
			}
		}
		return null;
	}

}
