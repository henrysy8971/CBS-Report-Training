package com.silverlakesymmetri.cbs.dep.svc.impl;

import java.util.*;

import com.silverlakesymmetri.cbs.commons.exception.base.CbsServiceProcessException;
import com.silverlakesymmetri.cbs.commons.exception.base.helper.ExceptionHelper;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.*;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mysema.query.types.EntityPath;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.svc.AbstractXmlApiBusinessService;
import com.silverlakesymmetri.cbs.commons.xmlapi.enums.CbsXmlApiOperation;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.id.CiSettlementSummaryPk;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.util.DepJpeConstants;
import com.silverlakesymmetri.cbs.dep.svc.CiSettlementService;
import com.silverlakesymmetri.cbs.dep.svc.DepositsFeeService;
import com.silverlakesymmetri.cbs.dep.svc.mapper.CiSettlementBuyServiceMapper;
import com.silverlakesymmetri.cbs.dep.svc.mapper.CiSettlementSellServiceMapper;
import com.silverlakesymmetri.cbs.dep.xmlapi.DEPBASEAPIType;
import com.silverlakesymmetri.cbs.dep.xmlapi.DEPCIPROCESSSETTLEBUYAPIType;
import com.silverlakesymmetri.cbs.dep.xmlapi.DEPCIPROCESSSETTLESELLAPIType;

@Service
public class CiSettlementServiceImpl extends 
									AbstractXmlApiBusinessService<CiSettlementSummary, CiSettlementSummaryJpe, CiSettlementSummaryPk,  DEPBASEAPIType, DEPBASEAPIType>  
									implements CiSettlementService{

	private static final String ERROR_TOTALREALAMT_GREATER_TOTALPAID = "CBS.B.DEP.CI_SETTLE_SERVICE.0001";

	private boolean isSell;
	
	@Autowired
	protected CiSettlementBuyServiceMapper buyMapper;
	
	@Autowired
	protected CiSettlementSellServiceMapper sellMapper;
	
	@Autowired
	protected DepositsFeeService depositsFeeService;
	
	@Override
	protected DEPBASEAPIType transformBdoToXmlApiRqCreate(CiSettlementSummary dataObject) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	protected DEPBASEAPIType transformBdoToXmlApiRqUpdate(CiSettlementSummary dataObject) {
		// TODO Auto-generated method stub
		
		return isSell ? transformCiSettlementToDEPCIPROCESSSETTLESELLAPIType( dataObject.getCiSettlementList().get(0), CbsXmlApiOperation.UPDATE) : 
						transformCiSettlementToDEPCIPROCESSSETTLEBUYAPIType( dataObject.getCiSettlementList().get(0), CbsXmlApiOperation.UPDATE);

	}
	
	private DEPCIPROCESSSETTLEBUYAPIType transformCiSettlementToDEPCIPROCESSSETTLEBUYAPIType(CiSettlement dataObject, CbsXmlApiOperation oper){
		
		CiSettlementJpe jpe = jaxbSdoHelper.unwrap(dataObject);
		DEPCIPROCESSSETTLEBUYAPIType api =  buyMapper.mapToApi(jpe, oper, new HashMap());
		super.setTechColsFromDataObject(dataObject, api);
				
		return api;
	}
	
	private DEPCIPROCESSSETTLESELLAPIType transformCiSettlementToDEPCIPROCESSSETTLESELLAPIType(CiSettlement dataObject, CbsXmlApiOperation oper){
		
		CiSettlementJpe jpe = jaxbSdoHelper.unwrap(dataObject);
		DEPCIPROCESSSETTLESELLAPIType api =  sellMapper.mapToApi(jpe, oper, new HashMap());
		super.setTechColsFromDataObject(dataObject, api);
				
		return api;
	}

	@Override
	protected DEPBASEAPIType transformBdoToXmlApiRqDelete(CiSettlementSummary dataObject) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	protected CiSettlementSummary processXmlApiRs(CiSettlementSummary dataObject, DEPBASEAPIType xmlApiRs) {
		// TODO Auto-generated method stub
		return dataObject;
	}

	@Override
	protected List<CiSettlementSummary> processXmlApiListRs(CiSettlementSummary dataObject, DEPBASEAPIType xmlApiRs) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	protected Class getXmlApiResponseClass() {
		// TODO Auto-generated method stub
		return isSell? DEPCIPROCESSSETTLESELLAPIType.class : DEPCIPROCESSSETTLEBUYAPIType.class;
	}

	@Override
	protected CiSettlementSummaryPk getIdFromDataObjectInstance(CiSettlementSummary dataObject) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	protected EntityPath<CiSettlementSummaryJpe> getEntityPath() {
		// TODO Auto-generated method stub
		return QCiSettlementSummaryJpe.ciSettlementSummaryJpe;
	}
	
	private FeeInquiryHdr getFees(CiSettlement bdo, CiTypeJpe ciTypeJpe){
		
		FeeInquiryHdr feeHdr= jaxbSdoHelper.createSdoInstance(FeeInquiryHdr.class);
		
		feeHdr.setProdNo(bdo.getAcctNo());
		feeHdr.setAcctAmt(bdo.getAmount());
		feeHdr.setTranAmt(bdo.getAmount());
		feeHdr.setTranCcy(bdo.getCcy());
		feeHdr.setScEventType("FNTR");
		feeHdr.setTranType(ciTypeJpe.getTranTypeCollChqSettle());
		
		return depositsFeeService.feeInquiry(feeHdr);
	}
	
	private Double getFeeAmount(FeeInquiryHdr feeHdr){
		if (feeHdr == null){
			return null;
		}
		
		Double total = Double.valueOf(0);
		for (FeeInquiryDtls feeInq : feeHdr.getFeeInquiryDtlsList() ){
			total = feeInq.getScTaxAmt()+total;
		}
		return total;
	}
	
	private CiTypeJpe getCiTypeJpe(String chequeType){
		Map<String, Object> params = new HashMap<>();
		params.put("chequeType", chequeType);
		List<CiTypeJpe> result = dataService.findWithNamedQuery(DepJpeConstants.CI_TYPE_JPE_FIND_BY_CHEQUE_TYPE, params, CiTypeJpe.class);
		
		if (result == null || result.isEmpty()){
			return null;
		}
		return result.get(0);
	}
	
	@Override
	public CiSettlementSummary getByPk(String publicKey, CiSettlementSummary reference) {
		// TODO Auto-generated method stub
		CiSettlementSummary  summary = super.getByPk(publicKey, reference);
		
		CiTypeJpe ciTypeJpe = getCiTypeJpe(summary.getChequeType());
		Map<String, Object> params = new HashMap<>();
		params.put("settleRefNo", publicKey);
		List<CiSettlementJpe> result = dataService.findWithNamedQuery(DepJpeConstants.CISETTLEMENT_JPE_FIND_BY_SETTLEREFNO, params, CiSettlementJpe.class);
		
		if (result == null || result.isEmpty()){
			return summary;
		}
		List <CiSettlement> bdoList = new ArrayList<CiSettlement>();
		for (CiSettlementJpe item: result){
			
			CiSettlement bdo = jaxbSdoHelper.wrap(item, CiSettlement.class);
			
			if (bdo.getProcType().equals("COL")){
//				bdo.setRealizedAmt(bdo.getRealizedAmt()!=null ? bdo.getRealizedAmt() : 0);
				bdo.setRealizedAmt(bdo.getRealizedAmt()!=null ? bdo.getRealizedAmt() : bdo.getAmount());
				FeeInquiryHdr feeHdr =  getFees(bdo, ciTypeJpe);
				bdo.setFeeInquiryHdr(feeHdr);
				bdo.setFeeAmount(getFeeAmount(feeHdr));
			}
			else{
				bdo.setRealizedAmt(bdo.getAmount());
			}
			bdoList.add(bdo);
		}

		summary.setCiSettlementList(bdoList);
		
		return summary;
	}
	
	@Override
	public CiSettlementSummary settle(CiSettlementSummary dataObject) {
		
		if (dataObject == null){
			return dataObject;
		}
		
		isSell = "RES".equals(dataObject.getCiSettlementList().get(0).getChequeStatus());
		return super.update(dataObject);
		// TODO Auto-generated method stub
		
	}

	@Override
	public List<CiSettlementSummary> find(FindCriteria findCriteria, CbsHeader cbsHeader) {
		// TODO Auto-generated method stub
		return super.find(findCriteria, cbsHeader);
	}
	
	
	@Override
	public List<CiSettlementSummary> query(int offset, int resultLimit, String groupBy, String order,
			Map<String, Object> filters) {
		// TODO Auto-generated method stub
		return super.query(offset, resultLimit, groupBy, order, filters);
	}

	@Override
	protected CiSettlementSummary preCreateValidation(CiSettlementSummary dataObject) {
		return super.preCreateValidation(dataObject);
	}

	@Override
	public CiSettlementSummary validateExecuteRequest(CiSettlementSummary dataObject, String methodName) {
		Collection<Throwable> exceptions = new ArrayList<Throwable>();

		if (dataObject.getCiSettlementList() != null && dataObject.getCiSettlementList().size() > 0) {
			int totalRealizedAmt = 0;
			int totalPaidAmt = (int) dataObject.getTotalPaidAmount().doubleValue();
			for (CiSettlement ciDetail : dataObject.getCiSettlementList()) {
				totalRealizedAmt += (int) ciDetail.getRealizedAmt().doubleValue();
			}
			if (totalRealizedAmt > totalPaidAmt) {
				String msg = messageUtils.getMessage(ERROR_TOTALREALAMT_GREATER_TOTALPAID, new String[] { dataObject.getTotalPaidAmount().toString() });
				CbsServiceProcessException exec = new CbsServiceProcessException(ERROR_TOTALREALAMT_GREATER_TOTALPAID, msg);
				exceptions.add(exec);
			}
		}
		ExceptionHelper.createAndThrowAggregateException(exceptions);

		return super.validateExecuteRequest(dataObject, methodName);
	}
}
