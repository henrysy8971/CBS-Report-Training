package com.silverlakesymmetri.cbs.dep.svc.impl;

import java.io.IOException;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Properties;
import java.util.Set;
import java.util.TreeSet;

import javax.mail.MessagingException;
import javax.persistence.TypedQuery;

import org.apache.commons.lang3.StringUtils;
import org.apache.velocity.VelocityContext;
import org.springframework.beans.factory.ObjectFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.mysema.query.types.EntityPath;
import com.mysema.query.types.OrderSpecifier;
import com.mysema.query.types.Predicate;
import com.mysema.query.types.expr.BooleanExpression;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.bdo.sdo.DmsFile;
import com.silverlakesymmetri.cbs.commons.bdo.sdo.RefCodeHdr;
import com.silverlakesymmetri.cbs.commons.context.CbsSessionContext;
import com.silverlakesymmetri.cbs.commons.exception.CbsRuntimeException;
import com.silverlakesymmetri.cbs.commons.exception.base.CbsServiceProcessException;
import com.silverlakesymmetri.cbs.commons.helper.jpa.LinkTable;
import com.silverlakesymmetri.cbs.commons.helper.jpa.QueryCondition;
import com.silverlakesymmetri.cbs.commons.helper.jpa.QueryType;
import com.silverlakesymmetri.cbs.commons.jpa.entity.FindCriteriaJpe;
import com.silverlakesymmetri.cbs.commons.jpa.entity.SortAttributeJpe;
import com.silverlakesymmetri.cbs.commons.jpa.entity.ViewCriteriaItemJpe;
import com.silverlakesymmetri.cbs.commons.jpa.entity.ViewCriteriaJpe;
import com.silverlakesymmetri.cbs.commons.jpa.entity.ViewCriteriaRowJpe;
import com.silverlakesymmetri.cbs.commons.jpa.mapping.sdo.enums.CommunicationChannelEnum;
import com.silverlakesymmetri.cbs.commons.jpa.service.CbsEntityManagerAware;
import com.silverlakesymmetri.cbs.commons.jpa.types.StructureBasisTypeObject;
import com.silverlakesymmetri.cbs.commons.notification.CbsMessageNotificationService;
import com.silverlakesymmetri.cbs.commons.svc.AbstractXmlApiBusinessService;
import com.silverlakesymmetri.cbs.commons.svc.BusinessObjectValidationCapable;
import com.silverlakesymmetri.cbs.commons.svc.RefCodeService;
import com.silverlakesymmetri.cbs.commons.svc.ref.ReferenceNumberGeneratorService;
import com.silverlakesymmetri.cbs.commons.svc.util.CbsAsychronousTaskSupport;
import com.silverlakesymmetri.cbs.constants.CommonsConstants;
import com.silverlakesymmetri.cbs.csd.bdo.sdo.ProdScIndividual;
import com.silverlakesymmetri.cbs.csd.jpa.mapping.sdo.ContactJpe;
import com.silverlakesymmetri.cbs.csd.jpa.mapping.sdo.CostFundsRateJpe;
import com.silverlakesymmetri.cbs.csd.jpa.mapping.sdo.util.CsdJpeConstants;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.Acct;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.AcctDashboardInfoBal;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.AcctStmt;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.AcctType;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.DepFeeApply;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.JointAcct;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.ProdScMaintFee;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.AcctJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.AcctStatusJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.AcctTypeJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.ProdDefaultJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.QAcctJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.id.AcctPk;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.util.DepJpeConstants;
import com.silverlakesymmetri.cbs.dep.svc.AcctDashboardInfoBalService;
import com.silverlakesymmetri.cbs.dep.svc.AcctTypeService;
import com.silverlakesymmetri.cbs.dep.svc.DepMessageQueueAsyncGenerationService;
import com.silverlakesymmetri.cbs.dep.svc.util.AcctHelper;
import com.silverlakesymmetri.cbs.mcl.bdo.sdo.Client;
import com.silverlakesymmetri.cbs.mcl.bdo.sdo.ClientContact;
import com.silverlakesymmetri.cbs.mcl.jpa.mapping.sdo.ClientGlobalIdJpe;
import com.silverlakesymmetri.cbs.mcl.jpa.mapping.sdo.ClientJpe;
import com.silverlakesymmetri.cbs.mcl.jpa.mapping.sdo.util.MclJpeConstants;
import com.silverlakesymmetri.cbs.mcl.svc.ClientService;
import com.silverlakesymmetri.cbs.pim.jpa.mapping.sdo.MasterAccountBalanceJpe;
import com.silverlakesymmetri.cbs.pim.jpa.mapping.sdo.MasterAccountDateJpe;
import com.silverlakesymmetri.cbs.pim.jpa.mapping.sdo.MasterAccountJpe;
import com.silverlakesymmetri.cbs.xps.bdo.sdo.AdvicePreview;
import com.silverlakesymmetri.cbs.xps.bdo.sdo.DocDomainObjDefn;
import com.silverlakesymmetri.cbs.xps.enums.XpsGlobalConstants;
import com.silverlakesymmetri.cbs.xps.svc.MessageQService;
import com.silverlakesymmetri.cbs.xps.svc.util.CbsDocumentTemplateBuilder;

public abstract class AbstractAcctServiceImpl<XmlApiRq, XmlApiRs>
		extends AbstractXmlApiBusinessService<Acct, AcctJpe, AcctPk, XmlApiRq, XmlApiRs>
		implements BusinessObjectValidationCapable<Acct> {

	@Autowired
	protected MessageQService messageQueueService;

	@Autowired
	protected AcctTypeService acctTypeService;

	@Autowired
    protected CbsAsychronousTaskSupport _asynchTaskSupport;

	@Autowired
    protected ObjectFactory<DepMessageQueueAsyncGenerationService<Acct, AcctJpe, AcctPk, XmlApiRq, XmlApiRs>> msgQueueAsyncGenerationServiceObjectFactory;

	@Autowired
	protected AcctHelper acctHelper;

	private static final String IS_FROM_LOV = "isFromLOV";
	private static LinkedHashMap<String, LinkTable> constructorMap;
	private static QueryCondition condition;
	protected static final String TEMPLATE_PROPERTIES = "templates/template-config.properties";

	static {

		constructorMap = new LinkedHashMap<String, LinkTable>();
		constructorMap.put("acctNo", new LinkTable(AcctJpe.class));
		constructorMap.put("certificateNo", new LinkTable(AcctJpe.class));
		constructorMap.put("acctType", new LinkTable(AcctJpe.class));
		constructorMap.put("ibanCode", new LinkTable(AcctJpe.class));
		constructorMap.put("globalIdType", new LinkTable(ClientGlobalIdJpe.class, "globalIdType", "FROMCLIENTGLOBALID"));
		constructorMap.put("globalId", new LinkTable(ClientGlobalIdJpe.class, "globalId", "FROMCLIENTGLOBALID"));
		constructorMap.put("clientNo", new LinkTable(ClientJpe.class, "clientNo", "FROMCLIENT"));
		constructorMap.put("clientShort", new LinkTable(AcctJpe.class));
		constructorMap.put("acctDesc", new LinkTable(AcctJpe.class));
		constructorMap.put("branch", new LinkTable(AcctJpe.class));
		constructorMap.put("ccy", new LinkTable(AcctJpe.class));
		constructorMap.put("ownershipType", new LinkTable(AcctJpe.class));
		constructorMap.put("acctStatus", new LinkTable(AcctJpe.class));
		constructorMap.put("origAcctOpenDate", new LinkTable(AcctJpe.class));
		constructorMap.put("acctOpenDate", new LinkTable(AcctJpe.class));
		constructorMap.put("openTranDate", new LinkTable(AcctJpe.class));
		constructorMap.put("lastChangeDate", new LinkTable(AcctJpe.class));
		constructorMap.put("profitCentre", new LinkTable(AcctJpe.class));
		constructorMap.put("clientInd", new LinkTable(AcctJpe.class));
		constructorMap.put("docType", new LinkTable(AcctJpe.class));
		constructorMap.put("stmtPbk", new LinkTable(AcctJpe.class));
		constructorMap.put("intStmt", new LinkTable(AcctJpe.class));
		constructorMap.put("freeCheques", new LinkTable(AcctJpe.class));
		constructorMap.put("exceedRfLimit", new LinkTable(AcctJpe.class));
		constructorMap.put("depositType", new LinkTable(AcctJpe.class));
		constructorMap.put("contractType", new LinkTable(AcctTypeJpe.class, "contractType", "FROMACCTTYPE"));
		constructorMap.put("islamicIndicator", new LinkTable(AcctTypeJpe.class, "islamicIndicator", "FROMACCTTYPE"));

		condition = new QueryCondition();
		condition.where("clientId", QueryType.EQUALS, new LinkTable(ClientJpe.class, "clientId", "FROMCLIENT")).and("clientId",
				QueryType.EQUALS, new LinkTable(AcctJpe.class, "clientId"));
		condition.and("acctType", QueryType.EQUALS, new LinkTable(AcctTypeJpe.class, "acctType", "FROMACCTTYPE"));
		condition.and("clientId", QueryType.EQUALS, new LinkTable(ClientGlobalIdJpe.class, "clientId", "FROMCLIENTGLOBALID"))
				.and("defaultFlag", QueryType.EQUALS, new LinkTable(ClientGlobalIdJpe.class, "defaultFlag", "FROMCLIENTGLOBALID").addFilter("ALL"));

	}

	private static final String OWNER_CODE_OUR = "ownerCodeOur";
	private static final String MATURITY_DATE = "MaturityDate";
	private static final String PRINCIPAL = "PRINCIPAL";
	private static final String DEPOSIT = "DEPOSIT";
	private static final String CBS_CHANNEL_CODE = "CBS";
	private static final String CBS_CHANNEL_SOURCE = "HTTP-UI";
	private static final Double DEFAULT_VALUE = Double.valueOf("0");
	private static final String[] BALANCE_TYPE_ARR = new String[] { "LEDGER", "AVAILABLE", "INTEREST", PRINCIPAL,
			"PENALTY", "FEE", "FUNDSHELD", "FLOAT", "OVERDRAFT" };
	private static final String N_VALUE = "N";
	private static final String B_VALUE = "B";
	private static final String F_VALUE = "F";
	private static final Integer ZERO_VALUE = 0;
	
	protected static final String DOCUMENT_LETTER_OF_THANKS = "LetterOfThanks";
	protected static final String EMAIL_LETTER_OF_THANKS = "LetterOfThanksEmail";
	protected static final String DOCUMENT_MATURITY_NOTICE = "MaturityNotice";
	protected static final String NOTIFICATION_MATURITY_NOTICE = "MaturityNoticeEmail";
	protected static final String NOTIFICATION_INTIMATION_LETTER = "IntimationLetter";

	@Autowired
	private ReferenceNumberGeneratorService referenceNumberGeneratorService;
	
	@Autowired
	protected CbsDocumentTemplateBuilder documentTemplateBuilder;
	
	@Autowired
	protected AcctDashboardInfoBalService acctBalanceService;
	
	@Autowired
	protected ClientService clientService;
	
	@Autowired
	protected RefCodeService refCodeService;
	
	@Autowired
	protected CbsMessageNotificationService msgNotificationService;

	@Override
	protected Acct preCreateValidation(Acct dataObject) {
		AcctJpe jpe = jaxbSdoHelper.unwrap(dataObject, AcctJpe.class);
		long internalKey = dataService.nextSequenceValue("PIM_MASTER_ACCOUNT_S").longValue();
		jpe.setInternalKey(internalKey);

		defaultAcctNo(dataObject);
		defaultFields(dataObject);
		setDefaultStmtFields(dataObject);
		setDocDefaults(dataObject);
		setFeeDefaults(dataObject);
		String acctNo = dataObject.getAcctNo();

		if (dataObject.getJointAcctList() != null) {
			for (JointAcct jointAcct : dataObject.getJointAcctList()) {
				jointAcct.setAcctNo(acctNo);
			}
		}

		if (dataObject.getIntDetailRec() != null) {
			dataObject.getIntDetailRec().setAcctNo(acctNo);
		}

		if (dataObject.getAcctStmtRec() != null) {
			dataObject.getAcctStmtRec().setAcctNo(acctNo);
		}

		if (dataObject.getTdaRec() != null) {
			dataObject.getTdaRec().setAcctNo(acctNo);
		}

		if (dataObject.getProdScDefRec() != null) {
			dataObject.getProdScDefRec().setProdNo(acctNo);
		}

		if (dataObject.getProdScIndividualList() != null) {
			for (ProdScIndividual prodScIndividual : dataObject.getProdScIndividualList()) {
				prodScIndividual.setProdNo(acctNo);
			}
		}

		if (dataObject.getProdScMaintFeeList() != null) {
			for (ProdScMaintFee prodScMaintFee : dataObject.getProdScMaintFeeList()) {
				prodScMaintFee.setProdNo(acctNo);
			}
		}

		return super.preCreateValidation(dataObject);
	}

	private void defaultAcctNo(Acct acct) {
		//if (StringUtils.isBlank(acct.getAcctNo())) { //allow database procedure to validate the structured refNo value
			referenceNumberGeneratorService.getNewRefNo(acct, "acctNo", this.getStructObject(acct));
		//}
	}

	private StructureBasisTypeObject getStructObject(Acct bdo) {
		if (bdo == null) {
			return null;
		}
		CbsSessionContext sessionContext = cbsRuntimeContextManager.getContext(CbsSessionContext.class);
		boolean fromSystem = CBS_CHANNEL_CODE.equals(sessionContext.getChannelCode())
				&& CBS_CHANNEL_SOURCE.equals(sessionContext.getChannelSource());
		String progId = isTermDeposit(bdo.getAcctType()) ? "DEPS213" : "DEPS212";
		String _structureType = null;                                               // STRUCTURE_TYPE - if null, RefNoGenJpe.structureType will be used
		String _branch = bdo.getBranch();                                           // BRANCH
		String _bank = null;                                                        // BANK
		String _country = null;                                                     // COUNTRY
		String _ccy = bdo.getCcy();                                                 // CCY
		String _prodType = bdo.getAcctType();                                       // PROD_TYPE
		String _clientNo = bdo.getClientNo();                                       // CLIENT_NO
		String _basicAcctNo = null;                                                 // BASIC_ACCT_NO
		String _userId = sessionContext.getUserCode();                              // USER_ID - if null, CbsSessionContext.getUserCode will be used
		String _programId = fromSystem ? progId : null;                             // PROGRAM_ID
		String _systemPhase = getRegistryValue(CommonsConstants.ATTR_SYSTEM_PHASE); // SYSTEM_PHASE - if null, registry value will be used
		String _stringValue = null;                                                 // STRING_VALUE
		Date _runDate = dateTimeHelper.getDate(bdo.getAcctOpenDate());              // RUN_DATE - if null, run date will be used
		String _moduleId = "DEP";                                                   // MODULE_ID
		StructureBasisTypeObject structObj = new StructureBasisTypeObject(_structureType, _branch, _bank, _country,
				_ccy, _prodType, _clientNo, _basicAcctNo, _userId, _programId, _systemPhase, _stringValue, _runDate,
				_moduleId);
		return structObj;
	}

	private void setFeeDefaults(Acct acct) {
		if (acct.getDepFeeApplyList() != null) {
			for (DepFeeApply df : acct.getDepFeeApplyList()) {
				df.setAcctNo(acct.getAcctNo());
				df.setProdNo(acct.getAcctNo());
				df.setProdSubType("A");
			}
		}
	}

	private Acct setDocDefaults(Acct account) {
		List<DocDomainObjDefn> updatedDocDomainObjDefn = new ArrayList<>();
		if (account.getDocDomainObjDefnList() != null) {
			for (DocDomainObjDefn docDomainObjDefn : account.getDocDomainObjDefnList()) {
				docDomainObjDefn.setModuleRefDomain("DEP");
				docDomainObjDefn.setRefDomain("DepositAccount");
				docDomainObjDefn.setRefDomainKey(account.getAcctType());
				docDomainObjDefn.setRefObjectKey(account.getAcctNo());
				docDomainObjDefn.setRefObjectType("Acct");
				updatedDocDomainObjDefn.add(docDomainObjDefn);
			}
		}
		account.setDocDomainObjDefnList(updatedDocDomainObjDefn);
		return account;
	}

	@Override
	protected Acct preUpdateValidation(Acct dataObject) {

		String acctNo = dataObject.getAcctNo();

		if (dataObject.getJointAcctList() != null) {
			for (JointAcct jointAcct : dataObject.getJointAcctList()) {
				if (StringUtils.isBlank(jointAcct.getAcctNo())) {
					jointAcct.setAcctNo(acctNo);
				}
			}
		}

		if (dataObject.getIntDetailRec() != null) {
			if (StringUtils.isBlank(dataObject.getIntDetailRec().getAcctNo())) {
				dataObject.getIntDetailRec().setAcctNo(acctNo);
			}
		}

		if (dataObject.getAcctStmtRec() != null) {
			if (StringUtils.isBlank(dataObject.getAcctStmtRec().getAcctNo())) {
				dataObject.getAcctStmtRec().setAcctNo(acctNo);
			}
		}

		if (dataObject.getTdaRec() != null) {
			if (StringUtils.isBlank(dataObject.getTdaRec().getAcctNo())) {
				dataObject.getTdaRec().setAcctNo(acctNo);
			}
		}

		if (dataObject.getProdScDefRec() != null) {
			if (StringUtils.isBlank(dataObject.getProdScDefRec().getProdNo())) {
				dataObject.getProdScDefRec().setProdNo(acctNo);
			}
		}

		if (dataObject.getProdScIndividualList() != null) {
			for (ProdScIndividual prodScIndividual : dataObject.getProdScIndividualList()) {
				if (StringUtils.isBlank(prodScIndividual.getProdNo())) {
					prodScIndividual.setProdNo(acctNo);
				}
			}
		}

		if (dataObject.getProdScMaintFeeList() != null) {
			for (ProdScMaintFee prodScMaintFee : dataObject.getProdScMaintFeeList()) {
				if (StringUtils.isBlank(prodScMaintFee.getProdNo())) {
					prodScMaintFee.setProdNo(acctNo);
				}
			}
		}

		defaultFields(dataObject);
		setDefaultStmtFields(dataObject);
		setDocDefaults(dataObject);
		setFeeDefaults(dataObject);
		return super.preUpdateValidation(dataObject);
	}

	private void defaultFields(Acct dataObject) {
		if (dataObject.getAcctType() != null) {
			Map<String, Object> queryParams = new HashMap<String, Object>();
			queryParams.put("acctType", dataObject.getAcctType());
			List<AcctTypeJpe> list = dataService.findWithNamedQuery(DepJpeConstants.ACCT_TYPE_JPE_GET_BY_ACCT_TYPE, queryParams, AcctTypeJpe.class);
			if (list != null && list.size() > 0) {
				String depositType = list.get(0).getDepositType();
				ProdDefaultJpe prodDefaultJpe = list.get(0).getProdDefaultRec();
				if (StringUtils.isBlank(dataObject.getProfitCentre())) {
					dataObject.setProfitCentre(prodDefaultJpe == null ? null : prodDefaultJpe.getProfitCentre());
				}
				if (StringUtils.isBlank(dataObject.getOwnershipType())) {
					dataObject.setOwnershipType(prodDefaultJpe == null ? null : prodDefaultJpe.getOwnershipType());
				}
				if (dataObject.getFreeCheques() == null) {
					dataObject.setFreeCheques(prodDefaultJpe == null ? null : prodDefaultJpe.getFreeCheques());
				}
				// if (StringUtils.isBlank(dataObject.getStmtPbk())) {
				// 	dataObject.setStmtPbk(prodDefaultJpe.getStmtPbk());
				// }
				if (StringUtils.isBlank(dataObject.getDocType())) {
					dataObject.setDocType(prodDefaultJpe == null ? null : prodDefaultJpe.getDocType());
				}
				if (StringUtils.isBlank(dataObject.getExceedRfLimit())) {
					dataObject.setExceedRfLimit(prodDefaultJpe == null ? null : prodDefaultJpe.getExceedRfLimit());
				}
				if (StringUtils.isBlank(dataObject.getIslamicInd())) {
					dataObject.setIslamicInd(list.get(0).getIslamicIndicator());
				}

				//
				// CBS9D-20485 - CR_COF_APP_TYPE is not being defaulted
				// This is only a temporary solution.  Once defaulting is implemented in wrapper api, this will be removed
				//
				if (dataObject.getIntDetailRec() != null) {

					String sql = "SELECT a FROM CostFundsRateJpe a WHERE a.costFunds = :costFunds AND a.ccy = :ccy AND a.effectDate <= :acctOpenDate ORDER BY a.effectDate DESC";
					Map<String, Object> params = new HashMap<String, Object>();

					// CR_COF_APP_TYPE defaulting
					if (StringUtils.isBlank(dataObject.getIntDetailRec().getCrCofAppType())) {
						// dataObject.getIntDetailRec().setCrCofAppType(prodDefaultJpe == null ? null : prodDefaultJpe.getCrCofAppType());
					}
					if (!StringUtils.isBlank(dataObject.getIntDetailRec().getCrCofAppType())) {
						if (dataObject.getIntDetailRec().getCrCofAppType().matches("^[AR]^$")) {
							params.clear();
							params.put("costFunds", dataObject.getIntDetailRec().getCrFundType());
							params.put("ccy", dataObject.getCcy());
							params.put("acctOpenDate", dateTimeHelper.getDate(dataObject.getAcctOpenDate()));
							List<CostFundsRateJpe> jpe = dataService.findWithQuery(sql, params, 0, 10, CostFundsRateJpe.class);
							if (jpe != null && jpe.size() > 0) {
								dataObject.getIntDetailRec().setCrCofRate(jpe.get(0).getCostFundsRate());
							}
						} else {
							if ("A".equals(dataObject.getIntDetailRec().getCrCofAppType())) {
								if (StringUtils.isBlank(dataObject.getIntDetailRec().getCrFundType())) {
									dataObject.getIntDetailRec().setCrFundType(prodDefaultJpe == null ? null : prodDefaultJpe.getCrFundType());
								}
							} else {
								if (dataObject.getIntDetailRec().getCrCofRate() == null) {
									dataObject.getIntDetailRec().setCrCofRate(prodDefaultJpe == null ? null : prodDefaultJpe.getCrCofRate());
								}
							}

						}
					}

					// DR_COF_APP_TYPE defaulting
					if (!depositType.equals("T")) {
						if (StringUtils.isBlank(dataObject.getIntDetailRec().getDrCofAppType())) {
							dataObject.getIntDetailRec().setDrCofAppType(prodDefaultJpe == null ? null : prodDefaultJpe.getDrCofAppType());
						}
						if (!StringUtils.isBlank(dataObject.getIntDetailRec().getDrCofAppType())) {
							if (dataObject.getIntDetailRec().getDrCofAppType().matches("^[AR]^$")) {
								params.clear();
								params.put("costFunds", dataObject.getIntDetailRec().getDrFundType());
								params.put("ccy", dataObject.getCcy());
								params.put("acctOpenDate", dateTimeHelper.getDate(dataObject.getAcctOpenDate()));
								List<CostFundsRateJpe> jpe = dataService.findWithQuery(sql, params, 0, 10, CostFundsRateJpe.class);
								if (jpe != null && jpe.size() > 0) {
									dataObject.getIntDetailRec().setDrCofRate(jpe.get(0).getCostFundsRate());
								}
							} else {
								if ("A".equals(dataObject.getIntDetailRec().getDrCofAppType())) {
									if (StringUtils.isBlank(dataObject.getIntDetailRec().getDrFundType())) {
										dataObject.getIntDetailRec().setDrFundType(prodDefaultJpe == null ? null : prodDefaultJpe.getDrFundType());
									}
								} else {
									if (dataObject.getIntDetailRec().getDrCofRate() == null) {
										dataObject.getIntDetailRec().setDrCofRate(prodDefaultJpe == null ? null : prodDefaultJpe.getDrCofRate());
									}
								}

							}
						}

					}
				}
			}
		}
		if (dataObject.getClientNo() != null) {
			Map<String, Object> queryParams = new HashMap<String, Object>();
			queryParams.put("clientNo", dataObject.getClientNo());
			List<ClientJpe> list = dataService.findWithNamedQuery(MclJpeConstants.CLIENT_JPE_GET_CLIENT_FROM_REF_NO, queryParams, ClientJpe.class);
			if (list != null && list.size() > 0) {
				ClientJpe clientJpe = list.get(0);
				if (StringUtils.isBlank(dataObject.getAcctDesc())) {
					dataObject.setAcctDesc(clientJpe.getClientShort());
				}
				if (StringUtils.isBlank(dataObject.getClientInd())) {
					dataObject.setClientInd(clientJpe.getClientIndicator());
				}
			}
		}
		if (StringUtils.isBlank(dataObject.getIslamicInd())) {
			dataObject.setIslamicInd("N");
		}
		if (dataObject.getFreeCheques() == null) {
			dataObject.setFreeCheques(0);
		}
		if (dataObject.getToleranceAmt() == null) {
			dataObject.setToleranceAmt(0.0);
		}
//		if (dataObject.getLimitAmt() == null) {
//			dataObject.setLimitAmt(0.0);
//		}
		if (dataObject.getProdScIndividualList() != null) {
			for (ProdScIndividual prodScIndividual : dataObject.getProdScIndividualList()) {
				if (StringUtils.isBlank(prodScIndividual.getProdScIndvlRefNo())) {
					referenceNumberGeneratorService.getNewRefNo(prodScIndividual, "prodScIndvlRefNo");
				}
			}
		}
	}

	private void setDefaultStmtFields(Acct dataObject) {
		AcctStmt acctStmt = dataObject.getAcctStmtRec();
		if (acctStmt != null) {
			if (StringUtils.isBlank(acctStmt.getOnMaturityStmt())) {
				acctStmt.setOnMaturityStmt(N_VALUE);
			}
			if (StringUtils.isBlank(acctStmt.getSuppressPrint())) {
				acctStmt.setSuppressPrint(N_VALUE);
			}
			if (acctStmt.getLastStmtNo() == null) {
				acctStmt.setLastStmtNo(ZERO_VALUE);
			}
			if (StringUtils.isBlank(acctStmt.getStmtAtCap())) {
				acctStmt.setStmtAtCap(N_VALUE);
			}
			if (StringUtils.isBlank(acctStmt.getStmtAfterMovement())) {
				acctStmt.setStmtAfterMovement(N_VALUE);
			}
			if (StringUtils.isBlank(acctStmt.getStmtType())) {
				acctStmt.setStmtType(F_VALUE);
			}
			if (StringUtils.isBlank(acctStmt.getConsSc())) {
				acctStmt.setConsSc(N_VALUE);
			}
			if (acctStmt.getContactRefNo() != null) {
				Map<String, Object> queryParams = new HashMap<String, Object>();
				queryParams.put("contactRefNo", acctStmt.getContactRefNo());
				List<ContactJpe> list = dataService.findWithNamedQuery(CsdJpeConstants.CONTACT_JPE_GET_BY_CONTACT_REF_NO, queryParams, ContactJpe.class);
				if (list != null && list.size() > 0) {
					acctStmt.setDistrChannel(list.get(0).getContactType());
				}
			}
			dataObject.setAcctStmtRec(acctStmt);
		}
	}

	@Override
	public Acct create(Acct dataObject) {
		return super.create(dataObject);
	}

	@Override
	public Acct update(Acct dataObject) {
		return super.update(dataObject);
	}

	@Override
	public boolean delete(Acct dataObject) {
		return super.delete(dataObject);
	}

	@Override
	public List<Acct> query(int offset, int resultLimit, String groupBy, String order, Map<String, Object> filters) {
		List<Acct> resultList = new ArrayList<>();
		if (filters.containsKey(IS_FROM_LOV)) {
			filters.remove(IS_FROM_LOV);
			resultList = getAllAcctThin(offset, resultLimit, groupBy, order, filters);
		} else {
			Boolean isCasa = null;
			if (filters != null && filters.get("isCasa") != null) {
				isCasa = Boolean.parseBoolean(filters.get("isCasa").toString());
				filters.remove("isCasa");
			}
            QueryCondition newCondition = convertFilters(condition, filters, constructorMap);
			if (isCasa != null) {
				resultList = customQuery(offset, resultLimit, groupBy, order, filters, isCasa);
			} else {
				resultList = super.query(newCondition, offset, resultLimit, groupBy, order, constructorMap);
			}
		}
//		if (resultList != null) {
//			for (Acct acct : resultList) {
//				this.setGlobalIdInfo(acct);
//			}
//		}
		return resultList;
	}

	private List<Acct> customQuery(int offset, int resultLimit, String groupBy, String order, Map<String, Object> filters,
			boolean isCasa) {
//		final List<OrderSpecifier<?>> orders = getOrderSpecifier(QAcctJpe.acctJpe, null, order);
//		Predicate predicate = convertMapToPredicate(filters, isCasa);
//		return super.query(QAcctJpe.acctJpe, offset, resultLimit, predicate, orders);
		this.convertFilterToCondition(filters, isCasa);
        QueryCondition newCondition = convertFilters(condition, filters, constructorMap);
		return super.query(newCondition, offset, resultLimit, groupBy, order, constructorMap);
	}

//	private Predicate convertMapToPredicate(Map<String, Object> filters, boolean isCasa) {
//		Predicate predicate = convertMapToPredicate(QAcctJpe.acctJpe, filters);
//		BooleanExpression booleanExpr = null;
//		if (isCasa) {
//			booleanExpr = QAcctJpe.acctJpe.depositType.in(Arrays.asList("S", "C"));
//		} else {
//			booleanExpr = QAcctJpe.acctJpe.depositType.eq("T");
//		}
//		if (predicate != null) {
//			predicate = ((BooleanExpression) predicate).and(booleanExpr);
//		} else {
//			predicate = booleanExpr;
//		}
//		return predicate;
//	}
	
	private void convertFilterToCondition(Map<String, Object> filters, boolean isCasa) {
		if (isCasa) {
			condition.and("depositType", QueryType.IN_STRING, new ArrayList<String>(){{add("S"); add("C");}});
		} else {
			condition.and("depositType", QueryType.EQUALS, "T");
		}
	}

	@Override
	public List<Acct> find(FindCriteria findCriteria, CbsHeader cbsHeader) {
		FindCriteriaJpe fcJpe = updateFCForCasaOrTD(findCriteria);
		if(fcJpe.getSortOrder() != null){
			boolean sortedByAcctNo = false;
			if(fcJpe.getSortOrder().getSortAttribute() != null && fcJpe.getSortOrder().getSortAttribute().size() > 0){
				for(SortAttributeJpe sortAttr : fcJpe.getSortOrder().getSortAttribute()) {
					if(sortAttr.getName() != null && sortAttr.getName().equals("acctNo")){
						sortedByAcctNo = true;
						break;
					}
				}
				if(!sortedByAcctNo){
					SortAttributeJpe acctNoSortAttr = new SortAttributeJpe();
					acctNoSortAttr.setName("acctNo");
					acctNoSortAttr.setDescendingYn(false);
					fcJpe.getSortOrder().getSortAttribute().add(acctNoSortAttr);
				}
			}
		}
		FindCriteria fcBdo = jaxbSdoHelper.wrap(fcJpe, FindCriteria.class);
		List<Acct> list = super.find(fcBdo, cbsHeader, constructorMap, condition);
//		if (list != null) {
//			for(Acct acct : list) {
//				this.setGlobalIdInfo(acct);
//			}
//		}
		return list;
	}

	@Override
	public Acct getByPk(String publicKey, Acct reference) {
		Acct acct = super.getByPk(publicKey, reference);
		this.setGlobalIdInfo(acct);
		return acct;
	}

	public Long count(FindCriteria findCriteria, CbsHeader cbsHeader) {
		FindCriteriaJpe fcJpe = updateFCForCasaOrTD(findCriteria);
		return dataService.getRowCount(AcctJpe.class, fcJpe, constructorMap, condition);
	}

	private FindCriteriaJpe updateFCForCasaOrTD(FindCriteria findCriteria) {
		FindCriteriaJpe fc = null;
		if (findCriteria == null) {
			fc = new FindCriteriaJpe();
			ViewCriteriaJpe rootViewCriteria = new ViewCriteriaJpe();
			fc.setFilter(rootViewCriteria);
		} else {
			fc = jaxbSdoHelper.unwrap(findCriteria, true);
		}
		if (fc != null) {
			List<ViewCriteriaRowJpe> rowList = fc.getFilter().getGroup();
			for (ViewCriteriaRowJpe row : rowList) {
				List<ViewCriteriaItemJpe> itemList = row.getItem();

				for (int i = itemList.size() - 1; i >= 0; i--) {
					ViewCriteriaItemJpe vci = itemList.get(i);
					if ("isCasa".equals(vci.getAttribute()) && vci.getValue().get(0) != null) {
						boolean isCasa = Boolean.parseBoolean(vci.getValue().get(0).toString());
						List<Object> depTypeList = new ArrayList<Object>();
						if (isCasa) {
							depTypeList.addAll(Arrays.asList("S", "C"));
						} else {
							depTypeList.addAll(Arrays.asList("T"));
						}

						vci.setAttribute("depositType");
						vci.setOperator("IN");
						vci.setValue(depTypeList);
						break;
					}
				}
			}
		}
		return fc;
	}

	@Override
	protected AcctPk getIdFromDataObjectInstance(Acct dataObject) {
		Map<String, Object> params = new HashMap<String, Object>();
		params.put("acctNo", dataObject.getAcctNo());
		Long result = dataService.getWithNamedQuery(DepJpeConstants.ACCT_JPE_FIND_INTERNAL_KEY_BY_ACCT_NO, params,
				Long.class);
		return new AcctPk(result);
	}

	@Override
	protected EntityPath<AcctJpe> getEntityPath() {
		return QAcctJpe.acctJpe;
	}

	abstract protected Class<XmlApiRs> getXmlApiResponseClass();

	protected void createMasterAccount(AcctJpe acct, boolean isCasa) {
		MasterAccountJpe masterAccountJpe = new MasterAccountJpe();
		masterAccountJpe.setAccountId(acct.getInternalKey());
		masterAccountJpe.setAccountNo(acct.getAcctNo());
		masterAccountJpe.setCcy(acct.getCcy());
		masterAccountJpe.setDomain(DEPOSIT);

		String ownerCodeOur = getRegistryValue(OWNER_CODE_OUR);
		if (ownerCodeOur == null) {
			ownerCodeOur = CBS_CHANNEL_CODE;
		}

		masterAccountJpe.setDataOwnerCode(ownerCodeOur);
		masterAccountJpe.setProductCode(acct.getAcctType());
		masterAccountJpe.setClientNoOwner(acct.getClientNo());
		masterAccountJpe.setBranch(acct.getBranch());
		masterAccountJpe.setAccountDesc(acct.getAcctDesc());
		masterAccountJpe.setRegisteredDt(acct.getAcctOpenDate());
		masterAccountJpe.setLastRefreshDt(acct.getAcctOpenDate());
		masterAccountJpe.setActiveYn(true);
		masterAccountJpe.setStartDt(acct.getAcctOpenDate());
		masterAccountJpe.setProfitCentre(acct.getProfitCentre());

		for (String balanceType : BALANCE_TYPE_ARR) {

			if (isCasa) {
				if (PRINCIPAL.equals(balanceType)) {
					continue;
				}
			}

			MasterAccountBalanceJpe masterAccountBalanceJpe = new MasterAccountBalanceJpe();
			masterAccountBalanceJpe.setBalanceType(balanceType);
			masterAccountBalanceJpe.setLastBalChangedDt(acct.getCreatedDt());
			masterAccountBalanceJpe.setBalanceAmt(DEFAULT_VALUE);
			if (PRINCIPAL.equals(balanceType)) {
				masterAccountBalanceJpe.setBalanceAmt(acct.getTdaRec().getPrincipalAmt());
			}

			masterAccountJpe.getMasterAccountBalanceList().add(masterAccountBalanceJpe);

		}

		if (!isCasa) {
			MasterAccountDateJpe masterAccountDateJpe = new MasterAccountDateJpe();
			masterAccountDateJpe.setDateType(MATURITY_DATE);
			masterAccountDateJpe.setDateTypeValueDt(acct.getTdaRec().getMaturityDate());
			masterAccountJpe.getMasterAccountDateList().add(masterAccountDateJpe);
		}

		dataService.create(masterAccountJpe);
	}

	/**
	 * Performs query for <i>attr</i> to CUT Registry via application context
	 * which will be loaded on application startup.
	 * 
	 * @return String
	 */
	private String getRegistryValue(String attr) {
		String result = cbsRuntimeContextManager.getBestAvailableContext()
				.getRegistryEntry(CommonsConstants.CUT_REGISTRY, attr, String.class);
		return result;
	}

	public void generateMessageQueue(Acct bdo) {
		Map<String, Object> params = new HashMap<String, Object>();
		VelocityContext context = new VelocityContext();
		
		//fill context with all related BDOs for this document
		context.put("Acct", bdo);
		context.put("Tda", bdo.getTdaRec());
		context.put("IntDetail", bdo.getIntDetailRec());
		
		Client client = clientService.getByPk(bdo.getClientNo(), null);
		context.put("Client", client);
		ClientContact contact = clientService.getClientContactFromType(client.getClientNo(), "POSTAL", null);
		context.put("ClientContact", contact);
		
		CbsSessionContext currentSessionCtx = cbsRuntimeContextManager.getContext(CbsSessionContext.class);
		AcctDashboardInfoBal infoBal = acctBalanceService.getByPk(bdo.getAcctNo(), null);
		context.put("AcctDashboardInfoBal", infoBal);
		context.put("sessionCtx", currentSessionCtx);
		params.put("context", context);
		params.put("sessionCtx", currentSessionCtx);

		DepMessageQueueAsyncGenerationService<Acct, AcctJpe, AcctPk, XmlApiRq, XmlApiRs> asyncService = msgQueueAsyncGenerationServiceObjectFactory.getObject();
		asyncService.initialize(this, bdo, params);
		_asynchTaskSupport.executeNoWait(asyncService);
	}

	public void asyncGenerateMessageQueue(Acct bdo, Map<String, Object> params) {
		DmsFile document = null;
		boolean useEmailRoute = false;
		boolean useQrCode = true;
		
		Properties config = readTemplateConfigFile(TEMPLATE_PROPERTIES);
		if(config != null && config.get("useEmailRouteForLetterOfThanks") != null){
			useEmailRoute = Boolean.parseBoolean(config.getProperty("useEmailRouteForLetterOfThanks"));
		}
		if(config != null && config.get("attachLetterOfThanksQrCode") != null){
			useQrCode = Boolean.parseBoolean(config.getProperty("attachLetterOfThanksQrCode"));
		}
		
		AcctJpe jpe = jaxbSdoHelper.unwrap(bdo);
		
		if(useEmailRoute){
			//sendLetterOfThanks(bdo, bdo.getAcctNo(), null, false, params);
		} else {
			if(params != null && params.get("context") != null){
				VelocityContext context = (VelocityContext) params.get("context");
				boolean islamicDocument = isAcctIslamic(bdo.getAcctType());
				document = documentTemplateBuilder.convertTemplateToDocument(DOCUMENT_LETTER_OF_THANKS, context, null, islamicDocument, bdo.getAcctNo(), useQrCode);
			} else {
				document = generateLetterOfThanks(bdo.getAcctNo(), null);
			}

			String destinationAddress = "";
			if(bdo.getClientNo() != null){
				ClientContact contact = clientService.getClientContactFromType(bdo.getClientNo(), XpsGlobalConstants.POSTAL_ROUTE, null);
				if(contact != null){
					destinationAddress = contact.getContactDetail().replaceAll("<br/>", ", ");
				}
			}
			CbsSessionContext sessionCtx = (CbsSessionContext) params.get("sessionCtx");
			//TODO: use message keys instead of hard coded event type
			//TODO: pass sourceType based on how the implementing module derives it
			messageQueueService.createMessageQueueEntry(null, document, "DEP", jpe.getInternalKey(), bdo.getAcctNo(), "ACOP", bdo.getAcctOpenDate(), 
					XpsGlobalConstants.POSTAL_ROUTE, bdo.getBranch(), null, 1L, destinationAddress, null, sessionCtx);						
		}
	}
	
	public AdvicePreview sendLetterOfThanks(Acct bdo, String publicKey, String locale, boolean isPreview, Map<String, Object> params) {
		VelocityContext context = new VelocityContext();
		
		if(locale == null){
			Locale local = Locale.getDefault();
			locale = local.getLanguage()+"-"+local.getCountry();
		}
		
		Properties config = readTemplateConfigFile(TEMPLATE_PROPERTIES);

		ClientJpe clientJpe = null;
		if(params != null && params.get("context") != null){
			context = (VelocityContext) params.get("context");
			if(context.get("Client") != null){
				clientJpe = jaxbSdoHelper.unwrap((Client) context.get("Client"));				
			} else {
				Client client = clientService.getByPk(bdo.getClientNo(), null);
				clientJpe = jaxbSdoHelper.unwrap(client);
			}
		} else {
			//fill context with all related BDOs for this document
			context.put("Acct", bdo);
			context.put("Tda", bdo.getTdaRec());
			context.put("IntDetail", bdo.getIntDetailRec());

			Map<String, Object> parameters = new HashMap<String, Object>();
			parameters.put("clientNo", bdo.getClientNo());
			clientJpe = dataService.getWithNamedQuery(MclJpeConstants.CLIENT_JPE_GET_CLIENT_FROM_CLIENT_NO, parameters, ClientJpe.class);
			context.put("Client", jaxbSdoHelper.wrap(clientJpe));			
			ClientContact contact = clientService.getClientContactFromType(clientJpe.getClientNo(), "POSTAL", null);
			context.put("ClientContact", contact);
		}

		//call template builder
		List<DmsFile> attachments = new ArrayList<DmsFile>();
		boolean islamicDocument = isAcctIslamic(bdo.getAcctType());
		Map<String, String> messageContext = documentTemplateBuilder.convertTemplateToMessage(EMAIL_LETTER_OF_THANKS, context, locale, islamicDocument);
		DmsFile attachment = documentTemplateBuilder.convertTemplateToDocument(DOCUMENT_LETTER_OF_THANKS, context, locale, islamicDocument, publicKey, false);
		attachments.add(attachment);

		String mailAddress = clientService.getClientElectronicMailAddress(clientJpe.getClientNo());
		String emailSubject = messageContext.get("subject");
		if(config != null && config.getProperty("letterOfThanksEmailSubject") != null){
			emailSubject = config.getProperty("letterOfThanksEmailSubject");	
		}

		AdvicePreview mailPreview = jaxbSdoHelper.createSdoInstance(AdvicePreview.class);
		mailPreview.setRecipients(mailAddress);
		mailPreview.setMsgBody(messageContext.get("message"));
		mailPreview.setSubject(emailSubject);
		mailPreview.setDocument(DOCUMENT_LETTER_OF_THANKS);
		mailPreview.setAttachments(attachments);			

		if(isPreview){
			return mailPreview;
		}

		try {
			msgNotificationService.sendNotificationMessage(CommunicationChannelEnum.MAIL, mailAddress, emailSubject, messageContext.get("message"), null, attachments);
			if(config.get("sendDepositConfirmationSms") != null && Boolean.parseBoolean(config.getProperty("sendDepositConfirmationSms"))){
				String phoneContact = getClientPhoneContact(clientJpe.getClientNo());
				if(phoneContact != null){
					Map<String, Object> templateParams = convertContextToMap(context);
					String smsMsg = msgNotificationService.getNotificationService().evaluateTemplate(config.get("depositConfirmationSms").toString(), templateParams);
					msgNotificationService.sendNotificationMessage(CommunicationChannelEnum.SMS, phoneContact, null, smsMsg, null, null);
				}
			}
		} catch (MessagingException e) {
			msgNotificationService.logFailedNotification(DOCUMENT_LETTER_OF_THANKS+"-"+publicKey, CommunicationChannelEnum.MAIL, mailAddress, emailSubject, messageContext.get("message"), attachments);
			return null;
		} catch (Exception e) {
			
		}
		return mailPreview;
	}


	public DmsFile generateLetterOfThanks(String acctNo, String locale) {
		VelocityContext context = new VelocityContext();
		boolean useQrCode = true;
		Properties config = readTemplateConfigFile(TEMPLATE_PROPERTIES);
		if(config != null && config.get("attachLetterOfThanksQrCode") != null){
			useQrCode = Boolean.parseBoolean(config.getProperty("attachLetterOfThanksQrCode"));
		}

		//fill context with all related BDOs for this document
		Map<String, Object> parameters = new HashMap<String, Object>();
		parameters.put("acctNo", acctNo);
		AcctJpe jpe = dataService.getWithNamedQuery(com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.util.DepJpeConstants.ACCT_JPE_FIND_BY_ACCTNO, parameters, AcctJpe.class);
		Acct bdo = jaxbSdoHelper.wrap(jpe);
		context.put("Acct", bdo);
		context.put("Tda", bdo.getTdaRec());
		context.put("IntDetail", bdo.getIntDetailRec());

		Client client = clientService.getByPk(bdo.getClientNo(), null);
		context.put("Client", client);
		ClientContact contact = clientService.getClientContactFromType(client.getClientNo(), "POSTAL", null);
		context.put("ClientContact", contact);

		AcctDashboardInfoBal infoBal = acctBalanceService.getByPk(acctNo, null);
		context.put("AcctDashboardInfoBal", infoBal);
		
		//call template builder
		boolean islamicDocument = isAcctIslamic(bdo.getAcctType());
		return documentTemplateBuilder.convertTemplateToDocument(DOCUMENT_LETTER_OF_THANKS, context, locale, islamicDocument, acctNo, useQrCode);
	}
	
	public AdvicePreview sendIntimationLetter(String acctNo, String locale, boolean isPreview) {
		VelocityContext context = new VelocityContext();

		//fill context with all related BDOs for this document
		Map<String, Object> parameters = new HashMap<String, Object>();
		parameters.put("acctNo", acctNo);
		AcctJpe jpe = dataService.getWithNamedQuery(DepJpeConstants.ACCT_JPE_FIND_BY_ACCTNO, parameters, AcctJpe.class);
		Acct bdo = jaxbSdoHelper.wrap(jpe);
		context.put("Acct", bdo);

		parameters.clear();
		parameters.put("acctType", bdo.getAcctType());
		AcctTypeJpe acctTypeJpe = dataService.getWithNamedQuery(DepJpeConstants.ACCT_TYPE_JPE_GET_BY_ACCT_TYPE,
				parameters, AcctTypeJpe.class);
		if (acctTypeJpe != null && acctTypeJpe.getAcctStatusList() != null) {
			for (AcctStatusJpe acctStatusJpe : acctTypeJpe.getAcctStatusList()) {
				if (acctStatusJpe.getAcctStatus().equals(jpe.getAcctStatus())) {
					context.put("AcctStatus", jaxbSdoHelper.wrap(acctStatusJpe));
					break;
				}
			}
		}

		RefCodeHdr refCode = refCodeService.find("RB_ACCT_STATUS.ACCT_STATUS", "acctStatus", bdo.getAcctStatus());
		context.put("RefCodeHdr", refCode);

		//call template builder
		boolean islamicDocument = isAcctIslamic(bdo.getAcctType());
		Map<String, String> messageContext = documentTemplateBuilder
				.convertTemplateToMessage(NOTIFICATION_INTIMATION_LETTER, context, locale, islamicDocument);

		String mailAddress = clientService.getClientElectronicMailAddress(bdo.getClientNo());

		//create preview
		AdvicePreview mailPreview = jaxbSdoHelper.createSdoInstance(AdvicePreview.class);
		mailPreview.setRecipients(mailAddress);
		mailPreview.setMsgBody(messageContext.get("message"));
		switch (bdo.getAcctStatus()) {
			case "A": mailPreview.setSubject("Account Reactivation"); break;
			//case "D": mailPreview.setSubject("Account Status to Dormant"); break;
			//case "I": mailPreview.setSubject("Account Status to Inactive"); break;
			//case "E": mailPreview.setSubject("Account Status to Escheated"); break;
			default: mailPreview.setSubject("Account Status Update");
		}

		if (isPreview) {
			return mailPreview;
		}

		try {
			msgNotificationService.sendNotificationMessage(CommunicationChannelEnum.MAIL, mailAddress,
					messageContext.get("subject"), messageContext.get("message"), null, null);
		} catch (MessagingException e) {
			msgNotificationService.logFailedNotification("IntimationLetter-" + acctNo + "-" + bdo.getAcctStatus(),
					CommunicationChannelEnum.MAIL, mailAddress, messageContext.get("subject"),
					messageContext.get("message"), null);
			return null;
		}
		return mailPreview;
	}

	private List<Acct> getAllAcctThin(int offset, int resultLimit, String groupBy, String order,
			Map<String, Object> filters) {

		if (offset < 0)
			offset = 0;
		if (resultLimit < 0 || resultLimit > 50)
			resultLimit = 50;

		if (StringUtils.isBlank(groupBy)) {
			groupBy = "acctNo";
		} else {
			try {
				AcctJpe.class.getDeclaredField(groupBy);
			} catch (NoSuchFieldException e) {
				e.printStackTrace();
				groupBy = null;
			} catch (SecurityException e) {
				e.printStackTrace();
				groupBy = null;
			}
		}

		final List<Acct> sdoResult = new ArrayList<Acct>();

		Boolean isCasa = null;
		if (filters != null && filters.get("isCasa") != null) {
			isCasa = Boolean.parseBoolean(filters.get("isCasa").toString());
			filters.remove("isCasa");
		}

		StringBuilder queryString = new StringBuilder();
		queryString.append(" SELECT NEW com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.AcctJpe ")
				.append(" ( a.acctNo, a.certificateNo, a.acctType, a.ibanCode, g.globalIdType, g.globalId ")
				.append(" , c.clientNo, a.clientShort, a.acctDesc, a.branch, a.ccy, a.ownershipType ")
				.append(" , a.acctStatus, a.origAcctOpenDate, a.acctOpenDate, a.openTranDate ")
				.append(" , a.lastChangeDate, a.profitCentre, a.clientInd, a.docType, a.stmtPbk ")
				.append(" , a.intStmt, a.freeCheques, a.exceedRfLimit, a.depositType, t.contractType, t.islamicIndicator ) ")
				.append(" FROM AcctJpe a, ClientJpe c, AcctTypeJpe t, ClientGlobalIdJpe g ").append(" WHERE a.clientId = c.clientId ")
				.append(" AND a.acctType = t.acctType AND a.clientId = g.clientId ");

		if (isCasa != null) {
			if (isCasa) {
				queryString.append(" AND a.depositType IN ('S','C') ");
			} else {
				queryString.append(" AND a.depositType = 'T' ");
			}
		}

		if (filters != null && !filters.isEmpty()) {
			for (Map.Entry<String, Object> entry : filters.entrySet()) {
				if ("excludeAcctStatusList".equals(entry.getKey())) {
					String excludeAcctStatusStr = (String) entry.getValue();
					if (!StringUtils.isEmpty(excludeAcctStatusStr)) {
						List<String> list = new ArrayList<String>(Arrays.asList(excludeAcctStatusStr.split(",")));
						StringBuilder b = new StringBuilder();
						int index = 0;
						for (String acctStatus : list) {
							b.append(index > 0 ? "," : "").append("'").append(acctStatus).append("'");
							index++;
						}
						queryString.append(" AND a.acctStatus NOT IN (").append(b).append(") ");
					}
				} else if ("includeAcctStatusList".equals(entry.getKey())) {
					String includeAcctStatusStr = (String) entry.getValue();
					if (!StringUtils.isEmpty(includeAcctStatusStr)) {
						List<String> list = new ArrayList<String>(Arrays.asList(includeAcctStatusStr.split(",")));
						StringBuilder b = new StringBuilder();
						int index = 0;
						for (String acctStatus : list) {
							b.append(index > 0 ? "," : "").append("'").append(acctStatus).append("'");
							index++;
						}
						queryString.append(" AND a.acctStatus IN (").append(b).append(") ");
					}
				} else if ("excludeAcctNoList".equals(entry.getKey())) {
					String excludeAcctNoStr = (String) entry.getValue();
					if (!StringUtils.isEmpty(excludeAcctNoStr)) {
						List<String> list = new ArrayList<String>(Arrays.asList(excludeAcctNoStr.split(",")));
						StringBuilder b = new StringBuilder();
						int index = 0;
						for (String acctNo : list) {
							b.append(index > 0 ? "," : "").append("'").append(acctNo).append("'");
							index++;
						}
						queryString.append(" AND a.acctNo NOT IN (").append(b).append(") ");
					}
				} else if ("includeAcctNoList".equals(entry.getKey())) {
					String includeAcctNoStr = (String) entry.getValue();
					if (!StringUtils.isEmpty(includeAcctNoStr)) {
						List<String> list = new ArrayList<String>(Arrays.asList(includeAcctNoStr.split(",")));
						StringBuilder b = new StringBuilder();
						int index = 0;
						for (String acctNo : list) {
							b.append(index > 0 ? "," : "").append("'").append(acctNo).append("'");
							index++;
						}
						queryString.append(" AND a.acctNo IN (").append(b).append(") ");
					}
				} else if ("excludeClientNoList".equals(entry.getKey())) {
					String excludeClientNoStr = (String) entry.getValue();
					if (!StringUtils.isEmpty(excludeClientNoStr)) {
						List<String> list = new ArrayList<String>(Arrays.asList(excludeClientNoStr.split(",")));
						StringBuilder b = new StringBuilder();
						int index = 0;
						for (String clientNo : list) {
							b.append(index > 0 ? "," : "").append("'").append(clientNo).append("'");
							index++;
						}
						queryString.append(" AND c.clientNo NOT IN (").append(b).append(") ");
					}
				} else if ("includeClientNoList".equals(entry.getKey())) {
					String includeClientNoStr = (String) entry.getValue();
					if (!StringUtils.isEmpty(includeClientNoStr)) {
						List<String> list = new ArrayList<String>(Arrays.asList(includeClientNoStr.split(",")));
						StringBuilder b = new StringBuilder();
						int index = 0;
						for (String clientNo : list) {
							b.append(index > 0 ? "," : "").append("'").append(clientNo).append("'");
							index++;
						}
						queryString.append(" AND c.clientNo IN (").append(b).append(") ");
					}
				} else if ("clientNo".equals(entry.getKey())) {
					queryString.append(" AND UPPER(c.").append(entry.getKey()).append(") LIKE UPPER(:")
							.append(entry.getKey()).append(") ");
				} else if ("acctNo".equals(entry.getKey()) || "acctDesc".equals(entry.getKey())
						|| "certificateNo".equals(entry.getKey()) || "branch".equals(entry.getKey())) {
					queryString.append(" AND UPPER(a.").append(entry.getKey()).append(") LIKE UPPER(:")
							.append(entry.getKey()).append(") ");
				} else {
					queryString.append(" AND a.").append(entry.getKey()).append("=:").append(entry.getKey())
							.append(" ");
				}
			}
		}

		if (filters.containsKey("excludeAcctStatusList")) {
			filters.remove("excludeAcctStatusList");
		}
		if (filters.containsKey("includeAcctStatusList")) {
			filters.remove("includeAcctStatusList");
		}
		if (filters.containsKey("excludeAcctNoList")) {
			filters.remove("excludeAcctNoList");
		}
		if (filters.containsKey("includeAcctNoList")) {
			filters.remove("includeAcctNoList");
		}
		if (filters.containsKey("excludeClientNoList")) {
			filters.remove("excludeClientNoList");
		}
		if (filters.containsKey("includeClientNoList")) {
			filters.remove("includeClientNoList");
		}

		String q = (groupBy == null || groupBy.isEmpty()) ? queryString.toString()
				: appendOrderByToQuery(queryString.toString(), "a", groupBy, order);

		TypedQuery<AcctJpe> query = ((CbsEntityManagerAware) dataService).getMyEntityManager().createQuery(q,
				AcctJpe.class);

		if (filters != null) {
			for (Map.Entry<String, Object> entry : filters.entrySet()) {
				String fieldName = entry.getKey();
				try {
					Field field = AcctJpe.class.getDeclaredField(fieldName);
					Class<?> fieldClass = field.getType();
					if (Boolean.class.equals(fieldClass)) {
						query.setParameter(entry.getKey(), Boolean.valueOf((String) entry.getValue()));
					} else {
						query.setParameter(entry.getKey(), entry.getValue());
					}
				} catch (NoSuchFieldException e) {
					e.printStackTrace();
				} catch (SecurityException e) {
					e.printStackTrace();
				}
			}
		}

		query.setFirstResult(offset);
		query.setMaxResults(resultLimit);

		final List<AcctJpe> jpeResult = query.getResultList();

		// do sorting and filtering here
		if (jpeResult != null) {
			for (AcctJpe jpe : jpeResult) {
				Acct sdo = jaxbSdoHelper.wrap(jpe, Acct.class);
				sdoResult.add(sdo);
			}
		}

		return sdoResult;

	}

	protected boolean isAcctIslamic(String acctType) {
		AcctType acctTypeBdo = acctTypeService.getByPk(acctType, null);
		if (acctTypeBdo != null && acctTypeBdo.getIslamicIndicator() != null) {
			return acctTypeBdo.getIslamicIndicator().equals("Y");
		}
		return false;
	}

	protected boolean isTermDeposit(String acctType) {
		AcctType acctTypeBdo = acctTypeService.getByPk(acctType, null);
		if (acctTypeBdo != null && acctTypeBdo.getDepositType() != null) {
			return acctTypeBdo.getDepositType().equals("T");
		}
		return false;
	}

	private void setGlobalIdInfo(Acct acct) {
		if (acct != null && acct.getClientNo() != null) {
			Long clientId = acctHelper.getClientIdByClientNo(acct.getClientNo());
			Map<String, Object> queryParams = new HashMap<String, Object>();
			queryParams.put("clientId", clientId);
			List<ClientGlobalIdJpe> list = dataService.findWithNamedQuery(
					MclJpeConstants.CLIENT_GLOBAL_ID_FIND_BY_CLIENT_ID, queryParams, ClientGlobalIdJpe.class);
			if (list != null && !list.isEmpty()) {
				for (ClientGlobalIdJpe globalId : list) {
					if ("ALL".equals(globalId.getDefaultFlag())) {
						acct.setGlobalId(globalId.getGlobalId());
						acct.setGlobalIdType(globalId.getGlobalIdType());
						break;
					}
				}
			}
		}
	}
	
    protected Properties readTemplateConfigFile(String configFile){
        try {
        	Properties properties = new Properties() {
				private static final long serialVersionUID = 1L;
				@Override
				public Set<Object> keySet() {
				    return Collections.unmodifiableSet(new TreeSet<Object>(super.keySet()));
				}
        	};
			properties.load(this.getClass().getClassLoader().getResourceAsStream(configFile));
			return properties;
		} catch (IOException e) {
			throw new CbsRuntimeException("Unable to read configuration file: " + configFile);
		}
		
	}
    
    protected Map<String, Object> convertContextToMap(VelocityContext context){
    	Map<String, Object> map = new HashMap<String, Object>();
    	for(String key : context.getKeys()){
    		map.put(key,  context.get(key));
    	}
    	return map;
    }

    protected String getClientPhoneContact(String clientNo){
    	try {
			ClientContact contact = clientService.getClientContactFromType(clientNo, "PHONE", null);
			if(contact != null){
				return contact.getContactDetail();
			}
		} catch (CbsServiceProcessException e) {}
    	return null;
    }


}
