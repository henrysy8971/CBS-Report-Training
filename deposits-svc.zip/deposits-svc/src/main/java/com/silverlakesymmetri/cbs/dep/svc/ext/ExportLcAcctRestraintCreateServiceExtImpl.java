package com.silverlakesymmetri.cbs.dep.svc.ext;

import org.springframework.stereotype.Service;

import com.silverlakesymmetri.cbs.commons.logging.CbsAppLogger;
import com.silverlakesymmetri.cbs.commons.logging.CbsAppLoggerFactory;
import com.silverlakesymmetri.cbs.xps.svc.util.ReleaseAcctRestraintCapable;

@Service
public class ExportLcAcctRestraintCreateServiceExtImpl extends AbstractTfnAcctRestraintServiceExtImpl implements ReleaseAcctRestraintCapable {

	private static CbsAppLogger logger = CbsAppLoggerFactory.getLogger(ExportLcAcctRestraintCreateServiceExtImpl.class.getName());
	
    @Override
    public String[] getExtendedBdoNames() {
        return new String[] { "ExportLc" };
    }

    @Override
    public String[] getExtendedServiceNames() {
        return new String[] {"ExportLcService.create"};
    }

    protected CbsAppLogger getLogger() {
    	return logger;
    }
}
