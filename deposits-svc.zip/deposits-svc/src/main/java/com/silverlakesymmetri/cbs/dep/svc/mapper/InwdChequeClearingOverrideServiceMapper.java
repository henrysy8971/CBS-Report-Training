package com.silverlakesymmetri.cbs.dep.svc.mapper;

import java.util.Map;

import org.mapstruct.Context;
import org.mapstruct.DecoratedWith;
import org.mapstruct.InheritConfiguration;
import org.mapstruct.InheritInverseConfiguration;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingTarget;
import org.mapstruct.Mappings;

import com.silverlakesymmetri.cbs.commons.jpa.util.DateTimeHelper;
import com.silverlakesymmetri.cbs.commons.xmlapi.enums.CbsXmlApiOperation;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.InwdChequeHistJpe;
import com.silverlakesymmetri.cbs.dep.svc.mapper.decorator.InwdChequeClearingOverrideServiceDecorator;
import com.silverlakesymmetri.cbs.dep.svc.mapper.mapping.InwdChequeHistToDEPINWDCCOVERRIDEAPITypeMapper;
import com.silverlakesymmetri.cbs.dep.xmlapi.DEPINWDCCOVERRIDEAPIType;

@Mapper(config=InwdChequeHistToDEPINWDCCOVERRIDEAPITypeMapper.class, uses={ DateTimeHelper.class})
@DecoratedWith(InwdChequeClearingOverrideServiceDecorator.class)
public interface InwdChequeClearingOverrideServiceMapper{
	
	@Mappings({
		 @Mapping(expression = "java(oper != null ? oper.getOperation() : null)", target="OPERATION")
	 })
	@InheritConfiguration
	public DEPINWDCCOVERRIDEAPIType mapToApi(InwdChequeHistJpe jpe, @Context CbsXmlApiOperation oper, @Context Map otherInfo);
	
	@InheritInverseConfiguration(name = "mapInwdChequeHistToDEPINWDCCOVERRIDEAPIType")
	public InwdChequeHistJpe mapToJpe(DEPINWDCCOVERRIDEAPIType api, @MappingTarget InwdChequeHistJpe jpe);
	
}
