package com.silverlakesymmetri.cbs.dep.svc;

import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.svc.BusinessService;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.CiDetailQry;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.CiDetailQryJpe;

import java.util.List;
import java.util.Map;

public interface CiDetailQryService extends BusinessService<CiDetailQry, CiDetailQryJpe> {

    public static final String SVC_OP_NAME_CIDETAILQRYSERVICE_GET = "CiDetailQryService.get";
    public static final String SVC_OP_NAME_CIDETAILQRYSERVICE_FIND = "CiDetailQryService.find";
    public static final String SVC_OP_NAME_CIDETAILQRYSERVICE_QUERY = "CiDetailQryService.query";
    public static final String SVC_OP_NAME_CIDETAILQRYSERVICE_COUNT = "CiDetailQryService.count";
    public static final String SVC_OP_NAME_CIDETAILQRYSERVICE_GETATTACHEDCIDETAILOFTRANHIST = "CiDetailQryService.getAttachedCiDetailOfTranHist";

    @ServiceOperation(name = SVC_OP_NAME_CIDETAILQRYSERVICE_GET, type = ServiceOperation.ServiceOperationType.GET)
    public CiDetailQry getByPk(String publicKey, CiDetailQry reference);

    @ServiceOperation(name = SVC_OP_NAME_CIDETAILQRYSERVICE_FIND)
    public List<CiDetailQry> find(FindCriteria findCriteria, CbsHeader cbsHeader);

    @ServiceOperation(name = SVC_OP_NAME_CIDETAILQRYSERVICE_QUERY)
    public List<CiDetailQry> query(int offset, int resultLimit, String groupBy, String order, Map<String, Object> filters);
    
    @ServiceOperation(name = SVC_OP_NAME_CIDETAILQRYSERVICE_COUNT, type = ServiceOperation.ServiceOperationType.GET)
    public Long count(FindCriteria findCriteria, CbsHeader cbsHeader);

    @ServiceOperation(name = SVC_OP_NAME_CIDETAILQRYSERVICE_GETATTACHEDCIDETAILOFTRANHIST, type = ServiceOperation.ServiceOperationType.GET, passParamAsMap = true)
    public List<CiDetailQry> getAttachedCiDetailOfTranHist(Map<String, Object> params);
}
