package com.silverlakesymmetri.cbs.dep.svc.mapper;

import java.util.List;

import com.silverlakesymmetri.cbs.commons.xmlapi.enums.CbsXmlApiOperation;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.InwdChequeJpe;
import com.silverlakesymmetri.cbs.dep.xmlapi.DEPINWDCLEARINGAPIType;

public interface ClearingServiceMapper {
	
	public DEPINWDCLEARINGAPIType mapToApi(List<InwdChequeJpe> jpeList, CbsXmlApiOperation oper);
	
	public List<InwdChequeJpe> mapToJpeList(DEPINWDCLEARINGAPIType apiType);
}
