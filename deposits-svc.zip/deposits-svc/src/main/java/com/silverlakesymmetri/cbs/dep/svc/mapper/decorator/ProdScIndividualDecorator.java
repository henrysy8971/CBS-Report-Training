package com.silverlakesymmetri.cbs.dep.svc.mapper.decorator;

import java.util.Map;

import org.mapstruct.Context;
import org.mapstruct.MappingTarget;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

import com.silverlakesymmetri.cbs.commons.xmlapi.enums.CbsXmlApiOperation;
import com.silverlakesymmetri.cbs.csd.jpa.mapping.sdo.ProdScIndividualJpe;
import com.silverlakesymmetri.cbs.csd.xmlapi.CSDPRODSCINDIVIDUALAPIType;
import com.silverlakesymmetri.cbs.dep.svc.mapper.ProdScIndividualMapper;
                                                                    
public abstract class ProdScIndividualDecorator implements ProdScIndividualMapper{
	
	@Autowired
	@Qualifier("delegate")
	protected  ProdScIndividualMapper delegate;
	
//	@Autowired(required = true)
//    @Qualifier("cbsGenericDataService")
//    protected CbsGenericDataService dataService;
	
	public final static String PRODKEY = "prodKey";
	@Override
	public CSDPRODSCINDIVIDUALAPIType mapToApi(ProdScIndividualJpe jpe, @Context CbsXmlApiOperation oper, @Context Map otherInfo){
				
		CSDPRODSCINDIVIDUALAPIType req = (CSDPRODSCINDIVIDUALAPIType)delegate.mapToApi(jpe, oper, otherInfo);
		if (otherInfo.containsKey(PRODKEY)){
			req.setPRODKEY(Double.parseDouble( (String) otherInfo.get(PRODKEY) ));
		}
		return  req;
	}
	
	@Override
	public ProdScIndividualJpe mapToJpe(CSDPRODSCINDIVIDUALAPIType api, @MappingTarget ProdScIndividualJpe jpe){
		
		if (jpe == null){
			jpe = new ProdScIndividualJpe();
		}
		
		if (api == null){
			return jpe;
		}
		
		delegate.mapToJpe(api, jpe);
			
		return jpe;
	}
}


