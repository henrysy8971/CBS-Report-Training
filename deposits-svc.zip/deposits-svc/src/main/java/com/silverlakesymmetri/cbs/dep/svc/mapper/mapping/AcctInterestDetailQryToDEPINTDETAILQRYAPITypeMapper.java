package com.silverlakesymmetri.cbs.dep.svc.mapper.mapping;

import com.silverlakesymmetri.cbs.commons.jpa.util.DateTimeHelper;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.AcctInterestDetailQryJpe;
import com.silverlakesymmetri.cbs.dep.xmlapi.DEPINTDETAILQRYAPIType;
import org.mapstruct.MapperConfig;
import org.mapstruct.Mapping;
import org.mapstruct.Mappings;

@MapperConfig(uses={ DateTimeHelper.class})
public interface AcctInterestDetailQryToDEPINTDETAILQRYAPITypeMapper {

    @Mappings({
            @Mapping(target ="INTERNALKEY", source = "internalKey"),
            @Mapping(target ="CREFFECTRATE", source = "crEffectRate"),
            @Mapping(target ="CRFUNDRATE", source = "crFundRate"),
            @Mapping(target ="DREFFECTRATE", source = "drEffectRate"),
            @Mapping(target ="DRFUNDRATE", source = "drFundRate"),
            @Mapping(target ="DRAUTHEARNEDINTAMT", source = "drAuthEarnedIntAmt"),
            @Mapping(target ="DRAUTHACCRINT", source = "drAuthAccrInt"),
            @Mapping(target ="DRAUTHINTADJ", source = "drAuthIntAdj"),
            @Mapping(target ="DRUNAUTHEARNEDINTAMT", source = "drUnauthEarnedIntAmt"),
            @Mapping(target ="DRUNAUTHACCRINT", source = "drUnauthAccrInt"),
            @Mapping(target ="DRUNAUTHINTADJ", source = "drUnauthIntAdj"),
            @Mapping(target ="SPECIALAVAILBAL", source = "specialAvailBal"),
            @Mapping(target ="SPECIALAVAILBALCRDRIND", source = "specialAvailBalCrDrInd"),
    })
    public DEPINTDETAILQRYAPIType mapAcctInterestDetailQryToDEPINTDETAILQRYAPITypeMapper(AcctInterestDetailQryJpe jpe);
}
