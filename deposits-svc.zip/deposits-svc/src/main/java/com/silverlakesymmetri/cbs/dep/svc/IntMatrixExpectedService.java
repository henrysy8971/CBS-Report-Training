package com.silverlakesymmetri.cbs.dep.svc;

import java.util.Date;
import java.util.List;
import java.util.Map;

import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation;
import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation.ServiceOperationType;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.svc.BusinessService;
import com.silverlakesymmetri.cbs.csd.bdo.sdo.IntType;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.IntMatrixExpected;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.IntMatrixExpectedJpe;

public interface IntMatrixExpectedService extends BusinessService<IntMatrixExpected, IntMatrixExpectedJpe> {
	public static final String SVC_OP_NAME_INTMATRIXEXPECTEDSERVICE_GET = "IntMatrixExpectedService.get";
	public static final String SVC_OP_NAME_INTMATRIXEXPECTEDSERVICE_QUERY = "IntMatrixExpectedService.query";
	public static final String SVC_OP_NAME_INTMATRIXEXPECTEDSERVICE_CREATE = "IntMatrixExpectedService.create";
	public static final String SVC_OP_NAME_INTMATRIXEXPECTEDSERVICE_UPDATE = "IntMatrixExpectedService.update";
	public static final String SVC_OP_NAME_INTMATRIXEXPECTEDSERVICE_DELETE = "IntMatrixExpectedService.delete";
	public static final String SVC_OP_NAME_INTMATRIXEXPECTEDSERVICE_FIND = "IntMatrixExpectedService.find";
	public static final String SVC_OP_NAME_INTMATRIXEXPECTEDSERVICE_GET_HISTORY = "IntMatrixExpectedService.getHistory";
	public static final String SVC_OP_NAME_INTMATRIXEXPECTEDSERVICE_CR_INT_FOR_TD_ACCT = "IntMatrixExpectedService.findCrIntForTdAcct";
	public static final String SVC_OP_NAME_INTMATRIXEXPECTEDSERVICE_GET_BY_INTTYPE_CCY_EFFDT = "IntMatrixExpectedService.getbyinttypeccyeffdt";

	@ServiceOperation(name = SVC_OP_NAME_INTMATRIXEXPECTEDSERVICE_CREATE)
	public IntMatrixExpected create(IntMatrixExpected dataObject);

	@ServiceOperation(name = SVC_OP_NAME_INTMATRIXEXPECTEDSERVICE_UPDATE)
	public IntMatrixExpected update(IntMatrixExpected dataObject);

	@ServiceOperation(name = SVC_OP_NAME_INTMATRIXEXPECTEDSERVICE_DELETE)
	public boolean delete(IntMatrixExpected dataObject);

	@ServiceOperation(name = SVC_OP_NAME_INTMATRIXEXPECTEDSERVICE_QUERY)
	public List<IntMatrixExpected> query(int offset, int resultLimit, String groupBy, String order,
			Map<String, Object> filters);

	@ServiceOperation(name = SVC_OP_NAME_INTMATRIXEXPECTEDSERVICE_FIND)
	public List<IntMatrixExpected> find(FindCriteria findCriteria, CbsHeader cbsHeader);

	@ServiceOperation(name = SVC_OP_NAME_INTMATRIXEXPECTEDSERVICE_GET, type = ServiceOperationType.GET)
	public IntMatrixExpected getByPk(String publicKey, IntMatrixExpected reference);

	@ServiceOperation(name = SVC_OP_NAME_INTMATRIXEXPECTEDSERVICE_GET_HISTORY, type = ServiceOperationType.GET)
	public IntMatrixExpected getHistoryByPk(String intType, String ccy);

	@ServiceOperation(name = SVC_OP_NAME_INTMATRIXEXPECTEDSERVICE_CR_INT_FOR_TD_ACCT, type = ServiceOperationType.READ, passParamAsMap = true)
	public List<IntType> findCrIntForTdAcct(Map<String, Object> queryParams);

    @ServiceOperation(name = SVC_OP_NAME_INTMATRIXEXPECTEDSERVICE_GET_BY_INTTYPE_CCY_EFFDT, type = ServiceOperationType.GET)
    public IntMatrixExpected getbyinttypeccyeffdt(String intType, String ccy, Date asOfDate);

}
