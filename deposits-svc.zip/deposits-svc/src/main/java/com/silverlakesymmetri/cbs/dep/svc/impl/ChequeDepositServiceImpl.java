package com.silverlakesymmetri.cbs.dep.svc.impl;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.mysema.query.types.EntityPath;
import com.silverlakesymmetri.cbs.commons.aop.BpmCheckLimitPostProcess;
import com.silverlakesymmetri.cbs.commons.context.CbsSessionContext;
import com.silverlakesymmetri.cbs.commons.exception.CbsRuntimeException;
import com.silverlakesymmetri.cbs.commons.jpa.entity.CbsBpmInfoJpe;
import com.silverlakesymmetri.cbs.commons.logging.CbsAppLogger;
import com.silverlakesymmetri.cbs.commons.logging.CbsAppLoggerFactory;
import com.silverlakesymmetri.cbs.commons.svc.AbstractXmlApiBusinessService;
import com.silverlakesymmetri.cbs.commons.svc.LimitsCheckingCapable;
import com.silverlakesymmetri.cbs.commons.xmlapi.enums.CbsXmlApiOperation;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.DepositTransaction;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.AcctJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.DepositTransactionJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.QDepositTransactionJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.util.DepJpeConstants;
import com.silverlakesymmetri.cbs.dep.svc.ChequeDepositService;
import com.silverlakesymmetri.cbs.dep.svc.DepositsExpEmkService;
import com.silverlakesymmetri.cbs.dep.svc.mapper.ChequeDepositServiceMapper;
import com.silverlakesymmetri.cbs.dep.svc.util.AcctHelper;
import com.silverlakesymmetri.cbs.dep.xmlapi.DEPTRANHISTINSAPIType;
import com.silverlakesymmetri.cbs.dep.xmlapi.DEPTRANVALIDATIONFLAGSTType;
import com.silverlakesymmetri.cbs.lmt.util.ExpEmkObjectHolder;
import com.silverlakesymmetri.cbs.lmt.util.LimitsUtility;

@Service
@Transactional
public class ChequeDepositServiceImpl extends AbstractXmlApiBusinessService<DepositTransaction, DepositTransactionJpe,
        Long, DEPTRANHISTINSAPIType, DEPTRANHISTINSAPIType> implements ChequeDepositService, LimitsCheckingCapable<DepositTransaction> {

	private static CbsAppLogger logger = CbsAppLoggerFactory.getLogger(ChequeDepositServiceImpl.class.getName());
	private static final String TRAN_HIST_SEQ = "DEP_TRAN_HIST_S";

	@Autowired
	ChequeDepositServiceMapper mapper;

	@Autowired
	private DepositsExpEmkService depositsExpEmkService;

    @Autowired
    private LimitsUtility limitsUtility;

    @Autowired
	private AcctHelper acctHelper;

	private static final String INVALID_ACCT_NO_ERROR_CODE = "CBS.B.CORE.828047";
	
	@Override
	protected EntityPath<DepositTransactionJpe> getEntityPath() {
		return QDepositTransactionJpe.depositTransactionJpe;
	}

	@Override
	protected Long getIdFromDataObjectInstance(DepositTransaction dataObject) {
		return dataObject.getSeqNo();
	}

	@Override
    @BpmCheckLimitPostProcess
	public DepositTransaction postTransaction(DepositTransaction dataObject) {
		DepositTransaction originalDataObject = dataObject;
		if(dataObject.getTranDate() == null){
			dataObject.setTranDate(dateTimeHelper.getSDODateTime(dateTimeHelper.getRunDate()));
		}
		executeStoredProcedure(dataObject, shouldPerformValidate(dataObject));
		postCreateObject(dataObject, originalDataObject);
		return dataObject;
	}

	@Override
	protected DepositTransaction preCreateValidation(DepositTransaction dataObject) {
		long mainSeqNo = dataService.nextSequenceValue(TRAN_HIST_SEQ).longValue();
		dataObject.setSeqNo(mainSeqNo);
		return super.preCreateValidation(dataObject);
	}

	@Override
	protected DEPTRANHISTINSAPIType transformBdoToXmlApiRqCreate(DepositTransaction dataObject) {
		return transformDepositTransactionToDEPTRANHISTINSAPIType(dataObject, CbsXmlApiOperation.INSERT);
	}

	@Override
	protected DEPTRANHISTINSAPIType transformBdoToXmlApiRqUpdate(DepositTransaction dataObject) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	protected DEPTRANHISTINSAPIType transformBdoToXmlApiRqDelete(DepositTransaction dataObject) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	protected DepositTransaction processXmlApiRs(DepositTransaction dataObject, DEPTRANHISTINSAPIType xmlApiRs) {
		// TODO Auto-generated method stub

		DepositTransactionJpe jpe = jaxbSdoHelper.unwrap(dataObject);
		mapper.mapToJpe(xmlApiRs, jpe);
		dataObject = jaxbSdoHelper.wrap(jpe);
		
		return dataObject;
	}

	@Override
	protected Class<DEPTRANHISTINSAPIType> getXmlApiResponseClass() {
		// TODO Auto-generated method stub
		return DEPTRANHISTINSAPIType.class;
	}
	
	private DEPTRANHISTINSAPIType transformDepositTransactionToDEPTRANHISTINSAPIType(DepositTransaction dataObject, CbsXmlApiOperation oper){
		
		Map map = new HashMap();
		CbsSessionContext sessionCtx = cbsRuntimeContextManager.getContext(CbsSessionContext.class);
		map.put(mapper.BRANCH, sessionCtx.getBranch());
		map.put(mapper.CHANNEL_SOURCE, sessionCtx.getChannelSource());

		DepositTransactionJpe jpe = jaxbSdoHelper.unwrap(dataObject);
		DEPTRANHISTINSAPIType apiType =  mapper.mapToApi(jpe, oper, map);
		super.setTechColsFromDataObject(dataObject, apiType);
		if (apiType.getSCAPPLYIN() != null) {
			DEPTRANVALIDATIONFLAGSTType depTranValFlags = new DEPTRANVALIDATIONFLAGSTType();
			depTranValFlags.setCHKEFFDATE(apiType.getCHKEFFDATE());
			depTranValFlags.setCHKOVERRIDE(apiType.getCHKOVERRIDE());
			depTranValFlags.setCHKTELLERLIMIT(apiType.getCHKTELLERLIMIT());
			depTranValFlags.setIGNAVAILBAL(apiType.getIGNAVAILBAL());
			depTranValFlags.setIGNRESTRAINT(apiType.getIGNRESTRAINT());
			apiType.getSCAPPLYIN().setTRANVALIDATIONFLAGS(depTranValFlags);
		}
		return apiType;
	}

	@Override
	protected List<DepositTransaction> processXmlApiListRs(DepositTransaction dataObject,
			DEPTRANHISTINSAPIType xmlApiRs) {
		// TODO Auto-generated method stub
		return null;
	}

    @Override
    public CbsBpmInfoJpe doCheckLimit(DepositTransaction dataObject) {
        ExpEmkObjectHolder expEmkObject = getExpEmkObjectHolder(dataObject);
        return limitsUtility.getLimitExceptionApprover(expEmkObject, dataObject);
    }

    @Override
    public DepositTransaction getLimitExceptions(DepositTransaction dataObject) {
        ExpEmkObjectHolder expEmkObject = getExpEmkObjectHolder(dataObject);
        return limitsUtility.getLimitExceptionDetails(expEmkObject, dataObject);
    }

    private ExpEmkObjectHolder getExpEmkObjectHolder(DepositTransaction dataObject){
        AcctJpe acctJpe = null;
        Map<String,Object> param = new HashMap<String, Object>();
        param.put("acctNo", dataObject.getAcctNo());
        List<AcctJpe> acctJpeList = dataService.findWithNamedQuery(DepJpeConstants.ACCT_JPE_FIND_BY_ACCTNO, param,
                AcctJpe.class);
        acctJpe = acctJpeList.get(0);
        ExpEmkObjectHolder expEmkObject = depositsExpEmkService.getLimitsDetails(dataObject, acctJpe,
                DepositsExpEmkServiceImpl.DEP_EVENT_TYPE, DepositsExpEmkServiceImpl.CR_AMT_TYPE);
        return expEmkObject;
    }

	@Override
	public Long getEffectivityDate(DepositTransaction dataObject) {
		if (dataObject != null) {
			if (!StringUtils.isBlank(dataObject.getEffectDate())) {
				Date date = dateTimeHelper.getDate(dataObject.getEffectDate());
				if (date != null) {
					return dateTimeHelper.removeTime(date).getTime();
				}
			}
		}
		return null;
	}
	
	@Override
	public void validateApiRequest(DepositTransaction dataObject, DEPTRANHISTINSAPIType xmlApiRq) {
        try {
            String xmlApiReq = removeModifiedByAndModifiedDt(convertXmlApiRqToString(xmlApiRq));
            String xmlHeaderIn = convertXmlApiRqToString(createHeaderFromDataObject(dataObject));
            validate(dataObject, xmlApiReq, xmlHeaderIn);
        } catch (CbsRuntimeException cre) {
            throw cre;
        } catch (Exception e) {
            logger.error("Unhandled error encountered: {}", e.getMessage(), e);
            throw new RuntimeException(e);
        }
    }
}
