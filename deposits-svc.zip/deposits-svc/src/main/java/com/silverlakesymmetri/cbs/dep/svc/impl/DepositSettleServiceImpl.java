package com.silverlakesymmetri.cbs.dep.svc.impl;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.mysema.query.types.EntityPath;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.svc.AbstractBusinessService;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.DepositSettle;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.DepositSettleJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.QDepositSettleJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.id.DepositSettlePk;
import com.silverlakesymmetri.cbs.dep.svc.DepositSettleService;
import com.silverlakesymmetri.cbs.mcl.bdo.sdo.ClientType;
import com.silverlakesymmetri.cbs.mcl.jpa.mapping.sdo.ClientTypeJpe;

@Service
@Transactional
public class DepositSettleServiceImpl extends AbstractBusinessService<DepositSettle, DepositSettleJpe, DepositSettlePk> implements DepositSettleService {

	@Override
	protected EntityPath<DepositSettleJpe> getEntityPath() {
		return QDepositSettleJpe.depositSettleJpe;
	}

	@Override
	protected DepositSettlePk getIdFromDataObjectInstance(DepositSettle dataObject) {
		DepositSettlePk pk = new DepositSettlePk(dataObject.getSettleMethod(), dataObject.getPayRecCode());
        return pk;
	}

	@Override
	public DepositSettle getByPk(String publicKey, DepositSettle reference) {
		return super.getByPk(publicKey, reference);
	}
	
	@Override
    protected DepositSettle preCreateValidation(DepositSettle dataObject) {
		DepositSettleJpe depositSettleJpe = jaxbSdoHelper.unwrap(dataObject);
        if (null == depositSettleJpe.isUsedYn()) {
        	depositSettleJpe.setUsedYn(false);
        }
        if (null == depositSettleJpe.isActiveYn()) {
        	depositSettleJpe.setActiveYn(false);
        }
        
        dataObject = jaxbSdoHelper.wrap(depositSettleJpe, DepositSettle.class);
        return super.preCreateValidation(dataObject);
    }

	@Override
	public DepositSettle create(DepositSettle dataObject) {
		return super.create(dataObject);
	}

	@Override
	public DepositSettle update(DepositSettle dataObject) {
		return super.update(dataObject);
	}

	@Override
	public List<DepositSettle> query(int offset, int resultLimit, String groupBy, String order,
			Map<String, Object> filters) {
		return super.query(offset, resultLimit, groupBy, order, filters);
	}

	@Override
	public boolean delete(DepositSettle dataObject) {
		return super.delete(dataObject);
	}

	@Override
	public List<DepositSettle> find(FindCriteria findCriteria, CbsHeader cbsHeader) {
		return super.find(findCriteria, cbsHeader);
	}

}
