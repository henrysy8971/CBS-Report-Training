package com.silverlakesymmetri.cbs.dep.svc.mapper.mapping;

import com.silverlakesymmetri.cbs.commons.jpa.util.DateTimeHelper;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.CashMngtJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.OdFacilityMainJpe;
import com.silverlakesymmetri.cbs.dep.xmlapi.DEPCASHMNGTAPIType;
import com.silverlakesymmetri.cbs.dep.xmlapi.DEPODFACILITYAPIType;
import org.mapstruct.MapperConfig;
import org.mapstruct.Mapping;
import org.mapstruct.Mappings;

@MapperConfig(uses={ DateTimeHelper.class})
public interface CashMngtToDEPCASHMNGTAPITypeMapper {

	@Mappings({
		@Mapping(source = "seqNo", target = "SEQNO"),
		@Mapping(source = "tranDate", target = "TRANDATE", qualifiedByName = {"DateTimeHelper","convertDateToCbsXmlApiDate"}),
		@Mapping(source = "effectDate", target = "EFFECTDATE", qualifiedByName = {"DateTimeHelper","convertDateToCbsXmlApiDate"}),
		@Mapping(source = "tranMode", target = "TRANMODE"),
		@Mapping(source = "branch", target = "BRANCH"),
		@Mapping(source = "tranType", target = "TRANTYPE"),
		@Mapping(source = "tranDesc", target = "TRANDESC"),
		@Mapping(source = "crDrMaintInd", target = "CRDRMAINTIND"),
		@Mapping(source = "profitCentre", target = "PROFITCENTRE"),
		@Mapping(source = "transferBranch", target = "TRANSFERBRANCH"),
		@Mapping(source = "tellerId", target = "TELLERID"),
		@Mapping(source = "ccy", target = "CCY"),
		@Mapping(source = "tranAmt", target = "TRANAMT"),
		@Mapping(source = "baseEquivAmt", target = "BASEEQUIVAMT"),
		@Mapping(source = "narrative", target = "NARRATIVE")
	})
	public DEPCASHMNGTAPIType mapCashMngtToDEPCASHMNGTAPIType(CashMngtJpe jpe);

}
