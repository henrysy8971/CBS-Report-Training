package com.silverlakesymmetri.cbs.dep.svc.mapper.mapping;

import com.silverlakesymmetri.cbs.commons.jpa.util.DateTimeHelper;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.FxBuySellJpe;
import com.silverlakesymmetri.cbs.dep.xmlapi.DEPFXBUYSELLAPIType;
import org.mapstruct.MapperConfig;
import org.mapstruct.Mapping;
import org.mapstruct.Mappings;

@MapperConfig(uses={ DateTimeHelper.class})
public interface FxBuySellToDEPFXBUYSELLAPITypeMapper {
	
	@Mappings({
		@Mapping(source = "tranType", target = "TRANTYPE"),
		@Mapping(source = "paymentType", target = "PAYMENTTYPE"),
		@Mapping(source = "effectDate", target = "EFFECTDATE", qualifiedByName = {"DateTimeHelper","convertDateToCbsXmlApiDate"}),
		@Mapping(source = "officerId", target = "OFFICERID"),
		@Mapping(source = "captureAmtType", target = "CAPTUREAMTTYPE"),
		@Mapping(source = "dcTranType", target = "DCTRANTYPE"),
		@Mapping(source = "acctNo", target = "DCACCTNO"),
		@Mapping(source = "acctCcy", target = "DCACCTCCY"),
		@Mapping(source = "acctBranch", target = "DCACCTBRANCH"),
		@Mapping(source = "clientName", target = "CLIENTNAME"),
		@Mapping(source = "globalIdType", target = "GLOBALIDTYPE"),
		@Mapping(source = "global", target = "GLOBALID"),
		@Mapping(target = "SOURCEMODULE", constant = "DEP"),
		@Mapping(source = "profitCentre", target = "PROFITCENTRE"),
		@Mapping(source = "narrative", target = "NARRATIVE"),
		@Mapping(source = "ccy", target = "SOURCECCY"),
		@Mapping(source = "contraCcy", target = "TARGETCCY"),
		@Mapping(source = "tranAmt", target = "SOURCEAMT"),
		@Mapping(source = "contraEquivAmt", target = "TARGETAMT"),
		@Mapping(source = "rateType", target = "MAINXRATETYPE"),
		@Mapping(source = "crossRate", target = "CROSSRATE"),
		@Mapping(source = "origCrossRate", target = "ORIGCROSSRATE"),
		@Mapping(source = "baseEquivAmt", target = "BASEEQUIVAMT"),
		@Mapping(source = "feeTranType", target = "COMMISSIONTRANTYPE"),
		@Mapping(source = "feeAmt", target = "COMMISSIONTRANAMT"),
		@Mapping(source = "baseCcy", target = "BASECCY"),
		@Mapping(source = "branch", target = "TRANBRANCH"),
		@Mapping(source = "ignoreRestraint", target = "TRANVALIDATIONFLAGS.IGNRESTRAINT", defaultValue = "N"),
		@Mapping(source = "ignoreAvailbal", target = "TRANVALIDATIONFLAGS.IGNAVAILBAL" , defaultValue = "N"),
		@Mapping(source = "checkOverride", target = "TRANVALIDATIONFLAGS.CHKOVERRIDE" , defaultValue = "N"),
		@Mapping(source = "checkTellerLimit", target = "TRANVALIDATIONFLAGS.CHKTELLERLIMIT" , defaultValue = "N"),
		@Mapping(source = "checkEffdate", target = "TRANVALIDATIONFLAGS.CHKEFFDATE" , defaultValue = "Y")
	})
	public DEPFXBUYSELLAPIType mapFxBuySellToDEPFXBUYSELLAPIType(FxBuySellJpe jpe);
		
}




