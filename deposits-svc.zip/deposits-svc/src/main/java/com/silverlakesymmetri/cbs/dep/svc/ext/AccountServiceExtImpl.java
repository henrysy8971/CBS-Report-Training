package com.silverlakesymmetri.cbs.dep.svc.ext;

import javax.inject.Inject;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.silverlakesymmetri.cbs.commons.ext.ServiceExtensionPoint;
import com.silverlakesymmetri.cbs.commons.ext.impl.AbstractServiceExtPointImpl;
import com.silverlakesymmetri.cbs.commons.jpa.extension.JaxbSdoHelper;
import com.silverlakesymmetri.cbs.commons.jpa.service.CbsGenericDataService;
import com.silverlakesymmetri.cbs.csd.bdo.sdo.Contact;
import com.silverlakesymmetri.cbs.csd.svc.ContactService;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.Acct;
import com.silverlakesymmetri.cbs.dep.svc.AcctService;
import com.silverlakesymmetri.cbs.xps.svc.ext.AccountServiceExt;

@Service
@Transactional
public class AccountServiceExtImpl extends AbstractServiceExtPointImpl implements ServiceExtensionPoint, AccountServiceExt {

	@Autowired
    @Qualifier("cbsGenericDataService")
    protected CbsGenericDataService dataService;
	
    @Inject
    protected JaxbSdoHelper jaxbSdoHelper;
    
    @Autowired
    private AcctService acctService;

	@Autowired
	private ContactService contactService;

	@Override
	public Contact getAccountStmtContact(String acctNo) {
		Acct acct = acctService.getByPk(acctNo, null);
		if(acct != null && acct.getAcctStmtRec() != null && acct.getAcctStmtRec().getContactRefNo() != null){
			Contact contact = contactService.getByPk(acct.getAcctStmtRec().getContactRefNo(), null);
			return contact;
		}
		return null;
	}

	@Override
	public String[] getExtendedBdoNames() {
		return new String[] {ACCOUNT_SERVICE};
	}

	@Override
	public String[] getExtendedServiceNames() {
		return new String[] {ACCOUNT_SERVICE_CONTACT};
	}

}
