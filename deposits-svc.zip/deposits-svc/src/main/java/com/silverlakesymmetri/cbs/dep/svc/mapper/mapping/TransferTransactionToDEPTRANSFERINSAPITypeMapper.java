package com.silverlakesymmetri.cbs.dep.svc.mapper.mapping;

import org.mapstruct.MapperConfig;
import org.mapstruct.Mapping;
import org.mapstruct.Mappings;

import com.silverlakesymmetri.cbs.commons.jpa.util.DateTimeHelper;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.TransferTransactionDetailJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.TransferTransactionJpe;
import com.silverlakesymmetri.cbs.dep.xmlapi.DEPTRANSFERINSAPIType;

@MapperConfig(uses={ DateTimeHelper.class})
public interface TransferTransactionToDEPTRANSFERINSAPITypeMapper {

	@Mappings({
		@Mapping(source = "seqNo", target = "DRTRANSEQNO"),
		@Mapping(source = "debitTranType", target = "DRTRANTYPE"),
		@Mapping(source = "creditTranType", target = "CRTRANTYPE"),
		@Mapping(source = "ignoreRestraint", target = "IGNRESTRAINT", defaultValue = "N"),
		@Mapping(source = "ignoreAvailbal", target = "IGNAVAILBAL", defaultValue = "N"),
		@Mapping(source = "checkOverride", target = "CHKOVERRIDE", defaultValue = "N"),
		@Mapping(source = "checkTellerLimit", target = "CHKTELLERLIMIT", defaultValue = "Y"),
		@Mapping(source = "checkEffdate", target = "CHKEFFDATE", defaultValue = "Y")
	 })
	public DEPTRANSFERINSAPIType mapTransferTransactionToDEPTRANSFERINSAPITypeMapper(TransferTransactionJpe jpe);

}
