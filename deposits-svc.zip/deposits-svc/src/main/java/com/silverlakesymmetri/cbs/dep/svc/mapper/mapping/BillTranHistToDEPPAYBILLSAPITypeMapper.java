package com.silverlakesymmetri.cbs.dep.svc.mapper.mapping;

import org.mapstruct.MapperConfig;
import org.mapstruct.Mapping;
import org.mapstruct.Mappings;

import com.silverlakesymmetri.cbs.commons.jpa.util.DateTimeHelper;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.BillTranHistJpe;
import com.silverlakesymmetri.cbs.dep.xmlapi.DEPPAYBILLSAPIType;

@MapperConfig(uses={ DateTimeHelper.class})
public interface BillTranHistToDEPPAYBILLSAPITypeMapper {

	@Mappings({
		@Mapping(source="accountNo", target ="ACCTNO"), 
		@Mapping(source="branch", target ="BRANCH"), 
		@Mapping(source="tranType", target ="TRANTYPE"	), 
		@Mapping(source="effectDate", target ="EFFECTDATE",  qualifiedByName = {"DateTimeHelper","convertDateToCbsXmlApiDate"}), 
		@Mapping(source="tranAmt", target ="TRANAMT"),
		@Mapping(source="ccy", target ="CCY"), 
		@Mapping(source="chequeNo", target ="REFERENCE"),
		@Mapping(source="referenceBank", target ="REFERENCEBANK"),
		@Mapping(source="referenceBranch", target ="REFERENCEBRANCH"),
		@Mapping(source="issuerAcctNo", target ="ISSUERACCTNO"),
		@Mapping(source="floatDays", target ="FLOATDAYS"),
		@Mapping(source="contraCcy", target ="CONTRACCY"),
		@Mapping(source="equivAmt", target ="ACCTEQUIVAMT"),
		@Mapping(source="baseEquivAmt", target ="BASEEQUIVAMT"),
		@Mapping(source="crossRateOrigin", target ="CROSSRATEORIGIN"),
		@Mapping(source="crossRate", target ="CROSSRATE"),
		@Mapping(source="crossRateRefNo", target ="CROSSRATEREFNO"),		
		@Mapping(source="origRate", target ="ORIGRATE"),
		@Mapping(source="exchRateType", target ="EXCHRATETYPE"),
		@Mapping(source="narrative", target ="NARRATIVE"),
		@Mapping(source="scAmount", target ="TOTALSVCAMT"),		
		@Mapping(source="subscriberName", target ="CLIENTNAME"),
		@Mapping(source="instCode", target ="INSTCODE"),
		@Mapping(source="paymentRef", target ="BILLREFERENCE"),
		@Mapping(source="subscriberName", target ="NAME"),
		@Mapping(source="tranSeqNo", target ="TRANSEQNO"),
		@Mapping(source="availableBal", target ="ACCTAVAILBAL"),
		@Mapping(source="ledgerBal", target ="ACCTLEDGERBAL"),
		@Mapping(source="minPayAmt", target ="MINPAYAMT"),
		@Mapping(source="maxPayAmt", target ="MAXPAYAMT")
	 })
	public DEPPAYBILLSAPIType mapBillTranHistToDEPPAYBILLSAPIType(BillTranHistJpe  jpe);

}
