package com.silverlakesymmetri.cbs.dep.svc;

import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.svc.BusinessService;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.DepositRateCategoryHdr;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.DepositRateCategoryHdrJpe;

import java.util.List;
import java.util.Map;

/**
 * Created by Emerson.Sanchez on 12/4/2019.
 */
public interface DepositRateCategoryHdrService extends BusinessService<DepositRateCategoryHdr, DepositRateCategoryHdrJpe> {

    public static final String SVC_OP_NAME_DEPOSITRATECATEGORYHDRSERVICE_GET = "DepositRateCategoryHdrService.get";
    public static final String SVC_OP_NAME_DEPOSITRATECATEGORYHDRSERVICE_QUERY = "DepositRateCategoryHdrService.query";
    public static final String SVC_OP_NAME_DEPOSITRATECATEGORYHDRSERVICE_CREATE = "DepositRateCategoryHdrService.create";
    public static final String SVC_OP_NAME_DEPOSITRATECATEGORYHDRSERVICE_UPDATE = "DepositRateCategoryHdrService.update";
    public static final String SVC_OP_NAME_DEPOSITRATECATEGORYHDRSERVICE_DELETE = "DepositRateCategoryHdrService.delete";
    public static final String SVC_OP_NAME_DEPOSITRATECATEGORYHDRSERVICE_FIND = "DepositRateCategoryHdrService.find";
    public static final String SVC_OP_NAME_DEPOSITRATECATEGORYHDRSERVICE_COUNT = "DepositRateCategoryHdrService.count";

    @ServiceOperation(name = SVC_OP_NAME_DEPOSITRATECATEGORYHDRSERVICE_GET, type = ServiceOperation.ServiceOperationType.GET)
    public DepositRateCategoryHdr getByPk(String publicKey, DepositRateCategoryHdr reference);

    @ServiceOperation(name = SVC_OP_NAME_DEPOSITRATECATEGORYHDRSERVICE_CREATE)
    public DepositRateCategoryHdr create(DepositRateCategoryHdr dataObject);

    @ServiceOperation(name = SVC_OP_NAME_DEPOSITRATECATEGORYHDRSERVICE_UPDATE)
    public DepositRateCategoryHdr update(DepositRateCategoryHdr dataObject);

    @ServiceOperation(name = SVC_OP_NAME_DEPOSITRATECATEGORYHDRSERVICE_QUERY)
    public List<DepositRateCategoryHdr> query(int offset, int resultLimit, String groupBy, String order,
                                        Map<String, Object> filters);

    @ServiceOperation(name = SVC_OP_NAME_DEPOSITRATECATEGORYHDRSERVICE_DELETE)
    public boolean delete(DepositRateCategoryHdr dataObject);

    @ServiceOperation(name = SVC_OP_NAME_DEPOSITRATECATEGORYHDRSERVICE_FIND)
    public List<DepositRateCategoryHdr> find(FindCriteria findCriteria, CbsHeader cbsHeader);

    @ServiceOperation(name = SVC_OP_NAME_DEPOSITRATECATEGORYHDRSERVICE_COUNT, type = ServiceOperation.ServiceOperationType.GET)
    public Long count(FindCriteria findCriteria, CbsHeader cbsHeader);
}
