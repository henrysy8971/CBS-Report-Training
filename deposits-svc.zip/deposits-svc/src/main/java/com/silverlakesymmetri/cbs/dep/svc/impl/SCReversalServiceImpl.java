package com.silverlakesymmetri.cbs.dep.svc.impl;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.mysema.query.types.EntityPath;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.bdo.ViewCriteriaItem;
import com.silverlakesymmetri.cbs.commons.bdo.ViewCriteriaRow;
import com.silverlakesymmetri.cbs.commons.exception.base.CbsServiceProcessException;
import com.silverlakesymmetri.cbs.commons.exception.base.helper.ExceptionHelper;
import com.silverlakesymmetri.cbs.commons.helper.jpa.LinkTable;
import com.silverlakesymmetri.cbs.commons.helper.jpa.QueryCondition;
import com.silverlakesymmetri.cbs.commons.helper.jpa.QueryType;
import com.silverlakesymmetri.cbs.commons.jpa.entity.ConjunctionEnumJpe;
import com.silverlakesymmetri.cbs.commons.jpa.entity.FindCriteriaJpe;
import com.silverlakesymmetri.cbs.commons.jpa.entity.ViewCriteriaItemJpe;
import com.silverlakesymmetri.cbs.commons.jpa.entity.ViewCriteriaJpe;
import com.silverlakesymmetri.cbs.commons.jpa.entity.ViewCriteriaRowJpe;
import com.silverlakesymmetri.cbs.commons.jpa.service.CriteriaConverter;
import com.silverlakesymmetri.cbs.commons.svc.AbstractXmlApiBusinessService;
import com.silverlakesymmetri.cbs.commons.svc.BusinessObjectValidationCapable;
import com.silverlakesymmetri.cbs.commons.svc.util.InMemoryQueryExecutor;
import com.silverlakesymmetri.cbs.commons.xmlapi.enums.CbsXmlApiOperation;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.SCReversal;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.AcctJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.QSCReversalJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.SCReversalJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.id.SCReversalPk;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.util.DepJpeConstants;
import com.silverlakesymmetri.cbs.dep.svc.SCReversalService;
import com.silverlakesymmetri.cbs.dep.svc.mapper.SCReversalServiceMapper;
import com.silverlakesymmetri.cbs.dep.xmlapi.DEPFEEREVERSALAPIType;
import com.silverlakesymmetri.cbs.pim.jpa.mapping.sdo.MasterDepositAcctQryJpe;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.ScUncollQryJpe;

@Service
@Transactional
public class SCReversalServiceImpl extends
		AbstractXmlApiBusinessService<SCReversal, SCReversalJpe, SCReversalPk, DEPFEEREVERSALAPIType, DEPFEEREVERSALAPIType>
		implements SCReversalService, BusinessObjectValidationCapable<SCReversal> {

	private static final String PU = "PU";
	private static final String UP = "UP";
	private static final String RX = "RX";
	private static final String XR = "XR";
	private static final String WS = "WS";
	private static final String SW = "SW";
	private static final String SUB_TYPE_CANNOT_BE_SDB = "CBS.B.DEP.SC_REVERSAL_SERVICE.0001";

	@Autowired
	SCReversalServiceMapper mapper;

    private static LinkedHashMap<String, LinkTable> constructorMap;

    private static QueryCondition queryCondition;

    static {
        constructorMap = new LinkedHashMap<String, LinkTable>();
        constructorMap.put("scDate", new LinkTable(SCReversalJpe.class));
        constructorMap.put("scType", new LinkTable(SCReversalJpe.class));
        constructorMap.put("scRateType", new LinkTable(SCReversalJpe.class));
        constructorMap.put("scEventType", new LinkTable(SCReversalJpe.class));
        constructorMap.put("internalKey", new LinkTable(SCReversalJpe.class));
        constructorMap.put("acctNo", new LinkTable(MasterDepositAcctQryJpe.class));
        constructorMap.put("thirdPartyKey", new LinkTable(SCReversalJpe.class));
        constructorMap.put("productClass", new LinkTable(SCReversalJpe.class));
        constructorMap.put("prodNo", new LinkTable(SCReversalJpe.class));
        constructorMap.put("calcBalType", new LinkTable(SCReversalJpe.class));
        constructorMap.put("scCcy", new LinkTable(SCReversalJpe.class));
        constructorMap.put("scAmt", new LinkTable(SCReversalJpe.class));
        constructorMap.put("scTaxAmt", new LinkTable(SCReversalJpe.class));
        constructorMap.put("status", new LinkTable(SCReversalJpe.class));
        constructorMap.put("reasonType", new LinkTable(SCReversalJpe.class));
        constructorMap.put("reasonDesc", new LinkTable(SCReversalJpe.class));
        constructorMap.put("changeDate", new LinkTable(SCReversalJpe.class));
        constructorMap.put("changeScSeqNo", new LinkTable(SCReversalJpe.class));
        constructorMap.put("scSeqNo", new LinkTable(SCReversalJpe.class));
        constructorMap.put("scLocation", new LinkTable(SCReversalJpe.class));
        constructorMap.put("moduleId", new LinkTable(SCReversalJpe.class));
        constructorMap.put("subType", new LinkTable(SCReversalJpe.class));

        queryCondition = new QueryCondition();
        queryCondition.where("internalKey", QueryType.EQUALS, new LinkTable(ScUncollQryJpe.class, "internalKey"));
        queryCondition.where("internalKey", QueryType.EQUALS, new LinkTable(MasterDepositAcctQryJpe.class, "internalKey"));
        queryCondition.where("scSeqNo", QueryType.EQUALS, new LinkTable(ScUncollQryJpe.class, "scSeqNo"));
    }

    @Override
	protected EntityPath<SCReversalJpe> getEntityPath() {
		return QSCReversalJpe.sCReversalJpe;
	}

	@Override
	protected SCReversalPk getIdFromDataObjectInstance(SCReversal dataObject) {
		return new SCReversalPk(dateTimeHelper.getDate(dataObject.getScDate()), dataObject.getScSeqNo(),
				dataObject.getScLocation());
	}

	@Override
	public SCReversal getByPk(String publicKey, SCReversal reference) {
		SCReversal scReversal = super.getByPk(publicKey, reference);
		//TODO: the status does not fully identify uncollected SC - once status has been fully implemented, execute below code only for Uncollected 
		//as a temporary workaround, perform below query for every getByPk request
		//if("U".equals(scReversal.getStatus())){
			Map<String, Object> params = new HashMap<String, Object>();
			params.put("internalKey", scReversal.getInternalKey());
			params.put("scSeqNo", scReversal.getScSeqNo());
			List<ScUncollQryJpe> resultList = dataService.findWithQuery("SELECT a FROM ScUncollQryJpe a WHERE a.internalKey = :internalKey AND a.scSeqNo = :scSeqNo", ScUncollQryJpe.class, params, null);
			if(resultList != null && resultList.size() > 0){
				scReversal.setScUncollectedAmt(resultList.get(0).getUncollScAmt());
			}
		//}
		return scReversal;
	}

	@Override
	public List<SCReversal> query(int offset, int resultLimit, String groupBy, String order,
			Map<String, Object> filters) {
		return super.query(offset, resultLimit, groupBy, order, filters);
	}

	@Override
	public List<SCReversal> find(FindCriteria findCriteria, CbsHeader cbsHeader) {
		boolean shouldSwitchSource = switchSource(findCriteria);
		FindCriteriaJpe fcJpe = updateFC(findCriteria);
		FindCriteria fcBdo = jaxbSdoHelper.wrap(fcJpe, FindCriteria.class);
		if(shouldSwitchSource){
			List<Object> resultList = getUncollectedServiceCharge(fcBdo);
			List<SCReversal> bdoList = new ArrayList<SCReversal>();
			List<SCReversal> result = new ArrayList<SCReversal>();
			if(resultList != null){
				for(int i = 0; i < resultList.size(); i++){
					Object[] jpeRep = (Object[]) resultList.get(i);
					SCReversalJpe jpe = new SCReversalJpe();
					jpe.setScDate(jpeRep[0] == null ? null : (Date) jpeRep[0]);
					jpe.setScType(jpeRep[1] == null ? null : jpeRep[1].toString());
					jpe.setScRateType(jpeRep[2] == null ? null : jpeRep[2].toString());
					jpe.setScEventType(jpeRep[3] == null ? null : jpeRep[3].toString());
					jpe.setInternalKey(jpeRep[4] == null ? null : Long.parseLong(jpeRep[4].toString()));
					jpe.setThirdPartyKey(jpeRep[5] == null ? null : Long.parseLong(jpeRep[5].toString()));
					jpe.setProductClass(jpeRep[6] == null ? null : jpeRep[6].toString());
					jpe.setProdNo(jpeRep[7] == null ? null : jpeRep[7].toString());
					jpe.setCalcBalType(jpeRep[8] == null ? null : jpeRep[8].toString());
					jpe.setScCcy(jpeRep[9] == null ? null : jpeRep[9].toString());
					jpe.setScAmt(jpeRep[10] == null ? null : Double.parseDouble(jpeRep[10].toString()));
					jpe.setScTaxAmt(jpeRep[11] == null ? null : Double.parseDouble(jpeRep[11].toString()));
					jpe.setStatus(jpeRep[12] == null ? null : jpeRep[12].toString());
					jpe.setReasonType(jpeRep[13] == null ? null : jpeRep[13].toString());
					jpe.setReasonDesc(jpeRep[14] == null ? null : jpeRep[14].toString());
					jpe.setChangeDate(jpeRep[15] == null ? null : (Date) jpeRep[15]);
					jpe.setChangeScSeqNo(jpeRep[16] == null ? null : Long.parseLong(jpeRep[16].toString()));
					jpe.setScSeqNo(jpeRep[17] == null ? null : Long.parseLong(jpeRep[17].toString()));
					jpe.setScLocation(jpeRep[18] == null ? null : jpeRep[18].toString());
					jpe.setModuleId(jpeRep[19] == null ? null : jpeRep[19].toString());
					jpe.setSubType(jpeRep[20] == null ? null : jpeRep[20].toString());
					bdoList.add(jaxbSdoHelper.wrap(jpe));
				}
				InMemoryQueryExecutor<SCReversal> inMemQry = new InMemoryQueryExecutor<>(bdoList);
				result = inMemQry.executeFilter(fcBdo);
			}
			return result;
		}
		return super.find(fcBdo, cbsHeader);
	}
	
	private List<Object> getUncollectedServiceCharge(FindCriteria fcBdo){
		Map<String, Object> params = new HashMap<String, Object>();
		
		List<ViewCriteriaRow> rowList = fcBdo.getFilter().getGroup();
		for (ViewCriteriaRow row : rowList) {
			List<ViewCriteriaItem> itemList = row.getItem();
			for (int i = itemList.size() - 1; i >= 0; i--) {
				ViewCriteriaItem vci = itemList.get(i);
				if ("internalKey".equals(vci.getAttribute()) && vci.getValue().get(0) != null) {
					ViewCriteriaItemJpe vciJpe = jaxbSdoHelper.unwrap(vci);
					String internalKey = vciJpe.getValue().get(0).toString();
					params.put("internalKey", Long.parseLong(internalKey));
					break;
				}
			}
		}
		
		List<Object> resultList = dataService.findWithNamedQuery(DepJpeConstants.SC_REVERSAL_UNCOLLECTED, params, Object.class);
		return resultList;
	}

	@Override
	public Long count(FindCriteria findCriteria, CbsHeader cbsHeader) {
		boolean shouldSwitchSource = switchSource(findCriteria);
		FindCriteriaJpe fcJpe = updateFC(findCriteria);
		if(shouldSwitchSource){
			FindCriteria fcBdo = jaxbSdoHelper.wrap(fcJpe, FindCriteria.class);
			List<Object> resultList = getUncollectedServiceCharge(fcBdo);
			if(resultList != null){
				return new Long(resultList.size());
			}
			return 0L;
		}
		return dataService.getRowCount(SCReversalJpe.class, fcJpe);
	}

	@Override
	public SCReversal update(SCReversal dataObject) {
		return super.update(dataObject);
	}

	@Override
	protected SCReversal preUpdateValidation(SCReversal dataObject) {
		validateSubType(dataObject);
		return super.preUpdateValidation(dataObject);
	}

	private void validateSubType(SCReversal dataObject) {
		Collection<Throwable> exceptions = new ArrayList<>();

		if (dataObject.getSubType().equals("S")) {
			String msg = messageUtils.getMessage(SUB_TYPE_CANNOT_BE_SDB, new String[] { dataObject.getSubType() });
			CbsServiceProcessException exec = new CbsServiceProcessException(SUB_TYPE_CANNOT_BE_SDB, msg);
			exceptions.add(exec);
		}

		ExceptionHelper.createAndThrowAggregateException(exceptions);
	}

	@Override
	protected DEPFEEREVERSALAPIType transformBdoToXmlApiRqCreate(SCReversal dataObject) {
		return null;
	}

	@Override
	protected DEPFEEREVERSALAPIType transformBdoToXmlApiRqUpdate(SCReversal dataObject) {
		return transformBdoToApi(dataObject, CbsXmlApiOperation.UPDATE);
	}

	@Override
	protected DEPFEEREVERSALAPIType transformBdoToXmlApiRqDelete(SCReversal dataObject) {
		return null;
	}

	@Override
	protected SCReversal processXmlApiRs(SCReversal dataObject, DEPFEEREVERSALAPIType xmlApiRs) {
		return dataObject;
	}

	@Override
	protected List<SCReversal> processXmlApiListRs(SCReversal dataObject, DEPFEEREVERSALAPIType xmlApiRs) {
		return null;
	}

	@Override
	protected Class<DEPFEEREVERSALAPIType> getXmlApiResponseClass() {
		return DEPFEEREVERSALAPIType.class;
	}

	@SuppressWarnings({ "rawtypes" })
	private DEPFEEREVERSALAPIType transformBdoToApi(SCReversal bdo, CbsXmlApiOperation operation) {
		SCReversalJpe jpe = jaxbSdoHelper.unwrap(bdo, SCReversalJpe.class);
		DEPFEEREVERSALAPIType apiRq = mapper.mapToApi(jpe, operation, new HashMap());
		super.setTechColsFromDataObject(bdo, apiRq);
		return apiRq;
	}

	private FindCriteriaJpe updateFC(FindCriteria findCriteria) {

		FindCriteriaJpe fc = null;
		String acctNo = null;
		String stat = null;

		if (findCriteria == null) {
			fc = new FindCriteriaJpe();
			ViewCriteriaJpe rootViewCriteria = new ViewCriteriaJpe();
			fc.setFilter(rootViewCriteria);
		} else {
			fc = jaxbSdoHelper.unwrap(findCriteria, true);
		}

		if (fc != null) {

			List<ViewCriteriaRowJpe> rowList = fc.getFilter().getGroup();

			for (ViewCriteriaRowJpe row : rowList) {

				List<ViewCriteriaItemJpe> itemList = row.getItem();
				boolean addScLocationFilter = true;
				ViewCriteriaItemJpe vciForRemoval = null;
				for (int i = itemList.size() - 1; i >= 0; i--) {

					ViewCriteriaItemJpe vci = itemList.get(i);

					if ("acctNo".equals(vci.getAttribute()) && vci.getValue().get(0) != null) {
						acctNo = vci.getValue().get(0).toString();
						List<Object> datalist = new ArrayList<Object>();
						if (acctNo != null) {
							AcctJpe acctJpe = getAccount(acctNo);
							datalist.add(acctJpe.getInternalKey());
							vci.setAttribute("internalKey");
							vci.setOperator("=");
							vci.setValue(datalist);
						}
					}

					if ("status".equals(vci.getAttribute()) && vci.getValue().get(0) != null) {
						stat = vci.getValue().get(0).toString();
						List<Object> datalist = new ArrayList<Object>();
						if (stat != null) {
							if (stat.trim().equalsIgnoreCase(PU) || stat.trim().equalsIgnoreCase(UP)) {
								datalist.add("P");
								datalist.add("U");
							} else if (stat.trim().equalsIgnoreCase(RX) || stat.trim().equalsIgnoreCase(XR)) {
								datalist.add("R");
								datalist.add("X");
							} else if (stat.trim().equalsIgnoreCase(WS) || stat.trim().equalsIgnoreCase(SW)) {
								datalist.add("W");
								datalist.add("S");
							} else if (stat.trim().equalsIgnoreCase("P")) {
								datalist.add("P");
							} else if (stat.trim().equalsIgnoreCase("U")) {
								vciForRemoval = vci;
								addScLocationFilter = false;
							} else if (stat.trim().equalsIgnoreCase("R")) {
								datalist.add("R");
							} else if (stat.trim().equalsIgnoreCase("X")) {
								datalist.add("X");
							} else if (stat.trim().equalsIgnoreCase("W")) {
								datalist.add("W");
							} else if (stat.trim().equalsIgnoreCase("S")) {
								datalist.add("S");
							} else if (stat.trim().equalsIgnoreCase("D")) {
								datalist.add("D");
							}
							if (datalist.size() > 0) {
								vci.setAttribute("status");
								vci.setOperator(CriteriaConverter.OP_IN);
								vci.setValue(datalist);
							}
						}
					}
				}
				if(addScLocationFilter){
					List<Object> datalist = new ArrayList<Object>();
					datalist.add("E");
					ViewCriteriaItemJpe scLoc = new ViewCriteriaItemJpe();
					scLoc.setAttribute("scLocation");
					scLoc.setOperator(CriteriaConverter.OP_NOT_IN);
					scLoc.setValue(datalist);
					scLoc.setConjunction(ConjunctionEnumJpe.AND);
				}
				if(vciForRemoval != null){
					row.getItem().remove(vciForRemoval);
				}
			}
		}
		return fc;
	}

	private boolean switchSource(FindCriteria findCriteria) {
		boolean shouldChangeSource = false;
		FindCriteriaJpe fc = null;
		if (findCriteria != null) {
			fc = jaxbSdoHelper.unwrap(findCriteria, true);
			List<ViewCriteriaRowJpe> rowList = fc.getFilter().getGroup();

			for (ViewCriteriaRowJpe row : rowList) {
				List<ViewCriteriaItemJpe> itemList = row.getItem();

				for (int i = itemList.size() - 1; i >= 0; i--) {
					ViewCriteriaItemJpe vci = itemList.get(i);
					if ("status".equals(vci.getAttribute()) && vci.getValue().get(0) != null) {
						String stat = vci.getValue().get(0).toString();
						if (stat != null) {
							if (stat.trim().equalsIgnoreCase("U")) {
								shouldChangeSource = true;
								break;
							}
						}
					}
				}
			}
		}
		return shouldChangeSource;
	}

	private AcctJpe getAccount(String acctNo) {
		AcctJpe acctJpe = null;
		Map<String, Object> param = new HashMap<String, Object>();
		param.put("acctNo", acctNo);
		List<AcctJpe> acctJpeList = dataService.findWithNamedQuery(DepJpeConstants.ACCT_JPE_FIND_BY_ACCTNO, param,
				AcctJpe.class);
		if (acctJpeList != null && acctJpeList.size() > 0) {
			acctJpe = acctJpeList.get(0);
		}
		return acctJpe;
	}

}
