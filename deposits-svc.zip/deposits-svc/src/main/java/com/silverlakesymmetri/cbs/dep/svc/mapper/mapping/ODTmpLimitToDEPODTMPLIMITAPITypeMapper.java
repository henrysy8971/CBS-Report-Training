package com.silverlakesymmetri.cbs.dep.svc.mapper.mapping;

import org.mapstruct.MapperConfig;
import org.mapstruct.Mapping;
import org.mapstruct.Mappings;

import com.silverlakesymmetri.cbs.commons.jpa.util.DateTimeHelper;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.OdTmpLimitJpe;
import com.silverlakesymmetri.cbs.dep.xmlapi.DEPODTMPLIMITAPIType;

@MapperConfig(uses={ DateTimeHelper.class})
public interface ODTmpLimitToDEPODTMPLIMITAPITypeMapper {

	@Mappings({
		@Mapping(source="acctNo", target ="ACCTNO"), 
		@Mapping(source="seqNo", target ="SEQNO"), 
		@Mapping(source="tmpLimitSeqNo", target ="TMPLIMITSEQNO"	), 
		@Mapping(source="priorityNo", target ="PRIORITYNO"	), 
		@Mapping(source="tmpLimitFromDate", target ="TMPLIMITFROMDATE",  qualifiedByName = {"DateTimeHelper","convertDateToCbsXmlApiDate"}), 
		@Mapping(source="tmpLimitToDate", target ="TMPLIMITTODATE",  qualifiedByName = {"DateTimeHelper","convertDateToCbsXmlApiDate"}),
		@Mapping(source="tmpLimitAmt", target ="TMPLIMITAMT"),
		@Mapping(source="status", target ="STATUS"), 
		@Mapping(source="narrative", target ="NARRATIVE"),
		@Mapping(source="markInd", target ="MARKIND"),
		@Mapping(source="purpose", target ="PURPOSE")
	 })
	public DEPODTMPLIMITAPIType mapOdTmpLimitToDEPODTMPLIMITAPIType(OdTmpLimitJpe  jpe);

}