package com.silverlakesymmetri.cbs.dep.svc.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.silverlakesymmetri.cbs.dep.bdo.sdo.Acct;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.SiDetail;
import com.silverlakesymmetri.cbs.dep.svc.AcctService;
import com.silverlakesymmetri.cbs.dep.svc.util.AcctHelper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mysema.query.types.EntityPath;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.jpa.entity.FindCriteriaJpe;
import com.silverlakesymmetri.cbs.commons.jpa.entity.ViewCriteriaItemJpe;
import com.silverlakesymmetri.cbs.commons.jpa.entity.ViewCriteriaJpe;
import com.silverlakesymmetri.cbs.commons.jpa.entity.ViewCriteriaRowJpe;
import com.silverlakesymmetri.cbs.commons.jpa.listener.Auditor;
import com.silverlakesymmetri.cbs.commons.svc.AbstractXmlApiBusinessService;
import com.silverlakesymmetri.cbs.commons.svc.BusinessObjectValidationCapable;
import com.silverlakesymmetri.cbs.commons.xmlapi.enums.CbsXmlApiOperation;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.SiHeader;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.AcctJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.QSiHeaderJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.SiHeaderJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.id.SiHeaderPk;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.util.DepJpeConstants;
import com.silverlakesymmetri.cbs.dep.svc.DepositsValidatorService;
import com.silverlakesymmetri.cbs.dep.svc.StandingInstructionService;
import com.silverlakesymmetri.cbs.dep.svc.mapper.StandingInstructionServiceMapper;
import com.silverlakesymmetri.cbs.dep.xmlapi.DEPSIDETAILAPIType;
import com.silverlakesymmetri.cbs.dep.xmlapi.DEPSIWRAPPERAPIType;


@Service
public class StandingInstructionServiceImpl extends 
									AbstractXmlApiBusinessService<SiHeader, SiHeaderJpe, SiHeaderPk,  DEPSIWRAPPERAPIType, DEPSIWRAPPERAPIType>  
									implements StandingInstructionService, BusinessObjectValidationCapable<SiHeader>{
	
	private static final String ACCT_NO = "acctNo";
	private static final String INTERNAL_KEY = "internalKey";

	@Autowired
	private AcctHelper acctHelper;

	@Autowired
	private AcctService acctService;
	
	@Autowired
	StandingInstructionServiceMapper mapper;
	
	@Autowired
    DepositsValidatorService depositsValidatorService;
	
	@Override
	protected DEPSIWRAPPERAPIType transformBdoToXmlApiRqCreate(SiHeader dataObject) {
		 return transformSiHeaderToDEPSIWRAPPERAPIType( dataObject, CbsXmlApiOperation.INSERT);
	}

	@Override
	protected DEPSIWRAPPERAPIType transformBdoToXmlApiRqUpdate(SiHeader dataObject) {
		return transformSiHeaderToDEPSIWRAPPERAPIType( dataObject, CbsXmlApiOperation.UPDATE);
	}

	@Override
	protected DEPSIWRAPPERAPIType transformBdoToXmlApiRqDelete(SiHeader dataObject) {
		return transformSiHeaderToDEPSIWRAPPERAPIType( dataObject, CbsXmlApiOperation.DELETE);
	}

	@Override
	protected SiHeader processXmlApiRs(SiHeader dataObject, DEPSIWRAPPERAPIType xmlApiRs) {
		SiHeaderJpe jpe = jaxbSdoHelper.unwrap(dataObject);
		jpe = mapper.mapToJpe(xmlApiRs, jpe);
		
		return jaxbSdoHelper.wrap(jpe);
	}

	@Override
	protected List<SiHeader> processXmlApiListRs(SiHeader dataObject, DEPSIWRAPPERAPIType xmlApiRs) {
		return null;
	}

	@Override
	protected Class<DEPSIWRAPPERAPIType> getXmlApiResponseClass() {
		return DEPSIWRAPPERAPIType.class;
	}

	@Override
	protected SiHeaderPk getIdFromDataObjectInstance(SiHeader dataObject) {
		SiHeaderJpe jpe = jaxbSdoHelper.unwrap(dataObject);
		return new SiHeaderPk(jpe.getInternalKey(), jpe.getSeqNo());
	}

	@Override
	protected EntityPath<SiHeaderJpe> getEntityPath() {
		return QSiHeaderJpe.siHeaderJpe;
	}

	@Override
	public SiHeader getByPk(String publicKey, SiHeader reference) {
		return super.getByPk(publicKey, reference);
	}

	@Override
	public SiHeader create(SiHeader siHeader) {
		return super.create(siHeader);
	}

	@Override
	public SiHeader update(SiHeader siHeader) {
		return super.update(siHeader);
	}

	@Override
	public boolean delete(SiHeader siHeader) {
		return super.delete(siHeader);
	}

	@Override
	protected SiHeader preCreateValidation(SiHeader dataObject) {
		final Map<String, Object> parameters = new HashMap<>();

		Acct acct = acctService.getByPk(dataObject.getAcctNo(), null);
		AcctJpe acctJpe = jaxbSdoHelper.unwrap(acct, true);
		parameters.put("internalKey", acctJpe.getInternalKey());

		Integer seqNo = dataService.getWithNamedQuery(DepJpeConstants.SIHEADERJPE_GET_MAX_SEQNO_BY_INTERNAL_KEY, parameters, Integer.class);
		if (seqNo != null) {
			dataObject.setSeqNo(seqNo);
			for (SiDetail siDetail: dataObject.getSiDetailList()) {
				siDetail.setSeqNo(seqNo);
			}
		}
		return super.preCreateValidation(dataObject);
	}

	@Override
	public List<SiHeader> query(int offset, int resultLimit, String groupBy, String order,
			Map<String, Object> filters) {

		if (filters.containsKey(ACCT_NO)) {
			String acctNo = (String) filters.get(ACCT_NO);
			Long internalKey = acctHelper.getInternalKeyByAcctNo(acctNo);
			filters.remove(ACCT_NO);
			filters.put(INTERNAL_KEY, internalKey);
		}
		return super.query(offset, resultLimit, groupBy, order, filters);
	}

	@Override
	public List<SiHeader> find(FindCriteria findCriteria, CbsHeader cbsHeader) {
		FindCriteriaJpe fcJpe = updateFC(findCriteria);
		FindCriteria fcBdo = jaxbSdoHelper.wrap(fcJpe, FindCriteria.class);
		return super.find(fcBdo, cbsHeader);
	}
	
	@Override
	public Long count(FindCriteria findCriteria, CbsHeader cbsHeader) {
		FindCriteriaJpe fcJpe = updateFC(findCriteria);
		return dataService.getRowCount(SiHeaderJpe.class, fcJpe);
	}

	@Override
	public Long getCount(Map<String, Object> filters) {
		return super.getRowCount(filters);
	}
		
	private DEPSIWRAPPERAPIType transformSiHeaderToDEPSIWRAPPERAPIType(SiHeader dataObject, CbsXmlApiOperation oper){
		
//		Map map = new HashMap();
//		CbsSessionContext sessionCtx = _ctxMngr.getContext(CbsSessionContext.class);
//		map.put(mapper.BRANCH, super.getUserBranch(sessionCtx.getUserCode()));
		
		SiHeaderJpe jpe = jaxbSdoHelper.unwrap(dataObject);
		DEPSIWRAPPERAPIType api =  mapper.mapToApi(jpe, oper);
		super.setTechColsFromDataObject(dataObject, api.getDEPSIREC());
		
		if (api.getDEPSILIST() == null || api.getDEPSILIST().getDEPSIDETAILAPI() == null ||
			api.getDEPSILIST().getDEPSIDETAILAPI().isEmpty()){
			return api;
		}
				
		for (DEPSIDETAILAPIType sd:  api.getDEPSILIST().getDEPSIDETAILAPI()){
			super.setTechColsFromDataObject(dataObject, sd);
		}
		
		return api;
	}
	
	@Autowired
	private Auditor auditor;
	
	protected SiHeader preCreateObject(SiHeader dataObject) {
		SiHeaderJpe jpe = unwrap(dataObject);
//		validateEntity(jpe);	
		auditor.prePersistCallback(jpe);
		return wrap(jpe);
	}
	
	private FindCriteriaJpe updateFC(FindCriteria findCriteria) {
		FindCriteriaJpe fc = null;
		String acctNo = null;
		if (findCriteria == null) {
			fc = new FindCriteriaJpe();
	        ViewCriteriaJpe rootViewCriteria = new ViewCriteriaJpe();
	        fc.setFilter(rootViewCriteria);
		} else {
			fc = jaxbSdoHelper.unwrap(findCriteria, true);
		}
		if (fc != null) {
			List<ViewCriteriaRowJpe> rowList = fc.getFilter().getGroup();
			for (ViewCriteriaRowJpe row : rowList) {
				List<ViewCriteriaItemJpe> itemList = row.getItem();

				for (int i = itemList.size() - 1; i >= 0; i--) {
					ViewCriteriaItemJpe vci = itemList.get(i);
					if ("acctNo".equals(vci.getAttribute()) && vci.getValue().get(0) != null) {
						acctNo = vci.getValue().get(0).toString();
						List<Object> datalist = new ArrayList<Object>();
						if (acctNo!=null){
							AcctJpe acctJpe = getAccount(acctNo);
							datalist.add(acctJpe.getInternalKey());
							vci.setAttribute("internalKey");
					        vci.setOperator("=");
					        vci.setValue(datalist);
							break;
						}
					}
				}
			}
		}
		return fc;
	}
	
	private AcctJpe getAccount(String acctNo){
		AcctJpe acctJpe = null;
		Map<String,Object> param = new HashMap<>();
		param.put("acctNo", acctNo);
		List<AcctJpe> acctJpeList = dataService.findWithNamedQuery(DepJpeConstants.ACCT_JPE_FIND_BY_ACCTNO, param, AcctJpe.class);
		if (acctJpeList!=null && !acctJpeList.isEmpty()){
			acctJpe = acctJpeList.get(0);
		}
		return acctJpe;
	}
	
	@Override
	public SiHeader validateCreateRequest(SiHeader dataObject) {
    	
		validateTransferAllowed(dataObject);
    	return super.validateCreateRequest(dataObject);
    }
	
	private void validateTransferAllowed(SiHeader dataObject){
		
		String returnCode = depositsValidatorService.isFinancialTransferAllowedByAcctNos(dataObject.getAcctNo(), dataObject.getBenfAcctNo());
	}
	
	
//	protected SiHeader preUpdateObject(SiHeader dataObject) {
//		SiHeaderJpe jpe = unwrap(dataObject);
////		validateEntity(jpe);
//		auditor.preUpdateCallback(jpe);
//		return wrap(jpe);
//	}
	
//	protected SiHeader preDeleteObject(SiHeader dataObject) {
//		SiHeaderJpe jpe = unwrap(dataObject);
//        removeVirtualAttributes(jpe);
//        auditor.auditDeleteOperation(jpe);
//		return dataObject;
//	}

}
