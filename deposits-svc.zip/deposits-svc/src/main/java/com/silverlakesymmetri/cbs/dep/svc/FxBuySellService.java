package com.silverlakesymmetri.cbs.dep.svc;

import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation;
import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation.ServiceOperationType;
import com.silverlakesymmetri.cbs.commons.svc.BusinessService;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.FxBuySell;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.FxBuySellJpe;

public interface FxBuySellService extends BusinessService<FxBuySell, FxBuySellJpe> {

    public static final String SVC_OP_NAME_FXBUYSELLSERVICE_POSTTRANSACTION = "FxBuySellService.postTransaction";
    public static final String SVC_OP_NAME_FXBUYSELLSERVICE_GET = "FxBuySellService.get";

    @ServiceOperation(name = SVC_OP_NAME_FXBUYSELLSERVICE_POSTTRANSACTION,  type = ServiceOperationType.CREATE)
    public FxBuySell postTransaction(FxBuySell dataObject);

    
    
    @ServiceOperation(name = SVC_OP_NAME_FXBUYSELLSERVICE_GET, type = ServiceOperationType.GET)
    public FxBuySell getByPk(String publicKey, FxBuySell reference);

}
