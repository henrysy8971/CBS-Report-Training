package com.silverlakesymmetri.cbs.dep.svc.impl;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.mysema.query.types.EntityPath;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.jpa.entity.FindCriteriaJpe;
import com.silverlakesymmetri.cbs.commons.svc.AbstractBusinessService;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.DeferredCap;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.DeferredCapJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.QDeferredCapJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.id.DeferredCapPk;
import com.silverlakesymmetri.cbs.dep.svc.DeferredCapService;

/**
 * Created by Emerson.Sanchez on 11/2/2021.
 */
@Service
@Transactional
public class DeferredCapServiceImpl extends AbstractBusinessService<DeferredCap, DeferredCapJpe, DeferredCapPk>
		implements DeferredCapService {

	@Override
	protected DeferredCapPk getIdFromDataObjectInstance(DeferredCap dataObject) {
		DeferredCapJpe jpe = jaxbSdoHelper.unwrap(dataObject);
		return new DeferredCapPk(jpe.getAcctType(), jpe.getCapDate());
	}

	@Override
	protected EntityPath<DeferredCapJpe> getEntityPath() {
		return QDeferredCapJpe.deferredCapJpe;
	}

	@Override
	public List<DeferredCap> query(int offset, int resultLimit, String groupBy, String order,
			Map<String, Object> filters) {
		return super.query(offset, resultLimit, groupBy, order, filters);
	}

	@Override
	public Long count(FindCriteria findCriteria, CbsHeader cbsHeader) {
		FindCriteriaJpe jpe = jaxbSdoHelper.unwrap(findCriteria, FindCriteriaJpe.class);
		return dataService.getRowCount(DeferredCapJpe.class, jpe);
	}

	@Override
	public List<DeferredCap> find(FindCriteria findCriteria, CbsHeader cbsHeader) {
		return super.find(findCriteria, cbsHeader);
	}
}
