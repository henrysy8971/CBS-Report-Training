package com.silverlakesymmetri.cbs.dep.svc.impl;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.mysema.query.types.EntityPath;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.jpa.entity.FindCriteriaJpe;
import com.silverlakesymmetri.cbs.commons.svc.AbstractBusinessService;
import com.silverlakesymmetri.cbs.commons.svc.BusinessObjectValidationCapable;
import com.silverlakesymmetri.cbs.commons.svc.ref.ReferenceNumberGeneratorService;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.ChqbkReg;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.ChqbkRegJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.QChqbkRegJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.id.ChqbkRegPk;
import com.silverlakesymmetri.cbs.dep.svc.ChqbkRegService;

@Service
@Transactional
public class ChqbkRegServiceImpl extends AbstractBusinessService<ChqbkReg, ChqbkRegJpe, ChqbkRegPk> implements ChqbkRegService,
	BusinessObjectValidationCapable<ChqbkReg> {

	private final static String DEP_CHQBK_REG = "DEP_CHQBK_REG_S";
	
	@Autowired
    private ReferenceNumberGeneratorService referenceNumberGeneratorService;
	
	@Override
	public Long count(FindCriteria findCriteria, CbsHeader cbsHeader) {
		FindCriteriaJpe jpe = jaxbSdoHelper.unwrap(findCriteria, FindCriteriaJpe.class);
        return dataService.getRowCount(ChqbkRegJpe.class, jpe);
	}

	@Override
	protected ChqbkRegPk getIdFromDataObjectInstance(ChqbkReg dataObject) {
		return new ChqbkRegPk(dataObject.getSeqNo());
	}

	@Override
	protected EntityPath<ChqbkRegJpe> getEntityPath() {
		return QChqbkRegJpe.chqbkRegJpe;
	}

	@Override
	public ChqbkReg create(ChqbkReg dataObject) {
		return super.create(dataObject);
	}

	@Override
	public ChqbkReg update(ChqbkReg dataObject) {
		return super.update(dataObject);
	}

	@Override
	public boolean delete(ChqbkReg dataObject) {
		return super.delete(dataObject);
	}

	@Override
	public List<ChqbkReg> query(int offset, int resultLimit, String groupBy, String order,
			Map<String, Object> filters) {
		return super.query(offset, resultLimit, groupBy, order, filters);
	}

	@Override
	public List<ChqbkReg> find(FindCriteria findCriteria, CbsHeader cbsHeader) {
		return super.find(findCriteria, cbsHeader);
	}

	@Override
	public ChqbkReg getByPk(String publicKey, ChqbkReg reference) {
		return super.getByPk(publicKey, reference);
	}

	@Override
	protected ChqbkReg preCreateValidation(ChqbkReg dataObject) {
		dataObject.setSeqNo(dataService.nextSequenceValue(DEP_CHQBK_REG).longValue());
		return super.preCreateValidation(dataObject);
	}

}
