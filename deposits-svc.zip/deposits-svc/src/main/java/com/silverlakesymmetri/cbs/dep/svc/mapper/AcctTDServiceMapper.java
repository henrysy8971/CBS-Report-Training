package com.silverlakesymmetri.cbs.dep.svc.mapper;

import com.silverlakesymmetri.cbs.commons.xmlapi.enums.CbsXmlApiOperation;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.Acct;
import com.silverlakesymmetri.cbs.dep.xmlapi.DEPTDAWRAPPERAPIType;


public interface AcctTDServiceMapper{
	

	public DEPTDAWRAPPERAPIType mapToApi(Acct bdo, CbsXmlApiOperation oper);
	
	public Acct mapToJpe(DEPTDAWRAPPERAPIType api, Acct bdo);
}
