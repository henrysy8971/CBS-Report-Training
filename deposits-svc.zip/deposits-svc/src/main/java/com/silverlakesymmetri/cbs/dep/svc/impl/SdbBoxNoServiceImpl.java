package com.silverlakesymmetri.cbs.dep.svc.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.mysema.query.types.EntityPath;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.jpa.util.DateTimeHelper;
import com.silverlakesymmetri.cbs.commons.svc.AbstractBusinessService;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.SdbInventory;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.QSdbInventoryJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.SdbInventoryJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.id.SdbInventoryPk;
import com.silverlakesymmetri.cbs.dep.svc.SdbBoxNoService;

@Service
@Transactional
public class SdbBoxNoServiceImpl extends AbstractBusinessService<SdbInventory, SdbInventoryJpe, SdbInventoryPk> implements SdbBoxNoService {
	
	@Autowired
	private DateTimeHelper dateTimeHelper;
	
	@Override
    public SdbInventory getByPk(String publicKey, SdbInventory reference) {
        return super.getByPk(publicKey, reference);
    }
	
	private static final String SDB_BOXNO_LOV_1 = "SELECT DISTINCT NEW com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.SdbInventoryJpe (rsi.boxNo, rsi.boxType, ref.valueDesc, rsi.sdbStatus, rsi.keyNo) "
											+" FROM "
											+"  SdbInventoryJpe rsi, "
											+"  SdbTypeJpe rst, "
											+"  RefCodeHdrJpe ref "
											+" WHERE "
											+"  rsi.branch LIKE :branch ";
	private static final String SDB_BOXNO_LOV_2 = "  AND rsi.branch = rst.branch "
											+"  AND rsi.boxType = rst.boxType "
											+"  AND rsi.sdbStatus LIKE :sdbStatus "
											+"  AND rsi.boxType = ref.valueS "
											+"  AND rsi.activeYn = true "
											+"  AND ref.metaType = 'REF_CODE' " 
											+"  AND ref.metaCode = 'RB_SDB_TYPE.BOX_TYPE' "
											+"  AND ref.activeYn = true "
											+"  AND rst.ccy LIKE :ccy "
											+"  AND rst.effectDate <=  :runDate "
											+"  AND rst.effectDate <= (SELECT MAX(rs.effectDate) "
											+"      FROM SdbTypeJpe rs "
											+"      WHERE "
											+"      rs.branch = :branch "
											+"      AND rs.ccy LIKE :ccy "
											+"      AND rs.effectDate <= :runDate "
											+"      ) "
											+" ORDER BY rsi.boxType DESC";

	
    @Override
    public List<SdbInventory> query(int offset, int resultLimit, String groupBy, String order, Map<String, Object> filters) {
    	
    	if (filters == null){
    		filters = new HashMap<String, Object>();
    	}
    	
    	StringBuilder criteria = new StringBuilder(SDB_BOXNO_LOV_1);
    	if (filters.containsKey("boxNo")){
    		
    		filters.put("boxNo", Long.parseLong((String) filters.get("boxNo")));
    		criteria.append("  AND rsi.boxNo = :boxNo");
    	}
    	criteria.append(SDB_BOXNO_LOV_2);
    	
    	if (!filters.containsKey("branch")){
    		filters.put("branch", "%");
    	}
    	
    	if (!filters.containsKey("ccy")){
    		filters.put("ccy", "%");
    	}
    	
    	if (!filters.containsKey("sdbStatus")){
    		filters.put("sdbStatus", "V");
    	}
    	
    	if (!filters.containsKey("runDate")){
    		filters.put("runDate", dateTimeHelper.getRunDate());
    	}
    	else{
    		filters.put("runDate", dateTimeHelper.getDate((String)filters.get("runDate")));
    	}
   
    	List<SdbInventoryJpe> jpeList = (List<SdbInventoryJpe>) dataService.findWithQuery(criteria.toString(), filters, offset, resultLimit, SdbInventoryJpe.class);
    	        
        List<SdbInventory> retList = new ArrayList<>();
		if (jpeList != null && jpeList.size() > 0) {
			for(SdbInventoryJpe jpe: jpeList){
				retList.add(jaxbSdoHelper.wrap(jpe, SdbInventory.class));				
			}
		}
		
		return retList;    	
    }

    @Override
    public List<SdbInventory> find(FindCriteria findCriteria, CbsHeader cbsHeader) {
        return super.find(findCriteria, cbsHeader);
    }


	@Override
	protected SdbInventoryPk getIdFromDataObjectInstance(SdbInventory dataObject) {
		// TODO Auto-generated method stub
		return new SdbInventoryPk(dataObject.getBranch(), dataObject.getBoxNo());
	}

	@Override
	protected EntityPath<SdbInventoryJpe> getEntityPath() {
		// TODO Auto-generated method stub
		return QSdbInventoryJpe.sdbInventoryJpe;
	}
	
}
