package com.silverlakesymmetri.cbs.dep.svc;

import java.io.Serializable;
import java.util.Map;

import com.silverlakesymmetri.cbs.commons.bdo.CbsBusinessDataObject;
import com.silverlakesymmetri.cbs.commons.jpa.entity.CbsBusinessDataObjectJpe;
import com.silverlakesymmetri.cbs.commons.svc.AbstractXmlApiBusinessService;
import com.silverlakesymmetri.cbs.commons.svc.util.CbsAsychronousTask;

public interface DepMessageQueueAsyncGenerationService<B extends CbsBusinessDataObject, E extends CbsBusinessDataObjectJpe, ID extends Serializable, XmlApiRq, XmlApiRs> extends CbsAsychronousTask<B> {

	public void initialize(
			AbstractXmlApiBusinessService<B, E, ID, XmlApiRq, XmlApiRs> generationService, 
			B bdoObject, 
			Map<String, Object> params);
}
