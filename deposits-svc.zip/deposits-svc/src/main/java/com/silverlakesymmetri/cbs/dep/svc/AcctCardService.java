package com.silverlakesymmetri.cbs.dep.svc;

import java.util.List;
import java.util.Map;

import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation;
import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation.ServiceOperationType;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.svc.BusinessService;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.AcctCard;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.AcctCardJpe;

public interface AcctCardService extends BusinessService<AcctCard, AcctCardJpe> {

    public static final String SVC_OP_NAME_ACCTCARDSERVICE_GET = "AcctCardService.get";
    public static final String SVC_OP_NAME_ACCTCARDSERVICE_QUERY = "AcctCardService.query";
    public static final String SVC_OP_NAME_ACCTCARDSERVICE_CREATE = "AcctCardService.create";
    public static final String SVC_OP_NAME_ACCTCARDSERVICE_UPDATE = "AcctCardService.update";
    public static final String SVC_OP_NAME_ACCTCARDSERVICE_DELETE = "AcctCardService.delete";
    public static final String SVC_OP_NAME_ACCTCARDSERVICE_FIND = "AcctCardService.find";

    @ServiceOperation(name = SVC_OP_NAME_ACCTCARDSERVICE_GET, type = ServiceOperationType.GET)
    public AcctCard getByPk(String publicKey, AcctCard reference);

    @ServiceOperation(name = SVC_OP_NAME_ACCTCARDSERVICE_CREATE)
    public AcctCard create(AcctCard dataObject);

    @ServiceOperation(name = SVC_OP_NAME_ACCTCARDSERVICE_UPDATE)
    public AcctCard update(AcctCard dataObject);

    @ServiceOperation(name = SVC_OP_NAME_ACCTCARDSERVICE_QUERY)
    public List<AcctCard> query(int offset, int resultLimit, String groupBy, String order, Map<String, Object> filters);

    @ServiceOperation(name = SVC_OP_NAME_ACCTCARDSERVICE_DELETE)
    public boolean delete(AcctCard dataObject);

    @ServiceOperation(name = SVC_OP_NAME_ACCTCARDSERVICE_FIND)
    public List<AcctCard> find(FindCriteria findCriteria, CbsHeader cbsHeader);

}
