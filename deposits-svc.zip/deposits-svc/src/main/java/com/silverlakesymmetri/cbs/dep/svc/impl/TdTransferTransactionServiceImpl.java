package com.silverlakesymmetri.cbs.dep.svc.impl;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Set;
import java.util.TreeSet;

import javax.mail.MessagingException;

import org.apache.commons.lang3.StringUtils;
import org.apache.velocity.VelocityContext;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mysema.query.types.EntityPath;
import com.silverlakesymmetri.cbs.commons.bdo.sdo.DmsFile;
import com.silverlakesymmetri.cbs.commons.context.CbsSessionContext;
import com.silverlakesymmetri.cbs.commons.exception.CbsRuntimeException;
import com.silverlakesymmetri.cbs.commons.exception.base.CbsServiceProcessException;
import com.silverlakesymmetri.cbs.commons.jpa.entity.CbsBpmInfoJpe;
import com.silverlakesymmetri.cbs.commons.jpa.mapping.sdo.enums.CommunicationChannelEnum;
import com.silverlakesymmetri.cbs.commons.logging.CbsAppLogger;
import com.silverlakesymmetri.cbs.commons.logging.CbsAppLoggerFactory;
import com.silverlakesymmetri.cbs.commons.notification.CbsMessageNotificationService;
import com.silverlakesymmetri.cbs.commons.svc.AbstractXmlApiBusinessService;
import com.silverlakesymmetri.cbs.commons.svc.BusinessObjectValidationCapable;
import com.silverlakesymmetri.cbs.commons.svc.LimitsCheckingCapable;
import com.silverlakesymmetri.cbs.commons.xmlapi.enums.CbsXmlApiOperation;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.Acct;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.AcctDashboardInfoBal;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.TdTransferTransaction;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.AcctJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.QTdTransferTransactionJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.TdTransferTransactionJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.id.TdTransferTransactionPk;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.util.DepJpeConstants;
import com.silverlakesymmetri.cbs.dep.svc.AcctDashboardInfoBalService;
import com.silverlakesymmetri.cbs.dep.svc.DepositsExpEmkService;
import com.silverlakesymmetri.cbs.dep.svc.DepositsValidatorService;
import com.silverlakesymmetri.cbs.dep.svc.TdTransferTransactionService;
//import com.silverlakesymmetri.cbs.dep.svc.DepositsValidatorService;
import com.silverlakesymmetri.cbs.dep.svc.mapper.TdTransferTransactionServiceMapper;
import com.silverlakesymmetri.cbs.dep.xmlapi.DEPTDPLACEMENTAPIType;
import com.silverlakesymmetri.cbs.lmt.util.ExpEmkObjectHolder;
import com.silverlakesymmetri.cbs.lmt.util.LimitsUtility;
import com.silverlakesymmetri.cbs.mcl.bdo.sdo.Client;
import com.silverlakesymmetri.cbs.mcl.bdo.sdo.ClientContact;
import com.silverlakesymmetri.cbs.mcl.svc.ClientService;
import com.silverlakesymmetri.cbs.xps.bdo.sdo.AdvicePreview;
import com.silverlakesymmetri.cbs.xps.svc.util.CbsDocumentTemplateBuilder;

/**
 * 
 * @author Jeffrey.Villanueva
 *
 */
@Service
public class TdTransferTransactionServiceImpl extends
		AbstractXmlApiBusinessService<TdTransferTransaction, TdTransferTransactionJpe, TdTransferTransactionPk,
                DEPTDPLACEMENTAPIType, DEPTDPLACEMENTAPIType> implements TdTransferTransactionService, BusinessObjectValidationCapable<TdTransferTransaction>,
        LimitsCheckingCapable<TdTransferTransaction> {

	private static final String TRAN_HIST_SEQ = "DEP_TRAN_HIST_S";

	@Autowired
	private TdTransferTransactionServiceMapper mapper;

    @Autowired
    private LimitsUtility limitsUtility;

    @Autowired
	private DepositsExpEmkService depositsExpEmkService;	
	
	@Autowired
    DepositsValidatorService depositsValidatorService;

	@Autowired
	protected ClientService clientService;

	@Autowired
	protected CbsDocumentTemplateBuilder documentTemplateBuilder;

	@Autowired
	protected CbsMessageNotificationService msgNotificationService;

	@Autowired
	protected AcctDashboardInfoBalService acctDashboardInfoBalService;

	protected static final String TEMPLATE_PROPERTIES = "templates/template-config.properties";
	protected static final String BALANCE_CONFIRMATION = "BalanceConfirmation";
	protected static final String BALANCE_CONFIRMATION_EMAIL = "BalanceConfirmationEmail";

	private static CbsAppLogger logger = CbsAppLoggerFactory.getLogger(TdTransferTransactionServiceImpl.class.getName());

	@Override
	public TdTransferTransaction create(TdTransferTransaction dataObject) {
		if(dataObject.getTranDate() == null){
			dataObject.setTranDate(dateTimeHelper.getSDODateTime(dateTimeHelper.getRunDate()));
		}
		TdTransferTransaction result = super.create(dataObject);
		/*try {
			sendDepositBookingConfirmation(dataObject);
		} catch (Exception e) {
			//do not allow notifications to interfere with processing
			logger.warn(e.getMessage());
		}*/
		return result;
    }

	@Override
	protected TdTransferTransaction preCreateValidation(TdTransferTransaction dataObject) {
		long seqNo = dataService.nextSequenceValue(TRAN_HIST_SEQ).longValue();
		dataObject.setSeqNo(seqNo);
		return super.preCreateValidation(dataObject);
	}

	@Override
	protected DEPTDPLACEMENTAPIType transformBdoToXmlApiRqCreate(TdTransferTransaction dataObject) {
		return tranformToDEPTDPLACEMENTAPIType(dataObject, CbsXmlApiOperation.INSERT);
	}

	private DEPTDPLACEMENTAPIType tranformToDEPTDPLACEMENTAPIType(TdTransferTransaction dataObject,
			CbsXmlApiOperation oper) {
		TdTransferTransactionJpe jpe = jaxbSdoHelper.unwrap(dataObject);
		
		Map otherInfo = new HashMap();
		CbsSessionContext sessionCtx = cbsRuntimeContextManager.getContext(CbsSessionContext.class);
		otherInfo.put("USERBRANCH", getUserBranch(sessionCtx.getUserCode()));
		
		Map<String, Object> param = new HashMap<String, Object>();
		param.put("acctNo", jpe.getAcctNo());
		AcctJpe acctJpe = dataService.getWithNamedQuery(DepJpeConstants.ACCT_JPE_FIND_BY_ACCTNO, param, AcctJpe.class);
		otherInfo.put("ACCT", acctJpe);
		
		DEPTDPLACEMENTAPIType apiType = mapper.mapToApi(jpe, oper, otherInfo);
		super.setTechColsFromDataObject(dataObject, apiType);
				
		if (apiType.getDRSCAPPLYIN() != null) {
			apiType.getDRSCAPPLYIN().setTRANVALIDATIONFLAGS(apiType.getTRANVALIDATIONFLAGS());
		}
		if (apiType.getCRSCAPPLYIN() != null) {
			apiType.getCRSCAPPLYIN().setTRANVALIDATIONFLAGS(apiType.getTRANVALIDATIONFLAGS());
		}
		return apiType;
	}

	@Override
	protected TdTransferTransaction processXmlApiRs(TdTransferTransaction dataObject, DEPTDPLACEMENTAPIType xmlApiRs) {
		TdTransferTransaction request = dataObject;
		//instead on unwrapping dataObject, create a new instance to reset publicKey
		//reason: debit is the first transaction made by api and crSeqNo will be internally generated by api further along the way
		//however, the main transaction is CR, so crSeqNo should be used as publickey
		//but since drSeqNo was the first created, and set to seqNo from preCreateValidation, this will be used as public key - which is incorrect
		//creating a new instance of jpe will reset this 
		TdTransferTransactionJpe jpe = new TdTransferTransactionJpe();
		mapper.mapToJpe(xmlApiRs, jpe);
		Number seqNo = xmlApiRs.getCRSEQNO();
		if (seqNo == null) {
			seqNo = xmlApiRs.getDRSEQNO();
		}
		if (seqNo != null) {
			jpe.setSeqNo(seqNo.longValue());	
		}
		dataObject = jaxbSdoHelper.wrap(jpe);
		dataObject.setTranDate(request.getTranDate());
		dataObject.setVirtualAttributeList(request.getVirtualAttributeList());
		return dataObject;
	}
	
	@Override
	protected DEPTDPLACEMENTAPIType transformBdoToXmlApiRqUpdate(TdTransferTransaction dataObject) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	protected DEPTDPLACEMENTAPIType transformBdoToXmlApiRqDelete(TdTransferTransaction dataObject) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	protected List<TdTransferTransaction> processXmlApiListRs(TdTransferTransaction dataObject,
			DEPTDPLACEMENTAPIType xmlApiRs) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	protected Class<DEPTDPLACEMENTAPIType> getXmlApiResponseClass() {
		return DEPTDPLACEMENTAPIType.class;
	}

	@Override
	protected TdTransferTransactionPk getIdFromDataObjectInstance(TdTransferTransaction dataObject) {
		return new TdTransferTransactionPk(1l);
	}

	@Override
	protected EntityPath<TdTransferTransactionJpe> getEntityPath() {
		return QTdTransferTransactionJpe.tdTransferTransactionJpe;
	}
	
	@Override
	public TdTransferTransaction validateCreateRequest(TdTransferTransaction dataObject) {
		
		validateTransferAllowed(dataObject);
		return super.validateCreateRequest(dataObject);
	}
	
	private void validateTransferAllowed(TdTransferTransaction dataObject){

		String returnCode = depositsValidatorService.isFinancialTransferAllowedByAcctNos(dataObject.getCpartyAcctNo(), dataObject.getAcctNo());
	}
	
    @Override
    public CbsBpmInfoJpe doCheckLimit(TdTransferTransaction dataObject) {
        ExpEmkObjectHolder expEmkObject = depositsExpEmkService.getLimitsDetails(dataObject,
                DepositsExpEmkServiceImpl.DEP_EVENT_TYPE, DepositsExpEmkServiceImpl.CR_AMT_TYPE);
        return limitsUtility.getLimitExceptionApprover(expEmkObject, dataObject);
    }

    @Override
    public TdTransferTransaction getLimitExceptions(TdTransferTransaction dataObject) {
        ExpEmkObjectHolder expEmkObject = depositsExpEmkService.getLimitsDetails(dataObject,
                DepositsExpEmkServiceImpl.DEP_EVENT_TYPE, DepositsExpEmkServiceImpl.CR_AMT_TYPE);
        return limitsUtility.getLimitExceptionDetails(expEmkObject, dataObject);
    }

	@Override
	public Long getEffectivityDate(TdTransferTransaction dataObject) {
		if (dataObject != null) {
			if (!StringUtils.isBlank(dataObject.getEffectDate())) {
				Date date = dateTimeHelper.getDate(dataObject.getEffectDate());
				if (date != null) {
					return dateTimeHelper.removeTime(date).getTime();
				}
			}
		}
		return null;
	}

    @Override
    public void validateApiRequest(TdTransferTransaction dataObject, DEPTDPLACEMENTAPIType xmlApiRq){
        try {
            String xmlApiReq = removeModifiedByAndModifiedDt(convertXmlApiRqToString(xmlApiRq));
            String xmlHeaderIn = convertXmlApiRqToString(createHeaderFromDataObject(dataObject));
            validate(dataObject, xmlApiReq, xmlHeaderIn);
        } catch (CbsRuntimeException cre) {
            throw cre;
        } catch (Exception e) {
            logger.error("Unhandled error encountered: {}", e.getMessage(), e);
            throw new RuntimeException(e);
        }
    }

	private void sendDepositBookingConfirmation(TdTransferTransaction dataObject){
		VelocityContext context = new VelocityContext();
		boolean useQrCode = true;
		Properties config = readTemplateConfigFile(TEMPLATE_PROPERTIES);

		//fill context with all related BDOs for this document
		Map<String, Object> parameters = new HashMap<String, Object>();
		parameters.put("acctNo", dataObject.getAcctNo());
		AcctJpe jpe = dataService.getWithNamedQuery(com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.util.DepJpeConstants.ACCT_JPE_FIND_BY_ACCTNO, parameters, AcctJpe.class);
		Acct bdo = jaxbSdoHelper.wrap(jpe);
		context.put("Acct", bdo);
		context.put("Tda", bdo.getTdaRec());
		context.put("IntDetail", bdo.getIntDetailRec());

		Client client = clientService.getByPk(bdo.getClientNo(), null);
		context.put("Client", client);
		ClientContact contact = clientService.getClientContactFromType(client.getClientNo(), "POSTAL", null);
		context.put("ClientContact", contact);
		AcctDashboardInfoBal acctDashboardInfoBal = acctDashboardInfoBalService.getByPk(dataObject.getAcctNo(), null);
		context.put("AcctDashboardInfoBal", acctDashboardInfoBal);

		//call template builder
		List<DmsFile> attachments = new ArrayList<DmsFile>();
		DmsFile balanceConfirmation = documentTemplateBuilder.convertTemplateToDocument(BALANCE_CONFIRMATION, context, null, false, dataObject.getAcctNo(), useQrCode);
		Map<String, String> messageContext = documentTemplateBuilder.convertTemplateToMessage(BALANCE_CONFIRMATION_EMAIL, context, null, false);
		attachments.add(balanceConfirmation);
		String mailAddress = clientService.getClientElectronicMailAddress(client.getClientNo());
		String emailSubject = messageContext.get("subject");
		if(config != null && config.getProperty("balanceConfirmationEmailSubject") != null){
			emailSubject = config.getProperty("balanceConfirmationEmailSubject");	
		}

		AdvicePreview mailPreview = jaxbSdoHelper.createSdoInstance(AdvicePreview.class);
		mailPreview.setRecipients(mailAddress);
		mailPreview.setMsgBody(messageContext.get("message"));
		mailPreview.setSubject(emailSubject);
		mailPreview.setDocument(BALANCE_CONFIRMATION);
		mailPreview.setAttachments(attachments);			

		try {
			msgNotificationService.sendNotificationMessage(CommunicationChannelEnum.MAIL, mailAddress, emailSubject, messageContext.get("message"), null, attachments);
			if(config.get("sendBalanceConfirmationSms") != null && Boolean.parseBoolean(config.getProperty("sendBalanceConfirmationSms"))){
				String phoneContact = getClientPhoneContact(client.getClientNo());
				if(phoneContact != null){
					Map<String, Object> templateParams = convertContextToMap(context);
					String smsMsg = msgNotificationService.getNotificationService().evaluateTemplate(config.get("balanceConfirmationSms").toString(), templateParams);
					msgNotificationService.sendNotificationMessage(CommunicationChannelEnum.SMS, phoneContact, null, smsMsg, null, null);
				}
			}
		} catch (MessagingException e) {
			msgNotificationService.logFailedNotification(BALANCE_CONFIRMATION+"-"+dataObject.getAcctNo(), CommunicationChannelEnum.MAIL, mailAddress, emailSubject, messageContext.get("message"), attachments);
		} catch (Exception e) {
			logger.info(e.getMessage());
		}

		
	}
	
	private Properties readTemplateConfigFile(String configFile){
        try {
        	Properties properties = new Properties() {
				private static final long serialVersionUID = 1L;
				@Override
				public Set<Object> keySet() {
				    return Collections.unmodifiableSet(new TreeSet<Object>(super.keySet()));
				}
        	};
			properties.load(this.getClass().getClassLoader().getResourceAsStream(configFile));
			return properties;
		} catch (IOException e) {
			throw new CbsRuntimeException("Unable to read configuration file: " + configFile);
		}
		
	}
    
    private Map<String, Object> convertContextToMap(VelocityContext context){
    	Map<String, Object> map = new HashMap<String, Object>();
    	for(String key : context.getKeys()){
    		map.put(key,  context.get(key));
    	}
    	return map;
    }

    private String getClientPhoneContact(String clientNo){
    	try {
			ClientContact contact = clientService.getClientContactFromType(clientNo, "PHONE", null);
			if(contact != null){
				return contact.getContactDetail();
			}
		} catch (CbsServiceProcessException e) {}
    	return null;
    }

}
