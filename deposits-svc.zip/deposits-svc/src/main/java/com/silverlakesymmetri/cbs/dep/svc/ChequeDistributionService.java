package com.silverlakesymmetri.cbs.dep.svc;

import java.util.List;
import java.util.Map;

import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation;
import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation.ServiceOperationType;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.svc.BusinessService;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.CiRdBunchDist;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.CiRdBunchDistJpe;

public interface ChequeDistributionService extends BusinessService<CiRdBunchDist, CiRdBunchDistJpe> {
	
	public static final String SVC_OP_NAME_CHEQUEDISTRIBUTIONSERVICE_GET 	= "ChequeDistributionService.get";
    public static final String SVC_OP_NAME_CHEQUEDISTRIBUTIONSERVICE_QUERY 	= "ChequeDistributionService.query";
    public static final String SVC_OP_NAME_CHEQUEDISTRIBUTIONSERVICE_UPDATE = "ChequeDistributionService.update";
    public static final String SVC_OP_NAME_CHEQUEDISTRIBUTIONSERVICE_FIND 	= "ChequeDistributionService.find";
    
    @ServiceOperation(name = SVC_OP_NAME_CHEQUEDISTRIBUTIONSERVICE_GET, type = ServiceOperationType.GET)
    public CiRdBunchDist getByPk(String publicKey, CiRdBunchDist reference);
    
    @ServiceOperation(name = SVC_OP_NAME_CHEQUEDISTRIBUTIONSERVICE_UPDATE)
    public CiRdBunchDist update(CiRdBunchDist objectInstanceIdentifier);
    
    @ServiceOperation(name = SVC_OP_NAME_CHEQUEDISTRIBUTIONSERVICE_QUERY)
    public List<CiRdBunchDist> query(int offset, int resultLimit, String groupBy, String order, Map<String, Object> filters);

    @ServiceOperation(name = SVC_OP_NAME_CHEQUEDISTRIBUTIONSERVICE_FIND)
    public List<CiRdBunchDist> find(FindCriteria findCriteria, CbsHeader cbsHeader);
		
}
