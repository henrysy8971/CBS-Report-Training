package com.silverlakesymmetri.cbs.dep.svc.impl;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mysema.query.types.EntityPath;
import com.silverlakesymmetri.cbs.commons.exception.base.CbsRuntimeException;
import com.silverlakesymmetri.cbs.commons.jpa.entity.CbsBpmInfoJpe;
import com.silverlakesymmetri.cbs.commons.logging.CbsAppLogger;
import com.silverlakesymmetri.cbs.commons.logging.CbsAppLoggerFactory;
import com.silverlakesymmetri.cbs.commons.svc.AbstractXmlApiBusinessService;
import com.silverlakesymmetri.cbs.commons.svc.LimitsCheckingCapable;
import com.silverlakesymmetri.cbs.commons.xmlapi.enums.CbsXmlApiOperation;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.BillTranHist;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.AcctJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.BillTranHistJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.QBillTranHistJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.TranDefJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.id.BillTranHistPk;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.util.DepJpeConstants;
import com.silverlakesymmetri.cbs.dep.svc.BillTranHistService;
import com.silverlakesymmetri.cbs.dep.svc.DepositsExpEmkService;
import com.silverlakesymmetri.cbs.dep.svc.mapper.BillTranHistServiceMapper;
import com.silverlakesymmetri.cbs.dep.xmlapi.DEPPAYBILLSAPIType;
import com.silverlakesymmetri.cbs.lmt.util.ExpEmkObjectHolder;
import com.silverlakesymmetri.cbs.lmt.util.LimitsUtility;

@Service
public class BillTranHistServiceImpl extends
		AbstractXmlApiBusinessService<BillTranHist, BillTranHistJpe, BillTranHistPk, DEPPAYBILLSAPIType, DEPPAYBILLSAPIType>
		implements BillTranHistService, LimitsCheckingCapable<BillTranHist> {

	private static final String DEP_TRAN_HIST = "DEP_TRAN_HIST_S";

	@Autowired
	BillTranHistServiceMapper mapper;

	@Autowired
	private DepositsExpEmkService depositsExpEmkService;

    @Autowired
    private LimitsUtility limitsUtility;
    
    private static CbsAppLogger logger = CbsAppLoggerFactory.getLogger(BillTranHistServiceImpl.class.getName());

	@Override
	protected BillTranHistPk getIdFromDataObjectInstance(BillTranHist dataObject) {
		return new BillTranHistPk(dataObject.getTranSeqNo());
	}

	@Override
	protected EntityPath<BillTranHistJpe> getEntityPath() {
		return QBillTranHistJpe.billTranHistJpe;
	}

	@SuppressWarnings("rawtypes")
	@Override
	protected DEPPAYBILLSAPIType transformBdoToXmlApiRqCreate(BillTranHist bdo) {
		BillTranHistJpe jpe = jaxbSdoHelper.unwrap(bdo);
		DEPPAYBILLSAPIType xmlApiRq = mapper.mapToApi(jpe, CbsXmlApiOperation.INSERT, new HashMap());
		if (xmlApiRq.getSCAPPLYIN() != null) {
			xmlApiRq.getSCAPPLYIN().setTRANVALIDATIONFLAGS(xmlApiRq.getTRANVALIDATIONFLAGS());
		}
		return xmlApiRq;
	}

	@Override
	public BillTranHist getByPk(String publicKey, BillTranHist reference) {
		return super.getByPk(publicKey, reference);
	}

	@Override
	protected DEPPAYBILLSAPIType transformBdoToXmlApiRqUpdate(BillTranHist dataObject) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	protected DEPPAYBILLSAPIType transformBdoToXmlApiRqDelete(BillTranHist dataObject) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	protected BillTranHist processXmlApiRs(BillTranHist dataObject, DEPPAYBILLSAPIType xmlApiRs) {
		BillTranHist bdo = jaxbSdoHelper.createSdoInstance(BillTranHist.class);
		BillTranHistJpe jpe = jaxbSdoHelper.unwrap(bdo);
		jpe = mapper.mapToJpe(xmlApiRs, jpe);
		return jaxbSdoHelper.wrap(jpe);
	}

	@Override
	protected List<BillTranHist> processXmlApiListRs(BillTranHist dataObject, DEPPAYBILLSAPIType xmlApiRs) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	protected Class<DEPPAYBILLSAPIType> getXmlApiResponseClass() {
		return DEPPAYBILLSAPIType.class;
	}

	@Override
	public BillTranHist create(BillTranHist dataObject) {
        dataObject = super.create(dataObject);
		return dataObject;
	}

    @Override
    public CbsBpmInfoJpe doCheckLimit(BillTranHist dataObject) {
        if (dataObject.getAccountNo() != null) {
            ExpEmkObjectHolder expEmkObject = getExpEmkObjectHolder(dataObject);
            return limitsUtility.getLimitExceptionApprover(expEmkObject, dataObject);
        }
        return null;
    }

    @Override
    public BillTranHist getLimitExceptions(BillTranHist dataObject) {
        ExpEmkObjectHolder expEmkObject = getExpEmkObjectHolder(dataObject);
        return limitsUtility.getLimitExceptionDetails(expEmkObject, dataObject);
    }

    private ExpEmkObjectHolder getExpEmkObjectHolder(BillTranHist dataObject){
        AcctJpe acctJpe = null;
        Map<String,Object> param = new HashMap<String, Object>();
        param.put("acctNo", dataObject.getAccountNo());
        List<AcctJpe> acctJpeList = dataService.findWithNamedQuery(DepJpeConstants.ACCT_JPE_FIND_BY_ACCTNO, param,
                AcctJpe.class);
        acctJpe = acctJpeList.get(0);
        ExpEmkObjectHolder expEmkObject = depositsExpEmkService.getLimitsDetails(dataObject, acctJpe,
                DepositsExpEmkServiceImpl.WHD_EVENT_TYPE, DepositsExpEmkServiceImpl.DR_AMT_TYPE);
        return expEmkObject;
    }

	@Override
	protected BillTranHist preCreateValidation(BillTranHist dataObject) {
		Map<String, Object> queryParams = new HashMap<String, Object>();
		queryParams.put("tranType", dataObject.getTranType());
		List<TranDefJpe> list = dataService.findWithNamedQuery(DepJpeConstants.TRAN_DEF_JPE_BY_TRAN_TYPE, queryParams, TranDefJpe.class);
		if (list != null && list.size() > 0) {
			String tranCode = list.get(0).getTranCode();
			// if Inst.Utility Payment Via Cash (4015) or Bills Payment by OBC (3311)
			if ("4015".equals(tranCode) || "3311".equals(tranCode)) {
				// set account number to null
				dataObject.setAccountNo(null);
			} else if ("4017".equals(tranCode)) {
				dataObject.setIssuerAcctNo(dataObject.getAccountNo());
				dataObject.setFloatDays(0);
			}
		}

		Long seqNo = dataService.nextSequenceValue(DEP_TRAN_HIST).longValue();
		dataObject.setTranSeqNo(seqNo);

		return super.preCreateValidation(dataObject);
	}

	@Override
	public Long getEffectivityDate(BillTranHist dataObject) {
		if (dataObject != null) {
			if (!StringUtils.isBlank(dataObject.getEffectDate())) {
				Date date = dateTimeHelper.getDate(dataObject.getEffectDate());
				if (date != null) {
					return dateTimeHelper.removeTime(date).getTime();
				}
			}
		}
		return null;
	}

    @Override
    public void validateApiRequest(BillTranHist dataObject, DEPPAYBILLSAPIType xmlApiRq){
        try {
            String xmlApiReq = removeModifiedByAndModifiedDt(convertXmlApiRqToString(xmlApiRq));
            String xmlHeaderIn = convertXmlApiRqToString(createHeaderFromDataObject(dataObject));
            validate(dataObject, xmlApiReq, xmlHeaderIn);
        } catch (CbsRuntimeException cre) {
            throw cre;
        } catch (Exception e) {
            logger.error("Unhandled error encountered: {}", e.getMessage(), e);
            throw new RuntimeException(e);
        }
    }

}
