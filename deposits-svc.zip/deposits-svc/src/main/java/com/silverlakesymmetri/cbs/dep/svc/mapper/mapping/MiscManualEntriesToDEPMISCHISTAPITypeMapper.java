package com.silverlakesymmetri.cbs.dep.svc.mapper.mapping;

import com.silverlakesymmetri.cbs.commons.jpa.util.DateTimeHelper;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.MiscManualEntriesJpe;
import com.silverlakesymmetri.cbs.dep.xmlapi.DEPMISCHISTAPIType;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Mappings;

@Mapper(uses = {DateTimeHelper.class})
public interface MiscManualEntriesToDEPMISCHISTAPITypeMapper {

    @Mappings({
            @Mapping(source = "tellerId", target = "TELLERID"),
            @Mapping(source = "wsId", target = "WSID"),
            @Mapping(source = "glCode", target = "GLCODE"),
            @Mapping(source = "branch", target = "BRANCH"),
            @Mapping(source = "tranType", target = "TRANTYPE"),
            @Mapping(source = "tranAmt", target = "TRANAMT"),
            @Mapping(source = "tranDate", target = "TRANDATE", qualifiedByName = {"DateTimeHelper","convertDateToCbsXmlApiDate"}),
            @Mapping(source = "effectDate", target = "EFFECTDATE", qualifiedByName = {"DateTimeHelper","convertDateToCbsXmlApiDate"}),
            @Mapping(source = "ccy", target = "CCY"),
            @Mapping(source = "overrideOfficer", target = "OVERRIDEOFFICER"),
            @Mapping(source = "sourceModule", target = "SOURCEMODULE"),
            @Mapping(source = "journalSeq", target = "JOURNALSEQ"),
            @Mapping(source = "narrative", target = "NARRATIVE"),
            @Mapping(source = "profitCentre", target = "PROFITCENTRE"),
            @Mapping(source = "seqNo", target = "TXNSEQNO")
    })
    public DEPMISCHISTAPIType mapMiscManualEntriesToDEPMISCHISTAPITypeMapper(MiscManualEntriesJpe jpe);
}
