package com.silverlakesymmetri.cbs.dep.svc.mapper.decorator;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

import com.silverlakesymmetri.cbs.commons.xmlapi.enums.CbsXmlApiOperation;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.CiSettlementJpe;
import com.silverlakesymmetri.cbs.dep.svc.mapper.CiSettlementBuyServiceMapper;
import com.silverlakesymmetri.cbs.dep.xmlapi.DEPCIPROCESSSETTLEBUYAPIType;
                                                                    
public abstract class CiSettlementBuyServiceDecorator extends FeeServiceDecorator implements CiSettlementBuyServiceMapper{
		
	@Autowired
	@Qualifier("delegate")
	protected  CiSettlementBuyServiceMapper delegate;
		
	@Override
	public DEPCIPROCESSSETTLEBUYAPIType mapToApi(CiSettlementJpe jpe, CbsXmlApiOperation oper, Map otherInfo){
		
		DEPCIPROCESSSETTLEBUYAPIType req = (DEPCIPROCESSSETTLEBUYAPIType)delegate.mapToApi(jpe, oper, otherInfo);
		mapFeeToApi(jpe, req);
		return  req;
	}
	
	@Override
	public CiSettlementJpe mapToJpe(DEPCIPROCESSSETTLEBUYAPIType api, CiSettlementJpe jpe){
		
		if (jpe == null){
			jpe = new CiSettlementJpe();
		}
		
		if (api == null){
			return jpe;
		}
		
		delegate.mapToJpe(api, jpe);
			
		return jpe;
	}
	

}


