package com.silverlakesymmetri.cbs.dep.svc.ext;

import com.silverlakesymmetri.cbs.xps.svc.util.ReleaseAcctRestraintCapable;
import org.springframework.stereotype.Service;

import com.silverlakesymmetri.cbs.commons.logging.CbsAppLogger;
import com.silverlakesymmetri.cbs.commons.logging.CbsAppLoggerFactory;

@Service
public class ImportLcAcctRestraintCreateServiceExtImpl extends AbstractTfnAcctRestraintServiceExtImpl implements ReleaseAcctRestraintCapable {

	private static CbsAppLogger logger = CbsAppLoggerFactory.getLogger(ImportLcAcctRestraintCreateServiceExtImpl.class.getName());
	
    @Override
    public String[] getExtendedBdoNames() {
        return new String[] { "ImportLc" };
    }

    @Override
    public String[] getExtendedServiceNames() {
        return new String[] {"ImportLcService.create"};
    }

    protected CbsAppLogger getLogger() {
    	return logger;
    }
}
