package com.silverlakesymmetri.cbs.dep.svc.impl;

import java.util.*;

import com.silverlakesymmetri.cbs.commons.exception.base.CbsServiceProcessException;
import com.silverlakesymmetri.cbs.commons.exception.base.helper.ExceptionHelper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mysema.query.types.EntityPath;
import com.mysema.query.types.OrderSpecifier;
import com.mysema.query.types.Predicate;
import com.mysema.query.types.expr.BooleanExpression;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.jpa.entity.FindCriteriaJpe;
import com.silverlakesymmetri.cbs.commons.jpa.entity.ViewCriteriaItemJpe;
import com.silverlakesymmetri.cbs.commons.jpa.entity.ViewCriteriaJpe;
import com.silverlakesymmetri.cbs.commons.jpa.entity.ViewCriteriaRowJpe;
import com.silverlakesymmetri.cbs.commons.logging.CbsAppLogger;
import com.silverlakesymmetri.cbs.commons.logging.CbsAppLoggerFactory;
import com.silverlakesymmetri.cbs.commons.svc.AbstractXmlApiBusinessService;
import com.silverlakesymmetri.cbs.commons.svc.BusinessObjectValidationCapable;
import com.silverlakesymmetri.cbs.commons.xmlapi.enums.CbsXmlApiOperation;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.AcctRestraint;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.RestraintType;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.AcctJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.AcctRestraintJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.QAcctRestraintJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.RestraintTypeJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.id.AcctRestraintPk;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.util.DepJpeConstants;
import com.silverlakesymmetri.cbs.dep.svc.AcctRestraintService;
import com.silverlakesymmetri.cbs.dep.svc.RestraintTypeService;
import com.silverlakesymmetri.cbs.dep.svc.mapper.AcctRestraintServiceMapper;
import com.silverlakesymmetri.cbs.dep.xmlapi.DEPRESTRAINTSAPIType;

@Service
public class AcctRestraintServiceImpl extends AbstractXmlApiBusinessService<AcctRestraint, AcctRestraintJpe, AcctRestraintPk, DEPRESTRAINTSAPIType, DEPRESTRAINTSAPIType> implements AcctRestraintService, BusinessObjectValidationCapable<AcctRestraint>{
    private CbsAppLogger logger = CbsAppLoggerFactory.getLogger(AcctRestraintServiceImpl.class.getName());
	public static final String A = "Active";
	public static final String F = "Future Dated";
	public static final String D = "History";
	public String status = "";

	private static final String CANNOT_DELETE_INTERNAL_RESTRAINT = "CBS.B.DEP.ACCT_RESTRAINT_SERVICE.0005";

	@Autowired 
	AcctRestraintServiceMapper mapper;
	
	@Autowired
	private RestraintTypeService restraintTypeService;
	
	@Override
	protected EntityPath<AcctRestraintJpe> getEntityPath() {
		return QAcctRestraintJpe.acctRestraintJpe;
	}
	
	@Override
	protected AcctRestraintPk getIdFromDataObjectInstance(AcctRestraint dataObject) {
		return new AcctRestraintPk(dataObject.getSeqNo());
	}
	
	@Override
	public AcctRestraint getByPk(String publicKey, AcctRestraint reference) {
		AcctRestraint acctRestraint = super.getByPk(publicKey, reference);
		processRestraintInfo(acctRestraint);
		processPledgedAcctInfo(acctRestraint);
		return acctRestraint;
	}
	
	@Override
	public AcctRestraint create(AcctRestraint dataObject) {
		RestraintType restraintType = restraintTypeService.getByPk(dataObject.getRestraintType(), null);
		if (restraintType != null) {
			dataObject.setRestraintClass(restraintType.getRestraintClass());
		}
		AcctJpe acctJpe = getAccount(dataObject.getAcctNo());
		if (acctJpe != null) {
			dataObject.setInternalKey(acctJpe.getInternalKey());
			dataObject.setCertificateNo(acctJpe.getCertificateNo());
		}
		if(dataObject.getRestraintClass() != null && dataObject.getRestraintClass().equals("FH") && dataObject.getPledgedAcctNo() != null) {
			AcctJpe acctJpe2 = getAccount(dataObject.getPledgedAcctNo());
			dataObject.setPledgedAcctType(acctJpe2.getAcctType());
		}
		return super.create(dataObject);
	}
	
	public AcctRestraint preCreateValidation(AcctRestraint dataObject) {
		return super.preCreateValidation(dataObject);
	}
	
	public AcctRestraint preUpdateValidation(AcctRestraint dataObject) {
		if(dataObject.getRestraintClass() != null && dataObject.getRestraintClass().equals("FH") && dataObject.getPledgedAcctNo() != null) {
			AcctJpe acctJpe = getAccount(dataObject.getPledgedAcctNo());
			dataObject.setPledgedAcctType(acctJpe.getAcctType());
		}
		RestraintType restraintType = restraintTypeService.getByPk(dataObject.getRestraintType(), null);
		dataObject.setRestraintClass(restraintType.getRestraintClass());
		return super.preUpdateValidation(dataObject);
	}

	@Override
	protected AcctRestraint preDeleteValidation(AcctRestraint dataObject) {
		Collection<Throwable> exceptions = new ArrayList<Throwable>();

		if(dataObject.getRestraintType() != null) {
			RestraintType restraintType = restraintTypeService.getByPk(dataObject.getRestraintType(), null);
			if (restraintType.getInternalYn() != null && restraintType.getInternalYn()) {
				String msg = messageUtils.getMessage(CANNOT_DELETE_INTERNAL_RESTRAINT, new String[]{"restraintType"});
				CbsServiceProcessException exec = new CbsServiceProcessException(CANNOT_DELETE_INTERNAL_RESTRAINT, msg);
				exceptions.add(exec);

				if (exceptions != null && exceptions.size() > 0) {
					ExceptionHelper.createAndThrowAggregateException(exceptions);
				}
			}
		}

		return dataObject;
	}
	
	@Override
	public AcctRestraint update(AcctRestraint dataObject) {
		return super.update(dataObject);
	}

	@Override
	public AcctRestraint removeRestraint(AcctRestraint dataObject) {
		preDeleteValidation(dataObject);
		return super.update(dataObject);
	}

	@Override
	public void validateApiExecuteRequest(AcctRestraint dataObject, String svcOperationName) {
		if (dataObject.getDateLifted() != null && "removeRestraint".equals(svcOperationName)) {
			super.validateApiUpdateRequest(dataObject);
			super.validateApiExecuteRequest(dataObject, svcOperationName);
		}
	}

	@Override
	public boolean delete(AcctRestraint dataObject) {
		return super.delete(dataObject);
	}

	@Override
	public List<AcctRestraint> query(int offset, int resultLimit, String groupBy, String order, Map<String, Object> filters) {
		String acctNo = null;
		String stat = null;
		List<AcctRestraint> acctRestraintList = null;
		
		if (filters != null && filters.get("acctNo") != null) {
			acctNo = filters.get("acctNo").toString();
			filters.remove("acctNo");
		}
		if (filters != null && filters.get("status") != null) {
			stat = filters.get("status").toString();
			filters.remove("status");
			if(A.equals(stat) || "A".equals(stat)) {
				status = "A";
			}else if(F.equals(stat) || "F".equals(stat)) {
				status = "F";
			}else if(D.equals(stat) || "D".equals(stat)) {
				status = "D";
			}
			filters.put("status", status);
		}
		
		AcctJpe acctJpe = getAccount(acctNo);
		if (acctJpe == null) {
			return acctRestraintList;
		}
		
		if (acctNo != null) {
			acctRestraintList = customQuery(offset, resultLimit, order, filters, acctNo);
		} else {
			acctRestraintList = super.query(offset, resultLimit, groupBy, order, filters);	
		}
		return processRestraintList(acctRestraintList);
	}
	
	@Override
	public List<AcctRestraint> find(FindCriteria findCriteria, CbsHeader cbsHeader) {
		FindCriteriaJpe fcJpe = updateFC(findCriteria);
		FindCriteria fcBdo = jaxbSdoHelper.wrap(fcJpe, FindCriteria.class);
		List<AcctRestraint> acctRestraintList = super.find(fcBdo, cbsHeader);
		return processRestraintList(acctRestraintList);
	}
	
	@Override
	public Long count(FindCriteria findCriteria, CbsHeader cbsHeader) {
		FindCriteriaJpe fcJpe = updateFC(findCriteria);
		return dataService.getRowCount(AcctRestraintJpe.class, fcJpe);
	}

	@Override
	public Long getCount(Map<String, Object> filters) {
		return super.getRowCount(filters);
	}

	@Override
	protected Class<DEPRESTRAINTSAPIType> getXmlApiResponseClass() {
		return DEPRESTRAINTSAPIType.class;
	}

	@Override
	protected AcctRestraint processXmlApiRs(AcctRestraint dataObject, DEPRESTRAINTSAPIType xmlApiRs) {
		//dataObject.setSeqNo((xmlApiRs!=null && xmlApiRs.getREFERENCENO()!=null)?Long.parseLong(xmlApiRs.getREFERENCENO()):dataObject.getSeqNo());
		
		AcctRestraintJpe jpe = jaxbSdoHelper.unwrap(dataObject, true);
		mapper.mapToJpe(xmlApiRs, jpe);
		dataObject = jaxbSdoHelper.wrap(jpe);
		if (dataObject.getSeqNo() == null) {
			dataObject.setSeqNo((xmlApiRs!=null && xmlApiRs.getREFERENCENO()!=null)?Long.parseLong(xmlApiRs.getREFERENCENO()):dataObject.getSeqNo());
		}
		
		return dataObject;
	}

	@Override
	protected DEPRESTRAINTSAPIType transformBdoToXmlApiRqCreate(AcctRestraint dataObject) {
		return transformAcctRestraintToDEPRESTRAINTSAPIType(dataObject, CbsXmlApiOperation.INSERT);
	}

	@Override
	protected DEPRESTRAINTSAPIType transformBdoToXmlApiRqDelete(AcctRestraint dataObject) {
		return transformAcctRestraintToDEPRESTRAINTSAPIType(dataObject, CbsXmlApiOperation.DELETE);
	}

	@Override
	protected DEPRESTRAINTSAPIType transformBdoToXmlApiRqUpdate(AcctRestraint dataObject) {
		if(dataObject.getDateLifted() != null) {
			return transformAcctRestraintToDEPRESTRAINTSAPIType(dataObject, CbsXmlApiOperation.DELETE);
		}else {
			return transformAcctRestraintToDEPRESTRAINTSAPIType(dataObject, CbsXmlApiOperation.UPDATE);
		}
	}
	
	private DEPRESTRAINTSAPIType transformAcctRestraintToDEPRESTRAINTSAPIType(AcctRestraint dataObject, CbsXmlApiOperation oper){
		
		Map map = new HashMap();
		AcctRestraintJpe jpe = jaxbSdoHelper.unwrap(dataObject);
		DEPRESTRAINTSAPIType apiType = mapper.mapToApi(jpe, oper, map);
		
		super.setTechColsFromDataObject(dataObject, apiType);
		
		if (CbsXmlApiOperation.INSERT.equals(oper)){
			if ("AS".equals(dataObject.getRestraintClass()) || "SW".equals(dataObject.getRestraintClass())) {
				if(apiType.getSCAPPLYIN() != null) {
					apiType.getSCAPPLYIN().setFORCEDPOST("Y");
				}
			}
		}
		
		if ("FH".equals(dataObject.getRestraintClass())){
			apiType.setPLEDGEDAMT((dataObject.getPledgedAmt()!=null)?dataObject.getPledgedAmt():0);
			apiType.setPLEDGEDACCTNO(dataObject.getPledgedAcctNo());		
		}
		if ("SC".equals(dataObject.getRestraintClass())){
			apiType.setSTARTCHEQUENO(dataObject.getStartChequeNo());
			apiType.setENDCHEQUENO(dataObject.getEndChequeNo());
		}
		
		if (CbsXmlApiOperation.DELETE.equals(oper) || CbsXmlApiOperation.UPDATE.equals(oper)){
			if ("AS".equals(dataObject.getRestraintClass()) || "SW".equals(dataObject.getRestraintClass())) {
				if(apiType.getSCAPPLYIN() != null) {
					apiType.getSCAPPLYIN().setFORCEDPOST("Y");
				}
			}
		} 
		return apiType;
	}
	
	private AcctJpe getAccount(String acctNo){
		AcctJpe acctJpe = null;
		Map<String,Object> param = new HashMap<String, Object>();
		param.put("acctNo", acctNo);
		List<AcctJpe> acctJpeList = dataService.findWithNamedQuery(DepJpeConstants.ACCT_JPE_FIND_BY_ACCTNO, param, AcctJpe.class);
		if (acctJpeList!=null && acctJpeList.size()>0){
			acctJpe = acctJpeList.get(0);
		}
		return acctJpe;
	}

	@Override
	protected List<AcctRestraint> processXmlApiListRs(AcctRestraint dataObject, DEPRESTRAINTSAPIType xmlApiRs) {
		return null;
	}
	
	private List<AcctRestraint> processRestraintList(List<AcctRestraint> acctRestraintList){
		if (acctRestraintList!=null){
			for (AcctRestraint acctRestraint : acctRestraintList){
				processRestraintInfo(acctRestraint);
			}
		}
		return acctRestraintList;
	}
	
	private void processRestraintInfo(AcctRestraint acctRestraint){
		Map<String,Object> param = new HashMap<String,Object>();
		param.put("restraintType", acctRestraint.getRestraintType());
		List<RestraintTypeJpe> restraintTypeList = dataService.findWithNamedQuery(DepJpeConstants.RESTRAINT_TYPE_JPE_FIND_BY_RESTRAINT_TYPE, param, RestraintTypeJpe.class);
		if (restraintTypeList!=null && restraintTypeList.size()>0){
			RestraintTypeJpe restraintType = restraintTypeList.get(0);
			acctRestraint.setRestraintClass(restraintType.getRestraintClass());
			acctRestraint.setRestraintDesc(restraintType.getRestraintDesc());
		}
	}
	
	private void processPledgedAcctInfo(AcctRestraint acctRestraint){
		if ("FH".equals(acctRestraint.getRestraintClass()) && acctRestraint.getPledgedAcctNo()!=null){
			AcctJpe acctJpe = getAccount(acctRestraint.getPledgedAcctNo());
			acctRestraint.setPledgedAcctType(acctJpe.getAcctType());
			acctRestraint.setPledgedAcctDesc(acctJpe.getAcctDesc());
		}
	}
	
	/**
	 * [CBS9D-13565] Default end date to to_date('01/01/2999','DD/MM/YYYY') if null
	 * @param acctRestraint
	 */
	@SuppressWarnings("unused")
	private void defaultEndDt(AcctRestraint acctRestraint){
		if (acctRestraint!=null && (acctRestraint.getEndDate()==null || acctRestraint.getEndDate().isEmpty())){
			Calendar cal = Calendar.getInstance();
			cal.set(2999, 0, 1);
			AcctRestraintJpe acctRestraintJpe = unwrap(acctRestraint);
			acctRestraintJpe.setEndDate(cal.getTime());
			acctRestraint = wrap(acctRestraintJpe);
		}
	}
	
	private List<AcctRestraint> customQuery(int offset, int resultLimit, String order, Map<String, Object> filters, String acctNo) {
		final List<OrderSpecifier<?>> orders = getOrderSpecifier(QAcctRestraintJpe.acctRestraintJpe, null, order);
		Predicate predicate = convertMapToPredicate(filters, acctNo);
		return super.query(QAcctRestraintJpe.acctRestraintJpe, offset, resultLimit, predicate, orders);
	}
	
	private Predicate convertMapToPredicate(Map<String, Object> filters, String acctNo) {
		Predicate predicate = convertMapToPredicate(QAcctRestraintJpe.acctRestraintJpe, filters);
		BooleanExpression booleanExpr = null;
		if (acctNo!=null) {
			AcctJpe acctJpe = getAccount(acctNo);
			if (acctJpe != null) {
				booleanExpr = QAcctRestraintJpe.acctRestraintJpe.internalKey.eq(acctJpe.getInternalKey());
			}
		} 
		if (predicate != null) {
			predicate = ((BooleanExpression) predicate).and(booleanExpr);	
		} else {
			predicate = booleanExpr;
		}
		return predicate;
	}
	
	private FindCriteriaJpe updateFC(FindCriteria findCriteria) {
		FindCriteriaJpe fc = null;
		String acctNo = null;
		String stat = null;
		if (findCriteria == null) {
			fc = new FindCriteriaJpe();
	        ViewCriteriaJpe rootViewCriteria = new ViewCriteriaJpe();
	        fc.setFilter(rootViewCriteria);
		} else {
			fc = jaxbSdoHelper.unwrap(findCriteria, true);
		}
		if (fc != null) {
			List<ViewCriteriaRowJpe> rowList = fc.getFilter().getGroup();
			for (ViewCriteriaRowJpe row : rowList) {
				List<ViewCriteriaItemJpe> itemList = row.getItem();

				for (int i = itemList.size() - 1; i >= 0; i--) {
					ViewCriteriaItemJpe vci = itemList.get(i);
					if ("acctNo".equals(vci.getAttribute()) && vci.getValue().get(0) != null) {
						acctNo = vci.getValue().get(0).toString();
						List<Object> datalist = new ArrayList<Object>();
						if (acctNo!=null){
							AcctJpe acctJpe = getAccount(acctNo);
							datalist.add(acctJpe.getInternalKey());
							vci.setAttribute("internalKey");
					        vci.setOperator("=");
					        vci.setValue(datalist);
							break;
						}
					}
					
					if ("status".equals(vci.getAttribute()) && vci.getValue().get(0) != null) {
						stat = vci.getValue().get(0).toString();
						List<Object> datalist = new ArrayList<Object>();
						if (stat!=null){
							if(stat.equals(A)) {
								status = "A";
							}else if(stat.equals(F)) {
								status = "F";
							}else if(stat.equals(D)) {
								status = "D";
							}
							datalist.add(status);
							vci.setAttribute("status");
					        vci.setOperator("=");
					        vci.setValue(datalist);
                                                vci.setUpperCaseCompareYn(false);
							break;
						}
					}
				}
			}
		}
		return fc;
	}
	
}
