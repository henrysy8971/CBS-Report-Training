package com.silverlakesymmetri.cbs.dep.svc.mapper.mapping;

import org.mapstruct.MapperConfig;
import org.mapstruct.Mapping;
import org.mapstruct.Mappings;

import com.silverlakesymmetri.cbs.commons.jpa.util.DateTimeHelper;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.OnlineIntCapJpe;
import com.silverlakesymmetri.cbs.dep.xmlapi.DEPACCTINTCAPAPIType;

@MapperConfig(uses={ DateTimeHelper.class})
public interface OnlineIntCapToDEPACCTINTCAPAPITypeMapper {
	

	@Mappings({
		@Mapping(target ="ACCTNO", source="acctNo"), 
		@Mapping(target ="PAYMENTOPTION", source="paymentOption"), 
		@Mapping(target ="CRINTACCRUED", source="crIntAccr"), 
		@Mapping(target ="CRINTACCRUEDWTAX", source="crIntAccrTax"), 
		@Mapping(target ="CRINTADJ", source="crIntAdj"), 
		@Mapping(target ="CRINTADJWTAX", source="crIntAdjTax"), 
		@Mapping(target ="DRINTACCRUED", source="drIntAccr"), 
		@Mapping(target ="DRINTAUTHACCRUED", source="drIntAuthAccr"), 
		@Mapping(target ="DRINTUNAUTHACCRUED", source="drIntUnauthAccr"), 
		@Mapping(target ="DRINTADJ", source="drIntAdj"), 
		@Mapping(target ="DRINTAUTHADJ", source="drIntAuthAdj"), 
		@Mapping(target ="DRINTUNAUTHADJ", source="drIntUnauthAdj"), 
	 })
	public DEPACCTINTCAPAPIType mapOnlineIntCapToDEPACCTINTCAPAPIType(OnlineIntCapJpe jpe);
	
}



