package com.silverlakesymmetri.cbs.dep.svc;

import java.util.Date;

import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation;
import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation.ServiceOperationType;

/**
 * 
 * @author Jeffrey.Villanueva
 *
 */
public interface DepTDStorUtilService {

	public static final String SVC_OP_NAME_CALC_FD_MAT_DATE = "DepTDStorUtilService.calcFdMatDate";
	public static final String SVC_OP_NAME_ENQUIRE_RATE = "DepTDStorUtilService.enquireRate";

	@ServiceOperation(name = SVC_OP_NAME_CALC_FD_MAT_DATE, type = ServiceOperationType.GET)
	public String calcFdMatDate(Integer freqPeriod, String freqType, Integer freqDay, String ccy, String clientNo, String branch, Date runDate);

	@ServiceOperation(name = SVC_OP_NAME_ENQUIRE_RATE, type = ServiceOperationType.GET)
	public Double enquireRate(Date effectDate, String intType, String ccy, Double balance, Long freqPeriod,
			String freqType, String crIntRateInd);

}
