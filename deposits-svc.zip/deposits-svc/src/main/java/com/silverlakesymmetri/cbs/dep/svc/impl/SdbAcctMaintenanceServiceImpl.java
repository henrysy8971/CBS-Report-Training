package com.silverlakesymmetri.cbs.dep.svc.impl;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javax.persistence.TypedQuery;

import com.silverlakesymmetri.cbs.commons.bdo.sdo.RefCodeHdr;
import com.silverlakesymmetri.cbs.commons.svc.RefCodeService;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.mysema.query.types.EntityPath;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.context.CbsSessionContext;
import com.silverlakesymmetri.cbs.commons.helper.jpa.LinkTable;
import com.silverlakesymmetri.cbs.commons.helper.jpa.QueryCondition;
import com.silverlakesymmetri.cbs.commons.helper.jpa.QueryType;
import com.silverlakesymmetri.cbs.commons.jpa.entity.FindCriteriaJpe;
import com.silverlakesymmetri.cbs.commons.jpa.service.CbsEntityManagerAware;
import com.silverlakesymmetri.cbs.commons.jpa.types.StructureBasisTypeObject;
import com.silverlakesymmetri.cbs.commons.svc.AbstractXmlApiBusinessService;
import com.silverlakesymmetri.cbs.commons.svc.ref.RefNoGenStructService;
import com.silverlakesymmetri.cbs.commons.svc.ref.ReferenceNumberGeneratorService;
import com.silverlakesymmetri.cbs.commons.xmlapi.enums.CbsXmlApiOperation;
import com.silverlakesymmetri.cbs.constants.CommonsConstants;
import com.silverlakesymmetri.cbs.csd.bdo.sdo.ProdScIndividual;
import com.silverlakesymmetri.cbs.csd.xmlapi.CSDPRODSCINDIVIDUALAPIType;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.SdbAcct;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.DepFeeApplyJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.QSdbAcctJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.SdbAcctJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.SdbAssigneeJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.SdbInventoryJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.SdbLicenseeJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.id.SdbAcctPk;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.util.DepJpeConstants;
import com.silverlakesymmetri.cbs.dep.svc.SdbAcctMaintenanceService;
import com.silverlakesymmetri.cbs.dep.svc.mapper.SdbAcctMaintenanceServiceMapper;
import com.silverlakesymmetri.cbs.dep.xmlapi.DEPFEEAPPLYDTLINTType;
import com.silverlakesymmetri.cbs.dep.xmlapi.DEPFEEAPPLYINType;
import com.silverlakesymmetri.cbs.dep.xmlapi.DEPPRODSCMAINTFEEAPIType;
import com.silverlakesymmetri.cbs.dep.xmlapi.DEPSDBASSIGNEEAPIType;
import com.silverlakesymmetri.cbs.dep.xmlapi.DEPSDBLICENSEEAPIType;
import com.silverlakesymmetri.cbs.dep.xmlapi.DEPSDBWRAPPERAPIType;
import com.silverlakesymmetri.cbs.mcl.jpa.mapping.sdo.ClientGlobalIdJpe;
import com.silverlakesymmetri.cbs.mcl.jpa.mapping.sdo.ClientJpe;
import com.silverlakesymmetri.cbs.mcl.jpa.mapping.sdo.util.MclJpeConstants;

@Service
@Transactional
public class SdbAcctMaintenanceServiceImpl extends
		AbstractXmlApiBusinessService<SdbAcct, SdbAcctJpe, SdbAcctPk, DEPSDBWRAPPERAPIType, DEPSDBWRAPPERAPIType>
		implements SdbAcctMaintenanceService, RefNoGenStructService<SdbAcct> {

	private static final String CBS_CHANNEL_CODE = "CBS";
	private static final String CBS_CHANNEL_SOURCE = "HTTP-UI";
	private static final String IS_FROM_LOV = "isFromLOV";
	private static LinkedHashMap<String, LinkTable> constructorMap;
	private static QueryCondition condition;

	static {
		constructorMap = new LinkedHashMap<String, LinkTable>();
		constructorMap.put("contractNo", new LinkTable(SdbAcctJpe.class));
		constructorMap.put("clientNo", new LinkTable(ClientJpe.class));
		constructorMap.put("contractDesc", new LinkTable(SdbAcctJpe.class));
		constructorMap.put("clientInd", new LinkTable(SdbAcctJpe.class));
		constructorMap.put("branch", new LinkTable(SdbAcctJpe.class));
		constructorMap.put("boxNo", new LinkTable(SdbAcctJpe.class));
		constructorMap.put("status", new LinkTable(SdbAcctJpe.class));
		constructorMap.put("productCode", new LinkTable(SdbAcctJpe.class));
		constructorMap.put("ccy", new LinkTable(SdbAcctJpe.class));
		constructorMap.put("dateOpen", new LinkTable(SdbAcctJpe.class));
		constructorMap.put("startDate", new LinkTable(SdbAcctJpe.class));
		constructorMap.put("closeDate", new LinkTable(SdbAcctJpe.class));
		constructorMap.put("withLicensees", new LinkTable(SdbAcctJpe.class));
		constructorMap.put("withAssignees", new LinkTable(SdbAcctJpe.class));
		constructorMap.put("depositAcct", new LinkTable(SdbAcctJpe.class));
		constructorMap.put("depositAcctNo", new LinkTable(SdbAcctJpe.class));
		constructorMap.put("depositCertificateNo", new LinkTable(SdbAcctJpe.class));
		constructorMap.put("siAcctNo", new LinkTable(SdbAcctJpe.class));
		constructorMap.put("rentalFeeAcctNo", new LinkTable(SdbAcctJpe.class));
		constructorMap.put("oldAcctNo", new LinkTable(SdbAcctJpe.class));
		constructorMap.put("oldCertificateNo", new LinkTable(SdbAcctJpe.class));
		condition = new QueryCondition();
		condition.where("clientId", QueryType.EQUALS, new LinkTable(ClientJpe.class, "clientId")).and("clientId",
				QueryType.EQUALS, new LinkTable(SdbAcctJpe.class, "clientId"));
	}

	@Autowired
	SdbAcctMaintenanceServiceMapper mapper;

	@Autowired
	private ReferenceNumberGeneratorService referenceNumberGeneratorService;

	@Autowired
	RefCodeService refCodeService;

	@Override
	protected DEPSDBWRAPPERAPIType transformBdoToXmlApiRqCreate(SdbAcct dataObject) {
		return transformSdbAcctToDEPSDBWRAPPERAPIType(dataObject, CbsXmlApiOperation.INSERT);
	}

	@Override
	protected DEPSDBWRAPPERAPIType transformBdoToXmlApiRqUpdate(SdbAcct dataObject) {
		return transformSdbAcctToDEPSDBWRAPPERAPIType(dataObject, CbsXmlApiOperation.UPDATE);
	}

	@Override
	protected DEPSDBWRAPPERAPIType transformBdoToXmlApiRqDelete(SdbAcct dataObject) {
		return transformSdbAcctToDEPSDBWRAPPERAPIType(dataObject, CbsXmlApiOperation.DELETE);
	}

	@Override
	protected SdbAcct processXmlApiRs(SdbAcct dataObject, DEPSDBWRAPPERAPIType xmlApiRs) {
		if (xmlApiRs != null && xmlApiRs.getDEPSDBACCTREC() != null) {
			Number sdbinternalkey = xmlApiRs.getDEPSDBACCTREC().getSDBINTERNALKEY();
			if (sdbinternalkey != null) {
				SdbAcctJpe sdbAcctJpe = dataService.find(SdbAcctJpe.class, new SdbAcctPk(sdbinternalkey.longValue()));
				return jaxbSdoHelper.wrap(sdbAcctJpe, SdbAcct.class);
			}
		}
		/*
		if (dataObject != null) {
			SdbAcctJpe jpe = jaxbSdoHelper.unwrap(dataObject);
			SdbAcctJpe jpeRs = mapper.mapToJpe(xmlApiRs, jpe);
			if (jpeRs != null) {
				SdbAcct response = jaxbSdoHelper.wrap(jpeRs, SdbAcct.class);
				if (response != null) {
					return response;
				}
			}
		}
		*/
		return dataObject;
	}

	@Override
	protected List<SdbAcct> processXmlApiListRs(SdbAcct dataObject, DEPSDBWRAPPERAPIType xmlApiRs) {
		return null;
	}

	@Override
	protected Class<DEPSDBWRAPPERAPIType> getXmlApiResponseClass() {
		return DEPSDBWRAPPERAPIType.class;
	}

	@Override
	protected SdbAcctPk getIdFromDataObjectInstance(SdbAcct dataObject) {
		SdbAcctJpe jpe = jaxbSdoHelper.unwrap(dataObject);
		return new SdbAcctPk(jpe.getSdbInternalKey());
	}

	@Override
	protected EntityPath<SdbAcctJpe> getEntityPath() {
		return QSdbAcctJpe.sdbAcctJpe;
	}

	@Override
	public SdbAcct getByPk(String publicKey, SdbAcct reference) {
		if ("new".equals(publicKey)) {
			return super.getByPk(publicKey, reference);
		} else {
			SdbAcct dataObject = super.getByPk(publicKey, reference);
			if (dataObject == null) return dataObject;
			SdbAcctJpe jpe = jaxbSdoHelper.unwrap(dataObject);
			SdbInventoryJpe sdbInventoryJpe = this.getSdbInventoryJpe(jpe.getBranch(), jpe.getBoxNo());
			if (sdbInventoryJpe != null) {
				jpe.setBoxType(sdbInventoryJpe.getBoxType());
				jpe.setBoxStatus(sdbInventoryJpe.getSdbStatus());
			}
			ClientJpe clientJpe = this.getClientJpe(jpe.getClientId());
			if (clientJpe != null) {
				jpe.setClientShort(clientJpe.getClientShort());
				if (clientJpe.getClientGlobalIdList() != null && clientJpe.getClientGlobalIdList().size() > 0) {
					for (ClientGlobalIdJpe globalId : clientJpe.getClientGlobalIdList()) {
						if ("ALL".equals(globalId.getDefaultFlag())) {
							jpe.setGlobalIdType(globalId.getGlobalIdType());
							jpe.setGlobalId(globalId.getGlobalId());
							break;
						}
					}
				}
			}
			SdbAcct bdo = jaxbSdoHelper.wrap(jpe, SdbAcct.class);
			RefCodeHdr refCodeHdr = refCodeService.find("RB_SDB_ACCT.STATUS", "status", bdo.getStatus());
			bdo.setStatusDesc(refCodeHdr.getValueDesc());
			return bdo;
		}
	}

	@Override
	public SdbAcct create(SdbAcct acct) {
		acct = super.create(acct);
		return acct;
	}

	@Override
	public SdbAcct update(SdbAcct acct) {
		return super.update(acct);
	}

	@Override
	public boolean delete(SdbAcct acct) {
		return super.delete(acct);
	}

	@Override
	public List<SdbAcct> query(int offset, int resultLimit, String groupBy, String order, Map<String, Object> filters) {
		if (filters.containsKey(IS_FROM_LOV)) {
			filters.remove(IS_FROM_LOV);
			List<SdbAcct> resultList = new ArrayList<>();
			resultList = getAllSdbAcctThin(offset, resultLimit, groupBy, order, filters);
			return resultList;
		}
		QueryCondition newCondition = convertFilters(condition, filters, constructorMap);
		List<SdbAcct> list = super.query(newCondition, offset, resultLimit, groupBy, order, constructorMap);
		if (list != null && list.size() > 0) {
			for (SdbAcct bdo : list) {
				SdbAcct temp = getByPk(bdo.getContractNo(), bdo);
				if (temp != null) {
					bdo.setSdbLicenseeList(temp.getSdbLicenseeList());
					bdo.setSdbAssigneeList(temp.getSdbAssigneeList());
					bdo.setDepFeeApplyList(temp.getDepFeeApplyList());
					bdo.setProdScDefRec(temp.getProdScDefRec());
					bdo.setProdScIndividualList(temp.getProdScIndividualList());
					bdo.setProdScMaintFeeList(temp.getProdScMaintFeeList());
				}
			}
		}
		return list;
	}

	@Override
	public List<SdbAcct> find(FindCriteria findCriteria, CbsHeader cbsHeader) {
		List<SdbAcct> list = super.find(findCriteria, cbsHeader, constructorMap, condition);
		if (list != null && list.size() > 0) {
			for (SdbAcct bdo : list) {
				SdbAcct temp = getByPk(bdo.getContractNo(), bdo);
				if (temp != null) {
					bdo.setSdbLicenseeList(temp.getSdbLicenseeList());
					bdo.setSdbAssigneeList(temp.getSdbAssigneeList());
					bdo.setDepFeeApplyList(temp.getDepFeeApplyList());
					bdo.setProdScDefRec(temp.getProdScDefRec());
					bdo.setProdScIndividualList(temp.getProdScIndividualList());
					bdo.setProdScMaintFeeList(temp.getProdScMaintFeeList());
				}
			}
		}
		return list;
	}

	@Override
	public Long count(FindCriteria findCriteria, CbsHeader cbsHeader) {
		FindCriteriaJpe jpe = jaxbSdoHelper.unwrap(findCriteria, FindCriteriaJpe.class);
		return dataService.getRowCount(SdbAcctJpe.class, jpe, constructorMap, condition);
	}

	private DEPSDBWRAPPERAPIType transformSdbAcctToDEPSDBWRAPPERAPIType(SdbAcct dataObject, CbsXmlApiOperation oper) {

		SdbAcctJpe jpe = jaxbSdoHelper.unwrap(dataObject);

		if (jpe != null && jpe.getClientId() != null) {
			jpe.setClientId(this.getClientId(jpe.getClientNo()));
		}

		DEPSDBWRAPPERAPIType api = mapper.mapToApi(jpe, oper);
		super.setTechColsFromDataObject(dataObject, api.getDEPSDBACCTREC());

		// TODO: temporary fix - remove this when Cash payment is available
		if (api.getDEPSDBACCTREC() != null && api.getDEPSDBACCTREC().getSCAPPLYIN() != null) {
			DEPFEEAPPLYINType feeApplyIn = api.getDEPSDBACCTREC().getSCAPPLYIN();
			if (feeApplyIn.getSCDETAILIN() != null && feeApplyIn.getSCDETAILIN().getDEPFEEAPPLYDTLINT() != null) {
				for (DEPFEEAPPLYDTLINTType fee : feeApplyIn.getSCDETAILIN().getDEPFEEAPPLYDTLINT()) {
					fee.setSCPAYMENTMODE("A");
				}
			}
		}

		if (api.getDEPSDBASSIGNEEINDTLS() == null || api.getDEPSDBASSIGNEEINDTLS().getDEPSDBASSIGNEEAPI() == null
				|| api.getDEPSDBASSIGNEEINDTLS().getDEPSDBASSIGNEEAPI().isEmpty()) {
		} else {
			for (DEPSDBASSIGNEEAPIType assignee : api.getDEPSDBASSIGNEEINDTLS().getDEPSDBASSIGNEEAPI()) {
				super.setTechColsFromDataObject(dataObject, assignee);
			}
		}

		if (api.getDEPSDBLICENSEEINDTLS() == null || api.getDEPSDBLICENSEEINDTLS().getDEPSDBLICENSEEAPI() == null
				|| api.getDEPSDBLICENSEEINDTLS().getDEPSDBLICENSEEAPI().isEmpty()) {
		} else {
			for (DEPSDBLICENSEEAPIType licensee : api.getDEPSDBLICENSEEINDTLS().getDEPSDBLICENSEEAPI()) {
				super.setTechColsFromDataObject(dataObject, licensee);
			}
		}

		if (api.getCSDPRODSCDEFREC() != null) {
			super.setTechColsFromDataObject(dataObject, api.getCSDPRODSCDEFREC());
		}

		if (api.getCSDPRODSCINDIVIDUALLIST() == null
				|| api.getCSDPRODSCINDIVIDUALLIST().getCSDPRODSCINDIVIDUALAPI() == null
				|| api.getCSDPRODSCINDIVIDUALLIST().getCSDPRODSCINDIVIDUALAPI().isEmpty()) {
		} else {
			for (CSDPRODSCINDIVIDUALAPIType prodScInd : api.getCSDPRODSCINDIVIDUALLIST().getCSDPRODSCINDIVIDUALAPI()) {
				super.setTechColsFromDataObject(dataObject, prodScInd);
			}
		}

		if (api.getDEPPRODSCMAINTFEELIST() == null || api.getDEPPRODSCMAINTFEELIST().getDEPPRODSCMAINTFEEAPI() == null
				|| api.getDEPPRODSCMAINTFEELIST().getDEPPRODSCMAINTFEEAPI().isEmpty()) {
		} else {
			for (DEPPRODSCMAINTFEEAPIType scMaintFee : api.getDEPPRODSCMAINTFEELIST().getDEPPRODSCMAINTFEEAPI()) {
				super.setTechColsFromDataObject(dataObject, scMaintFee);
			}
		}

		return api;
	}

	@Override
	protected SdbAcct preCreateValidation(SdbAcct dataObject) {

		//if (StringUtils.isBlank(dataObject.getContractNo())) { //allow database procedure to validate the structured refNo value
			referenceNumberGeneratorService.getNewRefNo(dataObject, "contractNo", this);
		//}

		if (dataObject.getProdScIndividualList() != null) {
			for (ProdScIndividual prodScIndividual : dataObject.getProdScIndividualList()) {
				if (StringUtils.isBlank(prodScIndividual.getProdScIndvlRefNo())) {
					referenceNumberGeneratorService.getNewRefNo(prodScIndividual, "prodScIndvlRefNo");
				}
			}
		}

		SdbAcctJpe jpe = jaxbSdoHelper.unwrap(dataObject, SdbAcctJpe.class);
		long internalKey = dataService.nextSequenceValue("PIM_MASTER_ACCOUNT_S").longValue();
		jpe.setSdbInternalKey(internalKey);
		jpe.setKeyDepPaidInd(NO);

		for (SdbLicenseeJpe l : jpe.getSdbLicenseeList()) {
			l.setSdbInternalKey(internalKey);
			l.setToContact(YES);
			if (l.getClientId() == null) {
				l.setClientId(this.getClientId(l.getClientNo()));
			}
		}

		for (SdbAssigneeJpe a : jpe.getSdbAssigneeList()) {
			a.setSdbInternalKey(internalKey);
			if (a.getClientId() == null) {
				a.setClientId(this.getClientId(a.getClientNo()));
			}
		}

		// why? params during fee posting should be changed accordingly
		for (DepFeeApplyJpe df : jpe.getDepFeeApplyList()) {
			df.setAcctNo(jpe.getRentalFeeAcctNo());
			df.setProdNo(jpe.getContractNo());
			df.setProdSubType("S");
		}

		setOtherFields(jpe);
		dataObject = jaxbSdoHelper.wrap(jpe);
		return super.preCreateValidation(dataObject);

	}

	protected SdbAcct preUpdateValidation(SdbAcct dataObject) {

		if (dataObject.getProdScIndividualList() != null) {
			for (ProdScIndividual prodScIndividual : dataObject.getProdScIndividualList()) {
				if (StringUtils.isBlank(prodScIndividual.getProdScIndvlRefNo())) {
					referenceNumberGeneratorService.getNewRefNo(prodScIndividual, "prodScIndvlRefNo");
				}
			}
		}

		SdbAcctJpe jpe = jaxbSdoHelper.unwrap(dataObject, SdbAcctJpe.class);

		for (SdbLicenseeJpe l : jpe.getSdbLicenseeList()) {
			if (l.getSdbInternalKey() == null) {
				l.setSdbInternalKey(dataObject.getSdbInternalKey());
			}
			if (l.getClientId() == null) {
				l.setClientId(this.getClientId(l.getClientNo()));
			}
			l.setToContact(YES);
		}

		for (SdbAssigneeJpe a : jpe.getSdbAssigneeList()) {
			if (a.getSdbInternalKey() == null) {
				a.setSdbInternalKey(dataObject.getSdbInternalKey());
			}
			if (a.getClientId() == null) {
				a.setClientId(this.getClientId(a.getClientNo()));
			}
		}

		setOtherFields(jpe);
		dataObject = jaxbSdoHelper.wrap(jpe);
		return super.preUpdateValidation(dataObject);

	}

	private static final String YES = "Y";
	private static final String NO = "N";

	private void setOtherFields(SdbAcctJpe jpe) {
		jpe.setWithAssignees(NO);
		jpe.setWithLicensees(NO);
		if (jpe.getSdbAssigneeList() != null && !jpe.getSdbAssigneeList().isEmpty()) {
			jpe.setWithAssignees(YES);
		}
		if (jpe.getSdbLicenseeList() != null && jpe.getSdbLicenseeList().size() >= 2) {
			jpe.setWithLicensees(YES);
		}
		if (jpe.getProdScDefRec() != null) {
			jpe.getProdScDefRec().setProdKey(jpe.getSdbInternalKey());
			jpe.getProdScDefRec().setProdNo(jpe.getContractNo());
		}
	}

	private ClientJpe getClientJpe(Long clientId) {
		Map<String, Object> parameters = new HashMap<String, Object>();
		parameters.put("clientId", clientId);
		List<ClientJpe> list = dataService.findWithNamedQuery(MclJpeConstants.CLIENT_JPE_GET_CLIENT_FROM_ID, parameters,
				ClientJpe.class);
		if (list != null && list.size() > 0) {
			return list.get(0);
		}
		return null;
	}

	private SdbInventoryJpe getSdbInventoryJpe(String branch, Long boxNo) {
		Map<String, Object> parameters = new HashMap<String, Object>();
		parameters.put("branch", branch);
		parameters.put("boxNo", boxNo);
		List<SdbInventoryJpe> list = dataService.findWithNamedQuery(DepJpeConstants.SDB_INVENTORY_JPE_BY_BRANCH_BOX_NO, parameters,
				SdbInventoryJpe.class);
		if (list != null && list.size() > 0) {
			return list.get(0);
		}
		return null;
	}

	private Long getClientId(String clientNo) {
		Map<String, Object> params = new HashMap<String, Object>();
		params.put("clientNo", clientNo);
		List<Long> list = dataService.findWithNamedQuery(MclJpeConstants.CLIENT_JPE_FIND_CLIENT_ID_USING_CLIENT_NO, params,
				Long.class);
		if (list != null && list.size() > 0) {
			return list.get(0);
		}
		return null;
	}

	private String getRegistryValue(String attr) {
		String result = cbsRuntimeContextManager.getBestAvailableContext()
				.getRegistryEntry(CommonsConstants.CUT_REGISTRY, attr, String.class);
		return result;
	}

	/*
	private void createMasterAccount(SdbAcct dataObject) {
		SdbAcctJpe jpe = jaxbSdoHelper.unwrap(dataObject, SdbAcctJpe.class);
		MasterAccountJpe masterAccountJpe = new MasterAccountJpe();
		masterAccountJpe.setAccountId(jpe.getSdbInternalKey());
		masterAccountJpe.setAccountNo(jpe.getContractNo());
		masterAccountJpe.setCcy(jpe.getCcy());
		masterAccountJpe.setDomain("SDB_DEPOSIT");

		String ownerCodeOur = getRegistryValue("ownerCodeOur");
		if (ownerCodeOur == null) {
			ownerCodeOur = "CBS";
		}

		masterAccountJpe.setDataOwnerCode(ownerCodeOur);
		masterAccountJpe.setProductCode("SDB_DEPOSIT");
		masterAccountJpe.setClientNoOwner(jpe.getClientNo());
		masterAccountJpe.setBranch(jpe.getBranch());
		masterAccountJpe.setAccountDesc(jpe.getContractDesc());
		masterAccountJpe.setAccountAlias(jpe.getContractDesc());
		masterAccountJpe.setRegisteredDt(jpe.getDateOpen());
		masterAccountJpe.setLastRefreshDt(jpe.getDateOpen());
		masterAccountJpe.setActiveYn(true);
		masterAccountJpe.setStartDt(jpe.getStartDate());
		masterAccountJpe.setEndDt(jpe.getRenewDate());
		// masterAccountJpe.setProfitCentre(acct.getRenewDate());

		dataService.create(masterAccountJpe);
	}
	*/

	public List<SdbAcct> getAllSdbAcctThin(int offset, int resultLimit, String groupBy, String order, Map<String, Object> filters) {

		if (offset < 0) offset = 0;
		if (resultLimit < 0 || resultLimit > 50) resultLimit = 50;

		if (StringUtils.isBlank(groupBy)) {
			groupBy = "contractNo";
		} else {
			try {
				SdbAcctJpe.class.getDeclaredField(groupBy);
			} catch (NoSuchFieldException e) {
				e.printStackTrace();
				groupBy = null;
			} catch (SecurityException e) {
				e.printStackTrace();
				groupBy = null;
			}
		}

		final List<SdbAcct> sdoResult = new ArrayList<SdbAcct>();

		StringBuilder queryString = new StringBuilder();
		queryString.append(" SELECT NEW com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.SdbAcctJpe ")
				   .append(" ( a.contractNo, c.clientNo, a.contractDesc, a.clientInd, a.branch, a.boxNo ")
				   .append(" , a.status, a.productCode, a.ccy, a.dateOpen, a.startDate, a.closeDate ")
				   .append(" , a.withLicensees, a.withAssignees, a.depositAcct, a.depositAcctNo ")
				   .append(" , a.depositCertificateNo, a.siAcctNo, a.rentalFeeAcctNo, a.oldAcctNo, a.oldCertificateNo ) ")
				   .append(" FROM SdbAcctJpe a, ClientJpe c ")
				   .append(" WHERE a.clientId = c.clientId ");

		if (filters != null && !filters.isEmpty()) {
			for (Map.Entry<String, Object> entry : filters.entrySet()) {
				if ("excludeStatusList".equals(entry.getKey())) {
					String excludeStatusStr = (String) entry.getValue();
					if (!StringUtils.isEmpty(excludeStatusStr)) {
						List<String> list = new ArrayList<String>(Arrays.asList(excludeStatusStr.split(",")));
						StringBuilder b = new StringBuilder();
						int index = 0;
						for (String status : list) {
							b.append(index > 0 ? "," : "").append("'").append(status).append("'");
							index++;
						}
						queryString.append(" AND a.status NOT IN (").append(b).append(") ");
					}
				} else if ("includeStatusList".equals(entry.getKey())) {
					String includeStatusStr = (String) entry.getValue();
					if (!StringUtils.isEmpty(includeStatusStr)) {
						List<String> list = new ArrayList<String>(Arrays.asList(includeStatusStr.split(",")));
						StringBuilder b = new StringBuilder();
						int index = 0;
						for (String status : list) {
							b.append(index > 0 ? "," : "").append("'").append(status).append("'");
							index++;
						}
						queryString.append(" AND a.status IN (").append(b).append(") ");
					}
				} else if ("clientNo".equals(entry.getKey())) {
					queryString.append(" AND UPPER(c.").append(entry.getKey()).append(") LIKE UPPER(:")
							.append(entry.getKey()).append(") ");
				} else if ("contractNo".equals(entry.getKey()) || "contractDesc".equals(entry.getKey())
						|| "depositAcctNo".equals(entry.getKey()) || "rentalFeeAcctNo".equals(entry.getKey())) {
					queryString.append(" AND UPPER(a.").append(entry.getKey()).append(") LIKE UPPER(:")
							.append(entry.getKey()).append(") ");
				} else {
					queryString.append(" AND a.").append(entry.getKey()).append("=:").append(entry.getKey()).append(" ");
				}
			}
		}

		if (filters.containsKey("excludeStatusList")) {
			filters.remove("excludeStatusList");
		}
		if (filters.containsKey("includeStatusList")) {
			filters.remove("includeStatusList");
		}

		String q = (groupBy == null || groupBy.isEmpty()) ? queryString.toString()
				: appendOrderByToQuery(queryString.toString(), "a", groupBy, order);

		TypedQuery<SdbAcctJpe> query = ((CbsEntityManagerAware) dataService).getMyEntityManager().createQuery(q,
				SdbAcctJpe.class);

		if (filters != null) {
			for (Map.Entry<String, Object> entry : filters.entrySet()) {
				String fieldName = entry.getKey();
				try {
					Field field = SdbAcctJpe.class.getDeclaredField(fieldName);
					Class<?> fieldClass = field.getType();
					if (Boolean.class.equals(fieldClass)) {
						query.setParameter(entry.getKey(), Boolean.valueOf((String) entry.getValue()));
					} else {
						query.setParameter(entry.getKey(), entry.getValue());
					}
				} catch (NoSuchFieldException e) {
					e.printStackTrace();
				} catch (SecurityException e) {
					e.printStackTrace();
				}
			}
		}

		query.setFirstResult(offset);
        query.setMaxResults(resultLimit);

        final List<SdbAcctJpe> jpeResult = query.getResultList();

        for (SdbAcctJpe jpe : jpeResult) {
            SdbAcct sdo = jaxbSdoHelper.wrap(jpe, SdbAcct.class);
            sdoResult.add(sdo);
        }

        return sdoResult;

	}

	@Override
	public StructureBasisTypeObject getStructObject(SdbAcct bdo) {
		if (bdo == null) {
			return null;
		}
		CbsSessionContext sessionContext = cbsRuntimeContextManager.getContext(CbsSessionContext.class);
		boolean fromSystem = CBS_CHANNEL_CODE.equals(sessionContext.getChannelCode())
				&& CBS_CHANNEL_SOURCE.equals(sessionContext.getChannelSource());
		String _structureType = null;                                               // STRUCTURE_TYPE - if null, RefNoGenJpe.structureType will be used
		String _branch = bdo.getBranch();                                           // BRANCH
		String _bank = null;                                                        // BANK
		String _country = null;                                                     // COUNTRY
		String _ccy = bdo.getCcy();                                                 // CCY
		String _prodType = bdo.getProductCode();                                    // PROD_TYPE
		String _clientNo = bdo.getClientNo();                                       // CLIENT_NO
		String _basicAcctNo = null;                                                 // BASIC_ACCT_NO
		String _userId = sessionContext.getUserCode();                              // USER_ID - if null, CbsSessionContext.getUserCode will be used
		String _programId = fromSystem ? "DEPS583" : null;                          // PROGRAM_ID
		String _systemPhase = getRegistryValue(CommonsConstants.ATTR_SYSTEM_PHASE); // SYSTEM_PHASE - if null, registry value will be used
		String _stringValue = null;                                                 // STRING_VALUE
		Date _runDate = dateTimeHelper.getDate(bdo.getDateOpen());                  // RUN_DATE - if null, run date will be used
		String _moduleId = "DEP";                                                   // MODULE_ID
		StructureBasisTypeObject structObj = new StructureBasisTypeObject(_structureType, _branch, _bank, _country,
				_ccy, _prodType, _clientNo, _basicAcctNo, _userId, _programId, _systemPhase, _stringValue, _runDate,
				_moduleId);
		return structObj;
	}

}
