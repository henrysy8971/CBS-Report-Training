package com.silverlakesymmetri.cbs.dep.svc.mapper.decorator;

import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.CiPrintReprintJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.CiSettlementJpe;
import com.silverlakesymmetri.cbs.dep.svc.mapper.CiPrintReprintServiceMapper;
import com.silverlakesymmetri.cbs.dep.xmlapi.DEPCHQPRINTAPIType;
import com.silverlakesymmetri.cbs.dep.xmlapi.DEPCIPROCESSSETTLEBUYAPIType;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

public abstract class CiPrintReprintServiceDecorator extends FeeServiceDecorator implements CiPrintReprintServiceMapper {
		
	@Autowired
	@Qualifier("delegate")
	protected CiPrintReprintServiceMapper delegate;
		
	@Override
	public DEPCHQPRINTAPIType mapToApi(CiPrintReprintJpe jpe){
		DEPCHQPRINTAPIType api = delegate.mapToApi(jpe);
		mapFeeToApi(jpe, api);
		return  api;
	}
	
	@Override
	public CiPrintReprintJpe mapToJpe(DEPCHQPRINTAPIType api, CiPrintReprintJpe jpe){
		if (jpe == null) {
			jpe = new CiPrintReprintJpe();
		}
		
		if (api == null) {
			return jpe;
		}
		
		delegate.mapToJpe(api, jpe);
		mapFeeToJpe(api, jpe);
		return jpe;
	}
}
