package com.silverlakesymmetri.cbs.dep.svc.mapper.mapping;

import java.util.List;

import org.mapstruct.MapperConfig;
import org.mapstruct.Mapping;
import org.mapstruct.Mappings;

import com.silverlakesymmetri.cbs.commons.jpa.util.DateTimeHelper;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.AcctClosureCheckJpe;
import com.silverlakesymmetri.cbs.dep.xmlapi.DEPACCTCLOSECHECKTType;

@MapperConfig(uses={ DateTimeHelper.class})
public interface AcctClosureCheckToDEPACCTCLOSECHECKTTypeMapper {
	
	@Mappings({
		@Mapping(target = "relationCheckDesc", source="CHECKDESC"), 
		@Mapping(target = "allowClosureInd", source="ALLOWCLOSURE"),
		@Mapping(target = "relationCheckDtls", source="CHECKDTLS"),
		@Mapping(target = "relationCheckType", source="CHECKTYPE"),
		
	 })
	public AcctClosureCheckJpe mapDEPACCTCLOSECHECKTTypeToAcctClosureCheckJpe(DEPACCTCLOSECHECKTType  api);	
	
	public List<AcctClosureCheckJpe> mapDEPACCTCLOSECHECKTTypeListToAcctClosureCheckJpeList(List<DEPACCTCLOSECHECKTType>  api);	

}

