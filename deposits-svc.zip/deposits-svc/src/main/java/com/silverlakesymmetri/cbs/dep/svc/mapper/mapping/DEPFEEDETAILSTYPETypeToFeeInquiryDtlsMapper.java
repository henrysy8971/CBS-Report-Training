package com.silverlakesymmetri.cbs.dep.svc.mapper.mapping;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Mappings;

import com.silverlakesymmetri.cbs.commons.jpa.util.DateTimeHelper;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.FeeInquiryDtlsJpe;
import com.silverlakesymmetri.cbs.dep.xmlapi.DEPFEEDETAILSTYPEType;

@Mapper(uses = { DateTimeHelper.class })
public interface DEPFEEDETAILSTYPETypeToFeeInquiryDtlsMapper {

	@Mappings({
	    @Mapping(source = "CCY", target = "scTranCcy"),
	    @Mapping(source = "SCTYPE", target = "scType"),
	    @Mapping(source = "TAXTYPE", target = "scTaxType"),
	    @Mapping(source = "SCRATETYPE", target = "scRateType"),
	    @Mapping(source = "SCMODE", target = "scMode"),
	    @Mapping(source = "SERVAMT", target = "scTaxAmt"),
	    @Mapping(source = "TAXAMT", target = "taxOnScAmt"),
	    @Mapping(source = "SCTAXTRANTYPE", target = "scTaxTranType"),
	    @Mapping(source = "TAXONSCTRANTYPE", target = "taxOnScTranType"),
	    @Mapping(source = "UPDATABLESC", target = "updateableSC"),
	    @Mapping(source = "UPDATABLESC", target = "updInd"),
	    @Mapping(source = "ORIGSERVAMT", target = "origScTaxAmt"),
	    @Mapping(source = "ORIGTAXAMT", target = "origTaxOnScAmt"),
	    @Mapping(source = "REASONTYPE", target = "reasonType"),
	    @Mapping(source = "REASONDESC", target = "reasonDesc"),
	    @Mapping(source = "DECIPLACES", target = "deciPlaces"),
	    @Mapping(source = "CALCBALTYPE", target = "calcBalType"),
	    @Mapping(source = "CALCBAL", target = "calcBal"),
	    @Mapping(source = "CALCBALCCY", target = "calcBalCcy"),
	    @Mapping(source = "SCEVENTSUBTYPE", target = "scEventSubType"),
	    @Mapping(source = "SCEXCEPTION", target = "scException"),
	    @Mapping(source = "SCGROUPCODE", target = "scGroupCode"),
	    @Mapping(source = "SCPACKTYPE", target = "scPackType"),
	    @Mapping(source = "TAXCHARGEIND", target = "taxChargeInd"),
	    @Mapping(source = "TAXRATE", target = "taxRate"),
	    @Mapping(source = "TAXINCLUDED", target = "taxIncluded"),
	    @Mapping(source = "PAYMENTMODE", target = "scPaymentMode")
	})
	public FeeInquiryDtlsJpe mapApitoJpe(DEPFEEDETAILSTYPEType api);
		
	

}




