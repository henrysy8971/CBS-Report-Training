package com.silverlakesymmetri.cbs.dep.svc.impl;

import com.mysema.query.types.EntityPath;
import com.silverlakesymmetri.cbs.commons.svc.AbstractXmlApiBusinessService;
import com.silverlakesymmetri.cbs.commons.xmlapi.enums.CbsXmlApiOperation;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.AcctReactivation;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.AcctReactivationJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.QAcctReactivationJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.id.AcctReactivationPk;
import com.silverlakesymmetri.cbs.dep.svc.AcctReactivationService;
import com.silverlakesymmetri.cbs.dep.svc.mapper.mapping.AcctReactivationToDEPACCTACTIVATEAPITypeMapper;
import com.silverlakesymmetri.cbs.dep.xmlapi.DEPACCTACTIVATEAPIType;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 *
 * @author luis.talag
 */
@Service
public class AcctReactivationServiceImpl extends AbstractXmlApiBusinessService<AcctReactivation, AcctReactivationJpe, AcctReactivationPk, DEPACCTACTIVATEAPIType, DEPACCTACTIVATEAPIType> implements AcctReactivationService {

    @Autowired
    private AcctReactivationToDEPACCTACTIVATEAPITypeMapper mapper;
    
    @Override
    public AcctReactivation updateAcctReactivation(AcctReactivation dataObject) {
        return super.updateDataObject(dataObject);
    }

    @Override
    protected DEPACCTACTIVATEAPIType transformBdoToXmlApiRqUpdate(AcctReactivation dataObject) {
        return transformBdoToXmlApiType(dataObject, CbsXmlApiOperation.UPDATE);
    }
    
    @Override
    protected DEPACCTACTIVATEAPIType transformBdoToXmlApiRqCreate(AcctReactivation dataObject) {
        return null;
    }

    @Override
    protected DEPACCTACTIVATEAPIType transformBdoToXmlApiRqDelete(AcctReactivation dataObject) {
        return null;
    }
    
    private DEPACCTACTIVATEAPIType transformBdoToXmlApiType(AcctReactivation dataObject, CbsXmlApiOperation oper) {
        AcctReactivationJpe jpe = jaxbSdoHelper.unwrap(dataObject, AcctReactivationJpe.class);
        DEPACCTACTIVATEAPIType acctActivateApiType = mapper.mapToApi(jpe);
        super.setTechColsFromDataObject(dataObject, acctActivateApiType);
        acctActivateApiType.setOPERATION(oper.getOperation());
        return acctActivateApiType;
    }

    @Override
    protected AcctReactivation processXmlApiRs(AcctReactivation dataObject, DEPACCTACTIVATEAPIType xmlApiRs) {
        AcctReactivationJpe jpe = jaxbSdoHelper.unwrap(dataObject, AcctReactivationJpe.class);
        jpe = mapper.mapToJpe(xmlApiRs, jpe);
        return jaxbSdoHelper.wrap(jpe);
    }

    @Override
    protected List<AcctReactivation> processXmlApiListRs(AcctReactivation dataObject, DEPACCTACTIVATEAPIType xmlApiRs) {
        return null;
    }

    @Override
    protected Class<DEPACCTACTIVATEAPIType> getXmlApiResponseClass() {
        return DEPACCTACTIVATEAPIType.class;
    }

    @Override
    protected AcctReactivationPk getIdFromDataObjectInstance(AcctReactivation dataObject) {
        AcctReactivationJpe jpe = jaxbSdoHelper.unwrap(dataObject, AcctReactivationJpe.class);
        return new AcctReactivationPk(jpe.getInternalKey());
    }

    @Override
    protected EntityPath<AcctReactivationJpe> getEntityPath() {
        return QAcctReactivationJpe.acctReactivationJpe;
    }
    
}
