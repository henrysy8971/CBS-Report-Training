package com.silverlakesymmetri.cbs.dep.svc.mapper.decorator;

import java.util.HashMap;
import java.util.Map;

import org.mapstruct.Context;
import org.mapstruct.MappingTarget;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

import com.silverlakesymmetri.cbs.commons.jpa.service.CbsGenericDataService;
import com.silverlakesymmetri.cbs.commons.xmlapi.enums.CbsXmlApiOperation;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.SdbLicenseeJpe;
import com.silverlakesymmetri.cbs.dep.svc.mapper.SdbLicenseeMapper;
import com.silverlakesymmetri.cbs.dep.xmlapi.DEPSDBLICENSEEAPIType;
import com.silverlakesymmetri.cbs.mcl.jpa.mapping.sdo.util.MclJpeConstants;

public abstract class SdbLicenseeDecorator implements SdbLicenseeMapper {

	@Autowired
	@Qualifier("delegate")
	protected SdbLicenseeMapper delegate;

	@Autowired(required = true)
	@Qualifier("cbsGenericDataService")
	protected CbsGenericDataService dataService;

	private Long getClientId(String clientNo) {
		Map<String, Object> params = new HashMap<String, Object>();
		params.put("clientNo", clientNo);
		Long clientId = dataService.getWithNamedQuery(MclJpeConstants.CLIENT_JPE_FIND_CLIENT_ID_USING_CLIENT_NO, params,
				Long.class);
		return clientId;
	}

	@SuppressWarnings("rawtypes")
	@Override
	public DEPSDBLICENSEEAPIType mapToApi(SdbLicenseeJpe jpe, @Context CbsXmlApiOperation oper,
			@Context Map otherInfo) {

		if (jpe.getClientId() != null) {
			jpe.setClientId(getClientId(jpe.getClientNo()));
		}

		DEPSDBLICENSEEAPIType req = (DEPSDBLICENSEEAPIType) delegate.mapToApi(jpe, oper, otherInfo);
		if (otherInfo.containsKey("sdbMainClientId")) {
			try {
				//req.setSDBMAINCLIENTNO(Double.parseDouble((String) otherInfo.get("sdbMainClientId")));
				req.setSDBMAINCLIENTNO((Double) otherInfo.get("sdbMainClientId"));
			} catch (Exception e) {
			}
		}
		if (otherInfo.containsKey("withLicensees")) {
			req.setSDBWITHLICENSESS((String) otherInfo.get("withLicensees"));
		}
		return req;
	}

	@Override
	public SdbLicenseeJpe mapToJpe(DEPSDBLICENSEEAPIType api, @MappingTarget SdbLicenseeJpe jpe) {

		if (jpe == null) {
			jpe = new SdbLicenseeJpe();
		}

		if (api == null) {
			return jpe;
		}

		delegate.mapToJpe(api, jpe);

		return jpe;
	}

}
