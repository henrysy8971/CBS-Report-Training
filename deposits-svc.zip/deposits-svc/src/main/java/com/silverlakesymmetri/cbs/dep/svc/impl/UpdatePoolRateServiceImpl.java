package com.silverlakesymmetri.cbs.dep.svc.impl;

import com.silverlakesymmetri.cbs.commons.jpa.service.CbsGenericDataService;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.IntMatrixDtlJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.util.DepJpeConstants;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.silverlakesymmetri.cbs.dep.svc.UpdatePoolRateService;
import com.silverlakesymmetri.cbs.pdm.svc.PoolService;
import java.util.HashMap;
import java.util.Map;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

@Service
@Transactional
public class UpdatePoolRateServiceImpl implements UpdatePoolRateService {

    @Autowired
    private PoolService poolService;
    @Autowired(required = true)
    @Qualifier("cbsGenericDataService")
    protected CbsGenericDataService ds;
    Map<String, Object> updateParam = new HashMap<>();

    @Override
    public boolean process() {

        for (Object o : poolService.loadPoolRatesMatrix()) {
            Object[] values = (Object[]) o;
            if (!Double.valueOf((Double) values[1]).equals(0.0)) {
                updateParam.put("intMatrixDtlRefNo", (String) values[0]);
                updateParam.put("intRate", (Double) values[1]);
                try {
                    System.out.println("Pooling rates(M): "+(String) values[0]+" "+(Double) values[1]);
                    //ds.bulkUpdateWithNamedQuery(DepJpeConstants.UPDATE_INT_MATRIX_NAME, updateParam, IntMatrixDtlJpe.class);
                } catch (Exception e) {
                    System.out.println("Error Update IntMatrixDtlJpe " + e.getMessage());
                    e.printStackTrace();
                }
            }
        }
        return true;

    }

}
