package com.silverlakesymmetri.cbs.dep.svc.impl;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Service;

import com.mysema.query.types.EntityPath;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.svc.AbstractBusinessService;
import com.silverlakesymmetri.cbs.commons.svc.BusinessObjectValidationCapable;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.DocNoCtrl;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.DocNoCtrlJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.QDocNoCtrlJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.id.DocNoCtrlPk;
import com.silverlakesymmetri.cbs.dep.svc.DocNoCtrlService;

/**
 * 
 * @author Jeffrey.Villanueva
 *
 */
@Service
public class DocNoCtrlServiceImpl extends AbstractBusinessService<DocNoCtrl, DocNoCtrlJpe, DocNoCtrlPk>
		implements DocNoCtrlService, BusinessObjectValidationCapable<DocNoCtrl> {

	@Override
	protected DocNoCtrlPk getIdFromDataObjectInstance(DocNoCtrl dataObject) {
		return new DocNoCtrlPk(dataObject.getDocType(), dataObject.getCtrlSeqNo());
	}

	@Override
	protected EntityPath<DocNoCtrlJpe> getEntityPath() {
		return QDocNoCtrlJpe.docNoCtrlJpe;
	}

	@Override
	public DocNoCtrl create(DocNoCtrl dataObject) {
		return super.create(dataObject);
	}

	@Override
	public DocNoCtrl update(DocNoCtrl dataObject) {
		return super.update(dataObject);
	}

	@Override
	public boolean delete(DocNoCtrl dataObject) {
		return super.delete(dataObject);
	}

	@Override
	public DocNoCtrl getByPk(String publicKey, DocNoCtrl reference) {
		return super.getByPk(publicKey, reference);
	}

	@Override
	public List<DocNoCtrl> find(FindCriteria fc, CbsHeader cbsHeader) {
		return super.find(fc, cbsHeader);
	}

	@Override
	public List<DocNoCtrl> query(int offset, int resultLimit, String groupBy, String order,
			Map<String, Object> filters) {
		return super.query(offset, resultLimit, groupBy, order, filters);
	}
	
}
