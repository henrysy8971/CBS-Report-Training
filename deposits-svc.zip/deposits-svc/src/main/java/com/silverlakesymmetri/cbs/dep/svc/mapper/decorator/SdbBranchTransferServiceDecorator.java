package com.silverlakesymmetri.cbs.dep.svc.mapper.decorator;

import org.mapstruct.Context;
import org.mapstruct.MappingTarget;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

import com.silverlakesymmetri.cbs.commons.xmlapi.enums.CbsXmlApiOperation;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.SdbBranchTransferJpe;
import com.silverlakesymmetri.cbs.dep.svc.mapper.SdbBranchTransferServiceMapper;
import com.silverlakesymmetri.cbs.dep.xmlapi.DEPSDBTRANSFERAPIType;

public abstract class SdbBranchTransferServiceDecorator implements SdbBranchTransferServiceMapper {
	
	@Autowired
	@Qualifier("delegate")
	protected  SdbBranchTransferServiceMapper delegate;
	
	@Override
	public DEPSDBTRANSFERAPIType mapToApi(SdbBranchTransferJpe jpe, CbsXmlApiOperation oper) {
		DEPSDBTRANSFERAPIType req = (DEPSDBTRANSFERAPIType) delegate.mapToApi(jpe, oper);
		return req;
	}
	
	@Override
	public SdbBranchTransferJpe mapToJpe(DEPSDBTRANSFERAPIType api, SdbBranchTransferJpe jpe) {
		delegate.mapToJpe(api, jpe);
		return jpe;
	}

}
