package com.silverlakesymmetri.cbs.dep.svc.impl;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import javax.persistence.NoResultException;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.bdo.sdo.DmsFile;
import com.silverlakesymmetri.cbs.commons.context.CbsSessionContext;
import com.silverlakesymmetri.cbs.commons.jpa.entity.CbsHeaderJpe;
import com.silverlakesymmetri.cbs.commons.jpa.util.BdoHelper;
import com.silverlakesymmetri.cbs.commons.xmlapi.enums.CbsXmlApiOperation;
import com.silverlakesymmetri.cbs.csd.xmlapi.CSDPRODSCINDIVIDUALAPIType;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.Acct;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.AcctJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.AcctStmtJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.id.AcctPk;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.util.DepJpeConstants;
import com.silverlakesymmetri.cbs.dep.svc.AcctService;
import com.silverlakesymmetri.cbs.dep.svc.mapper.AcctCasaServiceMapper;
import com.silverlakesymmetri.cbs.dep.xmlapi.DEPACCTWRAPPERAPIType;
import com.silverlakesymmetri.cbs.dep.xmlapi.DEPJOINTACCTAPIType;
import com.silverlakesymmetri.cbs.dep.xmlapi.DEPPRODSCMAINTFEEAPIType;
import com.silverlakesymmetri.cbs.dep.xmlapi.DEPSTMTAPIType;
import com.silverlakesymmetri.cbs.mcl.jpa.mapping.sdo.ClientJpe;
import com.silverlakesymmetri.cbs.mcl.jpa.mapping.sdo.util.MclJpeConstants;
import com.silverlakesymmetri.cbs.xps.bdo.sdo.AdvicePreview;
import com.silverlakesymmetri.cbs.xps.bdo.sdo.DocDomainObjDefn;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.DocDomainObjDefnJpe;
import com.silverlakesymmetri.cbs.xps.svc.DocDomainObjDefnService;

/**
 *
 * @author Jeffrey.Villanueva
 *
 */
@Service
public class AcctCasaServiceImpl extends AbstractAcctServiceImpl<DEPACCTWRAPPERAPIType, DEPACCTWRAPPERAPIType>
		implements AcctService {

	@Autowired
	protected AcctCasaServiceMapper acctCasaServiceMapper;

	@Autowired
	private DocDomainObjDefnService docDomainObjDefnService;

	@Override
	public Acct create(Acct dataObject) {
		Acct newAcct = super.create(dataObject);
		Map<String, Object> param = new HashMap<String, Object>();
		param.put("acctNo", newAcct.getAcctNo());
		AcctJpe acctJpe = dataService.getWithNamedQuery(DepJpeConstants.ACCT_JPE_FIND_BY_ACCTNO, param, AcctJpe.class);
		delegateDocDomainObjDefnCreateOrUpdate(acctJpe.getHeader(), dataObject.getDocDomainObjDefnList(),
				new ArrayList<DocDomainObjDefn>(), newAcct);
		generateMessageQueue(newAcct);
		return newAcct;
	}

	@Override
	public Acct update(Acct dataObject) {
		Acct updatedObject = super.update(dataObject);
		AcctJpe acctJpe = jaxbSdoHelper.unwrap(updatedObject, AcctJpe.class);
		delegateDocDomainObjDefnCreateOrUpdate(acctJpe.getHeader(), dataObject.getDocDomainObjDefnList(),
				getDocDomainObjDefnsByAcctNo(dataObject.getAcctNo(), dataObject.getAcctType()), updatedObject);
		return updatedObject;
	}

	@Override
	public boolean delete(Acct dataObject) {
		return super.delete(dataObject);
	}

	@Override
	public List<Acct> query(int offset, int resultLimit, String groupBy, String order, Map<String, Object> filters) {
		return super.query(offset, resultLimit, groupBy, order, filters);
	}

	@Override
	public List<Acct> find(FindCriteria findCriteria, CbsHeader cbsHeader) {
		return super.find(findCriteria, cbsHeader);
	}

	@Override
	public Acct getByPk(String publicKey, Acct reference) {
		Acct acct = super.getByPk(publicKey, reference);
		if (acct != null) {
			acct.setDocDomainObjDefnList(getDocDomainObjDefnsByAcctNo(acct.getAcctNo(), acct.getAcctType()));
		}
		return acct;
	}

	@Override
	public Long count(FindCriteria findCriteria, CbsHeader cbsHeader) {
		return super.count(findCriteria, cbsHeader);
	}

	@Override
	protected DEPACCTWRAPPERAPIType transformBdoToXmlApiRqCreate(Acct dataObject) {
		return tranformAcctToDEPACCTWRAPPERAPIType(dataObject, CbsXmlApiOperation.INSERT);
	}

	@Override
	protected DEPACCTWRAPPERAPIType transformBdoToXmlApiRqUpdate(Acct dataObject) {
		return tranformAcctToDEPACCTWRAPPERAPIType(dataObject, CbsXmlApiOperation.UPDATE);
	}

	@Override
	protected DEPACCTWRAPPERAPIType transformBdoToXmlApiRqDelete(Acct dataObject) {
		return tranformAcctToDEPACCTWRAPPERAPIType(dataObject, CbsXmlApiOperation.DELETE);
	}

	private DEPACCTWRAPPERAPIType tranformAcctToDEPACCTWRAPPERAPIType(Acct bdo, CbsXmlApiOperation oper) {

		DEPACCTWRAPPERAPIType api = acctCasaServiceMapper.mapToApi(bdo, oper);

		super.setTechColsFromDataObject(bdo, api.getDEPACCTREC());
		if (api.getDEPJOINTACCTLIST() == null || api.getDEPJOINTACCTLIST().getDEPJOINTACCTAPI() == null
				|| api.getDEPJOINTACCTLIST().getDEPJOINTACCTAPI().isEmpty()) {
		} else {
			for (DEPJOINTACCTAPIType joint : api.getDEPJOINTACCTLIST().getDEPJOINTACCTAPI()) {
				super.setTechColsFromDataObject(bdo, joint);
			}
		}

		if (api.getDEPSTMTLIST() == null || api.getDEPSTMTLIST().getDEPSTMTAPI() == null
				|| api.getDEPSTMTLIST().getDEPSTMTAPI().isEmpty()) {
		} else {
			for (DEPSTMTAPIType stmt : api.getDEPSTMTLIST().getDEPSTMTAPI()) {
				super.setTechColsFromDataObject(bdo, stmt);
			}
		}

		if (api.getCSDPRODSCDEFREC() != null) {
			super.setTechColsFromDataObject(bdo, api.getCSDPRODSCDEFREC());
		}

		if (api.getCSDPRODSCINDIVIDUALLIST() == null
				|| api.getCSDPRODSCINDIVIDUALLIST().getCSDPRODSCINDIVIDUALAPI() == null
				|| api.getCSDPRODSCINDIVIDUALLIST().getCSDPRODSCINDIVIDUALAPI().isEmpty()) {
		} else {
			for (CSDPRODSCINDIVIDUALAPIType indv : api.getCSDPRODSCINDIVIDUALLIST().getCSDPRODSCINDIVIDUALAPI()) {
				super.setTechColsFromDataObject(bdo, indv);
			}
		}

		if (api.getDEPPRODSCMAINTFEELIST() == null || api.getDEPPRODSCMAINTFEELIST().getDEPPRODSCMAINTFEEAPI() == null
				|| api.getDEPPRODSCMAINTFEELIST().getDEPPRODSCMAINTFEEAPI().isEmpty()) {
		} else {
			for (DEPPRODSCMAINTFEEAPIType scMaint : api.getDEPPRODSCMAINTFEELIST().getDEPPRODSCMAINTFEEAPI()) {
				super.setTechColsFromDataObject(bdo, scMaint);
			}
		}

		return api;
	}

	@Override
	protected Acct processXmlApiRs(Acct dataObject, DEPACCTWRAPPERAPIType xmlApiRs) {
		if (xmlApiRs != null && xmlApiRs.getDEPACCTREC() != null) {
			Number internalKey = xmlApiRs.getDEPACCTREC().getINTERNALKEY();
			if (internalKey != null) {
				AcctJpe acctJpe = dataService.find(AcctJpe.class, new AcctPk(internalKey.longValue()));
				
				//hack: reset transients
				AcctJpe og = jaxbSdoHelper.unwrap(dataObject);
				if (acctJpe != null) {
					mergeTransientFields(og, acctJpe);
					return jaxbSdoHelper.wrap(acctJpe, Acct.class);
				}
			}
		}
		return dataObject;
	}
	
	private void mergeTransientFields(AcctJpe og, AcctJpe resp ){
		AcctStmtJpe ogStmt = og.getAcctStmtRec() ;
		AcctStmtJpe respStmt = resp.getAcctStmtRec();
		if (ogStmt!= null && respStmt != null){
			respStmt.setClientName(ogStmt.getClientName());
			respStmt.setAddress(ogStmt.getAddress());
			respStmt.setPostalCode(ogStmt.getPostalCode());
		}
	}

	@Override
	protected List<Acct> processXmlApiListRs(Acct dataObject, DEPACCTWRAPPERAPIType xmlApiRs) {
		return null;
	}

	@Override
	protected Class<DEPACCTWRAPPERAPIType> getXmlApiResponseClass() {
		return DEPACCTWRAPPERAPIType.class;
	}

	@Override
	protected Map<String, String> executeStoredProcedure(String xmlApiReq, String xmlHeaderIn) {
		String xmlApiReqProcess = xmlApiReq.replaceAll("OPERATION=\"INSERT\"", "OPERATION=\"DO_INSERT\"")
				.replaceAll("OPERATION=\"UPDATE\"", "OPERATION=\"DO_UPDATE\"")
				.replaceAll("OPERATION=\"DELETE\"", "OPERATION=\"DO_DELETE\"");
		return super.executeStoredProcedure(xmlApiReqProcess, xmlHeaderIn);
	}

	@SuppressWarnings("unchecked")
	protected void delegateDocDomainObjDefnCreateOrUpdate(CbsHeaderJpe headerJpe, List<DocDomainObjDefn> sourceList,
			List<DocDomainObjDefn> targetList, Acct dataObject) {
		List<Object> sourceObjectList = (List<Object>) (Object) sourceList;
		List<Object> targetObjectList = (List<Object>) (Object) targetList;
		BdoHelper.ListDiffResult listDiffResult = getBdoHelper().diffItems(sourceObjectList, targetObjectList,
				new String[] { "docDomainObjDefnList" }, headerJpe, new BdoHelper.MergeAllPolicy(), true, true);

		if (listDiffResult.getNewItems() != null) {
			for (Object newItem : listDiffResult.getNewItems()) {
				docDomainObjDefnService.create((DocDomainObjDefn) newItem);
			}
		}

		if (listDiffResult.getUpdatedItems() != null) {
			for (Object updatedItem : listDiffResult.getUpdatedItems()) {
				docDomainObjDefnService.update((DocDomainObjDefn) updatedItem);
			}
		}

		if (listDiffResult.isChanged()) {
			dataObject.getDocDomainObjDefnList().clear();
			dataObject.getDocDomainObjDefnList().addAll(targetList);
		}
	}

	private List<DocDomainObjDefn> getDocDomainObjDefnsByAcctNo(String acctNo, String acctType) {
		Map<String, Object> map = new HashMap<>();
		map.put("refObjectKey", acctNo);
		map.put("refDomainKey", acctType);
		List<DocDomainObjDefnJpe> jpeList = dataService.find(map, DocDomainObjDefnJpe.class);
		List<DocDomainObjDefn> bdoList = new ArrayList<>(jpeList.size());
		for (DocDomainObjDefnJpe jpe : jpeList) {
			bdoList.add(jaxbSdoHelper.wrap(jpe, DocDomainObjDefn.class));
		}
		return bdoList;
	}

	@Override
	public List<Acct> findDistinctFromAcctNo(Map<String, Object> queryParams) {
		String acctType = (String) queryParams.get("acctType");
		String fromBranch = (String) queryParams.get("fromBranch");
		String toBranch = (String) queryParams.get("toBranch");
		String fromClientNo = (String) queryParams.get("fromClientNo");
		String toClientNo = (String) queryParams.get("toClientNo");
		String acctNo = (String) queryParams.get("acctNo");
		String acctDesc = (String) queryParams.get("acctDesc");
		int limit = queryParams.get("limit") != null ? Integer.parseInt((String) queryParams.get("limit")) : 10;
		int offset = queryParams.get("offset") != null ? Integer.parseInt((String) queryParams.get("offset")) : 0;

		List<Acct> result = new ArrayList<Acct>();
		StringBuilder query = new StringBuilder(DepJpeConstants.ACCT_TYPE_TRANSFER_FROM_ACCT_NO_QUERY);

		ClientJpe fromAcct = null;
		ClientJpe toAcct = null;

		try {
			Map<String, Object> clientParams = new HashMap<>();
			clientParams.put("clientNo", fromClientNo);
			fromAcct = dataService.getWithNamedQuery(MclJpeConstants.CLIENT_JPE_GET_CLIENT_FROM_REF_NO, clientParams,
					ClientJpe.class);

			clientParams.put("clientNo", toClientNo);
			toAcct = dataService.getWithNamedQuery(MclJpeConstants.CLIENT_JPE_GET_CLIENT_FROM_REF_NO, clientParams,
					ClientJpe.class);
		} catch (NoResultException e) {
		}

		final Map<String, Object> params = new HashMap<>();
		params.put("acctType", acctType);
		params.put("fromBranch", fromBranch);
		params.put("toBranch", toBranch);
		params.put("fromClientNo", fromAcct != null ? fromAcct.getClientId() : null);
		params.put("toClientNo", toAcct != null ? toAcct.getClientId() : null);

		if (acctNo != null) {
			query.append(" AND UPPER(a.acctNo) like :acctNo");
			params.put("acctNo", acctNo.toUpperCase());
		}

		if (acctDesc != null) {
			query.append(" AND UPPER(a.acctDesc) like :acctDesc");
			params.put("acctDesc", acctDesc.toUpperCase());
		}

		query.append(" ORDER BY a.clientId");

		List<AcctJpe> list = dataService.findWithQuery(query.toString(), params, offset, limit, AcctJpe.class);

		for (Object o : list) {
			Object[] values = (Object[]) o;
			Acct acct = jaxbSdoHelper.createSdoInstance(Acct.class);
			acct.setAcctNo((String) values[0]);
			acct.setAcctDesc((String) values[1]);
			result.add(acct);
		}

		return result;
	}

	@Override
	public List<Acct> findDistinctToAcctNo(Map<String, Object> queryParams) {

		String acctType = (String) queryParams.get("acctType");
		String fromBranch = (String) queryParams.get("fromBranch");
		String toBranch = (String) queryParams.get("toBranch");
		String fromClientNo = (String) queryParams.get("fromClientNo");
		String toClientNo = (String) queryParams.get("toClientNo");
		String startAcctNo = (String) queryParams.get("startAcctNo");
		String acctNo = (String) queryParams.get("acctNo");
		String acctDesc = (String) queryParams.get("acctDesc");
		int limit = queryParams.get("limit") != null ? Integer.parseInt((String) queryParams.get("limit")) : 10;
		int offset = queryParams.get("offset") != null ? Integer.parseInt((String) queryParams.get("offset")) : 0;

		List<Acct> result = new ArrayList<Acct>();
		StringBuilder query = new StringBuilder(DepJpeConstants.ACCT_TYPE_TRANSFER_TO_ACCT_NO_QUERY);

		ClientJpe fromAcct = null;
		ClientJpe toAcct = null;

		try {
			Map<String, Object> clientParams = new HashMap<>();
			clientParams.put("clientNo", fromClientNo);
			fromAcct = dataService.getWithNamedQuery(MclJpeConstants.CLIENT_JPE_GET_CLIENT_FROM_REF_NO, clientParams,
					ClientJpe.class);

			clientParams.put("clientNo", toClientNo);
			toAcct = dataService.getWithNamedQuery(MclJpeConstants.CLIENT_JPE_GET_CLIENT_FROM_REF_NO, clientParams,
					ClientJpe.class);
		} catch (NoResultException e) {
		}

		final Map<String, Object> params = new HashMap<>();
		params.put("acctType", acctType);
		params.put("startAcctNo", startAcctNo);
		params.put("fromBranch", fromBranch);
		params.put("toBranch", toBranch);
		params.put("fromClientNo", fromAcct != null ? fromAcct.getClientId() : null);
		params.put("toClientNo", toAcct != null ? toAcct.getClientId() : null);

		if (acctNo != null) {
			query.append(" AND UPPER(a.acctNo) like :acctNo");
			params.put("acctNo", acctNo.toUpperCase());
		}

		if (acctDesc != null) {
			query.append(" AND UPPER(a.acctDesc) like :acctDesc");
			params.put("acctDesc", acctDesc.toUpperCase());
		}

		List<AcctJpe> list = dataService.findWithQuery(query.toString(), params, offset, limit, AcctJpe.class);

		for (Object o : list) {
			Object[] values = (Object[]) o;
			Acct acct = jaxbSdoHelper.createSdoInstance(Acct.class);
			acct.setAcctNo((String) values[0]);
			acct.setAcctDesc((String) values[1]);
			result.add(acct);
		}

		return result;
	}

	@Override
	public List<Acct> findOwnAcctAndJointAcct(Map<String, Object> queryParams) {

		List<String> clientNoList = new ArrayList<>();
		String clientNoListStr = (String) queryParams.get("clientNoList");
		String clientNo = (String) queryParams.get("clientNo");
		String ccy = (String) queryParams.get("ccy");
		String acctNo = (String) queryParams.get("acctNo");
		String acctDesc = (String) queryParams.get("acctDesc");
		String groupBy = (String) queryParams.get("groupBy");
		String order = (String) queryParams.get("order");

		int limit = queryParams.get("limit") != null ? Integer.parseInt((String) queryParams.get("limit")) : 10;
		int offset = queryParams.get("offset") != null ? Integer.parseInt((String) queryParams.get("offset")) : 0;

		if (clientNoListStr != null && StringUtils.isNotEmpty(clientNoListStr.trim())) {
			Collections.addAll(clientNoList, StringUtils.deleteWhitespace(clientNoListStr).split(","));
		}

		if (clientNo != null && StringUtils.isNotEmpty(clientNo.trim())) {
			if (!clientNoList.contains(clientNo.trim())) {
				clientNoList.add(clientNo.trim());
			}
		}

		if (clientNoList.isEmpty()) {
			return null;
		}

		queryParams.clear();
		queryParams.put("clientNos", clientNoList);

		StringBuilder query1 = new StringBuilder(DepJpeConstants.GET_OWN_CASA_BY_CLIENT_NOS_QUERY);
		StringBuilder query2 = new StringBuilder(DepJpeConstants.GET_JOINT_ACCT_BY_CLIENT_NOS_QUERY);

		if (acctNo != null &&  StringUtils.isNotBlank(acctNo.trim())) {
			query1.append(" AND UPPER(main.acctNo) like :acctNo");
			query2.append(" AND UPPER(main.acctNo) like :acctNo");
			queryParams.put("acctNo", acctNo.toUpperCase().trim());
		}

		if (acctDesc != null && StringUtils.isNotBlank(acctDesc.trim())) {
			query1.append(" AND UPPER(main.acctDesc) like :acctDesc");
			query2.append(" AND UPPER(main.acctDesc) like :acctDesc");
			queryParams.put("acctDesc", acctDesc.toUpperCase().trim());
		}

		if (ccy != null && StringUtils.isNotBlank(ccy.trim())) {
			query1.append(" AND UPPER(main.ccy) like :ccy");
			query2.append(" AND UPPER(main.ccy) like :ccy");
			queryParams.put("ccy", ccy.toUpperCase().trim());
		}

		groupBy = StringUtils.isNotBlank(groupBy) ? groupBy.trim() : "acctNo";
		order = StringUtils.isNotBlank(order) ? order.toUpperCase().trim() : "ASC";

		query1.append(" UNION ").append(query2.toString());
		List<AcctJpe> jpeList = dataService.findWithQuery(query1.toString(), queryParams, offset, limit, AcctJpe.class);

		List<Acct> retList = new ArrayList<>();
		if (jpeList != null && jpeList.size() > 0) {
			for (AcctJpe jpe : jpeList) {
				retList.add(jaxbSdoHelper.wrap(jpe, Acct.class));
			}
		}

		if ("ccy".equalsIgnoreCase(groupBy)) {
			retList = retList.stream().sorted(Comparator.comparing(Acct::getCcy)).collect(Collectors.toList());
		} else if ("acctDesc".equalsIgnoreCase(groupBy)) {
			retList = retList.stream().sorted(Comparator.comparing(Acct::getAcctDesc)).collect(Collectors.toList());
		} else {
			retList = retList.stream().sorted(Comparator.comparing(Acct::getAcctNo)).collect(Collectors.toList());
		}

		if ("desc".equalsIgnoreCase(order)) {
			Collections.reverse(retList);
		}

		return retList;

	}

	/*
	private Long getClientId(String clientNo) {
		Map<String, Object> params = new HashMap<String, Object>();
		params.put("clientNo", clientNo);
		Long v = null;
		try {
			v = dataService.getWithNamedQuery(MclJpeConstants.CLIENT_JPE_FIND_CLIENT_ID_USING_CLIENT_NO, params,
					Long.class);
		} catch (Exception e) {
		}

		return v;
//		if (v == null) {
//			return null;
//		}

//		return String.valueOf(v);
	}
*/
	@Override
	public List<Acct> findCasaAcctByAcctNoAcctDescOrClientNo(Map<String, Object> queryParams) {
		List<Acct> list = new ArrayList<>();
		String acctNo = (String) queryParams.get("acctNo");
		String acctDesc = (String) queryParams.get("acctDesc");
		String clientNo = (String) queryParams.get("clientNo");
		String ccy = (String) queryParams.get("ccy");
		int limit = queryParams.get("limit") != null ? Integer.parseInt((String) queryParams.get("limit")) : 10;
		int offset = queryParams.get("offset") != null ? Integer.parseInt((String) queryParams.get("offset")) : 0;
		long orgId = cbsRuntimeContextManager.getContext(CbsSessionContext.class).getOrgId();

		Map<String, Object> params = new HashMap<>();
		StringBuilder nativeQuery = new StringBuilder("SELECT DISTINCT a.* FROM dep_acct a, mcl_client b");
		nativeQuery.append(" WHERE a.client_no = b.client_id");
		nativeQuery.append(" AND a.org_id$ = b.org_id$");
		nativeQuery.append(" AND b.org_id$ = ?org_id");

		params.put("org_id", orgId);
		if (StringUtils.isNotEmpty(acctNo)) {
			nativeQuery.append(" AND UPPER(a.acct_no) LIKE ?acctNo");
			params.put("acctNo", acctNo.toUpperCase());
		}

		if (StringUtils.isNotEmpty(acctDesc)) {
			nativeQuery.append(" AND UPPER(a.acct_desc) LIKE ?acctDesc");
			params.put("acctDesc", acctDesc.toUpperCase());
		}

		if (StringUtils.isNotEmpty(clientNo)) {
			nativeQuery.append(" AND UPPER(b.client_no) LIKE ?clientNo");
			params.put("clientNo", clientNo.toUpperCase());
		}

		if (StringUtils.isNotEmpty(ccy)) {
			nativeQuery.append(" AND UPPER(a.ccy) LIKE ?ccy");
			params.put("ccy", ccy.toUpperCase());
		}

		nativeQuery.append(" AND a.deposit_type != 'T'");
		nativeQuery.append(" AND a.acct_status != 'C'");
		nativeQuery.append(" ORDER BY a.acct_no");

		List<AcctJpe> jpeList = dataService.findWithNativeQuery(nativeQuery.toString(), params, offset, limit,
				AcctJpe.class);

		if (jpeList != null && !jpeList.isEmpty()) {
			for (AcctJpe jpe : jpeList) {
				list.add(jaxbSdoHelper.wrap(jpe, Acct.class));
			}

		}
		return list;
	}

	@Override
	public DmsFile generateLetterOfThanks(String acctNo, String locale) {
		return super.generateLetterOfThanks(acctNo, locale);
	}
	
	@Override
	public AdvicePreview sendIntimationLetter(String acctNo, String locale, boolean isPreview) {
		return super.sendIntimationLetter(acctNo, locale, isPreview);
	}

	/*
    private List<Long> getClientIdByClientNos(List<String> clientNoList) {
        Map<String, Object> params = ImmutableMap.<String, Object>of("clientNoList", clientNoList);
        List<Long> clientIds = dataService.findWithNamedQuery(MclJpeConstants.CLIENT_JPE_FIND_CLIENT_IDS_USING_CLIENT_NOS, params, Long.class);
        return clientIds;
    }
    */

}
