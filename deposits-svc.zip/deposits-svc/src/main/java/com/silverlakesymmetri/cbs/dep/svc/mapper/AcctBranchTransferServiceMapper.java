package com.silverlakesymmetri.cbs.dep.svc.mapper;

import java.util.Map;

import org.mapstruct.Context;
import org.mapstruct.DecoratedWith;
import org.mapstruct.InheritConfiguration;
import org.mapstruct.InheritInverseConfiguration;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingTarget;
import org.mapstruct.Mappings;

import com.silverlakesymmetri.cbs.commons.jpa.util.DateTimeHelper;
import com.silverlakesymmetri.cbs.commons.xmlapi.enums.CbsXmlApiOperation;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.AcctBranchTransferJpe;
import com.silverlakesymmetri.cbs.dep.svc.mapper.decorator.AcctBranchTransferServiceDecorator;
import com.silverlakesymmetri.cbs.dep.svc.mapper.mapping.AcctBranchTransferToDEPACCTBRANCHTRANSFERAPITypeMapper;
import com.silverlakesymmetri.cbs.dep.xmlapi.DEPACCTBRANCHTRANSFERAPIType;

@Mapper(config=AcctBranchTransferToDEPACCTBRANCHTRANSFERAPITypeMapper.class, uses={ DateTimeHelper.class})
@DecoratedWith(AcctBranchTransferServiceDecorator.class)
public interface AcctBranchTransferServiceMapper{
	
	@Mappings({
		 @Mapping(expression = "java(oper != null ? oper.getOperation() : null)", target="OPERATION")
	 })
	@InheritConfiguration
	public DEPACCTBRANCHTRANSFERAPIType mapToApi(AcctBranchTransferJpe jpe, @Context CbsXmlApiOperation oper, @Context Map otherInfo);
	
	
	@InheritInverseConfiguration(name = "mapAcctBranchTransferToDEPACCTBRANCHTRANSFERAPIType")
	@Mapping(source = "EFFECTDATE", target="trfDate", qualifiedByName = {"DateTimeHelper","convertCbsApiDateToString"})
	public AcctBranchTransferJpe mapToJpe(DEPACCTBRANCHTRANSFERAPIType api, @MappingTarget AcctBranchTransferJpe jpe);
	
}
