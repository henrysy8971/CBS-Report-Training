package com.silverlakesymmetri.cbs.dep.svc.impl;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mysema.query.types.EntityPath;
import com.silverlakesymmetri.cbs.commons.svc.AbstractBusinessService;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.CiStatus;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.CiStatusRestriction;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.CiStatusRestrictionJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.QCiStatusRestrictionJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.id.CiStatusRestrictionPk;
import com.silverlakesymmetri.cbs.dep.svc.CiStatusRestrictionService;
import com.silverlakesymmetri.cbs.dep.svc.CiStatusService;
import com.silverlakesymmetri.cbs.dep.svc.TranHistService;

@Service
public class CiStatusRestrictionServiceImpl  extends AbstractBusinessService<CiStatusRestriction, CiStatusRestrictionJpe, CiStatusRestrictionPk>
	implements CiStatusRestrictionService {

	@Autowired
	CiStatusService ciStatusService;
	
	@Override
	protected CiStatusRestrictionPk getIdFromDataObjectInstance(CiStatusRestriction dataObject) {
		return new CiStatusRestrictionPk(dataObject.getProcType(), dataObject.getFromStatus(), dataObject.getToStatus());
	}

	@Override
	protected EntityPath<CiStatusRestrictionJpe> getEntityPath() {
		return QCiStatusRestrictionJpe.ciStatusRestrictionJpe;
	}
	
	@Override
	public CiStatusRestriction getByPk(String publicKey, CiStatusRestriction reference) {
		return super.getByPk(publicKey, reference);
	}

	@Override
	public List<CiStatusRestriction> query(int offset, int resultLimit, String groupBy, String order,
			Map<String, Object> filters) {
		
		List<CiStatusRestriction> statusList = super.query(offset, resultLimit, groupBy, order, filters);
		if (statusList != null && statusList.size() > 0) {
			for (CiStatusRestriction status : statusList) {
				CiStatus ciStatus = ciStatusService.getByPk(status.getToStatus(), null);
				status.setToStatusDesc(ciStatus.getChequeStatusDesc());
			}
			return statusList;
		} else {
			return super.query(offset, resultLimit, groupBy, order, filters);
		}
	}
}
