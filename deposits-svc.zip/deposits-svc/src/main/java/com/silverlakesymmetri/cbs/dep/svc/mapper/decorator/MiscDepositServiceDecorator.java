package com.silverlakesymmetri.cbs.dep.svc.mapper.decorator;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

import com.silverlakesymmetri.cbs.commons.xmlapi.enums.CbsXmlApiOperation;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.DepFeeApplyJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.DepositTransactionJpe;
import com.silverlakesymmetri.cbs.dep.svc.mapper.MiscDepositServiceMapper;
import com.silverlakesymmetri.cbs.dep.xmlapi.DEPTRANCTRLPARAMTType;
import com.silverlakesymmetri.cbs.dep.xmlapi.DEPTRANHISTINSAPIType;

public abstract class MiscDepositServiceDecorator extends FeeServiceDecorator implements MiscDepositServiceMapper{
	
	private static final String CBS_CHANNEL_SOURCE = "HTTP-UI";
	private static final String FORCE_POST = "Y";
	private static final String NOT_FORCE_POST = "N";
	
	@Autowired
	@Qualifier("delegate")
	protected  MiscDepositServiceMapper delegate;

	@Override
	public DEPTRANHISTINSAPIType mapToApi(DepositTransactionJpe jpe, CbsXmlApiOperation oper, Map otherInfo){
		
		DEPTRANHISTINSAPIType req = (DEPTRANHISTINSAPIType)delegate.mapToApi(jpe, oper, otherInfo);
		
		if (otherInfo.containsKey(CHANNEL_SOURCE) && otherInfo.get(CHANNEL_SOURCE).equals(CBS_CHANNEL_SOURCE)) {
			if (otherInfo.containsKey(BRANCH)){
				req.setBRANCH((String) otherInfo.get(BRANCH));
			}
		} else {
			req.setBRANCH(jpe.getBranch());
		}
		
		DEPTRANCTRLPARAMTType ctrlParam = new DEPTRANCTRLPARAMTType();
		if (jpe.getHeader() != null && jpe.getHeader().getBpmInfo() != null && jpe.getHeader().getBpmInfo().getOfficerId() != null) {
			ctrlParam.setFORCEPOST(FORCE_POST);
			for (DepFeeApplyJpe feeJpe : jpe.getDepFeeApplyList()) {
				feeJpe.setForcedPost(FORCE_POST);
			}
		} else {
			ctrlParam.setFORCEPOST(NOT_FORCE_POST);
		}
		req.setCTRLPARAM(ctrlParam);
		
		mapFeeToApi(jpe, req);
		
		return  req;
	}
	
	@Override
	public DepositTransactionJpe mapToJpe(DEPTRANHISTINSAPIType api, DepositTransactionJpe jpe){
		
//		delegate.mapToBdo(api, bdo);
		
		//Other things to do
		jpe.setSeqNo(api.getTXNSEQNO());
		mapFeeToJpe(api, jpe);
		return jpe;
	}
}


