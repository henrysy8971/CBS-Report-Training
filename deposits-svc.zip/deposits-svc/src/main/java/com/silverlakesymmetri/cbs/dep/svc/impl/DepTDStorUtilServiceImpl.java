package com.silverlakesymmetri.cbs.dep.svc.impl;

import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.silverlakesymmetri.cbs.commons.jpa.util.DateTimeHelper;
import com.silverlakesymmetri.cbs.dep.jpa.util.DepTDStorHelper;
import com.silverlakesymmetri.cbs.dep.svc.DepTDStorUtilService;

/**
 * 
 * @author Jeffrey.Villanueva
 *
 */
@Service
public class DepTDStorUtilServiceImpl implements DepTDStorUtilService {

	@Autowired
	private DateTimeHelper dateTimeHelper;

	@Autowired
	private DepTDStorHelper depTDStorHelper;

	@Override
	public String calcFdMatDate(Integer freqPeriod, String freqType, Integer freqDay, String ccy, String clientNo, String branch,
			Date runDate) {
		Date matDate = depTDStorHelper.calcFdMatDate(freqPeriod, freqType, freqDay, ccy, clientNo, branch, runDate, null);
		if (matDate != null) {
			return dateTimeHelper.getSDODateTime(matDate);
		}
		return null;
	}

	@Override
	public Double enquireRate(Date effectDate, String intType, String ccy, Double balance, Long freqPeriod,
			String freqType, String crIntRateInd) {
		Double intRate = depTDStorHelper.enquireRate(effectDate, intType, ccy, balance, freqPeriod, freqType,
				crIntRateInd);
		return intRate;
	}

}
