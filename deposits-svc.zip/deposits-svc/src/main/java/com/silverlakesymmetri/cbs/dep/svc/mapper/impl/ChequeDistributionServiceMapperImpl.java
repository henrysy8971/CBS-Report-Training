package com.silverlakesymmetri.cbs.dep.svc.mapper.impl;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

import com.silverlakesymmetri.cbs.commons.jpa.service.CbsGenericDataService;
import com.silverlakesymmetri.cbs.commons.xmlapi.enums.CbsXmlApiOperation;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.CiRdBunchDistJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.CiRdRegJpe;
import com.silverlakesymmetri.cbs.dep.svc.mapper.ChequeDistributionServiceMapper;
import com.silverlakesymmetri.cbs.dep.svc.mapper.CiDistMapper;
import com.silverlakesymmetri.cbs.dep.xmlapi.DEPCIRDAPIType;

@Component
public class ChequeDistributionServiceMapperImpl implements ChequeDistributionServiceMapper{
	
	@Autowired
	protected CiDistMapper ciDistMapper;
		
	@Autowired(required = true)
    @Qualifier("cbsGenericDataService")
    protected CbsGenericDataService dataService;
		
	private CiRdRegJpe getCiRd (CiRdBunchDistJpe jpe){
		
		CiRdRegJpe ciRdRegJpe = new CiRdRegJpe();
		ciRdRegJpe.setChequeRdKey(jpe.getChequeRdKey());
		ciRdRegJpe.setChequeType(jpe.getChequeType());
		ciRdRegJpe.setCcy(jpe.getCcy());
		ciRdRegJpe.setBranch(jpe.getBranch());
		return ciRdRegJpe;
	}

	public DEPCIRDAPIType mapToApi(CiRdBunchDistJpe jpe, CbsXmlApiOperation oper){
		
		if (jpe == null){
			return null;
		}
	
		Map otherInfo = new HashMap<>();	
		otherInfo.put("CiRdBunchCaptureJpeList", jpe.getCiRdBunchCaptureList());
		
		return ciDistMapper.mapToApi(getCiRd(jpe), oper, otherInfo);
	}	
}
	