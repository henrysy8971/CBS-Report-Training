package com.silverlakesymmetri.cbs.dep.svc.mapper.mapping;

import org.mapstruct.MapperConfig;
import org.mapstruct.Mapping;
import org.mapstruct.Mappings;

import com.silverlakesymmetri.cbs.commons.jpa.util.DateTimeHelper;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.OdFacilityOthJpe;
import com.silverlakesymmetri.cbs.dep.xmlapi.DEPODFACILITYAPIType;

@MapperConfig(uses={ DateTimeHelper.class})
public interface OdFacilityOthToDEPODFACILITYAPITypeMapper {

	@Mappings({
		@Mapping(source = "acctNo", target = "ACCTNO"),
		@Mapping(source = "seqNo", target = "SEQNO"),
		@Mapping(source = "priorityNo", target = "PRIORITYNO"),
		@Mapping(source = "odType", target = "OVERDRAFTTYPE"),
		@Mapping(source = "agreementNo", target = "AGREEMENTNO"),
		@Mapping(source = "maturityDate", target = "MATURITYDATE", qualifiedByName = {"DateTimeHelper","convertDateToCbsXmlApiDate"}),
		@Mapping(source = "odEffectFromDate", target = "EFFECTFROMDATE", qualifiedByName = {"DateTimeHelper","convertDateToCbsXmlApiDate"}),
		@Mapping(source = "odEffectToDate", target = "EFFECTTODATE", qualifiedByName = {"DateTimeHelper","convertDateToCbsXmlApiDate"}),
		@Mapping(source = "odNextReviewDate", target = "ODNEXTREVIEWDATE", qualifiedByName = {"DateTimeHelper","convertDateToCbsXmlApiDate"}),
		@Mapping(source = "odOrigAmt", target = "ORIGINALLIMIT"),
		@Mapping(source = "status", target = "STATUS"),
		@Mapping(source = "collatRequired", target = "COLLATREQUIRED"),
		@Mapping(source = "intType", target = "INTERESTTYPE"),
		@Mapping(source = "bssSpread", target = "BUSINESSSPREAD"),
		@Mapping(source = "odIntRate", target = "FIXEDINTERESTRATE"),
		@Mapping(source = "rateSpread", target = "RATESP"),
		@Mapping(source = "compSpread", target = "COMPSP"),
		@Mapping(source = "collSpread", target = "COLLSP"),
		@Mapping(source = "intCalcBasisExpired", target = "INTCALCBASISEXPIRED"),
		@Mapping(source = "repricingInd", target = "REPRICINGIND"),
		@Mapping(source = "repricingFreq", target = "REPRICINGFREQ"),
		@Mapping(source = "nextRepricingDate", target = "NEXTREPRICINGDATE", qualifiedByName = {"DateTimeHelper","convertDateToCbsXmlApiDate"}),
		@Mapping(source = "odStatusCode", target = "ODSTATUSCODE"),
		@Mapping(source = "odStatusCode", target = "STATUSCODE"),
		@Mapping(source = "recType", target = "RECTYPE"),
		@Mapping(source = "recStatus", target = "RECSTATUS"),
		@Mapping(source = "odNarrative", target = "DESCRIPTION"),
		@Mapping(source = "odDelReason", target = "ODDELREASON"),
		@Mapping(source = "odGracePeriodPaymt", target = "ODGRACEPERIODPAYMT"),
		@Mapping(source = "odGracePeriodFee", target = "ODGRACEPERIODFEE"),
		@Mapping(source = "tcInd", target = "AUTOGENFEE"),
		@Mapping(constant = "N", target = "HOSTCHECKFLAG")
	})
	public DEPODFACILITYAPIType mapOdFacilityOthToDEPODFACILITYAPIType(OdFacilityOthJpe jpe);

}
