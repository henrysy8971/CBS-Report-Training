package com.silverlakesymmetri.cbs.dep.svc.mapper.mapping;

import org.mapstruct.MapperConfig;
import org.mapstruct.Mapping;
import org.mapstruct.Mappings;

import com.silverlakesymmetri.cbs.commons.jpa.util.DateTimeHelper;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.SdbAssigneeJpe;
import com.silverlakesymmetri.cbs.dep.xmlapi.DEPSDBASSIGNEEAPIType;

@MapperConfig(uses={ DateTimeHelper.class})
public interface SdbAssigneeToDEPSDBASSIGNEEAPITypeMapper {
	
	@Mappings({
		@Mapping(target="SDBINTERNALKEY",	source="sdbInternalKey"), 
		@Mapping(target="CLIENTNO",			source="clientId"), 
		@Mapping(target="OLDCLIENTNO",		source="oldClientId"), 
		@Mapping(target="BRANCH",			source="branch"), 
		@Mapping(target="BOXNO",			source="boxNo"), 
	 })
	public DEPSDBASSIGNEEAPIType mapSdbAssigneeJpeToDEPSDBASSIGNEEAPIType(SdbAssigneeJpe jpe);	
	

}



