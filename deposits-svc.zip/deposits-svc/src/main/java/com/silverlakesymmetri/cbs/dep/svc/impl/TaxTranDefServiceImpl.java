package com.silverlakesymmetri.cbs.dep.svc.impl;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.mysema.query.types.EntityPath;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.svc.AbstractBusinessService;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.TaxTranDef;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.QTaxTranDefJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.TaxTranDefJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.id.TaxTranDefPk;
import com.silverlakesymmetri.cbs.dep.svc.TaxTranDefService;


@Service
@Transactional
public class TaxTranDefServiceImpl extends AbstractBusinessService<TaxTranDef, TaxTranDefJpe, TaxTranDefPk> implements TaxTranDefService {

    @Override
    protected TaxTranDefPk getIdFromDataObjectInstance(TaxTranDef dataObject) {
        return new TaxTranDefPk(dataObject.getTaxType(), dataObject.getCrDrMaintInd());
    }

    @Override
    protected EntityPath<TaxTranDefJpe> getEntityPath() {
        return QTaxTranDefJpe.taxTranDefJpe;
    }
    
    @Override
    protected TaxTranDef preCreateValidation(TaxTranDef dataObject) {
    	TaxTranDefJpe taxTranDefJpe = jaxbSdoHelper.unwrap(dataObject);
        if (null == taxTranDefJpe.isUsedYn()) {
        	taxTranDefJpe.setUsedYn(false);
        }
        if (null == taxTranDefJpe.isActiveYn()) {
        	taxTranDefJpe.setActiveYn(false);
        }
        
        dataObject = jaxbSdoHelper.wrap(taxTranDefJpe, TaxTranDef.class);
        return super.preCreateValidation(dataObject);
    }
    
    @Override
    public TaxTranDef get(TaxTranDef objectInstanceIdentifier) {
        return super.get(objectInstanceIdentifier);
    }
    
    @Override
    public TaxTranDef create(TaxTranDef objectInstanceIdentifier) {
    	TaxTranDef result = super.create(objectInstanceIdentifier);
		return result;
    }
    
    @Override
    public TaxTranDef update(TaxTranDef objectInstanceIdentifier) {
    	TaxTranDef result = super.update(objectInstanceIdentifier);
        return result;
    }
    
    @Override
    public boolean delete(TaxTranDef dataObject) {
    	boolean result = super.delete(dataObject);
        return result;
    }

    @Override
    public List<TaxTranDef> query(int offset, int resultLimit, String groupBy, String order, Map<String, Object> filters) {
        return super.query(offset, resultLimit, groupBy, order, filters);
    }

    @Override
    public List<TaxTranDef> find(FindCriteria findCriteria, CbsHeader cbsHeader) {
        return super.find(findCriteria, cbsHeader);
    }

    @Override
    public TaxTranDef getByPk(String publicKey, TaxTranDef reference) {
        return super.getByPk(publicKey, reference);
    }
}
