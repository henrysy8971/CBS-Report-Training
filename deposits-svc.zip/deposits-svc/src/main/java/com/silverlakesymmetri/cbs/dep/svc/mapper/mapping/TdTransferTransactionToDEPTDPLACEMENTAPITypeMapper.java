package com.silverlakesymmetri.cbs.dep.svc.mapper.mapping;

import org.mapstruct.MapperConfig;
import org.mapstruct.Mapping;
import org.mapstruct.Mappings;

import com.silverlakesymmetri.cbs.commons.jpa.util.DateTimeHelper;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.TdTransferTransactionJpe;
import com.silverlakesymmetri.cbs.dep.xmlapi.DEPTDPLACEMENTAPIType;

@MapperConfig(uses={ DateTimeHelper.class})
public interface TdTransferTransactionToDEPTDPLACEMENTAPITypeMapper {

	@Mappings({
		@Mapping(source = "acctNo", target="ACCTNO"),
		@Mapping(source = "certificateNo", target="CERTIFICATENO"),
		@Mapping(source = "debitTranType", target="DRTRANTYPE"),
		@Mapping(source = "creditTranType", target="CRTRANTYPE"),
		@Mapping(source = "cpartyAcctNo", target="THIRDPARTYACCT"),
	    @Mapping(source = "effectDate", target="EFFECTDATE", qualifiedByName = {"DateTimeHelper","convertDateToCbsXmlApiDate"}),
	    @Mapping(source = "amount", target="TRANAMT"),
	    @Mapping(source = "equivAmount", target="BASEEQUIVAMT"),
	    @Mapping(source = "drNarrative", target="DRTRANDESC"),
	    @Mapping(source = "crNarrative", target="CRTRANDESC"),
	    @Mapping(source = "crossRate", target="CROSSRATE"),
	    @Mapping(source = "rateReferenceId", target="CROSSRATEREFERENCE"),
	    @Mapping(source = "rateOrigin", target="CROSSRATEORIGIN"),
	    @Mapping(source = "origCrossRate", target="ORIGCROSSRATE"),
		@Mapping(source = "drSeqNo", target="DRSEQNO"),
		@Mapping(source = "crSeqNo", target="CRSEQNO"),
		@Mapping(source = "branch", target="TRANBRANCH")
	})
	public DEPTDPLACEMENTAPIType mapTdTransferTransactionToDEPTDPLACEMENTAPIType(TdTransferTransactionJpe jpe);
}
