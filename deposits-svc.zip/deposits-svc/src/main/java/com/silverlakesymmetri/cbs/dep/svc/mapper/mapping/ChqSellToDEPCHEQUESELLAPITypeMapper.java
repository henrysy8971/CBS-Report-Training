package com.silverlakesymmetri.cbs.dep.svc.mapper.mapping;

import org.mapstruct.DecoratedWith;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Mappings;

import com.silverlakesymmetri.cbs.commons.jpa.util.DateTimeHelper;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.ChqSellJpe;
import com.silverlakesymmetri.cbs.dep.svc.mapper.decorator.ChqSellToDEPCHEQUESELLAPITYPEDecorator;
import com.silverlakesymmetri.cbs.dep.xmlapi.DEPCHEQUESELLAPIType;

@Mapper(uses = { DateTimeHelper.class })
@DecoratedWith(ChqSellToDEPCHEQUESELLAPITYPEDecorator.class)
public interface ChqSellToDEPCHEQUESELLAPITypeMapper {
	
	@Mappings({
		@Mapping(source = "grpCiSeqNoSell", target = "GRPCISEQNO"),
		@Mapping(source = "chequeType", target = "CHEQUETYPE"),
		@Mapping(source = "procType", target = "PROCTYPE"),
		@Mapping(source = "ccy", target = "CCY"),
		@Mapping(source = "denomGrp", target = "DENOMGROUP"),
		@Mapping(source = "narrative", target = "REMARKS"),
		@Mapping(source = "branch", target = "TRANBRANCH")
	})
	public DEPCHEQUESELLAPIType jpeToApiType(ChqSellJpe jpe);
	
}
