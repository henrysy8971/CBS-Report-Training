package com.silverlakesymmetri.cbs.dep.svc.mapper.decorator;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

import com.silverlakesymmetri.cbs.commons.xmlapi.enums.CbsXmlApiOperation;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.ChequeCtrlJpe;
import com.silverlakesymmetri.cbs.dep.svc.mapper.ChequeCtrlServiceMapper;
import com.silverlakesymmetri.cbs.dep.xmlapi.DEPCHQBKRQSTAPIType;

public abstract class ChequeCtrlServiceDecorator extends FeeServiceDecorator implements ChequeCtrlServiceMapper {

	@Autowired
	@Qualifier("delegate")
	protected ChequeCtrlServiceMapper delegate;

	@Override
	public DEPCHQBKRQSTAPIType mapToApi(ChequeCtrlJpe jpe, CbsXmlApiOperation oper, Map otherInfo) {
		DEPCHQBKRQSTAPIType req = (DEPCHQBKRQSTAPIType) delegate.mapToApi(jpe, oper, otherInfo);
		req.setNOOFLEAVES(0);
		if (jpe.getNoOfLeaves() != null) {
			try {
				req.setNOOFLEAVES(Integer.parseInt(jpe.getNoOfLeaves().trim().replace(",", "")));
			} catch (NumberFormatException  e) {
				req.setNOOFLEAVES(0);
			}
		}
		mapFeeToApi(jpe, req);
		return req;
	}

	@Override
	public ChequeCtrlJpe mapToJpe(DEPCHQBKRQSTAPIType api, ChequeCtrlJpe jpe) {
		if (jpe == null) {
			jpe = new ChequeCtrlJpe();
		}
		if (api == null) {
			return jpe;
		}
		delegate.mapToJpe(api, jpe);
		jpe.setNoOfLeaves(api.getNOOFLEAVES() + "");
		// mapFeeToJpe(api, jpe);
		return jpe;
	}

}