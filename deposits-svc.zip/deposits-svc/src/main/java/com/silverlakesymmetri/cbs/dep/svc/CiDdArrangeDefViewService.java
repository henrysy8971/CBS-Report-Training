package com.silverlakesymmetri.cbs.dep.svc;

import java.util.List;
import java.util.Map;

import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation;
import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation.ServiceOperationType;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.svc.BusinessService;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.CiDdArrangeDefView;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.CiDdArrangeDefViewJpe;

public interface CiDdArrangeDefViewService extends BusinessService<CiDdArrangeDefView, CiDdArrangeDefViewJpe> {

    public static final String SVC_OP_NAME_CIDDARRANGEDEFVIEWSERVICE_GET = "CiDdArrangeDefViewService.get";
    public static final String SVC_OP_NAME_CIDDARRANGEDEFVIEWSERVICE_QUERY = "CiDdArrangeDefViewService.query";
    public static final String SVC_OP_NAME_CIDDARRANGEDEFVIEWSERVICE_FIND = "CiDdArrangeDefViewService.find";
    
    @ServiceOperation(name = SVC_OP_NAME_CIDDARRANGEDEFVIEWSERVICE_GET, type = ServiceOperationType.GET)
    public CiDdArrangeDefView getByPk(String publicKey, CiDdArrangeDefView reference);

    @ServiceOperation(name = SVC_OP_NAME_CIDDARRANGEDEFVIEWSERVICE_QUERY)
    public List<CiDdArrangeDefView> query(int offset, int resultLimit, String groupBy, String order, Map<String, Object> filters);

    @ServiceOperation(name = SVC_OP_NAME_CIDDARRANGEDEFVIEWSERVICE_FIND)
    public List<CiDdArrangeDefView> find(FindCriteria findCriteria, CbsHeader cbsHeader);
	
}
