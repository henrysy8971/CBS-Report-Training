package com.silverlakesymmetri.cbs.dep.svc.ext;

import com.silverlakesymmetri.cbs.col.bdo.sdo.AssetWrapper;
import com.silverlakesymmetri.cbs.col.bdo.sdo.CollateralWrapper;
import com.silverlakesymmetri.cbs.col.bdo.sdo.Deposit;
import com.silverlakesymmetri.cbs.col.enums.ColGlobalConstants;
import com.silverlakesymmetri.cbs.col.jpa.mapping.sdo.AssetCategorySetupJpe;
import com.silverlakesymmetri.cbs.col.jpa.mapping.sdo.util.ColJpeConstants;
import com.silverlakesymmetri.cbs.commons.bdo.sdo.CbsServiceDataObjectBase;
import com.silverlakesymmetri.cbs.commons.context.CbsRuntimeContextManager;
import com.silverlakesymmetri.cbs.commons.ext.impl.AbstractServiceExtPointImpl;
import com.silverlakesymmetri.cbs.commons.jpa.extension.JaxbSdoHelper;
import com.silverlakesymmetri.cbs.commons.jpa.service.CbsGenericDataService;
import com.silverlakesymmetri.cbs.commons.logging.CbsAppLogger;
import com.silverlakesymmetri.cbs.commons.logging.CbsAppLoggerFactory;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.AcctRestraint;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.AcctJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.util.DepJpeConstants;
import com.silverlakesymmetri.cbs.dep.svc.AcctRestraintService;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class DepLoanBookingAcctRestraintCreateServiceExtImpl extends AbstractServiceExtPointImpl {

    private CbsAppLogger logger = CbsAppLoggerFactory.getLogger(DepLoanBookingAcctRestraintCreateServiceExtImpl.class.getName());

    @Autowired
    private AcctRestraintService acctRestraintService;

    @Autowired
    protected JaxbSdoHelper jaxbSdoHelper;

    @Autowired
    protected CbsGenericDataService cbsGenericDataService;

    @Autowired
    private CbsRuntimeContextManager cbsRuntimeContextManager;

    @Override
    public String[] getExtendedBdoNames() {
        return new String[] { "LoanBooking" };
    }

    @Override
    public String[] getExtendedServiceNames() {
        return new String[] { "LoanBookingService.create" };
    }

    @Override
    public Object afterService(Object result, Object[] serviceParameters) {

        //if (result != null && result instanceof Asset) {
        if (result != null) {
            Object collWrapperObj = ((CbsServiceDataObjectBase) result).get("collateralList");
            if (collWrapperObj != null) {
                List<CollateralWrapper> collWrapperList = (List<CollateralWrapper>) collWrapperObj;
                if (collWrapperList != null && collWrapperList.size() > 0) {
                    for (CollateralWrapper collwrap : collWrapperList) {
                        if (collwrap.getAssetWrapperList() != null && collwrap.getAssetWrapperList().size() > 0) {
                            for (AssetWrapper asset : collwrap.getAssetWrapperList()) {
                                if (asset != null) {
                                    addAssetRestraint(asset);
                                }
                            }
                        }
                    }
                }

            }
        }
        return result;
    }

    private void addAssetRestraint(AssetWrapper bdo) {
        if (isAssetCategoryDeposit(bdo)) {
            final String colRestraintType = getColRestraintType();
            if (StringUtils.isNotBlank(colRestraintType)) {
                Deposit d = bdo.getDepositRec();
                AcctRestraint arBdo = jaxbSdoHelper.createSdoInstance(AcctRestraint.class);
                arBdo.getChangeSummary().beginLogging();
                arBdo.setAcctNo(d.getAccountNo());
                arBdo.setCertificateNo(getCertificateNo(d.getAccountNo()));
                arBdo.setRestraintType(colRestraintType);
                arBdo.setRestraintClass("FH");
                arBdo.setPledgedAcctNo(d.getAccountNo());
                arBdo.setPledgedAmt(bdo.getAssetAmt());
                arBdo.setSourceModule("COL");
                arBdo.setStartDate(bdo.getStartDt());
                arBdo.setEndDate(bdo.getEndDt());
                if (StringUtils.isBlank(arBdo.getEndDate())) {
                    arBdo.setEndDate("2999-01-01");
                }
                arBdo.setReferenceNo(bdo.getAssetRefNo());
                arBdo.setForceFh("N");
                arBdo.setAutoGenFee("N");
                arBdo.getChangeSummary().endLogging();
                acctRestraintService.create(arBdo);
            } else {
                logger.warn("Missing Registry Collateral Restraint Type.");
            }
        }
    }

    private boolean isAssetCategoryDeposit(AssetWrapper bdo) {
        if (StringUtils.isNotBlank(bdo.getAssetType()) && bdo.getDepositRec() != null && !"DEL".equals(bdo.getStatus())) {
            Map<String, Object> params = new HashMap<>();
            params.put("assetType", bdo.getAssetType());
            AssetCategorySetupJpe acJpe = cbsGenericDataService.getWithNamedQuery(ColJpeConstants.ASSET_CATEGORY_SETUP_JPE_FIND_ASSET_CATEGORY_BY_ASSET_TYPE, params, AssetCategorySetupJpe.class);
            if ("D".equals(acJpe.getAssetCategory()) && StringUtils.isNotBlank(bdo.getDepositRec().getAccountNo())) {
                return true;
            }
        }
        return false;
    }

    private String getColRestraintType() {
        String colRestraintType = cbsRuntimeContextManager.getBestAvailableContext().getRegistryEntry(ColGlobalConstants.COLLATERAL_REGISTRY,
                "colRestraintType", String.class);
        return colRestraintType;
    }

    private String getCertificateNo(String acctNo) {
        Map<String, Object> param = new HashMap<String, Object>();
        param.put("acctNo", acctNo);
        AcctJpe acctJpe = cbsGenericDataService.getWithNamedQuery(DepJpeConstants.ACCT_JPE_FIND_BY_ACCTNO, param, AcctJpe.class);
        return acctJpe.getCertificateNo();
    }
}
