package com.silverlakesymmetri.cbs.dep.svc.mapper.decorator;

import com.silverlakesymmetri.cbs.commons.xmlapi.enums.CbsXmlApiOperation;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.AcctJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.DepFeeApplyJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.TdTransferTransactionJpe;
import com.silverlakesymmetri.cbs.dep.svc.mapper.TdTransferTransactionServiceMapper;
import com.silverlakesymmetri.cbs.dep.svc.mapper.TranValidationFlagsMapper;
import com.silverlakesymmetri.cbs.dep.svc.mapper.mapping.DepFeeApplyToDEPFEEAPPLYINTypeMapper;
import com.silverlakesymmetri.cbs.dep.svc.mapper.mapping.DepTranOtherDataToDEPTRANOTHERDATATTypeMapper;
import com.silverlakesymmetri.cbs.dep.svc.mapper.mapping.ScDetailInToDEPFEEAPPLYDTLINTTypeMapper;
import com.silverlakesymmetri.cbs.dep.svc.mapper.mapping.TranValidationFlagsToDEPTRANVALIDATIONFLAGSTTypeMapper;
import com.silverlakesymmetri.cbs.dep.xmlapi.DEPFEEAPPLYDTLINCOLLType;
import com.silverlakesymmetri.cbs.dep.xmlapi.DEPFEEAPPLYINType;
import com.silverlakesymmetri.cbs.dep.xmlapi.DEPTDPLACEMENTAPIType;
import com.silverlakesymmetri.cbs.dep.xmlapi.DEPTRANOTHERDATACOLLType;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

import java.util.List;
import java.util.Map;

public abstract class TdTransferTransactionServiceDecorator implements TdTransferTransactionServiceMapper, TranValidationFlagsMapper {
	
	@Autowired
	@Qualifier("delegate")
	protected TdTransferTransactionServiceMapper delegate;
	
	@Autowired
	protected DepFeeApplyToDEPFEEAPPLYINTypeMapper feeApplyMapper;

	@Autowired
	protected ScDetailInToDEPFEEAPPLYDTLINTTypeMapper scDetailInMapper;
	
	@Autowired
	protected TranValidationFlagsToDEPTRANVALIDATIONFLAGSTTypeMapper tranValidationFlagsMapper;
	
	@Autowired
	protected DepTranOtherDataToDEPTRANOTHERDATATTypeMapper depTranOtherDataMapper;

	@Override
	public DEPTDPLACEMENTAPIType mapToApi(TdTransferTransactionJpe jpe, CbsXmlApiOperation oper, Map otherInfo) {
		DEPTDPLACEMENTAPIType req = delegate.mapToApi(jpe, oper, otherInfo);
		
		req.setDRSCAPPLYIN(mapFeeToApi(jpe.getDrFeeApplyList()));
		req.setCRSCAPPLYIN(mapFeeToApi(jpe.getCrFeeApplyList()));
		
		AcctJpe acctJpe = null;
		if (otherInfo != null && !otherInfo.isEmpty()){
			if (otherInfo.containsKey("ACCT")){
				acctJpe = (AcctJpe) otherInfo.get("ACCT");
			}
		}
		
		if (jpe.isRemCcy()) {
			req.setTRANAMT(jpe.getAmount());
			if (acctJpe != null){
				req.setTRANCCY(acctJpe.getCcy());	
			}
		} 
		else {
			req.setTRANAMT(jpe.getEquivAmount());
			req.setTRANCCY(jpe.getCpartyAcctCcy());
		}

		if (jpe.getSeqNo() != null) {
			req.setDRSEQNO(jpe.getSeqNo().doubleValue());
		}
		req.setTRANVALIDATIONFLAGS(mapValidationFlags(jpe, "N", "N", "N", "N", "N"));
		req.setAUTOGENFEE("N");

		return req;
	}

	@Override
	public TdTransferTransactionJpe mapToJpe(DEPTDPLACEMENTAPIType api, TdTransferTransactionJpe jpe) {
		if (api.getCRSEQNO() != null) {
			jpe.setCrSeqNo(api.getCRSEQNO().longValue());
		}
		else {
			jpe.setCrSeqNo(null);
		}
		if (api.getDRSEQNO() != null) {
			jpe.setDrSeqNo(api.getDRSEQNO().longValue());
		}
		else {
			jpe.setDrSeqNo(null);
		}

		jpe.setAvailBal(api.getSOURCEAVAILBAL());
		jpe.setLedgerBal(api.getSOURCELEDGERBAL());

		return jpe;
	}
	
	private DEPFEEAPPLYINType mapFeeToApi(List<DepFeeApplyJpe> jpe) {
		DEPFEEAPPLYINType feeApplyIn = null;
		for (DepFeeApplyJpe depFeeApply : jpe) {
			if (feeApplyIn == null) {
				feeApplyIn = feeApplyMapper.mapDepFeeApplyToDEPFEEAPPLYIN(depFeeApply);
				feeApplyIn.setSCDETAILIN(new DEPFEEAPPLYDTLINCOLLType());
				feeApplyIn.setRBTRANOTHERDATAIN(new DEPTRANOTHERDATACOLLType());
			}
			feeApplyIn.getSCDETAILIN().getDEPFEEAPPLYDTLINT()
					.add(scDetailInMapper.mapScDetailInToDEPFEEAPPLYDTLIN(depFeeApply.getScDetailIn()));
			feeApplyIn.getRBTRANOTHERDATAIN().getDEPTRANOTHERDATAT().add(depTranOtherDataMapper
					.mapTranValidationFlagsToDEPTRANVALIDATIONFLAGST(depFeeApply.getRbTranOtherData()));
			feeApplyIn.setTRANVALIDATIONFLAGS(tranValidationFlagsMapper
					.mapTranValidationFlagsToDEPTRANVALIDATIONFLAGST(depFeeApply.getTranValidationFlags()));
		}			
		return feeApplyIn;
	}

}
