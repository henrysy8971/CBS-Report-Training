package com.silverlakesymmetri.cbs.dep.svc;

import java.util.List;
import java.util.Map;

import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation;
import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation.ServiceOperationType;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.svc.BusinessService;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.AcctIntMaint;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.AcctIntMaintJpe;

public interface AcctIntMaintService extends BusinessService<AcctIntMaint, AcctIntMaintJpe> {

    public static final String SVC_OP_NAME_ACCTINTMAINTSERVICE_GET = "AcctIntMaintService.get";
    public static final String SVC_OP_NAME_ACCTINTMAINTSERVICE_QUERY = "AcctIntMaintService.query";
    public static final String SVC_OP_NAME_ACCTINTMAINTSERVICE_CREATE = "AcctIntMaintService.create";
    public static final String SVC_OP_NAME_ACCTINTMAINTSERVICE_UPDATE = "AcctIntMaintService.update";
    public static final String SVC_OP_NAME_ACCTINTMAINTSERVICE_DELETE = "AcctIntMaintService.delete";
    public static final String SVC_OP_NAME_ACCTINTMAINTSERVICE_FIND = "AcctIntMaintService.find";

    @ServiceOperation(name = SVC_OP_NAME_ACCTINTMAINTSERVICE_GET, type = ServiceOperationType.GET)
    public AcctIntMaint getByPk(String publicKey, AcctIntMaint reference);

    @ServiceOperation(name = SVC_OP_NAME_ACCTINTMAINTSERVICE_CREATE)
    public AcctIntMaint create(AcctIntMaint dataObject);

    @ServiceOperation(name = SVC_OP_NAME_ACCTINTMAINTSERVICE_UPDATE)
    public AcctIntMaint update(AcctIntMaint dataObject);

    @ServiceOperation(name = SVC_OP_NAME_ACCTINTMAINTSERVICE_QUERY)
    public List<AcctIntMaint> query(int offset, int resultLimit, String groupBy, String order, Map<String, Object> filters);

    @ServiceOperation(name = SVC_OP_NAME_ACCTINTMAINTSERVICE_DELETE)
    public boolean delete(AcctIntMaint dataObject);

    @ServiceOperation(name = SVC_OP_NAME_ACCTINTMAINTSERVICE_FIND)
    public List<AcctIntMaint> find(FindCriteria findCriteria, CbsHeader cbsHeader);

}
