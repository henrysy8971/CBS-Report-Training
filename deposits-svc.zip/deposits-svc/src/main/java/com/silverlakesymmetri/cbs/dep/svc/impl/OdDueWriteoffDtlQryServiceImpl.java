package com.silverlakesymmetri.cbs.dep.svc.impl;

import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mysema.query.types.EntityPath;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.bpm.constants.BpmConstants;
import com.silverlakesymmetri.cbs.commons.bpm.svc.BpmServiceAdapter;
import com.silverlakesymmetri.cbs.commons.context.CbsSessionContext;
import com.silverlakesymmetri.cbs.commons.exception.CbsRuntimeException;
import com.silverlakesymmetri.cbs.commons.jpa.mapping.sdo.BpmHistoryJpe;
import com.silverlakesymmetri.cbs.commons.jpa.util.BdoHelperJpaImpl;
import com.silverlakesymmetri.cbs.commons.jpa.util.JaxbDatetimeAdapter;
import com.silverlakesymmetri.cbs.commons.logging.CbsAppLogger;
import com.silverlakesymmetri.cbs.commons.logging.annotation.Logger;
import com.silverlakesymmetri.cbs.commons.svc.AbstractXmlApiBusinessService;
import com.silverlakesymmetri.cbs.commons.svc.AccessPrivilegeOperationAndProcessService;
import com.silverlakesymmetri.cbs.commons.svc.BusinessObjectValidationCapable;
import com.silverlakesymmetri.cbs.commons.svc.impl.AccessPrivilegeOperationAndProcessServiceImpl.ServiceOperationEntry;
import com.silverlakesymmetri.cbs.commons.util.AbstractBdoPublicKeyResolverImpl;
import com.silverlakesymmetri.cbs.commons.xmlapi.enums.CbsXmlApiOperation;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.CommonDepObject;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.OdDueWriteoffDtlQry;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.OdRepositoryPaymt;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.OdDueWriteoffDtlJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.OdDueWriteoffDtlQryJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.OdRepositoryPaymtJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.QOdDueWriteoffDtlQryJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.id.OdDueWriteoffDtlPk;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.id.OdDueWriteoffDtlQryPk;
import com.silverlakesymmetri.cbs.dep.svc.OdDueWriteoffDtlQryService;
import com.silverlakesymmetri.cbs.dep.svc.mapper.mapping.OdDueWriteoffDtlQryToDEPODUNPDDUEREVERSALAPITypeMapper;
import com.silverlakesymmetri.cbs.dep.svc.mapper.mapping.OdDueWriteoffDtlQryToOdDueWriteoffDtlQryMapper;
import com.silverlakesymmetri.cbs.dep.xmlapi.DEPODUNPDDUEREVERSALAPIType;

@Service
public class OdDueWriteoffDtlQryServiceImpl extends
		AbstractXmlApiBusinessService<OdDueWriteoffDtlQry, OdDueWriteoffDtlQryJpe, OdDueWriteoffDtlQryPk, DEPODUNPDDUEREVERSALAPIType, DEPODUNPDDUEREVERSALAPIType>
		implements OdDueWriteoffDtlQryService, BusinessObjectValidationCapable<OdDueWriteoffDtlQry> {

	@Logger
	private CbsAppLogger logger;

	@Autowired
	private OdDueWriteoffDtlQryToDEPODUNPDDUEREVERSALAPITypeMapper mapper;

	@Autowired
	private OdDueWriteoffDtlQryToOdDueWriteoffDtlQryMapper odDueWriteoffDtlQryToOdDueWriteoffDtlQryMapper;

	@Autowired
	AccessPrivilegeOperationAndProcessService accessPrivService;

	@Autowired
	private BpmServiceAdapter bpmServiceAdapter;

	private static final String queryStr = "SELECT b FROM BpmHistoryJpe b "
			+ " WHERE b.service = :service "
			+ " AND b.operation = :operation "
			+ " AND b.referenceNo = :referenceNo "
			+ " AND b.status = :status";

	@Override
	protected OdDueWriteoffDtlQryPk getIdFromDataObjectInstance(OdDueWriteoffDtlQry dataObject) {
		return new OdDueWriteoffDtlQryPk(dataObject.getAcctNo(), JaxbDatetimeAdapter.parseDate(dataObject.getDueDate()),
				dataObject.getSeqNo());
	}

	@Override
	protected EntityPath<OdDueWriteoffDtlQryJpe> getEntityPath() {
		return QOdDueWriteoffDtlQryJpe.odDueWriteoffDtlQryJpe;
	}

	@Override
	public Long count(FindCriteria findCriteria, CbsHeader cbsHeader) {
		return dataService.getRowCount(OdDueWriteoffDtlQryJpe.class, jaxbSdoHelper.unwrap(findCriteria));
	}

	@Override
	public void setWriteoffInd(CommonDepObject objectInstanceIdentifier, CbsHeader header) {

		if (objectInstanceIdentifier == null) {
			return;
		}

		String listForReverseWriteoffInd = objectInstanceIdentifier.getPubKeyList();

		if (StringUtils.isEmpty(listForReverseWriteoffInd)) {
			return;
		}

		CbsSessionContext sessionCtx = cbsRuntimeContextManager.getContext(CbsSessionContext.class);
		List<String> pkList = new ArrayList<String>(Arrays.asList(listForReverseWriteoffInd.trim().split(",")));

		if (pkList != null) {

			Integer priority = null;
			String bpmProcess = null;
			List<ServiceOperationEntry> userBpmEnabledServiceList = accessPrivService
					.getUserBpmEnabledService(SVC_OP_NAME_ODDUEWRITEOFFDTLQRYSERVICE_UPDATE);
			String service = SVC_OP_NAME_ODDUEWRITEOFFDTLQRYSERVICE_UPDATE.split("\\.")[0];
			String operation = SVC_OP_NAME_ODDUEWRITEOFFDTLQRYSERVICE_UPDATE.split("\\.")[1];

			if (userBpmEnabledServiceList != null) {
				for (ServiceOperationEntry userBpmEnabledService : userBpmEnabledServiceList) {
					priority = userBpmEnabledService.getPriority();
					bpmProcess = userBpmEnabledService.getBpmProcess();
				}
			}

			for (String pk : pkList) {
				OdDueWriteoffDtlQry bdo = getOdDueWriteoffDtlQry(pk);
				if (bdo != null) {
					bdo.setHeader(header);
					if (header.getBpmInfo() != null && !StringUtils.isBlank(bpmProcess)) {
						String screenUrl = "/account-workspace/" + urlEncodeStr(bdo.getAcctNo())
								+ "/acct/detail-screen/od-unpaid-due-writeoff-detail/" + urlEncodeStr(pk)
								+ ";domain=DEPOSIT";
						Map<String, Object> params = new HashMap<>();
						params.put("service", service);
						params.put("operation", operation);
						params.put("referenceNo", bdo.getPublicKey());
						params.put("status", BpmConstants.FOR_APPROVAL);
						List<BpmHistoryJpe> existing = dataService.findWithQuery(queryStr, BpmHistoryJpe.class, params, null);
						if (existing == null || existing.isEmpty()) {
							try {
								header.getBpmInfo().setUniqueDataKey("publicKey:" + pk + "|");
								bdo = bpmServiceAdapter.createWorkItem(bdo, sessionCtx.getUserCode(),
										SVC_OP_NAME_ODDUEWRITEOFFDTLQRYSERVICE_UPDATE, screenUrl, bpmProcess,
										header.getBpmInfo().getActivityName(), header.getBpmInfo().getScreenMode(),
										priority, pk);
							} catch (Exception e) {
								throw new CbsRuntimeException(e.getMessage());
							}
						}
					} else {
						executeStoredProcedureUpdate(bdo, true);
					}
				}
			}
		}
	}

	@Override
	public OdDueWriteoffDtlQry update(OdDueWriteoffDtlQry dataObject) {
		OdDueWriteoffDtlQry bdo = super.update(dataObject);
		bdo = retrieveOdRepositoryPaymtList(bdo);
		computeTotalTranAmt(bdo);
		return bdo;
	}

	private OdDueWriteoffDtlQry getOdDueWriteoffDtlQry(String pk) {
		AbstractBdoPublicKeyResolverImpl bdoPublicKeyResolver = (BdoHelperJpaImpl) getBdoHelper();
		String[] pkValues = bdoPublicKeyResolver.splitPublicKeyParts(pk);
		final String acctNo = pkValues[0] == null ? null : pkValues[0];
		final Date dueDate = pkValues[1] == null ? null : JaxbDatetimeAdapter.parseDate(pkValues[1]);
		final Long seqNo = pkValues[2] == null ? null : Long.valueOf(pkValues[2]);
		OdDueWriteoffDtlQryPk qryPk = new OdDueWriteoffDtlQryPk(acctNo, dueDate, seqNo);
		OdDueWriteoffDtlQryJpe qryJpe = dataService.find(OdDueWriteoffDtlQryJpe.class, qryPk);
		OdDueWriteoffDtlQry bdo = jaxbSdoHelper.wrap(qryJpe);
		bdo.setAcctNo(acctNo);
		bdo.setPublicKey(pk);
		return bdo;
	}

	@Override
	public List<OdDueWriteoffDtlQry> query(int offset, int resultLimit, String groupBy, String order, Map<String, Object> filters) {
		return super.query(offset, resultLimit, groupBy, order, filters);
	}

	@Override
	public List<OdDueWriteoffDtlQry> find(FindCriteria findCriteria, CbsHeader cbsHeader) {
		return super.find(findCriteria, cbsHeader);
	}

	@Override
	public OdDueWriteoffDtlQry getByPk(String publicKey, OdDueWriteoffDtlQry reference) {
		OdDueWriteoffDtlQry bdo = super.getByPk(publicKey, reference);
		bdo = retrieveOdRepositoryPaymtList(bdo);
		computeTotalTranAmt(bdo);
		return bdo;
	}

	@Override
	protected DEPODUNPDDUEREVERSALAPIType transformBdoToXmlApiRqCreate(OdDueWriteoffDtlQry dataObject) {
		return transformOdDueWriteoffDtlToDEPODUNPDDUEREVERSALAPIType(dataObject, CbsXmlApiOperation.INSERT);
	}

	private DEPODUNPDDUEREVERSALAPIType transformOdDueWriteoffDtlToDEPODUNPDDUEREVERSALAPIType(
			OdDueWriteoffDtlQry dataObject, CbsXmlApiOperation oper) {
		OdDueWriteoffDtlQryJpe jpe = jaxbSdoHelper.unwrap(dataObject, OdDueWriteoffDtlQryJpe.class);
		DEPODUNPDDUEREVERSALAPIType xmlApiRq = mapper.jpeToApiType(jpe);
		xmlApiRq.setREVWRITEOFFIND("W");
		xmlApiRq.setOPERATION(oper.getOperation());
		super.setTechColsFromDataObject(dataObject, xmlApiRq);
		return xmlApiRq;
	}

	@Override
	protected DEPODUNPDDUEREVERSALAPIType transformBdoToXmlApiRqUpdate(OdDueWriteoffDtlQry dataObject) {
		return transformBdoToXmlApiRqCreate(dataObject);
	}

	@Override
	protected DEPODUNPDDUEREVERSALAPIType transformBdoToXmlApiRqDelete(OdDueWriteoffDtlQry dataObject) {
		return null;
	}

	@Override
	protected OdDueWriteoffDtlQry processXmlApiRs(OdDueWriteoffDtlQry dataObject, DEPODUNPDDUEREVERSALAPIType xmlApiRs) {
		if (xmlApiRs != null && xmlApiRs.getDUEDATE() != null && xmlApiRs.getSEQNO() != null) {
			OdDueWriteoffDtlQryJpe jpe = mapper.apiTypeToJpe(xmlApiRs);
			if (jpe.getSeqNo() > 0l) {
				OdDueWriteoffDtlPk pk = new OdDueWriteoffDtlPk(jpe.getDueDate(), jpe.getSeqNo());
				OdDueWriteoffDtlJpe dtlJpe = dataService.find(OdDueWriteoffDtlJpe.class, pk);
				if (dtlJpe != null) {
					OdDueWriteoffDtlQryJpe qryJpe = odDueWriteoffDtlQryToOdDueWriteoffDtlQryMapper.toOdDueWriteoffDtlQry(dtlJpe);
					OdDueWriteoffDtlQry bdo = jaxbSdoHelper.wrap(qryJpe);
					return bdo;
				}
			} else {
				OdDueWriteoffDtlQryPk qryPk = new OdDueWriteoffDtlQryPk(jpe.getAcctNo(), jpe.getDueDate(), jpe.getSeqNo());
				OdDueWriteoffDtlQryJpe qryJpe = dataService.find(OdDueWriteoffDtlQryJpe.class, qryPk);
				OdDueWriteoffDtlQry bdo = jaxbSdoHelper.wrap(qryJpe);
				return bdo;
			}
		}
		return dataObject;
	}

	@Override
	protected List<OdDueWriteoffDtlQry> processXmlApiListRs(OdDueWriteoffDtlQry dataObject, DEPODUNPDDUEREVERSALAPIType depodunpdduereversalapiType) {
		return null;
	}

	@Override
	protected Class<DEPODUNPDDUEREVERSALAPIType> getXmlApiResponseClass() {
		return DEPODUNPDDUEREVERSALAPIType.class;
	}

	private OdDueWriteoffDtlQry retrieveOdRepositoryPaymtList(OdDueWriteoffDtlQry dataObject) {
		OdDueWriteoffDtlQryJpe jpe = jaxbSdoHelper.unwrap(dataObject);
		if (jpe.getSeqNo() > 0l) {
			Map<String, Object> param = new HashMap<>();
			param.put("dueDate", jpe.getDueDate());
			param.put("seqNo", jpe.getSeqNo());
			List<OdRepositoryPaymtJpe> list =  dataService.find(param, OdRepositoryPaymtJpe.class);
			jpe.getOdRepositoryPaymtList().addAll(list);
		}
		return jaxbSdoHelper.wrap(jpe);
	}

	private void computeTotalTranAmt(OdDueWriteoffDtlQry bdo) {
		Double totalTranAmt = 0d;
		if (bdo.getOdRepositoryPaymtList() != null && bdo.getOdRepositoryPaymtList().size() > 0) {
			for (OdRepositoryPaymt paymtBdo : bdo.getOdRepositoryPaymtList()) {
				if (paymtBdo.getTranAmt() != null) {
					totalTranAmt += paymtBdo.getTranAmt();
				}
				paymtBdo.setCcy(bdo.getCcy());
			}
		}
		bdo.setTotalTranAmt(totalTranAmt);
	}

	private String urlEncodeStr(String input) {
		if (input == null) {
			return input;
		} else {
			try {
				return URLEncoder.encode(input, "UTF-8");
			} catch (Exception e) {
				return input;
			}
		}
	}

}
