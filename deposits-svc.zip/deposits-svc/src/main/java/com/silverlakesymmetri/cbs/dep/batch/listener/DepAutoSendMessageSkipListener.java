package com.silverlakesymmetri.cbs.dep.batch.listener;

import org.springframework.batch.core.SkipListener;

import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.MessageQJpe;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.util.XpsJpeConstants;
import com.silverlakesymmetri.cbs.xps.svc.batch.listener.AbstractMessageQueueSkipListener;

public class DepAutoSendMessageSkipListener extends AbstractMessageQueueSkipListener<MessageQJpe, MessageQJpe>
		implements SkipListener<MessageQJpe, MessageQJpe> {

	@Override
	protected void updateStatusToFailed(MessageQJpe item, Throwable t) {
		super.updateStatusToFailed(item, t);
	}

	@Override
	protected String getFailedStatus() {
		return XpsJpeConstants.MESSAG_Q_STATUS_AUTO_SEND;
	}
	
}
