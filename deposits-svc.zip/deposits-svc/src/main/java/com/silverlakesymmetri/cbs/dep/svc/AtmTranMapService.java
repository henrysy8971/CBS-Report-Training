package com.silverlakesymmetri.cbs.dep.svc;

import java.util.List;
import java.util.Map;

import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation;
import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation.ServiceOperationType;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.svc.BusinessService;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.AtmTranMap;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.AtmTranMapJpe;

public interface AtmTranMapService extends BusinessService<AtmTranMap, AtmTranMapJpe>{
	public static final String SVC_OP_NAME_ATMTRANMAPSERVICE_GET = "AtmTranMapService.get";
    public static final String SVC_OP_NAME_ATMTRANMAPSERVICE_QUERY = "AtmTranMapService.query";
    public static final String SVC_OP_NAME_ATMTRANMAPSERVICE_CREATE = "AtmTranMapService.create";
    public static final String SVC_OP_NAME_ATMTRANMAPSERVICE_UPDATE = "AtmTranMapService.update";
    public static final String SVC_OP_NAME_ATMTRANMAPSERVICE_DELETE = "AtmTranMapService.delete";
    public static final String SVC_OP_NAME_ATMTRANMAPSERVICE_FIND = "AtmTranMapService.find";
    
    @ServiceOperation(name = SVC_OP_NAME_ATMTRANMAPSERVICE_GET, type = ServiceOperationType.GET)
    public AtmTranMap getByPk(String publicKey, AtmTranMap reference);

    @ServiceOperation(name = SVC_OP_NAME_ATMTRANMAPSERVICE_CREATE)
    public AtmTranMap create(AtmTranMap dataObject);

    @ServiceOperation(name = SVC_OP_NAME_ATMTRANMAPSERVICE_UPDATE)
    public AtmTranMap update(AtmTranMap dataObject);

    @ServiceOperation(name = SVC_OP_NAME_ATMTRANMAPSERVICE_QUERY)
    public List<AtmTranMap> query(int offset, int resultLimit, String groupBy, String order, Map<String, Object> filters);

    @ServiceOperation(name = SVC_OP_NAME_ATMTRANMAPSERVICE_DELETE)
    public boolean delete(AtmTranMap dataObject);

    @ServiceOperation(name = SVC_OP_NAME_ATMTRANMAPSERVICE_FIND)
    public List<AtmTranMap> find(FindCriteria findCriteria, CbsHeader cbsHeader);

}
