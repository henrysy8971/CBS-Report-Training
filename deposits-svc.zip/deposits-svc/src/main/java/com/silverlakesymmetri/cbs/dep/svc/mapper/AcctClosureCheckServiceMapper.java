package com.silverlakesymmetri.cbs.dep.svc.mapper;

import java.util.List;

import org.mapstruct.DecoratedWith;
import org.mapstruct.InheritConfiguration;
import org.mapstruct.Mapper;

import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.AcctClosureCheckJpe;
import com.silverlakesymmetri.cbs.dep.svc.mapper.decorator.AcctClosureCheckServiceDecorator;
import com.silverlakesymmetri.cbs.dep.svc.mapper.mapping.AcctClosureCheckToDEPACCTCLOSECHECKTTypeMapper;
import com.silverlakesymmetri.cbs.dep.xmlapi.DEPACCTCLOSECHECKTType;

@Mapper(config=AcctClosureCheckToDEPACCTCLOSECHECKTTypeMapper.class)
@DecoratedWith(AcctClosureCheckServiceDecorator.class)
public interface AcctClosureCheckServiceMapper{
	

	@InheritConfiguration(name = "mapDEPACCTCLOSECHECKTTypeListToAcctClosureCheckJpeList")
	public List<AcctClosureCheckJpe> mapToJpe(List<DEPACCTCLOSECHECKTType> api);
	
	@InheritConfiguration
	public AcctClosureCheckJpe mapDEPACCTCLOSECHECKTTypeToAcctClosureCheckJpe(DEPACCTCLOSECHECKTType  api);	
}
