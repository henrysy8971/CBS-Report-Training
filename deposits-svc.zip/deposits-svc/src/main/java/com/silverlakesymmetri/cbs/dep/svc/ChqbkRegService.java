package com.silverlakesymmetri.cbs.dep.svc;

import java.util.List;
import java.util.Map;

import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation;
import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation.ServiceOperationType;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.svc.BusinessService;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.ChqbkReg;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.ChqbkRegJpe;

public interface ChqbkRegService extends BusinessService<ChqbkReg, ChqbkRegJpe> {

	public static final String SVC_OP_NAME_CHQBKREGSERVICE_GET= "ChqbkRegService.get";
	public static final String SVC_OP_NAME_CHQBKREGSERVICE_QUERY= "ChqbkRegService.query";
	public static final String SVC_OP_NAME_CHQBKREGSERVICE_CREATE= "ChqbkRegService.create";
	public static final String SVC_OP_NAME_CHQBKREGSERVICE_UPDATE= "ChqbkRegService.update";
	public static final String SVC_OP_NAME_CHQBKREGSERVICE_DELETE= "ChqbkRegService.delete";
	public static final String SVC_OP_NAME_CHQBKREGSERVICE_FIND= "ChqbkRegService.find";
	public static final String  SVC_OP_NAME_CHQBKREGSERVICE_COUNT = "ChqbkRegService.count";
	
	@ServiceOperation(name = SVC_OP_NAME_CHQBKREGSERVICE_CREATE)
    public ChqbkReg create(ChqbkReg dataObject);

    @ServiceOperation(name = SVC_OP_NAME_CHQBKREGSERVICE_UPDATE)
    public ChqbkReg update(ChqbkReg dataObject);

    @ServiceOperation(name = SVC_OP_NAME_CHQBKREGSERVICE_DELETE)
    public boolean delete(ChqbkReg dataObject);

    @ServiceOperation(name = SVC_OP_NAME_CHQBKREGSERVICE_QUERY)
    public List<ChqbkReg> query(int offset, int resultLimit, String groupBy, String order, Map<String, Object> filters);

    @ServiceOperation(name = SVC_OP_NAME_CHQBKREGSERVICE_FIND)
    public List<ChqbkReg> find(FindCriteria findCriteria, CbsHeader cbsHeader);

    @ServiceOperation(name = SVC_OP_NAME_CHQBKREGSERVICE_GET, type = ServiceOperationType.GET)
    public ChqbkReg getByPk(String publicKey, ChqbkReg reference);

	@ServiceOperation(name = SVC_OP_NAME_CHQBKREGSERVICE_COUNT, type = ServiceOperationType.GET)
	public Long count(FindCriteria findCriteria, CbsHeader cbsHeader);
	
}
