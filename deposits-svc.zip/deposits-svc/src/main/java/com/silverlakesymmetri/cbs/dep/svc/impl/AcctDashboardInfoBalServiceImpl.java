package com.silverlakesymmetri.cbs.dep.svc.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.mysema.query.types.EntityPath;
import com.silverlakesymmetri.cbs.commons.svc.AbstractXmlApiBusinessService;
import com.silverlakesymmetri.cbs.commons.xmlapi.enums.CbsXmlApiOperation;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.AcctDashboardInfoBal;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.AcctDashboardInfoBalJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.QAcctDashboardInfoBalJpe;
import com.silverlakesymmetri.cbs.dep.svc.AcctDashboardInfoBalService;
import com.silverlakesymmetri.cbs.dep.svc.mapper.AcctDashboardInfoBalServiceMapper;
import com.silverlakesymmetri.cbs.dep.xmlapi.DEPACCTQRYAPIType;

@Service
@Transactional
public class AcctDashboardInfoBalServiceImpl extends AbstractXmlApiBusinessService<AcctDashboardInfoBal, AcctDashboardInfoBalJpe, String, DEPACCTQRYAPIType, DEPACCTQRYAPIType> implements AcctDashboardInfoBalService {
	
	@Autowired
	AcctDashboardInfoBalServiceMapper mapper;
		
	@Override
	protected EntityPath<AcctDashboardInfoBalJpe> getEntityPath() {
		return QAcctDashboardInfoBalJpe.acctDashboardInfoBalJpe;
	}

	@Override
	protected String getIdFromDataObjectInstance(AcctDashboardInfoBal dataObject) {
		return dataObject.getAcctNo();
	}

	@Override
	public AcctDashboardInfoBal getByPk(String publicKey, AcctDashboardInfoBal dataObject) {
		if (dataObject == null){
			dataObject = jaxbSdoHelper.createSdoInstance(AcctDashboardInfoBal.class);
		}
		dataObject.setAcctNo(publicKey);
		return queryDataObject(transformAcctDashboardInfoBalToDEPACCTQRYAPIType(dataObject, CbsXmlApiOperation.QUERY));
	}

	@Override
	protected DEPACCTQRYAPIType transformBdoToXmlApiRqCreate(AcctDashboardInfoBal dataObject) {
		return null;
	}

	@Override
	protected DEPACCTQRYAPIType transformBdoToXmlApiRqUpdate(AcctDashboardInfoBal dataObject) {
		return null;
	}

	@Override
	protected DEPACCTQRYAPIType transformBdoToXmlApiRqDelete(AcctDashboardInfoBal dataObject) {
		return null;
	}

	@Override
	protected AcctDashboardInfoBal processXmlApiRs(AcctDashboardInfoBal dataObject, DEPACCTQRYAPIType xmlApiRs) {
		
		if (dataObject == null){
			dataObject = jaxbSdoHelper.createSdoInstance(AcctDashboardInfoBal.class);
		}
		AcctDashboardInfoBalJpe jpe = jaxbSdoHelper.unwrap(dataObject);
		mapper.mapToJpe(xmlApiRs, jpe);
		dataObject = jaxbSdoHelper.wrap(jpe);
		
		return dataObject;
	}

	@Override
	protected Class<DEPACCTQRYAPIType> getXmlApiResponseClass() {
		return DEPACCTQRYAPIType.class;
	}

	private DEPACCTQRYAPIType transformAcctDashboardInfoBalToDEPACCTQRYAPIType(AcctDashboardInfoBal dataObject, CbsXmlApiOperation oper){
		
		AcctDashboardInfoBalJpe jpe = jaxbSdoHelper.unwrap(dataObject);
		DEPACCTQRYAPIType apiType =  mapper.mapToApi(jpe, oper);
		super.setTechColsFromDataObject(dataObject, apiType);
		
		return apiType;
	}

	@Override
	protected List<AcctDashboardInfoBal> processXmlApiListRs(AcctDashboardInfoBal dataObject,
			DEPACCTQRYAPIType xmlApiRs) {
		return null;
	}

}
