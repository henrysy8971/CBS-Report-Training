package com.silverlakesymmetri.cbs.dep.svc.mapper;

import java.util.Map;

import org.mapstruct.Context;
import org.mapstruct.DecoratedWith;
import org.mapstruct.InheritConfiguration;
import org.mapstruct.InheritInverseConfiguration;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingTarget;
import org.mapstruct.Mappings;

import com.silverlakesymmetri.cbs.commons.jpa.util.DateTimeHelper;
import com.silverlakesymmetri.cbs.commons.xmlapi.enums.CbsXmlApiOperation;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.OdTmpLimitJpe;
import com.silverlakesymmetri.cbs.dep.svc.mapper.decorator.OdTmpLimitServiceDecorator;
import com.silverlakesymmetri.cbs.dep.svc.mapper.mapping.ODTmpLimitToDEPODTMPLIMITAPITypeMapper;
import com.silverlakesymmetri.cbs.dep.xmlapi.DEPODTMPLIMITAPIType;

@Mapper(config = ODTmpLimitToDEPODTMPLIMITAPITypeMapper.class, uses = { DateTimeHelper.class })
@DecoratedWith(OdTmpLimitServiceDecorator.class)
public interface OdTmpLimitServiceMapper {

	@SuppressWarnings("rawtypes")
	@InheritConfiguration
	public DEPODTMPLIMITAPIType mapToApi(OdTmpLimitJpe jpe, @Context CbsXmlApiOperation oper, @Context Map otherInfo);

	@Mappings({
		@Mapping(source = "TMPLIMITFROMDATE", target = "tmpLimitFromDate", qualifiedByName = { "DateTimeHelper", "convertCbsApiDateToString" }),
		@Mapping(source = "TMPLIMITTODATE", target = "tmpLimitToDate", qualifiedByName = { "DateTimeHelper", "convertCbsApiDateToString" })
	})
	@InheritInverseConfiguration(name = "mapOdTmpLimitToDEPODTMPLIMITAPIType")
	public OdTmpLimitJpe mapToJpe(DEPODTMPLIMITAPIType api, @MappingTarget OdTmpLimitJpe jpe);

}
