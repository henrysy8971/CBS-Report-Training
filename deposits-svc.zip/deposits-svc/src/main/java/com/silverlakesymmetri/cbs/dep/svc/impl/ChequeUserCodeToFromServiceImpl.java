package com.silverlakesymmetri.cbs.dep.svc.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.mysema.query.types.EntityPath;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.bdo.sdo.User;
import com.silverlakesymmetri.cbs.commons.jpa.mapping.sdo.QUserJpe;
import com.silverlakesymmetri.cbs.commons.jpa.mapping.sdo.UserJpe;
import com.silverlakesymmetri.cbs.commons.svc.AbstractBusinessService;
import com.silverlakesymmetri.cbs.dep.svc.ChequeUserCodeToFromService;

@Service
@Transactional
public class ChequeUserCodeToFromServiceImpl extends AbstractBusinessService<User, UserJpe, String> 
	implements ChequeUserCodeToFromService{

	@Override
	protected String getIdFromDataObjectInstance(User dataObject) {
		return dataObject.getUserCode();
	}

	@Override
	protected EntityPath<UserJpe> getEntityPath() {
		return QUserJpe.userJpe;
	}
	
	@Override
	public List<User> find(FindCriteria findCriteria, CbsHeader cbsHeader){
		return super.find(findCriteria, cbsHeader);
	}
	
	@Override 
	public List<User> query(int offset, int resultLimit, String groupBy, String order,
			Map<String, Object> filters){
		String transferMode = (String) filters.get("transferMode");
		List<User> list = new ArrayList<>();
		
		if(filters.get("transferMode") != null) {
			filters.remove("transferMode");
		}
		
		if(transferMode != null) {
			if(transferMode.equals("TC")) {
				list = (List<User>) this.userCodeQueryTC(offset, resultLimit, filters);	
			}else {
				list = (List<User>) this.userCodeQuery(offset, resultLimit, filters, transferMode);
			}
		}else {
			list = (List<User>) this.userCodeQuery(offset, resultLimit, filters, transferMode);
		}
		
		return list;
	}
	
	private List<User> userCodeQueryTC(int offset, int resultLimit, Map<String, Object> filters){
		List<User> list = new ArrayList<>();
		String userCode = (String) filters.get("userCode");
		String displayName = (String) filters.get("displayName");
		String userCodeFrom = (String) filters.get("userCodeFrom");
		
		String query = "Select a from UserJpe a "
				+ "Inner Join UserRolesJpe b on (a.userCode = b.userCode) "
				+ "Inner Join UserOrganizationJpe c on (a.userCode = c.userCode) "
				+ "Where b.businessRoleName = 'Custodian' "
				+ "And c.branch = :branch ";
		
		if(userCode != null) {
			query = query + "AND a.userCode = :userCode ";
		}
		
		if(displayName != null) {
			query = query + "AND a.displayName = :displayName ";
		}
		
		if(userCodeFrom != null) {
			query = query + "AND a.userCode <> :userCodeFrom ";
		}

		query = query + "UNION "
				+ "Select a from UserJpe a "
				+ "Inner Join UserRolesJpe b on (a.userCode = b.userCode) "
				+ "Inner Join UserProfilesJpe c on (a.userCode = c.userCode) "
				+ "Where b.businessRoleName = 'Custodian' "
				+ "And c.profileCode = :branch "
				+ "And c.defaultYn = true ";

		if(userCode != null) {
			query = query + "AND a.userCode = :userCode ";
		}

		if(displayName != null) {
			query = query + "AND a.displayName = :displayName ";
		}

		if(userCodeFrom != null) {
			query = query + "AND a.userCode <> :userCodeFrom ";
		}
		
		List<UserJpe> jpeList = dataService.findWithQuery(query, filters, offset, resultLimit, UserJpe.class);
		
		if(jpeList != null && !jpeList.isEmpty()) {
			for(UserJpe jpe: jpeList) {
				list.add(jaxbSdoHelper.wrap(jpe, User.class));
			}
		}
		
		return list;
	}
	
	private List<User> userCodeQuery(int offset, int resultLimit, Map<String, Object> filters, String transferMode){
		List<User> list = new ArrayList<>();
		String branch = (String) filters.get("branch");
		String userCode = (String) filters.get("userCode");
		String displayName = (String) filters.get("displayName");
		String userCodeFrom = (String) filters.get("userCodeFrom");
		boolean whereClause = true;

		/*
		String query = "Select x from "
				+ "(Select a from UserJpe a "
				+ "Inner Join UserOrganizationJpe b on (a.userCode = b.userCode) "
				+ "Where b.branch = :branch "
				+ "UNION "
				+ "Select a from UserJpe a "
				+ "Inner Join UserProfilesJpe b on (a.userCode = b.userCode) "
				+ "Where b.profileCode = :branch) x ";
		
		if(userCode != null) {
			if (whereClause) {
				whereClause = false;
				query = query + "WHERE x.userCode = :userCode ";
			} else {
				query = query + "AND x.userCode = :userCode ";
			}

		}
		
		if(displayName != null) {
			if (whereClause) {
				whereClause = false;
				query = query + "WHERE x.displayName = :displayName ";
			} else {
				query = query + "AND x.displayName = :displayName ";
			}
		}

		if (!"CT".equals(transferMode)) {
			if (userCodeFrom != null) {
				if (whereClause) {
					whereClause = false;
					query = query + "WHERE x.userCode <> :userCodeFrom ";
				} else {
					query = query + "AND x.userCode <> :userCodeFrom ";
				}
			}
		}
		
		List<UserJpe> jpeList = dataService.findWithQuery(query, filters, offset, resultLimit, UserJpe.class);
		*/

		final Map<String, Object> parameters = new HashMap<>();
		parameters.put("branch", branch);

		String query = "Select x.* from " +
				"    (Select a.* from CUT_USER a " +
				"    Inner Join CUT_USER_ORGANIZATION b on (a.user_Code = b.user_Code) " +
				"    Where b.branch = ?branch " +
				"    union " +
				"    Select a.* from CUT_USER a " +
				"    Inner Join CUT_USER_PROFILES b on (a.user_Code = b.user_Code) " +
				"    Where b.profile_code = ?branch) x ";

		if(userCode != null) {
			parameters.put("userCode", userCode);
			if (whereClause) {
				whereClause = false;
				query = query + "WHERE x.user_code = ?userCode ";
			} else {
				query = query + "AND x.user_code = ?userCode ";
			}
		}

		if(displayName != null) {
			parameters.put("displayName", displayName);
			if (whereClause) {
				whereClause = false;
				query = query + "WHERE x.display_name = ?displayName ";
			} else {
				query = query + "AND x.display_name = ?displayName ";
			}
		}

		if (!"CT".equals(transferMode)) {
			if (userCodeFrom != null) {
				parameters.put("userCodeFrom", userCodeFrom);
				if (whereClause) {
					whereClause = false;
					query = query + "WHERE x.user_code <> ?userCodeFrom ";
				} else {
					query = query + "AND x.user_code <> ?userCodeFrom ";
				}
			}
		}

		List<UserJpe> jpeList = dataService.findWithNativeQuery(query, parameters, offset, resultLimit, UserJpe.class);
		
		if(jpeList != null && !jpeList.isEmpty()) {
			for(UserJpe jpe: jpeList) {
				list.add(jaxbSdoHelper.wrap(jpe, User.class));
			}
		}
		
		return list;
	}
	
}
