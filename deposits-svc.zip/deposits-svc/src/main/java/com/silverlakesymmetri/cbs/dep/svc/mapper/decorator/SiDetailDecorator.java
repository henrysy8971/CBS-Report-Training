package com.silverlakesymmetri.cbs.dep.svc.mapper.decorator;

import java.util.Map;

import org.mapstruct.Context;
import org.mapstruct.MappingTarget;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

import com.silverlakesymmetri.cbs.commons.xmlapi.enums.CbsXmlApiOperation;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.SiDetailJpe;
import com.silverlakesymmetri.cbs.dep.svc.mapper.SiDetailMapper;
import com.silverlakesymmetri.cbs.dep.xmlapi.DEPSIDETAILAPIType;

public abstract class SiDetailDecorator implements SiDetailMapper{
	
	@Autowired
	@Qualifier("delegate")
	protected  SiDetailMapper delegate;
	
	
	@Override
	public DEPSIDETAILAPIType mapToApi(SiDetailJpe jpe, @Context CbsXmlApiOperation oper, @Context Map otherInfo){
		
		DEPSIDETAILAPIType req = (DEPSIDETAILAPIType)delegate.mapToApi(jpe, oper, otherInfo);
		
//		if (otherInfo.containsKey(BRANCH)){
//			req.setBRANCH((String) otherInfo.get(BRANCH));
//		}

		return  req;
	}
	
	@Override
	public SiDetailJpe mapToJpe(DEPSIDETAILAPIType api, @MappingTarget SiDetailJpe jpe){
		
		delegate.mapToJpe(api, jpe);
//		jpe.setSeqNo(api.getTXNSEQNO());
		
		return jpe;
	}
}


