package com.silverlakesymmetri.cbs.dep.svc.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.mysema.query.types.EntityPath;
import com.silverlakesymmetri.cbs.commons.context.CbsSessionContext;
import com.silverlakesymmetri.cbs.commons.logging.CbsAppLogger;
import com.silverlakesymmetri.cbs.commons.logging.CbsAppLoggerFactory;
import com.silverlakesymmetri.cbs.commons.svc.AbstractXmlApiBusinessService;
import com.silverlakesymmetri.cbs.commons.xmlapi.enums.CbsXmlApiOperation;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.FeeInquiryHdr;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.AcctJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.FeeInquiryHdrJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.QFeeInquiryHdrJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.TranDefJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.id.TranDefPk;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.util.DepJpeConstants;
import com.silverlakesymmetri.cbs.dep.jpa.util.DepStorHelper;
import com.silverlakesymmetri.cbs.dep.svc.DepositsFeeService;
import com.silverlakesymmetri.cbs.dep.svc.mapper.DepositsFeeServiceMapper;
import com.silverlakesymmetri.cbs.dep.xmlapi.DEPFEEDETAILSAPIType;
import com.silverlakesymmetri.cbs.mcl.jpa.mapping.sdo.ClientJpe;

import jersey.repackaged.com.google.common.collect.Lists;

@Service
@Transactional
public class DepositsFeeServiceImpl extends AbstractXmlApiBusinessService<FeeInquiryHdr, FeeInquiryHdrJpe, Long, DEPFEEDETAILSAPIType, DEPFEEDETAILSAPIType> implements DepositsFeeService {
	
	private static final CbsAppLogger logger = CbsAppLoggerFactory.getLogger(DepositsFeeServiceImpl.class);
	
	@Autowired
    private DepStorHelper depStorHelper;
	
	@Autowired
	DepositsFeeServiceMapper mapper;
		
	@Override
	protected EntityPath<FeeInquiryHdrJpe> getEntityPath() {
		return QFeeInquiryHdrJpe.feeInquiryHdrJpe;
	}

	@Override
	protected Long getIdFromDataObjectInstance(FeeInquiryHdr dataObject) {
		return dataObject.getTranNo();
	}

	@Override
	public FeeInquiryHdr feeInquiry(FeeInquiryHdr dataObject) {
		DEPFEEDETAILSAPIType request = transformFeeInquiryHdrToDEPFEEDETAILSAPIType(dataObject, CbsXmlApiOperation.QUERY);
		
		// check inter city
		String isInterCity = isInterCity(dataObject);
		if (StringUtils.isNotBlank(isInterCity)) {
			request.setINPUT8(isInterCity);
		}
		
		DEPFEEDETAILSAPIType response = queryXmlApiRs(request);
		FeeInquiryHdr result = processXmlApiRs(dataObject, response);
		return result;
	}

	private String isInterCity(FeeInquiryHdr dataObject) {
		if (isAllowedTranCode(dataObject.getTranType())) {
			CbsSessionContext sessionCtx = cbsRuntimeContextManager.getContext(CbsSessionContext.class);
			String tranBranch = sessionCtx.getBranch();
			if (StringUtils.isBlank(tranBranch)) {
				tranBranch = getUserBranch(sessionCtx.getUserCode());
				if (logger != null && logger.isWarnEnabled()) {
					logger.warn("Use Default Branch {}.", tranBranch);
				}
			}
			String acctBranch = findAcctBranch(dataObject.getProdNo());
			if (StringUtils.isBlank(acctBranch) || StringUtils.isBlank(tranBranch)) {
				if (logger != null && logger.isWarnEnabled()) {
					logger.warn("Account Branch or Transacting Branch has a blank value. ({}, {})", acctBranch, tranBranch);
				}	
			}
			return depStorHelper.checkInterCity(acctBranch, tranBranch);
		}
		return null;
	}

	private String findAcctBranch(String acctNo) {
		Map<String, Object> param = new HashMap<>();
		param.put("acctNo", acctNo);
		List<AcctJpe> list = dataService.findWithNamedQuery(DepJpeConstants.ACCT_JPE_FIND_ACCT_BY_ACCT_NO, param, AcctJpe.class);
		if (!list.isEmpty()) {
			return list.get(0).getBranch();
		}
		return null;
	}

	private boolean isAllowedTranCode(String tranType) {
		TranDefJpe jpe = dataService.find(TranDefJpe.class, new TranDefPk(tranType));
		return (jpe != null && ("3101".equals(jpe.getTranCode()) || "3102".equals(jpe.getTranCode())));
	}

	@Override
	public List<FeeInquiryHdr> query(int offset, int resultLimit, String groupBy, String order, Map<String, Object> filters) {
		return Lists.newArrayList(feeInquiry(mapToBdo(filters)));
	}

	@Override
	protected DEPFEEDETAILSAPIType transformBdoToXmlApiRqCreate(FeeInquiryHdr dataObject) {
		return null;
	}

	@Override
	protected DEPFEEDETAILSAPIType transformBdoToXmlApiRqUpdate(FeeInquiryHdr dataObject) {
		return null;
	}

	@Override
	protected DEPFEEDETAILSAPIType transformBdoToXmlApiRqDelete(FeeInquiryHdr dataObject) {
		return null;
	}

	@Override
	protected FeeInquiryHdr processXmlApiRs(FeeInquiryHdr dataObject, DEPFEEDETAILSAPIType xmlApiRs) {
		FeeInquiryHdrJpe jpe = jaxbSdoHelper.unwrap(dataObject);
		mapper.mapToJpe(xmlApiRs, jpe);
		dataObject = jaxbSdoHelper.wrap(jpe);
		
		return dataObject;
	}

	@Override
	protected Class<DEPFEEDETAILSAPIType> getXmlApiResponseClass() {
		return DEPFEEDETAILSAPIType.class;
	}
	
	private DEPFEEDETAILSAPIType transformFeeInquiryHdrToDEPFEEDETAILSAPIType(FeeInquiryHdr dataObject, CbsXmlApiOperation oper){
		Map map = new HashMap();
		FeeInquiryHdrJpe jpe = jaxbSdoHelper.unwrap(dataObject);
		Map<String, Object> parameters = new HashMap<String, Object>();
		parameters.put("clientNo", jpe.getClientNo());
		List<ClientJpe> clientList = dataService.findWithNamedQuery("ClientJpe.GET_CLIENT_FROM_REF_NO", parameters, ClientJpe.class);
		if(clientList != null && clientList.size() > 0) {
			jpe.setClientId(clientList.get(0).getClientId());
		}
		if(dataObject.getTranType() != null && dataObject.getCrDrMaint() == null) {
			Map<String, Object> params = new HashMap<String, Object>();
			params.put("tranType", dataObject.getTranType());
			TranDefJpe tranType = dataService.getWithNamedQuery(DepJpeConstants.TRAN_DEF_JPE_BY_TRAN_TYPE, params, TranDefJpe.class);
			if(tranType != null) {
				jpe.setCrDrMaint(tranType.getCrDrMaintInd());
			}
		}
		
		CbsSessionContext sessionCtx = cbsRuntimeContextManager.getContext(CbsSessionContext.class);
		map.put(mapper.BRANCH, sessionCtx.getBranch());
		map.put(mapper.CHANNEL_SOURCE, sessionCtx.getChannelSource());
		
		DEPFEEDETAILSAPIType apiType =  mapper.mapToApi(jpe, oper, map);
		super.setTechColsFromDataObject(dataObject, apiType);
		return apiType;
	}

	@Override
	protected List<FeeInquiryHdr> processXmlApiListRs(FeeInquiryHdr dataObject, DEPFEEDETAILSAPIType xmlApiRs) {
		return null;
	}

	public FeeInquiryHdr mapToBdo(Map<String, Object> map) {
		FeeInquiryHdr bdo = jaxbSdoHelper.createSdoInstance(FeeInquiryHdr.class);
		map.forEach(bdo::set);
		return bdo;
	}

}
