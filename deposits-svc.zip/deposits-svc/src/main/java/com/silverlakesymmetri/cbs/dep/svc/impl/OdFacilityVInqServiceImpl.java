package com.silverlakesymmetri.cbs.dep.svc.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Service;

import com.mysema.query.types.EntityPath;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.svc.AbstractBusinessService;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.OdFacilityVInq;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.OdFeesInq;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.OdFeesTcInq;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.OdOvdInq;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.OdRepayAcctInq;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.OdStatusInq;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.OdTmpLimitInq;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.OdFacilityVInqJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.OdFeesInqJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.OdFeesTcJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.OdOvdJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.OdRepayAcctJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.OdStatusJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.OdTmpLimitInqJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.QOdFacilityVInqJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.id.OdFacilityVInqPk;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.util.DepJpeConstants;
import com.silverlakesymmetri.cbs.dep.svc.OdFacilityVInqService;

@Service
public class OdFacilityVInqServiceImpl extends
		AbstractBusinessService<OdFacilityVInq, OdFacilityVInqJpe, OdFacilityVInqPk> implements OdFacilityVInqService {

	@Override
	protected EntityPath<OdFacilityVInqJpe> getEntityPath() {
		return QOdFacilityVInqJpe.odFacilityVInqJpe;
	}

	@Override
	protected OdFacilityVInqPk getIdFromDataObjectInstance(OdFacilityVInq dataObject) {
		Long internalKey = getInternalKey(dataObject.getAcctNo());
		return new OdFacilityVInqPk(internalKey, dataObject.getSeqNo());
	}

	@Override
	public OdFacilityVInq getByPk(String publicKey, OdFacilityVInq reference) {

		OdFacilityVInq dataObject = super.getByPk(publicKey, reference);

		if (dataObject != null) {

			Long internalKey = getInternalKey(dataObject.getAcctNo());
			Map<String, Object> params = new HashMap<String, Object>();

			params.clear();
			params.put("internalKey", internalKey);
			params.put("agreementNo", dataObject.getAgreementNo());
			params.put("maturityDate", dateTimeHelper.getDate(dataObject.getMaturityDate()));
			List<OdFeesInqJpe> odFeesInqJpeList = dataService.findWithNamedQuery(DepJpeConstants.OD_FEES_LIST_BY_INTERNALKEY_AGREEMENTNO_MATDATE, params, OdFeesInqJpe.class);
			if (odFeesInqJpeList != null && odFeesInqJpeList.size() > 0) {
				List<OdFeesInq> bdoList = new ArrayList<OdFeesInq>();
				for (OdFeesInqJpe odFeesInqJpe : odFeesInqJpeList) {
					bdoList.add(jaxbSdoHelper.wrap(odFeesInqJpe, OdFeesInq.class));
				}
				dataObject.setOdFeesInqList(bdoList);
			}

			params.clear();
			params.put("internalKey", internalKey);
			params.put("odSeqNo", dataObject.getSeqNo());
			List<OdOvdJpe> odOvdJpeList = dataService.findWithNamedQuery(DepJpeConstants.OD_OVD_LIST_BY_INTERNALKEY_ODSEQNO, params, OdOvdJpe.class);
			if (odOvdJpeList != null && odOvdJpeList.size() > 0) {
				List<OdOvdInq> bdoList = new ArrayList<OdOvdInq>();
				for (OdOvdJpe odOvdJpe : odOvdJpeList) {
					bdoList.add(jaxbSdoHelper.wrap(odOvdJpe, OdOvdInq.class));
				}
				dataObject.setOdOvdInqList(bdoList);
			}
			List<OdFeesTcJpe> odFeesTcJpeList = dataService.findWithNamedQuery(DepJpeConstants.OD_FEES_TC_LIST_BY_INTERNALKEY_ODSEQNO, params, OdFeesTcJpe.class);
			if (odFeesTcJpeList != null && odFeesTcJpeList.size() > 0) {
				List<OdFeesTcInq> bdoList = new ArrayList<OdFeesTcInq>();
				for (OdFeesTcJpe odFeesTcJpe : odFeesTcJpeList) {
					bdoList.add(jaxbSdoHelper.wrap(odFeesTcJpe, OdFeesTcInq.class));
				}
				dataObject.setOdFeesTcInqList(bdoList);
			}

			params.clear();
			params.put("internalKey", internalKey);
			List<OdRepayAcctJpe> odRepayAcctJpeList = dataService.findWithNamedQuery(DepJpeConstants.OD_REPAY_ACCT_LIST_BY_INTERNALKEY, params, OdRepayAcctJpe.class);
			if (odRepayAcctJpeList != null && odRepayAcctJpeList.size() > 0) {
				List<OdRepayAcctInq> bdoList = new ArrayList<OdRepayAcctInq>();
				for (OdRepayAcctJpe odRepayAcctJpe : odRepayAcctJpeList) {
					bdoList.add(jaxbSdoHelper.wrap(odRepayAcctJpe, OdRepayAcctInq.class));
				}
				dataObject.setOdRepayAcctInqList(bdoList);
			}

			params.clear();
			params.put("internalKey", internalKey);
			params.put("seqNo", dataObject.getSeqNo());
			List<OdTmpLimitInqJpe> odTmpLimitInqJpeList = dataService.findWithNamedQuery(DepJpeConstants.OD_TMP_LIMIT_INQ_LIST_BY_INTERNALKEY_SEQNO, params, OdTmpLimitInqJpe.class);
			if (odTmpLimitInqJpeList != null && odTmpLimitInqJpeList.size() > 0) {
				List<OdTmpLimitInq> bdoList = new ArrayList<OdTmpLimitInq>();
				for (OdTmpLimitInqJpe odTmpLimitInqJpe : odTmpLimitInqJpeList) {
					bdoList.add(jaxbSdoHelper.wrap(odTmpLimitInqJpe, OdTmpLimitInq.class));
				}
				dataObject.setOdTmpLimitInqList(bdoList);
			}

			List<OdStatusJpe> odStatusJpeList = dataService.findWithNamedQuery(DepJpeConstants.OD_STATUS_LIST_BY_INTERNALKEY_SEQNO, params, OdStatusJpe.class);
			if (odStatusJpeList != null && odStatusJpeList.size() > 0) {
				List<OdStatusInq> bdoList = new ArrayList<OdStatusInq>();
				for (OdStatusJpe odStatusJpe : odStatusJpeList) {
					bdoList.add(jaxbSdoHelper.wrap(odStatusJpe, OdStatusInq.class));
				}
				dataObject.setOdStatusInqList(bdoList);
			}

		}

		return dataObject;

	}

	@Override
	public List<OdFacilityVInq> query(int offset, int resultLimit, String groupBy, String order, Map<String, Object> filters) {
		return super.query(offset, resultLimit, groupBy, order, filters);
	}

	@Override
	public List<OdFacilityVInq> find(FindCriteria findCriteria, CbsHeader cbsHeader) {
		return super.find(findCriteria, cbsHeader);
	}

	private Long getInternalKey(String acctNo) {
		Long internalKey = null;
		if (acctNo != null) {
			Map<String, Object> params = new HashMap<String, Object>();
			params.put("acctNo", acctNo);
			internalKey = dataService.getWithNamedQuery(DepJpeConstants.ACCT_JPE_FIND_INTERNAL_KEY_BY_ACCT_NO, params,
					Long.class);
		}
		return internalKey;
	}

}
