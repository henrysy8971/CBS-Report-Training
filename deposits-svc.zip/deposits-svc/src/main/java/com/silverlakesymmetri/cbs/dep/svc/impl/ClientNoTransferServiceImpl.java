package com.silverlakesymmetri.cbs.dep.svc.impl;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mysema.query.types.EntityPath;
import com.silverlakesymmetri.cbs.commons.svc.AbstractXmlApiBusinessService;
import com.silverlakesymmetri.cbs.commons.xmlapi.enums.CbsXmlApiOperation;
import com.silverlakesymmetri.cbs.core.constants.CoreConstants;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.ClientNoTfrDetail;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.ClientNoTfrHeader;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.AcctJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.ClientNoTfrDetailJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.ClientNoTfrHeaderJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.QClientNoTfrHeaderJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.SiHeaderJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.id.ClientNoTfrHeaderPk;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.id.SiHeaderPk;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.util.DepJpeConstants;
import com.silverlakesymmetri.cbs.dep.svc.ClientNoTransferService;
import com.silverlakesymmetri.cbs.dep.xmlapi.CUTTECHNICALINFOType;
import com.silverlakesymmetri.cbs.dep.xmlapi.DEPCLIENTNOTFRDETAILAPIType;
import com.silverlakesymmetri.cbs.dep.xmlapi.DEPCLIENTNOTFRDETAILCOLLType;
import com.silverlakesymmetri.cbs.dep.xmlapi.DEPCLIENTNOTFRHEADERAPIType;
import com.silverlakesymmetri.cbs.dep.xmlapi.DEPCLIENTNOTFRWRAPPERAPIType;
import com.silverlakesymmetri.cbs.mcl.bdo.sdo.Client;
import com.silverlakesymmetri.cbs.mcl.jpa.mapping.sdo.ClientJpe;
import com.silverlakesymmetri.cbs.mcl.jpa.mapping.sdo.util.MclJpeConstants;
import com.silverlakesymmetri.cbs.commons.svc.util.InMemoryQueryExecutor;
import com.silverlakesymmetri.cbs.commons.jpa.service.impl.BusinessDataObjectJpaQueryComponentImpl;
import com.silverlakesymmetri.cbs.commons.jpa.util.DateTimeHelper;
import com.silverlakesymmetri.cbs.commons.jpa.util.JpaEntityChangeTracker;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.helper.jpa.LinkTable;
import com.silverlakesymmetri.cbs.commons.helper.jpa.QueryCondition;
import com.silverlakesymmetri.cbs.commons.helper.jpa.QueryType;
import com.silverlakesymmetri.cbs.commons.jpa.entity.FindCriteriaJpe;
import com.silverlakesymmetri.cbs.commons.jpa.entity.ViewCriteriaItemJpe;
import com.silverlakesymmetri.cbs.commons.jpa.entity.ViewCriteriaJpe;
import com.silverlakesymmetri.cbs.commons.jpa.entity.ViewCriteriaRowJpe;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.Acct;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.AcctType;

@Service
public class ClientNoTransferServiceImpl extends AbstractXmlApiBusinessService<ClientNoTfrHeader, ClientNoTfrHeaderJpe, ClientNoTfrHeaderPk,  DEPCLIENTNOTFRWRAPPERAPIType, DEPCLIENTNOTFRWRAPPERAPIType>  implements ClientNoTransferService {
    private static LinkedHashMap<String, LinkTable> constructorMap;

    private static QueryCondition condition;

    static {
        constructorMap = new LinkedHashMap<String, LinkTable>();
        constructorMap.put("mainSeqNo", new LinkTable(ClientNoTfrHeaderJpe.class));
        constructorMap.put("effectiveDate", new LinkTable(ClientNoTfrHeaderJpe.class));
        constructorMap.put("fromClientNo", new LinkTable(ClientJpe.class, "clientNo", "FROMCLIENT"));
        constructorMap.put("fromClientId", new LinkTable(ClientNoTfrHeaderJpe.class));
        constructorMap.put("toClientNo", new LinkTable(ClientJpe.class, "clientNo", "TOCLIENT"));
        constructorMap.put("toClientId", new LinkTable(ClientNoTfrHeaderJpe.class));
        constructorMap.put("processDate", new LinkTable(ClientNoTfrHeaderJpe.class));
        constructorMap.put("updSignature", new LinkTable(ClientNoTfrHeaderJpe.class));

        condition = new QueryCondition();
        condition.where( "toClientId", QueryType.EQUALS, new LinkTable(ClientJpe.class, "clientId").alias("TOCLIENT"))
                .and( "fromClientId", QueryType.EQUALS, new LinkTable(ClientJpe.class, "clientId").alias("FROMCLIENT"));
    }
	@Autowired
    private DateTimeHelper dateTimeHelper;
	
	private final static String DEP_CLIENT_NO_TFR_HEADER_SEQ = "DEP_CLIENT_NO_TFR_HEADER_S";
	private final static String BLANK = " ";
	
	@Override
	protected ClientNoTfrHeaderPk getIdFromDataObjectInstance(ClientNoTfrHeader dataObject) {		
		ClientNoTfrHeaderPk jpe = jaxbSdoHelper.unwrap(dataObject);
		return new ClientNoTfrHeaderPk(jpe.getMainSeqNo());
	}

	@Override
	protected EntityPath<ClientNoTfrHeaderJpe> getEntityPath() {		
		return QClientNoTfrHeaderJpe.clientNoTfrHeaderJpe;
	}

	public ClientNoTfrHeader create(ClientNoTfrHeader dataObject){		
		return super.create(dataObject);
	}
	
	@Override
	public List<ClientNoTfrHeader> query(int offset, int resultLimit, String groupBy, String order,
			Map<String, Object> filters) {
		return super.query(offset, resultLimit, groupBy, order, filters);
	}
	
	@Override
	public ClientNoTfrHeader update(ClientNoTfrHeader dataObject) {		
		return super.update(dataObject);
	}
	
	@Override
	public boolean delete(ClientNoTfrHeader dataObject) {
		return super.delete(dataObject);
	}
	
	@Override
	public List<ClientNoTfrHeader> find(FindCriteria findCriteria, CbsHeader cbsHeader) {
		return super.find(findCriteria, cbsHeader, constructorMap, condition);
	}
	
	@Override
	public Long count(FindCriteria findCriteria, CbsHeader cbsHeader) {
        FindCriteriaJpe fcJpe = jaxbSdoHelper.unwrap(findCriteria, FindCriteriaJpe.class);
		return dataService.getRowCount(ClientNoTfrHeaderJpe.class, fcJpe, constructorMap, condition);
	}
	
	@Override
    //public List<Client> queryFromClients(int resultLimit, int offset, String groupBy, String order, Map<String, Object> filters) {
	public List<Client> queryFromClients(Map<String, Object> queryParams) {		
		
        final Map<String, Object> parameters = new HashMap<>();
        List<Client> result = new ArrayList<Client>();
		
		 String clientNo = (String) queryParams.get("clientNo");
	     String clientName = (String) queryParams.get("clientName");		
        int limit = queryParams.get("limit") != null ? Integer.parseInt((String)queryParams.get("limit")) : 10;
        int offset = queryParams.get("offset") != null ? Integer.parseInt((String)queryParams.get("offset")) : 0;        
	
    	//String namedQuery = MclJpeConstants.CLIENT_JPE_FOR_TRANSFER_FROM_LOV;    	    	
    	//jpeList = dataService.findWithNamedQuery(namedQuery, parameters, offset, limit, ClientJpe.class);    	
    	
        String query = "SELECT cli.clientNo, cli.clientName"
			+ " FROM ClientJpe cli"			
			+ " WHERE cli.status = 'A'"
			+ " AND cli.depClientYn=1"
			+ " AND EXISTS (SELECT 1 FROM AcctJpe ac WHERE ac.clientId = cli.clientId AND ac.acctStatus <> 'C')"
			+ " AND NOT EXISTS (SELECT 1 FROM AcctJpe ac1, AcctRestraintJpe res, RegistryJpe reg "
			+ " WHERE ac1.internalKey = res.internalKey "
			+ " AND reg.rowKey = 'clientBlockRestraint' "
			+ " AND reg.metaCode = 'DEPOSITS_REGISTRY' "
			+ " AND res.restraintType = reg.valueS "
			+ " AND ac1.clientId = cli.clientId) ";             

        if(clientNo != null){
            query = query + " AND UPPER(cli.clientNo) like :clientNo";
            parameters.put("clientNo", clientNo);
        }

        if(clientName != null){
            query = query + " AND UPPER(a.clientName) like :clientName";
            parameters.put("clientName", clientName);
        }

        query = query + " ORDER BY cli.clientNo";
        
        List<Client> clients = dataService.findWithQuery(query, parameters, offset, limit, Client.class);
        
        for (Object o : clients) {
            Object[] values = (Object[]) o;
            Client clientBdo = jaxbSdoHelper.createSdoInstance(Client.class);
            clientBdo.setClientNo((String) values[0]);
            clientBdo.setClientName((String) values[1]);
            result.add(clientBdo);
        }
        return result;    
    }
	
	/*@Override
    public List<Acct> queryFromAccounts(int offset, int resultLimit, String groupBy, String order, Map<String, Object> filters, String clientNo) {
        
    	String namedQuery = DepJpeConstants.ACCT_JPE_FOR_CLIENT_TRANSFER_ACCT_LOV;    	
    	if (filters == null)
    		filters =  new HashMap<String, Object> ();
    	Map<String, Object> params =  new HashMap<String, Object> ();
    	params.put("clientNo", clientNo);
    	List<AcctJpe> jpeList = null;
    	
    	jpeList = dataService.findWithNamedQuery(namedQuery, params, resultLimit, AcctJpe.class);
    	    	
		List<Acct> bdoList = new ArrayList<Acct>();
    	if (jpeList != null && jpeList.size() > 0) {
    		for (AcctJpe jpe : jpeList) {
    			Acct sdo = jaxbSdoHelper.wrap(jpe, Acct.class);
    			bdoList.add(sdo);
    		}    		    		
    	} 
    	return bdoList;        
    }*/

	
	@Override
	public ClientNoTfrHeader getByPk(String publicKey, ClientNoTfrHeader reference) {
		return super.getByPk(publicKey, reference);
	}
	
		
	@Override
	protected DEPCLIENTNOTFRWRAPPERAPIType transformBdoToXmlApiRqCreate(ClientNoTfrHeader dataObject) {	
		DEPCLIENTNOTFRWRAPPERAPIType result = transformClientNoTransferToDEPCLIENTNOTRANSFERAPIType(dataObject, CbsXmlApiOperation.INSERT);
		return result;
	}

	@Override
	protected DEPCLIENTNOTFRWRAPPERAPIType transformBdoToXmlApiRqUpdate(ClientNoTfrHeader dataObject) {
		return transformClientNoTransferToDEPCLIENTNOTRANSFERAPIType(dataObject, CbsXmlApiOperation.UPDATE);
	}

	@Override
	protected DEPCLIENTNOTFRWRAPPERAPIType transformBdoToXmlApiRqDelete(ClientNoTfrHeader dataObject) {
		return transformClientNoTransferToDEPCLIENTNOTRANSFERAPIType(dataObject, CbsXmlApiOperation.DELETE);
	}

	@Override
	protected ClientNoTfrHeader processXmlApiRs(ClientNoTfrHeader dataObject, DEPCLIENTNOTFRWRAPPERAPIType xmlApiRs) {		
		return dataObject;
	}

	@Override
	protected List<ClientNoTfrHeader> processXmlApiListRs(ClientNoTfrHeader dataObject, DEPCLIENTNOTFRWRAPPERAPIType xmlApiRs) {		
		return null;
	}

	@Override
	protected Class<DEPCLIENTNOTFRWRAPPERAPIType> getXmlApiResponseClass() {		
		return DEPCLIENTNOTFRWRAPPERAPIType.class;
	}	

	private DEPCLIENTNOTFRWRAPPERAPIType transformClientNoTransferToDEPCLIENTNOTRANSFERAPIType(ClientNoTfrHeader bdo, CbsXmlApiOperation oper) {
		
		ClientNoTfrHeaderJpe jpe = jaxbSdoHelper.unwrap(bdo, ClientNoTfrHeaderJpe.class);
		DEPCLIENTNOTFRWRAPPERAPIType xmlApiObj = new DEPCLIENTNOTFRWRAPPERAPIType();
		DEPCLIENTNOTFRHEADERAPIType headerApi = new DEPCLIENTNOTFRHEADERAPIType();
		
//		super.setTechColsFromDataObject(bdo, xmlApiObj);

		xmlApiObj.setOPERATION(oper.getOperation());
		
		createDEPCLIENTNOTRANSFERAPI(bdo, jpe, xmlApiObj, headerApi);
		//transformClientNoTfrDtlToDEPCLIENTNOTRANSFERTType(jpe.getClientNoTfrDetailList(), oper, xmlApiObj);	
		
		if (CbsXmlApiOperation.INSERT.equals(oper)) {	
			transformClientNoTfrDtlToDEPCLIENTNOTRANSFERTType(jpe.getClientNoTfrDetailList(), oper, xmlApiObj, headerApi);	
		} else if (CbsXmlApiOperation.UPDATE.equals(oper)) {
			JpaEntityChangeTracker ct = dataService.getJpaEntityChangeTracker(jpe);
			List<ClientNoTfrDetailJpe> deletedObj =ct.getDeletedObjects("clientNoTfrDetailList", ClientNoTfrDetailJpe.class); 
			//List<ClientNoTfrDetailJpe> addedObj = ct.getAddedObjects("clientNoTfrDetailList", ClientNoTfrDetailJpe.class);
			List<ClientNoTfrDetailJpe> jpeDetailList = jpe.getClientNoTfrDetailList();
			
			if (xmlApiObj.getDEPCLIENTNOTFRLIST() == null) {
				xmlApiObj.setDEPCLIENTNOTFRLIST(new DEPCLIENTNOTFRDETAILCOLLType());
			}			
			
			
			//detail handle add and update			
			if (jpeDetailList != null && jpeDetailList.size() > 0) {
				for (ClientNoTfrDetailJpe detailJpe : jpeDetailList) {
					JpaEntityChangeTracker detailJpeCt = dataService.getJpaEntityChangeTracker(detailJpe);					
					if (detailJpeCt.isNew()) {
						createDEPCLIENTNOTRANSFERTType(CbsXmlApiOperation.INSERT, xmlApiObj, detailJpe, headerApi);
					}else {
						createDEPCLIENTNOTRANSFERTType(oper, xmlApiObj, detailJpe, headerApi);
					} 
				}
			}
			transformClientNoTfrDtlToDEPCLIENTNOTRANSFERTType(deletedObj, CbsXmlApiOperation.DELETE, xmlApiObj, headerApi);	
			
		}
		return xmlApiObj;
	}
	
	private void createDEPCLIENTNOTRANSFERAPI(ClientNoTfrHeader bdo, ClientNoTfrHeaderJpe jpe, DEPCLIENTNOTFRWRAPPERAPIType xmlApiObj, DEPCLIENTNOTFRHEADERAPIType headerApi)
	{
		setDEPCLIENTNOTRANSFERAPI(bdo, jpe, headerApi, xmlApiObj);
		xmlApiObj.setDEPCLIENTNOTFRREC(headerApi);
	}
	
	private void setDEPCLIENTNOTRANSFERAPI(ClientNoTfrHeader bdo, ClientNoTfrHeaderJpe jpe, DEPCLIENTNOTFRHEADERAPIType xmlApiObj, DEPCLIENTNOTFRWRAPPERAPIType xmlApiObj2) {		
		xmlApiObj.setMAINSEQNO(bdo.getMainSeqNo());
		xmlApiObj.setEFFECTIVEDATE((bdo.getEffectiveDate()!=null)?dateTimeHelper.convertToCbsXmlApiDate(bdo.getEffectiveDate()):null);
		xmlApiObj.setPROCESSDATE((bdo.getProcessDate()!=null)?dateTimeHelper.convertToCbsXmlApiDate(bdo.getProcessDate()):null);
		xmlApiObj.setFROMCLIENTNO(Double.parseDouble(getClientId(bdo.getFromClientNo())));
		xmlApiObj.setTOCLIENTNO(Double.parseDouble(getClientId(bdo.getToClientNo())));
		xmlApiObj.setUPDSIGNATURE(bdo.getUpdSignature());
		xmlApiObj.setOPERATION(xmlApiObj2.getOPERATION());
		
	}

	private void createDEPCLIENTNOTRANSFERTType(CbsXmlApiOperation oper, DEPCLIENTNOTFRWRAPPERAPIType xmlApiObj, ClientNoTfrDetailJpe detailJpe, DEPCLIENTNOTFRHEADERAPIType headerApi) {
		DEPCLIENTNOTFRDETAILAPIType detailApi = new DEPCLIENTNOTFRDETAILAPIType();
		setDEPCLIENTNOTRANSFERTType(detailJpe, detailApi, oper, xmlApiObj, headerApi);
		xmlApiObj.getDEPCLIENTNOTFRLIST().getDEPCLIENTNOTFRDETAILAPI().add(detailApi);
	}
	
	private void setDEPCLIENTNOTRANSFERTType(ClientNoTfrDetailJpe detailJpe, DEPCLIENTNOTFRDETAILAPIType detailApi, CbsXmlApiOperation oper, DEPCLIENTNOTFRWRAPPERAPIType xmlApiObj, DEPCLIENTNOTFRHEADERAPIType headerApi) {
		
		detailApi.setMAINSEQNO(headerApi.getMAINSEQNO());
		detailApi.setSEQNO(detailJpe.getSeqNo());
		detailApi.setACCTNO(detailJpe.getAcctNo());
		detailApi.setUPDACCTDESC(detailJpe.getUpdAcctDesc());
		detailApi.setCRRATING(detailJpe.getCrRating());
		detailApi.setAUTOGENFEE(detailJpe.getAutoGenFee());
		detailApi.setOPERATION(oper.getOperation());		
	}

	private void transformClientNoTfrDtlToDEPCLIENTNOTRANSFERTType(List<ClientNoTfrDetailJpe> jpeList, CbsXmlApiOperation oper, DEPCLIENTNOTFRWRAPPERAPIType xmlApiObj, DEPCLIENTNOTFRHEADERAPIType headerApi) {
		if (xmlApiObj.getDEPCLIENTNOTFRLIST() == null) {
			xmlApiObj.setDEPCLIENTNOTFRLIST(new DEPCLIENTNOTFRDETAILCOLLType());
		}		
		if (jpeList != null && jpeList.size() > 0) {
			for (ClientNoTfrDetailJpe detailJpe : jpeList) {
				createDEPCLIENTNOTRANSFERTType(oper, xmlApiObj, detailJpe, headerApi);
			}
		}
	}
	
	private String getClientId(String clientNo) {		
		Map<String, Object> params = new HashMap<String, Object>();
        params.put("clientNo", clientNo);
        Long clientId = dataService.getWithNamedQuery(MclJpeConstants.CLIENT_JPE_FIND_CLIENT_ID_USING_CLIENT_NO, params, Long.class);       
        
        return String.valueOf(clientId);
	}

	private String getClientNo(String clientId) {				
        Map<String, Object> params = new HashMap<String, Object>();
        params.put("clientId", Long.valueOf(clientId));
        String result = dataService.getWithNamedQuery(MclJpeConstants.CLIENT_JPE_FIND_CLIENT_NO_USING_CLIENT_ID, params, String.class);
        return result;
	}
	
	@Override
    protected ClientNoTfrHeader preCreateValidation(ClientNoTfrHeader dataObject) {		
        long mainSeqNo = dataService.nextSequenceValue(DEP_CLIENT_NO_TFR_HEADER_SEQ).longValue();
        
        for(ClientNoTfrDetail detail: dataObject.getClientNoTfrDetailList()){
        	long seqNo = dataService.nextSequenceValue(DEP_CLIENT_NO_TFR_HEADER_SEQ).longValue();
        	detail.setMainSeqNo(mainSeqNo);
        	detail.setSeqNo(seqNo); 
        	if (detail.getStatus()==null) detail.setStatus(BLANK); 
        }
        dataObject.setMainSeqNo(mainSeqNo);
        return super.preCreateValidation(dataObject);
    }	
	
	
	@Override
    protected ClientNoTfrHeader preUpdateValidation(ClientNoTfrHeader dataObject) {		        
        for(ClientNoTfrDetail detail: dataObject.getClientNoTfrDetailList()){
        	long seqNo = dataService.nextSequenceValue(DEP_CLIENT_NO_TFR_HEADER_SEQ).longValue();
        	detail.setMainSeqNo(dataObject.getMainSeqNo());
        	if (detail.getSeqNo()==null) detail.setSeqNo(seqNo); 
        	if (detail.getStatus()==null) detail.setStatus(BLANK);
        }
        return super.preUpdateValidation(dataObject);
    }	
	

}
