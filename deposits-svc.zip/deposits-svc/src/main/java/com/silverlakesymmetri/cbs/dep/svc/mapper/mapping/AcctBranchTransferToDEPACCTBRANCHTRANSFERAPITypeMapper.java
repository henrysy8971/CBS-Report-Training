package com.silverlakesymmetri.cbs.dep.svc.mapper.mapping;

import org.mapstruct.MapperConfig;
import org.mapstruct.Mapping;
import org.mapstruct.Mappings;

import com.silverlakesymmetri.cbs.commons.jpa.util.DateTimeHelper;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.AcctBranchTransferJpe;
import com.silverlakesymmetri.cbs.dep.xmlapi.DEPACCTBRANCHTRANSFERAPIType;

@MapperConfig(uses={ DateTimeHelper.class})
public interface AcctBranchTransferToDEPACCTBRANCHTRANSFERAPITypeMapper {
	

	@Mappings({
		@Mapping(target ="SEQNO", source="seqNo"),
		@Mapping(target ="ACCTNO", source="acctNo"),
		@Mapping(target ="NEWBRANCH", source="trfToBranch"), 
		@Mapping(target ="AUTOGENFEE", constant="N"), 
		@Mapping(target ="EFFECTDATE", source="trfDate", qualifiedByName = {"DateTimeHelper","convertDateToCbsXmlApiDate"}),
		@Mapping(target ="GLNARRATIVE", source="glNarrative")
	 })
	public DEPACCTBRANCHTRANSFERAPIType mapAcctBranchTransferToDEPACCTBRANCHTRANSFERAPIType(AcctBranchTransferJpe  jpe);
	
}