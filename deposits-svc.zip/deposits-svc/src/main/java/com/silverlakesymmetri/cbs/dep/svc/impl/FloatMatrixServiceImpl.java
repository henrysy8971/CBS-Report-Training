package com.silverlakesymmetri.cbs.dep.svc.impl;

import java.util.Arrays;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.mysema.query.types.EntityPath;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.logging.CbsAppLogger;
import com.silverlakesymmetri.cbs.commons.logging.annotation.Logger;
import com.silverlakesymmetri.cbs.commons.svc.AbstractBusinessService;
import com.silverlakesymmetri.cbs.commons.svc.CbsFileUploadCapable;
import com.silverlakesymmetri.cbs.commons.svc.util.FileUploadUtilImpl;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.FloatMatrix;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.FloatMatrixJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.QFloatMatrixJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.id.FloatMatrixPk;
import com.silverlakesymmetri.cbs.dep.svc.FloatMatrixService;

@Service
@Transactional
public class FloatMatrixServiceImpl extends AbstractBusinessService<FloatMatrix, FloatMatrixJpe, FloatMatrixPk>
		implements FloatMatrixService, CbsFileUploadCapable<FloatMatrix> {

	@Logger
	CbsAppLogger logger;

	@SuppressWarnings("rawtypes")
	@Autowired
	private FileUploadUtilImpl fileUploadUtility;

	@Override
	protected FloatMatrixPk getIdFromDataObjectInstance(FloatMatrix dataObject) {
		return new FloatMatrixPk(dataObject.getAcquirerBranch(), dataObject.getIssuerBank(),
				dataObject.getIssuerBranch());
	}

	@Override
	protected EntityPath<FloatMatrixJpe> getEntityPath() {
		return QFloatMatrixJpe.floatMatrixJpe;
	}

	@Override
	public FloatMatrix get(FloatMatrix objectInstanceIdentifier) {
		return super.get(objectInstanceIdentifier);
	}

	@Override
	public FloatMatrix create(FloatMatrix dataObject) {
		return super.create(dataObject);
	}

	@Override
	public boolean delete(FloatMatrix dataObject) {
		return super.delete(dataObject);
	}

	@Override
	public FloatMatrix update(FloatMatrix dataObject) {
		return super.update(dataObject);
	}

	@Override
	public List<FloatMatrix> find(FindCriteria findCriteria, CbsHeader cbsHeader) {
		return super.find(findCriteria, cbsHeader);
	}

	@Override
	public FloatMatrix getByPk(String publicKey, FloatMatrix reference) {
		return super.getByPk(publicKey, reference);
	}

	@Override
	public List<FloatMatrix> query(int offset, int resultLimit, String groupBy, String order,
			Map<String, Object> filters) {
		return super.query(offset, resultLimit, groupBy, order, filters);
	}

	@Override
	public FloatMatrix preCreateValidation(FloatMatrix floatMatrix) {
		if (floatMatrix != null) {
			if (floatMatrix.getUsedYn() == null) {
				floatMatrix.setUsedYn(false);
			}
			if (floatMatrix.getActiveYn() == null) {
				floatMatrix.setActiveYn(false);
			}
		}
		return super.preCreateValidation(floatMatrix);
	}

	@Override
	public boolean bulkCreate(List<FloatMatrix> bdoList) {
		validateBulkCreateList(bdoList);

		for (FloatMatrix bdo : bdoList) {
			try {
				this.create(bdo);
			} catch (Exception e) {
				logger.error("Error encountered while processing jpe: {}", jaxbSdoHelper.unwrap(bdo), e);
				throw e;
			}
		}

		return true;
	}

	private void validateBulkCreateList(List<FloatMatrix> bdoList) {
		isDuplicatesOnList(Arrays.asList("acquirerBranch", "issuerBank", "issuerBranch"), bdoList);
	}

	@SuppressWarnings("unchecked")
	@Override
	public boolean isDuplicatesOnList(List<String> uniqueKeys, List<FloatMatrix> bdoList) {
		return fileUploadUtility.isDuplicatesOnList(uniqueKeys, bdoList);
	}

}
