package com.silverlakesymmetri.cbs.dep.svc.mapper.decorator;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

import com.silverlakesymmetri.cbs.commons.xmlapi.enums.CbsXmlApiOperation;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.CiSettlementJpe;
import com.silverlakesymmetri.cbs.dep.svc.mapper.CiSettlementSellServiceMapper;
import com.silverlakesymmetri.cbs.dep.xmlapi.DEPCIPROCESSSETTLESELLAPIType;
                                                                    
public abstract class CiSettlementSellServiceDecorator implements CiSettlementSellServiceMapper{
		
	@Autowired
	@Qualifier("delegate")
	protected  CiSettlementSellServiceMapper delegate;
		
	@Override
	public DEPCIPROCESSSETTLESELLAPIType mapToApi(CiSettlementJpe jpe, CbsXmlApiOperation oper, Map otherInfo){
		
		DEPCIPROCESSSETTLESELLAPIType req = (DEPCIPROCESSSETTLESELLAPIType)delegate.mapToApi(jpe, oper, otherInfo);
		
		return  req;
	}
	
	@Override
	public CiSettlementJpe mapToJpe(DEPCIPROCESSSETTLESELLAPIType api, CiSettlementJpe jpe){
		
		if (jpe == null){
			jpe = new CiSettlementJpe();
		}
		
		if (api == null){
			return jpe;
		}
		
		delegate.mapToJpe(api, jpe);
			
		return jpe;
	}
	

}


