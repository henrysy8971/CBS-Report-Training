package com.silverlakesymmetri.cbs.dep.svc.mapper;

import com.silverlakesymmetri.cbs.commons.jpa.util.DateTimeHelper;
import com.silverlakesymmetri.cbs.commons.xmlapi.enums.CbsXmlApiOperation;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.AcctInterestProjectionJpe;
import com.silverlakesymmetri.cbs.dep.svc.mapper.mapping.AcctInterestProjectionToDEPINTPROJECTIONAPITypeMapper;
import com.silverlakesymmetri.cbs.dep.xmlapi.DEPINTPROJECTIONAPIType;
import org.mapstruct.*;

@Mapper(config= AcctInterestProjectionToDEPINTPROJECTIONAPITypeMapper.class, uses = DateTimeHelper.class)
public interface AcctInterestProjectionServiceMapper {

    @Mappings({
            @Mapping(expression = "java(oper != null ? oper.getOperation() : null)", target="OPERATION")
    })
    @InheritConfiguration
    DEPINTPROJECTIONAPIType mapToApi(AcctInterestProjectionJpe jpe, CbsXmlApiOperation oper);

    @InheritInverseConfiguration(name = "mapAcctInterestProjectionToDEPINTPROJECTIONAPITypeMapper")
    @Mappings({
            @Mapping(target = "intEndDate", source="INTENDDATE", qualifiedByName = {"DateTimeHelper","convertCbsApiDateToString"})
    })
    AcctInterestProjectionJpe mapToJpe(DEPINTPROJECTIONAPIType api);
}
