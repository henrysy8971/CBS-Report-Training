package com.silverlakesymmetri.cbs.dep.svc.mapper;

import com.silverlakesymmetri.cbs.commons.xmlapi.enums.CbsXmlApiOperation;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.Acct;
import com.silverlakesymmetri.cbs.dep.xmlapi.DEPACCTWRAPPERAPIType;


public interface AcctCasaServiceMapper{
	

	public DEPACCTWRAPPERAPIType mapToApi(Acct bdo, CbsXmlApiOperation oper);
	
	public Acct mapToJpe(DEPACCTWRAPPERAPIType api, Acct bdo);
}
