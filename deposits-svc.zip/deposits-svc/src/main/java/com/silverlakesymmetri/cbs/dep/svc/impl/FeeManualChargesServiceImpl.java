package com.silverlakesymmetri.cbs.dep.svc.impl;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mysema.query.types.EntityPath;
import com.silverlakesymmetri.cbs.commons.exception.base.CbsRuntimeException;
import com.silverlakesymmetri.cbs.commons.jpa.entity.CbsBpmInfoJpe;
import com.silverlakesymmetri.cbs.commons.logging.CbsAppLogger;
import com.silverlakesymmetri.cbs.commons.logging.CbsAppLoggerFactory;
import com.silverlakesymmetri.cbs.commons.svc.AbstractXmlApiBusinessService;
import com.silverlakesymmetri.cbs.commons.svc.BusinessObjectValidationCapable;
import com.silverlakesymmetri.cbs.commons.svc.LimitsCheckingCapable;
import com.silverlakesymmetri.cbs.commons.xmlapi.enums.CbsXmlApiOperation;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.FeeManualCharges;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.AcctJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.FeeManualChargesJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.QFeeManualChargesJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.id.FeeManualChargesPk;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.util.DepJpeConstants;
import com.silverlakesymmetri.cbs.dep.svc.DepositsExpEmkService;
import com.silverlakesymmetri.cbs.dep.svc.FeeManualChargesService;
import com.silverlakesymmetri.cbs.dep.svc.mapper.FeeManualChargesServiceMapper;
import com.silverlakesymmetri.cbs.dep.xmlapi.DEPMANUALCHARGESAPIType;
import com.silverlakesymmetri.cbs.lmt.util.ExpEmkObjectHolder;
import com.silverlakesymmetri.cbs.lmt.util.LimitsUtility;

@Service
public class FeeManualChargesServiceImpl extends
		AbstractXmlApiBusinessService<FeeManualCharges, FeeManualChargesJpe, FeeManualChargesPk, DEPMANUALCHARGESAPIType,
                DEPMANUALCHARGESAPIType> implements FeeManualChargesService,
        BusinessObjectValidationCapable<FeeManualCharges>, LimitsCheckingCapable<FeeManualCharges> {

	@Autowired
	FeeManualChargesServiceMapper mapper;

	@Autowired
	private DepositsExpEmkService depositsExpEmkService;

    @Autowired
    private LimitsUtility limitsUtility;
    
    private static CbsAppLogger logger = CbsAppLoggerFactory.getLogger(FeeManualChargesServiceImpl.class.getName());

	@Override
	protected Class<DEPMANUALCHARGESAPIType> getXmlApiResponseClass() {
		return DEPMANUALCHARGESAPIType.class;
	}

	@Override
	protected List<FeeManualCharges> processXmlApiListRs(FeeManualCharges dataObject,
			DEPMANUALCHARGESAPIType xmlApiRs) {
		return null;
	}

	@Override
	protected FeeManualCharges processXmlApiRs(FeeManualCharges dataObject, DEPMANUALCHARGESAPIType xmlApiRs) {
		FeeManualChargesJpe jpe = jaxbSdoHelper.unwrap(dataObject);
		return jaxbSdoHelper.wrap(mapper.mapToJpe(xmlApiRs, jpe));
	}

	@Override
	protected DEPMANUALCHARGESAPIType transformBdoToXmlApiRqCreate(FeeManualCharges dataObject) {
		return transformFeeManualChargesToDEPMANUALCHARGESAPIType(dataObject, CbsXmlApiOperation.INSERT);
	}

	@Override
	protected DEPMANUALCHARGESAPIType transformBdoToXmlApiRqDelete(FeeManualCharges dataObject) {
		return null;
	}

	@Override
	protected DEPMANUALCHARGESAPIType transformBdoToXmlApiRqUpdate(FeeManualCharges dataObject) {
		return null;
	}

	@Override
	protected EntityPath<FeeManualChargesJpe> getEntityPath() {
		return QFeeManualChargesJpe.feeManualChargesJpe;
	}

	@Override
	protected FeeManualChargesPk getIdFromDataObjectInstance(FeeManualCharges dataObject) {
		FeeManualChargesPk jpe = jaxbSdoHelper.unwrap(dataObject);
		return new FeeManualChargesPk(jpe.getScManualSeqNo());
	}

	@Override
	public FeeManualCharges create(FeeManualCharges dataObject) {
        dataObject = super.create(dataObject);
        return dataObject;
    }

	@Override
	protected FeeManualCharges preCreateValidation(FeeManualCharges dataObject) {
		FeeManualChargesJpe jpe = jaxbSdoHelper.unwrap(dataObject, FeeManualChargesJpe.class);
		if (jpe.getScManualSeqNo() == null || jpe.getScManualSeqNo() == 0) {
			long seqNo = dataService.nextSequenceValue("CSD_SC_MANUAL_S").longValue();
			jpe.setScManualSeqNo(seqNo);
			return super.preCreateValidation(jaxbSdoHelper.wrap(jpe, FeeManualCharges.class));
		}
		return super.preCreateValidation(dataObject);
	}

	@SuppressWarnings("rawtypes")
	private DEPMANUALCHARGESAPIType transformFeeManualChargesToDEPMANUALCHARGESAPIType(FeeManualCharges dataObject,
			CbsXmlApiOperation oper) {
		Map map = new HashMap();
		FeeManualChargesJpe jpe = jaxbSdoHelper.unwrap(dataObject);
		DEPMANUALCHARGESAPIType api = mapper.mapToApi(jpe, oper, map);
		super.setTechColsFromDataObject(dataObject, api);
		return api;
	}

	@Override
	public FeeManualCharges calcScAmt(FeeManualCharges dataObject) {

		DEPMANUALCHARGESAPIType xmlApiRq = new DEPMANUALCHARGESAPIType();
		xmlApiRq.setOPERATION(CbsXmlApiOperation.QUERY.getOperation());
		xmlApiRq.setMODULEID(dataObject.getModuleID());
		xmlApiRq.setACCTNO(dataObject.getAcctNo());
		xmlApiRq.setBRANCH(dataObject.getBranch());
		xmlApiRq.setSCTYPE(dataObject.getScType());
		xmlApiRq.setSCRATETYPE(dataObject.getScRateType());
		xmlApiRq.setCALCBALTYPE(dataObject.getCalcBalType());
		xmlApiRq.setCALCBALCCY(dataObject.getCalcBalCcy());
		xmlApiRq.setCALCBAL(dataObject.getCalcBal());
		xmlApiRq.setSCCCY(dataObject.getScCcy());
		xmlApiRq.setCROSSRATE(dataObject.getCrossRate());
		xmlApiRq.setPURPOSE(dataObject.getPurpose());

		if (StringUtils.isNotBlank(dataObject.getPurpose())) {
			if (!dataObject.getPurpose().equals("QS")) {
				xmlApiRq.setSCAMTUPDATED(new Double(0));
				xmlApiRq.setSCAMT(dataObject.getScAmt());
			}
		}

		super.setTechColumns(xmlApiRq);
		DEPMANUALCHARGESAPIType xmlApiRs = super.queryXmlApiRs(xmlApiRq);
		FeeManualChargesJpe jpe = new FeeManualChargesJpe();
		return jaxbSdoHelper.wrap(mapper.mapToJpe(xmlApiRs, jpe));

	}

    @Override
    public CbsBpmInfoJpe doCheckLimit(FeeManualCharges dataObject) {
        if (dataObject.getAcctNo() != null) {
            ExpEmkObjectHolder expEmkObject = getExpEmkObjectHolder(dataObject);
            return limitsUtility.getLimitExceptionApprover(expEmkObject, dataObject);
        }
        return null;
    }

    @Override
    public FeeManualCharges getLimitExceptions(FeeManualCharges dataObject) {
        if (dataObject.getAcctNo() != null) {
            ExpEmkObjectHolder expEmkObject = getExpEmkObjectHolder(dataObject);
            return limitsUtility.getLimitExceptionDetails(expEmkObject, dataObject);
        }
        return null;
    }

    private ExpEmkObjectHolder getExpEmkObjectHolder(FeeManualCharges dataObject){
        AcctJpe acctJpe = null;
        Map<String, Object> param = new HashMap<String, Object>();
        param.put("acctNo", dataObject.getAcctNo());
        List<AcctJpe> acctJpeList = dataService.findWithNamedQuery(DepJpeConstants.ACCT_JPE_FIND_BY_ACCTNO, param,
                AcctJpe.class);
        acctJpe = acctJpeList.get(0);
        ExpEmkObjectHolder expEmkObject = depositsExpEmkService.getLimitsDetails(dataObject, acctJpe,
                DepositsExpEmkServiceImpl.WHD_EVENT_TYPE, DepositsExpEmkServiceImpl.DR_AMT_TYPE);
        return expEmkObject;
    }

	@Override
	public Long getEffectivityDate(FeeManualCharges dataObject) {
		if (dataObject != null) {
			if (!StringUtils.isBlank(dataObject.getEffectDate())) {
				Date date = dateTimeHelper.getDate(dataObject.getEffectDate());
				if (date != null) {
					return dateTimeHelper.removeTime(date).getTime();
				}
			}
		}
		return null;
	}

    @Override
    public void validateApiRequest(FeeManualCharges dataObject, DEPMANUALCHARGESAPIType xmlApiRq){
        try {
            String xmlApiReq = removeModifiedByAndModifiedDt(convertXmlApiRqToString(xmlApiRq));
            String xmlHeaderIn = convertXmlApiRqToString(createHeaderFromDataObject(dataObject));
            validate(dataObject, xmlApiReq, xmlHeaderIn);
        } catch (CbsRuntimeException cre) {
            throw cre;
        } catch (Exception e) {
            logger.error("Unhandled error encountered: {}", e.getMessage(), e);
            throw new RuntimeException(e);
        }
    }
}
