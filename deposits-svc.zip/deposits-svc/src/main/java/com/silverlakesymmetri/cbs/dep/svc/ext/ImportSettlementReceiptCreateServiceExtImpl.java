package com.silverlakesymmetri.cbs.dep.svc.ext;

import org.springframework.stereotype.Service;

import com.silverlakesymmetri.cbs.commons.logging.CbsAppLogger;
import com.silverlakesymmetri.cbs.commons.logging.CbsAppLoggerFactory;
import com.silverlakesymmetri.cbs.xps.svc.util.ReleaseAcctRestraintCapable;

@Service
public class ImportSettlementReceiptCreateServiceExtImpl extends AbstractTfnAcctRestraintServiceExtImpl implements ReleaseAcctRestraintCapable {

	private static CbsAppLogger logger = CbsAppLoggerFactory.getLogger(ImportSettlementReceiptCreateServiceExtImpl.class.getName());
	
	@Override
	public String[] getExtendedBdoNames() {
		return new String[] { "ImportSettlementReceipt" };
	}

	@Override
	public String[] getExtendedServiceNames() {
		return new String[] {"ImportSettlementReceiptService.create"};
	}

	@Override
	protected CbsAppLogger getLogger() {
		return logger;
	}

}
