package com.silverlakesymmetri.cbs.dep.svc;

import java.util.List;
import java.util.Map;

import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation;
import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation.ServiceOperationType;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.svc.BusinessService;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.CiRdReg;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.CiRdRegJpe;

public interface ChequeRegistrationService extends BusinessService<CiRdReg, CiRdRegJpe> {
	
	public static final String SVC_OP_NAME_CHEQUEREGISTRATIONSERVICE_GET 	= "ChequeRegistrationService.get";
    public static final String SVC_OP_NAME_CHEQUEREGISTRATIONSERVICE_QUERY 	= "ChequeRegistrationService.query";
    public static final String SVC_OP_NAME_CHEQUEREGISTRATIONSERVICE_CREATE = "ChequeRegistrationService.create";
    public static final String SVC_OP_NAME_CHEQUEREGISTRATIONSERVICE_UPDATE = "ChequeRegistrationService.update";
    public static final String SVC_OP_NAME_CHEQUEREGISTRATIONSERVICE_DELETE = "ChequeRegistrationService.delete";
    public static final String SVC_OP_NAME_CHEQUEREGISTRATIONSERVICE_FIND 	= "ChequeRegistrationService.find";
    
    @ServiceOperation(name = SVC_OP_NAME_CHEQUEREGISTRATIONSERVICE_GET, type = ServiceOperationType.GET)
    public CiRdReg getByPk(String publicKey, CiRdReg reference);
    
    @ServiceOperation(name = SVC_OP_NAME_CHEQUEREGISTRATIONSERVICE_CREATE)
    public CiRdReg create(CiRdReg siHeader);
    
    @ServiceOperation(name = SVC_OP_NAME_CHEQUEREGISTRATIONSERVICE_UPDATE)
    public CiRdReg update(CiRdReg objectInstanceIdentifier);
    
    @ServiceOperation(name = SVC_OP_NAME_CHEQUEREGISTRATIONSERVICE_DELETE)
    public boolean delete(CiRdReg objectInstanceIdentifier);
    
    @ServiceOperation(name = SVC_OP_NAME_CHEQUEREGISTRATIONSERVICE_QUERY)
    public List<CiRdReg> query(int offset, int resultLimit, String groupBy, String order, Map<String, Object> filters);

    @ServiceOperation(name = SVC_OP_NAME_CHEQUEREGISTRATIONSERVICE_FIND)
    public List<CiRdReg> find(FindCriteria findCriteria, CbsHeader cbsHeader);
	
	
}
