package com.silverlakesymmetri.cbs.dep.svc.impl;

import com.mysema.query.types.EntityPath;
import com.silverlakesymmetri.cbs.commons.jpa.util.JaxbDatetimeAdapter;
import com.silverlakesymmetri.cbs.commons.svc.AbstractXmlApiBusinessService;
import com.silverlakesymmetri.cbs.commons.svc.BusinessObjectValidationCapable;
import com.silverlakesymmetri.cbs.commons.xmlapi.enums.CbsXmlApiOperation;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.ReversalTran;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.QReversalTranJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.ReversalTranJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.id.ReversalTranPk;
import com.silverlakesymmetri.cbs.dep.svc.ReversalValidationService;
import com.silverlakesymmetri.cbs.dep.xmlapi.DEPTRANREVERSALAPIType;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.xml.bind.JAXBException;
import org.springframework.stereotype.Service;

/**
 *
 * @author luis.talag
 */
@Service
public class ReversalValidationServiceImpl extends AbstractXmlApiBusinessService<ReversalTran, ReversalTranJpe, ReversalTranPk, DEPTRANREVERSALAPIType, DEPTRANREVERSALAPIType> implements ReversalValidationService {

    @Override
    public ReversalTran create(ReversalTran dataObject) {
        if (dataObject.getSeqNo() != null && dataObject.getTranDate() != null) {
            transformBdoToXmlApiRqCreate(dataObject);
        }
        return dataObject;
    }

    @Override
    protected DEPTRANREVERSALAPIType transformBdoToXmlApiRqCreate(ReversalTran dataObject) {
        return transformReversalTranRevToDEPTRANREVERSALAPIType(dataObject, CbsXmlApiOperation.VALIDATE_INSERT);
    }

    private DEPTRANREVERSALAPIType transformReversalTranRevToDEPTRANREVERSALAPIType(ReversalTran dataObject, CbsXmlApiOperation oper) {
        DEPTRANREVERSALAPIType apiType = new DEPTRANREVERSALAPIType();
        super.setTechColsFromDataObject(dataObject, apiType);
        apiType.setOPERATION(oper.getOperation());
        apiType.setTRANSEQNO(new Double(dataObject.getSeqNo()).doubleValue());
        apiType.setTRANDATE(dateTimeHelper.convertToCbsXmlApiDate(dataObject.getTranDate()));
        try {
            validate(dataObject, convertXmlApiRqToString(apiType), convertXmlApiRqToString(createHeader()));
        } catch (JAXBException ex) {
            Logger.getLogger(ReversalValidationServiceImpl.class.getName()).log(Level.SEVERE, null, ex);
        }
        return apiType;
    }

    @Override
    protected DEPTRANREVERSALAPIType transformBdoToXmlApiRqUpdate(ReversalTran dataObject) {
        return null;
    }

    @Override
    protected DEPTRANREVERSALAPIType transformBdoToXmlApiRqDelete(ReversalTran dataObject) {
        return null;
    }

    @Override
    protected ReversalTran processXmlApiRs(ReversalTran dataObject, DEPTRANREVERSALAPIType xmlApiRs) {
        return null;
    }

    @Override
    protected List<ReversalTran> processXmlApiListRs(ReversalTran dataObject, DEPTRANREVERSALAPIType xmlApiRs) {
        return null;
    }

    @Override
    protected Class<DEPTRANREVERSALAPIType> getXmlApiResponseClass() {
        return null;
    }

    @Override
    protected ReversalTranPk getIdFromDataObjectInstance(ReversalTran dataObject) {
        return new ReversalTranPk(dataObject.getSeqNo(), JaxbDatetimeAdapter.parseDate(dataObject.getTranDate()));
    }

    @Override
    protected EntityPath<ReversalTranJpe> getEntityPath() {
        return QReversalTranJpe.reversalTranJpe;
    }

}
