package com.silverlakesymmetri.cbs.dep.svc;

import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation;
import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation.ServiceOperationType;
import com.silverlakesymmetri.cbs.commons.svc.BusinessService;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.AtmTran;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.AtmTranJpe;

public interface AtmTranService extends BusinessService<AtmTran, AtmTranJpe> {

	public static final String SVC_OP_NAME_ATMTRANSERVICE_GET = "AtmTranService.get";
	public static final String SVC_OP_NAME_ATMTRANSERVICE_CREATE = "AtmTranService.create";
	
	@ServiceOperation(name = SVC_OP_NAME_ATMTRANSERVICE_GET, type = ServiceOperationType.GET)
    public AtmTran getByPk(String publicKey, AtmTran reference);
	
	@ServiceOperation(name = SVC_OP_NAME_ATMTRANSERVICE_CREATE)
    public AtmTran create(AtmTran dataObject);	
}
