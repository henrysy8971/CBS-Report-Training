package com.silverlakesymmetri.cbs.dep.svc.ext;

import com.silverlakesymmetri.cbs.commons.bdo.CbsBpmInfo;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.CbsServiceMessage;
import com.silverlakesymmetri.cbs.commons.bdo.sdo.CbsServiceDataObjectBase;
import com.silverlakesymmetri.cbs.commons.bpm.constants.BpmConstants;
import com.silverlakesymmetri.cbs.commons.bpm.svc.BpmService;
import com.silverlakesymmetri.cbs.commons.context.CbsRuntimeContextManager;
import com.silverlakesymmetri.cbs.commons.context.CbsSessionContext;
import com.silverlakesymmetri.cbs.commons.ext.impl.AbstractServiceExtPointImpl;
import com.silverlakesymmetri.cbs.commons.jpa.extension.JaxbSdoHelper;
import com.silverlakesymmetri.cbs.commons.jpa.entity.CbsBpmInfoJpe;
import com.silverlakesymmetri.cbs.commons.jpa.entity.CbsServiceMessageJpe;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.*;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Created by Emerson.Sanchez on 4/11/2022.
 */
@Service
public class DepValidationOverrideServiceExtImpl extends AbstractServiceExtPointImpl {
    private static final String YES = "Y";
    private static final String NO = "N";
    private static final String CBS_UI = "HTTP-UI";
    private static final String CBS = "CBS";
    private static List RESTRAINT_ERROR_CODES = Collections.unmodifiableList(Arrays.asList(
            "CBS.B.DEP.301431", "CBS.B.DEP.301901", "CBS.B.DEP.301432", "CBS.B.DEP.301902", "CBS.B.DEP.301433",
            "CBS.B.DEP.301903", "CBS.B.DEP.301904", "CBS.B.DEP.301435", "CBS.B.DEP.301906",
            "CBS.B.DEP.301191", "CBS.B.DEP.301195"));
    private static final String DEPOSIT_TRANSACTION = "DepositTransaction";
    private static final String CHEQUE_SELL = "ChqSell";
    private static final String CHEQUE_BUY = "ChqBuy";
    private static final String TDA_HIST = "TdaHist";
    private static final String TD_TRANSFER_TXN = "TdTransferTransaction";
    private static final String TD_DEPOSIT_TXN = "TdDepositTransaction";
    private static final String BILL_TRAN_HIST = "BillTranHist";
    private static final String FEE_MANUAL_CHARGES = "FeeManualCharges";
    private static final String TRANSFER_TRANSACTION = "TransferTransaction";
    private static final String CHEQUEBOOKREQ_TRANSACTION = "ChequeCtrl";
    private static final String CASH_DEPOSIT_SERVICE = "CashDepositService.postTransaction";
    private static final String CASH_WITHDRAWAL_SERVICE = "CashWithdrawalService.postTransaction";
    private static final String CHEQUE_DEPOSIT_SERVICE = "ChequeDepositService.postTransaction";
    private static final String CHEQUE_WITHDRAWAL_SERVICE = "ChequeWithdrawalService.postTransaction";
    private static final String MISC_DEPOSIT_SERVICE = "MiscDepositService.postTransaction";
    private static final String MISC_WITHDRAWAL_SERVICE = "MiscWithdrawalService.postTransaction";
    private static final String CHEQUE_SELL_SERVICE = "ChequeSellService.create";
    private static final String CHEQUE_BUY_SERVICE = "ChequeBuyService.create";
    private static final String TDA_HIST_SERVICE = "TdaHistService.create";
    private static final String TD_TRANSFER_TXN_SERVICE = "TdTransferTransactionService.create";
    private static final String TD_DEPOSIT_TXN_SERVICE = "TdDepositTransactionService.create";
    private static final String BILL_TRAN_HIST_SERVICE = "BillTranHistService.create";
    private static final String FEE_MANUAL_CHARGES_SERVICE = "FeeManualChargesService.create";
    private static final String TRANSFER_TRANSACTION_SERVICE = "TransferTransactionService.create";
    private static final String CHEQUEBOOK_REQ_SERVICE = "ChequeCtrlService.create";

    @Autowired
    private CbsRuntimeContextManager cbsRuntimeContextManager;

    @Autowired
    private BpmService bpmService;

    @Autowired
    protected JaxbSdoHelper jaxbSdoHelper;

    @Override
    public String[] getExtendedBdoNames() {
        return new String[]{DEPOSIT_TRANSACTION, CHEQUE_SELL, CHEQUE_BUY, TDA_HIST, TD_TRANSFER_TXN, 
        		TD_DEPOSIT_TXN, BILL_TRAN_HIST, FEE_MANUAL_CHARGES, TRANSFER_TRANSACTION, CHEQUEBOOKREQ_TRANSACTION };
    }

    @Override
    public String[] getExtendedServiceNames() {
        return new String[]{CASH_DEPOSIT_SERVICE, CASH_WITHDRAWAL_SERVICE, CHEQUE_DEPOSIT_SERVICE,
                CHEQUE_WITHDRAWAL_SERVICE, MISC_DEPOSIT_SERVICE, MISC_WITHDRAWAL_SERVICE, CHEQUE_SELL_SERVICE,
                CHEQUE_BUY_SERVICE, TDA_HIST_SERVICE, TD_TRANSFER_TXN_SERVICE, TD_DEPOSIT_TXN_SERVICE,
                BILL_TRAN_HIST_SERVICE, FEE_MANUAL_CHARGES_SERVICE, TRANSFER_TRANSACTION_SERVICE,
                CHEQUEBOOK_REQ_SERVICE};
    }

    @Override
    public void beforeService(Object[] serviceParameters) {
        for (Object item : serviceParameters) {
            if(item instanceof DepositTransaction) {
                DepositTransaction request = (DepositTransaction) item;
                if(shouldIgnoreRestraint(request)){
                    request.setIgnoreRestraint(YES);
                    ignoreRestraintForFee(request.getDepFeeApplyList());
                }
                break;
            } else if(item instanceof ChqSell){
                ChqSell request = (ChqSell) item;
                if(shouldIgnoreRestraint(request)){
                	handleChqSell(request);
                }
                break;
            } else if(item instanceof ChqBuy){
                ChqBuy request = (ChqBuy) item;
                if(shouldIgnoreRestraint(request)){
                	handleChqBuy(request);
                }
                break;
            } else if(item instanceof TdaHist){
            	TdaHist request = (TdaHist) item;
                if(shouldIgnoreRestraint(request)){
                	handleTdaHist(request);
                }
                break;
            } else if(item instanceof TdTransferTransaction){
            	TdTransferTransaction request = (TdTransferTransaction) item;
                if(shouldIgnoreRestraint(request)){
                	request.setIgnoreRestraint(YES);
                	ignoreRestraintForFee(request.getDrFeeApplyList());
                	ignoreRestraintForFee(request.getCrFeeApplyList());
                }
                break;
            } else if(item instanceof TdDepositTransaction){
            	TdDepositTransaction request = (TdDepositTransaction) item;
                if(shouldIgnoreRestraint(request)){
                	request.setIgnoreRestraint(YES);
                	ignoreRestraintForFee(request.getDepFeeApplyList());
                }
                break;
            } else if(item instanceof BillTranHist){
            	BillTranHist request = (BillTranHist) item;
                if(shouldIgnoreRestraint(request)){
                	request.setIgnoreRestraint(YES);
                	ignoreRestraintForFee(request.getDepFeeApplyList());
                }
                break;
            } else if(item instanceof TransferTransaction){
            	TransferTransaction request = (TransferTransaction) item;
                if(shouldIgnoreRestraint(request)){
                	request.setIgnoreRestraint(YES);
                	handleTransferTransaction(request);
                }
                break;
            } else if(item instanceof ChequeCtrl){
            	ChequeCtrl request = (ChequeCtrl) item;
                if(shouldIgnoreRestraint(request)){
                	ignoreRestraintForFee(request.getDepFeeApplyList());
                }
                break;
            }
        }
    }
    
    private boolean shouldIgnoreRestraint(CbsServiceDataObjectBase request){
        boolean setIgnoreRestraintYes = false;
        CbsSessionContext sessionCtx = getSessionContext();
        String dataOwner = sessionCtx.getChannelCode();
        String dataChannel = sessionCtx.getChannelSource();
        /**
         * Originated in CBS UI
         */
        if (request != null && request.getHeader() != null && request.getHeader().getBpmInfo() != null &&
                request.getHeader().getBpmInfo().getOfficerId() != null && CBS_UI.equals(dataChannel) && CBS.equals(dataOwner)) {
            CbsBpmInfo cbsBpmInfo = request.getHeader().getBpmInfo();
            ConcurrentHashMap<String, Object> map = bpmService.getProcessDataMapFromDB(cbsBpmInfo.getProcessInstanceId());
            Object svcResponse = map.get(BpmConstants.SERVICE_RESPONSE);
            if(svcResponse != null){
                if(svcResponse instanceof CbsBpmInfoJpe){
                    CbsBpmInfoJpe cbsBpmInfoJpe = (CbsBpmInfoJpe) svcResponse;
                    for (CbsServiceMessageJpe csmJpe : cbsBpmInfoJpe.getServiceMessageList()) {
                        if (csmJpe != null && csmJpe.getBdoObject() == null
                                && StringUtils.contains(csmJpe.getCode(), ':')) {
                            csmJpe.setCode(null);
                            csmJpe.setMessage(null);
                        }
                    }
                    CbsBpmInfo bdo = jaxbSdoHelper.wrap(cbsBpmInfoJpe);
                    cbsBpmInfo.setServiceMessageList(bdo.getServiceMessageList());
                }
            }

            List<CbsServiceMessage> serviceMessages = cbsBpmInfo.getServiceMessageList();
            CbsServiceMessage obj = serviceMessages.stream().filter(
                    serviceMessage -> RESTRAINT_ERROR_CODES.contains(serviceMessage.getCode())).findAny().orElse(null);
            if(obj != null) {
                //Set the ignoreRestraint to Y
                setIgnoreRestraintYes = true;
            }
        } else if(request != null && request.getHeader() != null && request.getHeader().getBpmInfo() != null &&
        		!StringUtils.isBlank(request.getHeader().getBpmInfo().getOfficerId()) && !CBS_UI.equals(dataChannel)) {
            setIgnoreRestraintYes = true;
        }
        return setIgnoreRestraintYes;
    }
    
    private void ignoreRestraintForFee(List<DepFeeApply> list){
        if (list != null && !list.isEmpty()) {
            for (DepFeeApply depFeeApply : list) {
                if (depFeeApply.getTranValidationFlags() != null) {
                    TranValidationFlags tranValidationFlags = depFeeApply.getTranValidationFlags();
                    tranValidationFlags.setIgnRestraint(YES);
                }
            }
        }    	
    }

    private void handleChqSell(ChqSell request){
        List<ChqSellTran> list = request.getChqSellTranList();
        if (list != null && !list.isEmpty()) {
            for (ChqSellTran chqSellTran : list) {
                chqSellTran.setIgnoreRestraint(YES);
            }
        }
        if(request.getChqSellScDtlsRec() != null && request.getChqSellScDtlsRec().getDepFeeApplyList() != null){
            ignoreRestraintForFee(request.getChqSellScDtlsRec().getDepFeeApplyList());
        }
    }

    private void handleChqBuy(ChqBuy request){
        List<ChqBuyTran> list = request.getChqBuyTranList();
        if (list != null && !list.isEmpty()) {
            for (ChqBuyTran chqBuyTran : list) {
                chqBuyTran.setIgnoreRestraint(YES);
            }
        }
        if(request.getChqBuyScDtlsRec() != null && request.getChqBuyScDtlsRec().getDepFeeApplyList() != null){
        	ignoreRestraintForFee(request.getChqBuyScDtlsRec().getDepFeeApplyList());
        }
    }
    
    private void handleTdaHist(TdaHist request){
    	if(request.getTdaPymtDtlsList() != null && request.getTdaPymtDtlsList().size() > 0){
    		for(TdaPymtDtls pymt : request.getTdaPymtDtlsList()){
    			pymt.setIgnoreRestraint(YES);
				ignoreRestraintForFee(pymt.getDrDepFeeApplyList());
				ignoreRestraintForFee(pymt.getCrDepFeeApplyList());
    		}
    	}
		ignoreRestraintForFee(request.getDepFeeApplyList());
    }
    
    private void handleTransferTransaction(TransferTransaction request){
    	if(request.getTfrDetailList() != null && request.getTfrDetailList().size() > 0){
    		for(TransferTransactionDetail tfrDtl : request.getTfrDetailList()){
    			ignoreRestraintForFee(tfrDtl.getCrFeeApplyList());
    			ignoreRestraintForFee(tfrDtl.getDrFeeApplyList());
    		}
    	}
    }

    private CbsSessionContext getSessionContext() {
        return cbsRuntimeContextManager.getContext(CbsSessionContext.class);
    }


}
