package com.silverlakesymmetri.cbs.dep.svc.mapper;

import java.util.Map;

import org.mapstruct.Context;
import org.mapstruct.DecoratedWith;
import org.mapstruct.InheritConfiguration;
import org.mapstruct.InheritInverseConfiguration;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingTarget;
import org.mapstruct.Mappings;

import com.silverlakesymmetri.cbs.commons.jpa.util.DateTimeHelper;
import com.silverlakesymmetri.cbs.commons.xmlapi.enums.CbsXmlApiOperation;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.FeeManualChargesJpe;
import com.silverlakesymmetri.cbs.dep.svc.mapper.decorator.FeeManualChargesServiceDecorator;
import com.silverlakesymmetri.cbs.dep.svc.mapper.mapping.FeeManualChargesToDEPMANUALCHARGESAPITypeMapper;
import com.silverlakesymmetri.cbs.dep.xmlapi.DEPMANUALCHARGESAPIType;

@Mapper(config = FeeManualChargesToDEPMANUALCHARGESAPITypeMapper.class, uses = { DateTimeHelper.class })
@DecoratedWith(FeeManualChargesServiceDecorator.class)
public interface FeeManualChargesServiceMapper {
	@SuppressWarnings("rawtypes")
	@Mappings({ @Mapping(expression = "java(oper != null ? oper.getOperation() : null)", target = "OPERATION") })
	@InheritConfiguration
	public DEPMANUALCHARGESAPIType mapToApi(FeeManualChargesJpe jpe, @Context CbsXmlApiOperation oper, @Context Map otherInfo);
	@InheritInverseConfiguration(name = "mapFeeManualChargesToDEPMANUALCHARGESAPIType")
	@Mappings({
		@Mapping(target = "effectDate", source = "EFFECTDATE", qualifiedByName = { "DateTimeHelper", "convertCbsApiDateToString" })
	})
	public FeeManualChargesJpe mapToJpe(DEPMANUALCHARGESAPIType api, @MappingTarget FeeManualChargesJpe jpe);
}
