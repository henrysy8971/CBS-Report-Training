package com.silverlakesymmetri.cbs.dep.svc;

import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation;
import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation.ServiceOperationType;
import com.silverlakesymmetri.cbs.commons.svc.BusinessService;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.BillTranHist;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.BillTranHistJpe;

public interface BillTranHistService extends BusinessService<BillTranHist, BillTranHistJpe> {

	public static final String SVC_OP_NAME_BILLTRANHISTSERVICE_CREATE= "BillTranHistService.create";
	public static final String SVC_OP_NAME_BILLTRANHISTSERVICE_GET= "BillTranHistService.get";
	
	@ServiceOperation(name = SVC_OP_NAME_BILLTRANHISTSERVICE_CREATE)
    public BillTranHist create(BillTranHist dataObject);

	@ServiceOperation(name = SVC_OP_NAME_BILLTRANHISTSERVICE_GET, type = ServiceOperationType.GET)
    public BillTranHist getByPk(String publicKey, BillTranHist reference);

}
