package com.silverlakesymmetri.cbs.dep.svc;

import java.util.List;
import java.util.Map;

import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation;
import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation.ServiceOperationType;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.svc.BusinessService;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.CiPrefix;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.CiPrefixJpe;

public interface CiPrefixMainService extends BusinessService<CiPrefix, CiPrefixJpe> {

    public static final String SVC_OP_NAME_CIPREFIXMAINSERVICE_GET = "CiPrefixMainService.get";
    public static final String SVC_OP_NAME_CIPREFIXMAINSERVICE_QUERY = "CiPrefixMainService.query";
    public static final String SVC_OP_NAME_CIPREFIXMAINSERVICE_CREATE = "CiPrefixMainService.create";
    public static final String SVC_OP_NAME_CIPREFIXMAINSERVICE_UPDATE = "CiPrefixMainService.update";
    public static final String SVC_OP_NAME_CIPREFIXMAINSERVICE_DELETE = "CiPrefixMainService.delete";
    public static final String SVC_OP_NAME_CIPREFIXMAINSERVICE_FIND = "CiPrefixMainService.find";

    @ServiceOperation(name = SVC_OP_NAME_CIPREFIXMAINSERVICE_GET, type = ServiceOperationType.GET)
    public CiPrefix getByPk(String publicKey, CiPrefix reference);

    @ServiceOperation(name = SVC_OP_NAME_CIPREFIXMAINSERVICE_CREATE)
    public CiPrefix create(CiPrefix dataObject);

    @ServiceOperation(name = SVC_OP_NAME_CIPREFIXMAINSERVICE_UPDATE)
    public CiPrefix update(CiPrefix dataObject);

    @ServiceOperation(name = SVC_OP_NAME_CIPREFIXMAINSERVICE_QUERY)
    public List<CiPrefix> query(int offset, int resultLimit, String groupBy, String order, Map<String, Object> filters);

    @ServiceOperation(name = SVC_OP_NAME_CIPREFIXMAINSERVICE_DELETE)
    public boolean delete(CiPrefix dataObject);

    @ServiceOperation(name = SVC_OP_NAME_CIPREFIXMAINSERVICE_FIND)
    public List<CiPrefix> find(FindCriteria findCriteria, CbsHeader cbsHeader);

}
