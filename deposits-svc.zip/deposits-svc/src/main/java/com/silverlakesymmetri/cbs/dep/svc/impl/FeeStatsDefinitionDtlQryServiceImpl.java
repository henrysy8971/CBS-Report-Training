package com.silverlakesymmetri.cbs.dep.svc.impl;

import com.mysema.query.types.EntityPath;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.svc.AbstractBusinessService;
import com.silverlakesymmetri.cbs.commons.svc.BusinessObjectValidationCapable;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.FeeStatsDefinitionDtl;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.FeeStatsDefinitionDtlJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.QFeeStatsDefinitionDtlJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.id.FeeStatsDefinitionDtlPk;
import com.silverlakesymmetri.cbs.dep.svc.FeeStatsDefinitionDtlQryService;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;

@Service
public class FeeStatsDefinitionDtlQryServiceImpl extends AbstractBusinessService<FeeStatsDefinitionDtl, FeeStatsDefinitionDtlJpe, FeeStatsDefinitionDtlPk>
        implements FeeStatsDefinitionDtlQryService, BusinessObjectValidationCapable<FeeStatsDefinitionDtl> {

	@Override
    protected FeeStatsDefinitionDtlPk getIdFromDataObjectInstance(FeeStatsDefinitionDtl dataObject) {
		if (dataObject != null) {
			return new FeeStatsDefinitionDtlPk(dataObject.getStatID(), dataObject.getTranType());
		}
        return null;
    }

    @Override
    protected EntityPath<FeeStatsDefinitionDtlJpe> getEntityPath() {
        return QFeeStatsDefinitionDtlJpe.feeStatsDefinitionDtlJpe;
    }

    @Override
    public FeeStatsDefinitionDtl getByPk(String publicKey, FeeStatsDefinitionDtl reference) {
        return super.getByPk(publicKey, reference);
    }

    @Override
    public List<FeeStatsDefinitionDtl> query(int offset, int resultLimit, String groupBy, String order,
                                   Map<String, Object> filters) {
        return super.query(offset, resultLimit, groupBy, order, filters);
    }

    @Override
    public List<FeeStatsDefinitionDtl> find(FindCriteria findCriteria, CbsHeader cbsHeader) {
        return super.find(findCriteria, cbsHeader);
    }
}
