package com.silverlakesymmetri.cbs.dep.svc;

import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation;
import com.silverlakesymmetri.cbs.commons.svc.BusinessService;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.AcctReactivation;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.AcctReactivationJpe;

/**
 *
 * @author luis.talag
 */
public interface AcctReactivationService extends BusinessService<AcctReactivation, AcctReactivationJpe> {
    
    public static final String SVC_OP_NAME_ACCTREACTIVATIONSERVICE_UPDATEACCTREACTIVATION = "acctReactivationService.updateAcctReactivation";

    @ServiceOperation(name = SVC_OP_NAME_ACCTREACTIVATIONSERVICE_UPDATEACCTREACTIVATION, type = ServiceOperation.ServiceOperationType.EXECUTE)
    public AcctReactivation updateAcctReactivation(AcctReactivation dataObject);
}
