package com.silverlakesymmetri.cbs.dep.svc.impl;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.mysema.query.types.EntityPath;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.svc.AbstractBusinessService;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.InwdType;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.InwdTypeJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.QInwdTypeJpe;
import com.silverlakesymmetri.cbs.dep.svc.InwdTypeService;

@Service
@Transactional
public class InwdTypeServiceImpl extends AbstractBusinessService<InwdType, InwdTypeJpe, String>
		implements InwdTypeService {

	@Override
	protected EntityPath<InwdTypeJpe> getEntityPath() {
		return QInwdTypeJpe.inwdTypeJpe;
	}

	@Override
	protected String getIdFromDataObjectInstance(InwdType dataObject) {
		return dataObject.getInwdType();
	}

	@Override
	public InwdType getByPk(String publicKey, InwdType reference) {
		return super.getByPk(publicKey, reference);
	}

	@Override
	public InwdType create(InwdType dataObject) {
		return super.create(dataObject);
	}

	@Override
	protected InwdType preCreateValidation(InwdType dataObject) {
		InwdTypeJpe inwdTypeJpe = jaxbSdoHelper.unwrap(dataObject);
		performDefaulting(inwdTypeJpe);
		return super.preCreateValidation(jaxbSdoHelper.wrap(inwdTypeJpe, InwdType.class));
	}

	private void performDefaulting(InwdTypeJpe inwdTypeJpe) {
		if (inwdTypeJpe != null) {
			if (inwdTypeJpe.isUsedYn() == null) {
				inwdTypeJpe.setUsedYn(false);
			}
			if (inwdTypeJpe.isActiveYn() == null) {
				inwdTypeJpe.setActiveYn(false);
			}
		}
	}

	@Override
	public InwdType update(InwdType dataObject) {
		return super.update(dataObject);
	}

	@Override
	public List<InwdType> query(int offset, int resultLimit, String groupBy, String order,
			Map<String, Object> filters) {
		return super.query(offset, resultLimit, groupBy, order, filters);
	}

	@Override
	public boolean delete(InwdType dataObject) {
		return super.delete(dataObject);
	}

	@Override
	public List<InwdType> find(FindCriteria findCriteria, CbsHeader cbsHeader) {
		return super.find(findCriteria, cbsHeader);
	}

}
