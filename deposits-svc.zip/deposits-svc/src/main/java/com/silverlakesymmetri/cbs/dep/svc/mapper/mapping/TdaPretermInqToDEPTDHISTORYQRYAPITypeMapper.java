package com.silverlakesymmetri.cbs.dep.svc.mapper.mapping;

import org.mapstruct.InheritInverseConfiguration;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Mappings;

import com.silverlakesymmetri.cbs.commons.jpa.util.DateTimeHelper;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.TdaPretermInqJpe;
import com.silverlakesymmetri.cbs.dep.xmlapi.DEPTDHISTORYQRYAPIType;

@Mapper(uses = { DateTimeHelper.class })
public interface TdaPretermInqToDEPTDHISTORYQRYAPITypeMapper {

	@Mappings({
		@Mapping(source = "pretermDate", target = "PRETERMDATE", qualifiedByName = { "DateTimeHelper", "convertDateToCbsXmlApiDate" }),
		@Mapping(source = "pretermAmt", target = "PRETERMAMT"),
		@Mapping(source = "penaltyRate", target = "PENALTYRATE"),
		@Mapping(source = "penaltyAmt", target = "PENALTYAMT")
	})
	public DEPTDHISTORYQRYAPIType mapTdaPretermInqToDEPTDHISTORYQRYAPIType(TdaPretermInqJpe jpe);

	@InheritInverseConfiguration(name = "mapTdaPretermInqToDEPTDHISTORYQRYAPIType")
	@Mappings({
		@Mapping(target = "pretermDate", source = "PRETERMDATE", qualifiedByName = { "DateTimeHelper", "convertCbsApiDateToString" })
	})
	public TdaPretermInqJpe mapDEPTDHISTORYQRYAPITypeToTdaPretermInq(DEPTDHISTORYQRYAPIType api);

}
