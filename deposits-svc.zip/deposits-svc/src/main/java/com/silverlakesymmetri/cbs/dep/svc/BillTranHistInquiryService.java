package com.silverlakesymmetri.cbs.dep.svc;

import java.util.List;
import java.util.Map;

import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation;
import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation.ServiceOperationType;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.svc.BusinessService;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.BalHistCtrlInq;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.BillTranHistInquiry;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.FloatMatrix;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.TranHist;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.BillTranHistInquiryJpe;

public interface BillTranHistInquiryService extends BusinessService<BillTranHistInquiry, BillTranHistInquiryJpe> {
	
	public static final String SVC_OP_NAME_BILLTRANHISTINQUIRYSERVICE_QUERY = "BillTranHistInquiryService.query";
	public static final String SVC_OP_NAME_BILLTRANHISTINQUIRYSERVICE_FIND = "BillTranHistInquiryService.find";
	public static final String SVC_OP_NAME_BILLTRANHISTINQUIRYSERVICE_GET = "BillTranHistInquiryService.get";
	public static final String SVC_OP_NAME_BILLTRANHISTINQUIRYSERVICE_PROCESSCHEQUE = "BillTranHistInquiryService.processCheque";

	@ServiceOperation(name = SVC_OP_NAME_BILLTRANHISTINQUIRYSERVICE_QUERY)
	public List<BillTranHistInquiry> query(int offset, int resultLimit, String groupBy, String order,
			Map<String, Object> filters);

	@ServiceOperation(name = SVC_OP_NAME_BILLTRANHISTINQUIRYSERVICE_FIND)
	public List<BillTranHistInquiry> find(FindCriteria findCriteria, CbsHeader cbsHeader);

	@ServiceOperation(name = SVC_OP_NAME_BILLTRANHISTINQUIRYSERVICE_GET, type = ServiceOperationType.GET)
	public BillTranHistInquiry getByPk(String publicKey, BillTranHistInquiry reference);
	
	@ServiceOperation(name = SVC_OP_NAME_BILLTRANHISTINQUIRYSERVICE_PROCESSCHEQUE, type = ServiceOperationType.EXECUTE)
    public BillTranHistInquiry processCheque(BillTranHistInquiry dataObject);

}
