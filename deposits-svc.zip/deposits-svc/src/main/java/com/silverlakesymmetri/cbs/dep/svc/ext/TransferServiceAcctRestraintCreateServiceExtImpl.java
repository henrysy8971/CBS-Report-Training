package com.silverlakesymmetri.cbs.dep.svc.ext;

import com.silverlakesymmetri.cbs.commons.context.CbsRuntimeContextManager;
import com.silverlakesymmetri.cbs.commons.ext.impl.AbstractServiceExtPointImpl;
import com.silverlakesymmetri.cbs.commons.jpa.extension.JaxbSdoHelper;
import com.silverlakesymmetri.cbs.commons.jpa.service.CbsGenericDataService;
import com.silverlakesymmetri.cbs.commons.jpa.util.DateTimeHelper;
import com.silverlakesymmetri.cbs.commons.logging.CbsAppLogger;
import com.silverlakesymmetri.cbs.commons.logging.CbsAppLoggerFactory;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.AcctRestraint;
import com.silverlakesymmetri.cbs.dep.svc.AcctRestraintService;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.util.CommonAcctRestraintHolder;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * Created by Emerson.Sanchez on 15/9/2020.
 */
@Service
public class TransferServiceAcctRestraintCreateServiceExtImpl extends AbstractServiceExtPointImpl {

    private CbsAppLogger logger = CbsAppLoggerFactory.getLogger(TransferServiceAcctRestraintCreateServiceExtImpl.class
            .getName());

    private static final String GFT = "GFT";
    private static final String FUNDS_TRANSFER_REGISTRY = "FUNDS_TRANSFER_REGISTRY";
    private static final String RESTRAINT_TYPE = "ftRestraintType";

    @Autowired
    private AcctRestraintService acctRestraintService;

    @Autowired
    protected JaxbSdoHelper jaxbSdoHelper;

    @Autowired
    protected CbsGenericDataService cbsGenericDataService;

    @Autowired
    private CbsRuntimeContextManager cbsRuntimeContextManager;

    @Autowired
    DateTimeHelper dateTimeHelper;

    @Override
    public String[] getExtendedBdoNames() {
        return new String[] { "OutgoingTransfers", "IncomingTransfers", "InternalTransfers" };
    }

    @Override
    public String[] getExtendedServiceNames() {
        return new String[] {"OutgoingTransfersService.create", "IncomingTransfersService.create",
                "InternalTransfersService.create"};
    }

    @Override
    public Object afterValidationBeforeMainService(Object result) {
        if(result == null) {
            return null;
        }
        CommonAcctRestraintHolder data = (CommonAcctRestraintHolder) result;
        final String restraintType = getRestraintType();
        if (StringUtils.isNotBlank(restraintType)) {
            AcctRestraint arBdo = jaxbSdoHelper.createSdoInstance(AcctRestraint.class);
            logger.debug("[DEBUG] OutgoingTransferAcctRestraintCreateServiceExtImpl.afterValidationBeforeMainService - "+data.getAcctNo());
            arBdo.setAcctNo(data.getAcctNo());
            arBdo.setRestraintType(restraintType);
            arBdo.setPledgedAmt(data.getPledgedAmt());
            arBdo.setSourceModule(GFT);
            arBdo.setStartDate(dateTimeHelper.getSDODateTime(data.getStartDate()));
            arBdo.setEndDate(dateTimeHelper.getSDODateTime(data.getEndDate()));
            if (StringUtils.isBlank(arBdo.getEndDate())) {
                arBdo.setEndDate("2999-01-01");
            }
            arBdo.setNarrative(data.getNarrative());
            arBdo.setReferenceNo(data.getReferenceNo());
            AcctRestraint response = acctRestraintService.create(arBdo);
            data.setAcctRestraintKey(response.getSeqNo());
        } else {
            logger.warn("Missing Registry GFT Restraint Type.");
        }
        return data;
    }

    private String getRestraintType() {
        String restraintType = cbsRuntimeContextManager.getBestAvailableContext().getRegistryEntry(
                FUNDS_TRANSFER_REGISTRY, RESTRAINT_TYPE, String.class);
        return restraintType;
    }

}
