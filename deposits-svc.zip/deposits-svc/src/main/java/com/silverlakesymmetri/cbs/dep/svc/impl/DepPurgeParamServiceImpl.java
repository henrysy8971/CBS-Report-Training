package com.silverlakesymmetri.cbs.dep.svc.impl;

import com.mysema.query.types.EntityPath;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.svc.AbstractBusinessService;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.DepPurgeParam;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.DepPurgeParamJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.QDepPurgeParamJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.id.DepPurgeParamPk;
import com.silverlakesymmetri.cbs.dep.svc.DepPurgeParamService;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;

/**
 * Created by Emerson.Sanchez on 16/5/2022.
 */
@Service
public class DepPurgeParamServiceImpl extends AbstractBusinessService<DepPurgeParam, DepPurgeParamJpe, DepPurgeParamPk>
        implements DepPurgeParamService{

    @Override
    protected DepPurgeParamPk getIdFromDataObjectInstance(DepPurgeParam dataObject) {
        return new DepPurgeParamPk(dataObject.getTableName());
    }

    @Override
    protected EntityPath<DepPurgeParamJpe> getEntityPath() {
        return QDepPurgeParamJpe.depPurgeParamJpe;
    }

    @Override
    public DepPurgeParam create(DepPurgeParam dataObject) {
        return super.create(dataObject);
    }

    @Override
    public DepPurgeParam update(DepPurgeParam dataObject) {
        return super.update(dataObject);
    }

    @Override
    public List<DepPurgeParam> query(int offset, int resultLimit, String groupBy, String order,
                                 Map<String, Object> filters) {
        return super.query(offset, resultLimit, groupBy, order, filters);
    }

    @Override
    public boolean delete(DepPurgeParam dataObject) {
        return super.delete(dataObject);
    }

    @Override
    public List<DepPurgeParam> find(FindCriteria findCriteria, CbsHeader cbsHeader) {
        return super.find(findCriteria, cbsHeader);
    }
}
