package com.silverlakesymmetri.cbs.dep.svc;

import java.util.List;
import java.util.Map;

import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation;
import com.silverlakesymmetri.cbs.commons.svc.BusinessService;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.CalcTdMaturityDate;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.CalcTdMaturityDateJpe;

public interface CalcTdMaturityDateService extends BusinessService<CalcTdMaturityDate, CalcTdMaturityDateJpe>  {

	String SVC_OP_NAME_CALCTDMATURITYDATESERVICE_QUERY = "CalcTdMaturityDateService.query";
	
	@ServiceOperation(name = SVC_OP_NAME_CALCTDMATURITYDATESERVICE_QUERY)
    List<CalcTdMaturityDate> query(int offset, int resultLimit, String groupBy, String order, Map<String, Object> filters);
}
