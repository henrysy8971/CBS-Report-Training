package com.silverlakesymmetri.cbs.dep.svc.impl;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.mysema.query.types.EntityPath;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.svc.AbstractBusinessService;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.CiStatus;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.CiStatusJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.QCiStatusJpe;
import com.silverlakesymmetri.cbs.dep.svc.CiStatusService;


@Service
@Transactional
public class CiStatusServiceImpl extends AbstractBusinessService<CiStatus, CiStatusJpe, String> implements CiStatusService {

    @Override
    protected String getIdFromDataObjectInstance(CiStatus dataObject) {
        return dataObject.getChequeStatus();
    }

    @Override
    protected EntityPath<CiStatusJpe> getEntityPath() {
        return QCiStatusJpe.ciStatusJpe;
    }
    
//    @Override
//    protected CiStatus preCreateValidation(CiStatus dataObject) {
//    	CiStatusJpe jpe = jaxbSdoHelper.unwrap(dataObject);
//        if (null == jpe.isUsedYn()) {
//        	jpe.setUsedYn(false);
//        }
//        if (null == jpe.isActiveYn()) {
//        	jpe.setActiveYn(false);
//        }
//        
//        dataObject = jaxbSdoHelper.wrap(jpe, CiStatus.class);
//        return super.preCreateValidation(dataObject);
//    }
    
    @Override
    public CiStatus get(CiStatus objectInstanceIdentifier) {
        return super.get(objectInstanceIdentifier);
    }
    
//    @Override
//    public CiStatus create(CiStatus objectInstanceIdentifier) {
//        return super.create(objectInstanceIdentifier);
//    }
//    
//    @Override
//    public CiStatus update(CiStatus objectInstanceIdentifier) {
//        return super.update(objectInstanceIdentifier);
//    }
//    
//    @Override
//    public boolean delete(CiStatus objectInstanceIdentifier) {
//        return super.delete(objectInstanceIdentifier);
//    }

    @Override
    public List<CiStatus> query(int offset, int resultLimit, String groupBy, String order, Map<String, Object> filters) {
        return super.query(offset, resultLimit, groupBy, order, filters);
    }

    @Override
    public List<CiStatus> find(FindCriteria findCriteria, CbsHeader cbsHeader) {
        return super.find(findCriteria, cbsHeader);
    }

    @Override
    public CiStatus getByPk(String publicKey, CiStatus reference) {
        return super.getByPk(publicKey, reference);
    }
}
