package com.silverlakesymmetri.cbs.dep.svc.impl;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.silverlakesymmetri.cbs.commons.context.CbsSessionContext;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mysema.query.types.EntityPath;
import com.silverlakesymmetri.cbs.commons.svc.AbstractXmlApiBusinessService;
import com.silverlakesymmetri.cbs.commons.xmlapi.enums.CbsXmlApiOperation;
import com.silverlakesymmetri.cbs.core.constants.CoreConstants;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.AcctBranchTransfer;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.AcctBranchTransferJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.QAcctBranchTransferJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.id.AcctBranchTransferPk;
import com.silverlakesymmetri.cbs.dep.svc.AcctBranchTransferService;
import com.silverlakesymmetri.cbs.dep.svc.mapper.AcctBranchTransferServiceMapper;
import com.silverlakesymmetri.cbs.dep.xmlapi.DEPACCTBRANCHTRANSFERAPIType;
import com.silverlakesymmetri.cbs.pim.jpa.mapping.sdo.MasterAccountJpe;
import com.silverlakesymmetri.cbs.pim.jpa.mapping.sdo.util.JpeConstants;

@Service
public class AcctBranchTransferServiceImpl extends AbstractXmlApiBusinessService<AcctBranchTransfer, AcctBranchTransferJpe, AcctBranchTransferPk,  DEPACCTBRANCHTRANSFERAPIType, DEPACCTBRANCHTRANSFERAPIType>  implements AcctBranchTransferService {

	private static final String DEP_ACCT_BRANCH_TRANSFER_STG = "DEP_ACCT_BRANCH_TRANSFER_STG_S";
	private static final String DEP_ACCT_BRANCH_TRANSFER = "DEP_ACCT_BRANCH_TRANSFER_S";

	@Autowired
	AcctBranchTransferServiceMapper mapper;
	
	@Override
	protected DEPACCTBRANCHTRANSFERAPIType transformBdoToXmlApiRqCreate(AcctBranchTransfer dataObject) {
		// TODO Auto-generated method stub
		return transformAcctBranchTransferToDEPACCTBRANCHTRANSFERAPIType( dataObject, CbsXmlApiOperation.INSERT);
	}

	@Override
	protected DEPACCTBRANCHTRANSFERAPIType transformBdoToXmlApiRqUpdate(AcctBranchTransfer dataObject) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	protected DEPACCTBRANCHTRANSFERAPIType transformBdoToXmlApiRqDelete(AcctBranchTransfer dataObject) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	protected AcctBranchTransfer processXmlApiRs(AcctBranchTransfer dataObject, DEPACCTBRANCHTRANSFERAPIType xmlApiRs) {
		
		AcctBranchTransferJpe jpe = jaxbSdoHelper.unwrap(dataObject);
		jpe = mapper.mapToJpe(xmlApiRs, jpe);
		
		return jaxbSdoHelper.wrap(jpe);
	}

	@Override
	protected List<AcctBranchTransfer> processXmlApiListRs(AcctBranchTransfer dataObject,
			DEPACCTBRANCHTRANSFERAPIType xmlApiRs) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	protected Class<DEPACCTBRANCHTRANSFERAPIType> getXmlApiResponseClass() {
		// TODO Auto-generated method stub
		return DEPACCTBRANCHTRANSFERAPIType.class;
	}

	@Override
	protected AcctBranchTransferPk getIdFromDataObjectInstance(AcctBranchTransfer dataObject) {
		// TODO Auto-generated method stub
		AcctBranchTransferPk jpe = jaxbSdoHelper.unwrap(dataObject);
		return new AcctBranchTransferPk(jpe.getSeqNo());
	}

	@Override
	protected EntityPath<AcctBranchTransferJpe> getEntityPath() {
		// TODO Auto-generated method stub
		return QAcctBranchTransferJpe.acctBranchTransferJpe;
	}
	
	private MasterAccountJpe getMasterAccount( String accountNo) {
        final Map<String, Object> param = new HashMap<String, Object>();
        param.put(CoreConstants.ATTR_ACCOUNT_DOMAIN, "DEPOSIT");
        param.put(CoreConstants.ATTR_ACCOUNT_NO, accountNo);
        MasterAccountJpe masterAccountRec = dataService.getWithNamedQuery(JpeConstants.MASTER_ACCOUNT_JPE_GET_ACCOUNT_BY_DOMAIN_ACCOUNT_NO,
                param, MasterAccountJpe.class);
        return masterAccountRec;
    }

	public AcctBranchTransfer create(AcctBranchTransfer dataObject){
		AcctBranchTransfer bdo = super.create(dataObject);
		
		MasterAccountJpe master = getMasterAccount(bdo.getAcctNo());
		master.setBranch(bdo.getTrfToBranch());
		dataService.update(master);
		return bdo;
	}

	@Override
	protected AcctBranchTransfer preCreateValidation(AcctBranchTransfer dataObject) {
		int mainSeqNo = 0;

		CbsSessionContext sessionCtx = cbsRuntimeContextManager.getContext(CbsSessionContext.class);

		SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
		String formattedDate = format.format(sessionCtx.getRunDate());
		if (formattedDate.equals(dataObject.getTrfDate())) {
			mainSeqNo = dataService.nextSequenceValue(DEP_ACCT_BRANCH_TRANSFER).intValue();
		} else {
			mainSeqNo = dataService.nextSequenceValue(DEP_ACCT_BRANCH_TRANSFER_STG).intValue();
		}
		dataObject.setSeqNo(mainSeqNo);
		return super.preCreateValidation(dataObject);
	}

	private DEPACCTBRANCHTRANSFERAPIType transformAcctBranchTransferToDEPACCTBRANCHTRANSFERAPIType(AcctBranchTransfer dataObject, CbsXmlApiOperation oper){
		
		Map map = new HashMap();
		
		AcctBranchTransferJpe jpe = jaxbSdoHelper.unwrap(dataObject);
		DEPACCTBRANCHTRANSFERAPIType api =  mapper.mapToApi(jpe, oper, map);
		super.setTechColsFromDataObject(dataObject, api);
			
		return api;
	}

}
