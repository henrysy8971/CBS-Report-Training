package com.silverlakesymmetri.cbs.dep.svc.mapper.mapping;

import org.mapstruct.Context;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Mappings;

import com.silverlakesymmetri.cbs.commons.jpa.util.DateTimeHelper;
import com.silverlakesymmetri.cbs.commons.xmlapi.enums.CbsXmlApiOperation;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.CiRdBunchCaptureJpe;
import com.silverlakesymmetri.cbs.dep.xmlapi.DEPCIRDBUNCHTType;

@Mapper(uses={ DateTimeHelper.class})
public interface CiRdBunchCaptureToDEPCIRDBUNCHAPITypeMapper {
	
	@Mappings({ 
		@Mapping(source = "chequeRdKey", target="CHEQUERDKEY"),
		@Mapping(source = "chequeType", target="CHEQUETYPE"),
		@Mapping(source = "denomination", target="DENOMINATION"),
		@Mapping(source = "quantity", target="QUANTITY"),
		@Mapping(source = "prefix", target="PREFIX"),
		@Mapping(source = "startNo", target="STARTNO"),
		@Mapping(source = "endNo", target="ENDNO"),
		@Mapping(source = "ccy", target="CCY"),
		@Mapping(source = "branch", target="BRANCH"),
		@Mapping(source = "mainStartNo", target="MAINSTARTNO"),
		@Mapping(source = "mainEndNo", target="MAINENDNO"),
		@Mapping(source = "newBranch", target="NEWBRANCH"),
//		@Mapping(expression = "java(oper != null ? oper.getOperation() : null)", target="OPERATION"),
	 })
	public DEPCIRDBUNCHTType mapCiRdBunchRegToDEPCIRDBUNCHAPIType(CiRdBunchCaptureJpe jpe,  @Context CbsXmlApiOperation oper);	

}

