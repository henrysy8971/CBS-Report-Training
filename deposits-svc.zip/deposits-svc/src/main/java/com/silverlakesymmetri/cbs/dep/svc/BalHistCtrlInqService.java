package com.silverlakesymmetri.cbs.dep.svc;

import java.util.List;
import java.util.Map;

import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation;
import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation.ServiceOperationType;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.svc.BusinessService;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.BalHistCtrlInq;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.BalHistCtrlInqJpe;

public interface BalHistCtrlInqService extends BusinessService<BalHistCtrlInq, BalHistCtrlInqJpe> {
	
	public static final String SVC_OP_NAME_BALHISTCTRLINQSERVICE_QUERY = "BalHistCtrlInqService.query";
	public static final String SVC_OP_NAME_BALHISTCTRLINQSERVICE_FIND = "BalHistCtrlInqService.find";
	public static final String SVC_OP_NAME_BALHISTCTRLINQSERVICE_GET = "BalHistCtrlInqService.get";

	@ServiceOperation(name = SVC_OP_NAME_BALHISTCTRLINQSERVICE_QUERY)
	public List<BalHistCtrlInq> query(int offset, int resultLimit, String groupBy, String order,
			Map<String, Object> filters);

	@ServiceOperation(name = SVC_OP_NAME_BALHISTCTRLINQSERVICE_FIND)
	public List<BalHistCtrlInq> find(FindCriteria findCriteria, CbsHeader cbsHeader);

	@ServiceOperation(name = SVC_OP_NAME_BALHISTCTRLINQSERVICE_GET, type = ServiceOperationType.GET)
	public BalHistCtrlInq getByPk(String publicKey, BalHistCtrlInq reference);

}
