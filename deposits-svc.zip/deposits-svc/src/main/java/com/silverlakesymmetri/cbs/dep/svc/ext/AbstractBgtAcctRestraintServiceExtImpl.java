package com.silverlakesymmetri.cbs.dep.svc.ext;

import com.silverlakesymmetri.cbs.commons.ext.impl.AbstractServiceExtPointImpl;
import com.silverlakesymmetri.cbs.commons.jpa.extension.JaxbSdoHelper;
import com.silverlakesymmetri.cbs.commons.jpa.service.CbsEntityManagerAware;
import com.silverlakesymmetri.cbs.commons.jpa.service.CbsGenericDataService;
import com.silverlakesymmetri.cbs.commons.jpa.util.DateTimeHelper;
import com.silverlakesymmetri.cbs.commons.logging.CbsAppLogger;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.AcctRestraint;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.AcctRestraintJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.id.AcctRestraintPk;
import com.silverlakesymmetri.cbs.dep.svc.AcctRestraintService;
import com.silverlakesymmetri.cbs.xps.jpa.mapping.sdo.util.CommonAcctRestraintHolder;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.Calendar;
import java.util.Date;
import java.util.List;

public abstract class AbstractBgtAcctRestraintServiceExtImpl extends AbstractServiceExtPointImpl {

    @Autowired
    protected AcctRestraintService acctRestraintService;

    @Autowired
    protected JaxbSdoHelper jaxbSdoHelper;

    @Autowired
    protected CbsGenericDataService cbsGenericDataService;

    @Autowired
    protected DateTimeHelper dateTimeHelper;

    @Override
    public Object afterValidationBeforeMainService(Object listData) {
    	if(listData == null) {
            return null;
        }
    	List<CommonAcctRestraintHolder> list = (List<CommonAcctRestraintHolder>) listData;
    	if(list.isEmpty()) {
            return null;
        }
    	for (CommonAcctRestraintHolder holder : list) {
            if (StringUtils.isNotBlank(holder.getRestraintType())) {
            	AcctRestraint ar = jaxbSdoHelper.createSdoInstance(AcctRestraint.class);
                ar.setAcctNo(holder.getAcctNo());
                ar.setRestraintType(holder.getRestraintType());
                ar.setPledgedAmt(holder.getPledgedAmt());
                ar.setSourceModule(holder.getSourceModule());
                ar.setStartDate(holder.getBdoStartDate());
                if (ar.getStartDate() == null) {
                	Date startDate = holder.getStartDate();
                	if (startDate == null) {
                		startDate = dateTimeHelper.getRunDate();
                	}
                	ar.setStartDate(dateTimeHelper.getSDODateTime(startDate));
                }
                ar.setEndDate(holder.getBdoEndDate());
                if (ar.getEndDate() == null) {
                	Date endDate = holder.getEndDate();
                	if (endDate == null) {
                		Calendar cal = Calendar.getInstance();
                        cal.setTime(holder.getStartDate());
                        //As per data model, set the end date to any max date
                        cal.add(Calendar.YEAR, 900);
                        endDate = cal.getTime();
                	}
                	ar.setEndDate(dateTimeHelper.getSDODateTime(endDate));
                }
                ar.setNarrative(holder.getNarrative());
                ar.setReferenceNo(holder.getReferenceNo());
                AcctRestraint response = acctRestraintService.create(ar);
                holder.setAcctRestraintKey(response.getSeqNo());
            } else {
            	getLogger().warn("Missing Registry BGT Restraint Type.");
            }	
    	}
        
        return list;
    }
 
    public void removeAcctRestraints(List<Long> restraintKeys) {
		if (restraintKeys == null || restraintKeys.isEmpty()) return;
		
		for(Long key : restraintKeys) {
			if (key == null) continue;

			AcctRestraintJpe arJpe = cbsGenericDataService.find(AcctRestraintJpe.class, new AcctRestraintPk(key));

			// Need to perform detach, if not detached OptimisticLockException is encountered
            // Exception Description: One or more objects cannot be updated because it has changed or been deleted since it was last read
            ((CbsEntityManagerAware) cbsGenericDataService).getMyEntityManager().detach(arJpe);

			arJpe.setDateLifted(dateTimeHelper.getRunDate());
			arJpe.setForceFh("Y");

			acctRestraintService.update(jaxbSdoHelper.wrap(arJpe));
		}
		
	}
    
    protected abstract CbsAppLogger getLogger();
}
