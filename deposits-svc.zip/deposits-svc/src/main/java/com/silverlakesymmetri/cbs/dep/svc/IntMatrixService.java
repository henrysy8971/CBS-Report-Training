package com.silverlakesymmetri.cbs.dep.svc;

import java.util.Date;
import java.util.List;
import java.util.Map;

import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation;
import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation.ServiceOperationType;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.svc.BusinessService;
import com.silverlakesymmetri.cbs.csd.bdo.sdo.IntType;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.IntMatrix;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.IntMatrixJpe;

public interface IntMatrixService extends BusinessService<IntMatrix, IntMatrixJpe> {
	public static final String SVC_OP_NAME_INTMATRIXSERVICE_GET = "IntMatrixService.get";
	public static final String SVC_OP_NAME_INTMATRIXSERVICE_QUERY = "IntMatrixService.query";
	public static final String SVC_OP_NAME_INTMATRIXSERVICE_CREATE = "IntMatrixService.create";
	public static final String SVC_OP_NAME_INTMATRIXSERVICE_UPDATE = "IntMatrixService.update";
	public static final String SVC_OP_NAME_INTMATRIXSERVICE_DELETE = "IntMatrixService.delete";
	public static final String SVC_OP_NAME_INTMATRIXSERVICE_FIND = "IntMatrixService.find";
	public static final String SVC_OP_NAME_INTMATRIXSERVICE_GET_HISTORY = "IntMatrixService.getHistory";
	public static final String SVC_OP_NAME_INTMATRIXSERVICE_CR_INT_FOR_TD_ACCT = "IntMatrixService.findCrIntForTdAcct";
	public static final String SVC_OP_NAME_INTMATRIXSERVICE_GET_BY_INTTYPE_CCY_EFFDT = "IntMatrixService.getbyinttypeccyeffdt";
	public static final String SVC_OP_NAME_INTMATRIXSERVICE_LOAD_POOL_RATES = "IntMatrixService.loadpoolrates";
	public static final String SVC_OP_NAME_INTMATRIXSERVICE_FIND_FOR_CASA_ACCOUNT = "IntMatrixService.findForCasaAcctCrIntType";
//	public static final String SVC_OP_NAME_INTMATRIXSERVICE_FIND_FOR_TD_ACCOUNT = "IntMatrixService.findForTdAcctCrIntType";
	public static final String SVC_OP_NAME_INTMATRIXSERVICE_FIND_FOR_PRETERM_PROFIT_TYPE = "IntMatrixService.findPretermProfitType";
	public static final String SVC_OP_NAME_INTMATRIXSERVICE_BULK_CREATE = "IntMatrixService.bulkCreate";

	@ServiceOperation(name = SVC_OP_NAME_INTMATRIXSERVICE_CREATE)
	public IntMatrix create(IntMatrix dataObject);

	@ServiceOperation(name = SVC_OP_NAME_INTMATRIXSERVICE_UPDATE)
	public IntMatrix update(IntMatrix dataObject);

	@ServiceOperation(name = SVC_OP_NAME_INTMATRIXSERVICE_DELETE)
	public boolean delete(IntMatrix dataObject);

	@ServiceOperation(name = SVC_OP_NAME_INTMATRIXSERVICE_QUERY)
	public List<IntMatrix> query(int offset, int resultLimit, String groupBy, String order,
			Map<String, Object> filters);

	@ServiceOperation(name = SVC_OP_NAME_INTMATRIXSERVICE_FIND)
	public List<IntMatrix> find(FindCriteria findCriteria, CbsHeader cbsHeader);

	@ServiceOperation(name = SVC_OP_NAME_INTMATRIXSERVICE_GET, type = ServiceOperationType.GET)
	public IntMatrix getByPk(String publicKey, IntMatrix reference);

	@ServiceOperation(name = SVC_OP_NAME_INTMATRIXSERVICE_GET_HISTORY, type = ServiceOperationType.GET)
	public IntMatrix getHistoryByPk(String intType, String ccy, boolean finalYn);

	@ServiceOperation(name = SVC_OP_NAME_INTMATRIXSERVICE_CR_INT_FOR_TD_ACCT, type = ServiceOperationType.READ, passParamAsMap = true)
	public List<IntType> findCrIntForTdAcct(Map<String, Object> queryParams);

	@ServiceOperation(name = SVC_OP_NAME_INTMATRIXSERVICE_GET_BY_INTTYPE_CCY_EFFDT, type = ServiceOperationType.GET)
	public IntMatrix getbyinttypeccyeffdt(String intType, String ccy, Date asOfDate);

	@ServiceOperation(name = SVC_OP_NAME_INTMATRIXSERVICE_LOAD_POOL_RATES)
	public String loadPoolRates();

	@ServiceOperation(name = SVC_OP_NAME_INTMATRIXSERVICE_FIND_FOR_CASA_ACCOUNT, type = ServiceOperationType.READ, passParamAsMap = true)
	public List<IntType> findForCasaAcctCrIntType(Map<String, Object> queryParams);
/*
	@ServiceOperation(name = SVC_OP_NAME_INTMATRIXSERVICE_FIND_FOR_TD_ACCOUNT, type = ServiceOperationType.READ, passParamAsMap = true)
	public List<IntType> findForTdAcctCrIntType(Map<String, Object> queryParams);
*/
	@ServiceOperation(name = SVC_OP_NAME_INTMATRIXSERVICE_FIND_FOR_PRETERM_PROFIT_TYPE, type = ServiceOperationType.READ, passParamAsMap = true)
	public List<IntType> findPretermProfitType(Map<String, Object> queryParams);

	@ServiceOperation(name = SVC_OP_NAME_INTMATRIXSERVICE_BULK_CREATE, type = ServiceOperationType.EXECUTE)
	public boolean bulkCreate(List<IntMatrix> bdoList);

}
