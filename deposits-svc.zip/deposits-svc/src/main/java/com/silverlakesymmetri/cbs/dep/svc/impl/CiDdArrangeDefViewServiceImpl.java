package com.silverlakesymmetri.cbs.dep.svc.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.mysema.query.types.EntityPath;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.jpa.service.impl.BusinessDataObjectJpaQueryComponentImpl;
import com.silverlakesymmetri.cbs.commons.svc.AbstractBusinessService;
import com.silverlakesymmetri.cbs.commons.svc.util.InMemoryQueryExecutor;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.BillTranHist;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.CiDdArrangeDefView;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.FloatRolldown;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.TranDef;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.CiDdArrangeDefViewJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.DepositTransactionJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.QCiDdArrangeDefViewJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.TranDefJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.id.CiDdArrangeDefViewPk;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.util.DepJpeConstants;
import com.silverlakesymmetri.cbs.dep.svc.CiDdArrangeDefViewService;

@Service
@Transactional
public class CiDdArrangeDefViewServiceImpl extends AbstractBusinessService<CiDdArrangeDefView, CiDdArrangeDefViewJpe, CiDdArrangeDefViewPk> 
	implements CiDdArrangeDefViewService {

	@Override
	protected CiDdArrangeDefViewPk getIdFromDataObjectInstance(CiDdArrangeDefView dataObject) {
		return new CiDdArrangeDefViewPk(dataObject.getDdArrangeType(), dataObject.getChequeType(), dataObject.getAgentBank(), dataObject.getAgentBranch(), dataObject.getCcy()); 
	}

	@Override
	protected EntityPath<CiDdArrangeDefViewJpe> getEntityPath() {
		return QCiDdArrangeDefViewJpe.ciDdArrangeDefViewJpe;
	}

	@Override
	public List<CiDdArrangeDefView> query(int offset, int resultLimit, String groupBy, String order,
			Map<String, Object> filters) {
		
		if (filters != null && filters.get("listType") != null) {

			List<CiDdArrangeDefView> bdoList = new ArrayList<CiDdArrangeDefView>();
			String listType = filters.remove("listType").toString();

			if (listType.equalsIgnoreCase("DISTINCT_COUNTRY")) {
				String chequeType = null;
				String ccy = null;
				if (filters.get("chequeType") != null) {
					chequeType = filters.remove("chequeType").toString();
				}
				if (filters.get("ccy") != null) {
					ccy = filters.remove("ccy").toString();
				}
				
				Map<String, Object> params = new HashMap<String, Object>();
				if (!StringUtils.isEmpty(StringUtils.trim(chequeType))) {
					params.put("chequeType", chequeType);
				}
				
				if (!StringUtils.isEmpty(StringUtils.trim(ccy))) {
					params.put("ccy", ccy);
				}
				
				List<CiDdArrangeDefViewJpe> jpeList = dataService.findWithQuery(DepJpeConstants.CIDDARRANGEDEFVIEW_COUNTRY_FIND_BY_CHEQUETYPE_CCY_QUERY, CiDdArrangeDefViewJpe.class, params, null);
				if (jpeList != null && jpeList.size() > 0) {
					Iterator it = jpeList.iterator();
					while(it.hasNext()){
						Object[] line = (Object[]) it.next();
						CiDdArrangeDefView bdo = jaxbSdoHelper.createSdoInstance(CiDdArrangeDefView.class);
						bdo.setDdArrangeType((String) line[0]);
						bdo.setChequeType((String) line[1]);
						bdo.setAgentBank((String) line[2]);
						bdo.setAgentBranch((String) line[3]);
						bdo.setCountry((String) line[4]);
						bdo.setCountryDesc((String) line[5]);
						bdo.setState((String) line[6]);
						bdo.setStateDesc((String) line[7]);
						bdo.setCcy((String) line[8]);
						bdo.setDfltChequeType((String) line[9]);
						bdo.setSettleGlCode((String) line[11]);
						bdo.setDdPayableGlCode((String) line[12]);
						bdo.setReimburseInstr((String) line[14]);
						bdo.setPrintFormat((String) line[15]);
						
						bdoList.add(bdo);
					}
					
					FindCriteria fc = jaxbSdoHelper.wrap(BusinessDataObjectJpaQueryComponentImpl
							.buildFindCriteria(offset, resultLimit, groupBy, order, null));
					InMemoryQueryExecutor<CiDdArrangeDefView> inMemQry = new InMemoryQueryExecutor<>(bdoList);
					return inMemQry.executeFilter(fc);
				}
			}
			
			return bdoList;
		}
		
		return super.query(offset, resultLimit, groupBy, order, filters);
	}

	@Override
	public List<CiDdArrangeDefView> find(FindCriteria findCriteria, CbsHeader cbsHeader) {
		return super.find(findCriteria, cbsHeader);
	}

	@Override
	public CiDdArrangeDefView getByPk(String publicKey, CiDdArrangeDefView reference) {
		return super.getByPk(publicKey, reference);
	}

}
