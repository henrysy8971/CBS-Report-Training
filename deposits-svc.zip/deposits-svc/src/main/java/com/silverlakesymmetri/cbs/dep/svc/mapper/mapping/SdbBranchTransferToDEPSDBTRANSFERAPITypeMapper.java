package com.silverlakesymmetri.cbs.dep.svc.mapper.mapping;

import java.util.List;

import org.mapstruct.InheritConfiguration;
import org.mapstruct.MapperConfig;
import org.mapstruct.Mapping;
import org.mapstruct.Mappings;

import com.silverlakesymmetri.cbs.commons.jpa.util.DateTimeHelper;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.SdbBranchTransferJpe;
import com.silverlakesymmetri.cbs.dep.xmlapi.DEPSDBTRANSFERAPIType;

@MapperConfig(uses={ DateTimeHelper.class })
public interface SdbBranchTransferToDEPSDBTRANSFERAPITypeMapper {

	@Mappings({
		@Mapping(target="LOCKERNO",    			source="oldLockerNo"), 
		@Mapping(target="CONTRACTNO",     		source="contractNo"), 
		@Mapping(target="OLDBRANCH",       		source="oldBranch"), 
		@Mapping(target="NEWBRANCH",       		source="newBranch"), 
		@Mapping(target="EFFECTDATE",       	source="effectDate", qualifiedByName = {"DateTimeHelper","convertDateToCbsXmlApiDate"}),
	 })
	public DEPSDBTRANSFERAPIType mapSdbBranchTransferToDEPSDBTRANSFERAPIType(SdbBranchTransferJpe jpe);
}
