package com.silverlakesymmetri.cbs.dep.svc.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.mysema.query.types.EntityPath;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.context.CbsSessionContext;
import com.silverlakesymmetri.cbs.commons.svc.AbstractXmlApiBusinessService;
import com.silverlakesymmetri.cbs.commons.util.CbsStringUtil;
import com.silverlakesymmetri.cbs.commons.xmlapi.enums.CbsXmlApiOperation;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.SdbVisit;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.SdbVisitDtls;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.QSdbVisitJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.SdbVisitDtlsJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.SdbVisitJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.id.SdbVisitPk;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.util.DepJpeConstants;
import com.silverlakesymmetri.cbs.dep.svc.SdbVisitService;
import com.silverlakesymmetri.cbs.dep.svc.mapper.SdbVisitServiceMapper;
import com.silverlakesymmetri.cbs.dep.xmlapi.DEPSDBVISITAPIType;
import com.silverlakesymmetri.cbs.dep.xmlapi.DEPSDBVISITDTLSCOLLType;
import com.silverlakesymmetri.cbs.dep.xmlapi.DEPSDBVISITDTLSTType;
import com.silverlakesymmetri.cbs.mcl.jpa.mapping.sdo.ClientJpe;
import com.silverlakesymmetri.cbs.mcl.jpa.mapping.sdo.util.MclJpeConstants;

@Service
@Transactional
public class SdbVisitServiceImpl extends AbstractXmlApiBusinessService<SdbVisit, SdbVisitJpe, SdbVisitPk, DEPSDBVISITAPIType, DEPSDBVISITAPIType> 
	implements SdbVisitService {

	@Autowired
	SdbVisitServiceMapper pMapper;
		
	@Override
	protected EntityPath<SdbVisitJpe> getEntityPath() {
		return QSdbVisitJpe.sdbVisitJpe;
	}

	@Override
	protected SdbVisitPk getIdFromDataObjectInstance(SdbVisit dataObject) {
		SdbVisitPk pk = new SdbVisitPk(dataObject.getSeqNo());
		return pk;
	}

	@Override
	public List<SdbVisit> query(int offset, int resultLimit, String groupBy, String order,
			Map<String, Object> filters) {
		List<SdbVisit> list = super.query(offset, resultLimit, groupBy, order, filters);
		if (list != null) {
			for (SdbVisit bdo : list) {
				bdo.setTerminalId(CbsStringUtil.maskIpAddr(bdo.getTerminalId()));
			}
		}
		return list;
	}


	@Override
	public List<SdbVisit> find(FindCriteria findCriteria, CbsHeader cbsHeader) {
		List<SdbVisit> list = super.find(findCriteria, cbsHeader);
		if (list != null) {
			for (SdbVisit bdo : list) {
				bdo.setTerminalId(CbsStringUtil.maskIpAddr(bdo.getTerminalId()));
			}
		}
		return list;
	}
	
	@Override
	public SdbVisit create(SdbVisit dataObject) {
		SdbVisit bdo = super.create(dataObject);
		if (bdo != null) bdo.setTerminalId(CbsStringUtil.maskIpAddr(bdo.getTerminalId()));
		return bdo;
	}

	@Override
	public SdbVisit getByPk(String publicKey, SdbVisit dataObject) {
		String [] keys = publicKey.split("~");
		SdbVisitPk pk = new SdbVisitPk(Long.parseLong(keys[0]));
		SdbVisitJpe jpe = this.dataService.find(SdbVisitJpe.class, pk);
		jpe.setSdbVisitDtlsList(getSdbVisitDtlsList(jpe.getSeqNo(), jpe.getSdbInternalKey()));
		
		SdbVisit bdo = jaxbSdoHelper.wrap(jpe);
		if (bdo != null) bdo.setTerminalId(CbsStringUtil.maskIpAddr(bdo.getTerminalId()));
		return bdo;
	}
		
	@Override
	protected SdbVisit preCreateValidation(SdbVisit dataObject) {
		Long seqNoDefault = new Long(-1);
		if (dataObject.getSeqNo() == null) {
			dataObject.setSeqNo(seqNoDefault);
		}
		dataObject.setTerminalId(getWsId());
		List<SdbVisitDtls> arrDtls = new ArrayList<>();
		
		for(SdbVisitDtls dtls : dataObject.getSdbVisitDtlsList()) {
			dtls.setSeqNo(seqNoDefault);
			dtls.setSdbInternalKey(dataObject.getSdbInternalKey());
			arrDtls.add(dtls);
		}
		
		dataObject.setSdbVisitDtlsList(arrDtls);				
		return super.preCreateValidation(dataObject);
	}

	private String getWsId() {
		CbsSessionContext sessionCtx = cbsRuntimeContextManager.getContext(CbsSessionContext.class);
		return (String) sessionCtx.getEntry("clientInfoRecClientIpAddress");
	}

	private ClientJpe getClientJpe(Long clientId) {
		Map<String, Object> parameters = new HashMap<String, Object>();
		parameters.put("clientId", clientId);
		return dataService.getWithNamedQuery(MclJpeConstants.CLIENT_JPE_GET_CLIENT_FROM_ID, parameters, ClientJpe.class);
	}
	
	private Long clientId (String clientNo){
		Map<String, Object> param = new HashMap<String, Object>();
		param.put("clientNo", clientNo);
		Long clientId = dataService.getWithNamedQuery(MclJpeConstants.CLIENT_JPE_FIND_CLIENT_ID_USING_CLIENT_NO, param, Long.class);
		return clientId;
	}
	
	private List<SdbVisitDtlsJpe> getSdbVisitDtlsList(Long seqNo, Long sdbInternalKey) {
		Map<String, Object> params = new HashMap<String, Object>();
		params.put("seqNo", seqNo);
		params.put("sdbInternalKey", sdbInternalKey);
		List<SdbVisitDtlsJpe> sdbVisitDtlsJpe = this.dataService.findWithNamedQuery(DepJpeConstants.SDBVISITDTLS_FIND_BY_SDBINTERNALKEY_AND_SEQNO, params, SdbVisitDtlsJpe.class);
		
		for(SdbVisitDtlsJpe jpe : sdbVisitDtlsJpe) {
			ClientJpe clientJpe = this.getClientJpe(jpe.getClientId());
			if (clientJpe != null) {
				jpe.setClientName(clientJpe.getClientName());
				jpe.setClientShort(clientJpe.getClientShort());
				jpe.setClientNo(clientJpe.getClientNo());
			}
		}
		return sdbVisitDtlsJpe;
	}
	
	@Override
	protected DEPSDBVISITAPIType transformBdoToXmlApiRqCreate(SdbVisit dataObject) {
		return transformSdbVisitToDEPSDBVISITAPIType(dataObject, CbsXmlApiOperation.INSERT);
	}

	@Override
	protected DEPSDBVISITAPIType transformBdoToXmlApiRqUpdate(SdbVisit dataObject) {
		return transformSdbVisitToDEPSDBVISITAPIType(dataObject, CbsXmlApiOperation.UPDATE);
	}

	@Override
	protected DEPSDBVISITAPIType transformBdoToXmlApiRqDelete(SdbVisit dataObject) {
		return transformSdbVisitToDEPSDBVISITAPIType(dataObject, CbsXmlApiOperation.DELETE);
	}

	@Override
	protected SdbVisit processXmlApiRs(SdbVisit dataObject, DEPSDBVISITAPIType xmlApiRs) {		
		SdbVisitJpe jpe = new SdbVisitJpe();
		jpe = pMapper.mapToJpe(xmlApiRs, jpe);
		SdbVisit bdo = jaxbSdoHelper.wrap(jpe);
		if (bdo != null) bdo.setTerminalId(CbsStringUtil.maskIpAddr(bdo.getTerminalId()));
		return bdo;
	}

	@Override
	protected List<SdbVisit> processXmlApiListRs(SdbVisit dataObject, DEPSDBVISITAPIType xmlApiRs) {
		return null;
	}

	@Override
	protected Class<DEPSDBVISITAPIType> getXmlApiResponseClass() {
		return DEPSDBVISITAPIType.class;
	}
	
	private DEPSDBVISITAPIType transformSdbVisitToDEPSDBVISITAPIType(SdbVisit dataObject, CbsXmlApiOperation oper){

		SdbVisitJpe jpe = jaxbSdoHelper.unwrap(dataObject, SdbVisitJpe.class);

		String branch = getContractBranch(dataObject.getSdbInternalKey());
		jpe.setBranch(branch);

		DEPSDBVISITAPIType apiType =  pMapper.mapToApi(jpe, oper);
		super.setTechColsFromDataObject(dataObject, apiType);

		if (oper.equals( CbsXmlApiOperation.INSERT ) && jpe.getOfficerId() == null) {
			jpe.setOfficerId(apiType.getTECHNICALINFO().getCREATEDBY());
		}
		
		DEPSDBVISITDTLSCOLLType sdbVisitDtlsCollType = new DEPSDBVISITDTLSCOLLType();
		if (dataObject.getSdbVisitDtlsList() != null && dataObject.getSdbVisitDtlsList().size() > 0) {
			
			for (SdbVisitDtls sdbVisitDtls : dataObject.getSdbVisitDtlsList()) {
				SdbVisitDtlsJpe sdbVisitDtlsJpe = jaxbSdoHelper.unwrap(sdbVisitDtls);				
				DEPSDBVISITDTLSTType sdbVisitDtlsType = new DEPSDBVISITDTLSTType();
				
				Long clientId = this.clientId(sdbVisitDtlsJpe.getClientNo());
				sdbVisitDtlsType.setCLIENTNO(clientId);				
				sdbVisitDtlsType.setSDBINTERNALKEY((long) apiType.getSDBINTERNALKEY());
				sdbVisitDtlsType.setSEQNO((long)apiType.getSEQNO());
				sdbVisitDtlsType.setTECHNICALINFO(apiType.getTECHNICALINFO());				
				sdbVisitDtlsCollType.getDEPSDBVISITDTLST().add(sdbVisitDtlsType);
			}
		}

		apiType.setDETAILS(sdbVisitDtlsCollType);
					
		return apiType;
	}

	private String getContractBranch (Long sdbInternalKey) {
		Map<String, Object> params = new HashMap<>();
		params.put("sdbInternalKey", sdbInternalKey);
		return dataService.getWithNamedQuery(DepJpeConstants.SDB_ACCT_JPE_GET_BRANCH_BY_SDB_INTERNAL_KEY, params, String.class);
	}
}
