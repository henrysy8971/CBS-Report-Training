package com.silverlakesymmetri.cbs.dep.svc.impl;

import java.util.*;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.mysema.query.types.EntityPath;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.jpa.entity.FindCriteriaJpe;
import com.silverlakesymmetri.cbs.commons.svc.AbstractXmlApiBusinessService;
import com.silverlakesymmetri.cbs.commons.svc.BusinessObjectValidationCapable;
import com.silverlakesymmetri.cbs.commons.xmlapi.enums.CbsXmlApiOperation;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.AcctTypeTfrDetail;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.AcctTypeTfrHeader;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.AcctTypeTfrDetailJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.AcctTypeTfrHeaderJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.QAcctTypeTfrHeaderJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.id.AcctTypeTfrHeaderPk;
import com.silverlakesymmetri.cbs.dep.svc.AcctTypeTfrBulkService;
import com.silverlakesymmetri.cbs.dep.svc.DepositsValidatorService;
import com.silverlakesymmetri.cbs.dep.xmlapi.DEPACCTTYPETFRBULKAPIType;
import com.silverlakesymmetri.cbs.dep.xmlapi.DEPACCTTYPETFRBULKCOLLType;
import com.silverlakesymmetri.cbs.dep.xmlapi.DEPACCTTYPETFRBULKTType;
import com.silverlakesymmetri.cbs.mcl.jpa.mapping.sdo.util.MclJpeConstants;

/**
 * Created by Emerson.Sanchez on 17/4/2019.
 */
@Service
@Transactional
public class AcctTypeTfrBulkServiceImpl extends AbstractXmlApiBusinessService<AcctTypeTfrHeader, AcctTypeTfrHeaderJpe,
        AcctTypeTfrHeaderPk, DEPACCTTYPETFRBULKAPIType, DEPACCTTYPETFRBULKAPIType> implements AcctTypeTfrBulkService,
        BusinessObjectValidationCapable<AcctTypeTfrHeader> {
    private final static String ACCT_TYPE_TFR_HEADER_SEQ = "DEP_ACCT_TYPE_TFR_HEADER_S";
    
    @Autowired
    DepositsValidatorService depositsValidatorService;

    @Override
    protected DEPACCTTYPETFRBULKAPIType transformBdoToXmlApiRqCreate(AcctTypeTfrHeader dataObject) {
        return transformAcctTypeTfrHeaderToDEPACCTTYPETFRBULKAPIType(dataObject, CbsXmlApiOperation.INSERT);
    }

    @Override
    protected DEPACCTTYPETFRBULKAPIType transformBdoToXmlApiRqUpdate(AcctTypeTfrHeader dataObject) {
        return transformAcctTypeTfrHeaderToDEPACCTTYPETFRBULKAPIType(dataObject, CbsXmlApiOperation.UPDATE);
    }

    @Override
    protected DEPACCTTYPETFRBULKAPIType transformBdoToXmlApiRqDelete(AcctTypeTfrHeader dataObject) {
        return transformAcctTypeTfrHeaderToDEPACCTTYPETFRBULKAPIType(dataObject, CbsXmlApiOperation.DELETE);
    }

    private DEPACCTTYPETFRBULKAPIType transformAcctTypeTfrHeaderToDEPACCTTYPETFRBULKAPIType(
            AcctTypeTfrHeader dataObject, CbsXmlApiOperation operation) {

        DEPACCTTYPETFRBULKAPIType apiType = new DEPACCTTYPETFRBULKAPIType();
        super.setTechColsFromDataObject(dataObject, apiType);

        apiType.setOPERATION(operation.getOperation());
        apiType.setEFFECTIVEDATE((dataObject.getEffectiveDate() != null) ?
                dateTimeHelper.convertToCbsXmlApiDate(dataObject.getEffectiveDate()) : null);
        apiType.setFROMACCTTYPE(dataObject.getFromAcctType());
        apiType.setMAINSEQNO(dataObject.getMainSeqNo());
        apiType.setPROCESSDATE((dataObject.getProcessDate() != null) ?
                dateTimeHelper.convertToCbsXmlApiDate(dataObject.getProcessDate()) : null);
        apiType.setPROFITCENTRE(dataObject.getProfitCentre());
        apiType.setTAXTYPE(dataObject.getTaxType());
        apiType.setTOACCTTYPE(dataObject.getToAcctType());
        apiType.setGLNARRATIVE(dataObject.getGlNarrative());

        DEPACCTTYPETFRBULKCOLLType detailColl = new DEPACCTTYPETFRBULKCOLLType();
        AcctTypeTfrDetail detail = dataObject.getAcctTypeTfrDetailRec();
        if (detail != null) {
	        DEPACCTTYPETFRBULKTType acctTypeDetail = new DEPACCTTYPETFRBULKTType();
	        acctTypeDetail.setMAINSEQNO(detail.getMainSeqNo());
	        acctTypeDetail.setFROMACCTNO(detail.getFromAcctNo());
	        acctTypeDetail.setFROMBRANCH(detail.getFromBranch());
	        Number fromClientId = getClientId(detail.getFromClientNo());
	        if(fromClientId != null){
	            acctTypeDetail.setFROMCLIENTNO(fromClientId.doubleValue());
	        }
	
	        acctTypeDetail.setSEQNO(detail.getSeqNo());
	        acctTypeDetail.setSTATUS(detail.getStatus() != null ? detail.getStatus() : "N");
	        acctTypeDetail.setTOACCTNO(detail.getToAcctNo());
	        acctTypeDetail.setTOBRANCH(detail.getToBranch());
	        Number toClientId = getClientId(detail.getToClientNo());
	        if(toClientId != null){
	            acctTypeDetail.setTOCLIENTNO(toClientId.doubleValue());
	        } else if(fromClientId != null){
	        	acctTypeDetail.setTOCLIENTNO(fromClientId.doubleValue());
	        }
	        detailColl.getDEPACCTTYPETFRBULKT().add(acctTypeDetail);
	        apiType.setDEPACCTTYPETFRDETAILLIST(detailColl);
    	}
        return apiType;
    }

    @Override
    protected AcctTypeTfrHeader processXmlApiRs(AcctTypeTfrHeader dataObject,
                                                DEPACCTTYPETFRBULKAPIType depaccttypetfrbulkapiType) {
        return dataObject;
    }

    @Override
    protected List<AcctTypeTfrHeader> processXmlApiListRs(AcctTypeTfrHeader dataObject,
                                                          DEPACCTTYPETFRBULKAPIType depaccttypetfrbulkapiType) {
        return null;
    }

    @Override
    protected Class<DEPACCTTYPETFRBULKAPIType> getXmlApiResponseClass() {
        return DEPACCTTYPETFRBULKAPIType.class;
    }

    @Override
    protected AcctTypeTfrHeaderPk getIdFromDataObjectInstance(AcctTypeTfrHeader dataObject) {
        AcctTypeTfrHeaderJpe jpe = jaxbSdoHelper.unwrap(dataObject, AcctTypeTfrHeaderJpe.class);
        return new AcctTypeTfrHeaderPk(jpe.getMainSeqNo());
    }

    @Override
    protected EntityPath<AcctTypeTfrHeaderJpe> getEntityPath() {
        return QAcctTypeTfrHeaderJpe.acctTypeTfrHeaderJpe;
    }

    @Override
    public Long count(FindCriteria findCriteria, CbsHeader cbsHeader) {
        FindCriteriaJpe jpe = jaxbSdoHelper.unwrap(findCriteria, FindCriteriaJpe.class);
        return dataService.getRowCount(AcctTypeTfrHeaderJpe.class, jpe);
    }

    @Override
    public List<AcctTypeTfrHeader> query(int offset, int resultLimit, String groupBy, String order,
                                        Map<String, Object> filters) {
        return super.query(offset, resultLimit, groupBy, order, filters);
    }

    @Override
    public List<AcctTypeTfrHeader> find(FindCriteria findCriteria, CbsHeader cbsHeader) {
        return super.find(findCriteria, cbsHeader);
    }

    @Override
    public AcctTypeTfrHeader update(AcctTypeTfrHeader dataObject) {
        return super.update(dataObject);
    }

    @Override
    protected AcctTypeTfrHeader preCreateValidation(AcctTypeTfrHeader dataObject) {
        AcctTypeTfrHeaderJpe jpe = jaxbSdoHelper.unwrap(dataObject, AcctTypeTfrHeaderJpe.class);
        long mainSeqNo = dataService.nextSequenceValue(ACCT_TYPE_TFR_HEADER_SEQ).longValue();
        long seqNo = 1;
        AcctTypeTfrDetailJpe detailJpe = jpe.getAcctTypeTfrDetailRec();
        detailJpe.setMainSeqNo(mainSeqNo);
        detailJpe.setSeqNo(seqNo);
        detailJpe.setStatus("N");

        jpe.setMainSeqNo(mainSeqNo);
        return super.preCreateValidation(dataObject);
    }

    @Override
    protected AcctTypeTfrHeader preUpdateValidation(AcctTypeTfrHeader dataObject) {
        //TODO: need update xml/api update with child insert is not handled in xml/api
        AcctTypeTfrHeaderJpe jpe = jaxbSdoHelper.unwrap(dataObject, AcctTypeTfrHeaderJpe.class);
        if (dataObject.getAcctTypeTfrDetailRec() != null) {
            Long seqNo = getLastDetailSeqNo(dataObject.getAcctTypeTfrDetailRec());
            AcctTypeTfrDetailJpe detailJpe = jpe.getAcctTypeTfrDetailRec();
            String status = detailJpe.getStatus() != null ? detailJpe.getStatus() : "N";
            detailJpe.setMainSeqNo(jpe.getMainSeqNo());
            if (detailJpe.getSeqNo() == null) {
                detailJpe.setSeqNo(++seqNo);
            }
            detailJpe.setStatus(status);
        }

        return super.preUpdateValidation(dataObject);
    }

    private Number getClientId(String clientNo) {
    	if (StringUtils.isBlank(clientNo)) return null;
    	
		Map<String, Object> params = new HashMap<>();
		params.put("clientNo", clientNo);
		Number clientId = dataService.getWithNamedQuery(MclJpeConstants.CLIENT_JPE_FIND_CLIENT_ID_USING_CLIENT_NO, params,
				Long.class);

		return (clientId != null) ? clientId : null;
	}
    
    
    public AcctTypeTfrHeader validateCreateRequest(AcctTypeTfrHeader dataObject) {
    	
    	String returnCode = depositsValidatorService.isAcctTypeTransferAllowedByAcctTypes(dataObject.getFromAcctType(), dataObject.getToAcctType());
    	return super.validateCreateRequest(dataObject);
    }
    
    public AcctTypeTfrHeader validateUpdateRequest(AcctTypeTfrHeader dataObject) {
    	
    	String returnCode = depositsValidatorService.isAcctTypeTransferAllowedByAcctTypes(dataObject.getFromAcctType(), dataObject.getToAcctType());
    	return super.validateUpdateRequest(dataObject);
    }

    private Long getLastDetailSeqNo(AcctTypeTfrDetail detail){
        List<Long> seqNo = new ArrayList<>();
        if (detail.getSeqNo() != null) {
            seqNo.add(detail.getSeqNo());
        }

        Long lastSeqNo = seqNo.stream().mapToLong(v -> v).max().orElse(new Long(0));
        return lastSeqNo;
    }

}
