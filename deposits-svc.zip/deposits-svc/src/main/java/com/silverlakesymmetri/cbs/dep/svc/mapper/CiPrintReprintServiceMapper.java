package com.silverlakesymmetri.cbs.dep.svc.mapper;

import com.silverlakesymmetri.cbs.commons.jpa.util.DateTimeHelper;
import com.silverlakesymmetri.cbs.commons.xmlapi.enums.CbsXmlApiOperation;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.CiPrintReprint;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.CiPrintReprintJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.CiSettlementJpe;
import com.silverlakesymmetri.cbs.dep.svc.mapper.decorator.CiPrintReprintServiceDecorator;
import com.silverlakesymmetri.cbs.dep.svc.mapper.decorator.CiSettlementBuyServiceDecorator;
import com.silverlakesymmetri.cbs.dep.svc.mapper.mapping.CiPrintReprintToDEPCHQPRINTAPITypeMapper;
import com.silverlakesymmetri.cbs.dep.svc.mapper.mapping.CiSettlementToDEPCIPROCESSSETTLEBUYAPITypeMapper;
import com.silverlakesymmetri.cbs.dep.xmlapi.DEPCHQPRINTAPIType;
import com.silverlakesymmetri.cbs.dep.xmlapi.DEPCIPROCESSSETTLEBUYAPIType;
import org.mapstruct.*;

import java.util.Map;

@Mapper(config= CiPrintReprintToDEPCHQPRINTAPITypeMapper.class, uses={ DateTimeHelper.class})
@DecoratedWith(CiPrintReprintServiceDecorator.class)
public interface CiPrintReprintServiceMapper {

	@InheritConfiguration
	DEPCHQPRINTAPIType mapToApi(CiPrintReprintJpe jpe);

	@InheritInverseConfiguration(name = "mapCiPrintReprintToDEPCHQPRINTAPIType")
	CiPrintReprintJpe mapToJpe(DEPCHQPRINTAPIType api, @MappingTarget CiPrintReprintJpe jpe);
}
