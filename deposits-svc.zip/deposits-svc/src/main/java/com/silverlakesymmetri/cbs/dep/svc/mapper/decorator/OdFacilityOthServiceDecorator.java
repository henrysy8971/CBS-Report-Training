package com.silverlakesymmetri.cbs.dep.svc.mapper.decorator;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

import com.silverlakesymmetri.cbs.commons.xmlapi.enums.CbsXmlApiOperation;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.OdFacilityOthJpe;
import com.silverlakesymmetri.cbs.dep.svc.mapper.OdFacilityOthServiceMapper;
import com.silverlakesymmetri.cbs.dep.xmlapi.DEPODFACILITYAPIType;

public abstract class OdFacilityOthServiceDecorator extends FeeServiceDecorator implements OdFacilityOthServiceMapper {

	@Autowired
	@Qualifier("delegate")
	protected OdFacilityOthServiceMapper delegate;

	@SuppressWarnings("rawtypes")
	@Override
	public DEPODFACILITYAPIType mapToApi(OdFacilityOthJpe jpe, CbsXmlApiOperation oper, Map otherInfo) {
		DEPODFACILITYAPIType req = (DEPODFACILITYAPIType) delegate.mapToApi(jpe, oper, otherInfo);
		if (jpe.getOdGracePeriodPaymt() != null) {
			if (jpe.getOdGracePeriodPaymt().compareTo(0) == 0) {
				req.setODGRACEPERIODPAYMT(null);
			} else {
				req.setODGRACEPERIODPAYMT(jpe.getOdGracePeriodPaymt());
			}
		}
		if (jpe.getOdGracePeriodFee() != null) {
			if (jpe.getOdGracePeriodFee().compareTo(0) == 0) {
				req.setODGRACEPERIODFEE(null);
			} else {
				req.setODGRACEPERIODFEE(jpe.getOdGracePeriodFee());
			}
		}
		if (oper.compareTo(CbsXmlApiOperation.INSERT) == 0) {
			if (jpe.getStatus().equalsIgnoreCase("U")) {
				req.setPURPOSE("C");
			}
		} else if (oper.compareTo(CbsXmlApiOperation.UPDATE) == 0) {
			String verifyRejectInd = jpe.getVerifyRejectInd();
			if (verifyRejectInd == null) {
				req.setPURPOSE("U");
			} else if (verifyRejectInd.equalsIgnoreCase("V")) {
				req.setPURPOSE("V");
			} else if (verifyRejectInd.equalsIgnoreCase("R")) {
				req.setPURPOSE("R");
			} else {
				req.setPURPOSE("U");
			}
		} else if (oper.compareTo(CbsXmlApiOperation.DELETE) == 0) {
			req.setPURPOSE("C");
		}
		mapFeeToApi(jpe, req);
		return req;
	}

	@Override
	public OdFacilityOthJpe mapToJpe(DEPODFACILITYAPIType api, OdFacilityOthJpe jpe) {
		if (jpe == null) {
			jpe = new OdFacilityOthJpe();
		}
		if (api == null) {
			return jpe;
		}
		delegate.mapToJpe(api, jpe);
		return jpe;
	}

}
