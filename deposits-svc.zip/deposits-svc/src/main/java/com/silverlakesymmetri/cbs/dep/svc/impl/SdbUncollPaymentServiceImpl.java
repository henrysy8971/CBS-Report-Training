package com.silverlakesymmetri.cbs.dep.svc.impl;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.mysema.query.types.EntityPath;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.helper.jpa.LinkTable;
import com.silverlakesymmetri.cbs.commons.helper.jpa.QueryCondition;
import com.silverlakesymmetri.cbs.commons.helper.jpa.QueryType;
import com.silverlakesymmetri.cbs.commons.jpa.entity.FindCriteriaJpe;
import com.silverlakesymmetri.cbs.commons.svc.AbstractXmlApiBusinessService;
import com.silverlakesymmetri.cbs.commons.xmlapi.enums.CbsXmlApiOperation;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.SdbAcctHdr;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.QSdbAcctHdrJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.SdbAcctHdrJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.id.SdbAcctHdrPk;
import com.silverlakesymmetri.cbs.dep.svc.SdbUncollPaymentService;
import com.silverlakesymmetri.cbs.dep.svc.mapper.SdbPaymentServiceMapper;
import com.silverlakesymmetri.cbs.dep.xmlapi.DEPSDBPAYMENTAPIType;
import com.silverlakesymmetri.cbs.mcl.jpa.mapping.sdo.ClientJpe;

@Service
@Transactional
public class SdbUncollPaymentServiceImpl extends
		AbstractXmlApiBusinessService<SdbAcctHdr, SdbAcctHdrJpe, SdbAcctHdrPk, DEPSDBPAYMENTAPIType, DEPSDBPAYMENTAPIType>
		implements SdbUncollPaymentService {

	private static LinkedHashMap<String, LinkTable> constructorMap;
	private static QueryCondition condition;

	static {
		constructorMap = new LinkedHashMap<String, LinkTable>();
		constructorMap.put("contractNo", new LinkTable(SdbAcctHdrJpe.class));
		constructorMap.put("clientNo", new LinkTable(ClientJpe.class));
		constructorMap.put("contractDesc", new LinkTable(SdbAcctHdrJpe.class));
		constructorMap.put("clientInd", new LinkTable(SdbAcctHdrJpe.class));
		constructorMap.put("branch", new LinkTable(SdbAcctHdrJpe.class));
		constructorMap.put("boxNo", new LinkTable(SdbAcctHdrJpe.class));
		constructorMap.put("status", new LinkTable(SdbAcctHdrJpe.class));
		constructorMap.put("productCode", new LinkTable(SdbAcctHdrJpe.class));
		constructorMap.put("ccy", new LinkTable(SdbAcctHdrJpe.class));
		constructorMap.put("dateOpen", new LinkTable(SdbAcctHdrJpe.class));
		constructorMap.put("startDate", new LinkTable(SdbAcctHdrJpe.class));
		constructorMap.put("closeDate", new LinkTable(SdbAcctHdrJpe.class));
		constructorMap.put("withLicensees", new LinkTable(SdbAcctHdrJpe.class));
		constructorMap.put("withAssignees", new LinkTable(SdbAcctHdrJpe.class));
		constructorMap.put("depositAcct", new LinkTable(SdbAcctHdrJpe.class));
		constructorMap.put("depositAcctNo", new LinkTable(SdbAcctHdrJpe.class));
		constructorMap.put("depositCertificateNo", new LinkTable(SdbAcctHdrJpe.class));
		constructorMap.put("siAcctNo", new LinkTable(SdbAcctHdrJpe.class));
		constructorMap.put("oldAcctNo", new LinkTable(SdbAcctHdrJpe.class));
		constructorMap.put("oldCertificateNo", new LinkTable(SdbAcctHdrJpe.class));
		condition = new QueryCondition();
		condition.where("clientId", QueryType.EQUALS, new LinkTable(ClientJpe.class, "clientId")).and("clientId",
				QueryType.EQUALS, new LinkTable(SdbAcctHdrJpe.class, "clientId"));
	}

	@Autowired
	SdbPaymentServiceMapper mapper;

	@Override
	protected SdbAcctHdrPk getIdFromDataObjectInstance(SdbAcctHdr dataObject) {
		return new SdbAcctHdrPk(dataObject.getSdbInternalKey());
	}

	@Override
	protected EntityPath<SdbAcctHdrJpe> getEntityPath() {
		return QSdbAcctHdrJpe.sdbAcctHdrJpe;
	}

	@Override
	public SdbAcctHdr create(SdbAcctHdr dataObject) {
		return super.create(dataObject);
	}

	@Override
	public SdbAcctHdr update(SdbAcctHdr dataObject) {
		return super.update(dataObject);
	}

	@Override
	protected DEPSDBPAYMENTAPIType transformBdoToXmlApiRqCreate(SdbAcctHdr dataObject) {
		SdbAcctHdrJpe jpe = jaxbSdoHelper.unwrap(dataObject);
		DEPSDBPAYMENTAPIType xmlApiRq = mapper.mapToApi(jpe, CbsXmlApiOperation.INSERT, new HashMap());
		return xmlApiRq;
	}

	@Override
	protected DEPSDBPAYMENTAPIType transformBdoToXmlApiRqUpdate(SdbAcctHdr dataObject) {
		SdbAcctHdrJpe jpe = jaxbSdoHelper.unwrap(dataObject);
		DEPSDBPAYMENTAPIType xmlApiRq = mapper.mapToApi(jpe, CbsXmlApiOperation.INSERT, new HashMap());
		super.setTechColsFromDataObject(dataObject, xmlApiRq);
		return xmlApiRq;
	}

	@Override
	protected DEPSDBPAYMENTAPIType transformBdoToXmlApiRqDelete(SdbAcctHdr dataObject) {
		return null;
	}

	@Override
	protected SdbAcctHdr processXmlApiRs(SdbAcctHdr dataObject, DEPSDBPAYMENTAPIType xmlApiRs) {
		SdbAcctHdrJpe jpe = jaxbSdoHelper.unwrap(dataObject);
		jpe = mapper.mapToJpe(xmlApiRs, jpe);
		return jaxbSdoHelper.wrap(jpe);
	}

	@Override
	protected List<SdbAcctHdr> processXmlApiListRs(SdbAcctHdr dataObject, DEPSDBPAYMENTAPIType xmlApiRs) {
		return null;
	}

	@Override
	protected Class<DEPSDBPAYMENTAPIType> getXmlApiResponseClass() {
		return DEPSDBPAYMENTAPIType.class;
	}

	@Override
	public SdbAcctHdr getByPk(String publicKey, SdbAcctHdr reference) {
		return super.getByPk(publicKey, reference);
	}

	@Override
	public List<SdbAcctHdr> query(int offset, int resultLimit, String groupBy, String order,
			Map<String, Object> filters) {
		QueryCondition newCondition = convertFilters(condition, filters, constructorMap);
		List<SdbAcctHdr> list = super.query(newCondition, offset, resultLimit, groupBy, order, constructorMap);
		if (list != null && list.size() > 0) {
			for (SdbAcctHdr bdo :list) {
				SdbAcctHdr temp = getByPk(bdo.getContractNo(), bdo);
				if (temp != null) {
					bdo.setUncollSdbFeesList(temp.getUncollSdbFeesList());
					bdo.setDepFeeApplyList(temp.getDepFeeApplyList());
				}
			}
		}
		return list;
	}

	@Override
	public List<SdbAcctHdr> find(FindCriteria findCriteria, CbsHeader cbsHeader) {
		List<SdbAcctHdr> list = super.find(findCriteria, cbsHeader, constructorMap, condition);
		if (list != null && list.size() > 0) {
			for (SdbAcctHdr bdo :list) {
				SdbAcctHdr temp = getByPk(bdo.getContractNo(), bdo);
				if (temp != null) {
					bdo.setUncollSdbFeesList(temp.getUncollSdbFeesList());
					bdo.setDepFeeApplyList(temp.getDepFeeApplyList());
				}
			}
		}
		return list;
	}

	@Override
	public Long count(FindCriteria findCriteria, CbsHeader cbsHeader) {
		FindCriteriaJpe jpe = jaxbSdoHelper.unwrap(findCriteria, FindCriteriaJpe.class);
		return dataService.getRowCount(SdbAcctHdrJpe.class, jpe, constructorMap, condition);
	}

}
