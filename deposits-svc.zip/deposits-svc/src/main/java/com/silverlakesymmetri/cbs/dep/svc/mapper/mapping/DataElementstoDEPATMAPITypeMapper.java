package com.silverlakesymmetri.cbs.dep.svc.mapper.mapping;

import com.silverlakesymmetri.cbs.dep.xmlapi.DEPATMAPIType;
import org.mapstruct.MapperConfig;
import org.mapstruct.Mapping;
import org.mapstruct.Mappings;

import com.silverlakesymmetri.cbs.commons.jpa.util.DateTimeHelper;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.DataElementsJpe;

@MapperConfig(uses={ DateTimeHelper.class})
public interface DataElementstoDEPATMAPITypeMapper {

	@Mappings({
		@Mapping(source="b1", target="b1"),
		@Mapping(source="b2", target="b2"),
		@Mapping(source="b3", target="b3"),
		@Mapping(source="b4", target="b4"),
		@Mapping(source="b6", target="b6"),
		@Mapping(source="b7", target="b7"),
		@Mapping(source="b9", target="b9"),
		@Mapping(source="b11", target="b11"),
		@Mapping(source="b12", target="b12"),
		@Mapping(source="b13", target="b13"),
		@Mapping(source="b14", target="b14"),
		@Mapping(source="b15", target="b15"),
		@Mapping(source="b16", target="b16"),
		@Mapping(source="b18", target="b18"),
		@Mapping(source="b22", target="b22"),
		@Mapping(source="b23", target="b23"),
		@Mapping(source="b24", target="b24"),
		@Mapping(source="b26", target="b26"),
		@Mapping(source="b30", target="b30"),
		@Mapping(source="b32", target="b32"),
		@Mapping(source="b33", target="b33"),
		@Mapping(source="b35", target="b35"),
		@Mapping(source="b36", target="b36"),
		@Mapping(source="b37", target="b37"),
		@Mapping(source="b39", target="b39"),
		@Mapping(source="b41", target="b41"),
		@Mapping(source="b42", target="b42"),
		@Mapping(source="b43", target="b43"),
		@Mapping(source="b44", target="b44"),
		@Mapping(source="b45", target="b45"),
		@Mapping(source="b46", target="b46"),
		@Mapping(source="b47", target="b47"),
		@Mapping(source="b48", target="b48"),
		@Mapping(source="b49", target="b49"),
		@Mapping(source="b50", target="b50"),
		@Mapping(source="b52", target="b52"),
		@Mapping(source="b54", target="b54"),
		@Mapping(source="b93", target="b93"),
		@Mapping(source="b94", target="b94"),
		@Mapping(source="b95", target="b95"),
		@Mapping(source="b100", target="b100"),
		@Mapping(source="b102", target="b102"),
		@Mapping(source="b103", target="b103"),
		@Mapping(source="b104", target="b104"),
		@Mapping(source="b111", target="b111"),
		@Mapping(source="b120", target="b120"),
		@Mapping(source="msgType", target="MSGTYPE")
	 })
	public DEPATMAPIType mapDataElementsToDEPATMAPIType(DataElementsJpe  jpe);
}
