package com.silverlakesymmetri.cbs.dep.svc;

import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation;
import com.silverlakesymmetri.cbs.commons.svc.BusinessService;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.CiAdministrationWrapper;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.CiAdministrationWrapperJpe;

public interface ChequeAdministrationWrapperService extends BusinessService<CiAdministrationWrapper, CiAdministrationWrapperJpe> {

	public static final String SVC_OP_NAME_CIADMINISTRATIONWRAPPERSERVICE_GET = "ChequeAdministrationWrapperService.get";
	public static final String SVC_OP_NAME_CIADMINISTRATIONWRAPPERSERVICE_UPDATE = "ChequeAdministrationWrapperService.update";
	
	@ServiceOperation(name = SVC_OP_NAME_CIADMINISTRATIONWRAPPERSERVICE_GET, type = ServiceOperation.ServiceOperationType.GET)
    public CiAdministrationWrapper getByPk(String publicKey, CiAdministrationWrapper reference);
	
	@ServiceOperation(name = SVC_OP_NAME_CIADMINISTRATIONWRAPPERSERVICE_UPDATE)
    public CiAdministrationWrapper update(CiAdministrationWrapper dataObject);
	
}
