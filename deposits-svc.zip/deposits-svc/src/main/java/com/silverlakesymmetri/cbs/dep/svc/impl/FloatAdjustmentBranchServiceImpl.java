package com.silverlakesymmetri.cbs.dep.svc.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.mysema.query.types.EntityPath;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.svc.AbstractBusinessService;
import com.silverlakesymmetri.cbs.commons.util.CurrentTenantResolver;
import com.silverlakesymmetri.cbs.csd.jpa.mapping.sdo.BranchJpe;
import com.silverlakesymmetri.cbs.csd.jpa.mapping.sdo.id.BranchPk;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.FloatAdjustmentBranch;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.TranHist;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.FloatAdjustmentBranchJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.QFloatAdjustmentBranchJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.TranHistJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.id.FloatAdjustmentBranchPk;
import com.silverlakesymmetri.cbs.dep.svc.FloatAdjustmentBranchService;
import com.silverlakesymmetri.cbs.dep.svc.FloatRolldownService;

@Service
@Transactional
public class FloatAdjustmentBranchServiceImpl extends AbstractBusinessService<FloatAdjustmentBranch, FloatAdjustmentBranchJpe, FloatAdjustmentBranchPk> implements FloatAdjustmentBranchService {

	@Autowired
    protected CurrentTenantResolver<Integer> currentTenantResolver;
	
	@Autowired
	protected FloatRolldownService floatRolldownService;
	
	@Override
	protected FloatAdjustmentBranchPk getIdFromDataObjectInstance(FloatAdjustmentBranch dataObject) {
		return new FloatAdjustmentBranchPk(dataObject.getBranch(), dataObject.getCcy(), dataObject.getFloatDays());
	}

	@Override
	protected EntityPath<FloatAdjustmentBranchJpe> getEntityPath() {
		return QFloatAdjustmentBranchJpe.floatAdjustmentBranchJpe;
	}

	@Override
	public FloatAdjustmentBranch get(FloatAdjustmentBranch objectInstanceIdentifier) {
		return super.get(objectInstanceIdentifier);
	}

	@Override
	public FloatAdjustmentBranch getByPk(String publicKey, FloatAdjustmentBranch reference) {
		FloatAdjustmentBranch bdo = super.getByPk(publicKey, reference);
		
		BranchPk branchPk = new BranchPk(bdo.getBranch());
		BranchJpe branchJpe = dataService.find(BranchJpe.class, branchPk);
		bdo.setBranchDesc(branchJpe.getBranchDesc());
		
		return bdo;
	}

	@Override
	public FloatAdjustmentBranch create(FloatAdjustmentBranch dataObject) {
		return super.create(dataObject);
	}

	@Override
	public FloatAdjustmentBranch update(FloatAdjustmentBranch dataObject) {
		return super.update(dataObject);
	}

	@Override
	public boolean delete(FloatAdjustmentBranch dataObject) {
		return super.delete(dataObject);
	}

	@Override
	public List<FloatAdjustmentBranch> query(int offset, int resultLimit, String groupBy, String order,
			Map<String, Object> filters) {
		List<FloatAdjustmentBranch> bdoList = super.query(offset, resultLimit, groupBy, order, filters);

		if (bdoList != null) {
			for (int i=0; i < bdoList.size(); i++) {
				BranchPk branchPk = new BranchPk(bdoList.get(i).getBranch());
				BranchJpe branchJpe = dataService.find(BranchJpe.class, branchPk);
				bdoList.get(i).setBranchDesc(branchJpe.getBranchDesc());
			}
		}
		
		return bdoList;
	}

	@Override
	public List<FloatAdjustmentBranch> find(FindCriteria findCriteria, CbsHeader cbsHeader) {
		return super.find(findCriteria, cbsHeader);
	}
	
	@Override
	public FloatAdjustmentBranch processFloatAdj(FloatAdjustmentBranch dataObject) {
		return floatRolldownService.processFloatAdj(dataObject);
	}

}
