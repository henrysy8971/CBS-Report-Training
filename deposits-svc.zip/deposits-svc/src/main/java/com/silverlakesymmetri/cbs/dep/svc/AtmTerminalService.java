package com.silverlakesymmetri.cbs.dep.svc;

import java.util.List;
import java.util.Map;

import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation;
import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation.ServiceOperationType;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.svc.BusinessService;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.AtmTerminal;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.AtmTerminalJpe;

public interface AtmTerminalService extends BusinessService<AtmTerminal, AtmTerminalJpe> {
	public static final String SVC_OP_NAME_ATMTERMINALSERVICE_CREATE = "AtmTerminalService.create";
	public static final String SVC_OP_NAME_ATMTERMINALSERVICE_UPDATE = "AtmTerminalService.update";
	public static final String SVC_OP_NAME_ATMTERMINALSERVICE_DELETE = "AtmTerminalService.delete";
	public static final String SVC_OP_NAME_ATMTERMINALSERVICE_QUERY = "AtmTerminalService.query";
	public static final String SVC_OP_NAME_ATMTERMINALSERVICE_FIND = "AtmTerminalService.find";
	public static final String SVC_OP_NAME_ATMTERMINALSERVICE_GET = "AtmTerminalService.get";

	@ServiceOperation(name = SVC_OP_NAME_ATMTERMINALSERVICE_CREATE)
	public AtmTerminal create(AtmTerminal dataObject);

	@ServiceOperation(name = SVC_OP_NAME_ATMTERMINALSERVICE_UPDATE)
	public AtmTerminal update(AtmTerminal dataObject);

	@ServiceOperation(name = SVC_OP_NAME_ATMTERMINALSERVICE_DELETE)
	public boolean delete(AtmTerminal dataObject);

	@ServiceOperation(name = SVC_OP_NAME_ATMTERMINALSERVICE_QUERY)
	public List<AtmTerminal> query(int offset, int resultLimit, String groupBy, String order,
			Map<String, Object> filters);

	@ServiceOperation(name = SVC_OP_NAME_ATMTERMINALSERVICE_FIND)
	public List<AtmTerminal> find(FindCriteria findCriteria, CbsHeader cbsHeader);

	@ServiceOperation(name = SVC_OP_NAME_ATMTERMINALSERVICE_GET, type = ServiceOperationType.GET)
	public AtmTerminal getByPk(String publicKey, AtmTerminal reference);

}
