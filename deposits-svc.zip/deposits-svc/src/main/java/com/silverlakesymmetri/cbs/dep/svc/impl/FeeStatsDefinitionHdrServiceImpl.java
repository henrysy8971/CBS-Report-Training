package com.silverlakesymmetri.cbs.dep.svc.impl;

import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;

import com.mysema.query.types.EntityPath;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.svc.AbstractBusinessService;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.FeeStatsDefinitionDtl;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.FeeStatsDefinitionHdr;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.FeeStatsDefinitionHdrJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.QFeeStatsDefinitionHdrJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.TranDefJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.id.FeeStatsDefinitionHdrPk;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.id.TranDefPk;
import com.silverlakesymmetri.cbs.dep.svc.FeeStatsDefinitionHdrService;

@Service
public class FeeStatsDefinitionHdrServiceImpl extends AbstractBusinessService<FeeStatsDefinitionHdr, FeeStatsDefinitionHdrJpe, FeeStatsDefinitionHdrPk> implements FeeStatsDefinitionHdrService {
    
    @Override
	protected FeeStatsDefinitionHdrPk getIdFromDataObjectInstance(FeeStatsDefinitionHdr dataObject) {
		return new FeeStatsDefinitionHdrPk(dataObject.getStatID());
	}

	@Override
	protected EntityPath<FeeStatsDefinitionHdrJpe> getEntityPath() {
		return QFeeStatsDefinitionHdrJpe.feeStatsDefinitionHdrJpe;
	}
	
    @Override
    public List<FeeStatsDefinitionHdr> query(int offset, int resultLimit, String groupBy, String order, Map<String, Object> filters) {
        return super.query(offset, resultLimit, groupBy, order, filters);
    }

    @Override
    public FeeStatsDefinitionHdr get(FeeStatsDefinitionHdr objectInstanceIdentifier) {
        return super.get(objectInstanceIdentifier);
    }
    
    @Override
	public FeeStatsDefinitionHdr getByPk(String publicKey, FeeStatsDefinitionHdr reference) {
    	FeeStatsDefinitionHdr result = super.getByPk(publicKey, reference);
    	setDtlTransiendFields(result);
    	return result;
	}

	private void setDtlTransiendFields(FeeStatsDefinitionHdr result) {
		if (result != null && !result.getFeeStatsDefinitionDtlList().isEmpty()) {
			for (FeeStatsDefinitionDtl dtl : result.getFeeStatsDefinitionDtlList()) {
				if (StringUtils.isNotBlank(dtl.getTranType())) {
					TranDefJpe tranDefJpe = dataService.find(TranDefJpe.class, new TranDefPk(dtl.getTranType()));
					dtl.setTranDesc(tranDefJpe.getTranDesc());
					dtl.setCrDrInd(tranDefJpe.getCrDrMaintInd());
				}
			}
		}
	}

	@Override
	public FeeStatsDefinitionHdr create(FeeStatsDefinitionHdr dataObject) {
		return super.create(dataObject);
	}

	@Override
	public FeeStatsDefinitionHdr update(FeeStatsDefinitionHdr dataObject) {
		return super.update(dataObject);
	}

	@Override
	public boolean delete(FeeStatsDefinitionHdr dataObject) {
		return super.delete(dataObject);
	}

	@Override
    public List<FeeStatsDefinitionHdr> find(FindCriteria findCriteria, CbsHeader cbsHeader) {
        return super.find(findCriteria, cbsHeader);
    }

	@Override
	protected FeeStatsDefinitionHdr preCreateValidation(FeeStatsDefinitionHdr dataObject) {
		defaultFields(dataObject);
		return super.preCreateValidation(dataObject);
	}

	@Override
	protected FeeStatsDefinitionHdr preUpdateValidation(FeeStatsDefinitionHdr dataObject) {
		defaultFields(dataObject);
		return super.preUpdateValidation(dataObject);
	}
	
	private void defaultFields(FeeStatsDefinitionHdr dataObject) {
		FeeStatsDefinitionHdrJpe jpe = jaxbSdoHelper.unwrap(dataObject);
		if (StringUtils.isBlank(jpe.getEarlyEodPrev())) {
			jpe.setEarlyEodPrev("N");
		}
	}
}

