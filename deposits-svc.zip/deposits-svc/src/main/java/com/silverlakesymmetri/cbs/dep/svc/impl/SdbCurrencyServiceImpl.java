package com.silverlakesymmetri.cbs.dep.svc.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.mysema.query.types.EntityPath;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.svc.AbstractBusinessService;
import com.silverlakesymmetri.cbs.csd.bdo.sdo.Branch;
import com.silverlakesymmetri.cbs.csd.bdo.sdo.Currency;
import com.silverlakesymmetri.cbs.csd.jpa.mapping.sdo.BranchJpe;
import com.silverlakesymmetri.cbs.csd.jpa.mapping.sdo.CurrencyJpe;
import com.silverlakesymmetri.cbs.csd.jpa.mapping.sdo.QCurrencyJpe;
import com.silverlakesymmetri.cbs.csd.jpa.mapping.sdo.id.CurrencyPk;
import com.silverlakesymmetri.cbs.dep.svc.SdbCurrencyService;

@Service
@Transactional
public class SdbCurrencyServiceImpl extends AbstractBusinessService<Currency, CurrencyJpe, CurrencyPk> implements SdbCurrencyService {

	
	@Override
    public Currency getByPk(String publicKey, Currency reference) {
        return super.getByPk(publicKey, reference);
    }
	
	private static final String SDB_CURRENCY_LOV = "SELECT  DISTINCT ccy"
			+ " FROM CurrencyJpe ccy"
			+ " INNER JOIN SdbTypeJpe st"
			+ "   ON (ccy.ccy = st.ccy)"
			+ " WHERE 1=1 AND ccy.ccy like :ccy AND ccy.activeYn = true";

	
    @Override
    public List<Currency> query(int offset, int resultLimit, String groupBy, String order, Map<String, Object> filters) {
    	
    	if (filters == null){
    		filters = new HashMap<String, Object>();
    	}
    		
    	if (!filters.containsKey("ccy")){
    		filters.put("ccy", "%");
    	}
   
    	List<CurrencyJpe> jpeList = (List<CurrencyJpe>) dataService.findWithQuery(SDB_CURRENCY_LOV, filters, offset, resultLimit, CurrencyJpe.class);
    	        
        List<Currency> retList = new ArrayList<>();
		if (jpeList != null && jpeList.size() > 0) {
			for(CurrencyJpe jpe: jpeList){
				retList.add(jaxbSdoHelper.wrap(jpe, Currency.class));				
			}
		}
		
		return retList;    	
    }

    @Override
    public List<Currency> find(FindCriteria findCriteria, CbsHeader cbsHeader) {
        return super.find(findCriteria, cbsHeader);
    }


	@Override
	protected CurrencyPk getIdFromDataObjectInstance(Currency dataObject) {
		// TODO Auto-generated method stub
		return new CurrencyPk(dataObject.getCcy());
	}

	@Override
	protected EntityPath<CurrencyJpe> getEntityPath() {
		// TODO Auto-generated method stub
		return QCurrencyJpe.currencyJpe;
	}
	
}
