package com.silverlakesymmetri.cbs.dep.svc.mapper;

import com.silverlakesymmetri.cbs.commons.jpa.util.DateTimeHelper;
import com.silverlakesymmetri.cbs.commons.xmlapi.enums.CbsXmlApiOperation;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.CashMngtJpe;
import com.silverlakesymmetri.cbs.dep.svc.mapper.mapping.CashMngtToDEPCASHMNGTAPITypeMapper;
import com.silverlakesymmetri.cbs.dep.xmlapi.DEPCASHMNGTAPIType;
import org.mapstruct.*;

@Mapper(config = CashMngtToDEPCASHMNGTAPITypeMapper.class, uses = { DateTimeHelper.class })
public interface CashMngtServiceMapper {

    @Mappings({
        @Mapping(expression = "java(oper != null ? oper.getOperation() : null)", target = "OPERATION")
    })
    @InheritConfiguration
    DEPCASHMNGTAPIType mapToApi(CashMngtJpe jpe, @Context CbsXmlApiOperation oper);

    @Mappings({
            @Mapping(source = "TRANDATE", target = "tranDate", qualifiedByName = { "DateTimeHelper", "convertCbsApiDateToString" }),
            @Mapping(source = "EFFECTDATE", target = "effectDate", qualifiedByName = { "DateTimeHelper", "convertCbsApiDateToString" }),
    })
    @InheritInverseConfiguration(name = "mapCashMngtToDEPCASHMNGTAPIType")
    CashMngtJpe mapToJpe(DEPCASHMNGTAPIType api, @MappingTarget CashMngtJpe jpe);

}