package com.silverlakesymmetri.cbs.dep.svc;

import java.util.List;
import java.util.Map;

import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation;
import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation.ServiceOperationType;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.svc.BusinessService;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.GlCodeTfr;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.GlCodeTfrJpe;

public interface GlCodeTfrService extends BusinessService<GlCodeTfr, GlCodeTfrJpe> {
	public static final String SVC_OP_NAME_GLCODETFRSERVICE_GET = "GlCodeTfrService.get";
	public static final String SVC_OP_NAME_GLCODETFRSERVICE_QUERY = "GlCodeTfrService.query";
	public static final String SVC_OP_NAME_GLCODETFRSERVICE_CREATE = "GlCodeTfrService.create";
	public static final String SVC_OP_NAME_GLCODETFRSERVICE_UPDATE = "GlCodeTfrService.update";
	public static final String SVC_OP_NAME_GLCODETFRSERVICE_DELETE = "GlCodeTfrService.delete";
	public static final String SVC_OP_NAME_GLCODETFRSERVICE_FIND = "GlCodeTfrService.find";

	@ServiceOperation(name = SVC_OP_NAME_GLCODETFRSERVICE_CREATE)
	public GlCodeTfr create(GlCodeTfr dataObject);

	@ServiceOperation(name = SVC_OP_NAME_GLCODETFRSERVICE_UPDATE)
	public GlCodeTfr update(GlCodeTfr dataObject);

	@ServiceOperation(name = SVC_OP_NAME_GLCODETFRSERVICE_DELETE)
	public boolean delete(GlCodeTfr dataObject);

	@ServiceOperation(name = SVC_OP_NAME_GLCODETFRSERVICE_QUERY)
	public List<GlCodeTfr> query(int offset, int resultLimit, String groupBy, String order,
			Map<String, Object> filters);

	@ServiceOperation(name = SVC_OP_NAME_GLCODETFRSERVICE_FIND)
	public List<GlCodeTfr> find(FindCriteria findCriteria, CbsHeader cbsHeader);

	@ServiceOperation(name = SVC_OP_NAME_GLCODETFRSERVICE_GET, type = ServiceOperationType.GET)
	public GlCodeTfr getByPk(String publicKey, GlCodeTfr reference);

}
