package com.silverlakesymmetri.cbs.dep.svc.mapper;

import java.util.Map;

import org.mapstruct.Context;
import org.mapstruct.DecoratedWith;
import org.mapstruct.InheritConfiguration;
import org.mapstruct.InheritInverseConfiguration;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingTarget;
import org.mapstruct.Mappings;

import com.silverlakesymmetri.cbs.commons.jpa.util.DateTimeHelper;
import com.silverlakesymmetri.cbs.commons.xmlapi.enums.CbsXmlApiOperation;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.ChequeCtrlJpe;
import com.silverlakesymmetri.cbs.dep.svc.mapper.decorator.ChequeCtrlServiceDecorator;
import com.silverlakesymmetri.cbs.dep.svc.mapper.mapping.ChequeCtrlToDEPCHQBKRQSTAPITypeMapper;
import com.silverlakesymmetri.cbs.dep.xmlapi.DEPCHQBKRQSTAPIType;

@Mapper(config = ChequeCtrlToDEPCHQBKRQSTAPITypeMapper.class, uses = { DateTimeHelper.class })
@DecoratedWith(ChequeCtrlServiceDecorator.class)
public interface ChequeCtrlServiceMapper {

	@Mappings({ @Mapping(expression = "java(oper != null ? oper.getOperation() : null)", target = "OPERATION") })
	@InheritConfiguration
	public DEPCHQBKRQSTAPIType mapToApi(ChequeCtrlJpe jpe, @Context CbsXmlApiOperation oper, @Context Map otherInfo);

	@Mappings({
		@Mapping(source = "ISSUEDATE", target = "issueDate", qualifiedByName = { "DateTimeHelper", "convertCbsApiDateToString" })
	})
	@InheritInverseConfiguration(name = "mapChequeCtrlToDEPCHQBKRQSTAPIType")
	public ChequeCtrlJpe mapToJpe(DEPCHQBKRQSTAPIType api, @MappingTarget ChequeCtrlJpe jpe);

}
