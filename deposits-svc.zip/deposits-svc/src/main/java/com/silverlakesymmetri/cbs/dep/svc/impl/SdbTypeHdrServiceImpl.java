package com.silverlakesymmetri.cbs.dep.svc.impl;

import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.mysema.query.types.EntityPath;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.svc.AbstractBusinessService;
import com.silverlakesymmetri.cbs.commons.svc.ref.ReferenceNumberGeneratorService;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.SdbType;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.SdbTypeHdr;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.QSdbTypeHdrJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.SdbTypeHdrJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.id.SdbTypeHdrPk;
import com.silverlakesymmetri.cbs.dep.svc.SdbTypeHdrService;

@Service
@Transactional
public class SdbTypeHdrServiceImpl extends AbstractBusinessService<SdbTypeHdr, SdbTypeHdrJpe, SdbTypeHdrPk> implements SdbTypeHdrService {

	@Autowired
    private ReferenceNumberGeneratorService referenceNumberGeneratorService;

	@Override
	protected EntityPath<SdbTypeHdrJpe> getEntityPath() {
		return QSdbTypeHdrJpe.sdbTypeHdrJpe;
	}

	@Override
	protected SdbTypeHdrPk getIdFromDataObjectInstance(SdbTypeHdr dataObject) {
		SdbTypeHdrPk pk = new SdbTypeHdrPk(dataObject.getBranch(), dataObject.getBoxType(), dataObject.getCcy());
		return pk;
	}
	
	@Override
	public SdbTypeHdr create(SdbTypeHdr dataObject) {
		return super.create(dataObject);
	}
	
	@Override
	public SdbTypeHdr get(SdbTypeHdr objectInstanceIdentifier) {
		return super.get(objectInstanceIdentifier);
	}

	@Override
	public List<SdbTypeHdr> query(int offset, int resultLimit, String groupBy, String order,
			Map<String, Object> filters) {
		return super.query(offset, resultLimit, groupBy, order, filters);
	}

	@Override
	public SdbTypeHdr update(SdbTypeHdr dataObject) {
		return super.update(dataObject);
	}

	@Override
	public boolean delete(SdbTypeHdr dataObject) {
		return super.delete(dataObject);
	}

	@Override
	public List<SdbTypeHdr> find(FindCriteria findCriteria, CbsHeader cbsHeader) {
		return super.find(findCriteria, cbsHeader);
	}

	@Override
	public SdbTypeHdr getByPk(String publicKey, SdbTypeHdr reference) {
		return super.getByPk(publicKey, reference);
	}

	@Override
	public SdbTypeHdr preCreateValidation(SdbTypeHdr dataObject) {
		for (SdbType subType : dataObject.getSdbTypeList()) {
			if (StringUtils.isBlank(subType.getSdbTypeDtlRefNo())) {
				referenceNumberGeneratorService.getNewRefNo(subType, "sdbTypeDtlRefNo");
			}
		}
		return super.preCreateValidation(dataObject);
	}

}
