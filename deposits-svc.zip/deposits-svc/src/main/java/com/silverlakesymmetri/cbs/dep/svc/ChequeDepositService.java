package com.silverlakesymmetri.cbs.dep.svc;

import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation;
import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation.ServiceOperationType;
import com.silverlakesymmetri.cbs.commons.svc.BusinessService;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.DepositTransaction;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.DepositTransactionJpe;

public interface ChequeDepositService extends BusinessService<DepositTransaction, DepositTransactionJpe> {


    public static final String SVC_OP_NAME_CHEQUEDEPOSITSERVICE_POSTTRANSACTION = "ChequeDepositService.postTransaction";
    public static final String SVC_OP_NAME_CHEQUEDEPOSITSERVICE_GET = "ChequeDepositService.get";

    @ServiceOperation(name = SVC_OP_NAME_CHEQUEDEPOSITSERVICE_POSTTRANSACTION, type = ServiceOperationType.CREATE)
    public DepositTransaction postTransaction(DepositTransaction dataObject);

	@ServiceOperation(name = SVC_OP_NAME_CHEQUEDEPOSITSERVICE_GET, type = ServiceOperationType.GET)
    public DepositTransaction getByPk(String publicKey, DepositTransaction reference);

}
