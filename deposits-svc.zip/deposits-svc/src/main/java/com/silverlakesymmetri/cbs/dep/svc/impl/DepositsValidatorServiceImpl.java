package com.silverlakesymmetri.cbs.dep.svc.impl;

import com.google.common.collect.ImmutableMap;
import com.silverlakesymmetri.cbs.commons.exception.base.dto.ValidationDto;
import com.silverlakesymmetri.cbs.commons.exception.base.helper.ExceptionHelper;
import com.silverlakesymmetri.cbs.commons.jpa.service.CbsGenericDataService;
import com.silverlakesymmetri.cbs.commons.util.CbsErrorCodePrefixFactory;
import com.silverlakesymmetri.cbs.commons.util.MessageUtils;
import com.silverlakesymmetri.cbs.commons.xmlapi.rs.CUTERRORFUNCTIONALType;
import com.silverlakesymmetri.cbs.commons.xmlapi.rs.CUTERRORLISTType;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.AcctJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.util.DepJpeConstants;
import com.silverlakesymmetri.cbs.dep.svc.DepositsValidatorService;
import com.silverlakesymmetri.cbs.dep.svc.util.DepValidatorApiHelper;
import org.hibernate.validator.internal.engine.path.PathImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.NoSuchMessageException;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Map;

/**
 * 
 * @author Xtian
 *
 */
@Service
public class DepositsValidatorServiceImpl implements DepositsValidatorService {
	
	@Autowired(required = true)
    @Qualifier("cbsGenericDataService")
    protected CbsGenericDataService dataService;
  
    @Autowired
    private DepValidatorApiHelper depValidatorApiHelper;
    
    @Autowired
    protected MessageUtils messageUtils;
    
    private static final String DEP_ACCT_TYPE_TRANSFER = "DEP_ACCT_TYPE_TRANSFER";
    private static final String DEP_ACCT_FIN_TRANSFER = "DEP_ACCT_FIN_TRANSFER";
      
    @Override
    public String isAcctTypeTransferAllowedByAcctTypes(String fromAcctType, String toAcctType){
    	
    	return isAcctTypeTransferAllowedByAcctTypes(DEP_ACCT_TYPE_TRANSFER, fromAcctType, toAcctType);
    }
    
    @Override
    public String isAcctTypeTransferAllowedByAcctNos(String fromAcctNo, String toAcctNo){
    	
    	
    	Map<String, Object> params = new ImmutableMap.Builder<String, Object>().put("acctNo", fromAcctNo).build();
        AcctJpe fromAcct = dataService.getWithNamedQuery(DepJpeConstants.ACCT_JPE_FIND_BY_ACCTNO, params, AcctJpe.class);
        
        params = new ImmutableMap.Builder<String, Object>().put("acctNo", toAcctNo).build();
        AcctJpe toAcct = dataService.getWithNamedQuery(DepJpeConstants.ACCT_JPE_FIND_BY_ACCTNO, params, AcctJpe.class);
    	
    	return isAcctTypeTransferAllowedByAcctTypes(DEP_ACCT_TYPE_TRANSFER, fromAcct.getAcctType(), toAcct.getAcctType());
    }
    
    public String isFinancialTransferAllowedByAcctTypes(String fromAcctType, String toAcctType){
    	
    	return isAcctTypeTransferAllowedByAcctTypes(DEP_ACCT_FIN_TRANSFER, fromAcctType, toAcctType);
    }
	
    public String isFinancialTransferAllowedByAcctNos(String fromAcctNo, String toAcctNo){
    	
    	Map<String, Object> params = new ImmutableMap.Builder<String, Object>().put("acctNo", fromAcctNo).build();
        AcctJpe fromAcct = dataService.getWithNamedQuery(DepJpeConstants.ACCT_JPE_FIND_BY_ACCTNO, params,
                AcctJpe.class);
        
        params = new ImmutableMap.Builder<String, Object>().put("acctNo", toAcctNo).build();
        AcctJpe toAcct = dataService.getWithNamedQuery(DepJpeConstants.ACCT_JPE_FIND_BY_ACCTNO, params,
                AcctJpe.class);
    
    	return isAcctTypeTransferAllowedByAcctTypes(DEP_ACCT_FIN_TRANSFER, fromAcct.getAcctType(), toAcct.getAcctType());
    }
    
    private String isAcctTypeTransferAllowedByAcctTypes(String reference, String fromAcctType, String toAcctType){
    	
    	boolean islamicCheck = true;
    	if (!islamicCheck){
    		return "000";
    	}
    	
    	CUTERRORLISTType error = depValidatorApiHelper.doValidate(reference, fromAcctType, toAcctType);
    	if (error == null || 
    			((error.getFunctionalErrorList() == null || error.getFunctionalErrorList().isEmpty()) && 
    			 (error.getSystemErrorList() == null || error.getSystemErrorList().isEmpty()))){
    		return "000";
    	}
    	
    	//this will throw an exception if transaction is not allowed
    	this.generateExceptions(error.getFunctionalErrorList());
    	return "999";
    } 
    
    private void generateExceptions(List<CUTERRORFUNCTIONALType> functionalErrorList ){
    	
    	Collection<ValidationDto> validators = new ArrayList<ValidationDto>();
    	for (CUTERRORFUNCTIONALType type : functionalErrorList){
    		processErrors(null, validators, type.getCODE(), null, type.getMESSAGE(), type.getATTRIBUTENAME());	
//    		ValidationDto dto =  new ValidationDto();
//    		try {
//    			dto.setCode(new StringBuilder("CBS.B.DEP.").append(Long.toString(fe.getCODE())).toString());
//    			dto.setMessage(messageUtils.getMessage(dto.getCode()));
//    		} 
//    		catch (NoSuchMessageException e) {}
//    		validators.add(dto);
    	}			
		ExceptionHelper.generateExceptions(validators, null, true, null, null);
	}
    
    private void processErrors(String errorCodePrefix, Collection<ValidationDto> validators,
			double code, String who, String xmlApiErrMsg, String otherMsg) {
		Number codeNum = code;
		ValidationDto dto =  new ValidationDto();
		if (errorCodePrefix == null) {
			//errorCodePrefix = defaultErrorCodePrefix(code);
			errorCodePrefix = CbsErrorCodePrefixFactory.errorCode(code);
		}
		
		dto.setCode(errorCodePrefix + codeNum.longValue());
		String msg = null;
		try {
			msg = messageUtils.getMessage(dto.getCode(), new Object[] { xmlApiErrMsg, otherMsg });
		} catch (NoSuchMessageException e) {
			dto.setCode("" + codeNum.longValue());
		}
		StringBuilder sb = new StringBuilder();
		if (who != null) {
			sb.append(who).append(": ");
			PathImpl path = PathImpl.createPathFromString(who);
			if (otherMsg != null) {
				//path.addNode(otherMsg);
				path.addPropertyNode(otherMsg);
			}
			dto.setPropertyPath(path);
		}
		if (msg != null) {
			sb.append(msg);
		} else if (xmlApiErrMsg != null) {
			boolean enclose = false;
			if (sb.length() > 0) {
				enclose = true;
			}
			if (enclose) {
				sb.append(". (Error Message: ");
			}
			sb.append(xmlApiErrMsg);
			if (enclose) {
				sb.append(")");
			}
		}
		
		dto.setMessage(sb.toString());
		validators.add(dto);
	}
}
