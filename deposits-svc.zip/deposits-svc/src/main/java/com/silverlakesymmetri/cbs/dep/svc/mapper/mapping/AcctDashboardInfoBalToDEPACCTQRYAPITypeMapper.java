package com.silverlakesymmetri.cbs.dep.svc.mapper.mapping;

import org.mapstruct.MapperConfig;
import org.mapstruct.Mapping;
import org.mapstruct.Mappings;

import com.silverlakesymmetri.cbs.commons.jpa.util.DateTimeHelper;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.AcctDashboardInfoBalJpe;
import com.silverlakesymmetri.cbs.dep.xmlapi.DEPACCTQRYAPIType;

@MapperConfig(uses={ DateTimeHelper.class})
public interface AcctDashboardInfoBalToDEPACCTQRYAPITypeMapper {
	
	@Mappings({
		
//		@Mapping(source = "internalKey", target="INTERNALKEY"),
		@Mapping(source = "acctNo", target="ACCTNO"),
		@Mapping(source = "certificateNo", target="CERTIFICATENO"),
		@Mapping(source = "acctDesc", target="ACCTDESC"),
		@Mapping(source = "clientNo", target="CLIENTNO"),
//		@Mapping(source = "clientId", target="CLIENTNO"),
		@Mapping(source = "clientShort", target="CLIENTSHORT"),
		@Mapping(source = "globalIdType", target="GLOBALIDTYPE"),
		@Mapping(source = "globalId", target="GLOBALID"),
		@Mapping(source = "branch", target="BRANCH"),
		@Mapping(source = "acctType", target="ACCTTYPE"),
		@Mapping(source = "ccy", target="ACCTCCY"),
		@Mapping(source = "acctStatus", target="ACCTSTATUS"),
		@Mapping(source = "acctStatusDesc", target="ACCTSTATUSDESC"),
		@Mapping(source = "ledgerBal", target="LEDGERBAL"),
		@Mapping(source = "actualBal", target="ACTUALBAL"),
		@Mapping(source = "availBal", target="ACCTAVAILBAL"),
		@Mapping(source = "principalAmt", target="PRINCIPALAMOUNT"),
		@Mapping(source = "reclassType", target="RECLASSTYPE"),
		@Mapping(source = "doubtfulStatus", target="DOUBTFULSTATUS"),
		@Mapping(source = "noExpiredDays", target="NOEXPIREDDAYS"),
		@Mapping(source = "fundsHeld", target="TOTALPLEDGEDAMT"),
		@Mapping(source = "odLimit", target="TOTALAUTHOD"),
		@Mapping(source = "toleranceAmt", target="TOLERANCEAMT"),
		@Mapping(source = "indCpgAvailBal", target="ACCTCPGAVAILBAL"),
		@Mapping(source = "totalFutureTranCr", target="TOTALCRFUTURETRANAMT"),
		@Mapping(source = "totalFutureTranDr", target="TOTALDRFUTURETRANAMT"),
		@Mapping(source = "avgDailyBal", target="AVGDAILYBAL"),
		@Mapping(source = "depositType", target="DEPOSITTYPE"),
		@Mapping(source = "floats", target="TOTALFLOATSAMT"),
		@Mapping(source = "uncollFees", target="UNCOLLFEES"),
		@Mapping(source = "batchFees", target="BATCHFEESOS"),
	})
	//TODO: to be refactored should use the jpe class not the bdo
	public DEPACCTQRYAPIType mapAcctDashboardInfoBalToDEPACCTQRYAPIType(AcctDashboardInfoBalJpe jpe);
		
}

