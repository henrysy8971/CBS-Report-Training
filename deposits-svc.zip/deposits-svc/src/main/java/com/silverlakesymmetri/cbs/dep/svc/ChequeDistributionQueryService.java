package com.silverlakesymmetri.cbs.dep.svc;

import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation;
import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation.ServiceOperationType;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.svc.BusinessService;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.CiRdBunchDistQry;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.CiRdBunchDistQryJpe;

import java.util.List;
import java.util.Map;

public interface ChequeDistributionQueryService extends BusinessService<CiRdBunchDistQry, CiRdBunchDistQryJpe> {
	
	public static final String SVC_OP_NAME_CHEQUEDISTRIBUTIONQUERYSERVICE_GET 	= "ChequeDistributionQueryService.get";
    public static final String SVC_OP_NAME_CHEQUEDISTRIBUTIONQUERYSERVICE_QUERY 	= "ChequeDistributionQueryService.query";
    public static final String SVC_OP_NAME_CHEQUEDISTRIBUTIONQUERYSERVICE_FIND 	= "ChequeDistributionQueryService.find";
    
    @ServiceOperation(name = SVC_OP_NAME_CHEQUEDISTRIBUTIONQUERYSERVICE_GET, type = ServiceOperationType.GET)
    public CiRdBunchDistQry getByPk(String publicKey, CiRdBunchDistQry reference);

    @ServiceOperation(name = SVC_OP_NAME_CHEQUEDISTRIBUTIONQUERYSERVICE_QUERY)
    public List<CiRdBunchDistQry> query(int offset, int resultLimit, String groupBy, String order, Map<String, Object> filters);

    @ServiceOperation(name = SVC_OP_NAME_CHEQUEDISTRIBUTIONQUERYSERVICE_FIND)
    public List<CiRdBunchDistQry> find(FindCriteria findCriteria, CbsHeader cbsHeader);
		
}
