package com.silverlakesymmetri.cbs.dep.svc.mapper.mapping;

import org.mapstruct.MapperConfig;
import org.mapstruct.Mapping;
import org.mapstruct.Mappings;

import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.SdbAcctHdrJpe;
import com.silverlakesymmetri.cbs.dep.xmlapi.DEPSDBPAYMENTAPIType;

@MapperConfig
public interface SdbAcctHdrJpeToDEPSDBPAYMENTAPITypeMapper {

	@Mappings({
		@Mapping(source="contractNo",     target="SDBCONTRACTNO"),
		@Mapping(source="paymentOption",  target="PAYOPTION")
	 })
	public DEPSDBPAYMENTAPIType mapSdbAcctHdrJpeToDEPSDBPAYMENTAPIType(SdbAcctHdrJpe jpe);
	
}
