package com.silverlakesymmetri.cbs.dep.svc;

import java.util.List;
import java.util.Map;

import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation;
import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation.ServiceOperationType;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.svc.BusinessService;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.IntLadderVInq;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.IntLadderVInqJpe;

public interface IntLadderVInqService extends BusinessService<IntLadderVInq, IntLadderVInqJpe>{

	public static final String SVC_OP_NAME_INTLADDERVINQSERVICE_GET= "IntLadderVInqService.get";
	public static final String SVC_OP_NAME_INTLADDERVINQSERVICE_QUERY= "IntLadderVInqService.query";
	public static final String SVC_OP_NAME_INTLADDERVINQSERVICE_FIND= "IntLadderVInqService.find";
	
	@ServiceOperation(name=SVC_OP_NAME_INTLADDERVINQSERVICE_GET, type = ServiceOperationType.GET)
	public IntLadderVInq getByPk(String publicKey, IntLadderVInq reference);
	
    @ServiceOperation(name = SVC_OP_NAME_INTLADDERVINQSERVICE_QUERY)
    public List<IntLadderVInq> query(int offset, int resultLimit, String groupBy, String order, Map<String, Object> filters);
 	
    @ServiceOperation(name = SVC_OP_NAME_INTLADDERVINQSERVICE_FIND)
    public List<IntLadderVInq> find(FindCriteria findCriteria, CbsHeader cbsHeader);
	
}
