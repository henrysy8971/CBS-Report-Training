package com.silverlakesymmetri.cbs.dep.svc;

import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation;
import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation.ServiceOperationType;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.svc.BusinessService;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.AcctType;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.AcctTypeJpe;

import java.util.List;
import java.util.Map;

public interface AcctTypeService extends BusinessService<AcctType, AcctTypeJpe> {

    public static final String SVC_OP_NAME_ACCTTYPESERVICE_GET = "AcctTypeService.get";
    public static final String SVC_OP_NAME_ACCTTYPESERVICE_QUERY = "AcctTypeService.query";
    public static final String SVC_OP_NAME_ACCTTYPESERVICE_CREATE = "AcctTypeService.create";
    public static final String SVC_OP_NAME_ACCTTYPESERVICE_UPDATE = "AcctTypeService.update";
    public static final String SVC_OP_NAME_ACCTTYPESERVICE_DELETE = "AcctTypeService.delete";
    public static final String SVC_OP_NAME_ACCTTYPESERVICE_FIND = "AcctTypeService.find";
    public static final String SVC_OP_NAME_ACCTTYPESERVICE_FIND_TO_ACCT_TYPE = "AcctTypeService.findToAcctType";
    public static final String SVC_OP_NAME_ACCTTYPESERVICE_FIND_NEW_ACCT_TYPE_FRO_ACCT_TYPE_TRANSFER =
            "AcctTypeService.findNewAcctTypeForAcctTypeTransfer";

    @ServiceOperation(name = SVC_OP_NAME_ACCTTYPESERVICE_GET, type = ServiceOperationType.GET)
    public AcctType getByPk(String publicKey, AcctType reference);

    @ServiceOperation(name = SVC_OP_NAME_ACCTTYPESERVICE_CREATE)
    public AcctType create(AcctType dataObject);

    @ServiceOperation(name = SVC_OP_NAME_ACCTTYPESERVICE_UPDATE)
    public AcctType update(AcctType dataObject);

    @ServiceOperation(name = SVC_OP_NAME_ACCTTYPESERVICE_QUERY)
    public List<AcctType> query(int offset, int resultLimit, String groupBy, String order, Map<String, Object> filters);

    @ServiceOperation(name = SVC_OP_NAME_ACCTTYPESERVICE_DELETE)
    public boolean delete(AcctType dataObject);

    @ServiceOperation(name = SVC_OP_NAME_ACCTTYPESERVICE_FIND)
    public List<AcctType> find(FindCriteria findCriteria, CbsHeader cbsHeader);

    @ServiceOperation(name = SVC_OP_NAME_ACCTTYPESERVICE_FIND_TO_ACCT_TYPE , type = ServiceOperationType.READ,
            passParamAsMap = true)
    public List<AcctType> findToAcctType(Map<String, Object> queryParams);

    @ServiceOperation(name = SVC_OP_NAME_ACCTTYPESERVICE_FIND_NEW_ACCT_TYPE_FRO_ACCT_TYPE_TRANSFER , type =
            ServiceOperationType.READ,
            passParamAsMap = true)
    public List<AcctType> findNewAcctTypeForAcctTypeTransfer(Map<String, Object> queryParams);
}
