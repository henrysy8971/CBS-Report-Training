package com.silverlakesymmetri.cbs.dep.svc.impl;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.ArrayList;
import java.util.HashMap;

import com.silverlakesymmetri.cbs.commons.helper.jpa.LinkTable;
import com.silverlakesymmetri.cbs.commons.helper.jpa.QueryCondition;
import com.silverlakesymmetri.cbs.commons.helper.jpa.QueryType;
import com.silverlakesymmetri.cbs.commons.jpa.entity.FindCriteriaJpe;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.mysema.query.types.EntityPath;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.jpa.util.DateTimeHelper;
import com.silverlakesymmetri.cbs.commons.jpa.util.JpaEntityChangeTracker;
import com.silverlakesymmetri.cbs.commons.svc.AbstractBusinessService;
import com.silverlakesymmetri.cbs.commons.svc.BusinessObjectValidationCapable;
import com.silverlakesymmetri.cbs.csd.bdo.sdo.ProdScDef;
import com.silverlakesymmetri.cbs.csd.jpa.mapping.sdo.ProdScDefJpe;
import com.silverlakesymmetri.cbs.csd.jpa.mapping.sdo.util.CsdJpeConstants;
import com.silverlakesymmetri.cbs.csd.svc.ProdScDefService;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.DepositClient;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.AcctJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.DepositClientJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.FloatRolldownJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.IntMatrixDtlJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.QDepositClientJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.util.DepJpeConstants;
import com.silverlakesymmetri.cbs.dep.svc.DepositClientService;
import com.silverlakesymmetri.cbs.mcl.jpa.mapping.sdo.ClientJpe;
import com.silverlakesymmetri.cbs.mcl.jpa.mapping.sdo.util.MclJpeConstants;

@Service
@Transactional
public class DepositClientServiceImpl extends AbstractBusinessService<DepositClient, DepositClientJpe, String> implements DepositClientService, BusinessObjectValidationCapable<DepositClient> {

    private static final String FEE_WAIVER_STATUS_NOT_ALLOWED = "N";
	private static LinkedHashMap<String, LinkTable> constructorMap;
	private static QueryCondition condition;
    
    @Autowired
    private DateTimeHelper dateTimeHelper;

    @Autowired
    private ProdScDefService prodScDefService;

	static {
		constructorMap = new LinkedHashMap<String, LinkTable>();
		constructorMap.put("clientId", new LinkTable(DepositClientJpe.class));
		constructorMap.put("clientNo", new LinkTable(ClientJpe.class));
		constructorMap.put("stopSc", new LinkTable(DepositClientJpe.class));
		constructorMap.put("scException", new LinkTable(DepositClientJpe.class));
		constructorMap.put("scGroup", new LinkTable(DepositClientJpe.class));
		constructorMap.put("scPackType", new LinkTable(DepositClientJpe.class));

		condition = new QueryCondition();
		condition.where("clientId", QueryType.EQUALS, new LinkTable(ClientJpe.class, "clientId"))
				.and("clientId", QueryType.EQUALS, new LinkTable(DepositClientJpe.class, "clientId"));

	}
    
    
	@Override
	protected EntityPath<DepositClientJpe> getEntityPath() {
		return QDepositClientJpe.depositClientJpe;
	}

	@Override
	protected String getIdFromDataObjectInstance(DepositClient dataObject) {
		return dataObject.getClientNo();
	}

	@Override
	public DepositClient getByPk(String publicKey, DepositClient reference) {
		return super.getByPk(publicKey, reference);
	}

	@Override
	public List<DepositClient> find(FindCriteria findCriteria, CbsHeader cbsHeader) {
		return super.find(findCriteria, cbsHeader, constructorMap, condition);
	}

	@Override
	public Long count(FindCriteria findCriteria, CbsHeader cbsHeader) {
		FindCriteriaJpe jpe = jaxbSdoHelper.unwrap(findCriteria, FindCriteriaJpe.class);
		return dataService.getRowCount(DepositClientJpe.class, jpe, constructorMap, condition);
	}

	@Override
	public List<DepositClient> query(int offset, int resultLimit, String groupBy, String order,
								final Map<String, Object> filters) {
		QueryCondition newCondition = convertFilters(condition, filters, constructorMap);
		return super.query(newCondition, offset, resultLimit,  groupBy, order, constructorMap);

	}

	@Override
	public DepositClient create(DepositClient arg0) {
		/* Default value is N. This will be updated by a batch process */
		arg0.setFwStatus(FEE_WAIVER_STATUS_NOT_ALLOWED);
		DepositClient result = super.create(arg0);
		
		if (result != null) {
			Map<String, Object> parameters = new HashMap<String, Object>();
			parameters.put("clientNo", arg0.getClientNo());
			ClientJpe clientJpe = dataService.getWithNamedQuery(MclJpeConstants.CLIENT_JPE_GET_CLIENT_FROM_REF_NO, parameters, ClientJpe.class);			
			clientJpe.setDepClientYn(true);
			dataService.update(clientJpe);
		}
		
		return result;
	}

	@Override
	protected DepositClient preCreateValidation(DepositClient dataObject) {
		if (dataObject.getFwEligible() == null || dataObject.getFwEligible().isEmpty()) {
			dataObject.setFwEligible("Y");
		}
		return super.preCreateValidation(dataObject);
	}

	@Override
	protected DepositClient preUpdateValidation(DepositClient dataObject) {
		if (dataObject.getFwEligible() == null || dataObject.getFwEligible().isEmpty()) {
			dataObject.setFwEligible("Y");
		}
		return super.preUpdateValidation(dataObject);
	}

	@Override
	public DepositClient update(DepositClient dataObject) {		
		
		DepositClient depositClient = super.update(setValues(dataObject));
		
		Map<String, Object> param1 = new HashMap<String, Object>();
		param1.put("clientNo", depositClient.getClientNo());
		List<Long> clientIdList = dataService.findWithNamedQuery(MclJpeConstants.CLIENT_JPE_FIND_ID_FROM_REF_NO, param1, Long.class);
		if (clientIdList != null && clientIdList.size() > 0) {
			Map<String, Object> param = new HashMap<String, Object>();
	        param.put("clientId", clientIdList.get(0));
	        List<AcctJpe> acctJpeList = dataService.findWithNamedQuery(DepJpeConstants.ACCT_JPE_FIND_ACCT_BY_CLIENT_NO, param, AcctJpe.class);
	        if (acctJpeList != null && acctJpeList.size() > 0) {
	        	List<String> acctNoList = new ArrayList<String>();
	        	for (AcctJpe acct: acctJpeList) {
		        	/*ProdScDef sc = prodScDefService.getByPk(acct.getAcctNo()+"~"+acct.getInternalKey().toString()+"~DEP~A", null);
		        	sc.setTaxFiler(depositClient.getTaxFiler());
		        	prodScDefService.update(sc);*/
	        		acctNoList.add(acct.getAcctNo());
	        	}
	        	
	        	Map<String, Object> param2 = new HashMap<String, Object>();
	        	param2.put("taxFiler", depositClient.getTaxFiler());
	        	param2.put("moduleId", "DEP");
	        	param2.put("subType", "A");
	        	param2.put("prodNoList", acctNoList);
	        	dataService.bulkUpdateWithNamedQuery(CsdJpeConstants.PROD_SC_DEF_JPE_TAX_FILER, param2, ProdScDefJpe.class);
	        }
		}
		
		return depositClient;
	}
	
	@Override
	public boolean delete(DepositClient arg0) {
		boolean result = super.delete(arg0);
		if (result) {
			Map<String, Object> parameters = new HashMap<String, Object>();
			parameters.put("clientNo", arg0.getClientNo());
			ClientJpe clientJpe = dataService.getWithNamedQuery(MclJpeConstants.CLIENT_JPE_GET_CLIENT_FROM_REF_NO, parameters, ClientJpe.class);			
			clientJpe.setDepClientYn(false);
			dataService.update(clientJpe);
		}
		return result;		
	}

	private DepositClient setValues(DepositClient dataObject) { 
		/* setFwManualUserUpdDate */
		DepositClient oldDataObject = super.getByPk(dataObject.getClientNo(), dataObject);
		if (!oldDataObject.getFwManualStatus().equals(dataObject.getFwManualStatus()))
			dataObject.setFwManualUserUpdDate(dateTimeHelper.getSDODateTime(dateTimeHelper.getRunDate()));
		else 
			dataObject.setFwManualUserUpdDate(oldDataObject.getFwManualUserUpdDate());
		return dataObject;
		
	}
}
