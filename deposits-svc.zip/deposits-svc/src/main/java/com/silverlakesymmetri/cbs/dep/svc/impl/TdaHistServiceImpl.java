package com.silverlakesymmetri.cbs.dep.svc.impl;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.mail.MessagingException;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.math.NumberUtils;
import org.apache.velocity.VelocityContext;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.google.common.collect.Lists;
import com.mysema.query.types.EntityPath;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.bdo.sdo.DmsFile;
import com.silverlakesymmetri.cbs.commons.exception.CbsRuntimeException;
import com.silverlakesymmetri.cbs.commons.exception.base.CbsServiceProcessException;
import com.silverlakesymmetri.cbs.commons.exception.base.helper.ExceptionHelper;
import com.silverlakesymmetri.cbs.commons.jpa.entity.CbsBpmInfoJpe;
import com.silverlakesymmetri.cbs.commons.jpa.mapping.sdo.enums.CommunicationChannelEnum;
import com.silverlakesymmetri.cbs.commons.logging.CbsAppLogger;
import com.silverlakesymmetri.cbs.commons.logging.CbsAppLoggerFactory;
import com.silverlakesymmetri.cbs.commons.notification.CbsMessageNotificationService;
import com.silverlakesymmetri.cbs.commons.svc.AbstractXmlApiBusinessService;
import com.silverlakesymmetri.cbs.commons.svc.BusinessObjectValidationCapable;
import com.silverlakesymmetri.cbs.commons.svc.LimitsCheckingCapable;
import com.silverlakesymmetri.cbs.commons.xmlapi.enums.CbsXmlApiOperation;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.Acct;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.AcctType;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.TdaHist;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.QTdaHistJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.TdaHistJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.TdaPretermInqJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.id.TdaHistPk;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.util.DepJpeConstants;
import com.silverlakesymmetri.cbs.dep.jpa.util.DepTDStorHelper;
import com.silverlakesymmetri.cbs.dep.svc.AcctTDService;
import com.silverlakesymmetri.cbs.dep.svc.AcctTypeService;
import com.silverlakesymmetri.cbs.dep.svc.DepTDStorUtilService;
import com.silverlakesymmetri.cbs.dep.svc.DepositsExpEmkService;
import com.silverlakesymmetri.cbs.dep.svc.TdaHistService;
import com.silverlakesymmetri.cbs.dep.svc.mapper.TdaHistServiceMapper;
import com.silverlakesymmetri.cbs.dep.xmlapi.DEPTDAPRETERMAPIType;
import com.silverlakesymmetri.cbs.lmt.util.ExpEmkObjectHolder;
import com.silverlakesymmetri.cbs.lmt.util.LimitsUtility;
import com.silverlakesymmetri.cbs.mcl.bdo.sdo.Client;
import com.silverlakesymmetri.cbs.mcl.svc.ClientService;
import com.silverlakesymmetri.cbs.xps.bdo.sdo.AdvicePreview;
import com.silverlakesymmetri.cbs.xps.svc.util.CbsDocumentTemplateBuilder;

@Service
@Transactional
public class TdaHistServiceImpl extends
		AbstractXmlApiBusinessService<TdaHist, TdaHistJpe, TdaHistPk, DEPTDAPRETERMAPIType, DEPTDAPRETERMAPIType>
		implements TdaHistService, BusinessObjectValidationCapable<TdaHist>, LimitsCheckingCapable<TdaHist> {

	@Autowired
	private TdaHistServiceMapper mapper;

	@Autowired
	private DepTDStorHelper depTDStorHelper;
	
	@Autowired
	private DepositsExpEmkService depositsExpEmkService;

    @Autowired
    private LimitsUtility limitsUtility;
    
    @Autowired
    private DepTDStorUtilService tdStorUtilService;
    
    @Autowired
    private AcctTDService acctTDService;
    
    @Autowired
    private ClientService clientService;
    
    @Autowired
    private AcctTypeService acctTypeService;
    
    @Autowired
    private CbsDocumentTemplateBuilder documentTemplateBuilder;
	
	@Autowired
	protected CbsMessageNotificationService msgNotificationService;
    
    private static CbsAppLogger logger = CbsAppLoggerFactory.getLogger(TdaHistServiceImpl.class.getName());

	private static final String INTERNAL_KEY = "internalKey";
	private static final String ACCT_NO = "acctNo";
	private static final String CERTIFICATE_NO = "certificateNo";
	private static final String MOVT_STATUS = "movtStatus";
	private static final String AUTO_GEN_FEE = "autoGenFee";
	private static final String AMT_WDRAWN = "amtWdrawn";
	private static final String PRETERM_AMT = "pretermAmt";
	private static final String PRETERM_INT_RATE = "pretermIntRate";
	private static final String PRETERM_INT_AMT = "pretermIntAmt";
	private static final String WTAX_POSTED = "wtaxPosted";
	private static final String INT_ADJ_AMT = "intAdjAmt";
	private static final String PRETERM_SC_AMT = "pretermScAmt";
	private static final String NET_PROCEEDS = "netProceeds";
	private static final String PRETERM_PROFIT_IND = "pretermProfitPayout";
	private static final String ACTION = "action";
	private static final String RECALCULATE_ACTION = "RECALCULATE";
	private static final String INITIALIZE_ACTION = "INITIALIZE";
	private static final String ADVICE_NAME = "TdMovementNotice";
	
	private static final String NO_MOVEMENT_FOR_TD = "CBS.B.DEP.TDA_HIST_SERVICE.0023";

	@Override
	protected EntityPath<TdaHistJpe> getEntityPath() {
		return QTdaHistJpe.tdaHistJpe;
	}

	@Override
	protected TdaHistPk getIdFromDataObjectInstance(TdaHist dataObject) {
		TdaHistJpe jpe = jaxbSdoHelper.unwrap(dataObject);
		return new TdaHistPk(jpe.getSeqNo(), jpe.getInternalKey());
	}

	@Override
	public TdaHist getByPk(String publicKey, TdaHist reference) {
		return super.getByPk(publicKey, reference);
	}

	@Override
	public TdaHist create(TdaHist dataObject) {
		if(dataObject.getTdaPymtDtlsList() != null && dataObject.getTdaPymtDtlsList().size() > 0){
			for(int i = 0; i < dataObject.getTdaPymtDtlsList().size(); i++){
				dataObject.getTdaPymtDtlsList().get(i).setSeqNo(i+1L);
			}
		}
		TdaHist result = super.create(dataObject);
		try {
			generateTdMovementNotification(dataObject, false);
		} catch (Exception e) {
			//notifications should not interfere with processing
			e.printStackTrace();
		}
		return result;
    }

	@Override
	public List<TdaHist> query(int offset, int resultLimit, String groupBy, String order, Map<String, Object> filters) {
		String action = (String) filters.getOrDefault(ACTION, "");
		String acctNo = (String) filters.get(ACCT_NO);

		if (StringUtils.isBlank(action)) {
			if (filters.containsKey(ACCT_NO)) {
				Map<String, Object> params = new HashMap<>();
				params.put(ACCT_NO, filters.get(ACCT_NO));
				Long result = dataService.getWithNamedQuery(DepJpeConstants.ACCT_JPE_FIND_INTERNAL_KEY_BY_ACCT_NO, params,
						Long.class);
				filters.remove(ACCT_NO);
				filters.put(INTERNAL_KEY, result);
			}
			return super.query(offset, resultLimit, groupBy, order, filters);
		} else if (action.equals(RECALCULATE_ACTION)) {
			return Lists.newArrayList(recalculate(transformMapToBdo(filters), null));
		} else if (action.equals(INITIALIZE_ACTION)) {
			List<TdaHist> tdaHistList = Lists.newArrayList(initialize(transformMapToBdo(filters), null));
			return tdaHistList;
		} else {
			throw new CbsRuntimeException(String.format("Specified action %s is invalid", action));
		}
	}

	@Override
	public TdaHist update(TdaHist dataObject) {
		return null;
	}

	@Override
	public boolean delete(TdaHist dataObject) {
		return false;
	}

	@Override
	public List<TdaHist> find(FindCriteria findCriteria, CbsHeader cbsHeader) {
		return super.find(findCriteria, cbsHeader);
	}

	@Override
	protected Class<DEPTDAPRETERMAPIType> getXmlApiResponseClass() {
		return DEPTDAPRETERMAPIType.class;
	}

	@Override
	protected List<TdaHist> processXmlApiListRs(TdaHist dataObject, DEPTDAPRETERMAPIType apiRs) {
		List<TdaHist> result = new ArrayList<TdaHist>();
		if (apiRs != null) {
			dataObject = transformApiToBdo(apiRs, dataObject);
			result.add(dataObject);
		}
		return result;
	}

	@Override
	protected TdaHist processXmlApiRs(TdaHist dataObject, DEPTDAPRETERMAPIType apiRs) {
		dataObject = transformApiToBdo(apiRs, dataObject);
		return dataObject;
	}
	
	public AdvicePreview generateTdMovementNotification(TdaHist dataObject, boolean isPreview){
		VelocityContext context = new VelocityContext();
		context.put("TdaHist", dataObject);
		
		boolean islamicDocument = false;
		islamicDocument = fillContext(context, dataObject.getAcctNo(), dataObject.getSeqNo());
		
		//call template builder
		Map<String, String> messageContext = documentTemplateBuilder.convertTemplateToMessage(ADVICE_NAME+"Email", context, null, islamicDocument);
		DmsFile tdMovementNotice = generateMovementNotification(dataObject.getAcctNo(), dataObject.getSeqNo(), context);
		tdMovementNotice.setName(ADVICE_NAME+"-"+dataObject.getAcctNo()+".pdf");
		
		List<DmsFile> attachments = new ArrayList<DmsFile>();
		attachments.add(tdMovementNotice);

		Client client = (Client) context.get("Client");
		String mailAddress = clientService.getClientElectronicMailAddress(client.getClientNo());

		AdvicePreview mailPreview = jaxbSdoHelper.createSdoInstance(AdvicePreview.class);
		mailPreview.setRecipients(mailAddress);
		mailPreview.setMsgBody(messageContext.get("message"));
		mailPreview.setSubject("Time Deposit movement notification");
		mailPreview.setAttachments(attachments);
		mailPreview.setDocument(ADVICE_NAME);

		if(isPreview){
			return mailPreview;
		}

		try {
			msgNotificationService.sendNotificationMessage(CommunicationChannelEnum.MAIL, mailAddress, messageContext.get("subject"), messageContext.get("message"), null, attachments);
		} catch (MessagingException e) {
			return null;
		}
		return mailPreview;
	}
	
	public DmsFile generateMovementNotification(String acctNo, Long seqNo, VelocityContext context){
		boolean islamicDocument = false;
		String publicKey = acctNo;
		if(context == null){
			//called from UI
			context = new VelocityContext();
			TdaHistJpe jpe = getTdLastMovement(acctNo);
			if(jpe != null){
				TdaHist dataObject = jaxbSdoHelper.wrap(jpe);
				publicKey = acctNo + "~" + dataObject.getSeqNo();
				context.put("TdaHist", dataObject);
				islamicDocument = fillContext(context, dataObject.getAcctNo(), dataObject.getSeqNo());				
			} else {
				throwNoTdMovementRecordedException(acctNo);
			}
		}
		//call template builder
		DmsFile tdMovementNotice = documentTemplateBuilder.convertTemplateToDocument(ADVICE_NAME, context, null, islamicDocument, publicKey);
		return tdMovementNotice;
	}
	
	private boolean fillContext(VelocityContext context, String acctNo, Long seqNo){
		Acct acct = acctTDService.getByPk(acctNo, null);
		context.put("Acct", acct);
		Client client = clientService.getByPk(acct.getClientNo(), null);
		context.put("Client", client);
		Map<String, Object> params = new HashMap<String, Object>();
		params.put("acctNo", acctNo);
		params.put("tdaHistSeqNo", seqNo);
		List<TdaPretermInqJpe> tdPretermList = dataService.findWithNamedQuery(DepJpeConstants.TDA_PRETERM_INQ_JPE_FIND_LAST_MOVEMENT, params, TdaPretermInqJpe.class);
		if(tdPretermList != null && tdPretermList.size() > 0){
			context.put("TdaPretermInq", jaxbSdoHelper.wrap(tdPretermList.get(0)));
		}
		AcctType acctTypeBdo = acctTypeService.getByPk(acct.getAcctType(), null);
		if (acctTypeBdo != null && acctTypeBdo.getIslamicIndicator() != null) {
			return acctTypeBdo.getIslamicIndicator().equals("Y");
		}
		return false;
	}

	@Override
	protected DEPTDAPRETERMAPIType transformBdoToXmlApiRqCreate(TdaHist dataObject) {
		return transform(dataObject, CbsXmlApiOperation.INSERT);
	}

	@Override
	protected DEPTDAPRETERMAPIType transformBdoToXmlApiRqDelete(TdaHist dataObject) {
		return null;
	}

	@Override
	protected DEPTDAPRETERMAPIType transformBdoToXmlApiRqUpdate(TdaHist dataObject) {
		return null;
	}

	@Override
    public TdaHist initialize(TdaHist dataObject, CbsHeader cbsHeader) {
        TdaHist computedPreTerm = super.queryDataObject(dataObject, transform(dataObject, CbsXmlApiOperation.QUERY));
        
        if (computedPreTerm.getPretermAmt() == null) {computedPreTerm.setPretermAmt(0d);}
        if (computedPreTerm.getLedgerBal() == null) {computedPreTerm.setLedgerBal(0d);}
        if (computedPreTerm.getAccruedInt() == null) {computedPreTerm.setAccruedInt(0d);}
        if (computedPreTerm.getPretermIntRate() == null) {computedPreTerm.setPretermIntRate(0d);}
        if (computedPreTerm.getPretermIntAmt() == null) {computedPreTerm.setPretermIntAmt(0d);}
        if (computedPreTerm.getTaxAmt() == null) {computedPreTerm.setTaxAmt(0d);}
        if (computedPreTerm.getFundsHeld() == null) {computedPreTerm.setFundsHeld(0d);}
        if (computedPreTerm.getIntAdjAmt() == null) {computedPreTerm.setIntAdjAmt(0d);}
        if (computedPreTerm.getPretermScAmt() == null) {computedPreTerm.setPretermScAmt(0d);}
        if (computedPreTerm.getAvailBal() == null) {computedPreTerm.setAvailBal(0d);}
        if (computedPreTerm.getNewPrincipalAmt() == null) {computedPreTerm.setNewPrincipalAmt(0d);}
        if (computedPreTerm.getNewIntRate() == null) {computedPreTerm.setNewIntRate(0d);}
        if (computedPreTerm.getRemainBalInt() == null) {computedPreTerm.setRemainBalInt(0d);}
        if (computedPreTerm.getTdIntPayout() == null) {computedPreTerm.setTdIntPayout(0d);}
        if (computedPreTerm.getWtaxPosted() == null) {computedPreTerm.setWtaxPosted(0d);}
        if (computedPreTerm.getNetProceeds() == null) {computedPreTerm.setNetProceeds(0d);}
        if (computedPreTerm.getPretermIntAdj() == null) {computedPreTerm.setPretermIntAdj(0d);}
        
        return computedPreTerm;
	}

	@Override
    public TdaHist recalculate(TdaHist dataObject, CbsHeader cbsHeader) {
		Map<String, Object> recalculatedValues = depTDStorHelper.recalculatePretermValues(dataObject.getAcctNo(),
				dataObject.getCertificateNo(), dataObject.getMovtStatus(), dataObject.getAmtWdrawn(),
				dataObject.getPretermAmt(), dataObject.getPretermIntRate(), dataObject.getPretermIntAmt(),
				dataObject.getTaxAmt(), dataObject.getIntAdjAmt(), dataObject.getPretermScAmt(),
				dataObject.getNetProceeds());
		dataObject.setPretermAmt((Double) recalculatedValues.get("p_amt_to_preterm"));
		dataObject.setPretermIntRate((Double) recalculatedValues.get("p_preterm_int_rate"));
		dataObject.setPretermIntAmt((Double) recalculatedValues.get("p_preterm_int_amt"));
		dataObject.setTaxAmt((Double) recalculatedValues.get("p_witholding_tax"));
		dataObject.setIntAdjAmt((Double) recalculatedValues.get("p_cr_int_adjustment"));
		dataObject.setPretermScAmt((Double) recalculatedValues.get("p_preterm_sc_amt"));
		dataObject.setNetProceeds((Double) recalculatedValues.get("p_net_proceeds"));
		dataObject.setAvailBal((Double) recalculatedValues.get("p_final_bal"));
		return dataObject;
	}

	@SuppressWarnings("rawtypes")
	private DEPTDAPRETERMAPIType transform(TdaHist bdo, CbsXmlApiOperation operation) {
		TdaHistJpe jpe = jaxbSdoHelper.unwrap(bdo, TdaHistJpe.class);
		DEPTDAPRETERMAPIType preTerm = mapper.mapToApi(jpe, operation, new HashMap());
		super.setTechColsFromDataObject(bdo, preTerm);
		return preTerm;
	}

	private TdaHist transformApiToBdo(DEPTDAPRETERMAPIType apiRs, TdaHist dataObject) {
		TdaHistJpe jpe = new TdaHistJpe();
		
		if (dataObject != null) {
			jpe = jaxbSdoHelper.unwrap(dataObject);
		}
		
		mapper.mapToJpe(apiRs, jpe);
		if (apiRs.getPRINCIPALAMT() != null) {
            jpe.setNewPrincipalAmt(apiRs.getPRINCIPALAMT().doubleValue() - jpe.getPretermAmt().doubleValue());
		}
		
		return jaxbSdoHelper.wrap(jpe, TdaHist.class);
	}

	private TdaHist transformMapToBdo(Map<String, Object> map) {
		TdaHist dataObject = jaxbSdoHelper.createSdoInstance(TdaHist.class);
		dataObject.setAcctNo((String) map.getOrDefault(ACCT_NO, null));
		dataObject.setCertificateNo((String) map.getOrDefault(CERTIFICATE_NO, null));
		dataObject.setMovtStatus((String) map.getOrDefault(MOVT_STATUS, null));
		dataObject.setAmtWdrawn((String) map.getOrDefault(AMT_WDRAWN, null));
		dataObject.setPretermAmt(NumberUtils.createDouble((String) map.getOrDefault(PRETERM_AMT, null)));
		dataObject.setPretermIntRate(NumberUtils.createDouble((String) map.getOrDefault(PRETERM_INT_RATE, null)));
		dataObject.setPretermIntAmt(NumberUtils.createDouble((String) map.getOrDefault(PRETERM_INT_AMT, null)));
		dataObject.setWtaxPosted(NumberUtils.createDouble((String) map.getOrDefault(WTAX_POSTED, null)));
		dataObject.setIntAdjAmt(NumberUtils.createDouble((String) map.getOrDefault(INT_ADJ_AMT, null)));
		dataObject.setPretermScAmt(NumberUtils.createDouble((String) map.getOrDefault(PRETERM_SC_AMT, null)));
		dataObject.setNetProceeds(NumberUtils.createDouble((String) map.getOrDefault(NET_PROCEEDS, null)));
		dataObject.setAutoGenFee((String) map.getOrDefault(AUTO_GEN_FEE, null));
		dataObject.setPretermProfitPayout((String) map.getOrDefault(PRETERM_PROFIT_IND, null));
		return dataObject;
	}

    @Override
    public CbsBpmInfoJpe doCheckLimit(TdaHist dataObject) {
        ExpEmkObjectHolder expEmkObject = depositsExpEmkService.getLimitsDetails(dataObject,
                DepositsExpEmkServiceImpl.WHD_EVENT_TYPE, DepositsExpEmkServiceImpl.DR_AMT_TYPE);
        return limitsUtility.getLimitExceptionApprover(expEmkObject, dataObject);
    }

    @Override
    public TdaHist getLimitExceptions(TdaHist dataObject) {
        ExpEmkObjectHolder expEmkObject = depositsExpEmkService.getLimitsDetails(dataObject,
                DepositsExpEmkServiceImpl.WHD_EVENT_TYPE, DepositsExpEmkServiceImpl.DR_AMT_TYPE);
        return limitsUtility.getLimitExceptionDetails(expEmkObject, dataObject);
    }

	@Override
	public Long getEffectivityDate(TdaHist dataObject) {
		if (dataObject != null) {
			if (!StringUtils.isBlank(dataObject.getAcctOpenDate())) {
				Date date = dateTimeHelper.getDate(dataObject.getAcctOpenDate());
				if (date != null) {
					return dateTimeHelper.removeTime(date).getTime();
				}
			}
		}
		return null;
	}
	
    @Override
    public void validateApiRequest(TdaHist dataObject, DEPTDAPRETERMAPIType xmlApiRq){
        try {
            String xmlApiReq = removeModifiedByAndModifiedDt(convertXmlApiRqToString(xmlApiRq));
            String xmlHeaderIn = convertXmlApiRqToString(createHeaderFromDataObject(dataObject));
            validate(dataObject, xmlApiReq, xmlHeaderIn);
        } catch (CbsRuntimeException cre) {
            throw cre;
        } catch (Exception e) {
            logger.error("Unhandled error encountered: {}", e.getMessage(), e);
            throw new RuntimeException(e);
        }
    }
    
    @Override
	public DmsFile generateMovementAdvice(String acctNo) {
		return generateMovementNotification(acctNo, null, null);
	}

	@Override
	public AdvicePreview sendMovementAdvice(String acctNo, boolean isPreview) {
		TdaHistJpe jpe = getTdLastMovement(acctNo);
		if(jpe != null){
			return generateTdMovementNotification(jaxbSdoHelper.wrap(jpe), isPreview);
		} else {
			throwNoTdMovementRecordedException(acctNo);
		}
		return null;
	}
	
	private TdaHistJpe getTdLastMovement(String acctNo){
		Map<String, Object> params = new HashMap<String, Object>();
		params.put("acctNo", acctNo);
		List<TdaHistJpe> tdMovementList = dataService.findWithNamedQuery(DepJpeConstants.TDA_HIST_JPE_FIND_LAST_MOVEMENT, params, TdaHistJpe.class);
		if(tdMovementList != null && tdMovementList.size() > 0){
			return tdMovementList.get(0);
		}
		return null;
	}
	
	private void throwNoTdMovementRecordedException(String acctNo){
		Collection<Throwable> exceptions = new ArrayList<>();
		String msg = messageUtils.getMessage(NO_MOVEMENT_FOR_TD, new String[] { acctNo });
		CbsServiceProcessException exec = new CbsServiceProcessException(NO_MOVEMENT_FOR_TD, msg);
		exceptions.add(exec);
		ExceptionHelper.createAndThrowAggregateException(exceptions);

	}

}
