package com.silverlakesymmetri.cbs.dep.svc;

import java.util.List;
import java.util.Map;

import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation;
import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation.ServiceOperationType;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.svc.BusinessService;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.LockerReversalDtls;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.LockerReversalDtlsJpe;

public interface LockerReversalDtlsService extends BusinessService<LockerReversalDtls, LockerReversalDtlsJpe> {

	public static final String SVC_OP_NAME_LOCKERREVERSALDTLSSERVICE_UPDATE = "LockerReversalDtlsService.update";
	public static final String SVC_OP_NAME_LOCKERREVERSALDTLSSERVICE_QUERY = "LockerReversalDtlsService.query";
	public static final String SVC_OP_NAME_LOCKERREVERSALDTLSSERVICE_DELETE = "LockerReversalDtlsService.delete";
	public static final String SVC_OP_NAME_LOCKERREVERSALDTLSSERVICE_FIND = "LockerReversalDtlsService.find";
	public static final String SVC_OP_NAME_LOCKERREVERSALDTLSSERVICE_GET = "LockerReversalDtlsService.get";

	@ServiceOperation(name = SVC_OP_NAME_LOCKERREVERSALDTLSSERVICE_UPDATE)
	public LockerReversalDtls update(LockerReversalDtls dataObject);

	@ServiceOperation(name = SVC_OP_NAME_LOCKERREVERSALDTLSSERVICE_QUERY)
	public List<LockerReversalDtls> query(int offset, int resultLimit, String groupBy, String order,
			Map<String, Object> filters);

	@ServiceOperation(name = SVC_OP_NAME_LOCKERREVERSALDTLSSERVICE_DELETE)
	public boolean delete(LockerReversalDtls dataObject);

	@ServiceOperation(name = SVC_OP_NAME_LOCKERREVERSALDTLSSERVICE_FIND)
	public List<LockerReversalDtls> find(FindCriteria findCriteria, CbsHeader cbsHeader);

	@ServiceOperation(name = SVC_OP_NAME_LOCKERREVERSALDTLSSERVICE_GET, type = ServiceOperationType.GET)
	public LockerReversalDtls getByPk(String publicKey, LockerReversalDtls reference);

}
