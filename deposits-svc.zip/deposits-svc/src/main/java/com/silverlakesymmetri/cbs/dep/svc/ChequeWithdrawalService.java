package com.silverlakesymmetri.cbs.dep.svc;

import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation;
import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation.ServiceOperationType;
import com.silverlakesymmetri.cbs.commons.svc.BusinessService;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.DepositTransaction;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.DepositTransactionJpe;

public interface ChequeWithdrawalService extends BusinessService<DepositTransaction, DepositTransactionJpe> {


    public static final String SVC_OP_NAME_CHEQUEWITHDRAWALSERVICE_POSTTRANSACTION = "ChequeWithdrawalService.postTransaction";
    public static final String SVC_OP_NAME_CHEQUEWITHDRAWALSERVICE_GET = "ChequeWithdrawalService.get";

    @ServiceOperation(name = SVC_OP_NAME_CHEQUEWITHDRAWALSERVICE_POSTTRANSACTION, type = ServiceOperationType.CREATE)
    public DepositTransaction postTransaction(DepositTransaction dataObject);
    
	@ServiceOperation(name = SVC_OP_NAME_CHEQUEWITHDRAWALSERVICE_GET, type = ServiceOperationType.GET)
    public DepositTransaction getByPk(String publicKey, DepositTransaction reference);

}
