package com.silverlakesymmetri.cbs.dep.svc.mapper.mapping;

import org.mapstruct.MapperConfig;
import org.mapstruct.Mapping;
import org.mapstruct.Mappings;

import com.silverlakesymmetri.cbs.commons.jpa.util.DateTimeHelper;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.FeeInquiryHdrJpe;
import com.silverlakesymmetri.cbs.dep.xmlapi.DEPFEEDETAILSAPIType;

@MapperConfig(uses = { DateTimeHelper.class })
public interface FeeInquiryHdrToDEPFEEDETAILSAPITypeMapper {

	@Mappings({
	    @Mapping(source = "prodNo", target = "ACCTNO"),
	    @Mapping(source = "clientId", target = "CLIENTNO"),
	    @Mapping(source = "acctAmt", target = "ACCTAMT"),
	    @Mapping(source = "tranAmt", target = "TRANAMT"),
	    @Mapping(source = "tranCcy", target = "TRANCCY"),
	    @Mapping(source = "tranCcy", target = "SCCCY"),
	    @Mapping(source = "tranType", target = "TRANTYPE"),
	    @Mapping(source = "crDrMaint", target = "CRDRMAINT"),
	    @Mapping(source = "counterparty", target = "COUNTERPARTY"),
	    @Mapping(source = "scEventType", target = "SCEVENTTYPE"),
	    @Mapping(source = "prodNo", target = "PRODNO"),
	    @Mapping(source = "prodSubType", target = "SUBTYPE"),
	    @Mapping(constant = "DEP", target = "MODULEID"),
	    @Mapping(source = "input1", target = "INPUT1"),
	    @Mapping(source = "input2", target = "INPUT2"),
	    @Mapping(source = "input3", target = "INPUT3"),
	    @Mapping(source = "input4", target = "INPUT4"),
	    @Mapping(source = "input5", target = "INPUT5"),
	    @Mapping(source = "input6", target = "INPUT6"),
	    @Mapping(source = "input7", target = "INPUT7"),
	    @Mapping(source = "input8", target = "INPUT8"),
	    @Mapping(source = "calcBalType1", target = "CALCBALTYPE1"),
	    @Mapping(source = "calcBalCcy1", target = "CALCBALCCY1"),
	    @Mapping(source = "calcBalType2", target = "CALCBALTYPE2"),
	    @Mapping(source = "calcBalCcy1", target = "CALCBALCCY2"),
	    @Mapping(source = "calcBalType3", target = "CALCBALTYPE3"),
	    @Mapping(source = "calcBalCcy1", target = "CALCBALCCY3"),
	    @Mapping(source = "calcBalType4", target = "CALCBALTYPE4"),
	    @Mapping(source = "calcBalCcy1", target = "CALCBALCCY4"),
	    @Mapping(source = "calcBalType5", target = "CALCBALTYPE5"),
	    @Mapping(source = "calcBalCcy1", target = "CALCBALCCY5"),
	    @Mapping(source = "calcBal1", target = "CALCBAL1"),
	    @Mapping(source = "calcBal2", target = "CALCBAL2"),
	    @Mapping(source = "calcBal3", target = "CALCBAL3"),
	    @Mapping(source = "calcBal4", target = "CALCBAL4"),
	    @Mapping(source = "calcBal5", target = "CALCBAL5")
	})
	public DEPFEEDETAILSAPIType mapFeeInquiryHdrToDEPFEEDETAILSAPIType(FeeInquiryHdrJpe jpe);
		
}




