package com.silverlakesymmetri.cbs.dep.svc;

import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation;
import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation.ServiceOperationType;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.svc.BusinessService;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.CiPrintReprint;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.CiPrintReprint;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.CiPrintReprint;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.CiPrintReprintJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.CiPrintReprintJpe;

import java.util.List;
import java.util.Map;

public interface CiPrintReprintService extends BusinessService<CiPrintReprint, CiPrintReprintJpe> {

    String SVC_OP_NAME_CIPRINTREPRINTSERVICE_GET = "CiPrintReprintService.get";
    String SVC_OP_NAME_CIPRINTREPRINTSERVICE_QUERY = "CiPrintReprintService.query";
    String SVC_OP_NAME_CIPRINTREPRINTSERVICE_UPDATE = "CiPrintReprintService.update";
    String SVC_OP_NAME_CIPRINTREPRINTSERVICE_FIND = "CiPrintReprintService.find";

    @ServiceOperation(name = SVC_OP_NAME_CIPRINTREPRINTSERVICE_GET, type = ServiceOperationType.GET)
    CiPrintReprint getByPk(String publicKey, CiPrintReprint reference);

    @ServiceOperation(name = SVC_OP_NAME_CIPRINTREPRINTSERVICE_UPDATE)
    CiPrintReprint update(CiPrintReprint dataObject);

    @ServiceOperation(name = SVC_OP_NAME_CIPRINTREPRINTSERVICE_QUERY)
    List<CiPrintReprint> query(int offset, int resultLimit, String groupBy, String order, Map<String, Object> filters);

    @ServiceOperation(name = SVC_OP_NAME_CIPRINTREPRINTSERVICE_FIND)
    List<CiPrintReprint> find(FindCriteria findCriteria, CbsHeader cbsHeader);

}
