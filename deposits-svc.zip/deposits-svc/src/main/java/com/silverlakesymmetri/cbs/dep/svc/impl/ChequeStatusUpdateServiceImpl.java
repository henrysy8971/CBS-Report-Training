package com.silverlakesymmetri.cbs.dep.svc.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Service;

import com.mysema.query.types.EntityPath;
import com.mysema.query.types.OrderSpecifier;
import com.mysema.query.types.Predicate;
import com.mysema.query.types.expr.BooleanExpression;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.jpa.entity.FindCriteriaJpe;
import com.silverlakesymmetri.cbs.commons.jpa.entity.ViewCriteriaItemJpe;
import com.silverlakesymmetri.cbs.commons.jpa.entity.ViewCriteriaJpe;
import com.silverlakesymmetri.cbs.commons.jpa.entity.ViewCriteriaRowJpe;
import com.silverlakesymmetri.cbs.commons.svc.AbstractXmlApiBusinessService;
import com.silverlakesymmetri.cbs.commons.svc.BusinessObjectValidationCapable;
import com.silverlakesymmetri.cbs.commons.xmlapi.enums.CbsXmlApiOperation;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.ChequeStatusUpdate;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.AcctJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.ChequeStatusUpdateJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.QChequeStatusUpdateJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.util.DepJpeConstants;
import com.silverlakesymmetri.cbs.dep.svc.ChequeStatusUpdateService;
import com.silverlakesymmetri.cbs.dep.xmlapi.DEPCHQREGAPIType;

@Service
public class ChequeStatusUpdateServiceImpl extends AbstractXmlApiBusinessService<ChequeStatusUpdate, ChequeStatusUpdateJpe, Long, DEPCHQREGAPIType, DEPCHQREGAPIType> implements ChequeStatusUpdateService, BusinessObjectValidationCapable<ChequeStatusUpdate>{
	
	private static final String ACCT_NO = "acctNo";
	@Override
	protected EntityPath<ChequeStatusUpdateJpe> getEntityPath() {
		return QChequeStatusUpdateJpe.chequeStatusUpdateJpe;
	}
	
	@Override
	protected Long getIdFromDataObjectInstance(ChequeStatusUpdate dataObject) {
		return dataObject.getChequeNo();
	}
	
	@Override
	public List<ChequeStatusUpdate> query(int offset, int resultLimit, String groupBy, String order, Map<String, Object> filters) {
		String acctNo = null;
		List<ChequeStatusUpdate> chequeStatusUpdateList = null;
		if (filters != null && filters.get(ACCT_NO) != null) {
			acctNo = filters.get(ACCT_NO).toString();
			filters.remove(ACCT_NO);
		}
		if (acctNo != null) {
			chequeStatusUpdateList = customQuery(offset, resultLimit, order, filters, acctNo);
		} else {
			chequeStatusUpdateList = super.query(offset, resultLimit, groupBy, order, filters);	
		}
		return chequeStatusUpdateList;
	}
	
	@Override
	public List<ChequeStatusUpdate> find(FindCriteria findCriteria, CbsHeader cbsHeader) {
		FindCriteriaJpe fcJpe = updateFC(findCriteria);
		FindCriteria fcBdo = jaxbSdoHelper.wrap(fcJpe, FindCriteria.class);
		return super.find(fcBdo, cbsHeader);
	}
	
	@Override
	public Long count(FindCriteria findCriteria, CbsHeader cbsHeader) {
		FindCriteriaJpe fcJpe = updateFC(findCriteria);
		return dataService.getRowCount(ChequeStatusUpdateJpe.class, fcJpe);
	}
	
	private AcctJpe getAccount(String acctNo){
		AcctJpe acctJpe = null;
		Map<String,Object> param = new HashMap<>();
		param.put(ACCT_NO, acctNo);
		List<AcctJpe> acctJpeList = dataService.findWithNamedQuery(DepJpeConstants.ACCT_JPE_FIND_BY_ACCTNO, param, AcctJpe.class);
		if (acctJpeList!=null && !acctJpeList.isEmpty()){
			acctJpe = acctJpeList.get(0);
		}
		return acctJpe;
	}
	
	private List<ChequeStatusUpdate> customQuery(int offset, int resultLimit, String order, Map<String, Object> filters, String acctNo) {
		final List<OrderSpecifier<?>> orders = getOrderSpecifier(QChequeStatusUpdateJpe.chequeStatusUpdateJpe, null, order);
		Predicate predicate = convertMapToPredicate(filters, acctNo);
		return super.query(QChequeStatusUpdateJpe.chequeStatusUpdateJpe, offset, resultLimit, predicate, orders);
	}
	
	private Predicate convertMapToPredicate(Map<String, Object> filters, String acctNo) {
		Predicate predicate = convertMapToPredicate(QChequeStatusUpdateJpe.chequeStatusUpdateJpe, filters);
		BooleanExpression booleanExpr = null;
		if (acctNo!=null) {
			AcctJpe acctJpe = getAccount(acctNo);
			if (acctJpe!=null){
				booleanExpr = QChequeStatusUpdateJpe.chequeStatusUpdateJpe.internalKey.eq(acctJpe.getInternalKey());
			}
		} 
		if (predicate != null) {
			predicate = ((BooleanExpression) predicate).and(booleanExpr);	
		} else {
			predicate = booleanExpr;
		}
		return predicate;
	}
	
	private FindCriteriaJpe updateFC(FindCriteria findCriteria) {
		FindCriteriaJpe fc = null;
		String acctNo = null;
		if (findCriteria == null) {
			fc = new FindCriteriaJpe();
	        ViewCriteriaJpe rootViewCriteria = new ViewCriteriaJpe();
	        fc.setFilter(rootViewCriteria);
		} else {
			fc = jaxbSdoHelper.unwrap(findCriteria, true);
		}
		if (fc != null) {
			List<ViewCriteriaRowJpe> rowList = fc.getFilter().getGroup();
			for (ViewCriteriaRowJpe row : rowList) {
				List<ViewCriteriaItemJpe> itemList = row.getItem();
				for (int i = itemList.size() - 1; i >= 0; i--) {
					ViewCriteriaItemJpe vci = itemList.get(i);
					if (ACCT_NO.equals(vci.getAttribute()) && vci.getValue().get(0) != null) {
						acctNo = vci.getValue().get(0).toString();
						List<Object> datalist = new ArrayList<>();
						if (acctNo!=null){
							AcctJpe acctJpe = getAccount(acctNo);
							if (acctJpe!=null){
								datalist.add(acctJpe.getInternalKey());
								vci.setAttribute("internalKey");
						        vci.setOperator("=");
						        vci.setValue(datalist);
							}							
							break;
						}
					}
				}
			}
		}
		return fc;
	}

	@Override
	protected DEPCHQREGAPIType transformBdoToXmlApiRqCreate(ChequeStatusUpdate dataObject) {
		return transformChequeStatusUpdateToDEPCHQREGAPIType(dataObject, CbsXmlApiOperation.INSERT);
	}

	@Override
	protected DEPCHQREGAPIType transformBdoToXmlApiRqUpdate(ChequeStatusUpdate dataObject) {
		return transformChequeStatusUpdateToDEPCHQREGAPIType(dataObject, CbsXmlApiOperation.UPDATE);
	}

	@Override
	protected DEPCHQREGAPIType transformBdoToXmlApiRqDelete(ChequeStatusUpdate dataObject) {
		return transformChequeStatusUpdateToDEPCHQREGAPIType(dataObject, CbsXmlApiOperation.DELETE);
	}

	@Override
	protected ChequeStatusUpdate processXmlApiRs(ChequeStatusUpdate dataObject, DEPCHQREGAPIType xmlApiRs) {
		if (xmlApiRs!=null && xmlApiRs.getSTATUS()!=null){
			dataObject.setStatus(xmlApiRs.getSTATUS());
		}
		return dataObject;
	}

	@Override
	protected Class<DEPCHQREGAPIType> getXmlApiResponseClass() {
		return DEPCHQREGAPIType.class;
	}
	
	private DEPCHQREGAPIType transformChequeStatusUpdateToDEPCHQREGAPIType(ChequeStatusUpdate dataObject, CbsXmlApiOperation oper){
		DEPCHQREGAPIType apiType = new DEPCHQREGAPIType();
		super.setTechColsFromDataObject(dataObject, apiType);
		if (dataObject.getVersion()!=null){
			apiType.setVERSION(dataObject.getVersion());
		}
		apiType.setOPERATION(oper.getOperation());
		apiType.setACCTNO(dataObject.getAcctNo());
		apiType.setDOCTYPE(dataObject.getDocType());
		apiType.setSTATUS(dataObject.getStatus());
		apiType.setCHEQUENO((dataObject.getChequeNo()!=null)?dataObject.getChequeNo().doubleValue():null);
		apiType.setBRANCH(dataObject.getBranch());
		apiType.setTRANTYPE(dataObject.getTranType());
		apiType.setTRANAMT((dataObject.getTranAmt()!=null)?dataObject.getTranAmt().doubleValue():null);
		apiType.setTRANDATE(dateTimeHelper.convertToCbsXmlApiDate(dataObject.getTranDate()));
		apiType.setPREVSTATUS(dataObject.getPrevStatus());
		apiType.setEFFECTDATE(dateTimeHelper.convertToCbsXmlApiDate(dataObject.getEffectDate()));
		apiType.setTOACCTNO(dataObject.getToAcctNo());
		return apiType;
	}

	@Override
	protected List<ChequeStatusUpdate> processXmlApiListRs(ChequeStatusUpdate arg0, DEPCHQREGAPIType arg1) {
		return new ArrayList<>();
	}

}
