package com.silverlakesymmetri.cbs.dep.svc;

import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.svc.BusinessService;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.AcctClosureQryWrapper;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.AcctClosureQryWrapperJpe;

import java.util.List;
import java.util.Map;

public interface AcctClosureQryWrapperService extends BusinessService<AcctClosureQryWrapper, AcctClosureQryWrapperJpe> {

    public static final String SVC_OP_NAME_ACCTCLOSUREQRYWRAPPERSERVICE_GET = "AcctClosureQryWrapperService.get";
    public static final String SVC_OP_NAME_ACCTCLOSUREQRYWRAPPERSERVICE_QUERY = "AcctClosureQryWrapperService.query";

    @ServiceOperation(name = SVC_OP_NAME_ACCTCLOSUREQRYWRAPPERSERVICE_GET, type = ServiceOperation.ServiceOperationType.GET)
    public AcctClosureQryWrapper getByPk(String acct, AcctClosureQryWrapper dataObject);

    @ServiceOperation(name = SVC_OP_NAME_ACCTCLOSUREQRYWRAPPERSERVICE_QUERY, type = ServiceOperation.ServiceOperationType.GET)
    public List<AcctClosureQryWrapper> query(int offset, int resultLimit, String groupBy, String order, Map<String, Object> filters);

}