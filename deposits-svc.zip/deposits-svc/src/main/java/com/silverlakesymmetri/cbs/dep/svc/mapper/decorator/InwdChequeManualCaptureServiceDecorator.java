package com.silverlakesymmetri.cbs.dep.svc.mapper.decorator;

import org.mapstruct.Context;
import org.mapstruct.MappingTarget;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

import com.silverlakesymmetri.cbs.commons.xmlapi.enums.CbsXmlApiOperation;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.InwdChequeManualCaptureJpe;
import com.silverlakesymmetri.cbs.dep.svc.mapper.InwdChequeManualCaptureServiceMapper;
import com.silverlakesymmetri.cbs.dep.xmlapi.DEPINWDCHEQUEAPIType;

public abstract class InwdChequeManualCaptureServiceDecorator implements InwdChequeManualCaptureServiceMapper {

	@Autowired
	@Qualifier("delegate")
	protected InwdChequeManualCaptureServiceMapper delegate;

	@Override
	public DEPINWDCHEQUEAPIType mapToApi(InwdChequeManualCaptureJpe jpe, @Context CbsXmlApiOperation oper) {
		DEPINWDCHEQUEAPIType req = delegate.mapToApi(jpe, oper);
		return req;
	}

	@Override
	public InwdChequeManualCaptureJpe mapToJpe(DEPINWDCHEQUEAPIType api, @MappingTarget InwdChequeManualCaptureJpe jpe) {
		if (jpe == null) {
			jpe = new InwdChequeManualCaptureJpe();
		}
		if (api == null) {
			return jpe;
		}
		jpe = delegate.mapToJpe(api, jpe);
		return jpe;
	}

}
