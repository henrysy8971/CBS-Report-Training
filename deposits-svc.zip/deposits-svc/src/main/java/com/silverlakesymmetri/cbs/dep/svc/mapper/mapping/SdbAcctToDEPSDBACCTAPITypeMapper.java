package com.silverlakesymmetri.cbs.dep.svc.mapper.mapping;

import org.mapstruct.MapperConfig;
import org.mapstruct.Mapping;
import org.mapstruct.Mappings;

import com.silverlakesymmetri.cbs.commons.jpa.util.DateTimeHelper;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.SdbAcctJpe;
import com.silverlakesymmetri.cbs.dep.xmlapi.DEPSDBACCTAPIType;

@MapperConfig(uses={ DateTimeHelper.class})
public interface SdbAcctToDEPSDBACCTAPITypeMapper {
	
	@Mappings({
		@Mapping(target="SDBINTERNALKEY",       source="sdbInternalKey"), 
		@Mapping(target="CONTRACTNO",       	source="contractNo"), 
		@Mapping(target="CLIENTNO",       		source="clientId"), 
		@Mapping(target="CLIENTIND",       		source="clientInd"), 
		@Mapping(target="BRANCH",       		source="branch"), 
		@Mapping(target="BOXNO",       			source="boxNo"), 
		@Mapping(target="CONTRACTDESC",       	source="contractDesc"), 
		@Mapping(target="SDBSTATUSNARRATIVE",   source="sdbStatusNarrative"), 
		@Mapping(target="CCY",       			source="ccy"), 
		@Mapping(target="PRODUCTCODE",       	source="productCode"), 
		@Mapping(target="DATEOPEN",       		source="dateOpen", qualifiedByName = {"DateTimeHelper","convertDateToCbsXmlApiDate"}), 
		@Mapping(target="STARTDATE",       		source="startDate", qualifiedByName = {"DateTimeHelper","convertDateToCbsXmlApiDate"}), 
		@Mapping(target="RENEWALFREQ",       	source="renewalFreq"), 
		@Mapping(target="RENEWALFREQTYPE",      source="renewalFreqType"), 
		@Mapping(target="RENEWDATE",       		source="renewDate", qualifiedByName = {"DateTimeHelper","convertDateToCbsXmlApiDate"}), 
		@Mapping(target="RENEWDAY",       		source="renewDay"), 
		@Mapping(target="KEYSISSUED",       	source="keysIssued"), 
		@Mapping(target="WITHLICENSEES",       	source="withLicensees"), 
		@Mapping(target="WITHASSIGNEES",       	source="withAssignees"), 
//		@Mapping(target="KEYDEPPAIDIND",       	source="keyDepPaidInd"), 
		@Mapping(target="KEYDEPPAIDIND",       	constant="Y"), 
		@Mapping(target="RENTALFEEACCTNO",      source="rentalFeeAcctNo"), 
		@Mapping(target="BOXSTATUS",       		source="boxStatus"), 
		@Mapping(target="SDBSTATUS",   			source="status"), 
	 })
	public DEPSDBACCTAPIType mapSdbAcctJpeToDEPSDBACCTAPIType(SdbAcctJpe jpe);	
	

}



