package com.silverlakesymmetri.cbs.dep.svc;

import java.util.List;
import java.util.Map;

import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation;
import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation.ServiceOperationType;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.svc.BusinessService;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.AcctSweep;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.AcctSweepJpe;

/**
 * 
 * @author Jeffrey.Villanueva
 *
 */
public interface AcctSweepService extends BusinessService<AcctSweep, AcctSweepJpe> {
	public static final String SVC_OP_NAME_ACCTSWEEPSERVICE_GET= "AcctSweepService.get";
	public static final String SVC_OP_NAME_ACCTSWEEPSERVICE_QUERY= "AcctSweepService.query";
	public static final String SVC_OP_NAME_ACCTSWEEPSERVICE_CREATE= "AcctSweepService.create";
	public static final String SVC_OP_NAME_ACCTSWEEPSERVICE_UPDATE= "AcctSweepService.update";
	public static final String SVC_OP_NAME_ACCTSWEEPSERVICE_DELETE= "AcctSweepService.delete";
	public static final String SVC_OP_NAME_ACCTSWEEPSERVICE_FIND= "AcctSweepService.find";
	public static final String  SVC_OP_NAME_ACCTSWEEPSERVICE_COUNT = "AcctSweepService.count";
	
	@ServiceOperation(name = SVC_OP_NAME_ACCTSWEEPSERVICE_CREATE)
    public AcctSweep create(AcctSweep dataObject);

    @ServiceOperation(name = SVC_OP_NAME_ACCTSWEEPSERVICE_UPDATE)
    public AcctSweep update(AcctSweep dataObject);

    @ServiceOperation(name = SVC_OP_NAME_ACCTSWEEPSERVICE_DELETE)
    public boolean delete(AcctSweep dataObject);

    @ServiceOperation(name = SVC_OP_NAME_ACCTSWEEPSERVICE_QUERY)
    public List<AcctSweep> query(int offset, int resultLimit, String groupBy, String order, Map<String, Object> filters);

    @ServiceOperation(name = SVC_OP_NAME_ACCTSWEEPSERVICE_FIND)
    public List<AcctSweep> find(FindCriteria findCriteria, CbsHeader cbsHeader);

    @ServiceOperation(name = SVC_OP_NAME_ACCTSWEEPSERVICE_GET, type = ServiceOperationType.GET)
    public AcctSweep getByPk(String publicKey, AcctSweep reference);
    
    @ServiceOperation(name = SVC_OP_NAME_ACCTSWEEPSERVICE_COUNT, type = ServiceOperationType.GET)
	public Long count(FindCriteria findCriteria, CbsHeader cbsHeader);
}
