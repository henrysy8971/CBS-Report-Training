package com.silverlakesymmetri.cbs.dep.svc;

import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation;
import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation.ServiceOperationType;
import com.silverlakesymmetri.cbs.commons.svc.BusinessService;
import com.silverlakesymmetri.cbs.csd.bdo.sdo.Branch;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.FeeInquiryHdr;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.FeeInquiryHdrJpe;

import java.util.List;
import java.util.Map;

public interface DepositsFeeService extends BusinessService<FeeInquiryHdr, FeeInquiryHdrJpe> {

    public static final String SVC_OP_NAME_DEPOSITSFEESERVICE_INQUIRY = "DepositsFeeService.feeInquiry";
    public static final String SVC_OP_NAME_DEPOSITSFEESERVICE_GET = "DepositsFeeService.get";
    public static final String SVC_OP_NAME_DEPOSITSFEESERVICE_QUERY = "DepositsFeeService.query";

    @ServiceOperation(name = SVC_OP_NAME_DEPOSITSFEESERVICE_INQUIRY, type = ServiceOperationType.EXECUTE)
    public FeeInquiryHdr feeInquiry(FeeInquiryHdr dataObject);

	@ServiceOperation(name = SVC_OP_NAME_DEPOSITSFEESERVICE_GET, type = ServiceOperationType.GET)
    public FeeInquiryHdr getByPk(String publicKey, FeeInquiryHdr reference);

    @ServiceOperation(name = SVC_OP_NAME_DEPOSITSFEESERVICE_QUERY)
    public List<FeeInquiryHdr> query(int offset, int resultLimit, String groupBy, String order, Map<String, Object> filters);

}
