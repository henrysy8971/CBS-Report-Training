package com.silverlakesymmetri.cbs.dep.svc.ext;

import com.silverlakesymmetri.cbs.commons.logging.CbsAppLogger;
import com.silverlakesymmetri.cbs.commons.logging.CbsAppLoggerFactory;
import com.silverlakesymmetri.cbs.xps.svc.util.ReleaseAcctRestraintCapable;
import org.springframework.stereotype.Service;

@Service
public class ImportLcDiscrepancyRestraintCreateServiceExtImpl extends AbstractTfnAcctRestraintServiceExtImpl implements ReleaseAcctRestraintCapable {

	private static CbsAppLogger logger = CbsAppLoggerFactory.getLogger(ImportLcDiscrepancyRestraintCreateServiceExtImpl.class.getName());
	
    @Override
    public String[] getExtendedBdoNames() {
        return new String[] { "ImportLcDiscrepancy" };
    }

    @Override
    public String[] getExtendedServiceNames() {
        return new String[] {"ImportLcDiscrepancyService.create"};
    }

    protected CbsAppLogger getLogger() {
    	return logger;
    }
}
