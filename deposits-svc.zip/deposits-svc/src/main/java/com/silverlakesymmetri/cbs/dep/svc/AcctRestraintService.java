package com.silverlakesymmetri.cbs.dep.svc;

import java.util.List;
import java.util.Map;

import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation;
import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation.ServiceOperationType;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.svc.BusinessService;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.AcctRestraint;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.AcctRestraintJpe;

public interface AcctRestraintService extends BusinessService<AcctRestraint, AcctRestraintJpe>{
	
	public static final String SVC_OP_NAME_ACCTRESTRAINTSERVICE_GET= "AcctRestraintService.get";
	public static final String SVC_OP_NAME_ACCTRESTRAINTSERVICE_QUERY= "AcctRestraintService.query";
	public static final String SVC_OP_NAME_ACCTRESTRAINTSERVICE_CREATE= "AcctRestraintService.create";
	public static final String SVC_OP_NAME_ACCTRESTRAINTSERVICE_UPDATE= "AcctRestraintService.update";
	public static final String SVC_OP_NAME_ACCTRESTRAINTSERVICE_DELETE= "AcctRestraintService.removeRestraint";
	public static final String SVC_OP_NAME_ACCTRESTRAINTSERVICE_FIND= "AcctRestraintService.find";
	public static final String SVC_OP_NAME_ACCTRESTRAINTSERVICE_COUNT = "AcctRestraintService.count";
	public static final String SVC_OP_NAME_ACCTRESTRAINTSERVICE_GETCOUNT = "AcctRestraintService.getCount";

	@ServiceOperation(name = SVC_OP_NAME_ACCTRESTRAINTSERVICE_CREATE)
    public AcctRestraint create(AcctRestraint dataObject);

    @ServiceOperation(name = SVC_OP_NAME_ACCTRESTRAINTSERVICE_UPDATE)
    public AcctRestraint update(AcctRestraint dataObject);

    //delete is using update method - remove @ServiceOperation so this method cannot be identified as a BPM-enabled endpoint 
    //@ServiceOperation(name = SVC_OP_NAME_ACCTRESTRAINTSERVICE_DELETE)
    public boolean delete(AcctRestraint dataObject);

    @ServiceOperation(name = SVC_OP_NAME_ACCTRESTRAINTSERVICE_DELETE, type = ServiceOperationType.EXECUTE, useMethodForBpmApproval = true)
    public AcctRestraint removeRestraint(AcctRestraint dataObject);

    @ServiceOperation(name = SVC_OP_NAME_ACCTRESTRAINTSERVICE_QUERY)
    public List<AcctRestraint> query(int offset, int resultLimit, String groupBy, String order, Map<String, Object> filters);
    
    @ServiceOperation(name = SVC_OP_NAME_ACCTRESTRAINTSERVICE_FIND)
    public List<AcctRestraint> find(FindCriteria findCriteria, CbsHeader cbsHeader);

    @ServiceOperation(name = SVC_OP_NAME_ACCTRESTRAINTSERVICE_GET, type = ServiceOperationType.GET)
    public AcctRestraint getByPk(String publicKey, AcctRestraint reference);

	@ServiceOperation(name = SVC_OP_NAME_ACCTRESTRAINTSERVICE_COUNT, type = ServiceOperationType.GET)
	public Long count(FindCriteria findCriteria, CbsHeader cbsHeader);

	@ServiceOperation(name = SVC_OP_NAME_ACCTRESTRAINTSERVICE_GETCOUNT, type = ServiceOperationType.GET, passParamAsMap = true)
	public Long getCount(Map<String, Object> filters);

}
