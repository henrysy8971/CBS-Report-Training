 package com.silverlakesymmetri.cbs.dep.svc;

import java.util.List;
import java.util.Map;

import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation;
import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation.ServiceOperationType;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.svc.BusinessService;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.CiVerificationQry;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.CiVerificationSummaryQry;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.CiVerificationQryJpe;


public interface CiVerificationService extends BusinessService<CiVerificationQry, CiVerificationQryJpe> {

    public static final String SVC_OP_NAME_CIVERIFICATION_VERIFY = "CiVerificationService.verify";
    public static final String SVC_OP_NAME_CIVERIFICATION_QUERY = "CiVerificationService.query";
    public static final String SVC_OP_NAME_CIVERIFICATION_FIND = "CiVerificationService.find";
    public static final String SVC_OP_NAME_CIVERIFICATION_GET = "CiVerificationService.get";
    public static final String SVC_OP_NAME_CIVERIFICATION_CALCTOTALS = "CiVerificationService.getTotal";

    @ServiceOperation(name = SVC_OP_NAME_CIVERIFICATION_GET, type = ServiceOperationType.GET)
    public CiVerificationQry getByPk(String publicKey, CiVerificationQry reference);

    @ServiceOperation(name = SVC_OP_NAME_CIVERIFICATION_VERIFY, type = ServiceOperationType.EXECUTE,
            useMethodForBpmApproval = true)
    public String verify(CiVerificationSummaryQry summary);
      
    @ServiceOperation(name = SVC_OP_NAME_CIVERIFICATION_QUERY)
    public List<CiVerificationQry> query(int offset, int resultLimit, String groupBy, String order, Map<String, Object> filters);

    @ServiceOperation(name = SVC_OP_NAME_CIVERIFICATION_FIND)
    public List<CiVerificationQry> find(FindCriteria findCriteria, CbsHeader cbsHeader);
    
    @ServiceOperation(name = SVC_OP_NAME_CIVERIFICATION_CALCTOTALS)
    public List<CiVerificationSummaryQry> getTotal(FindCriteria findCriteria, CbsHeader cbsHeader);
}
