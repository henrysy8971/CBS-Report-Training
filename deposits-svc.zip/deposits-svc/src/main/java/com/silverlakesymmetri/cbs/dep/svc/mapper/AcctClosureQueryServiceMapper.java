package com.silverlakesymmetri.cbs.dep.svc.mapper;

import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.AcctClosureJpe;
import com.silverlakesymmetri.cbs.dep.svc.mapper.mapping.AcctClosureQueryToDEPACCTCLOSUREAPITypeMapper;
import com.silverlakesymmetri.cbs.dep.xmlapi.DEPACCTCLOSUREAPIType;
import org.mapstruct.InheritConfiguration;
import org.mapstruct.InheritInverseConfiguration;
import org.mapstruct.Mapper;
import org.mapstruct.MappingTarget;

@Mapper(config= AcctClosureQueryToDEPACCTCLOSUREAPITypeMapper.class)
public interface AcctClosureQueryServiceMapper {
	
	@InheritConfiguration
	DEPACCTCLOSUREAPIType mapToApi(AcctClosureJpe jpe);
	
	@InheritInverseConfiguration(name = "mapAcctClosureQueryToDEPACCTCLOSUREAPIType")
	AcctClosureJpe mapToJpe(DEPACCTCLOSUREAPIType api, @MappingTarget AcctClosureJpe jpe);
}
