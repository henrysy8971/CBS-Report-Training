package com.silverlakesymmetri.cbs.dep.svc.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.mysema.query.types.EntityPath;
import com.silverlakesymmetri.cbs.commons.jpa.service.CbsGenericDataService;
import com.silverlakesymmetri.cbs.commons.svc.AbstractXmlApiBusinessService;
import com.silverlakesymmetri.cbs.commons.svc.BusinessObjectValidationCapable;
import com.silverlakesymmetri.cbs.commons.xmlapi.enums.CbsXmlApiOperation;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.CiAdministrationWrapper;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.CiAdministrationWrapperJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.QCiAdministrationWrapperJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.id.CiAdministrationWrapperPk;
import com.silverlakesymmetri.cbs.dep.svc.ChequeAdministrationWrapperService;
import com.silverlakesymmetri.cbs.dep.xmlapi.DEPCISTATUSUPDATEAPIType;

@Service
@Transactional
public class ChequeAdministrationWrapperServiceImpl extends AbstractXmlApiBusinessService<CiAdministrationWrapper, CiAdministrationWrapperJpe, CiAdministrationWrapperPk, DEPCISTATUSUPDATEAPIType, DEPCISTATUSUPDATEAPIType> 
	implements ChequeAdministrationWrapperService, BusinessObjectValidationCapable<CiAdministrationWrapper> {
	
	@Autowired(required = true)
    @Qualifier("cbsGenericDataService")
    protected CbsGenericDataService dataService;
	
	@Override
	public CiAdministrationWrapper getByPk(String publicKey, CiAdministrationWrapper reference) {
		return null;
	}

	@Override
	public CiAdministrationWrapper update(CiAdministrationWrapper dataObject) {
		return super.update(dataObject);
	}

	@Override
	protected Class<DEPCISTATUSUPDATEAPIType> getXmlApiResponseClass() {
		return DEPCISTATUSUPDATEAPIType.class;
	}

	@Override
	protected List<CiAdministrationWrapper> processXmlApiListRs(CiAdministrationWrapper arg0,
			DEPCISTATUSUPDATEAPIType arg1) {
		return null;
	}

	@Override
	protected CiAdministrationWrapper processXmlApiRs(CiAdministrationWrapper arg0, DEPCISTATUSUPDATEAPIType arg1) {
		return arg0;
	}

	@Override
	protected EntityPath<CiAdministrationWrapperJpe> getEntityPath() {
		return QCiAdministrationWrapperJpe.ciAdministrationWrapperJpe;
	}

	@Override
	protected CiAdministrationWrapperPk getIdFromDataObjectInstance(CiAdministrationWrapper dataObject) {
		return new CiAdministrationWrapperPk(dataObject.getSeqNo());
	}

	@Override
	protected DEPCISTATUSUPDATEAPIType transformBdoToXmlApiRqCreate(CiAdministrationWrapper dataObject) {
		return transformCiAdministrationToDEPCISTATUSUPDATEAPIType(dataObject, CbsXmlApiOperation.INSERT);
	}
	
	@Override
	protected DEPCISTATUSUPDATEAPIType transformBdoToXmlApiRqUpdate(CiAdministrationWrapper dataObject) {
		return transformCiAdministrationToDEPCISTATUSUPDATEAPIType(dataObject, CbsXmlApiOperation.UPDATE);
	}

	@Override
	protected DEPCISTATUSUPDATEAPIType transformBdoToXmlApiRqDelete(CiAdministrationWrapper dataObject) {
		return transformCiAdministrationToDEPCISTATUSUPDATEAPIType(dataObject, CbsXmlApiOperation.DELETE);
	}
	
	private DEPCISTATUSUPDATEAPIType transformCiAdministrationToDEPCISTATUSUPDATEAPIType(
			CiAdministrationWrapper dataObject, CbsXmlApiOperation operation) {

        DEPCISTATUSUPDATEAPIType apiType = new DEPCISTATUSUPDATEAPIType();
        super.setTechColsFromDataObject(dataObject, apiType);

        apiType.setOPERATION(operation.getOperation());
        apiType.setCHEQUESTATUS(dataObject.getChequeStatus());
        apiType.setNARRATIVE(dataObject.getNarrative());
        apiType.setSEQNO(dataObject.getSeqNo());
        
        /*
        Map<String,Object> params = new HashMap<String, Object>();
        params.put("chequeRefNo", dataObject.getChequeRefNo());
        List<CiDetailActiveJpe> ciDetailJpeList = dataService.findWithNamedQuery(DepJpeConstants.CIDETAILACTIVE_JPE_FIND_BY_CHEQUEREFNO, params, CiDetailActiveJpe.class);        
        apiType.setSEQNO(ciDetailJpeList.get(0).getSeqNo());
        */
        
        return apiType;
    }
}
