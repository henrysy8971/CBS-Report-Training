package com.silverlakesymmetri.cbs.dep.svc;

import java.util.List;
import java.util.Map;

import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation;
import com.silverlakesymmetri.cbs.commons.annotation.ServiceOperation.ServiceOperationType;
import com.silverlakesymmetri.cbs.commons.svc.BusinessService;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.ClientNoTfrHeader;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.ClientNoTfrHeaderJpe;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.Acct;
import com.silverlakesymmetri.cbs.mcl.bdo.sdo.Client;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;

public interface ClientNoTransferService extends BusinessService<ClientNoTfrHeader, ClientNoTfrHeaderJpe> {

    public static final String SVC_OP_NAME_CLIENTNOTRANSFERSERVICE_CREATE = "ClientNoTransferService.create";
    public static final String SVC_OP_NAME_CLIENTNOTRANSFERSERVICE_QUERY = "ClientNoTransferService.query";
    public static final String SVC_OP_NAME_CLIENTNOTRANSFERSERVICE_GET = "ClientNoTransferService.get";
    public static final String SVC_OP_NAME_CLIENTNOTRANSFERSERVICE_UPDATE = "ClientNoTransferService.update";
    public static final String SVC_OP_NAME_CLIENTNOTRANSFERSERVICE_DELETE = "ClientNoTransferService.delete";
    public static final String SVC_OP_NAME_CLIENTNOTRANSFERSERVICE_FIND = "ClientNoTransferService.find";
    public static final String SVC_OP_NAME_CLIENTNOTRANSFERSERVICE_COUNT = "ClientNoTransferService.count";
    public static final String SVC_OP_NAME_CLIENTNOTRANSFERSERVICE_QUERYFROMCLIENTS = "ClientNoTransferService.queryfromclients";

    @ServiceOperation(name = SVC_OP_NAME_CLIENTNOTRANSFERSERVICE_CREATE)
    public ClientNoTfrHeader create(ClientNoTfrHeader dataObject);
    
    @ServiceOperation(name = SVC_OP_NAME_CLIENTNOTRANSFERSERVICE_QUERY)
    public List<ClientNoTfrHeader> query(int offset, int resultLimit, String groupBy, String order, Map<String, Object> filters);
    
    @ServiceOperation(name = SVC_OP_NAME_CLIENTNOTRANSFERSERVICE_GET, type = ServiceOperationType.GET)
    public ClientNoTfrHeader getByPk(String publicKey, ClientNoTfrHeader reference);

    @ServiceOperation(name = SVC_OP_NAME_CLIENTNOTRANSFERSERVICE_UPDATE)
    public ClientNoTfrHeader update(ClientNoTfrHeader objectInstanceIdentifier);
    
    @ServiceOperation(name = SVC_OP_NAME_CLIENTNOTRANSFERSERVICE_DELETE)
    public boolean delete(ClientNoTfrHeader objectInstanceIdentifier);
    
    @ServiceOperation(name = SVC_OP_NAME_CLIENTNOTRANSFERSERVICE_FIND)
    public List<ClientNoTfrHeader> find(FindCriteria findCriteria, CbsHeader cbsHeader);
    
    @ServiceOperation(name = SVC_OP_NAME_CLIENTNOTRANSFERSERVICE_COUNT, type = ServiceOperationType.GET)
	public Long count(FindCriteria findCriteria, CbsHeader cbsHeader);
    
    @ServiceOperation(name = SVC_OP_NAME_CLIENTNOTRANSFERSERVICE_QUERYFROMCLIENTS, type = ServiceOperationType.READ, passParamAsMap = true)
    public List<Client> queryFromClients(Map<String, Object> queryParams);
    
}
