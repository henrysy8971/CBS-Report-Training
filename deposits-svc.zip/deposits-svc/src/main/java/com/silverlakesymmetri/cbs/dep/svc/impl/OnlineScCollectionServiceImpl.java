package com.silverlakesymmetri.cbs.dep.svc.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mysema.query.types.EntityPath;
import com.silverlakesymmetri.cbs.commons.svc.AbstractXmlApiBusinessService;
import com.silverlakesymmetri.cbs.commons.xmlapi.enums.CbsXmlApiOperation;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.OnlineScCollection;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.AcctJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.OnlineScCollectionJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.QOnlineScCollectionJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.ScBatchSumJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.ScUncollJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.id.OnlineScCollectionPk;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.util.DepJpeConstants;
import com.silverlakesymmetri.cbs.dep.svc.OnlineScCollectionService;
import com.silverlakesymmetri.cbs.dep.svc.mapper.OnlineScCollectionServiceMapper;
import com.silverlakesymmetri.cbs.dep.xmlapi.DEPFEEONLINESETTLEAPIType;

@Service
public class OnlineScCollectionServiceImpl extends AbstractXmlApiBusinessService<OnlineScCollection, OnlineScCollectionJpe, OnlineScCollectionPk,  DEPFEEONLINESETTLEAPIType, DEPFEEONLINESETTLEAPIType> implements OnlineScCollectionService{
		
	@Autowired
	OnlineScCollectionServiceMapper mapper;
	
	@Override
	protected DEPFEEONLINESETTLEAPIType transformBdoToXmlApiRqCreate(OnlineScCollection dataObject) {
		// TODO Auto-generated method stub
		return mapToDEPFEEONLINESETTLEAPIType(dataObject, CbsXmlApiOperation.INSERT);
	}

	@Override
	protected DEPFEEONLINESETTLEAPIType transformBdoToXmlApiRqUpdate(OnlineScCollection dataObject) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	protected DEPFEEONLINESETTLEAPIType transformBdoToXmlApiRqDelete(OnlineScCollection dataObject) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	protected Class<DEPFEEONLINESETTLEAPIType> getXmlApiResponseClass() {
		// TODO Auto-generated method stub
		return DEPFEEONLINESETTLEAPIType.class;
	}

	@Override
	protected OnlineScCollectionPk getIdFromDataObjectInstance(OnlineScCollection dataObject) {
		OnlineScCollectionPk id = new OnlineScCollectionPk();
		return id;
	}

	@Override
	protected EntityPath<OnlineScCollectionJpe> getEntityPath() {
		// TODO Auto-generated method stub
		return QOnlineScCollectionJpe.onlineScCollectionJpe;
	}
	
	private AcctJpe getAccount(String acctNo){
		
		Map<String, Object> param = new HashMap<String, Object>();
		param.put("acctNo", acctNo);
		return dataService.getWithNamedQuery(DepJpeConstants.ACCT_JPE_FIND_BY_ACCTNO, param, AcctJpe.class);
	}
	
	@Override
	public OnlineScCollection getByPk(String acctNo, OnlineScCollection dataObject) {
		if (dataObject == null){
			dataObject = jaxbSdoHelper.createSdoInstance(OnlineScCollection.class);
		}
		dataObject.setAcctNo(acctNo);
		AcctJpe acctJpe = getAccount(acctNo);
		
		if (acctJpe == null){
			return dataObject;
		}
		
		Map<String, Object> parameters = new HashMap<String, Object>();
		parameters.put("internalKey", acctJpe.getInternalKey());
		
		List<ScUncollJpe> scUncollList = dataService.findWithNamedQuery(DepJpeConstants.SC_UNCOLL_JPE_FIND_BY_INTERNAL_KEY, parameters, ScUncollJpe.class);
		List<ScBatchSumJpe> scBatchSumList = dataService.findWithNamedQuery(DepJpeConstants.SC_BATCH_SUM_JPE_FIND_BY_INTERNAL_KEY, parameters, ScBatchSumJpe.class);
		OnlineScCollectionJpe onlineScCollectionJpe = jaxbSdoHelper.unwrap(dataObject);
		onlineScCollectionJpe.setScUncollList(scUncollList);
		onlineScCollectionJpe.setScBatchSumList(scBatchSumList);
		onlineScCollectionJpe.setPostScBatchSumYn(false);
		onlineScCollectionJpe.setPostScUncollYn(false);
		onlineScCollectionJpe.setTotalScBatchSum(getTotalScBatchSum(scBatchSumList));
		onlineScCollectionJpe.setTotalScUncoll(getTotalScUncoll(scUncollList));
		onlineScCollectionJpe.setInternalKey(acctJpe.getInternalKey());
		onlineScCollectionJpe.setPublicKey(acctNo);
		
		return dataObject;
	}
	
	private Double getTotalScBatchSum(List<ScBatchSumJpe> list){
		
		if (list == null || list.isEmpty()){
			return new Double(0);
		}
		Double total =  new Double(0);
		Double totalTax =  new Double(0);
		for (ScBatchSumJpe scBatch : list){
			total = Double.sum(total, scBatch.getScAmtUncoll());
			totalTax = Double.sum(totalTax, scBatch.getScTaxAmtUncoll());
		}
		return Double.sum(total, totalTax);
	}
	
	private Double getTotalScUncoll(List<ScUncollJpe> list){
		
		if (list == null || list.isEmpty()){
			return new Double(0);
		}
		
		Double total =  new Double(0);
		Double totalTax =  new Double(0);
		for (ScUncollJpe scUncoll : list){
			total = Double.sum(total, scUncoll.getUncollScAmt());
			totalTax = Double.sum(totalTax, scUncoll.getUncollScTaxAmt());
		}
		return Double.sum(total, totalTax);		
	}
	
//	@Override
//	public List<OnlineIntCap> query(int offset, int resultLimit, String groupBy, String order, Map<String, Object> filters) {
//		
//		// TODO Auto-generated method stub
//		if (filters.isEmpty() ){
//			return null;
//		}
//		
//		if (!filters.containsKey("acctNo") || !filters.containsKey("paymentOption")){
//			return null;
//		}
//		
//		OnlineIntCap dataObject = jaxbSdoHelper.createSdoInstance(OnlineIntCap.class);
//		dataObject.setAcctNo((String)filters.get("acctNo"));
//		dataObject.setPaymentOption((String)filters.get("paymentOption"));
//		
//		OnlineIntCap bdo = queryDataObject(mapToDEPACCTINTCAPAPIType(dataObject, CbsXmlApiOperation.QUERY));
//		
//		List<OnlineIntCap> list = new ArrayList<OnlineIntCap>();
//		list.add(bdo);
//		
//		return list;
//	}
	
	private DEPFEEONLINESETTLEAPIType mapToDEPFEEONLINESETTLEAPIType(OnlineScCollection bdo, CbsXmlApiOperation oper){
			   
		OnlineScCollectionJpe jpe = jaxbSdoHelper.unwrap(bdo);
		DEPFEEONLINESETTLEAPIType apiType =   mapper.mapToApi(jpe, oper, new HashMap());
		super.setTechColsFromDataObject(bdo, apiType);	   
	   
	   return apiType;
	}
	
	
    public OnlineScCollection create(OnlineScCollection onlineIntCap){
    	
    	onlineIntCap = super.create(onlineIntCap);
    	
//    	OnlineScCollectionJpe jpe = jaxbSdoHelper.unwrap(onlineIntCap);
//    	if (jpe.isPostScBatchSumYn()){
//    		jpe.setScBatchSumList(null);
//    		jpe.setTotalScBatchSum(new Double(0));
//    		jpe.setPostScBatchSumYn(false);
//    	}
//    	
//    	if (jpe.isPostScUncollYn()){
//    		jpe.setScUncollList(null);
//    		jpe.setTotalScUncoll(new Double(0));
//    		jpe.setPostScUncollYn(false);
//    	}
//    	
//    	return jaxbSdoHelper.wrap(jpe);
    	
    	return getByPk(onlineIntCap.getAcctNo(), onlineIntCap);
	}
    
//    protected OnlineScCollection preCreateObject(OnlineScCollection dataObject) {
//    	
//    	OnlineScCollectionJpe jpe = unwrap(dataObject);
//    	AcctJpe acctJpe = getAccount(dataObject.getAcctNo());
//    	jpe.setInternalKey(acctJpe.getInternalKey());
//    	
//    	return super.preCreateObject(wrap(jpe));
//	}
    
    protected OnlineScCollection preCreateValidation(OnlineScCollection dataObject){
    	
    	OnlineScCollectionJpe jpe = unwrap(dataObject);
    	AcctJpe acctJpe = getAccount(dataObject.getAcctNo());
    	jpe.setInternalKey(acctJpe.getInternalKey());
    	dataObject = wrap(jpe);
    	return super.preCreateValidation(dataObject);
    }
	
	@Override
	protected List<OnlineScCollection> processXmlApiListRs(OnlineScCollection dataObject,
			DEPFEEONLINESETTLEAPIType xmlApiRs) {
		// TODO Auto-generated method stub
		return null;
	}
    
    @Override
	protected OnlineScCollection processXmlApiRs(OnlineScCollection dataObject, DEPFEEONLINESETTLEAPIType xmlApiRs) {
		
//    	if (dataObject == null){
//    		dataObject = jaxbSdoHelper.createSdoInstance(OnlineScCollection.class);
//    	}
//    	OnlineScCollectionJpe jpe = jaxbSdoHelper.unwrap(dataObject);
//		mapper.mapToJpe(xmlApiRs, jpe);
//		return jaxbSdoHelper.wrap(jpe);
    	
    	return dataObject;
	}

//	private MasterAccountJpe getMasterAccount( String accountNo) {
//  final Map<String, Object> param = new HashMap<String, Object>();
//  param.put(CoreConstants.ATTR_ACCOUNT_DOMAIN, "DEPOSIT");
//  param.put(CoreConstants.ATTR_ACCOUNT_NO, accountNo);
//  MasterAccountJpe masterAccountRec = dataService.getWithNamedQuery(JpeConstants.MASTER_ACCOUNT_JPE_GET_ACCOUNT_BY_DOMAIN_ACCOUNT_NO,
//          param, MasterAccountJpe.class);
//  return masterAccountRec;
//}

}
