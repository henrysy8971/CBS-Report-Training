package com.silverlakesymmetri.cbs.dep.svc.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mysema.query.types.EntityPath;
import com.silverlakesymmetri.cbs.commons.bdo.CbsHeader;
import com.silverlakesymmetri.cbs.commons.bdo.FindCriteria;
import com.silverlakesymmetri.cbs.commons.svc.AbstractXmlApiBusinessService;
import com.silverlakesymmetri.cbs.commons.xmlapi.enums.CbsXmlApiOperation;
import com.silverlakesymmetri.cbs.dep.bdo.sdo.TdSo;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.QTdSoJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.TdSoJpe;
import com.silverlakesymmetri.cbs.dep.jpa.mapping.sdo.id.TdSoPk;
import com.silverlakesymmetri.cbs.dep.svc.TdSoService;
import com.silverlakesymmetri.cbs.dep.svc.mapper.TdSoServiceMapper;
import com.silverlakesymmetri.cbs.dep.xmlapi.DEPTDSOAPIType;


@Service
public class TdSoServiceImpl extends 
									AbstractXmlApiBusinessService<TdSo, TdSoJpe, TdSoPk,  DEPTDSOAPIType, DEPTDSOAPIType>  
									implements TdSoService{

	private static final String DEP_TD_SO = "DEP_TD_SO_S";

	@Autowired
	TdSoServiceMapper mapper;
	
	@Override
	protected DEPTDSOAPIType transformBdoToXmlApiRqCreate(TdSo dataObject) {
		// TODO Auto-generated method stub
		 return transformTdSoToDEPTDSOAPIType( dataObject, CbsXmlApiOperation.INSERT);
	}

	@Override
	protected DEPTDSOAPIType transformBdoToXmlApiRqUpdate(TdSo dataObject) {
		// TODO Auto-generated method stub
		return transformTdSoToDEPTDSOAPIType( dataObject, "Y".equals(dataObject.getCancel())? CbsXmlApiOperation.DELETE : CbsXmlApiOperation.UPDATE);
	}

	@Override
	protected DEPTDSOAPIType transformBdoToXmlApiRqDelete(TdSo dataObject) {
		// TODO Auto-generated method stub
		return transformTdSoToDEPTDSOAPIType( dataObject, CbsXmlApiOperation.DELETE);
	}

	@Override
	protected TdSo processXmlApiRs(TdSo dataObject, DEPTDSOAPIType xmlApiRs) {
		// TODO Auto-generated method stub
		TdSoJpe jpe = jaxbSdoHelper.unwrap(dataObject);
		jpe = mapper.mapToJpe(xmlApiRs, jpe);
		
		return jaxbSdoHelper.wrap(jpe);
	}

	@Override
	protected List<TdSo> processXmlApiListRs(TdSo dataObject, DEPTDSOAPIType xmlApiRs) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	protected Class<DEPTDSOAPIType> getXmlApiResponseClass() {
		// TODO Auto-generated method stub
		return DEPTDSOAPIType.class;
	}

	@Override
	protected TdSoPk getIdFromDataObjectInstance(TdSo dataObject) {
		// TODO Auto-generated method stub
		TdSoJpe jpe = jaxbSdoHelper.unwrap(dataObject);
		return new TdSoPk(jpe.getSeqNo());
	}

	@Override
	protected EntityPath<TdSoJpe> getEntityPath() {
		// TODO Auto-generated method stub
		return QTdSoJpe.tdSoJpe; //siHeaderJpe;
	}

	@Override
	public TdSo getByPk(String publicKey, TdSo reference) {
		// TODO Auto-generated method stub
		return super.getByPk(publicKey, reference);
	}

	@Override
	public TdSo create(TdSo tdSo) {
		// TODO Auto-generated method stub
		return super.create(tdSo);
//		return null;
	}

	@Override
	public TdSo update(TdSo tdSo) {
		// TODO Auto-generated method stub
		return super.update(tdSo);
	}

	@Override
	public boolean delete(TdSo tdSo) {
		// TODO Auto-generated method stub
		return super.delete(tdSo);
	}

	@Override
	public List<TdSo> query(int offset, int resultLimit, String groupBy, String order,
			Map<String, Object> filters) {
		// TODO Auto-generated method stub
		return super.query(offset, resultLimit, groupBy, order, filters);
	}

	@Override
	public List<TdSo> find(FindCriteria findCriteria, CbsHeader cbsHeader) {
		// TODO Auto-generated method stub
		return super.find(findCriteria, cbsHeader);
	}
		
	private DEPTDSOAPIType transformTdSoToDEPTDSOAPIType(TdSo dataObject, CbsXmlApiOperation oper){
		
//		Map map = new HashMap();
//		CbsSessionContext sessionCtx = _ctxMngr.getContext(CbsSessionContext.class);
//		map.put(mapper.BRANCH, super.getUserBranch(sessionCtx.getUserCode()));
		
		TdSoJpe jpe = jaxbSdoHelper.unwrap(dataObject);
		DEPTDSOAPIType api =  mapper.mapToApi(jpe, oper, new HashMap());
		super.setTechColsFromDataObject(dataObject, api);
				
		return api;
	}

	@Override
	protected TdSo preCreateValidation(TdSo dataObject) {
		Long seqNo = dataService.nextSequenceValue(DEP_TD_SO).longValue();
		dataObject.setSeqNo(seqNo);
		return super.preCreateValidation(dataObject);
	}

	//	@Autowired
//	private Auditor auditor;
	
//	protected SiHeader preCreateObject(SiHeader dataObject) {
//		SiHeaderJpe jpe = unwrap(dataObject);
////		validateEntity(jpe);	
//		auditor.prePersistCallback(jpe);
//		return wrap(jpe);
//	}
//	
//	protected SiHeader preUpdateObject(SiHeader dataObject) {
//		SiHeaderJpe jpe = unwrap(dataObject);
//		validateEntity(jpe);
//		auditor.preUpdateCallback(jpe);
//		return wrap(jpe);
//	}
	
//	protected SiHeader preDeleteObject(SiHeader dataObject) {
//		SiHeaderJpe jpe = unwrap(dataObject);
//        removeVirtualAttributes(jpe);
//        auditor.auditDeleteOperation(jpe);
//		return dataObject;
//	}

}
